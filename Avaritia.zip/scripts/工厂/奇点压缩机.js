const library = require("base/library");
const myliquids = require("液体");
const myitems = require("物品");
const 奇点压缩机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "奇点压缩机", [{
    input: {
        items: ["metaglass/2500"],
        liquids: ["slag/50"],
        power: 100,
    },
    output: {
        items: ["avaritia-钢化玻璃奇点/1"],
    },
    craftTime: 2460,
}, {
    input: {
        items: ["copper/3500"],
        liquids: ["slag/50"],
        power: 100,
    },
    output: {
        items: ["avaritia-铜奇点/1"],
    },
    craftTime: 2460,
}, {
    input: {
        items: ["lead/3500"],
        liquids: ["slag/50"],
        power: 1,
    },
    output: {
        items: ["avaritia-铅奇点/1"],
    },
    craftTime: 2460,
}, {
    input: {
        items: ["graphite/2500"],
        liquids: ["slag/50"],
        power: 1,
    },
    output: {
        items: ["avaritia-石墨奇点/1"],
    },
    craftTime: 2460,
}, {
    input: {
        items: ["sand/3500"],
        liquids: ["slag/50"],
        power: 1,
    },
    output: {
        items: ["avaritia-沙子奇点/1"],
    },
    craftTime: 2460,
}, {
    input: {
        items: ["coal/3500"],
        liquids: ["slag/50"],
        power: 100,
    },
    output: {
        items: ["avaritia-煤炭奇点/1"],
    },
    craftTime: 2460
}, {
    input: {
        items: ["titanium/3500"],
        liquids: ["slag/50"],
        power: 100,
    },
    output: {
        items: ["avaritia-钛奇点/1"],
    },
    craftTime: 2460
}, {
    input: {
        items: ["thorium/3500"],
        liquids: ["slag/50"],
        power: 100,
    },
    output: {
        items: ["avaritia-钍奇点/1"],
    },
    craftTime: 2460
}, {
    input: {
        items: ["scrap/3500"],
        liquids: ["slag/50"],
        power: 100,
    },
    output: {
        items: ["avaritia-废料奇点/1"],
    },
    craftTime: 2460
}, {
    input: {
        items: ["silicon/2000"],
        liquids: ["slag/50"],
        power: 100,
    },
    output: {
        items: ["avaritia-硅奇点/1"],
    },
    craftTime: 2460
}, {
    input: {
        items: ["plastanium/1500"],
        liquids: ["slag/50"],
        power: 100,
    },
    output: {
        items: ["avaritia-塑钢奇点/1"],
    },
    craftTime: 2460
}]);