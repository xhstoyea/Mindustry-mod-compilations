Vars.content.blocks().each(block => {
	if (block instanceof Floor) {
		block.buildVisibility = BuildVisibility.shown;
		block.alwaysUnlocked = false;
	}
});