 const 水晶核心1 = extend(CoreBlock, "水晶核心1", {

     canBreak() {
         return Vars.state.teams.cores(Vars.player.team()).size > 0;
     },
     canReplace(other) {
         return other.alwaysReplace;
     },
     canPlaceOn(tile, team) {
         return true;
     },
 });
 exports.水晶核心1 = 水晶核心1;