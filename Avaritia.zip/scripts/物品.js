function newItem(name) {
    exports[name] = (() => {
        let myItem = extend(Item, name, {});
        return myItem;
    })();
}
newItem("钢化玻璃奇点")
newItem("铜奇点")
newItem("铅奇点")
newItem("石墨奇点")
newItem("沙子奇点")
newItem("煤炭奇点")
newItem("钍奇点")
newItem("废料奇点")
newItem("硅奇点")
newItem("塑钢奇点")
//newItem("【物品名称】")