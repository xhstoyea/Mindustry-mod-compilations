require("缩放强化");
MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000
require("工厂/奇点压缩机");
require("物品");
require("液体");
require("水晶核心1");
require("地形")