const level1 = extend(Wall, "lv1", {}); 
const level2 = extend(Wall, "lv2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },    
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;
const level3 = extend(Wall, "lv3", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;
const level4 = extend(Wall, "lv4", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;



//初代版本 copy from 创世神2
//修改 by 飞雨
//要是良心好就在复制的时候把这三段加上(卑微)
const drill1 = extend(Drill, "drill1", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const drill2 = extend(Drill, "drill2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const drill3 = extend(Drill, "drill3", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const drill4 = extend(Drill, "drill4", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const drill5 = extend(Drill, "drill5", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;



/*

const drillG = extend(Drill, "drillG", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少四阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

drillG.buildType = prov(() => {
	let  time = 60;
	let maxTime=time;
	var picked;
	return extend(MendProjector.MendBuild, T8, {
		updateTile() {

			this.super$updateTile();

			time-=Time.delta;
			if (time <= 0) {
				time=maxTime
				if(items.total() < itemCapacity && dominantItems > 0 && efficiency > 0){
   			        	float speed = Mathf.lerp(1f, liquidBoostIntensity, optionalEfficiency) * efficiency;

                			lastDrillSpeed = (speed * dominantItems * warmup) / delay;
                			warmup = Mathf.approachDelta(warmup, speed, warmupSpeed);
                			progress += delta() * dominantItems * speed * warmup;
					p.build.handleItem(this, Items.phaseFabric);
                			if(Mathf.chanceDelta(updateEffectChance * warmup))
                    			updateEffect.at(x + Mathf.range(size * 2f), y + Mathf.range(size * 2f));
            			}
			}
		},
		draw() {
			this.super$draw();
			Draw.z(Layer.effect);
			Lines.stroke(2, this.team.color);
			Draw.alpha(1);
			Lines.arc(this.x, this.y, maxTime/5, time / maxTime, 90);
		}
	})
});
*/


//工厂****************************************************************************************************




const sili1 = extend(GenericCrafter, "silicon-smelter1", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const sili2 = extend(GenericCrafter, "silicon-smelter2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const pls1 = extend(GenericCrafter, "plastanium-compressor1", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const pls2 = extend(GenericCrafter, "plastanium-compressor2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;



//发电****************************************************************************************************




const steam1 = extend(ConsumeGenerator, "steam-generator1", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const steam2 = extend(ConsumeGenerator, "steam-generator2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;




const TReactor1 = extend(NuclearReactor, "thorium-reactor1", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;


const TReactor2 = extend(NuclearReactor, "thorium-reactor2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const TReactor3 = extend(NuclearReactor, "thorium-reactor3", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const TReactor4 = extend(NuclearReactor, "thorium-reactor4", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少四阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;



//修复与力墙****************************************************************************************************



const rpg1 = extend(ItemTurret, "small-repair1", {});   //定义修复1附属
const rpg2 = extend(ItemTurret, "small-repair2", {});   //定义修复2附属

const mend1 = extend(MendProjector, "mend-projector1", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

mend1.buildType = prov(() => {
	const p = new BuildPayload(rpg1, Team.derelict);
	return extend(MendProjector.MendBuild, mend1, {
		updateTile() {
			this.super$updateTile();
			if (p.build.team != this.team) {
				p.build.team = this.team;
			}
			if (p.build.acceptItem(this,Items.phaseFabric) && this.items.get(Items.phaseFabric) >= 5) {
				p.build.handleItem(this, Items.phaseFabric);
				this.items.remove(Items.phaseFabric, 1);
			}
			p.update(null, this);
			p.set(this.x, this.y, p.build.payloadRotation);
		},
		draw() {
			this.super$draw();
			p.draw();
		},
		drawSelect() {
			this.super$drawSelect();
			Drawf.dashCircle(this.x, this.y, 200, Pal.accent); //点击时显示的虚线圆
		}
	})
});


const mend2 = extend(MendProjector, "mend-projector2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

mend2.buildType = prov(() => {
	const p = new BuildPayload(rpg2, Team.derelict);
	return extend(MendProjector.MendBuild, mend2, {
		updateTile() {
			this.super$updateTile();
			if (p.build.team != this.team) {
				p.build.team = this.team;
			}
			if (p.build.acceptItem(this,Items.phaseFabric) && this.items.get(Items.phaseFabric) >= 5) {
				p.build.handleItem(this, Items.phaseFabric);
				this.items.remove(Items.phaseFabric, 1);
			}
			p.update(null, this);
			p.set(this.x, this.y, p.build.payloadRotation);
		},
		draw() {
			this.super$draw();
			p.draw();
		},
		drawSelect() {
			this.super$drawSelect();
			Drawf.dashCircle(this.x, this.y, 240, Pal.accent); //点击时显示的虚线圆
		}
	})
});



const force1 = extend(ForceProjector, "force-projector1", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;
force1.itemConsumer = force1.consumeItem(Items.phaseFabric,1).boost();



const force2 = extend(ForceProjector, "force-projector2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;
force2.itemConsumer = force2.consumeItem(Items.phaseFabric,1).boost();


//运输****************************************************************************************************
const phaseC = extend(Conveyor, "phase-convey", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;
phaseC.hasPower=true;
phaseC.conductivePower=true;
phaseC.placeableLiquid=true;

//炮台****************************************************************************************************



const duo1 = extend(ItemTurret, "duo1", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const duo2 = extend(ItemTurret, "duo2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const duo3 = extend(ItemTurret, "duo3", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const duo4 = extend(ItemTurret, "duo4", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const duo5 = extend(ItemTurret, "duo5", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;


const duo6 = extend(ItemTurret, "duo6", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;




const duoG = extend(ItemTurret, "duoG", {

	canPlaceOn(tile, team, rotation){       
     		let data = Vars.player.team().data();
            	return (!data.getBuildings(duo1).isEmpty())&&(!data.getBuildings(duo2).isEmpty())&&(!data.getBuildings(duo3).isEmpty())&&(!data.getBuildings(duo4).isEmpty())&&(!data.getBuildings(duo5).isEmpty())&&(!data.getBuildings(duo6).isEmpty())&&(data.getBuildings(this).isEmpty());
        },

	drawPlace(x, y, rotation, valid){
	    	const tile = Vars.world.tile(x, y);
            	if(tile == null) return;
            	if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
     			let data = Vars.player.team().data();
			if((data.getBuildings(duo1).isEmpty())||(data.getBuildings(duo2).isEmpty())||(data.getBuildings(duo3).isEmpty())||(data.getBuildings(duo4).isEmpty())||(data.getBuildings(duo5).isEmpty())||(data.getBuildings(duo6).isEmpty())){
            			this.drawPlaceText("[purple]吾之信徒，为何不欢迎吾之到来", x, y, valid);
			}
			else if(!data.getBuildings(this).isEmpty()){
            			this.drawPlaceText("[purple]一山不容二虎，汝竟不知...??", x, y, valid);
			}
            	} 
	 	if(this.canPlaceOn(tile, Vars.player.team(), rotation)){
			this.drawPlaceText("[purple].......差强人意", x, y, valid);
		}
	}
}) ;



const scatter1 = extend(ItemTurret, "scatter1", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;


const scatter2 = extend(ItemTurret, "scatter2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;








const lancer1 = extend(PowerTurret, "lancer1", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const lancer2 = extend(PowerTurret, "lancer2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const lancer3 = extend(PowerTurret, "lancer3", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const lancer4 = extend(PowerTurret, "lancer4", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level4).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少四阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;




const arc1 = extend(PowerTurret, "arc1", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;


const arc2 = extend(PowerTurret, "arc2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;


const arc3 = extend(PowerTurret, "arc3", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;


const arc4 = extend(PowerTurret, "arc4", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;


const arc5 = extend(PowerTurret, "arc5", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level4).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少四阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;









const salvo1 = extend(ItemTurret, "salvo1", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;


const salvo2 = extend(ItemTurret, "salvo2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;


const salvo3 = extend(ItemTurret, "salvo3", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;



const fuse1 = extend(ItemTurret, "fuse1", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;


const fuse2 = extend(ItemTurret, "fuse2", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;





const copperSword = extend(PowerTurret, "copper-sword", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const leadSword = extend(PowerTurret, "lead-sword", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const titaniumSword = extend(PowerTurret, "titanium-sword", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const plastaniumSword = extend(PowerTurret, "plastanium-sword", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const thoriumSword = extend(PowerTurret, "thorium-sword", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const pfSword = extend(PowerTurret, "phase-fabric-sword", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const superSword = extend(PowerTurret, "swords'son", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;








const fy = extend(PowerTurret, "fy", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;


const ts = extend(PowerTurret, "throwing'Son", {});

const throwing = extend(PowerTurret, "throwing", {


	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }

}) ;



throwing.buildType = prov(() => {

	const p1 = new BuildPayload(ts, Team.derelict);
	const p2 = new BuildPayload(ts, Team.derelict);
	const p3 = new BuildPayload(ts, Team.derelict);
	const p4 = new BuildPayload(ts, Team.derelict);
	return extend(PowerTurret.PowerTurretBuild, throwing, {
		updateTile() {
			this.super$updateTile();
			if (p1.build.team != this.team) {
				p1.build.team = this.team;
			}
			p1.update(null, this);
			p1.set(this.x+4, this.y+4, p1.build.payloadRotation);

			if (p2.build.team != this.team) {
				p2.build.team = this.team;
			}
			p2.update(null, this);
			p2.set(this.x-4, this.y+4, p2.build.payloadRotation);

			if (p3.build.team != this.team) {
				p3.build.team = this.team;
			}
			p3.update(null, this);
			p3.set(this.x+4, this.y-4, p3.build.payloadRotation);

			if (p4.build.team != this.team) {
				p4.build.team = this.team;
			}
			p4.update(null, this);
			p4.set(this.x-4, this.y-4, p4.build.payloadRotation);
		}
	})
});





const zy = extend(PowerTurret, "zy", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;

const hzxb = extend(PowerTurret, "hzxb", {

	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level4).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少四阶升级中枢作为建造前置", x, y, valid);
            }
        }
}) ;



//单位*****************************************************************
const t3 = Seq.with();//血量<=1000
const t4  = Seq.with(); //血量<=9200
const t5  = Seq.with(); //血量<=26400
const t6  = Seq.with(); //血量<=162000
const t7  = Seq.with(); //血量<=500000
const t8  = Seq.with(); //血量<=2000000
const allTheUnits  = Seq.with(); //全部单位

Events.on(EventType.ClientLoadEvent, e => {
  Vars.content.units().each(u => {
    	if(!u.flying && !u.naval && !u.hidden && u.speed<=108){
      		if(u.health <= 1000){t3.add(u)}
      		else if(u.health <= 9200){t4.add(u)}
      		else if(u.health <= 26400){t5.add(u)}
      	}
	if(!u.naval && u.health > 26400){
      		if(u.health <= 162000&&u.hitSize <= 159){t6.add(u)}
      		else if(u.health <= 550000&&u.hitSize != 160){t7.add(u)}
      		else if(u.health <= 2000000){t8.add(u)}
	}
	if(u.flying && u.health>=6000 && !u.hidden && u.speed <= 165&&u.hitSize <= 159){allTheUnits.add(u)}
	if(!u.flying && !u.naval && !u.hidden){allTheUnits.add(u)}
  })
});










//正片********************************************************************


const T3 = extend(MendProjector, "T3spawn", {
	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level1).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少一阶升级中枢作为建造前置", x, y, valid);
            }
        }
});
T3.destructible = true;
T3.buildType = prov(() => {
	let  time = 130
	let maxTime=time;
	var picked;
	return extend(MendProjector.MendBuild, T3, {
		updateTile() {
			this.super$updateTile();
				if (!Vars.headless) {
					Vars.ui.showLabel("正在召唤单位........", 0.015, this.x, this.y);
				}
				time-=Time.delta;
				if (time <= 0) {
					this.kill();
      					picked = t3.get(Mathf.random(t3.size - 1))
    					if(this.team.data().countType(picked) < Units.getCap(this.team)){
						const spawned = picked.spawn(this.team,this.x, this.y);
				}
			}
		},
		draw() {
			this.super$draw();
			Draw.z(Layer.effect);
			Lines.stroke(2, this.team.color);
			Draw.alpha(1);
			Lines.arc(this.x, this.y, time/20, time / maxTime, 90);
		}
	})
});

const T4 = extend(MendProjector, "T4spawn", {
	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
});
T4.destructible = true;
T4.buildType = prov(() => {
	let  time = 190;
	let maxTime=time;
	var picked;
	return extend(MendProjector.MendBuild, T4, {
		updateTile() {
			this.super$updateTile();
				if (!Vars.headless) {
					Vars.ui.showLabel("正在召唤单位........", 0.015, this.x, this.y);
				}
				time-=Time.delta;
				if (time <= 0) {
					this.kill();
      					picked = t4.get(Mathf.random(t4.size - 1))
    					if(this.team.data().countType(picked) < Units.getCap(this.team)){
						const spawned = picked.spawn(this.team,this.x, this.y);
				}
			}
		},
		draw() {
			this.super$draw();
			Draw.z(Layer.effect);
			Lines.stroke(2, this.team.color);
			Draw.alpha(1);
			Lines.arc(this.x, this.y, time/20, time / maxTime, 90);
		}
	})
});

const T5 = extend(MendProjector, "T5spawn", {
	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level2).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少二阶升级中枢作为建造前置", x, y, valid);
            }
        }
});
T5.destructible = true;
T5.buildType = prov(() => {
	let  time = 250;
	let maxTime=time;
	var picked;
	return extend(MendProjector.MendBuild, T5, {
		updateTile() {
			this.super$updateTile();
				if (!Vars.headless) {
					Vars.ui.showLabel("正在召唤单位........", 0.015, this.x, this.y);
				}
				time-=Time.delta;
				if (time <= 0) {
					this.kill();
      					picked = t5.get(Mathf.random(t5.size - 1))
    					if(this.team.data().countType(picked) < Units.getCap(this.team)){
						const spawned = picked.spawn(this.team,this.x, this.y);
				}
			}
		},
		draw() {
			this.super$draw();
			Draw.z(Layer.effect);
			Lines.stroke(2, this.team.color);
			Draw.alpha(1);
			Lines.arc(this.x, this.y, time/20, time / maxTime, 90);
		}
	})
});



const T6 = extend(MendProjector, "T6spawn", {
	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
});
T6.destructible = true;
T6.buildType = prov(() => {
	let  time = 310;
	let maxTime=time;
	var picked;
	return extend(MendProjector.MendBuild, T6, {
		updateTile() {
			this.super$updateTile();
				if (!Vars.headless) {
					Vars.ui.showLabel("正在召唤单位........", 0.015, this.x, this.y);
				}
				time-=Time.delta;
				if (time <= 0) {
					this.kill();
      					picked = t6.get(Mathf.random(t6.size - 1))
    					if(this.team.data().countType(picked) < Units.getCap(this.team)){
						const spawned = picked.spawn(this.team,this.x, this.y);
				}
			}
		},
		draw() {
			this.super$draw();
			Draw.z(Layer.effect);
			Lines.stroke(2, this.team.color);
			Draw.alpha(1);
			Lines.arc(this.x, this.y, time/20, time / maxTime, 90);
		}
	})
});


const T7 = extend(MendProjector, "T7spawn", {
	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
});
T7.destructible = true;
T7.buildType = prov(() => {
	let  time = 370;
	let maxTime=time;
	var picked;
	return extend(MendProjector.MendBuild, T7, {
		updateTile() {
			this.super$updateTile();
				if (!Vars.headless) {
					Vars.ui.showLabel("正在召唤单位........", 0.015, this.x, this.y);
				}
				time-=Time.delta;
				if (time <= 0) {
					this.kill();
      					picked = t7.get(Mathf.random(t7.size - 1))
    					if(this.team.data().countType(picked) < Units.getCap(this.team)){
						const spawned = picked.spawn(this.team,this.x, this.y);
				}
			}
		},
		draw() {
			this.super$draw();
			Draw.z(Layer.effect);
			Lines.stroke(2, this.team.color);
			Draw.alpha(1);
			Lines.arc(this.x, this.y, time/20, time / maxTime, 90);
		}
	})
});



const T8 = extend(MendProjector, "T8spawn", {
	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level4).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少四阶升级中枢作为建造前置", x, y, valid);
            }
        }
});
T8.destructible = true;
T8.buildType = prov(() => {
	let  time = 610;
	let maxTime=time;
	var picked;
	return extend(MendProjector.MendBuild, T8, {
		updateTile() {
			this.super$updateTile();
				if (!Vars.headless) {
					Vars.ui.showLabel("正在召唤单位........", 0.015, this.x, this.y);
				}
				time-=Time.delta;
				if (time <= 0) {
					this.kill();
      					picked = t8.get(Mathf.random(t8.size - 1))
    					if(this.team.data().countType(picked) < Units.getCap(this.team)){
						const spawned = picked.spawn(this.team,this.x, this.y);
				}
			}
		},
		draw() {
			this.super$draw();
			Draw.z(Layer.effect);
			Lines.stroke(2, this.team.color);
			Draw.alpha(1);
			Lines.arc(this.x, this.y, time/20, time / maxTime, 90);
		}
	})
});



const free = extend(CoreBlock, "core-spawner", {
	canPlaceOn(tile, team, rotation){       
            let data = Vars.player.team().data();
            return !data.getBuildings(level3).isEmpty();
        },
	
	drawPlace(x, y, rotation, valid){
	    const tile = Vars.world.tile(x, y);
            if(tile == null) return;

            if(!this.canPlaceOn(tile, Vars.player.team(), rotation)){
                this.drawPlaceText("缺少三阶升级中枢作为建造前置", x, y, valid);
            }
        }
});
free.solid = false;
free.buildType = prov(() => {
	let  time = 600;
	let score = 600;
	let bili=1;
	var picked;
	return extend(CoreBlock.CoreBuild, free, {
		updateTile() {
			this.super$updateTile();
			time-=Time.delta;
			if (time <= 0) {
				picked=allTheUnits.get(Mathf.random(allTheUnits.size - 1))
				if(picked.health <= score){
				if(this.team.data().countType(picked) < Units.getCap(this.team))const spawned = picked.spawn(this.team,this.x, this.y);
					score=score-picked.health;
				}
				if(score < 200){
					score=Mathf.sqrt(Vars.state.tick*Vars.state.tick*Vars.state.tick/216000)+600;
					time=600;
					bili=this.health*100/this.maxHealth;
					this.maxHealth=Mathf.sqrt(Vars.state.tick*Vars.state.tick*Vars.state.tick/216000)+600;
					this.health=this.maxHealth*bili/100;
				}
			}
		},
		draw() {
			this.super$draw();
			Draw.z(Layer.effect);
			Lines.stroke(2, this.team.color);
			Draw.alpha(1);
			Lines.arc(this.x, this.y, time/20, time / 600, 90);
		}
	})
});



