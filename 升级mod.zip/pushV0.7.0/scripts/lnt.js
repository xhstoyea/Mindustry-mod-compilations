const lib = require('misc/lib')
const sS = require('misc/sectorSize')

const lnt = new JavaAdapter(Planet, {load(){
	this.meshLoader = prov(() => new HexMesh(lnt, 3))
	this.super$load()
}}, 'lnt', Planets.serpulo, 0.5)
sS.planetGrid(lnt, 2)
lnt.generator = extend(TantrosPlanetGenerator, {
    allowLanding(sector) {
        return false;
    },//关闭数字区块
    generateSector(sector) {
        return false;
    },//无基地
})
lnt.bloom = false
lnt.accessible = true
lnt.visible = true
lnt.alwaysUnlocked = true
lnt.clearSectorOnLose = true//扇区丢失时是否重置地图
lnt.enemyCoreSpawnReplace = false//攻击图核心变刷怪点
lnt.allowLaunchSchematics = true//开启发射核心蓝图
lnt.allowLaunchLoadout = true//开启携带资源发射
lnt.localizedName = "升级星球"
lnt.allowSectorInvasion = false//模拟攻击图入侵
lnt.allowWaveSimulation = true;//模拟后台波次
lnt.prebuildBase = false
lnt.orbitRadius = 3
lnt.startSector = 0
lnt.defaultCore = Blocks.coreFoundation
lnt.atmosphereColor = Color.valueOf('bebebe')
lnt.atmosphereRadIn = 0.03
lnt.atmosphereRadOut = 0.1
lnt.iconColor = Color.valueOf('bebebe')
lnt.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems)
lnt.orbitTime = 60  //公转 1分钟一圈（不是哥们你怎么做到的
lnt.rotateTime = 24 * 60 //自转 24分钟一圈


const start = new SectorPreset('start', lnt, 0)
start.description = "标志着你升级mod的开始"
start.difficulty = 0
start.localizedName = "起始大厅"
start.alwaysUnlocked=true
start.captureWave = 0
exports.start = start
lib.addToResearch(start, {
	parent: 'groundZero',
	objectives:
		Seq.with(new Objectives.SectorComplete(SectorPresets.groundZero))
})

const first = new SectorPreset('first', lnt, 1)
first.description = "勇者为胜"
first.difficulty = 3
first.localizedName = "试炼I·狭路相逢"
first.alwaysUnlocked=true
first.captureWave = 20
exports.first = first
lib.addToResearch(first, {
	parent: 'start',
	objectives:
		Seq.with(new Objectives.SectorComplete(start))
})

const second = new SectorPreset('second', lnt, 2)
second.description = "黎明前往往最为黑暗"
second.difficulty = 4
second.localizedName = "试炼II·大军压境"
second.alwaysUnlocked=true
second.captureWave = 20
exports.first = first
lib.addToResearch(second, {
	parent: 'first',
	objectives:
		Seq.with(new Objectives.SectorComplete(first))
})