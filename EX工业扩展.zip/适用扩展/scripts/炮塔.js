function newTurret(name, type) {
	exports[name] = (() => {
		let myTurret = extend(type, name, {});
		return myTurret;
	})();
}
newTurret("蚁巢", PowerTurret)