
const lib = require("base/lib");
const ASKD = new Planet("奥斯柯达", Planets.sun, 1, 3.3);
ASKD.meshLoader = prov(() => new MultiMesh(
	new HexMesh(ASKD, 8)
));
ASKD.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(ASKD, 2, 0.15, 0.14, 5, Color.valueOf("ffc4ffde"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(ASKD, 3, 0.6, 0.15, 5, Color.valueOf("ff349988"), 2, 0.42, 1.2, 0.45)
));
ASKD.generator = new SerpuloPlanetGenerator();
ASKD.visible = ASKD.accessible = ASKD.alwaysUnlocked = ASKD.clearSectorOnLose = true;//可见 潮汐锁定 在行星菜单内显示 总是解锁 重置战败区块
ASKD.tidalLock = false;
ASKD.localizedName = "奥斯柯达";
ASKD.bloom = false;
ASKD.startSector = 1;
ASKD.orbitRadius = 45;
ASKD.orbitTime = 180 * 60;
ASKD.rotateTime = 60 * 60;
ASKD.atmosphereRadIn = 0.02;
ASKD.atmosphereRadOut = 0.1;
ASKD.atmosphereColor = ASKD.lightColor = Color.valueOf("FFE489FF");
ASKD.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);







const 寒冰之地 = new SectorPreset("寒冰之地", ASKD, 1);
寒冰之地.description = "十分寒冰的地方,无时无刻都在寒潮的笼罩之下,想办法开采这里的冰晶吧";
寒冰之地.difficulty = 2;
寒冰之地.alwaysUnlocked = false;
寒冰之地.addStartingItems = true;
寒冰之地.captureWave = 30;
寒冰之地.localizedName = "寒冰之地";
exports.寒冰之地 = 寒冰之地;
lib.addToResearch(寒冰之地, {
    parent: 'frozen forest',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.荒芜沙漠))
});

const 荒芜沙漠 = new SectorPreset("荒芜沙漠", ASKD, 32);
荒芜沙漠.description = "一个荒芜的沙漠,什么也没有,可以在这收集一些废料为制作熔融晶作准备";
荒芜沙漠.alwaysUnlocked = false;
荒芜沙漠.difficulty = 1;
荒芜沙漠.captureWave = 25;
荒芜沙漠.localizedName = "荒芜沙漠";
exports.荒芜沙漠 = 荒芜沙漠;
lib.addToResearch(荒芜沙漠, {
    parent: '寒冰谷地',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.ruinousShores))
});

const 陕长走廊 = new SectorPreset("陕长走廊", ASKD, 62);
陕长走廊.description = "这里没有退路,占领这块区域！";
陕长走廊.alwaysUnlocked = true;
陕长走廊.difficulty = 5;
陕长走廊.captureWave = 50;
陕长走廊.localizedName = "陕长走廊";
exports.陕长走廊 = 陕长走廊;
lib.addToResearch(陕长走廊, {
    parent: '荒芜沙漠',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.寒冰之地))
});

const 大浅滩 = new SectorPreset("大浅滩", ASKD, 84);
大浅滩.description = "四周全是海洋,没有任何矿物,想办法生存下去";
大浅滩.alwaysUnlocked = false;
大浅滩.difficulty = 6;
大浅滩.captureWave = 60;
大浅滩.localizedName = "大浅滩";
exports.大浅滩 = 大浅滩;
lib.addToResearch(大浅滩, {
    parent: '陕长走廊',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.陕长走廊))
});

const 千峦山岭 = new SectorPreset("千峦山岭", ASKD, 189);
千峦山岭.description = "这是一片资源丰富的地区,尽你所能收集一些星陨铁,但万不可掉以轻心";
千峦山岭.alwaysUnlocked = false;
千峦山岭.difficulty = 10;
千峦山岭.captureWave = 100;
千峦山岭.localizedName = "千峦山岭";
exports.千峦山岭 = 千峦山岭;
lib.addToResearch(千峦山岭, {
    parent: '大浅滩',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.大浅滩))
});

const 炽热沙漠 = new SectorPreset("炽热沙漠", ASKD, 13);
炽热沙漠.description = "十分炎热的沙漠,时不时刮起炽热风暴";
炽热沙漠.alwaysUnlocked = false;
炽热沙漠.difficulty = 7;
炽热沙漠.captureWave = 80;
炽热沙漠.localizedName = "炽热沙漠";
exports.炽热沙漠 = 炽热沙漠;
lib.addToResearch(炽热沙漠, {
    parent: '大浅滩',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.大浅滩))
});

