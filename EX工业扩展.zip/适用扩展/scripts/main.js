MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000

require("lib");
require("物品");
require("炮塔");
require("机械压缩机");
require("液体压缩机");
require("多重压缩机");
require("解压站");
require("星球/奥斯柯达");
require("unit/导弹类");