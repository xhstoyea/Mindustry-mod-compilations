const library = require("base/library");
const myitems = require("物品");
const 解压站 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "解压站", [
  {
    input: {
      items: ["适用扩展-压缩铜/1"],     
    },
    output: {
      items: ["copper/10"],
    },
    craftTime: 10,
  }, 
  {
    input: {
      items: ["适用扩展-压缩铅/1"],     
    },
    output: {
      items: ["lead/10"],
    },
    craftTime: 10,
  }, 
  {
    input: {
      items: ["适用扩展-压缩钛/1"],     
    },
    output: {
      items: ["titanium/10"],
    },
    craftTime: 10,
  }, 
  {
    input: {
      items: ["适用扩展-压缩钍/1"],     
    },
    output: {
      items: ["thorium/10"],
    },
    craftTime: 10,
  }, 
  {
    input: {
      items: ["适用扩展-压缩煤/1"],     
    },
    output: {
      items: ["coal/10"],
    },
    craftTime: 10,
  }, 
  
 {
    input: {
      items: ["适用扩展-压缩废料/1"],     
    },
    output: {
      items: ["scrap/10"],
    },
    craftTime: 10,
  }, 
  
    {
    input: {
      items: ["适用扩展-压缩水/1"],     
    },
    output: {
      liquids: ["water/100"],
    },
    craftTime: 10,
  }, 
  {
    input: {
      items: ["适用扩展-压缩矿渣/1"],     
    },
    output: {
      liquids: ["slag/100"],
    },
    craftTime: 10,
  }, 
  {
    input: {
      items: ["适用扩展-压缩石油/1"],     
    },
    output: {
      liquids: ["oil/100"],
    },
    craftTime: 10,
  }, 
  {
    input: {
      items: ["适用扩展-压缩冷冻液/1"],     
    },
    output: {
      liquids: ["cryofluid/100"],
    },
    craftTime: 10,
  }, 
]);