const library = require("base/library");
const myitems = require("物品");
const 机械压缩机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "机械压缩机", [
  {
    input: {
      items: ["copper/10"],     
    },
    output: {
      items: ["适用扩展-压缩铜/1"],
    },
    craftTime: 60,
  }, 
  {
    input: {
      items: ["lead/10"],     
    },
    output: {
      items: ["适用扩展-压缩铅/1"],
    },
    craftTime: 60,
  }, 
  {
    input: {
      items: ["titanium/10"],     
    },
    output: {
      items: ["适用扩展-压缩钛/1"],
    },
    craftTime: 60,
  }, 
 {
    input: {
      items: ["thorium/10"],     
    },
    output: {
      items: ["适用扩展-压缩钍/1"],
    },
    craftTime: 60,
  }, 
 {
    input: {
      items: ["coal/10"],     
    },
    output: {
      items: ["适用扩展-压缩煤/1"],
    },
    craftTime: 60,
  }, 
  {
    input: {
      items: ["scrap/10"],     
    },
    output: {
      items: ["适用扩展-压缩废料/1"],
    },
    craftTime: 60,
  }, 
  
  
]);