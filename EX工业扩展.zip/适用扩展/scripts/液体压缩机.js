const library = require("base/library");
const myitems = require("物品");
const 液体压缩机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "液体压缩机", [
  {
    input: {
      liquids: ["water/100"],     
      power:1
    },
    output: {
      items: ["适用扩展-压缩水/1"],
    },
    craftTime: 6,
  }, 
  {
    input: {
      liquids: ["oil/100"],     
      power:1
    },
    output: {
      items: ["适用扩展-压缩石油/1"],
    },
    craftTime: 6,
  }, 
 {
    input: {
      liquids: ["slag/100"],    
       power:1
    },
    output: {
      items: ["适用扩展-压缩矿渣/1"],
    },
    craftTime: 6,
  }, 
  {
    input: {
      liquids: ["cryofluid/100"],  
         power:1
    },
    output: {
      items: ["适用扩展-压缩冷冻液/1"],
    },
    craftTime: 6,
  }, 
  
  

]);