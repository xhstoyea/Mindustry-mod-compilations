const library = require("base/library");
const myitems = require("物品");
const 多重压缩机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "多重压缩机", [
  {
    input: {
      items: ["copper/100"],     
      power:6
    },
    output: {
      items: ["适用扩展-压缩铜/10"],
    },
    craftTime: 6,
  }, 
  {
    input: {
      items: ["lead/100"],  
        power:6
    },
    output: {
      items: ["适用扩展-压缩铅/10"],
    },
    craftTime: 6,
  }, 
  {
    input: {
      items: ["titanium/100"],   
        power:6
    },
    output: {
      items: ["适用扩展-压缩钛/10"],
    },
    craftTime: 6,
  }, 
 {
    input: {
      items: ["thorium/100"],    
       power:6
    },
    output: {
      items: ["适用扩展-压缩钍/10"],
    },
    craftTime: 6,
  }, 
 {
    input: {
      items: ["coal/100"],     
      power:6
    },
    output: {
      items: ["适用扩展-压缩煤/10"],
    },
    craftTime: 6,
  }, 
  {
    input: {
      items: ["scrap/100"],     
      power:6
    },
    output: {
      items: ["适用扩展-压缩废料/10"],
    },
    craftTime: 6,
  }, 
  
  
]);