function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("压缩铜")
newItem("压缩铅")
newItem("压缩煤")
newItem("压缩钛")
newItem("压缩钍")
newItem("压缩废料")
newItem("压缩水")
newItem("压缩冷冻液")
newItem("压缩石油")
newItem("压缩矿渣")