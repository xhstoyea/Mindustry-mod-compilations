const PTlib = require("base/PTlib");
const TL = new Planet("泰拉", Planets.sun, 1, 3.3);
TL.meshLoader = prov(() => new MultiMesh(
	new HexMesh(TL, 8)
));
TL.generator = extend(SerpuloPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nA3JMQ6AIBAAwQXFRr9i4XuMBR5XkCAYkP9LphwcbmLO/lHMwRq0SY3vF0sGluRvTQ17XoZNStU9d0na20gDduAHAc0Org==")
	}
});
TL.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(TL, 2, 0.15, 0.14, 5, Color.valueOf("B22222"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(TL, 3, 0.6, 0.15, 5, Color.valueOf("CD5555"), 2, 0.42, 1.2, 0.45)
));
TL.generator = new SerpuloPlanetGenerator();
TL.visible = TL.accessible = TL.alwaysUnlocked = true;
TL.clearSectorOnLose = false;
TL.tidalLock = false;
TL.localizedName = "泰拉";
TL.prebuildBase = false;
TL.bloom = false;
TL.startSector = 1;
TL.orbitRadius = 85;
TL.orbitTime = 180 * 60;
TL.rotateTime = 90 * 60;
TL.atmosphereRadIn = 0.02;
TL.atmosphereRadOut = 0.3;
TL.atmosphereColor = TL.lightColor = Color.valueOf("B22222");
TL.iconColor = Color.valueOf("800000"),
TL.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);
/*
map n head2
SC map n head2
SC map name
*/
const map1pj = new SectorPreset("再临区", TL, 1);
map1pj.description = "我们又一次来到了这里,指挥官立刻做好准备,虫族部队即将到来。";
map1pj.difficulty = 2;
map1pj.alwaysUnlocked = false;
map1pj.addStartingItems = true;
map1pj.captureWave = 0;
map1pj.localizedName = "再临区";
exports.map1pj = map1pj;
SFlib.addToResearch(map1pj, {
	parent: "planetaryTerminal",
	objectives: Seq.with(
	new Objectives.SectorComplete(SectorPresets.planetaryTerminal))
});


