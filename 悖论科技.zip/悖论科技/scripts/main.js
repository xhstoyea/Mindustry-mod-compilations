MapResizeDialog.minSize = 50
MapResizeDialog.maxSize = 50000
require("planets/泰拉");//星球
