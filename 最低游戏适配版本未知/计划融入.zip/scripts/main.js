    if(typeof(require) !== "undefined"){ 
	require("blocks/晶磁轨道炮");
	require("blocks/电磁重炮");
	require("coreblocks/小型核心");
	require("coreBlocks/便携核心");
	
	
}