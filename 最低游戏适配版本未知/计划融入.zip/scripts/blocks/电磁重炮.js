

const 分裂闪电 = extend(BasicBulletType,{
draw(b){
       Draw.color(Color.valueOf("ffd280"));
       Fill.circle(b.x, b.y, 2.5);
       Draw.color(Color.valueOf("ffffff"));
       Fill.circle(b.x, b.y, 1.25);
        },
        update(b){
        if(b.timer.get(1,4)){
             for(var i = 0; i < 30; i++){
				Lightning.create(b.getTeam(),Color.valueOf("97FFFF"), 100, b.x , b.y , Mathf.random(360), Mathf.random(8, 20));
				}
        }
			}
});
			
分裂闪电.speed = 0.1,
分裂闪电.damage = 1,
分裂闪电.knockback = 5,
分裂闪电.bulletWidth = 5,
分裂闪电.bulletHeight = 5,
分裂闪电.drag = 0,
分裂闪电.collidesTiles = false,
分裂闪电.hitTiles = false;
分裂闪电.pierce = true,
分裂闪电.hitSize = 0,
分裂闪电.collides = false,
分裂闪电.collidesAir = false,
分裂闪电.lifetime = 60;

const 母弹 = extend(BasicBulletType,{
    draw(b){
        Draw.color(Color.valueOf("55BBFF"));
       Fill.circle(b.x, b.y, 10);
       Draw.color(Color.valueOf("55BBFF"));
       Fill.circle(b.x, b.y, 5);
    },
    update(b){
         if(b.timer.get(1,4)){
             for(var i = 0; i < 1; i++){
				Lightning.create(b.getTeam(),Color.valueOf("97FFFF"), 1, b.x , b.y , Mathf.random(360), Mathf.random(7, 7));
				}
				}
				},
    })
母弹.speed = 0.5,
母弹.pierce = true,
母弹.damage = 1200,
母弹.knockback =0,
母弹.hitSize = 10,
母弹.drawSize = 50,
母弹.bulletWidth = 20,
母弹.bulletHeight = 20,
母弹.bulletShrink = 0,
母弹.collidesTiles = true,
母弹.collidesTeam = false,
母弹.collidesAir = true,
母弹.collides = true,
母弹.fragBullets = 1,
母弹.fragBullet = 分裂闪电,
母弹.hitEffect = Fx.none,
母弹.trailEffect = Fx.none,
母弹.shootEffect = Fx.none,
母弹.smokeEffect = Fx.none,
母弹.lifetime = 1200,
母弹.despawnEffect = Fx.flakExplosion
const 电磁重炮 = extendContent(ChargeTurret,"电磁重炮",{})
电磁重炮.shootType = 母弹
电磁重炮.chargeEffect = newEffect(300,e=>{
    const d = new Floatc2({get(x,y){
        Draw.color(Color.valueOf("#97FFFF"), e.fin());
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fout() * 10 + 1);
    }})
    Angles.randLenVectors(e.id, 7, 50 * e.fout(),e.rotation, 180,d)
});
电磁重炮.chargeBeginEffect = Fx.none;
