const 便携核心=extendContent(CoreBlock,"便携核心",{
    canBreak(tile){
        return true;
    }
})