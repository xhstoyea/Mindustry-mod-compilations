const 红豆牛角包 = extendContent(Item,"红豆牛角包",{});
红豆牛角包.color = Color.valueOf("dda159")

const 放射性调料 = extendContent(Item,"放射性调料",{});
放射性调料.color = Color.valueOf("c48cb9")
放射性调料.radioactivity = 3.1

const 牛角包 = extendContent(Item,"牛角包",{});
牛角包.color = Color.valueOf("dda159")

const 肉 = extendContent(Item,"肉",{});
肉.color = Color.valueOf("FFE7BA")

const 血 = extendContent(Liquid,"血",{});
血.heatCapacity = 0.3;
血.temperature = 0.6;
血.color = Color.valueOf("FF6347")

const 面包发射器1 = extend(MissileBulletType,{
    hit(b){
        Damage.dynamicExplosion(b.x,b.y, 0.8/*燃烧等级*/, 50/*爆炸*/, 0/*功率*/, 19/*范围*/, Pal.darkFlame);
        Effects.effect(Fx.nuclearsmoke,b.x, b.y);
        Effects.effect(Fx.explosion,b.x, b.y);
        Effects.effect(Fx.nuclearShockwave, b.x, b.y);
        Effects.effect(Fx.nuclearcloud,b.x, b.y)
    }
})

面包发射器1.bulletSprite= "食品工业-M1"
面包发射器1.speed= 4,
面包发射器1.drag= 0.006,
面包发射器1.homingPower= 0.2,
面包发射器1.damage= 0,
面包发射器1.lifetime= 820,
面包发射器1.knockback=0.5,
面包发射器1.splashDamageRadius= 50,
面包发射器1.splashDamage= 700,
面包发射器1.bulletShrink= 0,
面包发射器1.bulletWidth= 12,
面包发射器1.bulletHeight= 15,
面包发射器1.shootEffect= Fx.shootBig2,
面包发射器1.smokeEffect= Fx.nuclearsmoke,
面包发射器1.hitEffect= Fx.nuclearcloud,
面包发射器1.reloadMultiplier= 0.8,
面包发射器1.ammoMultiplier= 1,
面包发射器1.homingPower = 9,
面包发射器1.backColor=Color.valueOf("008300")
面包发射器1.frontColor=Color.valueOf("83b783")
面包发射器1.trailColor=Color.valueOf("83b783")
        
        
const 红豆炮1 = extend(BasicBulletType,{})
红豆炮1.speed = 8,
红豆炮1.damage = 95,
红豆炮1.knockback = 1.2,
红豆炮1.bulletSprite = "食品工业-M2";
红豆炮1.bulletWidth = 20,
红豆炮1.bulletHeight = 26,
红豆炮1.reloadMultiplier = 0.8,
红豆炮1.ammoMultiplier = 1,
红豆炮1.lifetime = 40,
红豆炮1.pierce = true,
红豆炮1.backColor = Color.valueOf("e2aa66"),
红豆炮1.frontColor = Color.valueOf("ffdeb6"),
红豆炮1.shootEffect = Fx.shootBig2,
红豆炮1.smokeEffect = newEffect(23,e => {
    
    const c = new Floatc2({get(x, y){
        Draw.color(Color.valueOf("e2aa66"));
        Fill.circle(e.x + x, e.y + y, e.fout() * 4);
    }}) 
    
    Angles.randLenVectors(e.id, 10, 1 + 40 * e.fin(), e.rotation, 160,c);
    
       });
            
红豆炮1.hitEffect = newEffect(18,e => {
    
	const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("e2aa66"));
                Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 7 + 0.5);
                
            }})
            
            Draw.color(Color.valueOf("e2aa66"),Color.valueOf("ffdeb6"),e.fin());
            Lines.stroke(e.fout() * 3);
            Angles.randLenVectors(e.id, 6, 1+70 * e.fin(),e.rotation, 25,d);
            
       Lines.stroke(e.fout() * 3 + 0.1 );
       Lines.circle(e.x, e.y, e.fin() * 15);
	
        });

红豆炮1.despawnEffect = hitEffect = newEffect(18,e => {
    
	const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("e2aa66"));
                Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 7 + 0.5);
                
            }})
            
            Draw.color(Color.valueOf("e2aa66"),Color.valueOf("ffdeb6"),e.fin());
            Lines.stroke(e.fout() * 4);
            Angles.randLenVectors(e.id, 6, 1+70 * e.fin(),e.rotation, 360,d);
            
       Lines.stroke(e.fout() * 3 + 0.1 );
       Lines.circle(e.x, e.y, e.fin() * 15);
	
        });
        
const 红豆炮2 = extend(BasicBulletType,{})
红豆炮2.speed = 8,
红豆炮2.damage = 70,
红豆炮2.knockback = 0.6,
红豆炮2.bulletSprite = "食品工业-M2";
红豆炮2.bulletWidth = 20,
红豆炮2.bulletHeight = 26,
红豆炮2.reloadMultiplier = 1.2,
红豆炮2.ammoMultiplier = 2,
红豆炮2.lifetime = 40,
红豆炮2.pierce = true,
红豆炮2.backColor = Color.valueOf("e2aa66"),
红豆炮2.frontColor = Color.valueOf("ffdeb6"),
红豆炮2.shootEffect = Fx.shootBig2,
红豆炮2.smokeEffect = newEffect(23,e => {
    
    const c = new Floatc2({get(x, y){
        Draw.color(Color.valueOf("e2aa66"));
        Fill.circle(e.x + x, e.y + y, e.fout() * 4);
    }}) 
    
    Angles.randLenVectors(e.id, 10, 1 + 40 * e.fin(), e.rotation, 160,c);
    
       });
            
红豆炮2.hitEffect = newEffect(18,e => {
    
	const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("e2aa66"));
                Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 7 + 0.5);
                
            }})
            
            Draw.color(Color.valueOf("e2aa66"),Color.valueOf("ffdeb6"),e.fin());
            Lines.stroke(e.fout() * 3);
            Angles.randLenVectors(e.id, 6, 1+70 * e.fin(),e.rotation, 25,d);
            
       Lines.stroke(e.fout() * 3 + 0.1 );
       Lines.circle(e.x, e.y, e.fin() * 15);
	
        });

红豆炮2.despawnEffect = hitEffect = newEffect(18,e => {
    
	const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("e2aa66"));
                Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 7 + 0.5);
                
            }})
            
            Draw.color(Color.valueOf("e2aa66"),Color.valueOf("ffdeb6"),e.fin());
            Lines.stroke(e.fout() * 4);
            Angles.randLenVectors(e.id, 6, 1+70 * e.fin(),e.rotation, 360,d);
            
       Lines.stroke(e.fout() * 3 + 0.1 );
       Lines.circle(e.x, e.y, e.fin() * 15);
	
        });
        
const 红豆炮 = extendContent(BurstTurret,"红豆炮",{})
红豆炮.ammo(红豆牛角包,红豆炮1,牛角包,红豆炮2)

const 面包发射器 = extendContent(BurstTurret,"面包发射器",{})
面包发射器.ammo(放射性调料,面包发射器1)

const 调料工厂 = extendContent(GenericSmelter,"调料工厂",{      
  
    draw(tile){
        Draw.rect(Core.atlas.find(this.name + "-底座"),tile.drawx(),tile.drawy());
        Draw.color(Color.valueOf("484539"));
        Draw.alpha(tile.entity.liquids.total() / this.liquidCapacity);
        Draw.rect(Core.atlas.find(this.name + "-liquid"), tile.drawx(), tile.drawy());
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-rotator"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 2) 
        Draw.rect(this.region,tile.drawx(),tile.drawy())
    },
    generateIcons(){
        return [
            Core.atlas.find(this.name + "-底座"),
            Core.atlas.find(this.name),
        ];
    }
});

const 岩浆钻探器 = extendContent(GenericSmelter,"岩浆钻探器",{      
  
    draw(tile){
        Draw.color(Color.valueOf("484539"));
        Draw.alpha(tile.entity.liquids.total() / this.liquidCapacity);
        Draw.rect(Core.atlas.find(this.name + "-liquid"), tile.drawx(), tile.drawy());
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-rotator"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 4) 
        Draw.rect(this.region,tile.drawx(),tile.drawy())
    },
    generateIcons(){
        return [
            Core.atlas.find(this.name),
        ];
    }
});