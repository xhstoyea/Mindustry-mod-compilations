const RemovableCore=extendContent(CoreBlock,"核心-2",{
    canBreak(tile){
        return true
    }
})