const RemovableCore=extendContent(CoreBlock,"核心",{
    canBreak(tile){
        return true
    }
})