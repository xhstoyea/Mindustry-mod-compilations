
const laser.tmpColor = Color();
const laser.colors = [Color.valueOf("67005500"), Color.valueOf("00b300"), Color.valueOf("00ff00")];
const laser.tscales = [1, 0.7, 0.5, 0.2];
const laser.strokes = [1, 1, 0.3];
const laser.lenscales = [1, 1.12, 1.15, 1.17];
const laser.length = 240;
const greenlaser = extend(BasicBulletType, {
    update(b) {
       if (b.timer.get(1, 9)) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), laser.length, true);
        }
        Effects.shake(1, 1, b.x, b.y);
    },
    hit(b, hitx, hity) {
        Effects.effect(this.hitEffect, laser.colors[2], hitx, hity);
        if (Mathf.chance(0.4)) {
            Fire.create(Vars.world.tileWorld(hitx + Mathf.range(5), hity + Mathf.range(5)));
        }
    },
    draw(b) {
        const baseLen = (laser.length) * b.fout();

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for (var s = 0; s < laser.colors.length; s++) {
            Draw.color(laser.tmpColor.set(laser.colors[s]).mul(1 + Mathf.absin(Time.time(), 1, 0.1)));
            for (var i = 0; i < laser.tscales.length; i++) {
                Lines.stroke((1 + Mathf.absin(Time.time(), 0.8, 1.5)) * b.fout() * laser.strokes[s] * laser.tscales[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * laser lenscales[i]);
            }
        }
        Draw.reset();
    }
})
greenlaser.damage = 1.5;
greenlaser.hitSize = 0.7;
greenlaser.drawSize = 420;
greenlaser.lifetime = 8;
greenlaser.pierce = true;
greenlaser.despawnEffect = Fx.none;

greenlaser.hitEffect = newEffect(1, e => {
    Draw.color(Color.valueOf("eeffee"), Color.valueOf("a3d4a5"), e.fin());

    Lines.stroke(e.fout() * 1);
    const d = new Floatc2({
        get(x, y) {
            Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1.5);
        }
    })
    Angles.randLenVectors(e.id, 8, 1 + 80 * e.fin(), e.rotation, 200, d);

    Lines.stroke(e.fout() * 3 + 0.5);
    Lines.circle(e.x, e.y, e.fin() * 32);

    Fill.circle(e.x, e.y, e.fout() * 6);
    Fill.circle(e.x, e.y, e.fout() * 4);

});

const greenarcsix = extendContent(LaserTurret, "greenarcsix", {

})

greenarcsix.inaccuracy = 0
greenarcsix.shootCone = 40;
greenarcsix.recoil = 0;
greenarcsix.size = 8;
greenarcsix.shootShake = 0;
greenarcsix.range = 260;
greenarcsix.reload = 1;
greenarcsix.firingMoveFract = 0.06;
greenarcsix.shootDuration = 180;
greenarcsix.powerUse = 3;
greenarcsix.shootSound = Sounds.laserbig;
greenarcsix.activeSound = Sounds.beam;
greenarcsix.activeSoundVolume = 2;
greenarcsix.shootType = greenlaser;

greenarcsix.shootEffect = Fx.shootBigSmoke2;