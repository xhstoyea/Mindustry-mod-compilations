if(typeof(require) !== "undefined"){ // Work on 103 too
	require("items/calcium");
	require("items/phosphorus");
	require("items/rna");
	require("items/dna");
	require("items/protein");
	require("items/ferrthorwolfium");
	require("blocks/greenarcsix");;
}
 