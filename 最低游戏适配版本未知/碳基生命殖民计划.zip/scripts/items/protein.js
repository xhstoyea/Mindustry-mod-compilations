
const protein = extendContent(Item,"protein",{});
protein.color = Color.valueOf("f8f8bb");
protein.cost = 0.2;
protein.flammability = 0.75;