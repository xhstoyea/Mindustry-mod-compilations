
const dnae = extendContent(Item,"dna",{});
dnae.color = Color.valueOf("000000");
dnae.type = ItemType.material;
dnae.cost = 0.4;