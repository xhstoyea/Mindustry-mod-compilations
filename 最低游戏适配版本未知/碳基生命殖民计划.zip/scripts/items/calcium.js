
const calcium = extendContent(Item,"calcium-ca",{});
calcium.color = Color.valueOf("e8e8e8");
calcium.type = ItemType.material;
calcium.hardness = 2;
calcium.cost = 1.1;