
const ferrthorwolfium = extendContent(Item,"ferrthorwolfium",{});
ferrthorwolfium.color = Color.valueOf("000000");
ferrthorwolfium.type = ItemType.material;
ferrthorwolfium.cost = 1.4;
ferrthorwolfium.radioactivity = 1.1;