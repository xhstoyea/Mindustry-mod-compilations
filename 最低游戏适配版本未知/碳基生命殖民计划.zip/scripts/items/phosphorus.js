
const phosphorus = extendContent(Item,"phosphorus-p",{});
phosphorus.color = Color.valueOf("dcdcc8");
phosphorus.type = ItemType.resource;
phosphorus.hardness = 2;
phosphorus.cost = 0.7;