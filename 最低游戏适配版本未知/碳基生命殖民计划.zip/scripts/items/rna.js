
const rnacid = extendContent(Item,"rna",{});
rnacid.color = Color.valueOf("000000");
rnacid.type = ItemType.resource;