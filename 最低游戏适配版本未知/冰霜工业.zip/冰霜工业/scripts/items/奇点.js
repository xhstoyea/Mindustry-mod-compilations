const 奇点 = extendContent(Item,"奇点",{})
奇点.color = Color.valueOf("e9a098")
奇点.type = ItemType.material;
奇点.cost = 3