
const 奇点破片 = extend(BombBulletType,{
    draw(b){
Draw.color(Color.valueOf("#FFF98C"))
Fill.circle(b.x, b.y, 1);
//圆的厚度4
 Lines.stroke(5); 
// 渲染一个圆，半径100
Lines.circle(b.x, b.y,50);
},
update(b){       
    if(b.timer.get(1,4)){
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x, b.y, b.rot() +360*b.fin(), 10/*长度*/);
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x-10, b.y-10, b.rot() +360*b.fin(), 10/*长度*/);
        
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x, b.y, b.rot() -360*b.fin(), 10/*长度*/);
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x-10, b.y-10, b.rot() -360*b.fin(), 10/*长度*/);
            
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x, b.y, b.rot() +360*b.fout(), 10/*长度*/);
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x-10, b.y-10, b.rot() +360*b.fout(), 10/*长度*/);
            
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x, b.y, b.rot() -360*b.fout(), 10/*长度*/);
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x-10, b.y-10, b.rot() -360*b.fin(), 10/*长度*/);
        }
        }
    
})

奇点破片.hitEffect = newEffect(55, e => {
    Draw.color(Color.valueOf("#FFF98C"),Color.valueOf("#fff98c"),e.fin());
    const c = new Floatc2({get(x, y){
        Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3.425, 45);
        Drawf.tri(e.x, e.y, 5, 5, 0)
        Fill.circle(e.x, e.y, e.fout() * 5);
        	Lines.stroke(e.fout() * 5);
		    Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 3 + 4);
   }}) 
    Angles.randLenVectors(e.id, 4, 1 + 40 * e.fin(), e.rotation, 360,c);
});
奇点破片.damage = 100

const 奇点墙 = extendContent(SurgeWall,"奇点墙",{
})
奇点墙.shootType = 奇点破片