/**
 * 作者:Minxyzgo
 * 前提提要，使用该js时，你需要一定的js基础。
 * 使用该js到你的模组时，标明作者是我便可。
*/

const 转化绿 = extendContent(Item,"转化绿",{});
const 转化红 = extendContent(Item,"转化红",{});
//物品变量的定义。不建议去改写名字。


//下是关于子弹的定义，使用接口时使用   名字.xxx
const 分散等离子 = extend(/*这是关于子弹类型的定义，可随便改*/BasicBulletType,{});
分散等离子.speed = 2.5
分散等离子.damage = 600,
分散等离子.knockback = 50,
分散等离子.bulletWidth = 30,
分散等离子.lifetime = 450
分散等离子.bulletHeight = 30,
分散等离子.shootEffect = Fx.shootBig2,
分散等离子.ammoMultiplier = 2,
分散等离子.backColor = Color.valueOf("#ffffff"),
分散等离子.frontColor = Color.valueOf("#fdfdfd")
const 聚集等离子 = extend(BasicBulletType,{});
聚集等离子.speed = 15,
聚集等离子.damage = 300,
聚集等离子.knockback = 20,
聚集等离子.lifetime = 240
聚集等离子.splashDamageRadius = 32,
聚集等离子.splashDamage = 50,
聚集等离子.bulletWidth = 30,
聚集等离子.bulletHeight = 24,
聚集等离子.shootEffect = Fx.shootBig2,
聚集等离子.ammoMultiplier = 2,
聚集等离子.backColor = Color.valueOf("#ffffff"),
聚集等离子.frontColor = Color.valueOf("#fdfdfd")
//更改子弹时，需看最后一行的说明。


//这里使用电炮来进行演示，可改成其他炮。若不需要用电力来启动将有关entity.power.status这一串代码删除即可
const 等离子炮 = extendContent(/*炮类型定义*/PowerTurret,"等离子炮",{
	draw(tile){
        Draw.rect(Core.atlas.find("block-" + this.size), tile.drawx(), tile.drawy());
        Draw.color();
    },

    buildConfiguration(tile, table){
        table.addImageButton(Icon.upOpen, Styles.clearTransi, run(() => {
            //按下发出信号
            tile.configure(0)
        })).size(50).disabled(boolf(b => tile.entity != null && !tile.entity.cons.valid()))
    },

    //重写配置事件
    configured(tile, value){
        //确保有发射的物品
         const entity = tile.ent();
        if(tile.entity.cons.valid()){
			Sounds.explosionbig.at(tile);
            //这是关于转换的定义，不需要改变。
            if(tile.entity.items.has(转化红)){
	            entity.items.add(转化绿, 1);
	            entity.items.remove(转化红, 1)
			}else if(tile.entity.items.has(转化绿)){
				entity.items.add(转化红, 1);
				entity.items.remove(转化绿, 1)
			}else{
			    entity.items.add(转化绿, 1)
			}
            }
            //出发消耗所需物品
            tile.entity.cons.trigger()
        },
    shoot(tile,ammo){
        //关于shoot函数的改写，这里使用了FF的改写，有需要可以自己改写。
        const entity = tile.ent();
        entity.shots++;
		if(tile.entity.items.has(转化红)&&entity.power.status > 0.5){
	        var i = Mathf.signs[entity.shots % 2];
	        this.tr.trns(entity.rotation - 90, this.shotWidth * i, this.size * this.tilesize / 2);
	        Bullet.create(红子(Math.floor(Math.random() * (7 - 0)) + 0), tile.entity, tile.getTeam(), tile.drawx(), tile.drawy(),entity.rotation + Mathf.range(this.inaccuracy));
	        this.effects(tile);
	        this.useAmmo(tile);
        };
        if(tile.entity.items.has(转化绿)&&entity.power.status > 0.5){
        	var i = Mathf.signs[entity.shots % 2];
	        this.tr.trns(entity.rotation - 90, this.shotWidth * i, this.size * this.tilesize / 2);
	        Bullet.create(绿子(Math.floor(Math.random() * (7 - 0)) + 0), tile.entity, tile.getTeam(), tile.drawx(), tile.drawy(),entity.rotation + Mathf.range(this.inaccuracy));
	        this.effects(tile);
	        this.useAmmo(tile);
        }
    },
    drawLayer(tile){
        const entity = tile.ent();

        this.tr2.trns(entity.rotation, -entity.recoil);
        if(tile.entity.items.has(转化红)){
		Draw.rect(Core.atlas.find(this.name + "-红"), tile.drawx() + this.tr2.x, tile.drawy() + this.tr2.y, entity.rotation - 90);
	}else{
		Draw.rect(Core.atlas.find(this.name + "-绿"), tile.drawx() + this.tr2.x, tile.drawy() + this.tr2.y, entity.rotation - 90);
	};
        const heatRegion = Core.atlas.find(this.name + "-heat");
        if(heatRegion != Core.atlas.find("error")){
        if(tile.heat <= 0.00001) return;
        Draw.color(this.heatColor, tile.heat);
        Draw.blend(Blending.additive);
        Draw.rect(heatRegion, tile.x() + this.tr2.x, tile.y() + this.tr2.y, tile.rotation - 90);
        Draw.blend();
        Draw.color();
    }
}
});

等离子炮.shootType = 聚集等离子;
//上面是电炮射击类型的定义，若修改为其他类型炮塔，使用以下代码:
//名字.ammo(消耗的物品, 使用的子弹名)
//使用原版物品名在名字前加Items.列如调用铜是Items.copper，使用mod物品需先定义。定义方法可看别mod
//下面的这些代码不可更改，否则会出现异常
等离子炮.update = true;
等离子炮.solid = true;
等离子炮.hasItems = true;
等离子炮.configurable = true
//上面的这些代码不可更改，否则会出现异常

function 绿子() {
    return 聚集等离子
}

function 红子() {
    return 分散等离子
}


//上面的两个表示引用子弹，若你更改了子弹的名字，将上面修改一致便可
//使用说明:该炮塔默认使用生产内的物品与电力做消耗来切换。若你不想消耗便可以不写生产。同时第一次射击需先切换一次才可射击

