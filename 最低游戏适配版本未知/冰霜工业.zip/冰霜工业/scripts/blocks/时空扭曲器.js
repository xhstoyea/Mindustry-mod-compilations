
const 破片子弹 = extend(BombBulletType,{
    draw(b){
Draw.color(Color.valueOf("#FFF98C"))
Fill.circle(b.x, b.y, 1);
//圆的厚度4
 Lines.stroke(3); 
// 渲染一个圆，半径100
Lines.circle(b.x, b.y,150);
},
update(b){       
    if(b.timer.get(1,4)){
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x, b.y, b.rot() +360*b.fin(), 21/*长度*/);
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x-10, b.y-10, b.rot() +360*b.fin(), 21/*长度*/);
        
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x, b.y, b.rot() -360*b.fin(), 21/*长度*/);
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x-10, b.y-10, b.rot() -360*b.fin(), 21/*长度*/);
            
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x, b.y, b.rot() +360*b.fout(), 21/*长度*/);
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x-10, b.y-10, b.rot() +360*b.fout(), 21/*长度*/);
            
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x, b.y, b.rot() -360*b.fout(), 21/*长度*/);
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 360, b.x-10, b.y-10, b.rot() -360*b.fin(), 21/*长度*/);
        }
        }
    
})
破片子弹.lifetime = 300,
破片子弹.speed = 0,
破片子弹.damage = 400,
破片子弹.knockback = 0.2,
破片子弹.splashDamageRadius = 40,
破片子弹.splashDamage = 5,
破片子弹.bulletWidth = 7,
破片子弹.bulletHeight = 25,
破片子弹.drag = 0,
破片子弹.collidesTiles = true,
破片子弹.pierce = false,
破片子弹.collides = true,
破片子弹.collidesAir = true,
破片子弹.shootEffect = newEffect(12, e => {
    Draw.color(Color.valueOf("#ffffff"));
    Fill.circle(e.x, e.y, e.fout() * 5);
    Draw.color(Color.valueOf("#FFF98C"),Color.valueOf("#ffffff"),e.fin());
    Fill.circle(e.x, e.y, e.fout() * 2.725);
});
破片子弹.hitEffect = newEffect(55, e => {
    Draw.color(Color.valueOf("#FFF98C"),Color.valueOf("#ffffff"),e.fin());
    const c = new Floatc2({get(x, y){
        Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3.425, 45);
    }}) 
    Angles.randLenVectors(e.id, 4, 1 + 40 * e.fin(), e.rotation, 360,c);
});

const 子弹 = extend(FlakBulletType,{
    draw(b){
Draw.color(Color.valueOf("#FFF98C"))
Fill.circle(b.x, b.y,4);
// 厚度4
 Lines.stroke(3); 
// 渲染一个圆，半径10
Lines.circle(b.x, b.y,10);
Lines.circle(b.x, b.y,14);
},
update(b){       
    if(b.timer.get(1,4)){
            Lightning.create(b.getTeam(),Color.valueOf("#ffffff"), 45, b.x, b.y, b.rot() +360*b.fin(), 8)
            Lightning.create(b.getTeam(),Color.valueOf("#FFF98C"), 45, b.x, b.y, b.rot() -360*b.fin(), 8)
        }
        }
    
})
子弹.speed = 6,
子弹.damage = 9999999999,
子弹.knockback = 0.2,
子弹.splashDamageRadius = 40,
子弹.splashDamage = 125,
子弹.bulletWidth = 7,
子弹.bulletHeight = 25,
子弹.drag = 0,
子弹.lifetime = 1000
子弹.fragBullets = 1,
子弹.fragBullet = 破片子弹,
子弹.collidesTiles = true,
子弹.pierce = false,
子弹.collides = true,
子弹.collidesAir = true,
子弹.shootEffect = newEffect(12, e => {
    Draw.color(Color.valueOf("#ffffff"));
    Fill.circle(e.x, e.y, e.fout() * 5);
    Draw.color(Color.valueOf("#FFF98C"),Color.valueOf("#ffffff"),e.fin());
    Fill.circle(e.x, e.y, e.fout() * 2.725);
});
子弹.hitEffect = newEffect(55, e => {
    Draw.color(Color.valueOf("#FFF98C"),Color.valueOf("#ffffff"),e.fin());
    const c = new Floatc2({get(x, y){
        Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3.425, 45);
    }}) 
    Angles.randLenVectors(e.id, 4, 1 + 40 * e.fin(), e.rotation, 360,c);
});

const 奇点 = extendContent(Item,"奇点",{})
奇点.color = Color.valueOf("e9a098")
奇点.type = ItemType.material;
奇点.cost = 3

const 时空扭曲器 = extendContent(ItemTurret,"时空扭曲器",{})
时空扭曲器.ammo(奇点,子弹);
时空扭曲器.reload=300;

const 奇点压缩机 = extendContent(GenericSmelter, "奇点压缩机", {})
奇点压缩机.outputItem = ItemStack(奇点, 1);