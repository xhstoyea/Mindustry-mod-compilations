const 小2 = newEffect(25,e => {
	Draw.color(Color.valueOf("#ffffff32"),Color.valueOf("#FFFFFF55"),e.fin());
	const d = new Floatc2({get(x, y){
		Lines.stroke(e.fout() * 2.725);
		Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 10 + 5);
	}})
	Angles.randLenVectors(e.id, 1, 1 + 0 * e.fin(),e.rotation, 0,d);
});

const 子弹 = extend(MissileBulletType,{
update(b){
    const target = Units.closestTarget(b.getTeam(), b.x,b.y,200)
		if (target != null) {
			b.velocity().setAngle(Mathf.slerpDelta(b.velocity().angle(), b.angleTo(target), 0.6));
		}
		if(b.timer.get(1,0.00001)){
		    Lightning.create(b.getTeam(),Color.valueOf("FFFFFF"), 45, b.x, b.y, b.rot() - 20, 6);         
            Lightning.create(b.getTeam(),Color.valueOf("FFFFFF"), 45, b.x, b.y, b.rot() + 50, 3);
			Effects.effect(小2,Color.valueOf("C2FF8300"), b.x, b.y, b.rot());
		}
	},
	draw(b){
Draw.color(Color.valueOf("ffffff55"))
Fill.circle(b.x, b.y, 7);
	}
})
子弹.speed = 7,
子弹.damage = 40,
子弹.knockback = 2,
子弹.splashDamageRadius = 30,
子弹.splashDamage = 10,
子弹.bulletWidth = 7,
子弹.bulletHeight = 25,
子弹.drag = 0,
子弹.collidesTiles = true,
子弹.pierce = false,
子弹.collides = true,
子弹.collidesAir = true,
子弹.shootEffect = newEffect(12, e => {
    Draw.color(Color.valueOf("#ffffff"));
    Fill.circle(e.x, e.y, e.fout() * 5);
    Draw.color(Color.valueOf("#FFFFFF"),Color.valueOf("#FFFFFF"),e.fin());
    Fill.circle(e.x, e.y, e.fout() * 2.725);
});
子弹.hitEffect = newEffect(55, e => {
    Draw.color(Color.valueOf("#FFFFFF"),Color.valueOf("#ffffff"),e.fin());
    const c = new Floatc2({get(x, y){
        Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3.425, 45);
        Drawf.tri(e.x, e.y, 5, 5, 0)
        Fill.circle(e.x, e.y, e.fout() * 5);
        	Lines.stroke(e.fout() * 5);
		    Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 3 + 4);
   }}) 
    Angles.randLenVectors(e.id, 4, 1 + 40 * e.fin(), e.rotation, 360,c);
});
子弹.shootEffect = newEffect(45, e => {
    Draw.color(Color.valueOf("#FFFFFF"),Color.valueOf("#ffffff"),e.fin());
    const c = new Floatc2({get(x, y){
        Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3.425, 45);
        Drawf.tri(e.x, e.y, 5, 5, 0)
        Fill.circle(e.x, e.y, e.fout() * 5);
        	Lines.stroke(e.fout() * 5);
		    Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 3 + 4);
   }}) 
    Angles.randLenVectors(e.id, 4, 1 + 40 * e.fin(), e.rotation, 360,c);
});

子弹.smokeEffect = newEffect(55, e => {
    
             const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("fdfdfd22"),Color.valueOf("ffffff22"),e.fin());
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3, 6);
            }})
            
            Angles.randLenVectors(e.id, 15, 10 + e.fin() * 20,d);
            
             
});

const 电圈投射器 = extendContent(PowerTurret,"电圈投射器",{})
电圈投射器.shootType = 子弹;
电圈投射器.reload = 100;