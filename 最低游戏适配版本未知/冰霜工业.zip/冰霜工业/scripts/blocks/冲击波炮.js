//代码大部分借鉴食品工厂，如不可借用请联系我
const 冲击colors = [Color.valueOf("fdfdfd55"), Color.valueOf("fjfjfj"), Color.white];
const 冲击tscales = [1, 0.7, 0.5, 0.2];
const 冲击lenscales = [1, 1.1, 1.13, 1.14];
const 冲击length = 130;

const 冲击波 = extend(BasicBulletType,{
    range(){
        return 冲击length;
    },
    // init(b){
    // },
    update(b){
        if (b.time()<0.001) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), 冲击length);
        }
    },
    draw(b){
        const f = Mathf.curve(b.fin(), 0, 0.2);
        const baseLen = 冲击length * f;

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for(var s = 0; s < 3; s++){
            Draw.color(冲击colors[s]);
            for(var i = 0; i < 冲击tscales.length; i++){
                Lines.stroke(7 * 2 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.3) * 冲击tscales[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * 冲击lenscales[i]);
            }
        }
        Draw.reset();
    }
})
冲击波.hitEffect= newEffect(20,e => {
	Draw.color(Color.valueOf("fdfdfd"),Color.valueOf("ffffff"),e.fin());
	
	Lines.stroke(e.fout() * 2);
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 8 + 1.5);
	}})
             Angles.randLenVectors(e.id, 8, 1+80 * e.fin(),e.rotation, 5,d);
             
             Lines.stroke(e.fout() * 3 + 0.5 );
             Lines.circle(e.x, e.y, e.fin() * 5);
            
            Fill.circle(e.x, e.y, e.fout() * 5);
            Fill.circle(e.x, e.y, e.fout() * 1);
            
}); 
冲击波.shootEffect = newEffect(5, e => {
            Draw.color(Color.valueOf("fdfdfd22"),Color.valueOf("ffffff22"),e.fin());
        
            Fill.circle(e.x, e.y, e.fout() * 5);
            Draw.color();
            Fill.circle(e.x, e.y, e.fout() * 1);
    
});
冲击波.smokeEffect = newEffect(55, e => {
    
             const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("fdfdfd22"),Color.valueOf("ffffff22"),e.fin());
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3, 6);
            }})
            
            Angles.randLenVectors(e.id, 15, 10 + e.fin() * 20,d);
            
             
});

冲击波.damage = 50;
冲击波.speed = 0.001;
冲击波.despawnEffect = Fx.none;
冲击波.hitSize = 10;
冲击波.lifetime = 10;
冲击波.pierce = true

const 冲击波炮 = extendContent(ChargeTurret,"冲击波炮",{
})
冲击波炮.shootType = 冲击波
冲击波炮.chargeBeginEffect = newEffect(20, e => {
    //蓄力效果                   颜色
    Draw.color(Color.valueOf("fdfdfd44"));
    Fill.circle(e.x, e.y, e.fin()*5);
    Draw.color();
    Fill.circle(e.x, e.y, e.fin()*1);
})
冲击波炮.chargeEffect = newEffect(40, e => {
    Draw.color(Color.valueOf("fdfdfd77"),Color.valueOf("fdfdfd77"),e.fin());
    
    //用于用于控制所有效果粗细
    Lines.stroke(e.fin() * 2.3);

});
