//代码大部分借鉴食品工厂，如不可借用请联系我
const 小colors = [Color.valueOf("d4cce055"), Color.valueOf("fjfjfj"), Color.white];
const 小tscales = [1, 0.7, 0.5, 0.2];
const 小lenscales = [1, 0.6, 1.13, 1.14];
const 小length = 90;

const 孢子 = extend(BasicBulletType,{
    range(){
        return 小length;
    },
    // init(b){
    // },
    update(b){
        if (b.time()<0.001) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), 小length);
        }
    },
    draw(b){
        const f = Mathf.curve(b.fin(), 0, 0.2);
        const baseLen = 小length * f;

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for(var s = 0; s < 3; s++){
            Draw.color(小colors[s]);
            for(var i = 0; i < 小tscales.length; i++){
            }
        }
        Draw.reset();
    }
})
孢子.shootEffect = newEffect(5, e => {
            Draw.color(Color.valueOf("d4cce022"),Color.valueOf("ffffff22"),e.fin());
        
            Fill.circle(e.x, e.y, e.fout() * 5);
            Draw.color();
            Fill.circle(e.x, e.y, e.fout() * 1);
    
});
孢子.smokeEffect = newEffect(55, e => {
    
             const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("d4cce022"),Color.valueOf("ffffff22"),e.fin());
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3, 6);
            }})
            
            Angles.randLenVectors(e.id, 15, 10 + e.fin() * 20,d);
            
             
});

孢子.damage = 10;
孢子.speed = 0.001;
孢子.despawnEffect = Fx.none;
孢子.hitSize = 4;
孢子.lifetime = 10;
孢子.pierce = true

const 繁殖炮 = extendContent(ChargeTurret,"繁殖炮",{
})
繁殖炮.shootType = 孢子
繁殖炮.chargeBeginEffect = newEffect(20, e => {
    //蓄力效果                   颜色
    Draw.color(Color.valueOf("d4cce044"));
    Fill.circle(e.x, e.y, e.fin()*5);
    Draw.color();
    Fill.circle(e.x, e.y, e.fin()*1);
})
繁殖炮.chargeEffect = newEffect(40, e => {
    Draw.color(Color.valueOf("d4cce077"),Color.valueOf("d4cce077"),e.fin());
    
    //用于用于控制所有效果粗细
    Lines.stroke(e.fin() * 2.3);

});
