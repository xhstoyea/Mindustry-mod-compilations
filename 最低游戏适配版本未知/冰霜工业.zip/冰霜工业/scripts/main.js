if(typeof(require) !== "undefined"){
	require("blocks/等离子炮");
    require("blocks/冲击波炮");
    require("blocks/繁殖炮");
    require("blocks/电圈投射器");
    require("blocks/时空扭曲器");
    //require("items/奇点");
    //require("blocks/奇点墙")
    //require("blocks/大型奇点墙")
}
