if(typeof(require) !== "undefined"){ 
	require("blocks/球形闪电");
	require("blocks/地星轨道激光");
	require("blocks/地星护卫舰激光");
	require("blocks/地星战列舰激光");
	require("blocks/地星主舰激光");
	require("blocks/地星矿机");
	require("blocks/空间提炼硅机床");
	require("blocks/特罗爆裂炮");
	require("blocks/防空集阵");
	require("blocks/神级矿机");
	require("blocks/地星超合金工厂");
	require("blocks/地星工业矿机");
	require("blocks/矿石液化器");
	require("blocks/矿液分离机");
	require("blocks/核裂变电站");
	require("blocks/地星主舰炮");
}