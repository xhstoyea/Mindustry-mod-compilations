

const 分裂闪电 = extend(BasicBulletType,{
draw(b){
       Draw.color(Color.valueOf("ffd280"));
       Fill.circle(b.x, b.y, 7);
       Draw.color(Color.valueOf("ffffff"));
       Fill.circle(b.x, b.y, 3.725);
        },
        update(b){
         if(b.timer.get(1,4)){
             for(var i = 0; i < 3; i++){
				Lightning.create(b.getTeam(),Color.valueOf("9400D3"), 750, b.x , b.y , Mathf.random(360), Mathf.random(20, 20));
				}
				}
				},
			});
			
分裂闪电.speed = 0.01,
分裂闪电.damage = 750,
分裂闪电.knockback = 0.2,
分裂闪电.splashDamageRadius = 40,
分裂闪电.splashDamage = 750,
分裂闪电.bulletWidth = 18,
分裂闪电.bulletHeight = 18,
分裂闪电.drag = 0,
分裂闪电.collidesTiles = false,
分裂闪电.hitTiles = false;
分裂闪电.pierce = true,
分裂闪电.hitSize = 0,
分裂闪电.collides = false,
分裂闪电.collidesAir = false,
分裂闪电.lifetime = 300;

const 球形闪电 = extend(BasicBulletType,{
    draw(b){
        Draw.color(Color.valueOf("#9400D3"));
       Fill.circle(b.x, b.y, 10);
       Draw.color(Color.valueOf("#C24BF4"));
       Fill.circle(b.x, b.y, 7);
       Draw.color(Color.valueOf("#76FFF5"));
       Fill.circle(b.x, b.y, 4);
       const plasmas = 2;
        var plasmaRegions = new Array();
        for(var i = 0; i < 2; i++){
            plasmaRegions[i] = "宇宙文明-球形闪电-plasma-"+i;
        }
        for(var i = 0; i < 2; i++){
            var r = 29 + Mathf.absin(Time.time(), 2 + i * 1, 5 - i * 0.5);
            Draw.color(Color.valueOf("#FF0000"),Color.valueOf("#9932CC"), i / 6);
            Draw.alpha(0.37128 + Mathf.absin(Time.time(), 2 + i * 2, 0.3 + i * 0.05) * 1);
            Draw.blend(Blending.additive);
            Draw.rect(Core.atlas.find(plasmaRegions[i]), b.x, b.y,Time.time() * (12 + i * 2) * 5);
            Draw.blend();
        }
    }
    })
球形闪电.speed = 1,
球形闪电.pierce = true,
球形闪电.damage = 750,
球形闪电.knockback =0,
球形闪电.splashDamageRadius =1,
球形闪电.splashDamage = 1000,
球形闪电.homingPower = 1,
球形闪电.homingRange = 190,
球形闪电.hitSize = 10,
球形闪电.drawSize = 50,
球形闪电.bulletWidth = 30,
球形闪电.bulletHeight = 30,
球形闪电.bulletShrink = 0,
球形闪电.collidesTiles = true,
球形闪电.collidesTeam = false,
球形闪电.collidesAir = true,
球形闪电.collides = true,
球形闪电.fragBullets = 3,
球形闪电.fragBullet = 分裂闪电,
球形闪电.hitEffect = Fx.none,
球形闪电.trailEffect = Fx.none,
球形闪电.shootEffect = newEffect(300,e =>{
    const d = new Floatc2({get(x,y){
        Draw.color(Color.valueOf("#9400D3"), Color.valueOf("#F0F8FF"), e.fin());
        Lines.stroke(e.fslope() * 4);
        Lines.circle(e.x, e.y, e.fin() * 50); 
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 10 + 2);
    }})
            Angles.randLenVectors(e.id, 10, 50 * e.fslope(),e.rotation, 360,d)
});
球形闪电.smokeEffect = newEffect(60,e => {
	const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("#abdbff"),Color.valueOf("#f0f8ff"),e.fin());
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
        });
球形闪电.lifetime = 15000,
球形闪电.despawnEffect = Fx.flakExplosion
const 地星轨道毁灭炮 = extendContent(ChargeTurret,"地星轨道毁灭炮",{})
地星轨道毁灭炮.shootType = 球形闪电
地星轨道毁灭炮.chargeEffect = newEffect(600,e=>{
    const d = new Floatc2({get(x,y){
        Draw.color(Color.valueOf("#F0F8FF"), Color.valueOf("#9400D3"), e.fin());
        Lines.stroke(e.fout() * 6);
        Lines.circle(e.x, e.y, e.fout() * 70);
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fout() * 15 + 1);
    }})
            Angles.randLenVectors(e.id, 10, 50 * e.fout(),e.rotation, 360,d)
});
地星轨道毁灭炮.chargeBeginEffect = Fx.lancerLaserChargeBegin
