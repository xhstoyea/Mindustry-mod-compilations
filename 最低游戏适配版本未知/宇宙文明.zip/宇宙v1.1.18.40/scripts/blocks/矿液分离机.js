const 矿液分离机 = extendContent(Separator,"矿液分离机",{         
    draw(tile){
        var frameRegions = new Array();
        for(var i = 0; i < 5; i++){
            frameRegions[i] = "宇宙文明-矿液分离机-"+i;}
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color(Color.valueOf("AEEEEE"));
        Draw.alpha(tile.entity.liquids.total() / this.liquidCapacity);
        Draw.rect(Core.atlas.find(this.name + "-liquid"), tile.drawx(), tile.drawy());
        Draw.color()
        Draw.rect(Core.atlas.find(frameRegions[Math.floor(Mathf.absin(tile.ent().totalProgress, 4, 5))]), tile.drawx(), tile.drawy());
        Draw.rect(Core.atlas.find(this.name + "-spinner"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 3)
    },
    generateIcons(){
        return [
            Core.atlas.find(this.name),
        ];
    }
});
