const juneng = extendContent(Drill,"神级矿机",{
    draw(tile){
        if(tile.ent().power.graph.getPowerBalance()*60>210){
        Draw.rect(Core.atlas.find(this.name + "-top"),tile.drawx(),tile.drawy());
        Draw.rect(Core.atlas.find(this.name + "-rim"),tile.drawx(),tile.drawy());
        Draw.rect(Core.atlas.find(this.name + "-4"),tile.drawx(),tile.drawy(),0 + Time.time() * 3.5)
        Draw.rect(Core.atlas.find(this.name + "-3"),tile.drawx(),tile.drawy(),0 - Time.time() * 3)
        Draw.rect(Core.atlas.find(this.name + "-1"),tile.drawx(),tile.drawy(),0 - Time.time() * 2)
        Draw.rect(Core.atlas.find(this.name + "-2"),tile.drawx(),tile.drawy(),0 + Time.time() * 2.50)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        }
        Draw.rect(Core.atlas.find(this.name + "-top"),tile.drawx(),tile.drawy());
        Draw.rect(Core.atlas.find(this.name + "-rim"),tile.drawx(),tile.drawy());
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
     },
    generateIcons(){
        return [
            Core.atlas.find(this.name + "-top"),
            Core.atlas.find(this.name),
        ];
    }
});
     juneng.craftEffect = Fx.none;
     juneng.drillEffect = Fx.none;