const 爆裂1 = extend(MissileBulletType,{})
爆裂1.speed = 3,
爆裂1.lifetime = 20,
爆裂1.bulletWidth = 10,
爆裂1.bulletHeight = 20,
爆裂1.damage = 50;

const 分裂2 = extend(BasicBulletType,{
    draw(b){
        Draw.color(Color.valueOf("#ffffff"));
       Fill.circle(b.x, b.y, 4);
       Draw.color(Color.valueOf("#ffffff"));
       Fill.circle(b.x, b.y, 4);
    },
    update(b){
         if(b.timer.get(1,4)){
             for(var i = 0; i < 3; i++){
				Bullet.create(爆裂1,b,b.x,b.y,Mathf.random(360),1);
				}
				}
				},
        })
分裂2.lifetime = 150,
分裂2.speed = 1,
分裂2.splashDamage = 300,
分裂2.splashDamageRadius = 32,
分裂2.bulletWidth = 8,
分裂2.bulletHeight = 8,
分裂2.bulletShrink = 0,
分裂2.homingPower = 1,
分裂2.homingRange = 16,
分裂2.prerce = false,
分裂2.shootEffect = Fx.none,
分裂2.collidesTiles = true,
分裂2.collidesTeam = false,
分裂2.collidesAir = false,
分裂2.collides = true,
分裂2.damage = 400;

const 爆裂2 = extend(MissileBulletType,{})
爆裂2.speed = 2,
爆裂2.lifetime = 60,
爆裂2.bulletWidth = 20,
爆裂2.bulletHeight = 30,
爆裂2.damage = 100;

const 分裂1 = extend(BasicBulletType,{
    draw(b){
        Draw.color(Color.valueOf("#ffffff"));
       Fill.circle(b.x, b.y, 7.5);
       Draw.color(Color.valueOf("#ffffff"));
       Fill.circle(b.x, b.y, 3.8);
    },
       update(b){
         if(b.timer.get(1,4)){
             for(var i = 0; i < 3; i++){
				Bullet.create(爆裂2,b,b.x,b.y,Mathf.random(360),1);
				}
				}
				},
        })
分裂1.lifetime = 300,
分裂1.speed = 1,
分裂1.splashDamage = 250,
分裂1.splashDamageRadius = 32,
分裂1.bulletWidth = 15,
分裂1.bulletHeight = 15,
分裂1.bulletShrink = 0,
分裂1.homingPower = 1,
分裂1.homingRange = 16,
分裂1.prerce = false,
分裂1.shootEffect = Fx.none,
分裂1.collidesTiles = true,
分裂1.collidesTeam = false,
分裂1.collidesAir = false,
分裂1.collides = true,
分裂1.damage = 300,
分裂1.fragBullets = 4,
分裂1.fragBullet = 分裂2;

const 分裂母弹 = extend(BasicBulletType,{
    draw(b){
       Draw.color(Color.valueOf("#97FFFF"));
       Fill.circle(b.x, b.y, 10);
       Draw.color(Color.valueOf("#000000"));
       Fill.circle(b.x, b.y, 5);
      const plasmas = 1;
        var plasmaRegions = new Array();
        for(var i = 0; i < 1; i++){
            plasmaRegions[i] = "宇宙文明-爆裂炮-plasma-"+i;
        }
        for(var i = 0; i < 1; i++){
            var r = 29 + Mathf.absin(Time.time(), 2 + i * 1, 5 - i * 0.5);
            Draw.color(Color.valueOf("#ffffff"),Color.valueOf("#ffffff"), i / 1);
            
            Draw.blend(Blending.additive);
            Draw.rect(Core.atlas.find(plasmaRegions[i]), b.x, b.y,Time.time() * (6 + i * 1) * 1);
            Draw.blend();
        }
}
})
分裂母弹.lifetime = 600,
分裂母弹.speed = 0.5,
分裂母弹.splashDamage = 200,
分裂母弹.splashDamageRadius = 64,
分裂母弹.bulletWidth = 20,
分裂母弹.bulletHeight = 20,
分裂母弹.bulletShrink = 0,
分裂母弹.homingPower = 1,
分裂母弹.homingRange = 32,
分裂母弹.prerce = false,
分裂母弹.shootEffect = Fx.none,
分裂母弹.collidesTiles = true,
分裂母弹.collidesTeam = false,
分裂母弹.collidesAir = false,
分裂母弹.collides = true,
分裂母弹.damage = 200,
分裂母弹.fragBullets = 4,
分裂母弹.fragBullet = 分裂1;

const 特罗爆裂炮 = extendContent(ChargeTurret,"特罗爆裂炮",{})
特罗爆裂炮.shootType = 分裂母弹;