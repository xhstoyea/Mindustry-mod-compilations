const colors光 = [Color.valueOf("AAAAAA"), Color.valueOf("#AEEEEE"), Color.valueOf("#AEEEEE")];
const tscales光 = [1, 0.8, 0.5, 0.2];//色块宽度
const lenscales光 = [1, 1.03, 1.06, 1.09];
const length光 = 800;
const 激光 = extend(BasicBulletType,{
        range(){
        return length光;
    },
    update(b){
        if (b.time()<0.00001) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), length光);
        }
        print(b.time())
    },
    draw(b){
        const f = Mathf.curve(b.fin(), 0, 0.2);
        const baseLen = length光 * f;

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for(var s = 0; s < 3; s++){
            Draw.color(colors光[s]);
            for(var i = 0; i < tscales光.length; i++){
                Lines.stroke(2.25 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.1) * tscales光[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscales光[i]);
            }
        }
        Draw.reset();
    }
})
激光.damage = 50,
激光.lifetime = 10,
激光.speed = 1,
激光.bulletWidth = 1,
激光.bulletHeight = 1,
激光.bulletShrink = 0,
激光.hitSize = 5,
激光.drag = 0,
激光.prerce = true,
激光.hitEffect = Fx.none,
激光.despawnEffect = Fx.none,
激光.shootEffect = Fx.none;
激光.smokeEffect = Fx.none,
激光.trailEffect = Fx.none,
激光.knockback = 0,
激光.hitTiles = false,
激光.collidesTiles = false,
激光.collidesTeam = false,
激光.collidesAir = true,
激光.collides = true;
const 地星阵地防空集阵 = extendContent(ChargeTurret,"地星阵地防空集阵",{})
地星阵地防空集阵.shootType = 激光,
地星阵地防空集阵.chargeEffect = newEffect(30,e=>{
 const d = new Floatc2({get(x,y){
        Draw.color(Color.valueOf("#F0F8FF"), e.fin());
        Lines.stroke(e.fout() * 2);
        Lines.circle(e.x, e.y, e.fout() * 3);
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fout() * 6 + 1);
    }})
            Angles.randLenVectors(e.id, 8, 50 * e.fout(),e.rotation, 360,d)
});
地星阵地防空集阵.chargeBeginEffect = Fx.none;
