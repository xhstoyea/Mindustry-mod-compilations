const colors光 = [Color.valueOf("F0F8FF"), Color.valueOf("#0000FF"), Color.valueOf("#F0F8FF")];
const tscales光 = [3.5, 3.3, 3.1, 2.9];//色块宽度
const lenscales光 = [1, 1.03, 1.06, 1.09];
const length光 = 2400;
const 激光 = extend(BasicBulletType,{
        range(){
        return length光;
    },
    update(b){
        if (b.time()<0.00001) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), length光);
        }
        print(b.time())
    },
    draw(b){
        const f = Mathf.curve(b.fin(), 0, 0.2);
        const baseLen = length光 * f;

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for(var s = 0; s < 3; s++){
            Draw.color(colors光[s]);
            for(var i = 0; i < tscales光.length; i++){
                Lines.stroke(2.25 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.1) * tscales光[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscales光[i]);
            }
        }
        Draw.reset();
    }
})
激光.damage = 200,
激光.lifetime = 20,
激光.speed = 0.1,
激光.bulletWidth = 1,
激光.bulletHeight = 1,
激光.bulletShrink = 0,
激光.hitSize = 5,
激光.drag = 0,
激光.prerce = true,
激光.hitEffect = Fx.none,
激光.despawnEffect = Fx.none,
激光.shootEffect = newEffect(30,e =>{
const d = new Floatc2({get(x,y){
        Draw.color(Color.valueOf("#9400D3"), e.fin());
        Lines.stroke(e.fslope() * 1);
        Lines.circle(e.x, e.y, e.fin() * 5); 
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 5 + 1);
    }})
            Angles.randLenVectors(e.id, 15, 20 * e.fslope(),e.rotation, 360,d)
});
激光.smokeEffect = Fx.none,
激光.trailEffect = Fx.none,
激光.knockback = 0,
激光.hitTiles = false,
激光.collidesTiles = false,
激光.collidesTeam = false,
激光.collidesAir = true,
激光.collides = true;
const 地星主舰激光炮 = extendContent(ChargeTurret,"地星主舰激光炮",{})
地星主舰激光炮.shootType = 激光,
地星主舰激光炮.chargeEffect = newEffect(30,e=>{
 const d = new Floatc2({get(x,y){
        Draw.color(Color.valueOf("#F0F8FF"), e.fin());
        Lines.stroke(e.fout() * 2);
        Lines.circle(e.x, e.y, e.fout() * 15);
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fout() * 15 + 1);
    }})
            Angles.randLenVectors(e.id, 10, 50 * e.fout(),e.rotation, 360,d)
});
地星主舰激光炮.chargeBeginEffect = Fx.lancerLaserChargeBegin;
