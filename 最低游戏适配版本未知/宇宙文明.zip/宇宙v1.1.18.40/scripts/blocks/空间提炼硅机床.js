const juneng = extendContent(GenericCrafter,"空间提炼硅机床",{
    draw(tile){
        Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-top"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 3)//0后+正传－逆转
        Draw.rect(this.region,tile.drawx(),tile.drawy())
     },
    generateIcons(){
        return [
            Core.atlas.find(this.name + "-bottom"),
            Core.atlas.find(this.name),
        ];
    }
});
     juneng.craftEffect = Fx.smeltsmoke;
     juneng.flameColor = Color.valueOf("64fdff");