const 地星超合金工厂 = extendContent(GenericSmelter,"地星超合金工厂",{         
    draw(tile){ 
        var frameRegions = new Array();
        for(var i = 0; i < 2; i++){
            frameRegions[i] = "宇宙文明-地星超合金工厂-"+i;
        }
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color()
        Draw.rect(Core.atlas.find(frameRegions[Math.floor(Mathf.absin(tile.ent().totalProgress, 7, 2))]), tile.drawx(), tile.drawy());
        Draw.rect(Core.atlas.find(this.name + "-top"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 3)
    },
    generateIcons(){
        return [
            Core.atlas.find(this.name),
        ];
    }
});