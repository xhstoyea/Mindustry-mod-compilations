const 矿石液化器 = extendContent(GenericSmelter,"矿石液化器",{         
    draw(tile){ 
        var frameRegions = new Array();
        for(var i = 0; i < 7; i++){
            frameRegions[i] = "宇宙文明-矿石液化器-"+i;
        }
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color(Color.valueOf("AEEEEE"));
        Draw.alpha(tile.entity.liquids.total() / this.liquidCapacity);
        Draw.rect(Core.atlas.find(this.name + "-liquid"), tile.drawx(), tile.drawy());
        Draw.color()
        Draw.rect(Core.atlas.find(frameRegions[Math.floor(Mathf.absin(tile.ent().totalProgress, 5, 7))]), tile.drawx(), tile.drawy());
        Draw.rect(Core.atlas.find(this.name + "-z0"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 3)
        Draw.rect(Core.atlas.find(this.name + "-z1"),tile.drawx(),tile.drawy(),0 - tile.ent().totalProgress * 2.5)
    },
    generateIcons(){
        return [
            Core.atlas.find(this.name),
        ];
    }
});
