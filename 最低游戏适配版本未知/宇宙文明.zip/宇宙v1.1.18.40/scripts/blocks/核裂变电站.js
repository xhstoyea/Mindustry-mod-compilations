const 核裂变电站 = extendContent(GenericSmelter,"核裂变电站",{         
    draw(tile){ 
        var frameRegions = new Array();
        for(var i = 0; i < 3; i++){
            frameRegions[i] = "宇宙文明-核裂变电站-"+i;
        }
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color()
        Draw.rect(Core.atlas.find(frameRegions[Math.floor(Mathf.absin(tile.ent().totalProgress, 7, 3))]), tile.drawx(), tile.drawy());
        Draw.rect(Core.atlas.find(this.name + "-z5"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 1)
        Draw.rect(Core.atlas.find(this.name + "-z4"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 1.5)
        Draw.rect(Core.atlas.find(this.name + "-z3"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 2)
        Draw.rect(Core.atlas.find(this.name + "-z2"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 2.5)
        Draw.rect(Core.atlas.find(this.name + "-z1"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 3)
    },
    generateIcons(){
        return [
            Core.atlas.find(this.name),
        ];
    }
});