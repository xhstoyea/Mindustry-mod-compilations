const 初级芯片组装机 = extendContent(GenericCrafter,"初级芯片组装机",{      
    draw(tile){
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-rotator"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 1)
    },
    generateIcons(){
        return [
            Core.atlas.find(this.name),
            Core.atlas.find(this.name + "-rotator"),
        ];
    }
});

const 紫水晶分解 = extendContent(GenericCrafter,"紫水晶分解",{      
    draw(tile){
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-top"),tile.drawx(),tile.drawy());
    },
   	generateIcons(){
      	 return [
       		Core.atlas.find(this.name),
           	Core.atlas.find(this.name + "-top")
       	];
       }
});