

const colorA = Color.valueOf("f779ff");
const colorB = Color.valueOf("f779ff");
const colorC = Color.valueOf("f779ff");
const colorD = Color.valueOf("f779ff");
const colorE = Color.valueOf("f779ff");
const wid = 1.25
const len = 2.125
const SUPTRange = 280;

const SUPTLaser = extend(BasicBulletType,{
		draw(b){
			
			const ang = b.rot();
			
			const trx1 = b.x + Angles.trnsx(ang - 80, len);
	        const try1 = b.y + Angles.trnsy(ang - 80, len);
			const trx2 = b.x + Angles.trnsx(ang - 80, len * 2);
	        const try2 = b.y + Angles.trnsy(ang - 80, len * 2);
	
			const trxa1 = b.x + Angles.trnsx(ang + 80, len);
			const trya1 = b.y + Angles.trnsy(ang + 80, len);
			const trxa2 = b.x + Angles.trnsx(ang + 80, len * 2);
			const trya2 = b.y + Angles.trnsy(ang + 80, len * 2);
			
			const trnx = Angles.trnsx(ang, len * 1.1);
			const trny = Angles.trnsy(ang, len * 1.1);
			
			const target = Units.closestTarget(b.getTeam(), b.x,b.y,SUPTRange);
			if(target != null){
				if(Angles.angleDist(b.angleTo(target), b.rot()) < 20){
					Draw.color(bulletCo(Math.floor(Math.random() * (5 - 0)) + 0),bulletCo(Math.floor(Math.random() * (5 - 0)) + 0),b.fout());
					Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11))), Core.atlas.find("科技革命-SUP-end"),trx2, try2,target.x, target.y, wid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),trx1 - trnx, try1 - trny,target.x, target.y, wid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),b.x - trnx * 2, b.y - trny * 2,target.x, target.y, wid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),trxa1 - trnx, trya1 - trny,target.x, target.y, wid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),trxa2, trya2,target.x, target.y, wid * b.fout() * b.fout());
					Draw.color();
				}else{
					var trueWid = wid
					trueWid = Mathf.lerpDelta(trueWid, 0, 0.020);
					Draw.color(bulletCo(Math.floor(Math.random() * (5 - 0)) + 0),bulletCo(Math.floor(Math.random() * (5 - 0)) + 0),b.fout());
					Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),trx2, try2,b.x,b.y, trueWid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),trx1 - trnx, try1 - trny,b.x,b.y, trueWid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),b.x - trnx * 2, b.y - trny * 2,b.x,b.y, trueWid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),trxa1 - trnx, trya1 - trny,b.x,b.y, trueWid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),trxa2, trya2,b.x,b.y, trueWid * b.fout() * b.fout());
					Draw.color();
				}
	        }else{
				var trueWid = wid
				trueWid = Mathf.lerpDelta(trueWid, 0, 0.020);
				Draw.color(bulletCo(Math.floor(Math.random() * (5 - 0)) + 0),bulletCo(Math.floor(Math.random() * (5 - 0)) + 0),b.fout());
				Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),trx2, try2,b.x,b.y, trueWid * b.fout() * b.fout());
				Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),trx1 - trnx, try1 - trny,b.x,b.y, trueWid * b.fout() * b.fout());
				Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),b.x - trnx * 2, b.y - trny * 2,b.x,b.y, trueWid * b.fout() * b.fout());
				Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),trxa1 - trnx, trya1 - trny,b.x,b.y, trueWid * b.fout() * b.fout());
				Drawf.laser(Core.atlas.find("科技革命-SUP-" + Math.floor(Math.random() * (11 - 0))), Core.atlas.find("科技革命-SUP-end"),trxa2, trya2,b.x,b.y, trueWid * b.fout() * b.fout());
				Draw.color();
			}
		},
			update(b){
				const target = Units.closestTarget(b.getTeam(), b.x,b.y,SUPTRange);
				if(target != null){
					if(Angles.angleDist(b.angleTo(target), b.rot()) < 25){
						if(b.timer.get(2, 8)){
							Damage.damage(target.x, target.y, 5, 30);
							Lightning.create(b.getTeam(),colorA, 50, target.x,target.y,Mathf.random(360), Mathf.random(5,10)); 
						}
					}
				}
			}
		})

SUPTLaser.speed = 0.00001;
SUPTLaser.damage = 6;
SUPTLaser.lifetime = 40;
SUPTLaser.drawSize = SUPTRange * 2.5;
SUPTLaser.splashDamageRadius = 40;
SUPTLaser.splashDamage = 50;
SUPTLaser.statusDuration = 240;
SUPTLaser.shootEffect = Fx.none;
SUPTLaser.smokeEffect = Fx.none;
SUPTLaser.despawnEffect = Fx.none;
SUPTLaser.hitEffect = Fx.none;
		
		
const SUPT = extendContent(LaserTurret,"SUPT",{
	turnToTarget(tile,targetRot){
        const entity = tile.ent();
        entity.rotation = Angles.moveToward(entity.rotation, entity.angleTo(entity.target), entity.power.status * 4.5);
    },
	drawLayer(tile){
        this.super$drawLayer(tile)
    },
    updateShooting(tile){
        const entity = tile.ent();
        if(entity.bulletLife > 0 && entity.bullet != null){
            return;
        }
        if(entity.reload >= this.reload && (entity.cons.valid() || tile.isEnemyCheat())){
            const type = this.peekAmmo(tile);
            this.shoot(tile, type);
            entity.reload = 0;
        }else{
            const liquid = entity.liquids.current();
            var used = Math.min(Math.min(entity.liquids.get(liquid), 0.2 * Time.delta()), Math.max(0, ((this.reload - entity.reload) / this.coolantMultiplier) / liquid.heatCapacity)) * this.baseReloadSpeed(tile);
            entity.reload += used;
            entity.liquids.remove(liquid, used);
            if(Mathf.chance(0.06 * used)){
                Effects.effect(this.coolEffect, tile.drawx() + Mathf.range(this.size * Vars.tilesize / 2), tile.drawy() + Mathf.range(this.size * Vars.tilesize / 2));
            }
        }
    }
})
SUPT.shootCone = 30;
SUPT.recoil = 0;
SUPT.expanded = true;
SUPT.range = SUPTRange;
SUPT.heatColor = Color.valueOf("#BDE6FF")
SUPT.reload = 25;
SUPT.shootDuration = 120;
SUPT.activeSoundVolume = 3;
SUPT.shootType = SUPTLaser;

function bulletCo(chance){
	switch (chance){
		case 0 : return colorA;
		case 1 : return colorB;
		case 2 : return colorC;
		case 3 : return colorD;
		case 4 : return colorE;
    }
}

