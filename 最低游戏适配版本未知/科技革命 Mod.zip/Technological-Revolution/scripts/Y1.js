//
//Vars.content.units();
//const unit1 = Vars.content.getByName(ContentType.unit,"test-战舰")
/*function uFind(name){
    const unitArray = Vars.content.units();
    return unitArray.get(name);
}
*/
//const unit0 = Vars.mods.locateMod("战舰");
//const unit1 = uFind(11);

const Y1 = extendContent(Block, "Y1", {
    update(tile){
        //Vars.content.createModContent();
        const unitType = ContentType.unit;
        var unit2 = Vars.content.getByName(unitType, "科技革命-yufengz");
        if (Mathf.chance(Time.delta() * 0.1)){
            UnitCreate(tile, unit2, 15)
        tile.ent().health -= 10
        }
    }
})
Y1.update = true;


function UnitCreate(itile,iUnit,range){
    const units = Vars.content.units();
    var unitI = units.get(iUnit.id).create(itile.getTeam());
    //unitI.spawner = itile;
    unitI.set(itile.drawx() + Mathf.range(range), itile.drawy() + Mathf.range(range) + range);
    Effects.effect(Fx.unitSpawn, unitI.x, unitI.y, 0, unitI);
    unitI.add();
    unitI.velocity().y = 0;
}
/*
const ce = extendContent(MessageBlock, "ce", {
    update(tile){
        Vars.content.createModContent();
        const entity = tile.ent();
        const unitArray = Vars.content.units();
        entity.message = unitArray;
  
    }
})
ce.update = true;
ce.requirements(Category.effect, ItemStack.with(Items.copper, 30))
*/