
const meiyingpShoot = newEffect(23, e => {
	Draw.color(Color.valueOf("a9d8ff"));

	//Drawf.tri(e.x, e.y, 9 * e.fout(), 45 + e.fin() * 6, e.rotation + 90 * i);
	Fill.poly(e.x, e.y, 3, e.fout() * 24, e.rotation);
	Fill.circle(e.x, e.y, e.fout() * 11);

	Draw.color(Color.valueOf("ffffff"));
	Fill.circle(e.x, e.y, e.fout() * 9);
});

const meiyingpTrail = newEffect(50, e => {
	Draw.color(Color.valueOf("a9d8ff"), Color.valueOf("4787ff"), e.fin());
	
	Fill.poly(e.x, e.y, 3, e.fout() * 4, e.rotation + e.fin() * 180);
});

const meiyingpHit = newEffect(12, e => {
	Draw.color(Color.valueOf("a9d8ff"), Color.valueOf("4787ff"), e.fin());
	Lines.stroke(e.fout() * 3);
	Lines.circle(e.x, e.y, e.fin() * 90);
	
	const hl = new Floatc2({get: function(x, y){
		const ang = Mathf.angle(x, y);
		//Lines.lineAngle(e.x + x, e.y + y, ang, e.fout() * 8 + 1.5);
		Fill.poly(e.x + x, e.y + y, 3, e.fout() * 4, (e.fin() * 120) + (e.rotation + ang));
	}});
	
	Angles.randLenVectors(e.id, 7, e.finpow() * 45.0, e.rotation, 360.0, hl);
	Draw.reset();
});



meiyingpBullet.speed = 9;
meiyingpBullet.damage = 62;
meiyingpBullet.lifetime = 22;
meiyingpBullet.bulletWidth = 12;
meiyingpBullet.bulletHeight = 19;
meiyingpBullet.bulletShrink = 0;
meiyingpBullet.hitSize = 9;
meiyingpBullet.trailEffect = meiyingpTrail;
meiyingpBullet.hitEffect = meiyingpHit;
meiyingpBullet.collides = true;
meiyingpBullet.collidesTiles = true;
meiyingpBullet.collidesAir = true;
meiyingpBullet.frontColor = Color.valueOf("ffffff");
meiyingpBullet.backColor = Color.valueOf("a9d8ff");
const meiyingp = extendContent(Weapon,"NGP",{

})
//子弹类型
const meiyingpBullet = extend(ArtilleryBulletType, {
	update: function(b){

		if(b.timer.get(0, 2 + b.fslope() * 1.5)){
			Effects.effect(this.trailEffect, this.backColor, b.x, b.y, b.fslope() * 4);
		}
	}
});
meiyingp.name = meiyingp;
//武器长
meiyingp.length = 9;
meiyingp.shootEffect = Fx.shootHeal;
meiyingp.smokeEffect = Fx.hitLaser;
//一次多少子弹
meiyingp.shots = 1;
//弹速随机改变区间
meiyingp.velocityRnd = 0;
//射击延迟
meiyingp.shotDelay = 4;
//是否左右手轮流射击
meiyingp.roundrobin = true
//一次打出多个子弹时，子弹间角
meiyingp.spacing = 0.25;
//后坐力
meiyingp.recoil = 1;
//武器宽
meiyingp.width = 3.45;
//重新装弹
meiyingp.reload = 25;
//精准度
meiyingp.inaccuracy = 1;
meiyingp.alternate = false;
//范围
meiyingp.range = 350;
meiyingp.bulletSprite = "科技革命-ho";
meiyingp.bulletWidth = 4
meiyingp.bulletHeight = 20
meiyingp.ejectEffect = Fx.none

const meiying = extendContent(GroundUnit,"NMJ1",{
	load(){
		this.weapon.load();
		this.region = Core.atlas.find(this.name);
		this.weapon.region = Core.atlas.find("科技革命-NGP");
	}
})
meiying.weapon = meiyingp;
meiying.weaponOffsetX = 4.5;
meiying.health = 300,
meiying.mass = 6,
meiying.speed = 0.3,
meiying.boostSpeed = 0.6,
meiying.drag = 0.05,
meiying.buildPower = 4,
meiying.itemCapacity = 70,
meiying.engineOffset = 6.325,
meiying.engineSize = 2.5,
meiying.engineColor = Color.valueOf("fe565d");
meiying.flying = false,
meiying.canHeal = true,
meiying.drillPower = 5,
meiying.mineSpeed = 4,
meiying.weaponOffsetY = 7.5