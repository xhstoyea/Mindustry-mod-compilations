
const goldSurge = Color.valueOf("3399ff");

const shoothuohua = newEffect(32, e => {
	const vec = new Vec2();
	
    Draw.color(Color.valueOf("3399ff"));
    for(var b = 0; b < 3; b++){
		var rnd1 = Mathf.randomSeed(e.id + (b * 15), 50, 180) / 15; // 3.33 - 12
		var rnd2 = Mathf.randomSeed(e.id + (b * 16), 36, 240) / 15; // 2.4 - 16
		var rnd3 = Mathf.randomSeed(e.id + (b * 17), 0, 45); // 0 - 45
		var rnd4 = Mathf.randomSeed(e.id + (b * 18), 56, 410) / 15; // 3.73 - 27.33
		var rnd5 = Mathf.randomSeed(e.id + (b * 19), 230, 340) / 15; // 15.33 - 22.33
		var rndRot = Mathf.randomSeedRange(e.id + (b * 14), 35); // -35 - 35
		
		var sin = Mathf.sin(Time.time() + rnd3, rnd1, rnd2);
		var sinB = Mathf.sin((Time.time() + rnd3) - 45, rnd1, rnd2);
		
		//vec.trns(e.rotation + rndRot + (sin / 3), e.finpow() * rnd4 * 3.3, sin * e.fslope());
		//vec.add(vec2.trns(e.rotation + rndRot + (sin / 3 * e.fout()), e.fout() * rnd4 * 3.3, sin * e.fslope()));
		vec.trns(e.rotation + rndRot, e.fin() * rnd4 * 3.3, sin * e.fslope());
		Lines.stroke(1);
		Lines.lineAngle(e.x + vec.x, e.y + vec.y, e.rotation + rndRot + (sinB * 2), rnd5 / 4 * e.fout());
	};
});

const HHShoot = newEffect(23, e => {
	Draw.color(Color.valueOf("a9d8ff"));

	//Drawf.tri(e.x, e.y, 9 * e.fout(), 45 + e.fin() * 6, e.rotation + 90 * i);
	Fill.poly(e.x, e.y, 3, e.fout() * 7, e.rotation);
	Fill.circle(e.x, e.y, e.fout() * 7);

	Draw.color(Color.valueOf("ffffff"));
	Fill.circle(e.x, e.y, e.fout() * 7);
});

const shipTrail = newEffect(44, e => {
	Draw.color(goldSurge);
	Fill.circle(e.x, e.y, 1.6 * e.fout());
});

const bladeLaserShoot = newEffect(11, e => {
	Draw.color(goldSurge);
	
	for(var g = 1; g < 3; g++){
		Drawf.tri(e.x, e.y, 5 * e.fout(), 29, e.rotation + 90 + (g * 180));
	};
	
	Drawf.tri(e.x, e.y, 7 * e.fout(), 48, e.rotation);
});

const bladeLaser = extend(BasicBulletType, {
	range: function(){
		return 190.0;
	},
	
	update: function(b){
		if(b.timer.get(1, 17)){
			Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), 170.0, false);
		};
	},
	
	/*init: function(b){
		Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), 190.0);
	},*/
	
	draw: function(b){
		const colors = [goldSurge.cpy().mul(1.0, 1.0, 1.0, 0.4), goldSurge, Color.white];
		const tscales = [1.0, 0.7, 0.5, 0.2];
		const lenscales = [1, 1.1, 1.13, 1.14];
		const length = 170.0;
		const f = Mathf.curve(b.fin(), 0.0, 0.2);
		const baseLen = length * f;
		//const lengthB = new Vec2();

		//Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
		for(var s = 0; s < 3; s++){
			Draw.color(colors[s]);
			for(var i = 0; i < 4; i++){
				//lengthB.trns(b.rot(), baseLen * lenscales[i]);
				Lines.stroke(7 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.3) * tscales[i]);
				//Lines.line(b.getOwner().x, b.getOwner().y, b.x + lengthB.x, b.y + lengthB.y);
				Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscales[i]);
			}
		};
		Draw.reset();
	}
});
bladeLaser.speed = 0.001;
bladeLaser.damage = 90;
bladeLaser.hitEffect = shoothuohua;
bladeLaser.despawnEffect = Fx.none;
bladeLaser.hitSize = 4;
bladeLaser.lifetime = 11;
bladeLaser.keepVelocity = false;
bladeLaser.pierce = true;
bladeLaser.shootEffect = shoothuohua;
bladeLaser.smokeEffect = Fx.none;

const bladeWeapon = extendContent(Weapon, "eeeee", {});

bladeWeapon.reload = 30;
bladeWeapon.alternate = true;
bladeWeapon.width = 0;
bladeWeapon.length = 2;
bladeWeapon.bullet = bladeLaser;
bladeWeapon.shootSound = Sounds.corexplode;
bladeWeapon.minPlayerDist = 45;

const blad = extendContent(Mech, "NJJ", {
	//const minV = 3.6;
	//const maxV = 6;
	
	/*load: function(){
		weapon.load();
		this.region = Core.atlas.find(this.name);
		this.shield = Core.atlas.find(this.name + "-shield");
	},*/
	
	/*scld: function(player){
		const minV = 3.6;
		const maxV = 6;
		return Mathf.clamp((player.velocity().len() - minV) / (maxV - minV));
	},*/
	updateAlt: function(player){
		const minVb = 4.6;
		const maxVb = 9.2;
		const sclb = Mathf.clamp((player.velocity().len() - minVb) / (maxVb - minVb));
		const pred = new Vec2();
		
		if(Mathf.chance(sclb)){
			pred.trns(player.velocity().angle(), 16);
			Effects.effect(shipTrail, Pal.surge, player.x + Mathf.range(4.7) + pred.x, player.y + Mathf.range(4.7) + pred.y, player.rotation);
			if(Mathf.chance(0.25)){
				Lightning.create(player.getTeam(), goldSurge, 18 * Vars.state.rules.playerDamageMultiplier, player.x, player.y, player.rotation + Mathf.range(21.0), Mathf.floorPositive((player.velocity().len() * 2) + Mathf.random(2, 4)));
			}
		}
	},
	
	draw: function(player){
		const minV = 3.6;
		const maxV = 7;
		//const scld = Mathf.clamp((player.velocity().len() - minV) / (maxV - minV));
		
		//const scl = this.scld;
		//if(scl < 0.01) return;
		const scl = Mathf.clamp((player.velocity().len() - minV) / (maxV - minV));
		
		Draw.color(goldSurge);
		Draw.alpha(scl / 2);
		Draw.blend(Blending.additive);
		Draw.rect(Core.atlas.find(this.name + "-shield"), player.x + Mathf.range(scl / 2.0), player.y + Mathf.range(scl / 2.0), player.rotation - 90);
		Draw.blend();
	}
});

blad.flying = true;
blad.health = 250;
blad.drag = 0.027;
blad.speed = 0.3;
blad.drillPower = 4;
blad.cellTrnsY = -5
blad.weapon = bladeWeapon;
blad.engineColor = goldSurge;
blad.mineSpeed = 3.2;
blad.buildPower = 1.4;
blad.localizedName = "TH-纳米机甲";
blad.description = "首个应用了纳米技术的机甲，有着优秀的武器，和速度，还搭载了能量助推器（TH意为神圣者，象征了艾格尼丝的神圣，为了人类的自由而战，神圣不可侵犯）[贴图原画师：MDT小李.美化：Alex]";
//blad.ability = "AC Surge Discharge Booster";

const bladePad = extendContent(MechPad, "NAJG", {});

bladePad.mech = blad;
bladePad.buildTime = 300;