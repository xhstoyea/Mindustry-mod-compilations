//（被括号（）包住的内容是我自己加上去的，没有被括号包住的内容是原版注释的翻译）
//（必须要注意的是，以/*XXX*/为形式的注释意味着这行注释一下都是注释所阐明的内容，而/XXX/有时是对这行注释以前的一部分做注释，有时候是对这行注释以下的内容做注释）
/* 对机甲的配置 */
const yolkChance = 1; //每打出五发子弹射出一发yolk子弹
const rotateSpeed = 0.45; // 机甲所能转动的最大度数

/* （我也不知道起什么作用，不会翻译这里，原文为Cache） */
const black = Color(0);

/* 关于这个机甲所需的数据 */
const friedEgg = extend(BasicBulletType, {});
friedEgg.speed = 5;
friedEgg.damage = 90;
friedEgg.bulletWidth = 12;
friedEgg.bulletHeight = 18;
friedEgg.shootEffect = Fx.shootSmall;
//名为friedEgg的子弹的击中音效为flame;
friedEgg.ammoMultiplier = 3;
friedEgg.homingPower = 1;
friedEgg.homingRange = 25;
friedEgg.knockback = 0.1;
friedEgg.hitShake = 1;
friedEgg.incendAmount = 20;
friedEgg.bulletSprite = "科技革命-ho";
friedEgg.frontColor = Color.valueOf("#ffeecc");
//（对friedEdd子弹的设置）
//（我不信这部分你看不懂，这些是对子弹的设置）
const eggShell = extend(FlakBulletType, {});
eggShell.speed = 7.5;
eggShell.damage = 15;
eggShell.homingPower = 0.001;
eggShell.homingRange = 25;
eggShell.splashDamageRadius = 40;
eggShell.splashDamage = 30;
eggShell.ammoMultiplier = 3;
eggShell.incendAmount = 20;
eggShell.frontColor = Color.valueOf("#ecaf7c");
//（对eggShell子弹的设置）
// 我不知道为什么不起作用（这是原注释的翻译，事实上意指作者想新建一个射击后附加一个名为"egged"的状态，但是不知道为什么没有起作用，于是就用注释将其无效化）
/*const yolkStatus = extendContent(StatusEffect, "egged", {
	init: function(){
		this.trans(StatusEffects.shocked, StatusEffect.TransitionHandler({
			handle: function(unit, time, newTime, result) {
				unit.damage(10); //导电性不如水（这是原注释的翻译，其实只是作者对于egged与shocked（电击）状态产生联动的一句调侃）
				if(unit.getTeam() == state.rules.waveTeam){
					Events.fire(Trigger.shock);
				} // 由于不允许事件而不能使用（对原注释的翻译，我只想说翻译的什么鬼玩意？？？） :(
				this.result.set(this, time);
			}
		}));
		this.opposite(StatusEffects.burning);
	}
});
yolkStatus.speedMultiplier = 0.25;
yolkStatus.effect = Fx.wet;
yolkStatus.color = Color.valueOf("#dac114");*/

const yolk = extend(BasicBulletType, {});
yolk.speed = 3;
yolk.damage = 10;
yolk.splashDamageRadius = 30;
yolk.splashDamage = 10;
yolk.ammoMultiplier = 3;
//yolk.status = yolkStatus;//在这里使用了上面被无效化的一大段代码，yolkStatus事实上就是指egged
yolk.status = StatusEffects.tarred;
yolk.frontColor = Color.valueOf("#dac114");
//（对yolk子弹的设置）
const cannon = extendContent(Weapon, "2", {});
cannon.ejectEffect = Fx.blastsmoke;
cannon.length = 3;
cannon.width = 5.2;
cannon.bullet = friedEgg;
//（对cannon武器的部分设置）
const flak = extendContent(Weapon, "3", {});
flak.ejectEffect = Fx.shellEjectBig;
flak.length = 3;
flak.width = 5.2;
flak.bullet = eggShell;
//（对flak武器的部分设置）
// 让玩家能够把cannon武器切换为flak武器（直白点就是切枪）
const multiWeapon = extendContent(Weapon, "3", {
	// 不要问（原文don't ask）
	// @Override（我也搞不懂这两行想说什么）
	load: function(){
		print("No!!!!!!");
	},
	loadProperly: function(mech){
		this.region = Core.atlas.find("clear");
		if(mech != null){
			this.parent = mech;
		}
	},

	// 使机甲像坦克一样慢慢转弯
	// @Override（或许是想说是Override提供的代码？）
	update: function(shooter, pX, pY){
		var left = false;
		do{
			var pos = Vec2(pX, pY);
			pos.sub(shooter.getX(), shooter.getY());
			if(pos.len() < this.minPlayerDist){
				pos.setLength(this.minPlayerDist);
			}
			var cx = pos.x + shooter.getX(), cy = pos.y + shooter.getY();

			var ang = pos.angle();
			pos.setAngle(ang);
			pos.trns(ang - 90, this.width * Mathf.sign(left), this.length + Mathf.range(this.lengthRand));

			// 使用"realUpdate"来避免反复的使用这一段代码（我差点懵掉）
			this.realUpdate(shooter, pos.x, pos.y, Angles.angle(shooter.getX() + pos.x, shooter.getY() + pos.y, cx, cy), left);
			left = !left;
		}while(left);
	},
//（虽然有必要解释一下这一段，但是我看不懂）
	realUpdate: function(shooter, x, y, angle, left){
		if(shooter.getTimer().get(shooter.getShootTimer(left), this.reload)){
			if(this.alternate){
				shooter.getTimer().reset(shooter.getShootTimer(!left), this.reload / 2);
			}

			this.shoot(shooter, x, y, angle, left);
		}
	},
//（这里是对上面使用的"realUpdate"的设置）
	// @Override（依然是个ID）
	shoot: function(shooter, x, y, angle, left){
		if(this.parent != null){
			const lastRotation = this.parent.getRotation();

			// 避免在+x处缠绕（看不懂的机翻）
			if(Math.abs(angle - lastRotation) > 180){
				angle += 360;
			}
			// 限制转向速度
			if(Math.abs(angle - lastRotation) > rotateSpeed){
				// 决定朝着哪个方向转（不知道是指武器还是机甲）
				if((angle - this.parent.getBaseRotation()) > lastRotation){
					angle = rotateSpeed;
				}else{
					angle = -rotateSpeed;
				}
				angle += lastRotation;
			}
			this.parent.setRotation(angle);

			this.bullet = left ? eggShell : friedEgg; // 在cannon和flak两种武器的发射间隙间切换子弹
			const shootYolk = Mathf.random(0, yolkChance) < 1;
			if(Vars.net.client()){
				this.shootDirect(shooter, x, y, angle, left);
				if(shootYolk){
					this.bullet = yolk;
					this.shootDirect(shooter, x, y, angle, false);
				}
			}else{
				// 对发射的东西不起作用！！！（原文全部用的大写字母，语气很强）
				// 我希望没有人会把武器放在这里...（作者对自己感到无语，讲真我很想笑）
				Call.onPlayerShootWeapon(shooter, x, y, angle, left);
				if(shootYolk){
					this.bullet = yolk;
					Call.onPlayerShootWeapon(shooter, x, y, angle, false);
				}
			}
			// 正确处理看到的后坐力（？？？）
			this.parent.setOffset(left);
		}
	}
});
multiWeapon.reload = 15;
multiWeapon.length = 3;
multiWeapon.alternate = true;
multiWeapon.bullet = friedEgg; // 假定为一开始使用flak武器
multiWeapon.width = 0;
//（对于两种武器的共同设置？）
//（下面是对这个机甲的正式内容（也许可以理解为准备工作已经做完了））
/* 完全重写mother-hen机甲 */
const hen = extendContent(Mech, "mother-meiying", {
	// @Override（依然是个ID）
	load: function(){ // 太棒了，我可以使用load函数，因为它不需要super！（单纯的，作者对自己能使用load函数的高兴，但是我不知道super怎么翻译）
		this.weapon.loadProperly(this);
		this.cannon.load();
		this.flak.load();
//（对武器的.....看不懂）
		this.region = Core.atlas.find("clear");
		this.legRegion = Core.atlas.find(this.name + "-leg");
		this.baseRegion = Core.atlas.find(this.name + "-base");
		this.cannonRegion = Core.atlas.find(this.name + "-cannon");
		this.flakRegion = Core.atlas.find(this.name + "-flak");
		this.wingsRegion = Core.atlas.find(this.name + "-wings");
		this.headRegion = Core.atlas.find(this.name + "-head");
	},//（对各部分贴图的定义）

	// @Override（还是个ID）
	updateAlt: function(player){
		// 旋转基础（不懂怎么翻译，应该是指子弹旋转？或者击中旋转）（我翻译时没法玩游戏，所以有些只能猜测）
		if(this.targetRotation === null){
			this.targetRotation = player.rotation;
		}
		this.targetRotation = Mathf.lerp(this.targetRotation, player.rotation, 0.02);
		this._baseRotation = player.baseRotation;

		// 慢慢地减少后坐力
		this.flakOffset = Mathf.lerp(this.flakOffset, 0, 0.035);
		this.cannonOffset = Mathf.lerp(this.cannonOffset, 0, 0.03);
	},

	// @Override（没错，还是个ID）
	draw: function(player){
		const rotation = this.targetRotation - 90;
		const flakTotal = this.gunOffsetY - this.flakOffset;
		const cannonTotal = this.gunOffsetY - this.cannonOffset;

		// OffsetX数值与OffsetY的数值在游戏里起到了相反的作用，即OffsetX是横向偏移，但是在游戏里是纵向偏移，原因是贴图被旋转了四分之一）
		const flakX = Angles.trnsx(this.targetRotation, flakTotal, -this.gunOffsetX);
		const cannonX = Angles.trnsx(this.targetRotation, cannonTotal, this.gunOffsetX);
		const flakY = Angles.trnsy(this.targetRotation, flakTotal, -this.gunOffsetX);
		const cannonY = Angles.trnsy(this.targetRotation, cannonTotal, this.gunOffsetX);
		Draw.rect(this.cannonRegion, player.x + cannonX, player.y + cannonY, rotation);
		Draw.rect(this.flakRegion, player.x + flakX, player.y + flakY, rotation);
		Draw.rect(this.wingsRegion, player.x, player.y, rotation);
		Draw.rect(this.headRegion, player.x, player.y, rotation);
	},

	// @Override（这个ID很频繁....）
	drawStats: function(player){
		const health = player.healthf();
		Draw.color(Color.black, player.getTeam().color, health + Mathf.absin(Time.time(), health * 5, 1 - health));
		Draw.rect(player.getPowerCellRegion(),
			player.x + Angles.trnsx(this.targetRotation, this.cellTrnsY, 0),
			player.y + Angles.trnsy(this.targetRotation, this.cellTrnsY, 0),
			this.targetRotation - 90);
		Draw.reset();
		//player.drawBackItems();
		//player.drawLight();（这两行是对机甲飞行时尾焰的设定与....看不懂）
	},

	setOffset: function(left){
		if(left){
			this.flakOffset = 1.5;
		}else{
			this.cannonOffset = 2;
		}
	},//（对左边的武器放置偏移的设置）

	setRotation: function(rotation){
		this.targetRotation = rotation;
	},

	getRotation: function(){
		return this.targetRotation;
	},

	getBaseRotation: function(){
		return this._baseRotation;
	}
});
hen.cannonRegion = null;
hen.flakRegion = null;
hen.wingsRegion = null;
hen.headRegion = null;
hen.gunOffsetX = 9;
hen.gunOffsetY = 5.2;
hen.speed = 0.3;
hen.boostSpeed = 0.35;
hen.buildPower = 0.5;
hen.mass = 20;
hen.engineColor = Color.valueOf("#d62d19");
hen.flying = false;
hen.health = 4000;
hen.weapon = multiWeapon;
hen.cellTrnsY = -6.5;
hen.engineOffset = 7.5;
//（对机甲的正常数据设置）
hen.cannon = cannon;
hen.flak = flak;
hen.cannonOffset = 0;
hen.flakOffset = 0;
hen.targetRotation = null;
hen._baseRotation = 0;
//（对两种武器的数据设置）
/* 自定义机甲在机甲板上的出生动画与名称改动（名称改动是什么东西？） */
const silo = extendContent(MechPad, "meiyingg", {
	// @Override（最后一个ID）
	drawLayer: function(tile){
		const entity = tile.ent();
		if(entity.player != null){
			print("Player isnt null");
			if(!entity.sameMech || entity.player.mech != this.mech){
				print("eeeeeee")
				Draw.rect(Core.atlas.find("vbucks-mother-hen"), tile.drawx(), tile.drawy());
				// 把机甲用阴影盖住，然后慢慢淡去阴影，就像机甲正慢慢从工厂里走出来.
				Draw.color(black, 1 - entity.progress);
				Draw.rect(Core.atlas.find("vbucks-mother-hen-shadow"), tile.drawx(), tile.drawy());
				Draw.color();
			}else{
				// 正常绘制机甲，因为并不是玩家在建造机甲（看不懂其实）
				RespawnBlock.drawRespawn(tile, entity.heat, entity.progress, entity.time, entity.player, Mechs.starterMech);
			}
		}
	}
});
silo.mech = hen;
silo.update = true;
// 如果mother hen机甲出现了任何的错误，这些将不会被设置
silo.localizedName = Core.bundle.get("block.vbucks-hen-silo.real-name");
silo.description = Core.bundle.get("block.vbucks-hen-silo.real-description");
/*（1.0版注释，作者：手电（似乎有点小题大做了？））*/