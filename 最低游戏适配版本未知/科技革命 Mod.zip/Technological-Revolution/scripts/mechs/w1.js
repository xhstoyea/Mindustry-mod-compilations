const wj = newEffect(60,e =>{
    const d = new Floatc2({get(x,y){
        Draw.color(Color.valueOf("#FFFFFF"), Color.valueOf("#FFFF00"), e.fin());
        Lines.stroke(e.fslope() * 4);//大小
        Lines.circle(e.x, e.y, e.fin() * 10); 
    }})//有10到0的缩放
            Angles.randLenVectors(e.id, 10, 50 * e.fslope(),e.rotation, 360,d)
});

const zd = extend(BasicBulletType,{
    update(b){
                if(b.timer.get(12)){
            Effects.effect(wj,Color.valueOf("C2FF8300")/*圆圈颜色*/, b.x, b.y, b.rot());
        }
                }})
zd.speed = 3,
zd.damage = 30,
zd.lifetime = 900,
zd.bulletWidth = 1,
zd.bulletHeight = 10;
print(0)

const w1w = extendContent(Weapon,"w1w",{})
w1w.shots = 7,
w1w.bullet = zd,
w1w.name = w1w,
w1w.spacing = 3,
w1w.length = 2,
w1w.reload = 60,
w1w.recoil = 0.2,
w1w.alternate = true,
w1w.bulletWidth = 2,
w1w.bulletHeight = 3;
print(0)

const w1 = extendContent(Mech,"w1",{
	updateAlt(player){
		if(player.boostHeat >= 0.1) return;
		this.hitsize = 120
},
	load(){
		this.weapon.load();
        if(!this.flying){
            this.legRegion = Core.atlas.find(this.name + "-leg");
            this.baseRegion = Core.atlas.find(this.name + "-base");
        }
		this.region = Core.atlas.find(this.name);
		this.weapon.region = Core.atlas.find("科技革命-ho");
	}
})