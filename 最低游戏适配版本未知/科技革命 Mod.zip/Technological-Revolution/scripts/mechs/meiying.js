
const meiyingp = extendContent(Weapon,"2",{

})
//子弹类型
meiyingp.bullet = Bullets.standardMechSmall;
meiyingp.name = meiyingp;
//武器长
meiyingp.length = 9;
meiyingp.shootEffect = Fx.shootHeal;
meiyingp.smokeEffect = Fx.hitLaser;
//一次多少子弹
meiyingp.shots = 1;
//弹速随机改变区间
meiyingp.velocityRnd = 0;
//射击延迟
meiyingp.shotDelay = 4;
//是否左右手轮流射击
meiyingp.roundrobin = true
//一次打出多个子弹时，子弹间角
meiyingp.spacing = 0.25;
//后坐力
meiyingp.recoil = 1;
//武器宽
meiyingp.width = 3.45;
//重新装弹
meiyingp.reload = 25;
//精准度
meiyingp.inaccuracy = 1;
meiyingp.alternate = false;
//范围
meiyingp.range = 350;
meiyingp.bulletSprite = "科技革命-ho";
meiyingp.bulletWidth = 4
meiyingp.bulletHeight = 20
meiyingp.ejectEffect = Fx.none

const meiying = extendContent(Mech,"meiying",{
	load(){
		this.weapon.load();
		this.region = Core.atlas.find(this.name);
		this.weapon.region = Core.atlas.find("科技革命-2");
	}
})
meiying.weapon = meiyingp;
meiying.weaponOffsetX = 4.5;
meiying.health = 300,
meiying.mass = 6,
meiying.speed = 0.3,
meiying.boostSpeed = 0.6,
meiying.drag = 0.05,
meiying.buildPower = 4,
meiying.itemCapacity = 70,
meiying.engineOffset = 6.325,
meiying.engineSize = 2.5,
meiying.engineColor = Color.valueOf("fe565d");
meiying.flying = true,
meiying.canHeal = true,
meiying.drillPower = 5,
meiying.mineSpeed = 4,
meiying.weaponOffsetY = 7.5