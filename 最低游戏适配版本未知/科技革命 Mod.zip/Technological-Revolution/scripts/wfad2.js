const wfad2 = extendContent(ImpactReactor,"wfad2",{
    update(tile){
        const entity = tile.ent();

        if(entity.cons.valid() && entity.power.status >= 0.99){

            var prevOut = this.getPowerProduction(tile) <= this.consumes.getPower().requestedPower(entity);

            entity.warmup = Mathf.lerpDelta(entity.warmup, 1, this.warmupSpeed);
            if(Mathf.equal(entity.warmup, 1, 0.001)){

                entity.warmup = 1;
            }

            if(!prevOut && (this.getPowerProduction(tile) > this.consumes.getPower().requestedPower(entity))){
            }

            if(entity.timer.get(this.timerUse, this.itemDuration / entity.timeScale)){

                entity.cons.trigger();
                Effects.effect(newEffect(25,e => {

                    const d = new Floatc2({get(x,y){

                        Draw.color(e.color, Color.valueOf("ff59ff"), e.fin());
                        Fill.square(e.x + x, e.y + y, 0.1 + e.fout() * 2+1, 25);
                    }})
                    Angles.randLenVectors(e.id, 20, 20 + e.fin() * 20,d);
                            
                }),tile)
                Effects.shake(3,3,tile)
                Sounds.release.at(tile);
                for (var i = 0; i < 7; i++) {

                    Lightning.create(Team.sharded,Color.valueOf("ff59ff"), 3, tile.drawx(), tile.drawy(),Mathf.random(360), 15);         
                }

            }
            if(Mathf.chance(Time.delta() * 0.07)){

                Effects.shake(1,1,tile)

                Lightning.create(Team.sharded,Color.valueOf("ff59ff"), 3, tile.drawx(), tile.drawy(),Mathf.random(360), 15);         
            }
        }else{
            
            entity.warmup = Mathf.lerpDelta(entity.warmup, 0, 0.01);
        }

        
        entity.productionEfficiency = Mathf.pow(entity.warmup, 5);
    },
    draw(tile){
        this.super$draw(tile)
        tile.entity.healBy(0.0005 * tile.entity.maxHealth());}
})