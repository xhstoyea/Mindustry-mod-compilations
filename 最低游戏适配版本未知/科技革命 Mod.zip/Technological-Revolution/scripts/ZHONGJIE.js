const range = 500;

const 心灵震荡波 = newEffect(20, e => {
    Draw.color(Color.valueOf("DA00FF"));
    Lines.stroke(e.fout() * 10);
    Lines.circle(e.x, e.y, 10 + e.finpow() * 30);
});
const 心灵控制 = newEffect(10, e => {
    Draw.color(Color.valueOf("DA00FF"));
    Lines.stroke(e.fout() * 2);
    Lines.circle(e.x, e.y, 2 + e.finpow() * 7);
});

const 心灵终结仪 = extendContent(GenericCrafter, "心灵终结仪", {
    update(tile){
        const entity = tile.ent();
        
        const target = Units.closestTarget(tile.getTeam(), tile.drawx(), tile.drawy(), range, boolf((e) => {return !e.isDead()}));
        if(entity.cons.valid()){
            if(entity.timer.get(230)){ 
                entity.charge += 1;
                entity.cons.trigger();
            }
        };
        if(target != null&&entity.charge >= 99){
            
            Effects.effect(心灵震荡波, tile.drawx(), tile.drawy());
            Units.nearby(target.getTeam(), tile.drawx(), tile.drawy(), range, cons(unit => {
				if(unit.getTeam() != tile.getTeam()){
				    const unitType = ContentType.unit;
				    for(var i = 0;;i++){
				        var units = Vars.content.getByID(unitType, i)
				        var unitR = null;
				        if(units == null){
				            return;
				        };
				        if(units.typeID == unit.getTypeID()){
				            unitR = units;
				            var unitI = unitR.create(tile.getTeam());
					        unitI.set(unit.getX(), unit.getY());
                            Effects.effect(心灵控制, unitI.x, unitI.y, 0, unitI);
                            unitI.add();
                            unitI.velocity().y = 0;
                            unitI.health(unit.health());
                            unit.onDeath();
				            return
				        }else{
				            continue;
				        };
				    };
				};
            }));
        entity.charge = 0;//(充能重置)
		const tilesize = Vars.tilesize;
		var tileRange = (range / tilesize + 1);
		const XLKZ = this.XLKZ;
		for(var x = -tileRange + tile.x; x <= tileRange + tile.x; x++){
            for(var y = -tileRange + tile.y; y <= tileRange + tile.y; y++){
                if(!Mathf.within(x * tilesize, y * tilesize, tile.drawx(), tile.drawy(), range)) continue;

                var other = Vars.world.ltile(x, y);

                if(other == null) continue;

                if(other.getTeamID() != tile.getTeamID() && !XLKZ.contains(other.pos()) && other.ent() != null){
                    other.setTeam(tile.getTeam());
                    Effects.effect(心灵控制, other.drawx(), other.drawy());
                    XLKZ.add(other.pos());
                    }
                }
            }
        };
        var toastU = 100 - entity.charge;
    },
    buildConfiguration(tile,table){
        const entity = tile.ent();
        table.addImageButton(Icon.cancel, Styles.clearTransi, run(() => {
	    entity.charge = 100;
    })).size(50)
    },
    drawSelect(tile){
        const entity = tile.ent();
        const len = 100;
        /*const baseColor = Color.valueOf("C8E8FF");
        Draw.color(baseColor);
	    Lines.stroke(3);
	    Lines.lineAngleCenter(tile.drawx() + Vars.tilesize * 4 + 4,tile.drawy() - 1000 * Vars.tilesize  / len * Vars.tilesize / 2 + entity.charge / len / 2 * Vars.tilesize, 90, entity.charge / len * Vars.tilesize);
		Drawf.dashCircle(tile.drawx(), tile.drawy(), 240, baseColor);*/
		Draw.color(Color.valueOf("#292F3C"));
		Lines.stroke(4);
	    Lines.lineAngleCenter(tile.drawx() + Vars.tilesize * 4 + 4,tile.drawy(), 90, 100 * Vars.tilesize  / len * Vars.tilesize);
		
        Draw.color(Color.valueOf("#DA00FF"));
        Lines.stroke(4);
	    Lines.lineAngleCenter(tile.drawx() + Vars.tilesize * 4 + 4,tile.drawy(), 90, entity.charge);
    },

    setBars(){
        this.super$setBars();
        this.bars.add("充能进度", func(entity => {
            var i = new Bar(prov(()=>"充能进度"), prov(()=>Color.valueOf("DA00FF")), floatp(() => entity.charge / 100));
            return i;
        }));
    }
});
心灵终结仪.health = 5050;
心灵终结仪.XLKZ = new IntSet();
心灵终结仪.size = 8;
心灵终结仪.consumes.power(50);
心灵终结仪.configurable = true;
心灵终结仪.localizedName = "控制中枢";
心灵终结仪.description = "长时间充能并放出中等范围控制波，控制建筑和敌人";
心灵终结仪.requirements(Category.effect, ItemStack.with(Items.copper, 30));
心灵终结仪.entityType=prov(()=>extend(GenericCrafter.GenericCrafterEntity,{
    getcharge(){return this._charge},
    setcharge(value){this._charge = value},
    _charge:0,
}))