

const TH = extendContent(StatusEffect,"TH",{});
TH.damage = 0;
TH.damageMultiplier = 1;
TH.armorMultiplier = 0.8;
TH.speedMultiplier = 0.3;
TH.effect = newEffect(40,e => {
	
	const d = new Floatc2({get(x,y){
	    
	    Draw.color(Color.valueOf("ffefd8"));
                
                Fill.square(e.x + x, e.y + y, 0.1 + e.fout() * 1, 45);
            }})
            
            Angles.randLenVectors(e.id, 3, 1 + e.fin() * 1,d);
            
        });
        
TH.color = Color.valueOf("ffefd8");
//const THH分裂 = extend(BasicBulletType,{})
//THH分裂.speed = 4,
//THH分裂.damage = 0,
//THH分裂.bulletWidth = 0,
//THH分裂.bulletHeight = 0,
//THH分裂.bulletShrink = 1,
//THH分裂.lifetime =18,
//THH分裂.pierce = true,
//THH分裂.backColor = Color.valueOf("FF8A6500"),
//THH分裂.frontColor = Color.valueOf("FF8A6500"),
//THH分裂.status =TH,
//THH分裂.statusDuration = 450,
//THH分裂.despawnEffect = Fx.none,
//THH分裂.hitEffect = Fx.none
const THH = extend(BasicBulletType, {});

THH.speed = 5.5,
    THH.damage = 25,
    THH.splashDamageRadius = 50,
    THH.splashDamage = 25,
    THH.bulletShrink = 0.1,
    THH.knockback = 0,
    THH.bulletSprite = "科技革命-ji";
THH.bulletWidth = 20,
    THH.bulletHeight = 20,
    THH.ammoMultiplier = 3,
    THH.lifetime = 45,
    THH.backColor = Color.valueOf("f3dbb9"),
    THH.frontColor = Color.valueOf("ffefd8"),
    THH.status = TH,
    THH.statusDuration = 400,
    //THH.fragBullets = 30,
    //THH.fragBullet = THH分裂,
    THH.smokeEffect = newEffect(30, e => {

        const d = new Floatc2({
            get(x, y) {

                Draw.color(Color.valueOf("ffefd8"));
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 5, 45);

            }
        });

        Angles.randLenVectors(e.id, 15, 1 + e.fin() * 25, d);

    });
THH.hitEffect = newEffect(18, e => {

    const d = new Floatc2({
        get(x, y) {
            Draw.color(Color.valueOf("f3dbb9"));
            Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 10 + 1);

        }
    });

    Draw.color(Color.valueOf("ffefd8"), Color.valueOf("f3dbb9"), e.fin());
    Lines.stroke(e.fout() * 3);
    Angles.randLenVectors(e.id, 6, 1 + 50 * e.fin(), e.rotation, 360, d);


    Lines.stroke(e.fout() * 4 + 0.1);
    Lines.circle(e.x, e.y, e.fin() * 50);

    Fill.circle(e.x, e.y, e.fout() * 13);
    Fill.circle(e.x, e.y, e.fout() * 7);

});
const THH = extendContent(PowerTurret,"THPZ",{})

