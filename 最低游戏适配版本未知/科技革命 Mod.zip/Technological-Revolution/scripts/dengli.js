const siloLaunchEffect2 = newEffect(20, e => 
    {
    Draw.color(Color.valueOf("33ff36"), Color.valueOf("a4ffb3"), e.fin());
    Lines.stroke(e.fout() * 3); //厚度从3到0
    Lines.circle(e.x, e.y, e.fin() * 11.5); //画一个从0到100的圆
});
const lizi = extendContent(PowerTurret,"deng1",{

});
lizi.shootEffect =  newEffect(50,e => {
    
    //圆圈烟雾
    const c = new Floatc2({get(x, y){
	    
	    Draw.color(Color.valueOf("a4ffb3"));
        Fill.circle(e.x + x, e.y + y, e.fout() * 5);
    }}) 
    
    Angles.randLenVectors(e.id, 5, 1 + 25 * e.fin(), e.rotation, 100,c);

        });
lizi.coolEffect = siloLaunchEffect2;
lizi.smokeEffect = siloLaunchEffect2;
