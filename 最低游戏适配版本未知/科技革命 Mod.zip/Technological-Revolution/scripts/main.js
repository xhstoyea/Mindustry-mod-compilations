
const Nanocore = extendContent(Item,"Nanocore",{});
Nanocore.color = Color.valueOf("cedbe3")
Nanocore.hardness = 5,//挖掘等级
Nanocore.explosiveness = 0.1,//爆炸性
Nanocore.flammability = 0.1,//可燃性
Nanocore.radioactivity = 0.1,//辐射性
Nanocore.type = ItemType.material;//是否进核心
	
	require("xlm");
	require("NAMI");
	require("Y1");
	require("NAMIQD");
	require("NAMIQX");
	require("wfad2");
	require("Ydire");
	require("Yfuse");
	require("electrum-forge");
	require("electrum-drill");
	require("SIG");
	require("SUP");
	require("LG1");
	require("CSK");
	require("NJJ");
//    require("THP");
	//require("ZHONGJIE");
	//require("ZHONG");
	//require("meiying1");
	require("dengli");
	//require("ce");
if(typeof(require) !== "undefined"){ // Work on 103 too
	require("blocks/xiaoji");
	//require("blocks/scatter-silo");
	require("blocks/chiyan");
	require("blocks/1");
	require("blocks/nagl");
	require("blocks/nagl2");
	require("blocks/shouhuw");
	require("blocks/cai");
	require("blocks/juneng");
	require("blocks/dagui");
	require("blocks/feili-forge-rotator");
	require("blocks/feili-electrum-forge");
	require("blocks/xl");
	require("blocks/junengqi");
	require("blocks/jxf");
	require("blocks/ho");
	require("blocks/wjj");
	require("blocks/xin");
	//require("items/JS");
};
 