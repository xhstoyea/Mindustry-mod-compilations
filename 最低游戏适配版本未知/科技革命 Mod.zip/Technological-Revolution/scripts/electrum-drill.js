const siloLaunchEffect2 = newEffect(20, e => 
    {
    Draw.color(Color.valueOf("33ff36"), Color.valueOf("a4ffb3"), e.fin());
    Lines.stroke(e.fout() * 3); //厚度从3到0
    Lines.circle(e.x, e.y, e.fin() * 13); //画一个从0到100的圆
});
const juneng = extendContent(Drill,"electrum-drill",{
  
});
     juneng.drillEffect = siloLaunchEffect2;