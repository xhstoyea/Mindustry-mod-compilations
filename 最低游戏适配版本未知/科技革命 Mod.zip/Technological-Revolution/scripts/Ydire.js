
const siloLaunchEffect2 = newEffect(20, e => {
    Draw.color(Color.valueOf("#9400D3"), Color.valueOf("#F0F8FF"), e.fin());
    Lines.stroke(e.fout() * 3); //厚度从3到0
    Lines.circle(e.x, e.y, e.fin() * 10); //画一个从0到100的圆
});
const Ydire = extendContent(ThermalGenerator,"Ydire",{
    draw(tile){      
        this.super$draw(tile)
        tile.entity.healBy(0.0005 * tile.entity.maxHealth());
    },
});
Ydire.generateEffect = siloLaunchEffect2;