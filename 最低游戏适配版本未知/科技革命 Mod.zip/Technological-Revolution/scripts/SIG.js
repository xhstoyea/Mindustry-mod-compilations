const colorsSG = [Color.valueOf("b200b3"), Color.valueOf("ff4cff"), Color.valueOf("ffa8ff")];
const tscalesSG = [2, 1.5, 1, 0.825];
const lenscalesSG = [1, 1.25, 1.4, 1.45];
const lengthSG = 365;
const SIG = extend(ArtilleryBulletType,{
    range(){
        return lengthSG;
    },
	init(b){
		if (b == null) return;
		Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), lengthSG);
	},
    draw(b){
        const f = Mathf.curve(b.fin(), 0, 0.2);
        const baseLen = lengthSG * f;
        for(var s = 0; s < 3; s++){
            Draw.color(colorsSG[s]);
            for(var i = 0; i < tscalesSG.length; i++){
                Lines.stroke(7 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.25) * tscalesSG[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscalesSG[i]);
            }
        }
        Draw.reset();
    }
})
SIG.damage = 1000;
SIG.speed = 0.0001;
SIG.hitEffect = newEffect(55, e => {
    Draw.color(Color.valueOf("ff33ff"),Color.valueOf("ffb2ff"),e.fin());
    const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 5);
    }}) 
    Angles.randLenVectors(e.id, 5, 1 + 30 * e.fout(), e.rotation, 360,d);
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 6);
    }}) 
    Angles.randLenVectors(e.id, 5, 1 + 40 * e.fin(), e.rotation, 360,c);
});
SIG.despawnEffect = Fx.none;
SIG.collidesTiles = false;
SIG.pierce = true;
SIG.hitSize = 250;
SIG.drawSize = 250;
SIG.bulletWidth = 60;
SIG.lifetime = 60;
SIG.drawSize = lengthSG * 2.5;
SIG.shootEffect = newEffect(60, e => {
    Draw.color(Color.valueOf("ee2dff"));
    Fill.circle(e.x, e.y, e.fout() * 11.25);
});
SIG.smokeEffect = newEffect(30, e => {
    Draw.color(Color.valueOf("bd32ca"),Color.valueOf("ffb2ff"),e.fin());
    
    Lines.stroke(e.fout() * 3);
    Lines.circle(e.x, e.y, e.fin() * 40);
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 4.25);
    }}) 
    Angles.randLenVectors(e.id, 20, 1 + 30 * e.fin(), e.rotation, 360,c);
});



const SIGP = extendContent(ChargeTurret,"SIGP",{})
SIGP.shootType = SIG
SIGP.chargeBeginEffect = newEffect(80, e => {
    Draw.color(Color.valueOf("ff33ff"));
    Fill.circle(e.x, e.y, e.fin() * 7);
    Draw.color(Color.valueOf("ff33ff"),Color.valueOf("ffb2ff"),e.fin());
    Fill.circle(e.x, e.y, e.fin() * 4.25);
});

SIGP.chargeEffect = newEffect(80, e => {
    Draw.color(Color.valueOf("270027"),Color.valueOf("db57db"),e.fin());
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 25, 1 + 100 * e.fout(), e.rotation, 360,d);
});