function UnitCreate(itile,iUnit,range){
    const units = Vars.content.units();
    var unitI = units.get(iUnit.id).create(itile.getTeam());
    //unitI.spawner = itile;
    unitI.set(itile.drawx() + Mathf.range(range), itile.drawy() + Mathf.range(range) + range);
    Effects.effect(Fx.unitSpawn, unitI.x, unitI.y, 0, unitI);
    unitI.add();
    unitI.velocity().y = 0;
}

const 心灵终结仪 = extendContent(GenericCrafter, "出生点0x00000", {
    update(tile){
        const entity = tile.ent();
        if(entity.cons.valid()&&entity.charge < 100){
            if(entity.timer.get(230)&&entity.charge < 100){ 
                entity.charge += 1;
                entity.cons.trigger();
            }
        };
        if(entity.charge >= 99){
            const unitType = ContentType.unit;
            var unit = Vars.content.getByName(unitType, "科技革命-yilong");
			UnitCreate(tile,unit,80)
           entity.charge = 0;//(充能重置)
        };
        var toastU = 100 - entity.charge;

    },
    buildConfiguration(tile,table){
        const entity = tile.ent();
        table.addImageButton(Icon.cancel, Styles.clearTransi, run(() => {
	    entity.charge = 100;
    })).size(50)
    },
    drawSelect(tile){
        const baseColor = Color.valueOf("C8E8FF");
        const len = 100;
        Draw.color(baseColor);
	    Lines.stroke(3);
		Drawf.dashCircle(tile.drawx(), tile.drawy(), this.range, baseColor);
    },
    setBars(){
        this.super$setBars();
        this.bars.add("充能进度", func(entity => {
            var i = new Bar(prov(()=>"充能进度"), prov(()=>Color.valueOf("DA00FF")), floatp(() => entity.charge / 100));
            return i;
        }));
    }
});
心灵终结仪.spawns = [UnitTypes.crawler,UnitTypes.titan,UnitTypes.crawler,UnitTypes.titan,UnitTypes.crawler,UnitTypes.titan];
心灵终结仪.health = 5050;
心灵终结仪.range = 100;
心灵终结仪.size = 5;
心灵终结仪.consumes.power(50);
心灵终结仪.configurable = true;
心灵终结仪.localizedName = "虫洞单位支援";
心灵终结仪.description = "单位支援，通过充能来和超远程的虫洞装置对接，传送支援单位";
心灵终结仪.requirements(Category.effect, ItemStack.with(Items.copper, 30));
心灵终结仪.entityType=prov(()=>extend(GenericCrafter.GenericCrafterEntity,{
    getcharge(){return this._charge},
    setcharge(value){this._charge = value},
    _charge:0,
}))