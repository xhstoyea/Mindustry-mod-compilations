const range = 1000;
const targetRange = 45;

const 时空缝隙 = newEffect(22, e => {
    Draw.color(Color.valueOf("3399ff"));
    Lines.stroke(e.fout() * 2);
    Lines.circle(e.x, e.y, 4 + e.finpow() * 60);
});
const 时空传送 = newEffect(12, e => {
    Draw.color(Color.valueOf("#00E2FF"));
    Lines.stroke(e.fout() * 2);
    Lines.circle(e.x, e.y, 2 + e.finpow() * 10);
});

const 超时空传送仪 = extendContent(GenericCrafter, "CSK", {
    update(tile){
        const entity = tile.ent();
        var spotTile = Vars.world.tile(this.selectaSpots[tile.x + "," + tile.y]);
        //if(this.selectaSpots2 == undefined) return;
        var spotTile2 = Vars.world.tile(this.selectaSpots2[tile.x + "," + tile.y]);
        if(entity.cons.valid()){

            entity.progress += this.getProgressIncrease(entity, this.craftTime);
            entity.totalProgress += entity.delta();
            entity.warmup = Mathf.lerpDelta(entity.warmup, 1, 0.02);
            
        }else{
            entity.warmup = Mathf.lerp(entity.warmup, 0, 0.02);
        };
        if(entity.progress >= 1){
            entity.cons.trigger();
            Effects.effect(时空缝隙, spotTile.drawx(), spotTile.drawy());
            Units.nearby(tile.getTeam(), spotTile.drawx(), spotTile.drawy(), targetRange, cons(unit => {
				unit.set(spotTile2.drawx(), spotTile2.drawy());
				Effects.effect(时空传送, unit.getX(), unit.getY(), 0, unit);
            }));
            entity.progress= 0;
        };
    },
    draw(tile){
        Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-0"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 3)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-1"),tile.drawx(),tile.drawy(),0 - tile.ent().totalProgress * 3.5)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-2"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 4)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-3"),tile.drawx(),tile.drawy(),0 - tile.ent().totalProgress * 9)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        this.super$draw(tile)
        tile.entity.healBy(0.0005 * tile.entity.maxHealth());
     },
    playerPlaced(tile) {
        
            this.selectaSpots[tile.x + "," + tile.y] = tile.pos();
        
        
            this.selectaSpots2[tile.x + "," + tile.y] = tile.pos();
        
    },
    configured(tile, player, value) {
        const entity = tile.ent();
        if(entity.open == 0){
            this.selectaSpots[tile.x + "," + tile.y] = value;
        };
        if(entity.open == 1){
            this.selectaSpots2[tile.x + "," + tile.y] = value;
        };
    },
    onConfigureTileTapped(tile, other) {
    	
        const entity = tile.ent();
        
        if(Math.pow(other.x - tile.x, 2) + Math.pow(other.y - tile.y, 2) > Math.pow((range - targetRange) / Vars.tilesize, 2)&&entity.selectTarget==1) return true;
        if((this.selectaSpots[tile.x + "," + tile.y] === other.pos()) || (this.selectaSpots2[tile.x + "," + tile.y] === other.pos())&&entity.selectTarget==1) return true;
        if(entity.selectTarget != 1)return true;
        
        tile.configure(other.pos());
        if(entity.open == 1){
            entity.open = 0;
        }else{
            entity.open = 1;
        };
        return false;
        
    },
    buildConfiguration(tile,table){
        const entity = tile.ent();
        table.addImageButton(Icon.cancel, Styles.clearTransi, run(() => {
	    entity.selectTarget = 0;
    })).size(50)
    
    table.addImageButton(Icon.zoom, Styles.clearTransi, run(() => {
	    entity.selectTarget = 1;
    })).size(50)
    },
    drawConfigure(tile){
        var spotTile = Vars.world.tile(this.selectaSpots[tile.x + "," + tile.y]);
        var spotTile2 = Vars.world.tile(this.selectaSpots2[tile.x + "," + tile.y]);
        
        const entity = tile.ent();
        
    	if(entity.selectTarget == 1){
	        Draw.color(Color.valueOf("0f2e4d"));
	        Draw.blend(Blending.additive);
	        Fill.circle(tile.drawx(), tile.drawy(), range);
	        Draw.color(Color.valueOf("3399ff"));
	        Lines.stroke(7);
	        Lines.circle(tile.drawx(), tile.drawy(),range);
	        Lines.circle(spotTile.drawx(), spotTile.drawy(), targetRange);
			Lines.square(spotTile.drawx(),spotTile.drawy(),  12, 45 + Time.time() * 3);
		    Lines.square(spotTile.drawx(),spotTile.drawy(), 7, 45 - Time.time() * 3);
		    Draw.color(Color.valueOf("#00E2FF"));
	        Lines.stroke(7);
	        Lines.circle(tile.drawx(), tile.drawy(),range);
	        Lines.circle(spotTile2.drawx(), spotTile2.drawy(), targetRange);
			Lines.square(spotTile2.drawx(), spotTile2.drawy(),  12, 45 + Time.time() * 3);
		    Lines.square(spotTile2.drawx(), spotTile2.drawy(), 7, 45 - Time.time() * 3);
	    }
	    Draw.blend();
        Draw.reset();
    }
});
超时空传送仪.health = 4000;
超时空传送仪.size = 8;
超时空传送仪.craftTime = 0.5;
超时空传送仪.consumes.power(50);
超时空传送仪.configurable = true;
超时空传送仪.localizedName = "虫洞迁跃装置";
超时空传送仪.description = "传送单位和机甲，用于突袭和长距离攻击，大大的节省了部队的进军时间（某国家的科学家提出了“虫洞”理论。那么，“虫洞”是什么呢？简单地说，“虫洞”是宇宙中的隧道，它能扭曲空间，可以让原本相隔亿万公里的地方近在咫尺。 早在以前20世纪50年代，已有科学家对“虫洞”作过研究，由于当时历史条件所限，一些物理学家认为，理论上也许可以使用“虫洞”，但“虫洞”的引力过大，会毁灭所有进入的东西，因此不可能用在宇宙航行上。 随着科学技术的发展，新的研究发现，“虫洞”的超强力场可以通过“负质量”来中和，达到稳定“虫洞”能量场的作用。科学家认为，相对于产生能量的“正物质”，“反物质”也拥有“负质量”，可以吸去周围所有能量。像“虫洞”一样，“负质量”也曾被认为只存在于理论之中。不过，目前世界上的许多实验室已经成功地证明了“负质量”能存在于现实世界，并且通过航天器在太空中捕捉到了微量的“负质量”。 据某国家研究人员的计算，“负质量”可以用来控制“虫洞”。他们指出，“负质量”能扩大原本细小的“虫洞”，使它们足以让太空飞船穿过。）";
超时空传送仪.requirements(Category.effect, ItemStack.with(Nanocore,5000));
超时空传送仪.selectaSpots = {};
超时空传送仪.selectaSpots2 = {};
超时空传送仪.entityType=prov(()=>extend(GenericCrafter.GenericCrafterEntity,{
    getselectTarget(){return this._selectTarget},
    setselectTarget(value){this._selectTarget = value},
    _selectTarget:0,
    getopen(){return this._open},
    setopen(value){this._open = value},
    _open:0,
}))