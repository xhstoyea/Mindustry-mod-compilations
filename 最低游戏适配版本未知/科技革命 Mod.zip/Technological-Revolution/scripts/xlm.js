const targetRange = 230;
const maxSpawn = 4;//最大控制数

const 心灵震荡波 = newEffect(22, e => {
    Draw.color(Color.valueOf("#DA00FF"));
    Lines.stroke(e.fout() * 2);
    Lines.circle(e.x, e.y, 4 + e.finpow() * 60);
});


const XL = extendContent(UnitFactory,"Dementor", {
    update(tile){
        const entity = tile.ent();
        const target = Units.closestTarget(tile.getTeam(), tile.drawx(), tile.drawy(), targetRange, boolf((e) => {return !e.isDead()}));
        if(target!=null&&entity.spawned2 < maxSpawn&&tile.ent().cons.valid()&&entity.power.status > 0.9){
            if(entity.timer.get(360)){
                Units.nearby(target.getTeam(), target.getX(), target.getY(), 1, cons(unit => {
                
                    
                    //entity.unitList.push(unit.getID());
                    
                    this.onUnitFactorySpawn(tile,entity.spawned2+1,unit);
                    entity.cons.trigger();
                
                }));
            };
        }
        
    },
    draw(tile){
        const entity = tile.ent();
        Draw.rect(this.name, tile.drawx(), tile.drawy());
        if(tile.ent().cons.valid()&&entity.power.status > 0.9) Draw.rect(this.name + "-top", tile.drawx(), tile.drawy());
        
    },
    drawSelect(tile){
        const baseColor = Color.valueOf("ee36ff");
        const len = 100;
        Draw.color(baseColor);
	    Lines.stroke(3);
		Drawf.dashCircle(tile.drawx(), tile.drawy(), targetRange, baseColor);
    },
    onUnitFactorySpawn:function(tile,spawns,unit){
        const 心灵控制 = newEffect(1000, e => {
    Draw.color(Color.valueOf("DA00FF"));
    Lines.stroke(e.fout() * 2);
    Lines.circle(e.x, e.y, 2 + e.finpow() * 7);
});

        if(unit.getTeam() != tile.getTeam()){
            const entity = tile.ent();
	    const unitType = ContentType.unit;
		for(var i = 0;;i++){
		var units = Vars.content.getByID(unitType, i)
		var unitR = null;
		if(units == null){
			return;
		};
		if(units.typeID == unit.getTypeID()){
		    
		    if(unit.isBoss()) return;
		   
		    var health1 = unit.health();
			unitR = units;
			var unitI = unitR.create(tile.getTeam());
			unitI.setSpawner(tile);
			unitI.set(unit.getX(), unit.getY());
            Effects.effect(心灵控制, unitI.x, unitI.y, 0, unitI);
            unitI.add();
            unitI.velocity().y = 0;
            
            const UnitCreateEvent = EventType.UnitCreateEvent;
            Events.fire(new UnitCreateEvent(unitI));
            
            entity.spawned2 = spawns;
            
            unit.remove();
            unitI.health = health1;
            
            
            return;
		    }else{
		        continue;
		    }
	    }
    }
    },
    unitRemoved(tile, unit){
        const entity = tile.ent();
        entity.spawned2--;
        entity.spawned2 = Math.max(entity.spawned2, 0);
    },
    /*drawLayer(tile){
        const entity = tile.ent();
        const t1 = new Vec2(), t2 = new Vec2();
        
        for(var i in entity.unitList){
            if(Vars.unitGroup.getByID(entity.unitList(index)).isDead()==true) {
                entity.unitList.splice(index,1);
                continue;
            };
            var x1 = tile.drawx(),  y1 = tile.drawy(), x2 = getX(tile, i), y2 = getY(tile, i);
            var angle1 = Angles.angle(x1, y1, x2, y2);
            t1.trns(angle1, tile.block().size * Vars.tilesize / 2 - 1.5);
            t2.trns(angle1 + 180, 1 * Vars.tilesize / 2 - 1.5);
            x1 += t1.x;
            y1 += t1.y;
            x2 += t2.x;
            y2 += t2.y;
            Draw.color(Color.HSVtoRGB((Mathf.sin(Time.time(), 50 * 2, 360) + 360) / 2,70,100));
            Draw.alpha(1);
            Drawf.laser(Core.atlas.find("minelaser"),Core.atlas.find("minelaser-end"), x1, y1, x2, y2, 0.25);
            Draw.color();
            Draw.blend();
            Draw.reset();
        }
    }*/
});
XL.health = 1000;
XL.unitType = UnitTypes.draug;//这里随便填，不影响效果
XL.size = 2;
XL.entityType=prov(()=>extend(UnitFactory.UnitFactoryEntity,{
    getspawned2(){return this._spawned2},
    setspawned2(value){this._spawned2 = value},
  
    _spawned2:0,
    /*
    getunitList(){return this._unitList},
    setunitList(value){this._unitList = value},
  
    _unitList:[],
    */
    write(stream){
        this.super$write(stream);
        stream.writeInt(this._spawned2);
    },
    read(stream,revision){
        this.super$read(stream,revision);
        this._spawned2=stream.readInt();
    },
    
    }));
XL.consumes.power(8.333333333);
XL.localizedName = "摄魂者";
XL.description = "这是我们最近研发的防御武器，它并不能发出能量攻击，而是控制靠近的敌人，来让他们互相残杀，为我们而战斗，这大大降低了我们争战的消耗（带有BOSS效果的敌人不会被控制）";
XL.requirements(Category.effect, ItemStack.with(Items.copper, 0))

/*
function getX(tile, index) {
            const entity = tile.ent();
            var v1 = Vars.unitGroup.getByID(entity.unitList(index));
            return v1.getX();
        }
function getY(tile, index) {
            const entity = tile.ent();
            var v1 = Vars.unitGroup.getByID(entity.unitList(index));
            return v1.getY();
        };
*/
