const NAMIQD = extendContent(DeflectorWall,"NAMIQD",{
    draw(tile){
        this.super$draw(tile)
        tile.entity.healBy(0.0006 * tile.entity.maxHealth());
    }
});
	NAMIQD.health = 5000,
    NAMIQD.size = 2;
