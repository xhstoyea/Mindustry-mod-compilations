const effectColor = Color.valueOf("81ACFF");
const effectColor2 = Color.valueOf("FFFFFF");

const lengthseparater = 640;

const separaterLaser = extend(BasicBulletType,{
	laserColors: [Color.valueOf("81ACFF55"), effectColor, effectColor2],
	laserStrokes: [1,0.5,0.3],
	laserTscales: [2, 1.75, 1.4, 1],
	laserLenscales: [1, 1.125, 1.2, 1.25],
	laserLength: lengthseparater,
	strl: 5,
	lineLaser(b, baseLen, laserColors, laserStrokes, laserTscales, laserLenscales, ang, x, y){
		for(var s = 0; s < laserColors.length; s++){
			Draw.color(Color().set(laserColors[s]).mul(1 + Mathf.absin(Time.time(), 1, 0.1)));
			for(var i = 0; i < laserTscales.length; i++){
				Lines.stroke((this.strl + 1 + Mathf.absin(Time.time(), 0.8, 1)) * b.fout() * laserStrokes[s] * laserTscales[i]);
				Lines.lineAngle(x, y, ang, baseLen * laserLenscales[i]);
			};
		};
		const trnsLen = new Vec2();
		trnsLen.trns(ang, baseLen * laserLenscales[laserLenscales.length - 1]);
		Vars.renderer.lights.line(x, y, x + trnsLen.x, y + trnsLen.y);
		Draw.reset();
	},
	range(){
		return lengthseparater ;
	}, 
	update(b){   	
		const ang = b.rot();
		const len = this.range();
		if(b.timer.get(1, 4)){
			if(Mathf.chance(Time.delta() * 0.7)){
				Effects.effect(newEffect(22,e => {
					Draw.color(effectColor, effectColor2, e.fin() * 0.5);
					const d = new Floatc2({get(x, y){
						Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 10 + 4);
					}}) 
					Angles.randLenVectors(e.id, 3, 56 * e.fin(), e.rotation, 30,d);
				}), b.x, b.y, ang);
			}
			Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), len);
		}
	},
	draw(b){
		//const f = Mathf.curve(b.fin(), 0, 0.2);
		const baseLen = this.range();
		this.lineLaser(b, baseLen, this.laserColors, this.laserStrokes, this.laserTscales, this.laserLenscales, b.rot(), b.x, b.y);
		Draw.color(effectColor);
		const sin = (22 + Mathf.absin(Time.time(), 1, 9)) * b.fout();
		const width = b.fout() * 4.1; const length = b.fout() * 45;
		Drawf.tri(b.x, b.y, width * 1.1, length + sin, 180);
		Drawf.tri(b.x, b.y, width * 1.1, length + sin, 0);
		
		const tM = Time.time() * 1.5;
		
		Drawf.tri(b.x, b.y, width, length, 180  - tM);
		Drawf.tri(b.x, b.y, width, length, 0  	- tM);
		Drawf.tri(b.x, b.y, width, length, 90   + tM);
		Drawf.tri(b.x, b.y, width, length, 270 + tM);
		
		Fill.circle(b.x, b.y, b.fout() * this.strl * 1.3);
    	Draw.color(effectColor2);
		Fill.circle(b.x, b.y, b.fout() * this.strl * 1);
	}
})
separaterLaser.damage = 1200;
separaterLaser.speed = 0.000001;
separaterLaser.hitEffect = newEffect(45, e => {
    Draw.color(effectColor, effectColor2, 0.5 * e.fin());
	const c = new Floatc2({get(x, y){
		Fill.circle(e.x + x, e.y + y, e.fout() * 6);
	}}) 
    Angles.randLenVectors(e.id, 2, 40 * e.fin(), e.rotation, 360,c);
});
separaterLaser.despawnEffect = Fx.none;
separaterLaser.collidesTiles = false;
separaterLaser.pierce = true;
separaterLaser.hitSize = 250;
separaterLaser.drawSize = 250;
separaterLaser.bulletWidth = 60;
separaterLaser.lifetime = 45;
separaterLaser.keepVelocity = false;
separaterLaser.drawSize = lengthseparater * 2.5;
separaterLaser.shootEffect = Fx.none;
separaterLaser.smokeEffect = newEffect(30, e => {
    Draw.color(effectColor, effectColor2, 0.5 * e.fin());
	Lines.stroke(e.fout() * 2.25);
	Lines.circle(e.x, e.y, e.fin() * 45);
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 4.25);
    }}) 
    Angles.randLenVectors(e.id, 7, 2 + 64 * e.fin(), e.rotation, 360,c);
});

const shieldRange = 220;

const sepShield = extend(BasicBulletType,{
	update(b){
		
	},
	init(b){
		if(b == null)return;
		Effects.effect(newEffect(35,e => {
			Draw.color(effectColor);
			Lines.stroke(e.fout() * 4); 
			Lines.circle(e.x, e.y, shieldRange  * 0.525 + 75 * e.fin());
		}), effectColor, b.x, b.y, b.rot());
	},
	draw(b){
		Draw.color(effectColor);
		Lines.stroke(b.fout() * 2.7); 
		Lines.circle(b.x, b.y, (shieldRange * 0.525) * b.fout() * b.fout());
		Draw.alpha(b.fout() * b.fout() * 0.3);
		Fill.circle(b.x, b.y, (shieldRange * 0.525) * b.fout() * b.fout());
	}
});
sepShield.damage = 0;
sepShield.speed = 0;
sepShield.lifetime = 80;
sepShield.despawnEffect = Fx.none;
sepShield.drawSize = shieldRange * 1.5;




const separaterWeapon = extend(Weapon, {});
separaterWeapon.reload = 6000000;
separaterWeapon.bullet = separaterLaser;
separaterWeapon.recoil = 5;
separaterWeapon.length = 20;
separaterWeapon.width = 0;
separaterWeapon.name = "科技革命-separater-mainWeapon";
separaterWeapon.shots = 1;
separaterWeapon.shootSound = Sounds.laser;
separaterWeapon.inaccuracy = 0;
separaterWeapon.ejectEffect = Fx.shootBigSmoke2;
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
const totalReload = 60;
const duration = 270;
const shieldBrokenReload = 480;
const weaponYnd = -40;
const weaponSize = 47;
const shieldTotalHP = 25000;
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
const separater = extendContent(UnitType, "separater", {});

separater.create(prov(() => new JavaAdapter(HoverUnit, {
	bulletLife: 0,
	bulletCon: null,
	reload: 0,
	bulletRot: 0,
	searchT: 0,
	shots: 0,
	
	shieldReload: 0,
	shieldHP: shieldTotalHP,
	shield: null,
	getPowerCellRegion(){
		return Core.atlas.find("科技革命-separater-cell");
	},
	draw(){
		this.super$draw();
		
		const x = this.x; const y = this.y; const rotation = this.rotation; const type = this.type;
		
		Draw.color(effectColor);
		Draw.blend(Blending.additive);
		Draw.alpha(this.shots);
		Draw.rect(Core.atlas.find("科技革命-separater-heat"), x, y, rotation - 90);
		Draw.blend();
		Draw.reset();
		
		var wx = x + Angles.trnsx(rotation, weaponYnd);
		var wy = y + Angles.trnsy(rotation, weaponYnd);
		var xRec = wx + Angles.trnsx(this.bulletRot, -this.shots * 5);
		var yRec =  wy + Angles.trnsy(this.bulletRot, -this.shots * 5);
		
		Draw.mixcol(Color.white, this.hitTime / this.hitDuration);
		Draw.rect(Core.atlas.find("科技革命-separater-mainWeapon"), xRec, yRec, weaponSize, weaponSize, this.bulletRot - 90);
		Draw.mixcol();
		
		Draw.color(effectColor);
		Draw.blend(Blending.additive);
		Draw.alpha(this.shots);
		Draw.rect(Core.atlas.find("科技革命-separater-mainWeapon-heat"), xRec, yRec, weaponSize, weaponSize, this.bulletRot - 90);
		Draw.blend();
		Draw.reset();
	},
	damage(amount){
		if(!Vars.net.client()){
			this.super$damage(this.calculateDamage(amount * 0.3));
		}
		this.hitTime = this.hitDuration;
    },
	drawWeapons(){
		
	},
	drawEngine(){
		const x = this.x; const y = this.y; const rotation = this.rotation; const type = this.type;
		const sin = Mathf.absin(Time.time(), 4, type.engineSize / 6);
		Draw.color(effectColor);
		Fill.circle(x + Angles.trnsx(rotation + 180, type.engineOffset), y + Angles.trnsy(rotation + 180, type.engineOffset),type.engineSize + sin);

		Draw.color(Color.white);
		Fill.circle(x + Angles.trnsx(rotation + 180, type.engineOffset - 1), y + Angles.trnsy(rotation + 180, type.engineOffset - 1),
		(type.engineSize + sin) / 2);
		Draw.color();
	},
	
	drawLight(){
		Vars.renderer.lights.add(this.x, this.y, shieldRange, effectColor, 0.8);
	},
    
	update(){
		this.super$update();
		
		const x = this.x; const y = this.y; const rotation = this.rotation; const type = this.type; const lasertarget = Units.closestTarget(this.getTeam(), x, y, type.range);
		
		var wx = x + Angles.trnsx(rotation, weaponYnd);
		var wy = y + Angles.trnsy(rotation, weaponYnd);
		
		const fireDst = 29;
		const trnsLen = new Vec2();
		trnsLen.trns(this.bulletRot, fireDst);
			
		const reload = this.reload;
		
		if(lasertarget != null){
			this.searchT = 0;
			this.bulletRot = Angles.moveToward(this.bulletRot, Angles.angle(wx, wy, lasertarget.x, lasertarget.y), 1.7);
			if(reload <= totalReload && this.bulletLife <= 0){
				this.reload++;
			}
		}else{
			if(this.searchT >= 15){
				this.bulletRot = Angles.moveToward(this.bulletRot, rotation, 1.125);
			}else this.searchT += 1;
		}
		
		if(reload > totalReload){
			Effects.effect(separaterLaser.smokeEffect, wx + trnsLen.x, wy + trnsLen.y, this.bulletRot);
			Sounds.laserbig.at(this, Mathf.random(0.9, 1.1));
			this.reload = 0;
			this.bulletCon = Bullet.create(separaterLaser, this, this.getTeam(), x, y, rotation);
			this.bulletLife = duration;
		}
		
		if(this.bulletLife > 0 && this.bulletCon != null){
			Effects.shake(1, 1, this);
			this.shots = 1.1;
			this.bulletCon.rot(this.bulletRot);
			//Sounds.beam.at(this, Mathf.random(0.9, 1.1));
		
			this.bulletCon.set(wx + trnsLen.x, wy + trnsLen.y);
			this.bulletCon.time(0);
			this.bulletLife -= Time.delta();
		}else{
			this.shots = Mathf.lerpDelta(this.shots, 0, 0.02);
		}
		
		if(this.bulletLife <= 0){
			this.bulletCon = null;
			this.bulletRot = Angles.moveToward(this.bulletRot, rotation, 1.125);;
		}
		
		//shield:
		
		if(this.shield == null){
			this.shieldReload += 1;
		}
 
		if(this.shieldReload >= shieldBrokenReload){
			this.shieldReload = 0;
			this.shield = Bullet.create(sepShield, this, this.getTeam(), x, y, rotation);
			this.shieldHP = shieldTotalHP;
		}
		
		if(this.shieldHP >= 0 && this.shieldHP <= shieldTotalHP){
			this.shieldHP += 3;
		}
		
		if(this.shieldHP >= 0){
			Vars.bulletGroup.intersect(x - shieldRange, y - shieldRange, shieldRange * 2, shieldRange * 2, cons(trait =>{
				if(trait.canBeAbsorbed() && trait.getTeam() != this.getTeam() && Intersector.isInsideHexagon(trait.getX(), trait.getY(), shieldRange, x, y) ){
					this.shieldHP -= trait.getShieldDamage();
					trait.absorb();
					Effects.effect(newEffect(20, e => {
						Draw.color(effectColor);
						Lines.stroke(e.fout() * 2.5);
						Lines.circle(e.x, e.y, e.fout() * 8 + 20);
						const d = new Floatc2({get(x, y){
							Lines.circle(e.x + x, e.y + y, e.fout() * 14);
						}})
						Angles.randLenVectors(e.id, 3, 28 * e.fin(), 0, 360,d);
					}), trait);
				}
			}));
		}else if(this.shield != null){
			this.shield = null;
		}
		
		if(this.shield != null && this.shieldHP >= 0){
			this.shield.set(x, y);
			this.shield.time(0);
		}
		
		//selfRepair
		this.healBy((type.health / 600) * Time.delta());
	},
	init(type, team){
		this.super$init(type, team);
		this.shield = Bullet.create(sepShield, this, this.getTeam(), this.x, this.y, 0);
	}
})));
separater.maxVelocity = 1.27;
separater.weapon = separaterWeapon;
separater.hitsize = 8;
separater.mass = 10000;
separater.speed = 0.09;
separater.drag = 0.2;
separater.flying = true;
separater.hitsize = 100;
separater.shootCone = 30;
separater.health = 100000;
separater.rotateWeapon = false;
separater.mass = 90000;
separater.engineOffset = 63;
separater.engineSize = 21;
separater.rotatespeed = 0.009;
separater.baseRotateSpeed = 0.008;
separater.range = lengthseparater - 40;
separater.attackLength = lengthseparater - 80;







