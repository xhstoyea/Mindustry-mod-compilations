const item = Items.copper;
const newF = extendContent(Unloader, "newF", {
    update(tile){
        const entity = tile.ent();
            if(entity.cons.valid() && entity.sortItem != item && entity.items.total() <= this.itemCapacity && entity.sortItem != null){
                if(entity.timer.get(this.progress)){
                    entity.cons.trigger();
                    entity.items.add(entity.sortItem, 1);
                    
            }
        };
        if(entity.sortItem != null){
            if(entity.items.get(entity.sortItem)){
                this.tryDump(tile, entity.sortItem)
            }
        }
    }
});
newF.progress = 100;
newF.hasPower = true;
newF.requirements(Category.effect, ItemStack.with(Items.copper, 30));
newF.consumes.power(50);
newF.consumes.items(new ItemStack(item, 1))