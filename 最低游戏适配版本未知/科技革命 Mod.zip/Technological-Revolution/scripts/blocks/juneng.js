const juneng = extendContent(GenericCrafter,"juneng",{
    draw(tile){
        Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-rotator"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 3)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-rotator1"),tile.drawx(),tile.drawy(),0 - tile.ent().totalProgress * 3.5)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-rotator2"),tile.drawx(),tile.drawy(),0 - tile.ent().totalProgress * 2.50)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
     },
    generateIcons(){
        return [
            Core.atlas.find(this.name + "-bottom"),
            Core.atlas.find(this.name),
        ];
    }
});
     juneng.craftEffect = Fx.smeltsmoke;
     juneng.flameColor = Color.valueOf("64fdff");