const juneng = extendContent(GenericCrafter,"dagui",{
    draw(tile){
        Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-2"),tile.drawx(),tile.drawy(),0 - tile.ent().totalProgress * 5)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-1"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 15)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-3"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 4)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-4"),tile.drawx(),tile.drawy(),0 - tile.ent().totalProgress * 6)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
     },
    generateIcons(){
        return [
            Core.atlas.find(this.name + "-bottom"),
            Core.atlas.find(this.name),
        ];
    }
});
     juneng.craftEffect = Fx.smeltsmoke;
     juneng.flameColor = Color.valueOf("64fdff");