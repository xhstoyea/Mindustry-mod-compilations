const targetRange = 220;
const maxSpawn = 3;//最大控制数

const xlb = newEffect(22, e => {
    Draw.color(Color.valueOf("#DA00FF"));
    Lines.stroke(e.fout() * 2);
    Lines.circle(e.x, e.y, 4 + e.finpow() * 60);
});


const xl = extendContent(UnitFactory,"摄魂者", {
    update(tile){
        const entity = tile.ent();
        const target = Units.closestTarget(tile.getTeam(), tile.drawx(), tile.drawy(), targetRange, boolf((e) => {return !e.isDead()}));
        if(target!=null&&entity.spawned2 < maxSpawn){
            Units.nearby(target.getTeam(), target.getX(), target.getY(), 8, cons(unit => {
                if(unit.isBoss()) return;
                this.onUnitFactorySpawn(tile,entity.spawned2+1,unit);
                
            }));
        };
        
    },
    drawSelect(tile){
        const baseColor = Color.valueOf("C8E8FF");
        const len = 100;
        Draw.color(baseColor);
	    Lines.stroke(3);
		Drawf.dashCircle(tile.drawx(), tile.drawy(), targetRange, baseColor);
    },
onUnitFactorySpawn:function(tile,spawns,unit){
        const xlk = newEffect(1000, e => {
    Draw.color(Color.valueOf("DA00FF"));
    Lines.stroke(e.fout() * 2);
    Lines.circle(e.x, e.y, 2 + e.finpow() * 7);
});

        if(unit.getTeam() != tile.getTeam()){
            const entity = tile.ent();
	    const unitType = ContentType.unit;
		for(var i = 0;;i++){
		var units = Vars.content.getByID(unitType, i)
		var unitR = null;
		if(units == null){
			return;
		};
		if(units.typeID == unit.getTypeID()){
			unitR = units;
			var unitI = unitR.create(tile.getTeam());
			unitI.setSpawner(tile);
			unitI.set(unit.getX(), unit.getY());
            Effects.effect(xlk, unitI.x, unitI.y, 0, unitI);
            unitI.add();
            unitI.velocity().y = 0;
            
            const UnitCreateEvent = EventType.UnitCreateEvent;
            Events.fire(new UnitCreateEvent(unitI));
            
            entity.spawned2 = spawns;
            var health1 = unit.health();
            unit.onDeath();
            unitI.health(health1);
            
            
            return;
		    }else{
		        continue;
		    }
	    }
    }
    },
    unitRemoved(tile, unit){
        const entity = tile.ent();
        entity.spawned2--;
        entity.spawned2 = Math.max(entity.spawned2, 0);
    }
});
xl.health = 550;
xl.unitType = UnitTypes.draug;//这里随便填，不影响效果
xl.size = 2;
xl.entityType=prov(()=>extend(UnitFactory.UnitFactoryEntity,{
    getspawned2(){return this._spawned2},
    setspawned2(value){this._spawned2 = value},
  
    _spawned2:0,
    
    write(stream){
        this.super$write(stream);
        stream.writeInt(this._spawned2);
    },
    read(stream,revision){
        this.super$read(stream,revision);
        this._spawned2=stream.readInt();
    },
    
    }));
xl.consumes.power(5);
xl.localizedName = "摄魂者";
xl.description = "控制单位，但无法控制BOSS";
xl.requirements(Category.effect, ItemStack.with(Items.copper, 30))

