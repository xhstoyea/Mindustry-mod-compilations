//
const colors = [Color.valueOf("ffffff"), Color.valueOf("ffc74f"), Color.valueOf("ff7d49")];
//
const tscales = [0.25, 0.2525, 0.7125, 0.25];
//
const lenscales = [1, 1.1, 1.16, 1.2];
//
const length = 350;

const caig = extend(BasicBulletType,{
    range(){
        return length;
    },
    //mindustry.entities.type.Bullet
    // init(b){
    // },3
    update(b){
        if (b.time()<0.001) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), length);
        }
        print(b.time())
    },
    draw(b){
        const f = Mathf.curve(b.fin(), 0, 0.2);
        const baseLen = length * f;

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for(var s = 0; s < 3; s++){
            Draw.color(colors[s]);
            for(var i = 0; i < tscales.length; i++){
                Lines.stroke(7 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.3) * tscales[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscales[i]);
            }
        }
        Draw.reset();
    }
})
caig.damage = 200;
caig.speed = 0.0001;
caig.hitEffect = Fx.hitLancer;
caig.despawnEffect = Fx.none;
caig.hitSize = 4;
caig.lifetime = 40;
caig.pierce = true;

const cai = extendContent(ChargeTurret,"cai",{})

cai.shootType = caig;
