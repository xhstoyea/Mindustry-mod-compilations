const colors末 = [Pal.lancerLaser.cpy().mul(1, 1, 1, 0.4), Pal.lancerLaser, Color.valueOf("#0b88ee")];
//
const tscales末 = [1, 0.7, 0.5, 0.2];
//
const lenscales末 = [1, 1.1, 1.13, 1.14];
//
const length末 = 8000;

const 末日激光 = extend(BasicBulletType,{
    range(){
        return length末;
    },
    //mindustry.entities.type.Bullet
    // init(b){
    // },
    update(b){
        if (b.time()<0.001) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), length末);
        }
        print(b.time())
    },
    draw(b){
        const f = Mathf.curve(b.fin(), 0, 0.2);
        const baseLen = length末 * f;

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for(var s = 0; s < 3; s++){
            Draw.color(colors末[s]);
            for(var i = 0; i < tscales末.length; i++){
                Lines.stroke(7 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.3) * tscales末[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscales末[i]);
            }
        }
        Draw.reset();
    }
})
末日激光.damage = 1;
末日激光.speed = 0.001;
末日激光.hitEffect = Fx.lancerLaserCharge;
末日激光.despawnEffect = Fx.none;
末日激光.hitSize = 64;
末日激光.lifetime = 240;
末日激光.pierce = true

const newWeapon = extend(Weapon,{});
newWeapon.reload = 200;
newWeapon.ejectEffect = Fx.none;
newWeapon.shootSound = Sounds.explosion;
newWeapon.bullet = 末日激光

//const newUnit = new UnitType("newUnit");
const newUnit = extendContent(UnitType,"newUnit",{
});




newUnit.constructor = prov(()=>{const ret = extend(FlyingUnit,{
    radius:220,
    broken:true,
    buildup:0,
    radscl:0,
    breakage:500,
    hit:0,
    warmup:0,
    phaseHeat:0,
    shield2:null,
    shield:function(ret){const ret2 = extend(BaseEntity,{
        update(){
            const entity = ret;
            if(entity.isDead() || !entity.isAdded()){
                this.remove();
            }
        },
        drawSize(){
            const entity = ret;
            return realRadius(entity) * 2 + 2;
        },
        draw(){
            const entity = ret;
            Draw.color(Pal.accent);
            Fill.poly(this.x, this.y, 6, realRadius(entity));
            Draw.color();
        },
        drawOver(){
            const entity = ret;
            if(entity.hit <= 0) return;
            Draw.color(Color.white);
            Draw.alpha(entity.hit);
            Fill.poly(this.x, this.y, 6, realRadius(entity));
            Draw.color();
        },
        drawSimple(){
            const entity = ret;
            if(realRadius(entity) < 0.5) return;
            var rad = realRadius(entity);
            Draw.color(Pal.accent);
            Lines.stroke(1.5);
            Draw.alpha(0.09 + 0.08 * entity.hit);
            Fill.poly(this.x, this.y, 6, rad);
            Draw.alpha(1);
            Lines.poly(this.x, this.y, 6, rad);
            Draw.reset();
        },
        targetGroup(){
            return Vars.shieldGroup;
        },
        create(x, y){
            const entity = ret;
            this.set(x, y);
            return this;
        },
        add(){
            if(this.targetGroup() != null){
                this.targetGroup().add(this);
            }
        }
    })
        return ret2;
    },
    write(stream){
        this.super$write(stream);
        stream.writeBoolean(this.broken);
        stream.writeFloat(this.buildup);
        stream.writeFloat(this.radscl);
        stream.writeFloat(this.warmup);
        stream.writeFloat(this.phaseHeat);
    },
    read(stream, revision){
        this.super$read(stream, revision);
        this.broken = stream.readBoolean();
        this.buildup = stream.readFloat();
        this.radscl = stream.readFloat();
        this.warmup = stream.readFloat();
        this.phaseHeat = stream.readFloat();
    },
    update(){
        this.super$update();
        if(this.shield2 == null){
            this.shield2 = this.shield(this).create(this.getX(), this.getY());
            this.shield2.add();
        };
        if(this.getX()!=this.shield2.getX()||this.getY()!=this.shield2.getY()){
            this.shield2.set(this.getX(), this.getY());
        };
        this.radscl = Mathf.lerpDelta(this.radscl, this.broken ? 0 : this.warmup, 0.05);
        this.warmup = Mathf.lerpDelta(this.warmup, 1, 0.1);
        if(this.buildup > 0){
            this.buildup -= Time.delta();
        };
        if(this.broken && this.buildup <= 0){
            this.broken = false;
        };
        if(this.buildup >= this.breakage && !this.broken){
            this.broken = true;
            this.buildup = this.breakage;
        };
        if(this.hit > 0){
            this.hit -= 1 / 5 * Time.delta();
        };
        var realRadius = (this.radius + this.phaseHeat) * this.radscl;
        Vars.bulletGroup.intersect(this.getX() - realRadius, this.getY() - realRadius, realRadius*2, realRadius * 2, cons(trait =>{
            if(trait.canBeAbsorbed() && trait.getTeam() != this.getTeam() && Intersector.isInsideHexagon(trait.getX(), trait.getY(), realRadius, this.getX(), this.getY())){
            trait.absorb();
            Effects.effect(Fx.absorb, trait);
            this.hit = 1;
            this.buildup += trait.getShieldDamage() * this.warmup;
            }
        }));
    },
    drawSimple(){
        this.super$drawLight();
        Draw.color(Pal.accent);
        Lines.stroke(1);
        Lines.poly(this.getX() * Vars.tilesize, this.getY() * Vars.tilesize, 6, this.radius);
        Draw.color();
    }
})
    return ret;
});

newUnit.maxVelocity = 1.27;
newUnit.speed = 0.285;
newUnit.drag = 0.4;
newUnit.weapon = newWeapon;
newUnit.hitsize = 8;
newUnit.mass = 1.75;
newUnit.health = 1E8

function realRadius(obj){
    return (obj.radius + obj.phaseHeat) * obj.radscl;
}


