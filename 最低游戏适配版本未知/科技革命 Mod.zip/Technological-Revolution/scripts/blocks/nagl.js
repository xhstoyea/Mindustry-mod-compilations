const nag = extendContent(GenericCrafter,"nag",{
    draw(tile){
        Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-z1"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 3)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-z"),tile.drawx(),tile.drawy(),0 - tile.ent().totalProgress * 2)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
     },
    generateIcons(){
        return [
            Core.atlas.find(this.name + "-bottom"),
            Core.atlas.find(this.name),
        ];
    }
});
nag.craftEffect = Fx.smeltsmoke;
nag.flameColor = Color.valueOf("64fdff");