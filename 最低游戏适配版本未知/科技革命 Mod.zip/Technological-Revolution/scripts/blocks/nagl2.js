const siloLaunchEffect2 = newEffect(20, e => 
    {
    Draw.color(Color.valueOf("3377ff"), Color.valueOf("3399ff"), e.fin());
    Lines.stroke(e.fout() * 4); //厚度从3到0
    Lines.circle(e.x, e.y, e.fin() * 35); //画一个从0到100的圆
});

const nag2 = extendContent(GenericCrafter,"nag2",{
    draw(tile){
        Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-z1"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 3)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-z"),tile.drawx(),tile.drawy(),0 - tile.ent().totalProgress * 1)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
     },
    generateIcons(){
        return [
            Core.atlas.find(this.name + "-bottom"),
            Core.atlas.find(this.name),
        ];
    }
});
nag2.craftEffect = siloLaunchEffect2;
nag2.flameColor = Color.valueOf("64fdff");