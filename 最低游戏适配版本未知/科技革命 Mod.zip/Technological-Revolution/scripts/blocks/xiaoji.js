//
const colors = [Pal.lancerLaser.cpy().mul(1, 1, 1, 0.4), Pal.lancerLaser, Color.white];
//激光粗细
const tscales = [1, 0.7, 0.5, 0.2];
//
const lenscales = [1, 1.1, 1.13, 1.14];
//
const length = 260;

const longlaser = extend(BasicBulletType,{
    range(){
        return length;
    },
    update(b){
        if (b.time()<0.001) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), length);
        }
        print(b.time())
    },
draw(b){
        const f = Mathf.curve(b.fin(), 0, 0.2);
        const baseLen = length * f;

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for(var s = 0; s < 3; s++){
            Draw.color(colors[s]);
            for(var i = 0; i < tscales.length; i++){
                Lines.stroke(7 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.3) * tscales[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscales[i]);
            }
        }
        Draw.reset();
    } 
})
longlaser.shootEffect = newEffect(23, e => {
    Draw.color(Color.valueOf("a7d7fd"), Color.valueOf("ffffff"), e.fin());
    Lines.stroke(e.fout() * 6);
});

longlaser.damage = 60;
longlaser.speed = 0.001;
longlaser.hitEffect = Fx.hitLancer;
longlaser.despawnEffect = Fx.none;
longlaser.hitSize = 4;
longlaser.lifetime = 30;
longlaser.pierce = true;

const heavylaserturret = extendContent(ChargeTurret,"xiaoji",{})
heavylaserturret.shootType = longlaser;