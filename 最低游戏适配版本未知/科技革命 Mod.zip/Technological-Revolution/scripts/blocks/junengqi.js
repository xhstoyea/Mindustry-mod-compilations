const junengqi = extendContent(SolarGenerator,"junengqi",{
    draw(tile){
        Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-1"),tile.drawx(),tile.drawy(),0 + Time.time * 3)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-2"),tile.drawx(),tile.drawy(),0 - Time.time * 3.5)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-3"),tile.drawx(),tile.drawy(),0 - Time.time * 2.50)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-4"),tile.drawx(),tile.drawy(),0 - Time.time * 2.50)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
     },
    generateIcons(){
        return [
            Core.atlas.find(this.name + "-bottom"),
            Core.atlas.find(this.name),
        ];
    }
});
