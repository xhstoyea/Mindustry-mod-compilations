const NAMIQD = extendContent(Wall,"NAMIQD",{
    draw(tile){
        this.super$draw(tile)
        tile.entity.healBy(0.0005 * tile.entity.maxHealth());}
});
	NAMIQD.health = 3000,
    NAMIQD.size = 2;
