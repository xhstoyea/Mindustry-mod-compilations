//this is NOT the complete definition for this block! see content/blocks/scatter-silo.hjson for the stats and other properties.

//创建简单冲击波效果
const jxfLaunchEffect = newEffect(20, e => {
    Draw.color(Color.cyan, Color.lightGray, e.fin()); //颜色从青色变为浅白色
    Lines.stroke(e.fout() * 3); //厚度从3到0
    Lines.circle(e.x, e.y, e.fin() * 10); //画一个从0到100的圆
});

//创建类型
const silo = extendContent(Block, "jxf", {
    //重写方法以生成配置
})

