const ho = newEffect(180,e =>{
    const d = new Floatc2({get(x,y){
        Draw.color(Color.valueOf("#FFFFFF"), Color.valueOf("#FF00FF"), e.fin());
        Lines.stroke(e.fslope() * 2);
        Lines.circle(e.x, e.y, e.fin() * 8); 
    }})
            Angles.randLenVectors(e.id, 10, 50 * e.fslope(),e.rotation, 360,d)
});