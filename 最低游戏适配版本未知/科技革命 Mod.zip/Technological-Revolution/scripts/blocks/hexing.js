const juneng = extendContent(CoreBlock,"hexing",{
    draw(tile){
        Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-1"),tile.drawx(),tile.drawy(),0 - Time.time()* 3.5)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();

     },
    generateIcons(){
        return [
            Core.atlas.find(this.name + "-bottom"),
            Core.atlas.find(this.name),
        ];
    }
});