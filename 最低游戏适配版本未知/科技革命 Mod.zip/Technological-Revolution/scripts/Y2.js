
const siloLaunchEffect = newEffect(20, e => {
    Draw.color(Color.valueOf("#9400D3"), Color.valueOf("#F0F8FF"), e.fin());
    Lines.stroke(e.fout() * 3); //厚度从3到0
    Lines.circle(e.x, e.y, e.fin() * 30); //画一个从0到100的圆
});

const siloLaunchEffect2 = newEffect(20, e => {
    Draw.color(Color.valueOf("#9400D3"), Color.valueOf("#F0F8FF"), e.fin());
    Lines.stroke(e.fout() * 4); //厚度从3到0
    Lines.circle(e.x, e.y, e.fin() * 20); //画一个从0到100的圆
});

const spawns = [ 
    [UnitTypes.crawler,UnitTypes.fortress],
    [UnitTypes.crawler,UnitTypes.titan,UnitTypes.crawler,UnitTypes.titan,UnitTypes.crawler,UnitTypes.titan],
];
const waveL = extendContent(Block, "Y1", {
    
    update(tile){
        if(tile.ent().timer.get(this.delay)){
            try{
                spawns[tile.ent().wave].forEach(spawn => {
                    var unit = spawn.create(tile.getTeam());
                    const spread = 40;
                    unit.set(tile.drawx() + Mathf.range(spread), tile.drawy() + Mathf.range(spread));
                    Time.run(50, run(() =>{
                        Effects.effect(siloLaunchEffect, unit.x, unit.y, 0, unit);
                        Time.run(30, run(() => {
                            unit.add();
                            Effects.effect(siloLaunchEffect2, unit);
                        }));
                    }));
                    tile.ent().wave++;
                })
            }catch(e){
                tile.ent().kill();
            }
        }
    },
    canBreak(tile){
        return false;
    },
});
waveL.delay = 225;
waveL.update = true;
waveL.entityType = prov(()=>extend(TileEntity,{
    getwave(){return this._wave},
    setwave(value){this._wave = value},
    _wave:0,
    write(stream){
        this.super$write(stream);
        stream.writeInt(this._wave);
    },
    read(stream,revision){
        this.super$read(stream,revision);
        this._wave=stream.readInt();
    },
}));
waveL.requirements(Category.units, BuildVisibility.shown, ItemStack.with());