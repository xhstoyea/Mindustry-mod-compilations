const item = Nanocore;
const Nanobuilder = extendContent(Unloader, "Nanobuilder", {
    update(tile){
        const entity = tile.ent();
            if(entity.cons.valid() && entity.sortItem != item && entity.items.total() <= this.itemCapacity && entity.sortItem != null){
                if(entity.timer.get(this.progress)){
                    entity.cons.trigger();
                    entity.items.add(entity.sortItem, 1);
                    
            }
        };
        if(entity.sortItem != null){
            if(entity.items.get(entity.sortItem)){
                this.tryDump(tile, entity.sortItem)
            }
        }
    }
});
Nanobuilder.size = 3;
Nanobuilder.progress = 140;
Nanobuilder.hasPower = true;
Nanobuilder.requirements(Category.effect, ItemStack.with(Nanocore, 50));
Nanobuilder.consumes.power(60);
Nanobuilder.consumes.items(new ItemStack(item, 1))