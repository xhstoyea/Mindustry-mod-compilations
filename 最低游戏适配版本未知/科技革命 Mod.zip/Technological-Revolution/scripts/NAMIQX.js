const NAMIQX = extendContent(DeflectorWall,"NAMIQX",{
    draw(tile){
        this.super$draw(tile)
        tile.entity.healBy(0.0003 * tile.entity.maxHealth());}
});
	NAMIQX.health = 1250,
    NAMIQX.size = 1;
