const siloLaunchEffect2 = newEffect(20, e => 
    {
    Draw.color(Color.valueOf("33ff36"), Color.valueOf("a4ffb3"), e.fin());
    Lines.stroke(e.fout() * 3); //厚度从3到0
    Lines.circle(e.x, e.y, e.fin() * 13); //画一个从0到100的圆
});
const juneng = extendContent(GenericCrafter,"LG1",{
    draw(tile){
        Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-1"),tile.drawx(),tile.drawy(),0 + tile.ent().totalProgress * 3)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color();
     },
    generateIcons(){
        return [
            Core.atlas.find(this.name + "-bottom"),
            Core.atlas.find(this.name),
        ];
    }
});
     juneng.craftEffect = siloLaunchEffect2;
     juneng.flameColor = Color.valueOf("33ff36");