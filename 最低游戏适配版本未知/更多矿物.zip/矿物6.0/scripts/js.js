const RemovableCore=extendContent(CoreBlock,"Removable-Core",{
    canBreak(tile){
        return true
    }
})