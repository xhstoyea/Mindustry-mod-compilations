# Mindustry Green

*Changed name from mindustry plus

A mod that brings new items, buildings weapon amunition and more into the game!

Designed and created by BurritoAlpaca and Arkanic on github.com

Please note:
This mod is not intergrated into the campaign and is only meant for sandbox style games.
The support for this mod has dissappeared and has gone into other projects that I am working on. Sorry for this unfinished mod.
Hope you enjoy!
