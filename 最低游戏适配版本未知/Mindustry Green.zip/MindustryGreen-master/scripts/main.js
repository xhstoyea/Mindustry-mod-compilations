if(typeOf(require) !== "undefined"){
    require("blocks/scatter-silo");
}
