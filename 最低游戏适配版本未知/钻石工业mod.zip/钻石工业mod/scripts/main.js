if(typeof(require) !== "undefined"){
	require("blocks/激光狙击炮台");
    require("blocks/分裂炮");
}
 