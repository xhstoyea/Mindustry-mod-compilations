
const 小tmpColor = Color();
const 小colors = [Color.valueOf("#FF0033"), Color.valueOf("#CC0033"), Color.valueOf("#DDF0FF"), Color.valueOf("ffffff")];
const 小tscales = [1,0.8,0.5,0.2];
const 小strokes = [1,0.5,0.3];
const 小lenscales = [1.0125,1.02,1.025,1.0275];
const 小length = 380;
const 小 = extend(BasicBulletType,{
    update(b) {
        if (b.timer.get(1, 9)) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), 小length, true);
        }
        Effects.shake(1, 1, b.x, b.y);
    },
    hit(b, hitx, hity) {
        Effects.effect(this.hitEffect, 小colors[2], hitx, hity);
        if (Mathf.chance(0.4)) {
            Fire.create(Vars.world.tileWorld(hitx + Mathf.range(5), hity + Mathf.range(5)));
        }
    },
    draw(b) {
        const baseLen = (小length) * b.fout();

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for (var s = 0; s < 小colors.length; s++) {
            Draw.color(小tmpColor.set(小colors[s]).mul(1 + Mathf.absin(Time.time(), 1, 0.1)));
            for (var i = 0; i < 小tscales.length; i++) {
                Lines.stroke((9 + Mathf.absin(Time.time(), 0.8, 1.5)) * b.fout() * 小strokes[s] * 小tscales[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * 小lenscales[i]);
            }
        }
        Draw.reset();
    }
})
小.damage = 200;
小.hitSize = 1;
小.drawSize = 420;
小.lifetime = 16;
小.pierce = true;

小.despawnEffect = Fx.none;
小.hitEffect = newEffect(25, e => {
    Draw.color(Color.valueOf("#FFF98C"));
    Fill.circle(e.x, e.y, e.fout() * 5);
    Draw.color(Color.valueOf("#FFF98C"),Color.valueOf("#ffffff"),e.fin());
    Fill.circle(e.x, e.y, e.fout() * 2.725);
    Draw.color(Color.valueOf("#FFF98C"));
});

const 激光炮 = extendContent(LaserTurret,"激光炮",{})
激光炮.shootType = 小