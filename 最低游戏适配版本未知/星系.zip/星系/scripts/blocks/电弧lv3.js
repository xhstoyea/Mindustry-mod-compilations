const annolaserhit = newEffect(25,e => {
	
})
const annolasershoot = newEffect(25,e => {

    
    
})

const 小tmpColor = Color();
const 小colors = [Color.valueOf("#A6D2FF55"), Color.valueOf("#B3DBFF"), Color.valueOf("#DDF0FF"), Color.valueOf("ffffff")];
const 小tscales = [1,0.8,0.5,0.2];
const 小strokes = [1,0.5,0.3];
const 小lenscales = [1.0125,1.02,1.025,1.0275];
const 小length = 380;
const 小 = extend(BasicBulletType,{
update(b){
  if(Mathf.chance(Time.delta() * 0.02)){
        	Lightning.create(b.getTeam(),Color.valueOf("A0CCFF"), 75, b.x , b.y , b.rot(), Mathf.random(65, 90)); 
}
}
})
小.damage = 170;
小.speed = 0.0001;
小.hitEffect = newEffect(55, e => {
    Draw.color(Color.valueOf("#FFF98C"));
    Fill.circle(e.x, e.y, e.fout() * 5);
    Draw.color(Color.valueOf("#FFF98C"),Color.valueOf("#ffffff"),e.fin());
    Fill.circle(e.x, e.y, e.fout() * 2.725);
});

小.despawnEffect = Fx.none;
小.hitSize = 250;
小.drawSize = 250;
小.bulletWidth = 15;
小.lifetime = 60;
小.pierce = true;
小.shootEffect = newEffect(60, e => {
Draw.color(Color.valueOf("#FFF98C"));
    Fill.circle(e.x, e.y, e.fout() * 5);
    Draw.color(Color.valueOf("#FFF98C"),Color.valueOf("#ffffff"),e.fin());
    Fill.circle(e.x, e.y, e.fout() * 2.725);
    Draw.color(Color.valueOf("#FFF98C"));
});

const 电弧lv3 = extendContent(DoubleTurret,"电弧lv3",{})
电弧lv3.ammo(Items.surgealloy,小)