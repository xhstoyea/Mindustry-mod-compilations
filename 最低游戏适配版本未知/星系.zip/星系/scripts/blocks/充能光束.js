const colors小 = [Color.valueOf("7b68ee55"), 
//激光颜色
Color.valueOf("	#BA55D3"), Color.valueOf("#0000CD")];

const tscales小 = [2, 1.5, 1, 0.825];
const lenscales小 = [1, 1.25, 1.4, 1.45];
const length小 = 350;
const 小 = extend(BasicBulletType,{
    range(){
        return length小;
    },
    update(b){
        if (b.time()<0.001) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), length小);
        }
        print(b.time())
    },
    draw(b){
        const f = Mathf.curve(b.fin(), 0, 0.2);
        const baseLen = length小 * f;

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for(var s = 0; s < 3; s++){
            Draw.color(colors小[s]);
            for(var i = 0; i < tscales小.length; i++){
                Lines.stroke(7 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.25) * tscales小[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscales小[i]);
            }
        }
        Draw.reset();
    }
})
小.damage = 10;
小.speed = 0.0001;
小.hitEffect = newEffect(55, e => {
   // 颜色从黄到红渐变 
Draw.color(Color.yellow, Color.red, e.fin()); 
// 厚度从 4到 0
 Lines.stroke(e.fout() * 4); 
// 渲染一个圆，半径 10 到 0 
Lines.circle(e.x, e.y, e.fout() * 10); });

小.despawnEffect = Fx.none;
小.hitSize = 250;
小.drawSize = 250;
小.bulletWidth = 15;
小.lifetime = 60;
小.pierce = true;
小.shootEffect = newEffect(60, e => {
// 颜色从白到灰渐变 
Draw.color(Color.white, Color.lightGray, e.fin()); 
// 厚度从 3 到 0
 Lines.stroke(e.fout() * 3); 
// 渲染一个圆，半径 0 到 30 
Lines.circle(e.x, e.y, e.fin() * 30); });


const 充能光束 = extendContent(ChargeTurret,"充能光束",{})
充能光束.shootType = 小
充能光束.chargeBeginEffect = newEffect(80, e => {
//随机特效
   // 颜色从紫到蓝渐变 
Draw.color(Color.purple, Color.blue, e.fin()); 
// 厚度从 4到 0
 Lines.stroke(e.fout() * 4); 
// 渲染一个圆，半径 10 到 0 
Lines.circle(e.x, e.y, e.fout() * 10); });

充能光束.chargeEffect = newEffect(80, e => {
 // 颜色从黄到红渐变 
Draw.color(Color.yellow, Color.red, e.fin()); 
// 厚度从 4到 0
 Lines.stroke(e.fout() * 4); 
// 渲染一个圆，半径 10 到 0 
Lines.circle(e.x, e.y, e.fout() * 10); });