if(typeof(require) !== "undefined"){ 
	require("blocks/充能光束");
    require("blocks/电弧lv2");
    require("blocks/电弧lv3");
    require("blocks/激光炮");
}
 

