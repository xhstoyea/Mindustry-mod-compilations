if(typeof(require) !== "undefined"){
    require("blocks/蒸汽涡轮反应堆");
    }
