if(typeof(require) !== "undefined"){ // Work on 103 too
	require("blocks/虚空能工厂");
	require("blocks/虚空炮");
	require("blocks/裂变");
}
 