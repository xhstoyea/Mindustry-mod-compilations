
//----虚极姬射器的子弹
// var a = global.硬糖
// print(a)
const 虚colors = [Color.valueOf("ec745855"), Color.valueOf("ff9c5a"), Color.white];
const 虚tscales = [1, 0.7, 0.5, 0.2];
const 虚lenscales = [1, 1.1, 1.13, 1.14];
const 虚length = 310;

const 虚极激光 = extend(BasicBulletType, {
    range() {
        return 虚length;
    },
    // init(b){
    // },
    update(b) {
        if (b.time() < 0.001) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), 虚length);
        }
    },
    draw(b) {
        const f = Mathf.curve(b.fin(), 0, 0.2);
        const baseLen = 虚length * f;

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for (var s = 0; s < 3; s++) {
            Draw.color(虚colors[s]);
            for (var i = 0; i < 虚tscales.length; i++) {
                Lines.stroke(7 * 2 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.3) * 虚tscales[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * 虚lenscales[i]);
            }
        }
        Draw.reset();
    }
})
虚极激光.hitEffect = newEffect(20, e => {
    Draw.color(Color.valueOf("ffa264"), Color.valueOf("ffa264"), e.fin());

    Lines.stroke(e.fout() * 4);
    const d = new Floatc2({
        get(x, y) {
            Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1.5);
        }
    })
    Angles.randLenVectors(e.id, 8, 1 + 80 * e.fin(), e.rotation, 50, d);

    Lines.stroke(e.fout() * 3 + 0.5);
    Lines.circle(e.x, e.y, e.fin() * 30);

    Fill.circle(e.x, e.y, e.fout() * 20);
    Fill.circle(e.x, e.y, e.fout() * 8);

});
虚极激光.shootEffect = newEffect(30, e => {
    Draw.color(Color.valueOf("ffa264"), Color.valueOf("ffa264"), e.fin());

    Fill.circle(e.x, e.y, e.fout() * 15);
    Draw.color();
    Fill.circle(e.x, e.y, e.fout() * 10);

});
虚极激光.smokeEffect = newEffect(55, e => {

    const d = new Floatc2({
        get(x, y) {
            Draw.color(Color.valueOf("ffa264"), Color.valueOf("ffa264"), e.fin());
            Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3, 60);
        }
    })

    Angles.randLenVectors(e.id, 15, 10 + e.fin() * 20, d);


});

虚极激光.damage = 800;
虚极激光.speed = 0.001;
虚极激光.despawnEffect = Fx.none;
虚极激光.hitSize = 4;
虚极激光.lifetime = 30;
虚极激光.pierce = true

const 虚空炮 = extendContent(ChargeTurret, "虚空炮", {
})
虚空炮.shootType = 虚极激光
虚空炮.chargeBeginEffect = newEffect(45, e => {
    //蓄力效果                   颜色
    Draw.color(Color.valueOf("ffa264"));
    Fill.circle(e.x, e.y, e.fin() * 15);
    Draw.color();
    Fill.circle(e.x, e.y, e.fin() * 10);

    Draw.color(Color.valueOf("ffa264"));
    Lines.stroke(e.fin() * 5 + 0.01);
    Lines.circle(e.x, e.y, e.fout() * 60);

})
虚空炮.chargeEffect = newEffect(40, e => {
    Draw.color(Color.valueOf("ffa264"), Color.valueOf("ffa264"), e.fin());

    //用于用于控制所有效果粗细
    Lines.stroke(e.fin() * 6.9);

    const d = new Floatc2({
        get(x, y) {
            Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 10 + 1);
        }
    })
    Angles.randLenVectors(e.id, 13, 1 + 120 * e.fout(), e.rotation, 110, d);

});

//==============================================================