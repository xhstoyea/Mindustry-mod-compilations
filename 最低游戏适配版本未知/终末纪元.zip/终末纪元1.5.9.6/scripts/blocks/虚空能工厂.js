

const 虚空能工厂 = extendContent(GenericSmelter,"虚空能工厂",{
    draw(tile){
        Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
        Draw.color(tile.entity.liquids.current().color);
        Draw.alpha(tile.entity.liquids.total() / this.liquidCapacity);
        Draw.rect(Core.atlas.find(this.name + "-liquid"), tile.drawx(), tile.drawy());
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-rotator"),tile.drawx(),tile.drawy(),20 + tile.ent().totalProgress * 1.25)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color(Color.valueOf("ffef9966"),tile.ent().warmup);
        Draw.rect(Core.atlas.find(this.name+"-top"),tile.drawx(), tile.drawy());
        Fill.circle(tile.drawx(), tile.drawy(), 3.95 + Mathf.absin(Time.time(), 4, 1.35) + Mathf.random(0.075));
        Draw.color(Color.valueOf("ffffff"),tile.ent().warmup);
        Fill.circle(tile.drawx(), tile.drawy(), 2.425 + Mathf.absin(Time.time(), 4, 0.95) + Mathf.random(0.05));
        Draw.color();
    },
    generateIcons(){
        return [
            Core.atlas.find(this.name + "-bottom"),
            Core.atlas.find(this.name),
        ];
    }
});
虚空能工厂.craftEffect = Fx.smeltsmoke;
虚空能工厂.flameColor = Color.valueOf("ffef99");