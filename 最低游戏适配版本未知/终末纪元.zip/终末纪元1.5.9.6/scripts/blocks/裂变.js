const 追踪尾迹 = newEffect(25,e => {
	Draw.color(Color.valueOf("#ffd280"),Color.valueOf("#ffd280"),e.fin());
                const d = new Floatc2({get(x, y){
                	Lines.stroke(e.fout() * 2.725);
        Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 8 + 50);
    }}) 
    Angles.randLenVectors(e.id, 1, 1 + 0 * e.fin(),e.rotation, 0,d);
        });
        
const 裂变追踪弹 = extend(MissileBulletType,{
update(b){
        if(b.timer.get(1,1)){
            Effects.effect(追踪尾迹,Color.valueOf("ffd28000"), b.x, b.y, b.rot());
        }
        }
        })
裂变追踪弹.speed = 3,
裂变追踪弹.bulletWidth = 10,
裂变追踪弹.bulletHeight = 20,
裂变追踪弹.damage = 100
裂变追踪弹.hitEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("ffd280"),Color.valueOf("ffd280"),e.fin());
	Lines.stroke(e.fout() * 1.125);
    Lines.circle(e.x, e.y, e.fin() * 37);
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 8);
    }}) 
    Angles.randLenVectors(e.id, 5, 1 + 40 * e.fin(), e.rotation, 360,c);
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 12, 1 + 40 * e.fin(), e.rotation, 100,d);
        });

const 裂变子弹 = extend(BasicBulletType,{
draw(b){
       Draw.color(Color.valueOf("ffd280"));
       Fill.circle(b.x, b.y, 7);
       Draw.color(Color.valueOf("ffffff"));
       Fill.circle(b.x, b.y, 3.725);
       
        },
 update(b){
         if(b.timer.get(1,4)){
             for(var i = 0; i < 3; i++){
				Bullet.create(裂变追踪弹,b,b.x,b.y,Mathf.random(360),1);
				}
				}
				},
			});
			
裂变子弹.speed = 0,
裂变子弹.damage = 0,
裂变子弹.knockback = 0.2,
裂变子弹.splashDamageRadius = 40,
裂变子弹.splashDamage = 750,
裂变子弹.bulletWidth = 18,
裂变子弹.bulletHeight = 18,
裂变子弹.drag = 0,
裂变子弹.collidesTiles = false,
裂变子弹.hitTiles = false;
裂变子弹.pierce = true,
裂变子弹.hitSize = 0,
裂变子弹.collides = false,
裂变子弹.collidesAir = false,
裂变子弹.lifetime = 120
       
const 尾迹裂变母弹 = newEffect(25,e => {
	Draw.color(Color.valueOf("#ffd280"));
    Fill.circle(e.x, e.y, e.fout() * 4);
    Draw.color(Color.valueOf("#ffffff"));
    Fill.circle(e.x, e.y, e.fout() * 2.25);
        });
        
const 裂变母弹 = extend(BasicBulletType,{
	draw(b){
       Draw.color(Color.valueOf("ffd280"));
       Fill.circle(b.x, b.y, 7);
       Draw.color(Color.valueOf("ffffff"));
       Fill.circle(b.x, b.y, 3.725);
      
        },
update(b){
                if(b.timer.get(12)){
            Effects.effect(尾迹裂变母弹,Color.valueOf("C2FF8300"), b.x, b.y, b.rot());
        }
                },
})
裂变母弹.speed = 1,
裂变母弹.damage = 0,
裂变母弹.knockback = 0.2,
裂变母弹.splashDamageRadius = 40,
裂变母弹.splashDamage = 750,
裂变母弹.bulletWidth = 18,
裂变母弹.bulletHeight = 18,
裂变母弹.drag = 0,
裂变母弹.collidesTiles = false,
裂变母弹.hitTiles = false;
裂变母弹.pierce = true,
裂变母弹.hitSize = 0,
裂变母弹.collides = false,
裂变母弹.collidesAir = false,
裂变母弹.lifetime = 120
裂变母弹.fragBullets = 1,
裂变母弹.fragBullet = 裂变子弹,
裂变母弹.frag = 0;

const 该死的 = extendContent(BurstTurret,"该死的",{})
该死的.ammo(Items.surgealloy,裂变母弹)