const 尾迹裂变母弹 = newEffect(25,e => {
	Draw.color(Color.valueOf("#ffd280"));
    Fill.circle(e.x, e.y, e.fout() * 4);
    Draw.color(Color.valueOf("#ffffff"));
    Fill.circle(e.x, e.y, e.fout() * 2.25);
        });
        
const 裂变母弹 = extend(BasicBulletType,{
	draw(b){
       Draw.color(Color.valueOf("ffd280"));
       Fill.circle(b.x, b.y, 7);
       Draw.color(Color.valueOf("ffffff"));
       Fill.circle(b.x, b.y, 3.725);
      
        },
update(b){
                if(b.timer.get(1,2)){
            Effects.effect(尾迹裂变母弹,Color.valueOf("C2FF8300"), b.x, b.y, b.rot());
        }
                },
})
裂变母弹.speed = 3,
裂变母弹.pierce = false,
裂变母弹.damage = 5.25,
裂变母弹.knockback = 0,
裂变母弹.bulletWidth = 8,
裂变母弹.bulletHeight = 8,
裂变母弹.fragBullets = 1,
裂变母弹.fragBullet = 裂变子弹,
裂变母弹.frag = 0

裂变母弹.smokeEffect = newEffect(25,e => {
	const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("abdbff"),Color.valueOf("f0f8ff"),e.fin());
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
        });
        
裂变母弹.lifetime = 120,
裂变母弹.despawnEffect = Fx.flakExplosion
//-----------------------------------------
const 裂变追踪弹 = extend(MissileBulletType,{})
裂变追踪弹.speed = 3,
裂变追踪弹.pierce = false,
裂变追踪弹.bulletWidth = 5,
裂变追踪弹.bulletHeight = 10,
//------------------------------------------
const 裂变子弹 = extend(BasicBulletType,{
update(b){
      		if(Mathf.chance(Time.delta() * 0.075)){
				Bullet.create(裂变追踪弹b,b.x,b.y,Mathf.random(360),1);
			}
	despawned(b){
        Effects.effect(this.despawnEffect, b.x, b.y, b.rot());
        for(var i = 0; i < 12; i++){  
        	Bullet.create(裂变追踪弹,b,b.x,b.y,Mathf.random(360),1);
	        }
        }
        }
       });
裂变子弹.speed = 0,
裂变子弹.pierce = true,
裂变子弹.bulletWidth = 10,
裂变子弹.bulletHeight = 10,
裂变子弹.lifetime = 200
//-----------------------------------------
const 裂变 = extendContent(DoubleTurret,"裂变",{})
裂变.ammo(Items.thorium,裂变母弹)
