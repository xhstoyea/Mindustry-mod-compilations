var M=0
var dh=false

function addM(tile,item,m)
{
   if(tile.entity.items.get(item)>=1)
     {
       tile.entity.items.remove(item,1)
       M+=m;
     }
}

function additems(c,tile,item,m)
{
if(M>=m)
  {
  M-=m;
  tile.entity.items.add(item,1)
  c.tryDump(tile,item)
  addM(tile,item,m)
  }
}
function toast(text, lifetime){
	if(Vars.ui !== null){
		Vars.ui.showInfoToast(text, lifetime);
	}
}

var items=[
{item:Vars.content.getByName(ContentType.item,"copper"),M:2},
{item:Vars.content.getByName(ContentType.item,"lead"),M:2},
{item:Vars.content.getByName(ContentType.item,"titanium"),M:10},
{item:Vars.content.getByName(ContentType.item,"metaglass"),M:30},
{item:Vars.content.getByName(ContentType.item,"thorium"),M:30},
{item:Vars.content.getByName(ContentType.item,"pyratite"),M:50},
{item:Vars.content.getByName(ContentType.item,"silicon"),M:34},
{item:Vars.content.getByName(ContentType.item,"graphite"),M:36},
{item:Vars.content.getByName(ContentType.item,"phase-fabric"),M:302},
{item:Vars.content.getByName(ContentType.item,"coal"),M:4},
{item:Vars.content.getByName(ContentType.item,"sand"),M:2},
{item:Vars.content.getByName(ContentType.item,"scrap"),M:4},
{item:Vars.content.getByName(ContentType.item,"surge-alloy"),M:400},
{item:Vars.content.getByName(ContentType.item,"spore-pod"),M:28},
{item:Vars.content.getByName(ContentType.item,"plastanium"),M:210},
{item:Vars.content.getByName(ContentType.item,"blast-compound"),M:104}
]//感谢blac8大佬提供的代码
const 点数监视器 = extendContent(Block, "点数监视器", {
    update(tile){
    toast("点数:"+M, 0.02)
     }
})


const 转换炉 = extendContent(Block, "转换炉", {
    update(tile){
   for(var i = 0; i < items.length; i++){
  addM(tile,items[i].item,items[i].M/2)
  }
  }
})


const 复原炉 = extendContent(Block, "复原炉", {
    update(tile){
   for(var i = 0; i < items.length; i++){
  additems(this,tile,items[i].item,items[i].M)
  }
  }
  
})


//我感觉这几串代码应该能优化不少，有优化方案的可以联系我QQ2091541371(小号)