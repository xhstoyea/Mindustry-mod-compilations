![Logo](sprites/BBM_logo.png)

# Better-Blocks-Mod
This mod adds more blocks , materials and enemies (I'll add enemies soon) (OH NO)

# Translators
- [MemFaceGo](https://github.com/MemFaceGo) (Russian - Owner)
- [LonelyYmomfe](https://github.com/ymomfe) (Ukrainian)
- Makc - Carbon (Ukrainian)
- NoName (Korean)

## Update v1.4
- Added 2 New Conveyors
- Added Super Overdrive Projector
- Added Teleport (from Mindustry Classic)
- Revamped Batteries
- Fixed Block Boost

![Logo](sprites/Screenshot_586.png)

## Update v1.3
- Added 14 new blocks
- Added 3 New items
- Added new liquid
- Some Fixes

![Logo](sprites/Screenshot_562.png)
