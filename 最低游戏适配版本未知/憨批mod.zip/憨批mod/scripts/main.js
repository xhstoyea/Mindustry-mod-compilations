	require("blocks/effect/抽奖");
	require("blocks/effect/手摇发电机");