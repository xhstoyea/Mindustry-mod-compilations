var $_$$$_$ = {
	items:{
		getAll:function(){
			var Items=Vars.content.items().toArray();
			var jg=[];
			for(var k in Items){
				jg.push(Items[k]);
			}
			return jg;
		}
	},
	whileArray:function(Ithis,code){
		for(var k in code){
			eval('Ithis.'+code[k]+';');
		}
		return Ithis;
	},
	whileObject:function(Ithis,code){
		for(var k in code){
			Ithis[k]=code[k];
		}
		return Ithis;
	}
};

var jsq=0;
const 抽奖机=extendContent(GenericCrafter,'抽奖机',{
	update:function(tile){
		const entity=tile.ent();
		//var jg=[];
		//this.description=entity.cons+'\n\n'+this.consumes;
		var items=$_$$$_$.items.getAll();
		var jg=[];
		for(var k in items){
			jg.push("ItemStack(items["+k+"],1)");
		}
		this.description='输入任何物品,输出任何物品\n支持接受'+items
		eval('this.consumes.items('+jg.join()+')');
		if(entity.items.total()){
			entity.items.take();
			this.offloadNear(tile, items[jsq%items.length]);
		}
		jsq+=1
	}
})

var items=$_$$$_$.items.getAll();
var jg=[];
for(var k in items){
	jg.push("ItemStack(items["+k+"],1)");
}

$_$$$_$.whileArray($_$$$_$.whileObject(抽奖机,{
	localizedName:"抽奖机",
	description:"输入任何物品,输出任何物品",
	itemCapacity:25,
	update:true
}),[
	'consumes.power(6)',
	'requirements(Category.power,ItemStack.with(Items.copper,200,Items.lead,200,Items.titanium,200,Items.thorium,200,Items.silicon,1000));',
	'consumes.items('+jg.join()+')'
]);
