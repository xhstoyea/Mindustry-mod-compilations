const _11=extendContent(SingleTypeGenerator,'_11',{
	update:function(tile){
		const entity=tile.ent();
		if(entity.productionEfficiency<=0.01){
			entity.productionEfficiency=0;
			return
		};
		if(entity.productionEfficiency>=6){
			entity.productionEfficiency-=1;
		}else if(entity.productionEfficiency>=5){
			entity.productionEfficiency-=0.5;
		}else if(entity.productionEfficiency>=4){
			entity.productionEfficiency-=0.16;
		}else if(entity.productionEfficiency>=3){
			entity.productionEfficiency-=0.06;
		}else if(entity.productionEfficiency>=2){
			entity.productionEfficiency-=0.02;
		}else if(entity.productionEfficiency>=0){
			entity.productionEfficiency-=0.01;
		}
	},
	buildConfiguration:function(tile,table){
		const entity=tile.ent();
		table.addButton('$ok',run(() => {
			if(entity.productionEfficiency<=7) entity.productionEfficiency+=0.05;
			if(entity.productionEfficienc>7) entity.productionEfficiency=7;
		})).size(60,60);
		if(entity.productionEfficiency>=7) table.row(),table.add('已达最大输出')
	}
})

_11.update=_11.configurable=true;
_11.requirements(Category.power,ItemStack.with(
	Items.copper,100,
	Items.lead,70
));
_11.localizedName='་手摇发电机';
_11.description='手摇发电机!!!';
_11.powerProduction=1;