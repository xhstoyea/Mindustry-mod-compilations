//真就全部改一遍才能用啊
//特效你用extendContent?
const 核辐射 = extend(StatusEffect, {});
核辐射.damage = 10;
核辐射.damageMultiplier = 0.8;
核辐射.armorMultiplier = 0.8;
核辐射.speedMultiplier = 0.8;
核辐射.effect = newEffect(25, e => {
    const d = new Floatc2({
        get(x, y) {
            Draw.color(Color.valueOf("6b8e23"));
            Fill.square(e.x + x, e.y + y, 0.1 + e.fout() * 1, 45);
        }
    })
    Angles.randLenVectors(e.id, 3, 1 + e.fin() * 1, d);
});
核辐射.color = Color.valueOf("6b8e23")

const EMP = extend(StatusEffect,{});
EMP.damage = 0;
EMP.damageMultiplier = 0;
EMP.armorMultiplier = 1;
EMP.speedMultiplier = 0;
EMP.effect = newEffect(25, e => {
    const d = new Floatc2({
        get(x, y) {
            Draw.color(Color.valueOf("1e90ff"));
            Fill.square(e.x + x, e.y + y, 0.1 + e.fout() * 1, 45);
        }
    })
    Angles.randLenVectors(e.id, 3, 1 + e.fin() * 1, d);
});
EMP.color = Color.valueOf("1e90ff")

const 停滞 = extend(StatusEffect,{});
停滞.damage = 0;
停滞.damageMultiplier = 1;
停滞.armorMultiplier = 1;
停滞.speedMultiplier = 0;
停滞.effect = newEffect(25, e => {
    const d = new Floatc2({
        get(x, y) {
            Draw.color(Color.valueOf("ee3b3b"));
            Fill.square(e.x + x, e.y + y, 0.1 + e.fout() * 1, 45);
        }
    })
    Angles.randLenVectors(e.id, 3, 1 + e.fin() * 1, d);
});
停滞.color = Color.valueOf("ee3b3b")

const 等离子网 = extend(StatusEffect,{});
等离子网.damage = 0;
等离子网.damageMultiplier = 1;
等离子网.armorMultiplier = 1;
等离子网.speedMultiplier = 0.7;
等离子网.effect = newEffect(25, e => {
    const d = new Floatc2({
        get(x, y) {
            Draw.color(Color.valueOf("EE3B3B"));
            Fill.square(e.x + x, e.y + y, 0.1 + e.fout() * 1, 45);
        }
    })
    Angles.randLenVectors(e.id, 3, 1 + e.fin() * 1, d);
});
等离子网.color = Color.valueOf("EE3B3B")