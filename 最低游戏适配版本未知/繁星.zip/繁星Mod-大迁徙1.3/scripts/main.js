
require("block/改进型冷冻液混合器");
require("block/迷你核弹发射器")
require("block/等离子网投射器")
//我给你注释了。。因为你这俩出了类问题
//下是类详细错误
/**
 *  WrappedException: Wrapped java.lang.NoSuchMethodException: <init> [interface org.mozilla.javascript.Scriptable, class org.mozilla.javascript.ContextFactory] (global.js#16)
 * 出现这个代表接口溢出或者没有这个接口啥的。反正我不知道，没办法改，建议重写
 * 
*/