const 核辐射 = extend(StatusEffect, {});
核辐射.damage = 10;
核辐射.damageMultiplier = 0.8;
核辐射.armorMultiplier = 0.8;
核辐射.speedMultiplier = 0.8;
核辐射.effect = newEffect(25, e => {
    const d = new Floatc2({
        get(x, y) {
            Draw.color(Color.valueOf("6b8e23"));
            Fill.square(e.x + x, e.y + y, 0.1 + e.fout() * 1, 45);
        }
    })
    Angles.randLenVectors(e.id, 3, 1 + e.fin() * 1, d);
});
核辐射.color = Color.valueOf("6b8e23")

require("Effects");
const 迷你核弹1 = extend(MissileBulletType,{});

迷你核弹1.damage = 2500,//伤害
迷你核弹1.splashDamage = 10000,
迷你核弹1.splashDamageRadius = 120,
迷你核弹1.lifetime = 600,//子弹存在时间
迷你核弹1.speed = 3,//子弹速度
迷你核弹1.bulletWidth = 60,//子弹宽
迷你核弹1.bulletHeight = 60,//子弹长
迷你核弹1.bulletShrink = 0,//子弹缩小率
迷你核弹1.drag = 0,//子弹减速每帧
迷你核弹1.hitEffect = Fx.explosion,//使用内建特效需要加上Fx.  这里none表示无特效
迷你核弹1.despawnEffect = Fx.none,
迷你核弹1.smokeEffect = Fx.none,
迷你核弹1.trailEffect = Fx.none,
迷你核弹1.knockback = 0,//命中怪物，怪物减速
迷你核弹1.hitTiles = false,
迷你核弹1.collidesTiles = true,
迷你核弹1.collidesTeam = false,
迷你核弹1.collidesAir = true,
迷你核弹1.collides = true;
迷你核弹1.status = 核辐射
迷你核弹1.statusDuration = 600
const 迷你核弹发射器 = extendContent(ItemTurret,"迷你核弹发射器",{});//这里的要写你json的炮塔名字两个都是里面这的ChargeTurret是炮塔种类
迷你核弹发射器.ammo = 迷你核弹1;//这里写上面自定义子弹的名字能量武器用shootType物品炮用ammmo
//37到48都是炮塔的定义不是子弹！！1到36是子弹定义