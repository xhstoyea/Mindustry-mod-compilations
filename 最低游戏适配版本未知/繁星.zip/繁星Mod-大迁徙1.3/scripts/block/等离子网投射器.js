const 等离子网 = extend(StatusEffect,{});
等离子网.damage = 0;
等离子网.damageMultiplier = 1;
等离子网.armorMultiplier = 1;
等离子网.speedMultiplier = 0.7;
等离子网.effect = newEffect(25, e => {
    const d = new Floatc2({
        get(x, y) {
            Draw.color(Color.valueOf("EE3B3B"));
            Fill.square(e.x + x, e.y + y, 0.1 + e.fout() * 1, 45);
        }
    })
    Angles.randLenVectors(e.id, 3, 1 + e.fin() * 1, d);
});
等离子网.color = Color.valueOf("EE3B3B")

require("Effects");
//请不要写"-"符号，因为在编程语言中"-"有自己的意思
//js从上到下读，请先写要读的
const 展开等离子网 = extend(BasicBulletType,{});
展开等离子网.damage = 30,//伤害
展开等离子网.lifetime = 1200,//子弹存在时间
展开等离子网.speed = 0.001,//子弹速度
展开等离子网.bulletWidth = 80,//子弹宽
展开等离子网.bulletHeight = 80,//子弹长
展开等离子网.bulletShrink = 0,//子弹缩小率
展开等离子网.drag = 0,//子弹减速每帧
展开等离子网.hitEffect = Fx.none,//使用内建特效需要加上Fx.  这里none表示无特效
展开等离子网.despawnEffect = Fx.none,
展开等离子网.smokeEffect = Fx.none,
展开等离子网.trailEffect = Fx.none,
展开等离子网.knockback = 0,//命中怪物，怪物减速
展开等离子网.hitTiles = false,
展开等离子网.collidesTiles = false,
展开等离子网.collidesTeam = false,
展开等离子网.collidesAir = true,
展开等离子网.collides = true,
展开等离子网.status = 等离子网,
展开等离子网.statusDuration = 1
const 未展开等离子网= extend(BasicBulletType,{});

未展开等离子网.damage = 1,//伤害
未展开等离子网.lifetime = 120,//子弹存在时间
未展开等离子网.speed = 3,//子弹速度
未展开等离子网.bulletWidth = 8,//子弹宽
未展开等离子网.bulletHeight = 8,//子弹长
未展开等离子网.bulletShrink = 0,//子弹缩小率
未展开等离子网.drag = 0,//子弹减速每帧
未展开等离子网.hitEffect = Fx.none,//使用内建特效需要加上Fx.  这里none表示无特效
未展开等离子网.despawnEffect = Fx.none,
未展开等离子网.smokeEffect = Fx.none,
未展开等离子网.trailEffect = Fx.none,
未展开等离子网.knockback = 0,//命中怪物，怪物减速
未展开等离子网.hitTiles = false,
未展开等离子网.collidesTiles = false,
未展开等离子网.collidesTeam = false,
未展开等离子网.collidesAir = true,
未展开等离子网.collides = true;
未展开等离子网.status = 等离子网,
未展开等离子网.statusDuration = 1,
未展开等离子网.fragBullets = 1,
未展开等离子网.fragBullet = 展开等离子网
const 等离子网投射器 = extendContent(ItemTurret,"等离子网投射器",{});//这里的要写你json的炮塔名字两个都是里面这的ChargeTurret是炮塔种类
等离子网投射器.shootType = 未展开等离子网;//这里写上面自定义子弹的名字能量武器用shootType物品炮用ammmo
//37到48都是炮塔的定义不是子弹！！1到36是子弹定义


//说实话，你这个js确实水，除了效果无其他自建特效