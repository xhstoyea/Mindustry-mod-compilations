const 改进型冷冻液混合器 = extendContent(GenericSmelter,"改进型冷冻液混合器",{
	//update(tile){
		//if(Mathf.equal(tile.ent().warmup, 1, 1)){ 
        //        Effects.shake(1,1,tile)
       //         Effects.effect(Fx.smeltsmoke,tile);
      //      Lightning.create(Team.derelict,Color.valueOf("#ADDFFF"), 0, tile.drawx(), tile.drawy(),Mathf.random(360), 5);         
         // }
		
    draw(tile){
        Draw.rect(this.region,tile.drawx(),tile.drawy());
        Draw.rect(Core.atlas.find(this.name),tile.drawx(),tile.drawy());
        Draw.color(tile.entity.liquids.current().color);
        Draw.alpha(tile.entity.liquids.total() / this.liquidCapacity);
        Draw.rect(Core.atlas.find(this.name + "-liquid"), tile.drawx(), tile.drawy());
        Draw.color()
    },
    generateIcons(){
        return [
            Core.atlas.find(this.name + "-bottom"),
            Core.atlas.find(this.name),
        ];
    }
});
改进型冷冻液混合器.craftEffect = Fx.smeltsmoke
