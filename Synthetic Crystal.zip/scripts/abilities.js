const AllYearFieldAbility = (radius, regen, max, cooldown, sides, rotation) => { 
	var realrotation = rotation
	var alpha = 1
	var radscl = 0
	var ability = new JavaAdapter(Ability, {
		localized(){
			return Core.bundle.format('ability.合晶工业-allyearfield', radius / 8, regen * 60, max, cooldown / 60, sides)
		},
		update(unit){
			if(realrotation >= 361 && !Vars.state.isPaused()){
				realrotation = realrotation > 720 ? 361 : realrotation + 1
			}
			alpha = Math.max(alpha - Time.delta / 10, 0)
			if(unit.shield < max){
				unit.shield += Time.delta * regen
			}
			if(unit.shield > 0){
				radscl = Mathf.lerpDelta(radscl, 1, 0.06)
				Groups.bullet.intersect(unit.x - radscl * radius, unit.y - radscl * radius, radscl * radius * 2, radscl * radius * 2, cons(bullet => {
					if(bullet.team != unit.team  && Intersector.isInRegularPolygon(sides, unit.x, unit.y, radscl * radius, realrotation, bullet.x, bullet.y) && unit.shield > 0){
						var collision = true
						Fx.absorb.at(bullet)
						if(collision){
							bullet.absorb()
						}
						if(unit.shield <= bullet.damage){
							unit.shield -= cooldown * regen
							Fx.shieldBreak.at(unit.x, unit.y, radius, unit.team.color, unit)
							Sounds.spark.at(unit, Mathf.random(0.9, 1.1))
					
						}
						unit.shield -= bullet.damage
						alpha = 1
					}
				}))
			}else{
				radscl = 0
			}	
		},
		draw(unit){
			if(unit.shield > 0){
				Draw.z(Layer.shields)
				Draw.color(unit.team.color, Color.white, Mathf.clamp(alpha))
				if(Core.settings.getBool('animatedshields')){
					Fill.poly(unit.x, unit.y, sides, radscl * radius, realrotation)
				}else{
					Lines.stroke(1.5)
					Draw.alpha(0.09)
					Fill.poly(unit.x, unit.y, sides, radius, realrotation)
					Draw.alpha(1)
					Lines.poly(unit.x, unit.y, sides, radius, realrotation)
				}
			}
		},
		displayBars(unit, bars){
			bars.add(new Bar(Core.bundle.format("stat.shieldhealth"), Pal.accent, () => unit.shield / max)).row()
		},
		copy(){
			return AllYearFieldAbility(radius, regen, max, cooldown, sides, rotation)
		}
	})
	return ability
}
exports.AllYearFieldAbility = AllYearFieldAbility

