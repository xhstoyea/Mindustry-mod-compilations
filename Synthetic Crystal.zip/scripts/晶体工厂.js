const library = require("library");
const myitems = require("物品");
const 晶体工厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "晶体工厂", [
  {
    input: {
      items: ["合晶工业-铝/7","合晶工业-碳单质/5"],     
      liquids: ["slag/6"],
     power: 2.5,
    },
    output: {
      items: ["合晶工业-粗硅晶/6"],
    },
    craftTime: 80,
  }, 
  {
    input: {
      items: ["合晶工业-铝/10","合晶工业-碳单质/6"],     
      liquids: ["slag/6"],
      power: 3,
    },
    output: {
      items: ["合晶工业-纯硅晶/5"],
    },
    craftTime: 100,
  },  
])
晶体工厂.update = true
晶体工厂.category = Category.crafting;
晶体工厂.buildVisibility = BuildVisibility.shown;