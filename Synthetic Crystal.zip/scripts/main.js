Vars.renderer.minZoom = 0.1;
Vars.renderer.maxZoom = 50;
Vars.maxSchematicSize = 256;
require('地板')
//require('mod引用')
require('开屏菜单')
require('核心');
require("星球");
require('第三科技'),
require('炮/炮'),
require('工厂'),
require('单位');
require('单位工厂');
require('物品');
// require('质量流动器');
require('uu');
require('Attribute');
require('ui');
require('drills');
require('发电机');
require('辅助建筑');
require('mapTechTree');//科技树 
require('核心1');
//require('核心2');
require('fbs');
require("排序/运输")
require("晶体工厂")
require("次世代合晶工厂")
require('buff')
//________________________下面时海兹尔的
require('排序/排序(炮)')
require('排序/排序(其他)')
require('排序/排序(墙)')
require('排序/排序(钻头)')
require('排序/排序(电)')
require('排序/排序(单位)')
require('排序/排序(物流)')
require('排序/排序(逻辑)')
require('排序/排序(水)')
require('排序/排序(工厂)')
require('建筑修复塔')
require('海兹尔')
require('海科技树')
require('海地图')

 

 