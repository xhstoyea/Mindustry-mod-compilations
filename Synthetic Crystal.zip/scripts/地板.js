exports.沙 = (() => {
    const v = extend(Floor, "沙", {});//污沙
    //v.itemDrop = Items.sand;
   // v.playerUnmineable = true;
    v.variants = 3;
    v.attributes.set(Attribute.water, -0.3,);
    v.attributes.set(Attribute.oil, 0.7);
    return v;
})();
