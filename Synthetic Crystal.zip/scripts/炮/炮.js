const lib = require('lib')
const 物品 = require('物品')
const 单管炮 = new ItemTurret('单管炮');
exports.单管炮 = 单管炮;

const 震天 = new ItemTurret('震天');
exports.震天 = 震天;

const 震天ll型 = new ItemTurret('震天ll型');
exports.震天ll型 = 震天ll型;



const 集束 = new PowerTurret('集束');
exports.集束 = 集束;

const 突进 = new ItemTurret('突进');
exports.突进 = 突进;

const 突进ll型 = new ItemTurret('突进ll型');
exports.突进ll型 = 突进ll型;

const 涓涓 = new LiquidTurret('涓涓');
exports.涓涓 = 涓涓;

const 突围 = new ItemTurret('突围');
exports.突围 = 突围;

const 奇瑟炮 = new PowerTurret('奇瑟炮');
exports.奇瑟炮 = 奇瑟炮;



const 陨星 = new PowerTurret('陨星');
exports.陨星 = 陨星;

const 重击 = new ItemTurret('重击');
exports.重击 = 重击;

const 灾灭 = new ItemTurret('灾灭');
exports.灾灭 = 灾灭;

const 天景 = new ItemTurret('天景');
exports.天景 = 天景;
const 穿越 = extend(ItemTurret, "穿越", {});
exports.穿越 = 穿越;

const a = extend(BasicBulletType,{});
a.lifetime = 33;
a.speed = 5;
a.damage = 21;
a.width = 10;
a.height = 16;
a.shrinkY = 0;
a.drag = -0.01;
a.homingPower = 0.08;
a.reloadMultiplier = 1.2;
a.despawnEffect = lib.scFx.bigbluedown;
a.hitEffect = lib.scFx.bigbluedown;
exports.bigbluedown = lib.scFx.bigbluedown;
const 天道1 = extend(ItemTurret, "天道1", {});
天道1.ammo(
    物品.锆, a
);
exports.天道1 = 天道1;
