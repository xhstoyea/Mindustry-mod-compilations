//xvx神魂
//本代码可以塞在任意方块里
//比如墙又或者传送带，又或者核心
//只要这个方块可以刷新，就可以塞并且有效果

//感谢神魂（来自年年有鱼）
const 多管炮 = extend(ItemTurret, "穿越", {});



const myitems = require("物品");


const 核心 = extend(CoreBlock, "合晶核心l", {
	canReplace(other) {
		return true;
	}
	});


核心.buildVisibility = BuildVisibility.shown;
核心.category = Category.logic;

//这是必需的
核心.update = true;
//设置方块可使用物品
核心.hasItems = true;

//设置可使用的弹药
const TItems = [myitems.固态能]

核心.buildType = prov(() => {
	//创建多炮塔
	//(方块，队伍(不需要设置))
	const payloads = [
		new BuildPayload(多管炮, Team.derelict),
		new BuildPayload(多管炮, Team.derelict),
		new BuildPayload(多管炮, Team.derelict),				
		new BuildPayload(多管炮, Team.derelict),

					
	];
	const build = extend(CoreBlock.CoreBuild, 核心, {
		updateTile() {
			this.super$updateTile();


			//设置模块
		
			for(var id = 0; id < payloads.length; id++){
				//设置队伍，如果在上面的创建位置设置，无用
                if(payloads[id].build.team != this.team){
                    payloads[id].build.team = this.team;
                }
				
				//执行炮塔更新
                payloads[id].update(null, this);

				//为物品炮塔添加弹药
				//你们需要可自己定义
				for(var i = 0; i < TItems.length; i++){
					if(payloads[id].build.acceptItem(payloads[id].build, TItems[i]) && this.items.get(TItems[i]) >= 1) {
						payloads[id].build.handleItem(payloads[id].build, TItems[i]);
						this.items.remove(TItems[i], 1);
					}
				}
            }

			//设置炮塔的位置
			//有需求你们可以自己定义
			//（x, y, r）
			payloads[0].set(this.x + 14, this.y + 14, payloads[0].build.payloadRotation);
			payloads[1].set(this.x + 14, this.y - 14, payloads[1].build.payloadRotation);
			payloads[2].set(this.x - 14, this.y - 14, payloads[2].build.payloadRotation);
			payloads[3].set(this.x - 14, this.y + 14, payloads[3].build.payloadRotation);
	;
	
				
		
					
		},
		draw(){
			this.super$draw();

			//执行多炮塔的动画
			for(var i = 0; i < payloads.length; i++){
                payloads[i].draw();
            }
		},
	});

	return build;
});