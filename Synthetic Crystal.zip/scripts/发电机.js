const rtg = new ConsumeGenerator("RTG发电机")

rtg.consume(new ConsumeItemRadioactive())
//RTG型输入

const rtg1 = new ConsumeGenerator("大型RTG发电机")

rtg1.consume(new ConsumeItemRadioactive())
//RTG型输入
