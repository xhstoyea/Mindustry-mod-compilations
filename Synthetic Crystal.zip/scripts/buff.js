function newStatusEffect(name) {
	exports[name] = extend(StatusEffect, name, {});
}
newStatusEffect('短路')
newStatusEffect('离子灼烧')
newStatusEffect('暴雪装甲')
newStatusEffect('烈性燃烧')
newStatusEffect('沉重')
newStatusEffect('缴械')
newStatusEffect('嗜血')
newStatusEffect('一级武装')
newStatusEffect('极致')