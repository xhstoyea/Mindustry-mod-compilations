const 一级基站 = new CoreBlock('一级基站');
exports.一级基站 = 一级基站;
const 机动仓库 = new StorageBlock('机动仓库');
const 容差卸载器 = new Unloader('容差卸载器');
const 单位扩容装置 = new Wall('单位扩容装置');
/*const 机动核心 = extend(CoreBlock, "机动核心", {    canBreak() { return Vars.state.teams.cores(Vars.player.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
	canPlaceOn(tile, team) {
		return Vars.state.teams.cores(team).size < 15;
	},
});
//机动核心.coreMerge = false;
exports.机动核心 = 机动核心;*/