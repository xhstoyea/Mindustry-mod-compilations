const 锆采集工厂 = new UnitFactory('锆采集工厂');
const 钙采集工厂 = new UnitFactory('钙采集工厂');
const 黄玉采集工厂 = new UnitFactory('黄玉采集工厂');
const 挖墙机 = new BeamDrill('挖墙机');
const 硬质钻头 = new Drill('硬质钻头');