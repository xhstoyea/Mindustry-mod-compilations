const 降临 = new ItemTurret('降临');
const 波动 = new ItemTurret('波动');
const 焰火 = new LiquidTurret('焰火');
//const 禁空 = new ItemTurret('禁空');
const 洛普斯 = new ItemTurret('洛普斯');


