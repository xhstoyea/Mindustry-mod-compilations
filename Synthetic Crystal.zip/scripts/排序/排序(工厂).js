const 凝胶提取器 = new GenericCrafter('凝胶提取器');
const 植物碳化机 = new GenericCrafter('植物碳化机');
const 托尔曼锻造工厂 = new GenericCrafter('托尔曼锻造工厂');
