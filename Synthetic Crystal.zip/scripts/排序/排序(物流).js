const 锆传送带 = new StackConveyor('锆传送带');

const 黄玉传送带 = new Conveyor('黄玉传送带');

const 锆连接器 = extend(Junction, "锆连接器", {});
exports.锆连接器 = 锆连接器;

const 锆路由器 = extend(Router, "锆路由器", {});
exports.锆路由器 = 锆路由器;

//const 锆传送带桥 = extend(ItemBridge, "锆传送带桥", {});

const 锆传送带桥 = extend(ItemBridge, "锆传送带桥", {});
exports.锆传送带桥 = 锆传送带桥;

const 锆分类器 = extend(Sorter, "锆分类器", {});
exports.锆分类器 = 锆分类器;

const 锆反向分类器 = extend(Sorter, "锆反向分类器", {});
exports.锆反向分类器 = 锆反向分类器;

const 锆溢流门 = extend(OverflowGate, "锆溢流门", {});
exports.锆溢流门 = 锆溢流门;

const 锆反向溢流门 = extend(OverflowGate, "锆反向溢流门", {});
exports.锆反向溢流门 = 锆反向溢流门; 