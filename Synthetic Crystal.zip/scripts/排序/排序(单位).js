const 运输机制造机 = new UnitFactory('运输机制造机');
const 建造机装配工厂 = new UnitAssembler('建造机装配工厂');
const 小型载荷传送带 = new PayloadConveyor('小型载荷传送带')
const 小型载荷路由器 = new PayloadRouter('小型载荷路由器')