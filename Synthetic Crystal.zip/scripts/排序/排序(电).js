const 初级能量节点 = new PowerNode('初级能量节点')
const 酒精发电机 = new ConsumeGenerator('酒精发电机');
const 木炭发电机 = new ConsumeGenerator('木炭发电机');
