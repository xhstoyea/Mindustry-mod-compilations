const 锆墙 = new Wall('锆墙');
const 大型锆墙 = new Wall('大型锆墙');
const 黄玉墙 = new Wall('黄玉墙');
const 大型黄玉墙 = new Wall('大型黄玉墙');