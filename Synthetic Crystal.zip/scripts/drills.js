const 铝钻头 = extend(Drill, "铝钻头", {});
exports.铝钻头 = 铝钻头;
铝钻头.category = Category.logic;

const 硅晶钻头 = extend(Drill, "硅晶钻头", {});
exports.硅晶钻头 = 硅晶钻头;
硅晶钻头.category = Category.logic;


const 硅晶钻头ll型 = extend(Drill, "硅晶钻头ll型", {});
exports.硅晶钻头ll型 = 硅晶钻头ll型;
硅晶钻头ll型.category = Category.logic;

const 金钢钻头 = extend(Drill, "金钢钻头", {});
exports.金钢钻头 = 金钢钻头;
金钢钻头.category = Category.logic;

const 初代合晶钻头 = extend(Drill, "初代合晶钻头", {});
exports.初代合晶钻头 = 初代合晶钻头;
初代合晶钻头.category = Category.logic;

const 次代合晶钻头 = extend(Drill, "次代合晶钻头", {});
exports.次代合晶钻头 = 次代合晶钻头;
次代合晶钻头.category = Category.logic;

const 凝能钻头 = extend(Drill, "凝能钻头", {});
exports.凝能钻头 = 凝能钻头;
凝能钻头.category = Category.logic;

const 抽水机 = extend(SolidPump, "抽水机", {});
exports.抽水机 = 抽水机;
抽水机.category = Category.logic;

const 机械抽水机 = extend(SolidPump, "机械抽水机", {});
exports.机械抽水机 = 机械抽水机;
机械抽水机.category = Category.logic;

const 大型抽水机 = extend(SolidPump, "大型抽水机", {});
exports.大型抽水机 = 大型抽水机;
大型抽水机.category = Category.logic;

const 石油平台 = extend(Fracker, "石油平台", {});
exports.石油平台 = 石油平台;
石油平台.category = Category.logic;

const 能量流体收集器 = extend(SolidPump, "能量流体收集器", {});
exports.能量流体收集器 = 能量流体收集器;
能量流体收集器.category = Category.logic;