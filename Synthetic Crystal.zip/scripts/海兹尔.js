//此代码来自无限宇宙
const {铝,锂,碳单质,粗硅晶,锡,纯硅晶,废晶,废渣,铝钢,塑胶,金,铀,赤金,金辉合金,固态能,初代合晶,次代合晶,超代合晶,凝能晶}=require('物品')
const lib = require("lib");
const {一级基站} = require('排序/排序(其他)');
const 海兹尔 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(海兹尔, 7));
        this.super$load();
    }
}, "海兹尔", Planets.sun, 1);

const c1 = Color.valueOf("B7E092FF"), c2 = Color.valueOf("5898F0FF"), c3 = Color.valueOf("5898F0FF");
const sS = require("sectorSize");
sS.planetGrid(海兹尔, 3.6);

海兹尔.generator = extend(SerpuloPlanetGenerator,{
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgYmBiZmDJS8xNZeB5sqPh+a7lT+fver56JgN3SmpxclFmQUlmfh4DAwNbTmJSak4xA0f0swU7nu5vjmVkkHw6oePZzG1Pty99smOWLopmBgZGBggAAIqBKJE=");
	},
	allowLanding (sector) {
		return false
	},
    getColor(position) {
        var depth = Simplex.noise3d(4, 4, 0.56, 1.7, position.x, position.y, position.z) / 2;
        return c1.write(c3).lerp(c2, Mathf.clamp(Mathf.round(depth, 0.25)));
    },
});

海兹尔.atmosphereColor = Color.valueOf("B7E092FF");
海兹尔.landCloudColor = Color.valueOf("5898F0FF");
海兹尔.atmosphereRadIn = 0.005;
海兹尔.atmosphereRadOut = 0.05;
海兹尔.lightSrcTo = 0.5;
海兹尔.lightDstFrom  = 0.2;
海兹尔.localizedName = "海兹尔";
海兹尔.visible = true;
海兹尔.bloom = false;
海兹尔.updateLighting = true;
海兹尔.accessible = true;
海兹尔.launchCapacityMultiplier = 0.8;
海兹尔.allowLaunchSchematics = true;//开启发射核心蓝图
//海兹尔.description = " 这是一个富饶的星球，丰富的矿藏也招惹了一些敌人……攻下这里，发展科技，开启合晶之旅吧！";
海兹尔.allowSectorInvasion = false;//模拟攻击图入侵
海兹尔.allowWaveSimulation = true;//模拟后台波次
海兹尔.alwaysUnlocked = true;
海兹尔.clearSectorOnLose = false;
海兹尔.allowLaunchLoadout = true;
海兹尔.startSector = 0;
海兹尔.orbitRadius = 150;
海兹尔.tidalLock = false
海兹尔.iconColor = Color.valueOf("B7E092FF");
海兹尔.rotateTime = 600;
海兹尔.hiddenItems.addAll(Items.serpuloItems)
海兹尔.hiddenItems.addAll(Items.erekirItems)
海兹尔.hiddenItems.addAll(
铝,锂,碳单质,粗硅晶,锡,纯硅晶,废晶,废渣,铝钢,塑胶,金,铀,赤金,金辉合金,固态能,初代合晶,次代合晶,超代合晶,凝能晶
);
海兹尔.defaultCore = 一级基站

exports.海兹尔= 海兹尔



const 基站始发点 = new SectorPreset("基站始发点", 海兹尔, 0);
基站始发点.alwaysUnlocked = true;
基站始发点.difficulty = 1;
基站始发点.captureWave = 30;
基站始发点.description = "这是我们来到海兹尔的第一个区块，敌人较为弱小，建立防线，阻挡敌人进攻";
基站始发点.localizedName = "基站始发点";
exports.基站始发点 = 基站始发点;

const 平原遗迹 = new SectorPreset("平原遗迹", 海兹尔, 1);
平原遗迹.alwaysUnlocked = false;
平原遗迹.description = "打下根据地后,我们来到了平原,这里有一些遗迹,可能有用"
平原遗迹.difficulty = 2;
平原遗迹.captureWave = 40;
平原遗迹.localizedName = "平原遗迹";
exports.平原遗迹 = 平原遗迹;

const 崩裂峡谷 = new SectorPreset("崩裂峡谷", 海兹尔, 2);
崩裂峡谷.alwaysUnlocked = false;
崩裂峡谷.description = "穿过平原,是一处峡谷,似乎有着强大的东西"
崩裂峡谷.difficulty = 6;
崩裂峡谷.captureWave = 40;
崩裂峡谷.localizedName = "崩裂峡谷";
exports.崩裂峡谷 = 崩裂峡谷;

const 蜿蜒山洞 = new SectorPreset("蜿蜒山洞", 海兹尔, 3);
蜿蜒山洞.alwaysUnlocked = false;
蜿蜒山洞.description = ""
蜿蜒山洞.difficulty = 6;
蜿蜒山洞.captureWave = 25;
蜿蜒山洞.localizedName = "蜿蜒山洞";
exports.蜿蜒山洞 = 蜿蜒山洞;

const 下游湖泊 = new SectorPreset("下游湖泊", 海兹尔, 4);
下游湖泊.alwaysUnlocked = false;
下游湖泊.description = ""
下游湖泊.difficulty = 6;
下游湖泊.captureWave = 50;
下游湖泊.localizedName = "下游湖泊";
exports.下游湖泊 = 下游湖泊;

const 粉碎冰川 = new SectorPreset("粉碎冰川", 海兹尔, 5);
粉碎冰川.alwaysUnlocked = false;
粉碎冰川.description = ""
粉碎冰川.difficulty = 6;
粉碎冰川.captureWave = 21;
粉碎冰川.localizedName = "粉碎冰川";
exports.粉碎冰川 = 粉碎冰川;

const 沙石缝隙 = new SectorPreset("沙石缝隙", 海兹尔, 6);
沙石缝隙.alwaysUnlocked = false;
沙石缝隙.description = ""
沙石缝隙.difficulty = 6;
//沙石缝隙.captureWave = 50;
沙石缝隙.localizedName = "沙石缝隙";
exports.沙石缝隙 = 沙石缝隙;