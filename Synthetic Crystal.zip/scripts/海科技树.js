const {一级基站} = require('排序/排序(其他)');
const lib = require("lib");
const {海兹尔} = require('海兹尔');
海兹尔.techTree = TechTree.nodeRoot( "海兹尔", 一级基站, true, run(() => {}));

			