const lib = require("lib");
const {一级基站} = require('排序/排序(其他)');
const {基站始发点,平原遗迹,崩裂峡谷,蜿蜒山洞,下游湖泊,粉碎冰川,沙石缝隙} = require('海兹尔');

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(基站始发点, {
        parent: '一级基站',
    });
}));



Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(平原遗迹, {
        parent: '基站始发点',
        objectives: Seq.with(
            new Objectives.SectorComplete(基站始发点),
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(崩裂峡谷, {
        parent: '平原遗迹',
        objectives: Seq.with(
            new Objectives.SectorComplete(平原遗迹),
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(蜿蜒山洞, {
        parent: '平原遗迹',
        objectives: Seq.with(
            new Objectives.SectorComplete(平原遗迹),
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(下游湖泊, {
        parent: '蜿蜒山洞',
        objectives: Seq.with(
            new Objectives.SectorComplete(蜿蜒山洞),
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(粉碎冰川, {
        parent: '蜿蜒山洞',
        objectives: Seq.with(
            new Objectives.SectorComplete(蜿蜒山洞),
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(沙石缝隙, {
        parent: '下游湖泊',
        objectives: Seq.with(
            new Objectives.SectorComplete(下游湖泊),
        ),
    });
}));