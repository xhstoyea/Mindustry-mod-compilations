const 樱花核心 = extend(CoreBlock, "樱花核心", {

canBreak() { return Vars.state.teams.cores(Vars.player.team).size > 1; },
canReplace(other) { return other.alwaysReplace; },
canPlaceOn(tile, team) { return true; },

});
exports.樱花核心 = 樱花核心;