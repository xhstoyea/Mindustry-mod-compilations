const SakuraFall = new Planet("SakuraFall", Planets.sun, 1, 2);
SakuraFall.meshLoader = prov(() => new MultiMesh(
	new HexMesh(SakuraFall,5)
));
SakuraFall.generator = extend(SerpuloPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgZWBlYWDJS8xNZeB1fTqv+8mOtc8W7Hi6v5mBvbgkNTE3M4WBqzg5IzU3sSQzuZiBOyW1OLkos6AkMz+PgYGBLScxKTWnmIEpOpaRQerF5LkvJy16un3pkx2zdFENY2BgZGBgAkIGAJhxK7o=")
	}
});
SakuraFall.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(SakuraFall, 4, 0.5, 0.5, 6, Color.valueOf("fd92ff"), 4, 0.5, 0.5, 0.5),
	new HexSkyMesh(SakuraFall, 4, 0.4, 0.4, 8, Color.valueOf("ffe9ff"), 4, 0.3, 0.3, 0.4)
));
SakuraFall.generator = new SerpuloPlanetGenerator();
SakuraFall.visible = SakuraFall.accessible = SakuraFall.alwaysUnlocked = true;
SakuraFall.atmosphereColor = SakuraFall.lightColor = Color.valueOf("fd92ff");
SakuraFall.iconColor = Color.valueOf("fd92ff"),

SakuraFall.allowWaves = true;
SakuraFall.allowWaveSimulation = true;
SakuraFall.enemyCoreSpawnReplace = true;

SakuraFall.allowLaunchSchematics = true;//许核心蓝图		
SakuraFall.allowLaunchLoadout = true;//许带资源
SakuraFall.launchCapacityMultiplier = 1;
SakuraFall.visible = true;
SakuraFall.bloom = false;
SakuraFall.allowSectorInvasion =true;
SakuraFall.startSector = 1;
SakuraFall.camRadius = 0.6;
SakuraFall.orbitRadius = 35;
SakuraFall.orbitSpacing = 2;
SakuraFall.orbitTime = 180 * 60;
SakuraFall.rotateTime = 90 * 60;
SakuraFall.atmosphereRadIn = 0.02;
SakuraFall.atmosphereRadOut = 0.3;
SakuraFall.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);
SakuraFall.clearSectorOnLose = false;
SakuraFall.tidalLock = false;
SakuraFall.prebuildBase = false;
SakuraFall.defaultCore =core-shard.core-shard;
exports.SakuraFall = SakuraFall;

