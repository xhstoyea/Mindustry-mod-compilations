new Wall("樱花墙");
new Wall("大型樱花墙");
new Wall("茉莉墙");
new Wall("大型茉莉墙");
new Wall("武士墙");
new Wall("大型武士墙");
new Wall("复合绝缘墙");
new Wall("大型复合绝缘墙");

new Drill("钻头-初学者");
new Drill("钻头-新生");
new Drill("钻头-园丁");
new Drill("钻头-园艺师");
new Drill("钻头-园艺达人");
new Drill("钻头-园艺处理系统");

new LaunchPad("樱花发射台");
new StorageBlock("樱花容器");
new OverdriveProjector("小型花香投影仪");
new OverdriveProjector("花香投影仪");
new MendProjector("建筑疗愈投影");
new RepairTower("生物疗愈站");