//信息栏
//作者是谁我不道
//好吧
//问了之后才知道是高科技模组作者



Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("一个一个信息栏");
    dialog.cont.image(Core.atlas.find("合金进化-图片")).row();;
    dialog.buttons.defaults().size(210, 64);
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(210, 64);
    dialog.cont.pane((() => {
        var table = new Table();   
         table.add("这里是一个一个普通得不能再普通的信息栏\n总之大概就是这么这么个样吧，，，\n          [blue]感     谢     名     单\n感谢年年有鱼（毕竟我所有代码都是从他模组那复制的）\n感谢年年有鱼的蓝钢模组群各位大佬的帮助\n然后好像就没了（\n\n什么？你问我模组群是啥？\n好吧，我现在有了\n676380795\n但是\n你还是可以加年年有鱼的蓝钢模组群哒\n\n960996833\n\n大概就是这么个样\n我也没什么想说的了\n886").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
table.button("加QQ群", run(() => {
    var dialog2 = new BaseDialog("蓝钢工业模组QQ群二维码");
    var table = new Table();
    dialog2.cont.image(Core.atlas.find("合金进化-二维码")).row();;
    dialog2.buttons.defaults().size(210, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 64);
       dialog2.show();
    })).size(210, 64).row();
table.button("更新记录", run(() => {
    var dialog2 = new BaseDialog("[red]更新日志");
    var table = new Table();
	
	var t = new Table();
	t.add("啥也没有\n因为作者懒得写");
    dialog2.cont.add(new ScrollPane(t)).size(500, 600).row();
    dialog2.buttons.defaults().size(620, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(500, 64);
       dialog2.show();
    })).size(210, 64);
        return table;
    })()).grow().center().maxWidth(620);
    dialog.show();
}));
//感谢，高/新科技作者提供

//还有能不能问本人，而不是问提供方（恼）-----年年有鱼

//这上面两行事年年有鱼写的辣
//俺要留下来当纪念
//qwq