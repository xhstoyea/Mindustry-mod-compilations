const lib = require("新星球/lib");
const item = require("新星球/item");
const liquid = require("新星球/liquid");

const TLX = new Planet("天狼星", Planets.sun, 1, 3.3);
TLX.meshLoader = prov(() => new MultiMesh(
	new HexMesh(TLX, 8)
));
TLX.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(TLX, 2, 0.15, 0.14, 5, Color.valueOf("B2B8FFFF"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(TLX, 3, 0.6, 0.15, 5, Color.valueOf("B2B8FFFF"), 2, 0.42, 1.2, 0.45)
));
TLX.generator = new SerpuloPlanetGenerator();
TLX.visible = TLX.accessible = TLX.alwaysUnlocked =  true;
TLX.clearSectorOnLose = false;
TLX.tidalLock = false;
TLX.localizedName = "天狼星";
TLX.bloom = false;
TLX.startSector = 1;
TLX.orbitRadius = 40;
TLX.orbitTime = 180 * 60;
TLX.rotateTime = 90 * 60;
TLX.atmosphereRadIn = 0.02;
TLX.atmosphereRadOut = 0.3;
TLX.atmosphereColor = TLX.lightColor = Color.valueOf("B2B8FFFF");
TLX.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);

const 降落 = new SectorPreset("降落", TLX, 1);
降落.description = "你发现一个资源丰富的星球，所以你要占领它，嗯，对";
降落.difficulty = 2;
降落.alwaysUnlocked = true;
降落.addStartingItems = true;
降落.captureWave = 25;
降落.localizedName = "降落";
exports.降落 = 降落;
lib.addToResearch(降落, {
	parent: "planetaryTerminal",
	objectives: Seq.with(
	new Objectives.SectorComplete(SectorPresets.planetaryTerminal))
});

const 港口 = new SectorPreset("港口", TLX, 2);
港口.description = "在继续深入探索时遇到一个据点，嗯，对";
港口.difficulty = 4;
港口.alwaysUnlocked = true;
港口.addStartingItems = true;
港口.captureWave = 35;
港口.localizedName = "港口";
exports.港口 = 港口;
lib.addToResearch(港口, {
	parent: "planetaryTerminal",
	objectives: Seq.with(
	new Objectives.SectorComplete(SectorPresets.planetaryTerminal))
});
