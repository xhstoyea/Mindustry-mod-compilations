MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000
require('qwer');
require('独立小核心');
require('新星球/天狼星');
require('新星球/item');
require('新星球/liquid');
require('新星球/独立科技');