 const 独立小核心 = extend(CoreBlock, "独立小核心", {
    
    canBreak() { return Vars.state.teams.cores(Vars.player.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) { return true; },
});
exports.独立小核心 = 独立小核心;