module.exports = [
    'alpha', 'beta', 'gamma', 'evoke', 'incite', 'emanate'
]
