var checkread=false
Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("蒸汽朋克工业");
    dialog.buttons.defaults().size(400, 64);
       /* dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128)*/
    dialog.buttons.button("@close", run(() => {dialog.hide()})).size(400, 128)/*.disabled(b=>!checkread).update(b => {
        if (!checkread){
            b.setText("请仔细阅读本次更新公告并确认")
        }
        if (checkread){
            b.setText("关闭")
        }
            })*/

    dialog.cont.pane((() => {

        var table = new Table();
        table.add("蒸汽朋克工业");
        table.row();
        table.add("v0.0.1");
        table.row();
        table.add(" ");
        table.row();
        table.add('模组添加群:791636288');
        table.row()
        table.add("b站:一只钍呀!")
        table.row();
        table.add(" ");
        table.row();
    table.button('更新', Icon.infoCircle, run(() => {
    var dialog = new BaseDialog("更新");
    dialog.cont.pane(t => {
        t.add("更新");
        t.row();
        t.button("本次模组更新", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("本次模组更新");
            dialog.cont.pane(t => {
                t.add("这个版本目前只有整个独立科技树上的物品和独立核心。这个版本目前属于内测版本。").left()
                t.row()
    			t.check("确认收到",checkread, m => {
			    checkread=m
			}).left()
			    t.row()
                t.add("这里什么也没有")
                t.row()
            })
            dialog.buttons.button("@close", ()=>{
        dialog.hide()
            }).size(400, 128)
            dialog.show();
        })).size(400, 128);
        t.row()
        t.button("历次模组更新", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("历次模组更新");
            dialog.cont.pane(t => {
                t.add("没有")
                t.row()
                t.add("没有")
                t.add("没有")
                t.row()
                t.add(" ")
                t.row()
                t.add("story，没有");
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128);;
            dialog.show();
        })).size(400, 128);
    });
    dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128);;
    dialog.show();
})).size(400, 64);

        table.row();
    table.button('介绍', Icon.infoCircle, run(() => {
    var dialog = new BaseDialog("介绍");
    dialog.cont.pane(t => {
        t.add("围绕蒸汽作为科技发展，新的科技等待你的挖掘!")
    });
    dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128)
    dialog.show();
})).size(400, 64);
        table.row();
        return table;
    })()).grow().center().maxWidth(620);
    dialog.show();
}));
//代码来源于铧金工业！