
Events.on(EventType.ContentInitEvent, 
cons(e => {
    Log.info("Content init")
    //...
}));
