
const 核心 = extend(CoreBlock, "核心", {
	canReplace(other) {
		return true;
	}
	});


核心.buildVisibility = BuildVisibility.shown;
核心.category = Category.logic;

//这是必需的
核心.update = true
//设置方块可使用物品
核心.hasItems = true;