//首先你要制作一个星球，星球的各种接口在源码Planet文件里面，并不止我写的下面那几个，里面的注释你可以用翻译机翻译一下就知道每个接口的作用


//------------------------------------------------------


//“星球变量名字”可以自己随便改，这个是用于代码读取使用的
//注意:所有变量名必须保持统一
const 漠星=JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(漠星, 6));
        this.super$load();
    }
}, "漠星", Planets.sun, 1,2);
漠星.generator = new SerpuloPlanetGenerator();
漠星.meshLoader = () => new HexMesh(this, 6);
漠星.atmosphereColor = Color.valueOf("C89D2AFF");("C89D2AFF");("C89D2AFF")//大气颜色
漠星.atmosphereRadIn = 0.05;//大气
漠星.atmosphereRadOut = 0.2;//大气
漠里.localizedName = "漠星";//这是星球界面显示的名字,可以与上面的星球名字写一样，这个是界面显示用的，上面是代码读取用的
漠星.startSector = 1;//第一降落区块
漠星.orbitRadius = 40;//离太阳远有多远
漠星.alwaysUnlocked = true;//默认解锁，必须开启
漠星.clearSectorOnLose = true;//地图丢失时是否重置地图
漠星.enemyCoreSpawnReplace = false;//关闭攻击图核心变刷怪点
漠星.allowLaunchSchematics = true;//开启发射核心蓝图
漠星.allowLaunchLoadout = true;//开启携带资源发射
漠星.allowSectorInvasion = false;//关闭模拟攻击图入侵
漠星.allowWaveSimulation = true;//开启模拟后台波次，如果关闭就无法在未占领时切换地图
漠星.accessible = true;
/*********************************************** */
//然后你要创建一个自己的核心：
const 目标核心= extend(CoreBlock, "目标核心", {});
//然后创建一个同名的json文件，自己写这个核心的属性
//注意："tyep":"CoreBlock" 这个接口不要写，不然闪退，因为这里已经写过了

漠星.defaultCore = 目标核心;//这里注意看变量名，别搞错了
目标核心.always Unlocked= true;//默认解锁，不是必须，你可以加条件，比如占领核列阵 解锁冲击发电机后解锁你的mod科技树。当然你必须先把默认解锁关闭
//漠星.unlockedOnLand.add(目标核心);//这个是改默认落地核心，原版是小核心。但是好像改了没效果，所以我注释了

漠星.techTree = TechTree.nodeRoot("漠星", 目标核心, true, run(() => {}));

//到这里就完成独立科技树了，然后你用json写一个方块，然后json里面的科技树接口 接上你的“核心名字”  就可以了。另外 我是9527，做创世神mod的那位，有不懂的可以来群里找我


const map1 = new SectorPreset("封闭山谷", 漠星, 1);
map1.alwaysUnlocked = true;
map1.difficulty = 0;
map1.captureWave = 0;
map1.description = " 封闭山谷";
map1.localizedName = "封闭山谷";
exports.map1 = map1;


const map2 = new SectorPreset("复杂盆地", 漠星, 9);
map2.alwaysUnlocked = true;
map2.difficulty = 1;
map2.captureWave = 0;
map2.description = " 复杂盆地";
map2.localizedName = "复杂盆地";
exports.map2 = map2;

