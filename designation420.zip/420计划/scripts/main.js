//require("blocks/紫渊合金核心");
require("星球/紫渊星");//告诉游戏加载星球文件
require("星球/核心");
require("星球/ivi铜铅核心");//告诉游戏加载核心文件
require("items");
require("liquids");
require("qwer");
require("工厂/电解制氢机");
require("工厂/月澜工厂");
require("工厂/矿渣处理器");
require("工厂/奇点转化器");
require("辅助/缩放强化");
MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 500000//，这两条不需要管