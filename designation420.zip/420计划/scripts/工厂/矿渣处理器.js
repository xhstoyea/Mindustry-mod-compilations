const library = require("base/library");
const 矿渣处理器 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "矿渣处理器", [
  {
    input: {
      items: ["coal/1"],     
      liquids: ["slag/16.2"],
      power:4.05,
    },
    output: {
      items: ["pyratite/1"],
    },
    craftTime: 34.8
  }, 
  {
    input: {
      items: ["silicon/4"],     
      liquids: ["slag/60"],
      power:6,
    },
    output: {
      items: ["surge-alloy/2"],     
    },
    craftTime:126
  }
  ]);
矿渣处理器.itemCapacity = 30;
矿渣处理器.liquidCapacity = 140;
矿渣处理器.health = 320;
矿渣处理器.size = 2;
矿渣处理器.hasItems = true;
矿渣处理器.hasLiquids = true;
矿渣处理器.hasPower = true;
矿渣处理器.researchCost = ItemStack.with(
Items.lead, 180,
Items.silicon, 110,
Items.graphite, 180,
Items.titanium,100,
Items.copper,360
);
矿渣处理器.buildVisibility = BuildVisibility.shown;
矿渣处理器.category = Category.crafting;//显示界面

exports.矿渣处理器 = 矿渣处理器
