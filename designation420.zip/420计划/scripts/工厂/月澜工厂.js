const library = require("base/library");
const 月澜工厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "月澜工厂", [//"  "里面填上方块的名字
  {
    input: {
      items: ["coal/3","titanium/2"],    //物品 
      power:3.8,//电力
    },
    output: {
      items: ["plastanium/1"],
    },   
    craftTime: 72
  }, 
  {
    input: {//输入
      items: ["spore-pod/1","titanium/2"],     
      power:2.45,
    },
    output: {//输出
      items: ["plastanium/1"],  
    },
    craftTime:51//产出时间
  },
  {
    input: {
      items: ["spore-pod/10","titanium/10"],    //物品 
      power:6.86,//电力
    },
    output: {
      items: ["plastanium/13"],
    },   
    craftTime: 360
  }, 
    {
    input: {
      items: ["titanium/7"],          //物品
       liquids: ["oil/113"],
      power:4.1,//电力
    },
    output: {
      items: ["plastanium/5"],
    },   
    craftTime: 230
  }, 
  {
    input: {
      items: ["titanium/4"],          //物品
       liquids: ["oil/72"],
      power:8.1,//电力
    },
    output: {
      items: ["plastanium/5"],
    },   
    craftTime:30
  }
  ]
  );
  月澜工厂.craftEffect = Fx.formsmoke;//工作效果
  月澜工厂.updateEffect = Fx.plasticburn;
  月澜工厂.itemCapacity = 45;  //物品容量
  月澜工厂.liquidCapacity=145;
  月澜工厂.health = 652;//方块生命值
  月澜工厂.size = 3;//方块大小 
  月澜工厂.hasItems = true;//需要物品
  月澜工厂.hasLiquids = true;//需要液体
  月澜工厂.hasPower = true;//需要电力
月澜工厂.buildVisibility = BuildVisibility.shown;
月澜工厂.category = Category.crafting;//显示界面

exports.月澜工厂 = 月澜工厂;
//