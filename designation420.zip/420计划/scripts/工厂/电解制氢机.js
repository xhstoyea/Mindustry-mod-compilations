const library = require("base/library");
const 电解制氢机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "电解制氢机", [
  {
    input: {
      items: ["beryllium/1"],     
      liquids: ["water/1"],
      power:1.9,
    },
    output: {
      items: ["oxide/1"],
      liquids: ["hydrogen/1"]     
    },
    heat:5,
    craftTime: 80.6
  }, 
  {
    input: {
      items: ["beryllium/10"],     
      liquids: ["water/10"],
      power:15.2,
    },
    output: {
      items: ["oxide/10"],
      liquids: ["hydrogen/10"]     
    },
    heat:50,
    craftTime:120.6
  }
  ]);
电解制氢机.craftEffect = Fx.pulverizeMedium;
电解制氢机.itemCapacity = 20;
电解制氢机.liquidCapacity = 50;
电解制氢机.health = 680;
电解制氢机.size = 3;
电解制氢机.hasheat=true;
电解制氢机.hasItems = true;
电解制氢机.hasLiquids = true;
电解制氢机.hasPower = true;
电解制氢机.requirements = ItemStack.with(
    Items.beryllium, 125,
    Items.silicon, 75,
    Items.graphite, 60,
    Items.tungsten,100,
);
电解制氢机.researchCost = ItemStack.with(
Items.beryllium, 75,
Items.silicon, 37,
Items.graphite, 40,
Items.tungsten,80,
);
电解制氢机.buildVisibility = BuildVisibility.shown;
电解制氢机.category = Category.crafting;//显示界面

exports.电解制氢机 = 电解制氢机;
