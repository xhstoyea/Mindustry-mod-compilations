const library = require("base/library");
const 奇点转化器 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "奇点转化器", [//"  "里面填上方块的名字
  {
    input: {
      items: ["sand/1"],    //物品 
      power:0.135,//电力
    },
    output: {
      items: ["metaglass/1"],
    },   
    craftTime: 28.8
  }, 
  {
    input: {//输入
      items: ["sand/2"],     
      power:0.139,
    },
    output: {//输出
      items: ["silicon/1"],  
    },
    craftTime:30//产出时间
  }
  ]);
  奇点转化器.craftEffect = Fx.pulverizeMedium;//工作效果
  奇点转化器.itemCapacity = 20;  //物品容量
  奇点转化器.health = 45;//方块生命值
  奇点转化器.size = 1;//方块大小
  奇点转化器.hasheat=false;//需要热量
  奇点转化器.hasItems = true;//需要物品
  奇点转化器.hasLiquids = false;//需要液体
  奇点转化器.hasPower = true;//需要电力
  奇点转化器.requirements = ItemStack.with(
    Items.lead, 30,
    Items.silicon, 6,
    Items.graphite, 15,
    Items.copper,45,
);//建造所需要的物品
奇点转化器.researchCost = ItemStack.with(
    Items.lead, 40,
    Items.silicon, 10,
    Items.graphite, 30,
    Items.copper,45,
);//研究所需要的物品
奇点转化器.buildVisibility = BuildVisibility.shown;
奇点转化器.category = Category.crafting;//显示界面

exports.奇点转化器 = 奇点转化器;
//