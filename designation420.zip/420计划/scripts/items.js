function newItem(name) {
	exports[name] = (() => {
		let ltems= extend(Item, name, {});
		return ltems;
	})();
}
newItem("相位合金")
newItem("紫渊合金")
newItem("420燃料")
newItem("亚砜协议")
newItem("钛钢")