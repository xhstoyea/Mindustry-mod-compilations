//信息栏(未知编写者)
//更改者，年年有鱼(年年有余本人编写)
//二次更改者，homeless Ziyuan420(王子源)
Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("[red]420project信息栏");
    dialog.cont.image(Core.atlas.find("420工程-icon.png")).row();;
    dialog.buttons.defaults().size(210, 64);
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(210, 64);
    dialog.cont.pane((() => {
        var table = new Table();   
         table.add("当前版本0.5.5\n[blue]更新记录:\n[blue]埃里克尔炮台科技线重组！").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
table.button("作者的联系方式", run(() => {
    var dialog2 = new BaseDialog("模组群二维码(QQ)");
    var table = new Table();
    dialog2.cont.image(Core.atlas.find("420工程-二维码")).row();;
    dialog2.buttons.defaults().size(210, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210,64);
       dialog2.show();
    })).size(210,64).row();
table.button("[green]致谢", run(() => {
    var dialog2 = new BaseDialog("感谢名单");
    var table = new Table();
	
	var t = new Table();
	t.add("感谢E提供了星球.js代码\n感谢E对星球部分代码的修改(改良)\n感谢引力矩阵、火玄、R提供本模组部分贴图\n本mod 已内置莉娅汐塔的核心霸屏mod(已魔改，非原版)\n感谢洋葱对贴图提供的支持\n感谢ivi、烤土豆、");//代码:homeless Ziyuan420\n帮助:\n感谢E、引力矩阵、火玄(特别鸣谢:R对承上启下冷冻液工厂的贴图绘画)
    dialog2.cont.add(new ScrollPane(t)).size(500, 600).row();
    dialog2.buttons.defaults().size(620, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(500, 64);
       dialog2.show();
    })).size(210, 64);
        return table;
    })()).grow().center().maxWidth(620);
    dialog.show();
}));
//感谢，高/新科技作者提供(年年有余本人编写)

//还有能不能问本人，而不是问提供方（恼）-----年年有鱼(年年有余本人编写)
//完了，我成盗窃者了(惨)               ------王子源[模初](homeless Ziyuan420本人写于2024.7.8 09.30)