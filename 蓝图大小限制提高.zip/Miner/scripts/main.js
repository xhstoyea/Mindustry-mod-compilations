// 读取蓝图时大小不能超过128
Vars.maxSchematicSize = 128;