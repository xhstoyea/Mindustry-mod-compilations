const 海洋面板 = new Floor("海洋面板");
const 地热块 = new Wall("地热块");
const 水面板 = new Wall("水面板");
const 沙滩 = new Wall("沙滩");
const 开凿喷口 = new Wall("开凿喷口");
const 气井 = new SteamVent("气井");

exports.海洋面板 = 海洋面板;
exports.水面板 = 水面板;
exports.地热块 = 地热块;
exports.沙滩 = 沙滩;
exports.开凿喷口 = 开凿喷口;
exports.气井 = 气井;

沙滩.update = true;
沙滩.buildType = prov(() => extend(Wall.WallBuild, 沙滩, {
	updateTile(){
	    Vars.world.tile(this.tileX(), this.tileY()).setFloor(Blocks.sand);
	    Vars.world.tile(this.tileX(), this.tileY()).setAir();
	},
}));

地热块.update = true;
地热块.buildType = prov(() => extend(Wall.WallBuild, 地热块, {
	updateTile(){
	    Vars.world.tile(this.tileX(), this.tileY()).setFloor(Blocks.hotrock);
	    Vars.world.tile(this.tileX(), this.tileY()).setAir();
	},
}));


水面板.update = true;
水面板.buildType = prov(() => extend(Wall.WallBuild, 水面板, {
	updateTile(){
	    Vars.world.tile(this.tileX(), this.tileY()).setFloor(海洋面板);
	    Vars.world.tile(this.tileX(), this.tileY()).setAir();
	},
}));

开凿喷口.update = true;
开凿喷口.buildType = prov(() => extend(Wall.WallBuild, 开凿喷口, {
	updateTile(){
	    Vars.world.tile(this.tileX(), this.tileY()).setFloor(气井);
	   	Vars.world.tile(this.tileX(), this.tileY()).setAir()
	},
}));