function newItem(name) {
	exports[name] = extend(Item, name, {});
}
function newCellLiquid(name) {
	exports[name] = extend(CellLiquid, name, {});
}
function newLiquid(name) {
	exports[name] = extend(Liquid, name, {});
}
function newBlock(name) {
	exports[name] = extend(Block, name, {});
}

newItem("铝");
newItem("镍");
newItem("紫金");
newItem("强化合金");