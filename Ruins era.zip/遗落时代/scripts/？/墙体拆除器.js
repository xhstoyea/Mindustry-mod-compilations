const mblock = extend(Wall,"墙体拆除器",{
    ox:0,
    oy:0,
    drawPlace(x, y, rotation, valid){
		this.super$drawPlace(x, y, rotation, valid);
		
		this.ox = Angles.trnsx(rotation * 90, 1, 0);
        this.oy = Angles.trnsy(rotation * 90, 1, 0);
        for(let i = 1;i <= 3;i ++){
		    Drawf.dashSquare(
		        Pal.accent,
		        x * 8 + this.offset + this.ox * 8 * i,
		        y * 8 + this.offset + this.oy * 8 * i,
		        8
		    );
		}
	},
	canBreak(tile){return false}
});
Object.assign(mblock,{
    size: 1,
    health: 40,
    buildVisibility: BuildVisibility.shown,
    solid: true,
    update: true,
    hasShadow: false,
    destructible: true,
    rotate: true,
    hasItems: true,
});

mblock.buildType = prov(() => extend(Building, {
    time:420,
    i: 1,
    updateTile(){
        this.super$updateTile();
        
        this.dump()
        
        this.time -= Time.delta;
        if(this.time > 0)Vars.ui.showLabel("拆除中,剩余[accent]" + (Math.round(this.time / 60)) + "[]秒", 0.01, this.x, this.y);
        
        if(this.time <= 0){
        
            let ox = Angles.trnsx(this.rotation * 90, 1, 0) * this.i;
            let oy = Angles.trnsy(this.rotation * 90, 1, 0) * this.i;
            
            Vars.world.tile(
                this.tileX() + ox,
                this.tileY() + oy
            ).setAir();
            
            if(this.i <= 3){
                this.i += 1;
                this.time = 420;
                this.items.add(Items.sand, 20);
            }else if(this.items.get(Items.sand) == 0){
                this.tile.setAir()
            }
        }
    }
}))