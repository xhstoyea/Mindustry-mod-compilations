function ArmorStatus(name, armor) {
	return extend(StatusEffect,name, {
		update(unit) {
unit.armor = unit.type.armor + armor;
	}});
};
ArmorStatus("装甲强化", 8);
ArmorStatus("装甲弱化", -6);

function ArmorStatusMultiplier(name, armor) {
	return extend(StatusEffect,name, {
		update(unit) {
unit.armor = unit.type.armor * armor;
	}});
};//healthMultiplier
ArmorStatusMultiplier("复合装甲", 1.5);


function HealthStatus(name, hp) {//一个函数
	return extend(StatusEffect,name, {
		update(unit) {
unit.maxHealth = unit.type.health + hp;//单位上限血量=该种单位单位上限血量 + hp
	}});
};
HealthStatus("生命强化", 400);//赋值
