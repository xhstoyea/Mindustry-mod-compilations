const 护盾映射 = new ForceProjector("护盾映射");
护盾映射.buildType = prov(() => extend(ForceProjector.ForceBuild, 护盾映射,{
    updateTile(){
        this.super$updateTile()
        let realRadius = this.realRadius();
        if(!this.broken){
            Groups.bullet.intersect(this.x - realRadius, this.y - realRadius, realRadius * 2, realRadius * 2, b => {
                if(b.type.absorbable && b.team != this.team){
                    b.trns(-b.vel.x, -b.vel.y);
                    b.team = this.team
                }
            });
        }
    }
}))