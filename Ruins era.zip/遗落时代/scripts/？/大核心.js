const core柳叶 = extend(ItemTurret, "core柳叶", {});
const 大型前哨 = extend(CoreBlock, "大型前哨", {});
大型前哨.buildVisibility = BuildVisibility.shown;
大型前哨.category = Category.logic;

//这是必需的
大型前哨.update = true;
//设置方块可使用物品
大型前哨.hasItems = true;

//设置可使用的弹药
const TItems = [Items.copper]

大型前哨.buildType = prov(() => {
	//创建多炮塔
	//(方块，队伍(不需要设置))
	const payloads = [
	new BuildPayload(core柳叶, Team.derelict),			];
	const build = extend(CoreBlock.CoreBuild, 大型前哨, {
		updateTile() {
			this.super$updateTile();

			//可以让炮塔转起来的代码
			//删除注释以使用
			/*for (var i = 0; i < payloads.length; i++) {
                var t = payloads[i];
                var rotation = (360.0 / payloads.length) * i + Time.time;

				//这里的24为距离本体方块中心的多少距离旋转(8为1格)
                t.set(x + Angles.trnsx(rotation, 24), y + Angles.trnsy(rotation, 24), t.build.payloadRotation);
            }*/

			//设置模块
		
			for(var id = 0; id < payloads.length; id++){
				//设置队伍，如果在上面的创建位置设置，无用
                if(payloads[id].build.team != this.team){
                    payloads[id].build.team = this.team;
                }
				
				//执行炮塔更新
                payloads[id].update(null, this);

				//为物品炮塔添加弹药
				//你们需要可自己定义
				for(var i = 0; i < TItems.length; i++){
					if(payloads[id].build.acceptItem(payloads[id].build, TItems[i]) && this.items.get(TItems[i]) >= 1) {
						payloads[id].build.handleItem(payloads[id].build, TItems[i]);
						this.items.remove(TItems[i], 1);
					}
				}
            }

			//设置炮塔的位置
			//有需求你们可以自己定义
			//（x, y, r）
 payloads[0].set(this.x + 0, this.y + 0, payloads[0].build.payloadRotation);
		},
		draw(){
			this.super$draw();

			//执行多炮塔的动画
			for(var i = 0; i < payloads.length; i++){
                payloads[i].draw();
            }
		},
	});

	return build;
});