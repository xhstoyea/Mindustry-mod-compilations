const Tree = TechTree;
function ModTree(){
    this.nodes = new Seq();
    this.nodeMap = new ObjectMap();
    return this;
}
function modNode(node){
    this.node = node;
    this.child = child => childLast(child);
    this.warp = () => {
        prev();
        return last.peek()
    };
    this.warpChild = child => {
        this.child(child);
        return this.warp();
    };
    this.produce = objective => {
        this.node.objectives.add(objective);
        return this
    };
    this.setRequirements = itemStacks => {
        this.node.setupRequirements(itemStacks);
        return this
    }
    return this
}
const modTree = new ModTree();
var last = new Seq();
//可选配置
var defaultPlanet = Planets.serpulo;
var mod = true;
//
function reverse(){
    mod = !mod;
}
function getByNameBlock(name){
    return Vars.content.block(modName+"-"+name)
}
function blockResearchRequirements(block){
    if(block.researchCost != null) return block.researchCost;
        if(block.researchCostMultiplier <= 0) return ItemStack.empty;
        var out = new Seq(block.requirements.length);
        for(var i = 0; i < out.size; i++){
            var quantity = Mathf.round(60 * block.researchCostMultiplier + Mathf.pow(block.requirements[i].amount, 1.11) * 20 * block.researchCostMultiplier * block.researchCostMultipliers.get(block.requirements[i].item, 1), 10);
            out.set(i,new ItemStack(requirements[i].item, UI.roundAmount(quantity)))
        }
    return new ItemSeq(out).toArray();
}
function unitResearchRequirements(unit){
    if(unit.cachedRequirements != null){
            return unit.cachedRequirements;
        }
        var stacks = unit.getRequirements(null, null);
        if(stacks != null){
            var out = new Seq(stacks.length);
            for(var i = 0; i < out.size; i++){
                out.set(i,new ItemStack(stacks[i].item, UI.roundAmount(parseInt((Math.pow(stacks[i].amount, 1.1) * researchCostMultiplier)))))
            }
            out = Structs.filter(ItemStack, out, stack => stack.amount > 0);
            unit.cachedRequirements = out;
            return new ItemSeq(out).toArray();
        }
    return ItemStack.empty;
}
function putMap(content,node){
    if (modTree.nodeMap.containsKey(content)){
        modTree.nodeMap.get(content).add(node)
    }else{
        modTree.nodeMap.put(content,new Seq());
        putMap(content,node)
    }
}
function putTree(node){
    modTree.nodes.add(node.node);
    putMap(node.node.content,node.node);
/*    if (node.node.content instanceof Block){
        node.setRequirements(blockResearchRequirements(node.node.content))
    }else if (node.node.content instanceof UnitType){
        node.setRequirements(unitResearchRequirements(node.node.content))
    }*/
    last.add(node)
}
function prev(){
    last.pop();
}
function getTreeNodeBool(bool,content){
    return Tree.all.find(e=>e.content==content&&bool(e))
}
function getTreeNode(content){
    return getTreeNodeBool(e=>true,content)
}
function addChild(parent,node){
    if (parent instanceof TechTree.TechNode){
        parent.children.add(node.node)
        return node
    }else if (parent instanceof modNode){
        parent.node.children.add(node.node)
    }
    var getd = modTree.nodeMap.get(parent);
    if (getd!=null) getd.each(n=>n.children.add(node.node));
    if (mod) return node
    else getTreeNode(parent).children.add(node.node);
    return node;
}
function rootPlanet(planet,name,content){
    var node = root(name,content)
    planet.techTree = node.node;
    return node;
}
function rootPlanetD(name,content){
    var node = root(name,content);
    defaultPlanet.techTree = node.node;
    return node;
}
function root(name,content){
    var node = new modNode(Tree.nodeRoot(name,content,()=>{}));
    putTree(node);
    return node;
}
function Node(parent,content){
    var node = new modNode(Tree.node(content));
    addChild(parent,node);
    putTree(node);
    return node
}
function childLast(content,warp){
    var node = Node(last.peek(),content)
    if (warp) prev();
    return node
}
/*示例
root("name",Items.copper)
    .child(Items.lead)
        .warpChild(Items.sand);
    childLast(Items.titanium)
        .produce(new Objectives.Research(Blocks.hail))
        .warpChild(Blocks.titaniumWall)
        .child(Blocks.copperWall)
            .setRequirements(Blocks.hail.requirements)
            .warp()
        .warp();
    childLast(UnitTypes.mono,true);
    childLast(Blocks.duo)
        .child(Blocks.lancer)
            .warpChild(Blocks.thoriumWall)
            .warp();
        childLast(Blocks.hail,true);
    prev()
prev()*/
exports.getByNameBlock = getByNameBlock;
exports.rootPlanet = rootPlanet;