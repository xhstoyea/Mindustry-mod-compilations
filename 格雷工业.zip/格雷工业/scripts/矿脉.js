
function getbyname(name){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
var oremap=new Map()
var liqmap=new Map()
oremap.set("晶质铀矿",getbyname("社会主义工业化-二氧化铀"))
oremap.set("盐矿",getbyname("社会主义工业化-硫酸盐矿"))
oremap.set("石墨矿簇",getbyname("graphite"))
oremap.set("铍矿脉",getbyname("社会主义工业化-绿柱石"))
oremap.set("稀土矿脉",getbyname("社会主义工业化-独居石"))
oremap.set("黄石矿脉",getbyname("社会主义工业化-黄石"))
oremap.set("萤石矿脉",getbyname("社会主义工业化-萤石"))
oremap.set("钨酸盐矿",getbyname("社会主义工业化-钨酸盐矿"))

const ore=[]
ore.push({pos:[[110,90],[120,90],[120,100],[110,100]],type:"晶质铀矿",layer:6,drop:getbyname("社会主义工业化-二氧化铀")})
ore.push({pos:[[90,60],[120,90],[120,100],[110,100]],type:"盐矿",layer:4,drop:getbyname("社会主义工业化-硫酸盐矿")})
ore.push({pos:[[70,40],[100,70],[100,80],[90,80]],type:"盐矿",layer:7,drop:getbyname("社会主义工业化-硫酸盐矿")})
ore.push({pos:[[90,60],[120,90],[120,100],[110,100]],type:"铍矿脉",layer:4,drop:oremap.get("铍矿脉")})
ore.push({pos:[[110,80],[140,110],[140,120],[130,120]],type:"钨酸盐矿",layer:11,drop:oremap.get("钨酸盐矿")})
ore.push({pos:[[150,130],[190,160],[190,170],[180,170]],type:"萤石矿脉",layer:15,drop:oremap.get("萤石矿脉")})

const liq=[]
liq.push({pos:[[110,90],[120,90],[120,100],[110,100]],type:"石油",layer:2,drop:Liquids.oil})
exports.ore=ore
exports.liq=liq