const 黄石焙烧炉 = extend(GenericCrafter, '黄石焙烧炉', {});
exports.黄石焙烧炉 = 黄石焙烧炉
const 钛冶炼炉 = extend(GenericCrafter, '钛冶炼炉', {});
exports.钛冶炼炉 = 钛冶炼炉
