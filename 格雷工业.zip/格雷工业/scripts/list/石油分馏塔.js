const 石油分馏塔 = extend(GenericCrafter, '石油分馏塔', {});
exports.石油分馏塔 = 石油分馏塔
