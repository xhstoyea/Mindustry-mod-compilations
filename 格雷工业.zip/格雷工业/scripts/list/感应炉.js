const 感应炉 = extend(GenericCrafter, '感应炉', {});
exports.感应炉 = 感应炉
