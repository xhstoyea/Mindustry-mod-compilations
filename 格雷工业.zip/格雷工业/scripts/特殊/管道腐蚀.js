
function getbyname(name){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}  
const ti=6
const harm = require("数据/value").corr.harm
const defense = require("数据/value").corr.defense
const list=Array.from(harm.keys())
function liquidharm(self){
    var li=self.liquids.current()
    if (!harm.has(li.name)){return}
    var damage=harm.get(li.name)
    var p=defense.get(self.block.name)
    if (damage<=p){return}
    var c=self.block.liquidCapacity
    if (defense.has(self.block.name)){
    var f=self.liquids.get(li)
    damage=r((damage-p)*f/c,3)
    if (f > 0.05) {
        self.health=self.health-damage*ti
    if (self.health<damage*ti){self.kill()}
            }}
    }
const setBuildingType = (block) => {
    const build = block.buildType.get()
        .getClass()
    var timer=0
    block.buildType = prov(() => new JavaAdapter(build, {
        update() {
            this.super$update()
            timer++
            if (timer>=ti){
            liquidharm(this)
            timer=0
            }
        },
    }, block));
}

Events.on(EventType.ClientLoadEvent, () => {
   for (var i=0;i<list.length;i++){
    getbyname(list[i]).stats.add(new Stat("腐蚀性", StatCat.function),(harm.get(list[i])-1)*100, StatUnit.percent)}
    Vars.content.blocks().each(cons(block => {
        if (defense.has(block.name)){
            setBuildingType(block)
            block.stats.add(new Stat("腐蚀抗性", StatCat.function),(defense.get(block.name)-1)*100, StatUnit.percent)     
        }
    }));
})