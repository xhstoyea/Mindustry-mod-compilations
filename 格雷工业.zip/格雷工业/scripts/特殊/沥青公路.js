var 沥青地板 = new Floor("沥青地板");
var 沥青公路 = new Wall("沥青公路");
var 拆除 = new Wall("拆除");
var 地基 = new Floor("地基");

exports.沥青地板 = 沥青地板;
exports.沥青公路 = 沥青公路;
exports.拆除 = 拆除;
exports.地基 = 地基;

沥青公路.update = true;
沥青公路.buildType = prov(() => {
	var b = extend(Wall.WallBuild, 沥青公路, {
	updateTile(){
	    Vars.world.tile(this.tileX(), this.tileY()).setFloor(沥青地板);
	    Vars.world.tile(this.tileX(), this.tileY()).setAir();
	},
	})
	return b
});
拆除.update = true;
拆除.buildType = prov(() => {
	var b = extend(Wall.WallBuild, 拆除, {
	updateTile(){
	    Vars.world.tile(this.tileX(), this.tileY()).setFloor(地基);
	    Vars.world.tile(this.tileX(), this.tileY()).setAir();
	},
	})
	return b
});