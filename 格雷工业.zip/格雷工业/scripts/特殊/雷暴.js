
const we = extend(ParticleWeather, "闪电风暴", {
	drawOver(state) {
		this.drawRain(10, 40, 8, 10, 1000, state.intensity, 0.85, this.rainColor)
		if (Vars.state.isPlaying() && Mathf.chanceDelta(0.04 * state.intensity / 2)) {
			let wx = Mathf.random(0, Vars.world.width()) * 8,
				wy = Mathf.random(0, Vars.world.height()) * 8,
				st = Mathf.random(8, 32 + state.intensity * 4),
				block = Vars.indexer.findEnemyTile(Team.derelict, wx, wy, 800, b => b.block instanceof PowerBlock)
		}
	}
})
we.attrs.set(Attribute.light, -0.8)
we.attrs.set(Attribute.water, 0.9)
we.useWindVector = true;
we.sizeMin = 75;
we.sizeMax = 125;
we.minAlpha = 0.02;
we.maxAlpha = 0.12;
we.baseSpeed = 12;
we.force = 1;
we.density = 20000;
we.padding = 16;
we.status = StatusEffects.wet;
we.sound = Sounds.rain;
we.soundVol = 0.9;