function generateQuadrilateral(range, pointx, pointy, seed) {
    // 确保range是正数
    if (range <= 0) {
        throw new Error("Range must be a positive number.");
    }
    function seededRandom(seed) {
        let x = Math.sin(seed) * 10000;
        return x - Math.floor(x);
    }
    let vertices = [];
    for (let i = 0; i < 4; i++) {
        let randX = seededRandom(seed + i * 2); // 使用seed生成随机x坐标
        let randY = seededRandom(seed + i * 2 + 1); // 使用seed生成随机y坐标
        vertices.push({ x: randX * 10 - 5, y: randY * 10 - 5 }); // 将随机数映射到[-5, 5]范围
    }
    // 计算四边形的中心点
    let centerX = (vertices[0].x + vertices[1].x + vertices[2].x + vertices[3].x) / 4;
    let centerY = (vertices[0].y + vertices[1].y + vertices[2].y + vertices[3].y) / 4;
    // 调整四边形的中心点到(pointx, pointy)附近
    let offsetX = pointx - centerX;
    let offsetY = pointy - centerY;
    for (let vertex of vertices) {
        vertex.x += offsetX;
        vertex.y += offsetY;
    }
    // 计算四边形的面积
    function calculateArea(v) {
        let area = 0;
        for (let i = 0; i < v.length; i++) {
            let x1 = v[i].x;
            let y1 = v[i].y;
            let x2 = v[(i + 1) % v.length].x;
            let y2 = v[(i + 1) % v.length].y;
            area += (x1 * y2 - x2 * y1);
        }
        return Math.abs(area) / 2;
    }
    let currentArea = calculateArea(vertices);
    // 缩放四边形，使其面积等于range
    let scaleFactor = Math.sqrt(range / currentArea);
    for (let vertex of vertices) {
        vertex.x = pointx + (vertex.x - pointx) * scaleFactor;
        vertex.y = pointy + (vertex.y - pointy) * scaleFactor;
    }
    // 返回四个顶点的坐标
    return vertices;
}
let range = 16; // 面积
let pointx = 10; // 点的x坐标
let pointy = 10; // 点的y坐标
let seed = 123456; // 6位整数种子
let quadrilateral = generateQuadrilateral(range, pointx, pointy, seed);
console.log(quadrilateral);