function newLiquid(name) {
	exports[name] = (() => {
		let myLiquid = extend(Liquid, name, {});
		return myLiquid;
	})();
}
newLiquid("盐水")
newLiquid("芳香烃")
newLiquid("乙醇")
newLiquid("杂酚")
newLiquid("氨气")
newLiquid("硫酸")
newLiquid("硝酸")
newLiquid("氧气")
newLiquid("氟气")
newLiquid("一氧化碳")
newLiquid("硅烷")
newLiquid("乙烯")
newLiquid("烷烃")
newLiquid("燃油")
newLiquid("沥青")
newLiquid("高硫石油")
newLiquid("反应堆废料")
newLiquid("反应堆废料2")
newLiquid("反应堆废料3")
newLiquid("六氟化钚")
newLiquid("微生物悬浊液")
newLiquid("生物质")
newLiquid("毒泥浆")
newLiquid("尿素")
newLiquid("肼")
newLiquid("稀土络合物")
newLiquid("羰基硫")
newLiquid("高压蒸汽")