//AdvancedBuildLib  高级建筑库
//作者:cuso4 - 格雷工业
//使用前必须经作者同意，否则即为侵权
//todo:heat
//todo:mapping of "or"
//todo:laser system
//todo:error display
function getbyname(name){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
function aver(a){
    var s = 0
    for (var i=0;i<a.length;i++){
        s=s+a[i]
    }
    return s/a.length
}
function chance(p){
    return Math.floor(Math.random()*1000)<=p*1000
}                      //p=(0,1]


module.exports={ advanced(name,recipes,map){
    //获取配方
    var Recipes=[]
    for (var i=0;i<recipes.length;i++){
        var recs={
            input:{
                item:[],
                liquid:[],
                oritem:[],
                orliquid:[],
                boostliquid:[],
                heat:0,
                power:0,
                tem:0,
                reqcat:false,
                cat:[]
            },
            output:{
                item:[],
                liquid:[],
                productitem:[],
                productliquid:[],
                result:[],
                resultBoostFromOrLiquid:[],
                resultBoostFromOrItem:[],
                heat:0,
                power:0
            },
            crafttime:60,
            detail:""
        }
        var rec=recipes[i]
        var inputf=rec.input
        var outputf=rec.output
        var itemf=inputf.item
        var liquidf=inputf.liquid
        var oritemf=inputf.oritem
        var orliquidf=inputf.orliquid
        var resultBoostFromOrItemf=outputf.resultBoostFromOrItem
        var resultBoostFromOrLiquidf=outputf.resultBoostFromOrLiquid
        if (itemf!=null){
            for (var j=0;j<itemf.length;j++){
                recs.input.item.push({item:Vars.content.getByName(ContentType.item,itemf[j].split("/")[0]),amo:itemf[j].split("/")[1]})
            }
        }
        if (liquidf!=null){
            for (var j=0;j<liquidf.length;j++){
                recs.input.liquid.push({liquid:Vars.content.getByName(ContentType.liquid,liquidf[j].split("/")[0]),amo:liquidf[j].split("/")[1]})
            }
        }
        if (oritemf!=null){
            for (var j=0;j<oritemf.length;j++){
                recs.input.oritem.push({item:Vars.content.getByName(ContentType.item,oritemf[j].split("/")[0]),amo:oritemf[j].split("/")[1]})
            }
        }
        if (orliquidf!=null){
            for (var j=0;j<orliquidf.length;j++){
                recs.input.orliquid.push({liquid:Vars.content.getByName(ContentType.liquid,orliquidf[j].split("/")[0]),amo:orliquidf[j].split("/")[1]})
            }
        }
        var itemf=outputf.item
        var liquidf=outputf.liquid
        var resultf=outputf.result
        var productitemf=outputf.productitem
        var productliquidf=outputf.productliquid
        if (itemf!=null){
            for (var j=0;j<itemf.length;j++){
                recs.output.item.push({item:Vars.content.getByName(ContentType.item,itemf[j].split("/")[0]),amo:itemf[j].split("/")[1]})
            }
        }
        if (liquidf!=null){
            for (var j=0;j<liquidf.length;j++){
                recs.output.liquid.push({liquid:Vars.content.getByName(ContentType.liquid,liquidf[j].split("/")[0]),amo:liquidf[j].split("/")[1]})
            }
        }
        if (resultf!=null){
            for (var j=0;j<resultf.length;j++){
                recs.output.result.push({item:Vars.content.getByName(ContentType.item,resultf[j].split("/")[0]),amo:resultf[j].split("/")[1]})
            }
        }
        if (productitemf!=null){
            for (var j=0;j<productitemf.length;j++){
                recs.output.productitem.push({item:Vars.content.getByName(ContentType.item,productitemf[j].split("/")[0]),amo:productitemf[j].split("/")[1]})
            }
        }
        if (productliquidf!=null){
            for (var j=0;j<productliquidf.length;j++){
                recs.output.productliquid.push({liquid:Vars.content.getByName(ContentType.liquid,productliquidf[j].split("/")[0]),amo:productliquidf[j].split("/")[1]})
            }
        }
        if (inputf.power!=null){
            recs.input.power=inputf.power
        }
        if (inputf.tem!=null){
            recs.input.tem=inputf.tem
        }
        if (inputf.cat!=null){
            for (var j=0;j<inputf.cat.length;j++){
                recs.input.cat.push({item:Vars.content.getByName(ContentType.item,inputf.cat[j].split("/")[0]),amo:inputf.cat[j].split("/")[1]})
            }
        }
        if (inputf.reqcat!=null){
            recs.input.reqcat=inputf.reqcat
        }
        if (resultBoostFromOrItemf!=null){
            recs.output.resultBoostFromOrItem=resultBoostFromOrItemf
        }
        if (resultBoostFromOrLiquidf!=null){
            recs.output.resultBoostFromOrLiquid=resultBoostFromOrLiquidf
        }
        if (inputf.heat!=null){
            recs.input.heat=inputf.heat
        }
        if (outputf.power!=null){
            recs.output.power=outputf.power
        }
        if (outputf.heat!=null){
            recs.output.heat=outputf.heat
        }
        if (rec.crafttime!=null){
            recs.crafttime=rec.crafttime
        }
        if (rec.detail!=null){
            recs.detail=rec.detail
        }
        Recipes.push(recs)
    }
    var block=extend(GenericCrafter,name,
{
//block
getrecm(){
    return Recipes
},
turnstr(str,type){
    if (type=="item"){
    return {item:Vars.content.getByName(ContentType.item,str.split("/")[0]),amount:str.split("/")[1]}}
    if (type=="liquid"){
    return {liquid:Vars.content.getByName(ContentType.liquid,str.split("/")[0]),amount:str.split("/")[1]}}
},
checkliquid(){
    for (var i=0;i<recipes.length;i++){
        var rec=recipes[i]
        if (rec.input.liquid!=null){
            return true
        }
        if (rec.input.orliquid!=null){
            return true
        }
        if (rec.output.liquid!=null){
            return true
        }
        if (rec.output.productliquid!=null){
            return true
        }
    }
},
checkitem(){
    for (var i=0;i<recipes.length;i++){
        var rec=recipes[i]
        if (rec.input.item!=null){
            return true
        }
        if (rec.input.oritem!=null){
            return true
        }
        if (rec.output.item!=null){
            return true
        }
        if (rec.output.productitem!=null){
            return true
        }
        if (rec.output.result!=null){
            return true
        }
    }
},
checkpower(){
    var powerf=[]
    for (var i=0;i<recipes.length;i++){
        var rec=recipes[i]
        if (rec.input.power>0){
            powerf[0]=true
        }
        if (rec.output.power>0){
            powerf[1]=true
        }
    }
    return powerf
},
init(){
    this.consumeBuilder.add(extend(ConsumePower, {
        requestedPower(e) {
                var power=e.getRec().input.power
                if (!e.getchecks()){
                        return 0
                }
                return e.realpower()
            }
        }))
        if (this.checkpower()[0]){
            this.consumesPower=true
        }
        if (this.checkpower()[1]){
            this.outputsPower=true
        }
        if (this.checkpower()[0] || this.checkpower()[1]){
            this.hasPower = true
        }
        if (this.checkitem()){
            this.hasItems=true
            if (!this.itemCapacity>0){
                this.itemCapacity=20
            }
        }
        if (this.checkliquid()){
            this.hasLiquids=true
            if (!this.liquidCapacity>0){
                this.liquidCapacity=20
            }
        }
        if (recipes.length>1){
            this.configurable=true
        }
        this.super$init();
},
setBars() {
	this.super$setBars();
	this.removeBar("liquid")
	this.removeBar("items")
    if (this.checkpower()[1]){
        this.addBar("poweroutput", e => new Bar(() => Core.bundle.format("bar.poweroutput", e.getPowerProduction()*60* e.timeScale), () => Pal.powerBar, () => e.getPowerProduction()*60/e.getRec().output.power))
    }
	if (!this.foldBar){
	var len=recipes.length
	var stack=[]
    for (var i=0;i<len;i++){
	    var rec=recipes[i]
	    var liquidf=rec.input.liquid
	    if (liquidf!=null){
	    for (var j=0;j<liquidf.length;j++){
	        var li=this.turnstr(liquidf[j],"liquid").liquid
	        if (!stack.some(obj => obj.name==li.name)){
	            stack.push(li)
	        }
	    }
	    }
	    liquidf=rec.input.orliquid
	    if (liquidf!=null){
	    for (var j=0;j<liquidf.length;j++){
	        var li=this.turnstr(liquidf[j],"liquid").liquid
	        if (!stack.some(obj => obj.name==li.name)){
	            stack.push(li)
	        }
	    }
	    }
	    liquidf=rec.output.liquid
	    if (liquidf!=null){
	    for (var j=0;j<liquidf.length;j++){
	        var li=this.turnstr(liquidf[j],"liquid").liquid
	        if (!stack.some(obj => obj.name==li.name)){
	            stack.push(li)
	        }
	    }
	    }
	    liquidf=rec.output.productliquid
	    if (liquidf!=null){
	    for (var j=0;j<liquidf.length;j++){
	        var li=this.turnstr(liquidf[j],"liquid").liquid
	        if (!stack.some(obj => obj.name==li.name)){
	            stack.push(li)
	        }
	    }
	    }
    }
    for (var i=0;i<stack.length;i++){
    (function(i,self){
		self.addBar("liquid"+i, func(e => new Bar(
			prov(() => stack[i].toString()),
			prov(() => stack[i].color),
			floatp(() => e.liquids.get(stack[i])/e.block.liquidCapacity)
		)))
    })(i,this)}
    }
    if (this.foldBar){
       this.addBar("输入", e => new Bar(() => "输入", () => Color.valueOf("ffd06d"), () => e.getliquidbar()[0]))
        this.addBar("输出", e => new Bar(() => "输出", () => Color.valueOf("ffff00"), () => e.getliquidbar()[1]))        
    }
},
setStats() {
    this.super$setStats()
    this.stats.remove(Stat.productionTime);
    this.stats.remove(Stat.powerUse)
    var basecolor=this.colorStat
if (basecolor==null){
    basecolor=Color.valueOf("96c8fa")
}
    this.stats.add(Stat.input, new JavaAdapter(StatValue,{
        display(table){
function turnstr(str,type){
    if (type=="item"){
    return {item:Vars.content.getByName(ContentType.item,str.split("/")[0]),amount:str.split("/")[1]}}
    if (type=="liquid"){
    return {liquid:Vars.content.getByName(ContentType.liquid,str.split("/")[0]),amount:str.split("/")[1]}}
}
table.row()
for (var i=0;i<recipes.length;i++){
    var rec=recipes[i]
    var colors=rec.color
    if (colors==null){
        colors=basecolor
    }
    table.table(Core.scene.getStyle(Button.ButtonStyle).up, t => {
        if (rec.detail!=null){
            t.add("[lightgray]"+rec.detail).expandX().left().row()
        }
        t.add("[accent]输入").expandX().left().row()
        var inputf=rec.input
        var outputf=rec.output
        var itemf=inputf.item
        var liquidf=inputf.liquid
        var oritemf=inputf.oritem
        var orliquidf=inputf.orliquid
        var power=inputf.power
        var heat=inputf.heat
        var crafttime=rec.crafttime
        if (crafttime==null){
            crafttime=60
        }
        t.table(cons(b => {
            if (itemf!=null || liquidf!=null){
                b.add("[lightgray]输入 ")
            }
            if (itemf!=null){
                for (var j=0;j<itemf.length;j++){
                    b.add(new ItemDisplay(turnstr(itemf[j],"item").item,turnstr(itemf[j],"item").amount,crafttime,true))
        }
                b.add(" ")
        }
            if (liquidf!=null){
                for (var j=0;j<liquidf.length;j++){
                    b.add(new LiquidDisplay(turnstr(liquidf[j],"liquid").liquid,turnstr(liquidf[j],"liquid").amount*60/crafttime,true))
        }
        }
        })).left().row()
        t.table(cons(b => {
            if (oritemf!=null || orliquidf!=null){
                b.add("[lightgray]可选输入 ")
            }            
            if (oritemf!=null){
                for (var j=0;j<oritemf.length;j++){
                    if (j>=1){
                        b.add(" [white]/ ")
                    }
                    b.add(new ItemDisplay(turnstr(oritemf[j],"item").item,turnstr(oritemf[j],"item").amount,crafttime,true))
                }
            }
            if (orliquidf!=null){
                for (var j=0;j<orliquidf.length;j++){
                    if (j>=1){
                        b.add(" [white]/ ")
                    }
                    b.add(new LiquidDisplay(turnstr(orliquidf[j],"liquid").liquid,turnstr(orliquidf[j],"liquid").amount*60/crafttime,true))
                }
        }  
        })).left().row()
        t.table(cons(b => {
            if (power>0){
            b.add("[lightgray]" + Stat.powerUse.localized() + ":[]").padRight(4);
            (StatValues.number(power*60, StatUnit.powerSecond)).display(b)
            }
        })).left().row()
        t.row()
        if (map.tem){
        t.table(cons(b => {
            if (inputf.tem!=null){
                b.add("[accent]炉温: "+inputf.tem)
            }            
        })).left().row() 
        }
        if (map.cat){
        t.table(cons(b => {
            if (inputf.cat!=null){
                var catf=inputf.cat
                b.add("[accent]催化剂: ")
                if (inputf.reqcat){
                    b.add("[accent]必需催化剂! ")
                }
                for (var j=0;j<catf.length;j++){
                b.add(new ItemDisplay(turnstr(catf[j],"item").item,0,true))
                b.add(" "+turnstr(catf[j],"item").amount*100+"%")
                }
            }            
        })).left().row()             
        }
        t.row()
        itemf=outputf.item
        liquidf=outputf.liquid
        var productitemf=outputf.productitem
        var productliquidf=outputf.productliquid
        var result=outputf.result
        var power=outputf.power
        var heat=outputf.heat
        t.add("[accent]输出").expandX().left().row()
        t.table(cons(b => {
            if (itemf!=null || liquidf!=null){
                b.add("[lightgray]输出 ")
            }
            if (itemf!=null){
                for (var j=0;j<itemf.length;j++){
                    b.add(new ItemDisplay(turnstr(itemf[j],"item").item,turnstr(itemf[j],"item").amount,crafttime,true))
        }
                b.add(" ")
        }
            if (liquidf!=null){
                for (var j=0;j<liquidf.length;j++){
                    b.add(new LiquidDisplay(turnstr(liquidf[j],"liquid").liquid,turnstr(liquidf[j],"liquid").amount*60/crafttime,true))
        }
        }
        })).left().row()
        t.table(cons(b => {
            if (productitemf!=null || productliquidf!=null){
                b.add("[lightgray]副产")
            }            
            if (productitemf!=null){
                for (var j=0;j<productitemf.length;j++){
                    b.add(" ")
                    b.add(new ItemDisplay(turnstr(productitemf[j],"item").item,turnstr(productitemf[j],"item").amount,crafttime,true))
                }
            }
            if (productliquidf!=null){
                for (var j=0;j<productliquidf.length;j++){
                    b.add(new LiquidDisplay(turnstr(productliquidf[j],"liquid").liquid,turnstr(productliquidf[j],"liquid").amount*60/crafttime,true))
                }
        }  
        })).left().row()
        t.table(cons(b => {
            if (result!=null){
                b.add("[lightgray]产物")
                for (var j=0;j<result.length;j++){
                    if (j>=1){
                        b.add(" [white]/ ")
                    }
                    b.add(new ItemDisplay(turnstr(result[j],"item").item,0,true))
                    b.add(" "+r(turnstr(result[j],"item").amount*100,2)+"%")
        }
                /*var boostmap=rec.output.resultBoostFromOrLiquid
                if (boostmap!=null){
                for (var j=0;j<result.length;j++){
            for (var m=0;m<boostmap.length;m++){
            var boost=boostmap[m]
            if (boost.For==turnstr(result[j],"item").item.name){
                var p=turnstr(result[j],"item").amount*boost.boost
                b.row()
                b.table(cons(h=>{
                h.add("("+r(p*100,2)+"%使用"+getbyname(boost.From).name+"时)").left()
                }))
            }
            }
        }}*/
            }
        })).left().row()
        t.table(cons(b => {
            if (power>0){
            b.add("[lightgray]" + Stat.basePowerGeneration.localized() + ":[]").padRight(4);
            (StatValues.number(power*60, StatUnit.powerSecond)).display(b)
            }
        })).left().row()
        t.table(cons(b => {
            b.add("[lightgray]" + Stat.productionTime.localized() + ":[]").padRight(4);
            (StatValues.number(crafttime/60, StatUnit.seconds)).display(b);
        })).left().row()
    }).color(colors).left().growX().row()
}
        }}))
},
ABL(){
    return true
},
returnignoreResultOnFull(){
    return this.ignoreResultOnFull
},
returndata(){
    return this.data
},

})
    block.buildType = prov(() => {
//this

    var tog=0
    var timer=0
    var tem=1000
    //配方转化
    var process=[]
    for (var i=0;i<Recipes.length;i++){
        process[i]=0
    }
    var processsave=0
    
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, 
{
//bulid

buildConfiguration(table){
    var len=this.rlen()
    this.super$buildConfiguration(table)
    var group = new ButtonGroup()
    group.setMinCheckCount(0)
    group.setMaxCheckCount(1)
    table.pane(t=>{
    for (var i=0;i<len;i++){
    (function(i,self){
        var rec=self.getr(i)
        //获取图标
        var icon=Icon.cancel
        if (rec.input!=null){
            var inputf=rec.input
            if (inputf.orliquid!=null){
                var liquidf=self.turnstr(inputf.orliquid[0],"liquid").liquid
                icon=liquidf.uiIcon
            }
            if (inputf.oritem!=null){
                var itemf=self.turnstr(inputf.oritem[0],"item").item
                icon=itemf.uiIcon
            }
            if (inputf.liquid!=null){
                var liquidf=self.turnstr(inputf.liquid[0],"liquid").liquid
                icon=liquidf.uiIcon
            }
            if (inputf.item!=null){
                var itemf=self.turnstr(inputf.item[0],"item").item
                icon=itemf.uiIcon
            }
        }
        if (rec.output!=null){
            var outputf=rec.output
            if (outputf.power>0){
                icon=Icon.power
            }
            if (outputf.heat>0){
                icon=Icon.wavesSmall
            }
            if (outputf.result!=null){
                var itemf=self.turnstr(outputf.result[0],"item").item
                icon=itemf.uiIcon
            }
            if (outputf.productliquid!=null){
                var liquidf=self.turnstr(outputf.productliquid[0],"liquid").liquid
                icon=liquidf.uiIcon
            }
            if (outputf.productitem!=null){
                var itemf=self.turnstr(outputf.productitem[0],"item").item
                icon=itemf.uiIcon
            }
            if (outputf.liquid!=null){
                var liquidf=self.turnstr(outputf.liquid[0],"liquid").liquid
                icon=liquidf.uiIcon
            }
            if (outputf.item!=null){
                var itemf=self.turnstr(outputf.item[0],"item").item
                icon=itemf.uiIcon
            }
        }
        if (typeof rec.icon==="function"){
            icon=rec.icon()
        }
        //按钮设置
        var button = t.button(Tex.pane,25,() => {
            self.settog(i)
            self.configure(i)
        }).group(group).get()
        button.getStyle().imageUp = new TextureRegionDrawable(icon)
        })(i,this)
    }
    }).size(180,50)
    table.row()
    //获取配方表
    function getdisplay(self,t){
        var rec=self.getr(t)
        var display={input:[],output:[]}
        if (rec.input!=null){
            var inputf=rec.input
            if (inputf.item!=null){
                var items=inputf.item
                for (var i=0;i<items.length;i++){
                    var itemf=self.turnstr(items[i],"item").item
                    display.input.push(itemf.uiIcon)
                }
            }
            if (inputf.liquid!=null){
                var liquids=inputf.liquid
                for (var i=0;i<liquids.length;i++){
                    var liquidf=self.turnstr(liquids[i],"liquid").liquid
                    display.input.push(liquidf.uiIcon)
                }
            }
        }
        if (rec.output!=null){
            var outputf=rec.output
            if (outputf.item!=null){
                var items=outputf.item
                for (var i=0;i<items.length;i++){
                    var itemf=self.turnstr(items[i],"item").item
                    display.output.push(itemf.uiIcon)
                }
            }
            if (outputf.productitem!=null){
                var items=outputf.productitem
                for (var i=0;i<items.length;i++){
                    var itemf=self.turnstr(items[i],"item").item
                    display.output.push(itemf.uiIcon)
                }
            }
            if (outputf.liquid!=null){
                var liquids=outputf.liquid
                for (var i=0;i<liquids.length;i++){
                    var liquidf=self.turnstr(liquids[i],"liquid").liquid
                    display.output.push(liquidf.uiIcon)
                }
            }
            if (outputf.productliquid!=null){
                var liquids=outputf.productliquid
                for (var i=0;i<liquids.length;i++){
                    var liquidf=self.turnstr(liquids[i],"liquid").liquid
                    display.output.push(liquidf.uiIcon)
                }
            }
            if (outputf.power>0){
                display.output.push(Icon.power)
            }
            if (outputf.heat>0){
                display.output.push(Icon.wavesSmall)
            }
        }
        return display
    }
    function displayor(tables,self,t){
        var rec=self.getr(t).input
        if (rec.oritem!=null){
        tables.pane(panes=>{
	        for (var i=0;i<rec.oritem.length;i++){
	            panes.add(Image(self.turnstr(rec.oritem[i],"item").item.uiIcon)).size(30).row()
	        }
	    }).size(70,40)}
	    if (rec.orliquid!=null){
        tables.pane(panes=>{
	        for (var i=0;i<rec.orliquid.length;i++){
	            panes.add(Image(self.turnstr(rec.orliquid[i],"liquid").liquid.uiIcon)).size(30).row()
	        }
	    }).size(70,40)}
    }
    function displayresult(tables,self,t){
        var rec=self.getr(t).output
        if (rec.result!=null){
        tables.pane(panes=>{
	        for (var i=0;i<rec.result.length;i++){
	            panes.add(Image(self.turnstr(rec.result[i],"item").item.uiIcon)).size(30).row()
	        }
	    }).size(70,40)}
    }
    //配方表设置
    for (var j=0;j<len;j++){
    (function(j,self){
	table.collapser(b => {
	b.pane(m=>{
	    var display=getdisplay(self,j).input
	    for (var k=0;k<display.length;k++){
	        m.add(Image(display[k])).size(35)
	    }
	    displayor(m,self,j)
	    m.add(Image(Icon.right)).size(35)
	    display=getdisplay(self,j).output
	    for (var k=0;k<display.length;k++){
	        m.add(Image(display[k])).size(35)
	    }
	    displayresult(m,self,j)
	}).size(180,40)
	}, () => (j==self.gettog())).row()
    })(j,this)}
    //炉温设定
    if (map.tem){
    table.button("温度", Icon.infoCircle, run(() => {
    var dialog = new BaseDialog("温度");
    dialog.cont.pane(table => {
        table.add("炉温"+": "+this.tem()).update(t => {
		t.setText("炉温: "+this.tem())})
        table.row()
        table.add("[yellow]!温度过低!").update(t => {
		if (this.temmul()<1){
		t.setText("[yellow]!温度过低!")}
		else{t.setText("温度正常")}
	})
		table.row()
        table.add("耗电:"+r(this.realpower()*60,0)).update(t => {
t.setText("耗电:"+r(this.realpower()*60,0))})
        table.row()
        table.add(" ").update(t => {
            if (this.temmul()<=1){
                t.setText(" ")}
            else{
				t.setText("[yellow]超频中: "+r(this.temmul()*100,0)+"%")}
			})
        table.row()
        table.add(" ")
        table.row()
        table.add("炉温调节")
        table.row()
		table.slider(200,3200, 200,this.tem(),lw => {this.settem(lw)}).width(300);
		table.row()
		table.button("", Icon.up, run(() => {if (this.tem()<3200){this.settem(this.tem()+200)}})).size(70, 70);
		table.row()
		table.button("", Icon.down, run(() => {if (this.tem()>200){this.settem(this.tem()-200)}})).size(70, 70);		
            })
        dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128);
        dialog.show()
        })).size(100, 50)}
},
//接受
acceptItem(source,item){
    var itemf=this.turnstack(this.getRec().input.item,"item")
    var oritemf=this.turnstack(this.getRec().input.oritem,"item")
    var catf=this.turnstack(this.getRec().input.cat,"item")
    if (this.items.get(item)<this.getMaximumAccepted(item)){
        if (itemf.some(obj => obj.name==item.name)){
            return true
        }
        if (oritemf.some(obj => obj.name==item.name)){
            return true
        }
        if (map.cat){
            if (catf.some(obj => obj.name==item.name)){
            return true
        }
        }
    }
},
acceptLiquid(source,liquid){
    var liquidf=this.turnstack(this.getRec().input.liquid,"liquid")
    var orliquidf=this.turnstack(this.getRec().input.orliquid,"liquid")
    if (this.liquids.get(liquid)<this.block.liquidCapacity){
        if (liquidf.some(obj => obj.name==liquid.name)){
            return true
        }
        if (orliquidf.some(obj => obj.name==liquid.name)){
            return true
        }        
    }
},
//检查条件
checkcraft(){
    return this.checkinput() && this.checkoutput()
},
checkinput(){
    return this.checkinitem() && this.checkinliquid() && this.checkinoritem() && this.checkinorliquid() &&this.checktem() &&this.checkcat()
},
checkinitem(){
    var itemf=this.getRec().input.item
    for (var i=0;i<itemf.length;i++){
        if (this.items.get(itemf[i].item)<itemf[i].amo){
            return false
        }
    }
    return true
},
checkinliquid(){
    var rec=this.getRec()
    var liquidf=rec.input.liquid
    for (var i=0;i<liquidf.length;i++){
        if (this.liquids.get(liquidf[i].liquid)<liquidf[i].amo*this.liquiddelta()/rec.crafttime){
            return false
        }
    }
    return true
},
checkinoritem(){
    var oritemf=this.getRec().input.oritem
    if (oritemf.length==0){
        return true
    }
    if (this.getfirstoritem()!=null){
        return true
    }
    return false
},
checkinorliquid(){
    var rec=this.getRec()
    var orliquidf=rec.input.orliquid
    if (orliquidf.length==0){
        return true
    }
    if (this.getfirstorliquid()!=null){
        return true
    }
    return false
},
checkoutput(){
    return this.checkoutitem() && this.checkoutliquid() &&this.checkresult()
},
checkoutitem(){
    var itemf=this.getRec().output.item
    for (var i=0;i<itemf.length;i++){
        if (this.items.get(itemf[i].item)>this.getMaximumAccepted(itemf[i].item)-itemf[i].amo){
            return false
        }
    }
    return true
},
checkoutliquid(){
    var liquidf=this.getRec().output.liquid
    for (var i=0;i<liquidf.length;i++){
        if (this.liquids.get(liquidf[i].liquid)>this.block.liquidCapacity-(liquidf[i].amo*this.liquiddelta()/rec.crafttime)){
            return false
        }
    }
    return true
},
checkresult(){
    if (this.block.returnignoreResultOnFull() || this.getr(this.gettog()).ignoreResultOnFull){
        return true
    }
    var resultf=this.getRec().output.result
    var total=0
    for (var i=0;i<resultf.length;i++){
        total+=this.items.get(resultf[i].item)
        if (total>=this.block.itemCapacity){
            return false
        }
    }
    return true
},
getfirstoritem(){
    var itemf=this.getRec().input.oritem
    for (var i=0;i<itemf.length;i++){
        if (this.items.get(itemf[i].item)>=itemf[i].amo){
            return itemf[i]
        }
    }
    return null
},
getfirstorliquid(){
    var rec=this.getRec()
    var liquidf=rec.input.orliquid
    for (var i=0;i<liquidf.length;i++){
        if (this.liquids.get(liquidf[i].liquid)>=liquidf[i].amo*this.liquiddelta()/rec.crafttime){
            return liquidf[i]
        }
    }
    return null
},
checktem(){
    if (map.tem){
        return this.temmul()>=1
    }
    return true
},
checkcat(){
    if (map.cat){
        if (this.getRec().input.cat==null){
            return true
        }
        if (this.getRec().input.reqcat){
            return this.hascat()
        }
        return true
    }
    return true
},
//处理生产
handlecraft(){
    if (this.getprocess()==0){
        this.itemconsume()
    }
    this.liquidconsume()
    this.liquidproduce()
    this.addprocess()
    if (this.getprocess()>=this.getRec().crafttime){
        if (this.geteffect()!=null){
            this.geteffect().at(this.x, this.y)
        }
        this.itemproduce()
        this.setprocess(0)
    }
},
itemconsume(){
    var itemf=this.getRec().input.item
    var oritemf=this.getfirstoritem()
    for (var i=0;i<itemf.length;i++){
        this.items.remove(itemf[i].item,itemf[i].amo)
    }
    if (oritemf!=null){
        this.items.remove(oritemf.item,oritemf.amo)
    }
},
liquidconsume(){
    var rec=this.getRec()
    var liquidf=rec.input.liquid
    var orliquidf=this.getfirstorliquid()
    for (var i=0;i<liquidf.length;i++){
        this.liquids.remove(liquidf[i].liquid,liquidf[i].amo*this.liquiddelta()/rec.crafttime)
    }
    if (orliquidf!=null){
        this.liquids.remove(orliquidf.liquid,orliquidf.amo*this.liquiddelta()/rec.crafttime)
    }
},
itemproduce(){
    var rec=this.getRec()
    var itemf=rec.output.item
    var resultf=rec.output.result
    var product=rec.output.productitem
    for (var i=0;i<itemf.length;i++){
        for (var j=0;j<itemf[i].amo;j++){
        this.offload(itemf[i].item)
        }
    }
    for (var i=0;i<product.length;i++){
        if (this.items.get(product[i].item)<=this.block.itemCapacity-product[i].amo){
            for (var j=0;j<product[i].amo;j++){
        this.offload(product[i].item)
        }
        }
    }
    for (var i=0;i<resultf.length;i++){
        if (this.items.get(resultf[i].item)<=this.block.itemCapacity-1){
            var p=resultf[i].amo
            var boostmap=rec.output.resultBoostFromOrLiquid
            /*if (boostmap.length>0){
            var boost=boostmap[i]
            if (boost.From==this.getfirstorliquid().liquid.name){
            if (boost.For==resultf[i].item.name){
                p*=boost.boost
            }
            }
            }*/
            if (chance(p)){
                this.offload(resultf[i].item)
            }
        }
    }
},
liquidproduce(){
    var rec=this.getRec()
    var liquidf=rec.output.liquid
    var product=rec.output.productliquid
    for (var i=0;i<liquidf.length;i++){
        this.liquids.add(liquidf[i].liquid,liquidf[i].amo*this.liquiddelta()/rec.crafttime)
    }
    for (var i=0;i<product.length;i++){
        if (this.liquids.get(product[i].liquid)<=this.block.liquidCapacity-(product[i].amo/rec.crafttime)){
            this.liquids.add(product[i].liquid,product[i].amo*this.liquiddelta()/rec.crafttime)
        }
    }
},
//处理
dumpoutput(){
    var output=this.getRec().output
    for (var i=0;i<output.item.length;i++){
        this.dump(output.item[i].item)
    }
    for (var i=0;i<output.result.length;i++){
        this.dump(output.result[i].item)
    }
    for (var i=0;i<output.liquid.length;i++){
        this.dumpLiquid(output.liquid[i].liquid)
    }
    for (var i=0;i<output.productliquid.length;i++){
        this.dumpLiquid(output.productliquid[i].liquid)
    }
},
getPowerProduction(){
    if (this.check){
        return this.getRec().output.power*this.efficiency
    }
    else {return 0}
},
handlewarmup(bool){
    if (bool){
        this.warmup=Mathf.lerpDelta(this.warmup,1,0.02*this.block.warmupSpeed)
    }
    else {
        this.warmup=Mathf.lerpDelta(this.warmup,0,0.02*this.block.warmupSpeed)
    }
},
//执行
updateTile(){
    this.handletimer()
    this.check=this.checkcraft()
    if (this.check && this.power.status>0){
        this.handlecraft()
        this.handlewarmup(true)
    }
    else {this.handlewarmup(false)}
    this.dumpoutput()
    /*if (!this.init){this.init=true}*/
},
//方法
handletimer(){
    timer++
    if (timer>=60){
    timer=0}
},
rlen(){
    return recipes.length
},
getr(t){
    return recipes[t]
},
getRec(){
    return Recipes[this.gettog()]
},
getrinput(t){
    return this.getr(t).input
},
getroutput(t){
    return this.getr(t).output
},
processincrease(){
    return this.getProgressIncrease(60)*60*this.warmup*this.getboost()
},
getprocess(){
    return process[this.gettog()]
},
addprocess(){
    process[this.gettog()]+=this.processincrease()
},
setprocess(m){
    process[this.gettog()]=m
},
realpower(){
    var power=this.getRec().input.power
    var powermul = 0.5
    var effmul = 0.8
    if (map.tem){
        return Math.pow(2,((this.tem()/200)-1)*effmul/5)*this.tem()*powermul/60
    }
    return power
},
liquiddelta(){
    return this.processincrease()
},
geteffect(){
    var effect= this.getr(this.gettog()).crafteffect
    if (effect!=null){
        return effect
    }
    return this.block.craftEffect
},
turnstr(str,type){
    if (type=="item"){
    return {item:Vars.content.getByName(ContentType.item,str.split("/")[0]),amount:str.split("/")[1]}}
    if (type=="liquid"){
    return {liquid:Vars.content.getByName(ContentType.liquid,str.split("/")[0]),amount:str.split("/")[1]}}
},
turnstack(stack,type){
    if (type=="item"){
    var items=[]
    for (var i=0;i<stack.length;i++){
        items.push(stack[i].item)
    }
    return items}
    if (type=="liquid"){
    var liquids=[]
    for (var i=0;i<stack.length;i++){
        liquids.push(stack[i].liquid)
    }
    return liquids}
},
displayor1(array,table,time){
    var len=array.length
    var del=60/len
    var display=array[0]
    for (var i=0;i<len;i++){
        if (time>del*i&&time<del*(i+1)){display=array[i]}}
    return Image(display)
},
getliquidbar(){
    var inputf=this.getRec().input
    var outputf=this.getRec().output
    var inputarr=[]
    var outputarr=[]
    for (var i=0;i<inputf.liquid.length;i++){
        var inf=inputf.liquid[i]
        inputarr.push(this.liquids.get(inf.liquid)/this.block.liquidCapacity)
    }
    if (inputf.orliquid.length>0){
        var orinf=this.getfirstorliquid()
        if (orinf!=null){
            inputarr.push(this.liquids.get(orinf.liquid)/this.block.liquidCapacity)
        }
        if (orinf==null){
            inputarr.push(0)
        }
    }
    for (var i=0;i<outputf.liquid.length;i++){
        var outf=outputf.liquid[i]
        outputarr.push(this.liquids.get(outf.liquid)/this.block.liquidCapacity)
    }
    for (var i=0;i<outputf.productliquid.length;i++){
        var outf=outputf.productliquid[i]
        outputarr.push(this.liquids.get(outf.liquid)/this.block.liquidCapacity)
    }
    inputf=aver(inputarr)
    outputf=aver(outputarr)
    return [inputf,outputf]
},
getchecks(){
    return this.check
},
gettog(){
    return tog
},
settog(t){
    tog=t
},
hascat(){
    var catf=this.getRec().input.cat
    if (catf==null){
        return true
    }
    for (var i=0;i<catf.length;i++){
        if (this.items.get(catf[i].item)>0){
            return true
        }
    }
},
catmul(){
    var catf=this.getRec().input.cat
    var boost=[1]
    if (catf==null){
        return 1
    }
    for (var i=0;i<catf.length;i++){
        boost.push(this.items.get(catf[i].item)*catf[i].amo/this.getMaximumAccepted(catf[i].item))
    }
    return Math.max.apply(null,boost)
    
},
getboost(){
    var boost=1
    if (map.tem){
        boost*=this.temmul()
    }
    if (map.cat){
        boost*=this.catmul()
    }
    return boost
},
tem(){
    return tem
},
settem(m){
    tem=m
},
temmul(){
    return this.tem()/this.getRec().input.tem
},
configured(player,value){
    if (value!=null){
        this.settog(value)
    }
},
write(write){
    this.super$write(write)
    write.f(tog)
    var num=process.length
    if (this.block.returndata()!=-1){
        num=this.block.returndata()
    }
    processsave=process[tog]
    write.f(processsave)
    for (var i=0;i<num-1;i++){
        write.f(0)
    }
    if (map.tem){
        write.f(tem)
    }
},
read(read, revision){
    this.super$read(read, revision)
    tog=read.f()
    var num=process.length
    if (this.block.returndata()!=-1){
        num=this.block.returndata()
    }
    process[tog]=read.f()
    for (var i=0;i<num-1;i++){
        read.f()
    }
    if (map.tem){
        tem=read.f()
    }
},
},block)})
    block.getrec=recipes
    block.advanced=true
    //属性
    block.foldBar=false
    block.ignoreResultOnFull=false
    block.data=-1
    block.warmupSpeed=1
    block.saveConfig=true
    block.colorStat=null
    if (map!=null){
        map.map(block)
    }
    return block
}
}

//end
