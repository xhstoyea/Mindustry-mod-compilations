//generator

const mathlib = require("base/MathLib")


//lib
function round(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       
function getSixDigitsAfterDecimal(num){
    let numStr = num.toString();
    let decimalIndex = numStr.indexOf('.');
    let sixDigits = numStr.substring(decimalIndex + 1, decimalIndex + 7);
    return sixDigits;
}
function getSeed(id){
    let seed=Math.PI*id
    seed=getSixDigitsAfterDecimal(seed)
    return seed
}
function Pointgenerate(seed,rangex,rangey){
    let x=mathlib.seedRand(seed+1)
    let y=mathlib.seedRand(seed-1)
    x*=rangex
    y*=rangey
    x+=(rangex/2)
    y+=(rangey/2)
    return [x,y]
}
function setRange(seed,min,max){
    let range=mathlib.seedRand(seed)
    return min+(range*(max-min))
}
function setLayer(seed,min,max){
    let layer=mathlib.seedRand(seed)
    layer=min+(layer*(max-min))
    layer=round(layer,0)
}
function Quadrilateralgenerate(seed,range,center){
    let quad=[]
    for (var i=0;i<4;i++){
        let x=mathlib.seedRand(seed+i)
        let y=mathlib.seedRand(seed-i)
        quad.push([x,y])
    }
    let centerx=(quad[0][0]+quad[1][0]+quad[2][0]+quad[3][0])/4
    let centery=(quad[0][1]+quad[1][1]+quad[2][1]+quad[3][1])/4
    for (var i=0;i<4;i++){
        quad[i][0]-=centerx
        quad[i][1]-=centery
    }
    quad=mathlib.sortpointclock(quad)
    let squ=mathlib.quadSquare(quad)
    let squmul=Math.sqrt(range/squ)
    for (var i=0;i<4;i++){
        quad[i][0]*=squmul
        quad[i][1]*=squmul
    }
    centerx=(quad[0][0]+quad[1][0]+quad[2][0]+quad[3][0])/4
    centery=(quad[0][1]+quad[1][1]+quad[2][1]+quad[3][1])/4
    let addx=center[0]-centerx
    let addy=center[1]-centery
    let addx=0
    let addy=0
    for (var i=0;i<4;i++){
        quad[i][0]+=addx
        quad[i][1]+=addy
        quad[i][0]=round(quad[i][0],0)
        quad[i][1]=round(quad[i][1],0)
    }
    return quad
}
exports.generate=(seed,range,center)=>{
    return Quadrilateralgenerate(seed,range,center)
}
function Singlegenerate(ore,volume,seed,map){
    let center=Pointgenerate(seed,map.rangex,map.rangey)
    let range=setRange(seed,ore.rangemin,ore.rangemax)
    range*=volume
    let quad=Quadrilateralgenerate(seed,range,center)
    let layer=setLayer(seed,ore.layermin,ore.layermax)
    return {pos:quad,type:ore.type,layer:layer,drop:ore.drop}
}