//MathLib

//数学处理---------------------

//种子随机数
//----s----
function seedRand(seed){
    let x = Math.sin(seed) * 10000;
    return x - Math.floor(x);
}
exports.seedRand=(seed)=>{
    return seedRand(seed)
}

//----e----

//几何判断---------------------

//多边形面积
//----s----
function calculateQuadrilateralArea(points) {
    let sum = 0;
    let n = points.length;
    for (let i = 0; i < n; i++) {
        const current = points[i];
        const next = points[(i + 1) % n];
        sum += current[0] * next[1] - next[0] * current[1];
    }
    return Math.abs(sum) / 2;
}
exports.quadSquare=(quad)=>{
    return calculateQuadrilateralArea(quad)
}
//----e----

//判断点是否在四边形内
//----s----
function isPointInQuadrilateral(point, vertices) {
    // vertices 是一个包含四个坐标点的数组，格式为 [[x1, y1], [x2, y2], [x3, y3], [x4, y4]]
    let x = point[0]
    let y = point[1]
    let inside = false;
    for (let i = 0, j = vertices.length - 1; i < vertices.length; j = i++) {
        let xi = vertices[i][0], yi = vertices[i][1];
        let xj = vertices[j][0], yj = vertices[j][1];
        let intersect = ((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
        if (intersect) inside = !inside;
    }
    return inside;
}
exports.pointInQuad=(point,ver)=>{
    return isPointInQuadrilateral(point,ver)
}
//----e----

//顺时针排列点
//----s----
function sortPointsClockwise(points) {
    let getSortKey = (point) => {
        let x = point[0], y = point[1];
        let quadrant;
        if (x >= 0 && y >= 0) quadrant = y === 0 ? 0 : 0;
        else if (x >= 0 && y <= 0) quadrant = 1;
        else if (x <= 0 && y <= 0) quadrant = 2;
        else quadrant = 3;
        let angle = Math.atan2(y, x);
        let clockwiseAngle = (2 * Math.PI - angle) % (2 * Math.PI);
        return { quadrant:quadrant, angle: clockwiseAngle };
    };
    return points.slice().sort((a, b) => {
        let keyA = getSortKey(a);
        let keyB = getSortKey(b);
        if (keyA.quadrant !== keyB.quadrant) {
            return keyA.quadrant - keyB.quadrant;
        }
        return keyA.angle - keyB.angle;
    });
}
exports.sortpointclock=(vertices)=>{
    return sortPointsClockwise(vertices)
}
//----e----