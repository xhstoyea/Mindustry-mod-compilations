function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
//~~~~~~~~~~~~~~~
var r=8
const 引火器 = extend(Router, '引火器', {
    drawPlace(x, y, rotation, valid) {
        Drawf.dashSquare(Pal.accent, x * 8, y * 8, r * 16)
    }, 
});
引火器.configurable = true
引火器.buildType = prov(() => {
    var xx=r,yy=r,endxx=r,endyy=r
    var timer=0
    return new JavaAdapter(Router.RouterBuild, {
    	buildConfiguration(table){
			this.super$buildConfiguration(table)
			table.check("switch", this.enabled, t => {
			    this.enabled=t
			})
			table.row()
            table.add("x:"+(endxx-r)+"  "+"y:"+(endyy-r)).update(t => {t.setText("x:"+(endxx-r)+"  "+"y:"+(endyy-r))})
            table.row()
    	    table.slider(0,r*2,1, endxx,xx => {
			    endxx=xx
			}).width(300)
			table.row()
			table.slider(0,r*2,1, endyy,yy=> {
			    endyy=yy
			}).width(300);
    	},
        updateTile(){
            timer+=this.power.status
            if (timer>=20){
            this.tiles=Vars.world.tile(this.tileX()+endxx-r, this.tileY()+endyy-r)
            Fires.create(this.tiles)
            timer=0
            }
        },
        drawSelect(){
            Drawf.dashSquare(
		        Pal.accent,
		        this.x,this.y,r*16
		    )
        },
    	write(write){
    		this.super$write(write);
    		write.f(endxx)
    		write.f(endyy)
    	},
    	read(read, revision){
    		this.super$read(read, revision);
    		endxx=read.f()
    		endyy=read.f()
    	},
    },引火器);
});
