
const 信号增幅器 = extend(StorageBlock, "信号增幅器", {
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.get(team).getCount(this) < 8
	}
})
const 信号基站 = extend(StorageBlock, "信号基站", {
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.get(team).getCount(this) < 8
	}
})