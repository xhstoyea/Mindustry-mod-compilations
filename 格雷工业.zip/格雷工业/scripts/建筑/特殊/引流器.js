
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
//~~~~~~~~~~~~~~~
var r=8
const 引流器 = extend(LiquidRouter, '引流器', {
    drawPlace(x, y, rotation, valid) {
        Drawf.dashSquare(Pal.accent, x * 8, y * 8, r * 16)
    }, 
});
引流器.configurable = true
引流器.buildType = prov(() => {
    var xx=r,yy=r,endxx=r,endyy=r
    var timer=0
    return new JavaAdapter(LiquidRouter.LiquidRouterBuild, {
    	buildConfiguration(table){
			this.super$buildConfiguration(table)
			table.check("switch", this.enabled, t => {
			    this.enabled=t
			})
			table.row()
            table.add("x:"+(endxx-r)+"  "+"y:"+(endyy-r)).update(t => {t.setText("x:"+(endxx-r)+"  "+"y:"+(endyy-r))})
            table.row()
    	    table.slider(0,r*2,1, endxx,xx => {
			    endxx=xx
			}).width(300)
			table.row()
			table.slider(0,r*2,1, endyy,yy=> {
			    endyy=yy
			}).width(300);
    	},
        updateTile(){
            timer+=this.power.status
            this.li=this.liquids.current()
            this.liamo=this.liquids.get(this.li)
            if (this.liamo>=1 && timer>=6){
            timer=0
            this.liquids.remove(this.li,1)
            this.tiles=Vars.world.tile(this.tileX()+endxx-r, this.tileY()+endyy-r)
            Puddles.deposit(this.tiles,this.li,20)
            }
            if (this.liamo<=1 && this.liamo>0){
            timer=0
            this.liquids.remove(this.li,this.liamo)
            this.tiles=Vars.world.tile(this.tileX()+endxx-r, this.tileY()+endyy-r)
            Puddles.deposit(this.tiles,this.li,20*this.liamo)
            }
        },
        drawSelect(){
            Drawf.dashSquare(
		        Pal.accent,
		        this.x,this.y,r*16
		    )
        },
    	write(write){
    		this.super$write(write);
    		write.f(endxx)
    		write.f(endyy)
    	},
    	read(read, revision){
    		this.super$read(read, revision);
    		endxx=read.f()
    		endyy=read.f()
    	},
    },引流器);
});
