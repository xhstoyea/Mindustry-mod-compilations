//by cuso4
//其实写的是一坨
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
const list=[-1,0,0,-1,1,0,0,1]
//~~~~~~~~~~~~~~~
const 流体装卸器 = extend(GenericCrafter, '流体装卸器', {});
流体装卸器.configurable = true;
流体装卸器.buildType = prov(() => {
    var other
    var others=Vars.content.liquids()   
    var oo
    var conc
    var target
    var current
    var q=[]
    for (var i=0;i<others.size;i++){
        q[i]=others.get(i)}
    var nowliquid = Liquids.water
    var a =0
    var time=0
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
    	buildConfiguration(table){
    	this.super$buildConfiguration(table);
        var group = new ButtonGroup()
        group.setMinCheckCount(0)
        group.setMaxCheckCount(1)
     //   this.super$buildConfiguration(table)
       // var wui = new TextureRegionDrawable(Tex.whiteui)
			table.table(Tex.button,rootTable => {
	    rootTable.add(nowliquid.toString()).update(t => {t.setText(nowliquid.toString())})})
	    table.row()
        table.table(Tex.button,rootTable => {
        for (var i=0,j=-1;i<others.size;i++){
            (function(i){
        if (true){
        j++
        var button = rootTable.button(Tex.pane,32,() => {a=i}).tooltip(q[i].localizedName).group(group).get()
        button.getStyle().up = Styles.black3
        button.getStyle().down = Styles.black3
        button.getStyle().over = Styles.flatOver;
        button.getStyle().checked = Styles.accentDrawable
        button.getStyle().imageUp = new TextureRegionDrawable(q[i].uiIcon)     
        button.update(() => {button.setChecked(i==a)})
            }})(i)
        if(j%4==3){rootTable.row()}}})},
        updateTile(){
            time++
            nowliquid=q[a]
            other = Vars.world.build(this.tileX()+list[this.rotation*2], this.tileY()+list[1+this.rotation*2])
            target = Vars.world.build(this.tileX()-list[this.rotation*2], this.tileY()-list[1+this.rotation*2])
        current=this.liquids.get(nowliquid)
        if (other!=null){
        if (other.block.hasLiquids){
        if (time>=60){other.update()}
        if (current<=19 && other.liquids.get(nowliquid)>=1){
        other.liquids.remove(nowliquid,1)
        this.handleLiquid(this,nowliquid,1)
            }}}
        if (target!=null){
        if (target.block.hasLiquids){
        if (time>=60){target.updateTile()}
        if (current>=1 && target.liquids.get(nowliquid)<=target.block.liquidCapacity-1){
        target.handleLiquid(target,nowliquid,1)
        this.liquids.remove(nowliquid,1)
            }}}
        if (time>=60){time=0}
        },
        write(write){
    		this.super$write(write);
    		write.f(a)
    	},
    	read(read, revision){
    		this.super$read(read, revision);
    		a = read.f()
    	}
    },流体装卸器);
});
