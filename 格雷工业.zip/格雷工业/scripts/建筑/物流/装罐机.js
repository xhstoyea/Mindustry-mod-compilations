function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
function getbyname(name){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
const danmap = require("数据/value").danmap
//~~~~~~~~~~~~~~~
const 装罐机 = extend(LiquidRouter, '装罐机', {});
装罐机.buildType = prov(() => {
    var now = Liquids.water
    var a
    var dan
    var time=0
    return new JavaAdapter(LiquidRouter.LiquidRouterBuild, {
    	buildConfiguration(table){},
        updateTile(){
            this.dump()
		    this.super$updateTile()
		    now=this.liquids.current()
		    dan=this.getdan(now)
		    if (dan!=null){
            if (this.liquids.get(now)>=0.5 && this.items.total()<10){
            this.liquids.remove(now,0.5)
            time=time+Time.delta
                 }
            if (time>=30){
                time=0
                this.items.add(dan,1)
                this.dump()
            }
        }
        },
        getdan(liquid){
            return getbyname(danmap.get(liquid.name))
        }
    },装罐机);
});
