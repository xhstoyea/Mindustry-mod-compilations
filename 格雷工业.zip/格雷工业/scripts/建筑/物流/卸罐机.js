function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
function getbyname(name){
        var k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
const danmap = require("数据/value").danmap
const 卸罐机 = extend(LiquidRouter, '卸罐机', {});
卸罐机.buildType = prov(() => {
    var now
    var liquidf=Liquids.water
    var progress=0
    return new JavaAdapter(LiquidRouter.LiquidRouterBuild, {
        acceptItem(source, item) {
            if (danmap.has(item.name) && this.items.total()<1){return true}
            else{return false}
		},
        updateTile(){
		    this.super$updateTile()
		    now=this.items.first()
		    if (now!=null){
		        liquidf=this.getliquid(now)
		        if (r(this.liquids.get(liquidf),1)<=105 && progress==0){
		        this.items.remove(now,1)
		        progress=30
		        }}
		    if (r(this.liquids.get(liquidf),1)<120 && progress>0){
		        progress--
		        this.liquids.add(liquidf,0.5)
		    }
        },
        getliquid(dan){
            return getbyname(danmap.get(dan.name))}
    },卸罐机);
});
