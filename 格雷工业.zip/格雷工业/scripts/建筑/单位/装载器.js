function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
//~~~~~~~~~~~~~~
const 装载器 = extend(PayloadBlock, '装载器', {});
装载器.configurable = true;
装载器.buildType = prov(() => {
    var other
    var target
    return new JavaAdapter(PayloadBlock.PayloadBlockBuild, {
    	buildConfiguration(table){
    	   // let us = other.spawn(this.team, this.x, this.y)
    	   table.add("a"+other)
    	},
        updateTile(){
            Units.nearby(this.team,this.x,this.y,5, cons(o => {
                other=o
               // o.remove()
            }))
            target = Vars.world.build(this.x-1,this.y)
            if (other!=null){other.set(this.x,this.y+20)}
            if (this.payload!=null){
            this.unit=this.payload.unit}
        },
    },装载器);
});