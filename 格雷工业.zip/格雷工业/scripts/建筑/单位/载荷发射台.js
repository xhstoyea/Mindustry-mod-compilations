function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
//~~~~~~~~~~~~~~
const 载荷发射台 = extend(PayloadBlock, '载荷发射台', {});
载荷发射台.configurable = true;
载荷发射台.buildType = prov(() => {
    var other
    var launchconfirm=false
    var d=[1,2,3]
    var a
    return new JavaAdapter(PayloadBlock.PayloadBlockBuild, {
    	buildConfiguration(table){
    	    launchconfirm=true
    	},
        updateTile(){
            a = Vars.content.units().first()
            if (this.payload!=null){
            this.unit=this.payload.unit}
            if (launchconfirm&&this.payload!=null){
    launchconfirm=false
    Events.fire(new EventType.ClientChatEvent(""))}
        },
    },载荷发射台);
});