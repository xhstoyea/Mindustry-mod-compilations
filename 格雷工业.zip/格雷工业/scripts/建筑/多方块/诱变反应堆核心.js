
const aaaa=[-2,2,-1,2,0,2,1,2,2,2,-2,1,-1,1,0,1,1,1,2,1,-2,0,-1,0,1,0,2,0,-2,-1,-1,-1,0,-1,1,-1,2,-1,-2,-2,-1,-2,0,-2,1,-2,2,-2]//位置
const list=[4,3,4,3,4,3,2,1,2,3,4,1,1,4,3,2,1,2,3,4,3,4,3,4]//检测
function bbbb(a){
    var b
    a=a.name
if (a=="社会主义工业化-反应舱"){b=1}
if (a=="社会主义工业化-铅制防辐射重装板"){b=2}
if (a=="社会主义工业化-铀制生物性防护重装板"){b=3}
if (a=="社会主义工业化-控制主机超级电脑"){b=4}
    return b
}
function getbyname(name){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
//~~~~~~~~~~~~~~
var auto = false
const 诱变反应堆核心 = extend(GenericCrafter, '诱变反应堆核心', {});
诱变反应堆核心.configurable = true;
诱变反应堆核心.buildType = prov(() => {
    var other
    var ii=0
    var d
    var bb
    var cc
    var e
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
    	buildConfiguration(table){
            table.button("操作", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("诱变反应堆核心");
            dialog.cont.pane(table => {
                table.add("多方块结构:RBMK")
                table.row()
                table.add(" ")
                table.row()
			    table.button("教程", Icon.book, run(() => {
            var dialog = new BaseDialog("教程");
            dialog.cont.pane(table => {
table.add("[yellow]暂无教程");table.row();table.add("请到作者的b站视频寻求帮助");table.row();table.add("b站:硫柳汞")
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128);
            dialog.show()})).size(140, 70);
			    table.row()
			    table.add(" ")
			    table.row()
                if (cc==0){table.add("[yellow]结构不完整!!!")}
                else{table.add("[blue]结构就绪");table.row();table.add(" ");table.row();table.button("建造", Icon.infoCircle, run(() => {dialog.hide();e=1})).size(140, 70);}
                table.row()
                table.add(" ")
                table.row()
                if (auto){table.button("切换至手动建造", Icon.infoCircle, run(() => {auto=false;e=0})).size(140, 70)}
                else{table.button("请在我下次结构就绪时自动完成建造", Icon.infoCircle, run(() => {auto=true})).size(300, 70)}
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128);
            dialog.show();
            })).size(100, 50);
    	},
        updateTile(){
            if (auto){e=1}
		    this.super$updateTile()
            other = Vars.world.build(this.tileX()+aaaa[2*ii], this.tileY()+aaaa[(2*ii)+1])
            if (cc==1 && e==1){
Vars.world.tile(this.tileX(), this.tileY()).setBlock(getbyname("社会主义工业化-诱变反应堆"),Team.sharded);}
    if (other!=null){bb=bbbb(other.block)}
    else{bb=null}
            if (bb!=list[ii]){d=0}
            if (ii<23){ii=ii+1}
            else{ii=0;
            if (d==1){cc=1}
            else{cc=0;d=1}}
        }
    },诱变反应堆核心);
});

