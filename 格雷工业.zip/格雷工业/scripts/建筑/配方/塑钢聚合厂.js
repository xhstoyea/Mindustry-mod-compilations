const lib = require("base/AdvancedBuildLib")
var map={}
map.map=function(block){
}
map.kill=function(){}
var recipe=[]
recipe.push(
{
input:{
    item:[
        "titanium/2"
    ],
    orliquid:[
        "社会主义工业化-乙烯/15",
        "社会主义工业化-硅烷/15"
    ],
    power:4
},
output:{
    item:[
        "plastanium/1"
    ],
},
crafttime:30,
color:Pal.accent
//crafteffect:Fx.steam
})
const 塑钢聚合厂=lib.advanced("塑钢聚合厂",recipe,map)