const lib = require("base/AdvancedBuildLib")
var map={}
map.map=function(block){
    block.ignoreResultOnFull=true
    block.data=3
}
map.kill=function(){}
var recipe=[]
recipe.push(
{
input:{
    liquid:[
        "社会主义工业化-燃油/60"
    ],
    power:2
},
output:{
    item:[
        "coal/4"
    ]
},
crafttime:60,
color:Color.valueOf("ffffff"),
icon(){return Vars.content.getByName(ContentType.liquid,"社会主义工业化-燃油").uiIcon}
//crafteffect:Fx.steam
})
recipe.push(
{
input:{
    liquid:[
        "社会主义工业化-沥青/60"
    ],
    power:3
},
output:{
    item:[
        "coal/4"
    ]
},
crafttime:60,
color:Color.valueOf("dd00dd"),
icon(){return Vars.content.getByName(ContentType.liquid,"社会主义工业化-沥青").uiIcon}
})
recipe.push(
{
input:{
    liquid:[
        "社会主义工业化-芳香烃/60"
    ],
    power:3
},
output:{
    item:[
        "coal/4"
    ]
},
crafttime:60,
color:Color.valueOf("ff0000"),
icon(){return Vars.content.getByName(ContentType.liquid,"社会主义工业化-芳香烃").uiIcon}
})
const 焦化塔=lib.advanced("焦化塔",recipe,map)