function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
const aaaa=[-1,0,-1,1,0,2,1,2,2,1,2,0,1,-1,0,-1]
//~~~~~~~~~~~~~~~
const 辐照通道 = extend(GenericCrafter, '辐照通道', {
    	setBars() {
		this.super$setBars();
		this.addBar("rad", func(e => new Bar(
			prov(() => "中子通量"),
			prov(() =>  Color.valueOf("ffd06d")),
			floatp(() => e.enabled ==true ? 1 : 0)
		)));
	},
	    setStats() {
        this.super$setStats();
        this.stats.add(new Stat("条件", new StatCat("条件")), aaa());
    }
});
辐照通道.warmupSpeed = 0
辐照通道.privileged=true
辐照通道.buildType = prov(() => {
    var other
    var ii=0
    var aa
    var bb
    var d
    var cc=0
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
        updateTile(){
		    this.super$updateTile()
            other = Vars.world.build(this.tileX()+aaaa[2*ii], this.tileY()+aaaa[(2*ii)+1])
            if (other!=null){
            bb=other.block            
            if (bb.name=="社会主义工业化-RBMK"){aa=1;
            d=other.warmup
            }}
            if (ii<7){ii=ii+1}
            else {
            if (aa==1 && d>0.1){cc=1}
            else{cc=0}
            ii=0
            aa=0}
            if (cc==1){this.enabled=true}
            else{this.enabled=false}
        }
    },辐照通道);
});
function aaa() {
    return function (table) {
        table.add("需要[blue]RBMK[white]提供中子辐射");
        table.row();
    };
}

