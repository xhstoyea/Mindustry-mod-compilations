const lib = require("base/lib");
//const mathlib = require("base/MathLib")
//const gen=require("base/generator")
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
function flp(x){
    var y=2-(Math.pow(Math.E,((Math.E-x)/2))+((x-Math.E)/2))
    if (y<0){y=0}
    return y
}                     //效率函数
        //flp(x)=-(e^((e-x)/2)+(x-e)/2)+2
        //flp(x)max=flp(e)=1
        //flp(x)min=0
function fp(n,x){
    var y=n*x
    return y
}           //功率计算
function lerpDelta(a,b,delta){
    return a+(b-a)*delta
}          //线性插值
function getbyname(name){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
//~~~~~~~~~~~~~~
const 航空引擎 = extend(ConsumeGenerator, '航空引擎', {
    	    setStats() {
        this.super$setStats()
        this.stats.add(Stat.input, new JavaAdapter(StatValue,{
            display(table){
                table.add(new LiquidDisplay(myliquids.燃油,1,false)).padRight(5).left()
                table.add("[accent] ~ ") 
                table.add(new LiquidDisplay(myliquids.燃油,60,false)).padRight(5).left()
            }}))
    },
    setBars() {
		this.super$setBars();
		this.addBar("效率", func(e => new Bar(
			prov(() => lib.b("text-效率")),
			prov(() => Pal.ammo),
			floatp(() => e.geteff())
		)))
	},
})
const myliquids = require("液体")
航空引擎.warmupSpeed = 0
航空引擎.configurable = true;
航空引擎.buildType = prov(() => {
    var end=0
    var fuellp=0
    var exfuelmul=0
    var repow=0
    var rewarmup=0
    return new JavaAdapter(ConsumeGenerator.ConsumeGeneratorBuild, {
    	buildConfiguration(table){
    	    //table.add("s"+gen.generate(191961,15,[0,0]))
    	    //table.background(Tex.pane)
            table.add("        [accent]"+lib.b("text-流量")+"：" +end).update(t => {t.setText("        [accent]"+lib.b("text-流量")+": "+end)}).left()
            table.row()
            table.add("        [accent]"+lib.b("text-等效流量")+"：" +r(this.refuel(),1)).update(t => {t.setText("        [accent]"+lib.b("text-等效流量")+": "+r(this.refuel(),2))}).left()
            table.row()
            table.add("        [accent]"+lib.b("text-效率")+"："+r((this.geteff()*100),2)+"%").update(t => {t.setText("        [accent]"+lib.b("text-效率")+": "+r((this.geteff()*100),2)+"%")}).left()
            table.row()
            table.add("        [accent]"+lib.b("text-预热")+"："+(rewarmup*100,1)+"%").update(t => {t.setText("        [accent]"+lib.b("text-预热")+": "+r(rewarmup*100,1)+"%")}).left()
            table.row()
            table.add("        [accent]"+lib.b("text-功率")+"："+r(this.getPowerProduction()*60,0)).update(t => {t.setText("        [accent]"+lib.b("text-功率")+": "+r(this.getPowerProduction()*60,0))}).left()   
            table.row()
            table.add("        [accent]"+lib.b("text-流量阀")).left()
            table.row()
			table.slider(0, 60, 1, end, g=> {
			    end=g
			    fuellp=end/60
			}).width(300)
    	},
        acceptLiquid(source, liquid){
            if (liquid.name==myliquids.燃油.name&&this.fuel()<120){
                return true
            }
            return false
        },
        updateTile(){
	        this.super$updateTile()
	        this.handlewarmup()
	        this.handlerepow()
            this.reduceexfuelmul()
            if (this.enoughfuel()){
                this.consumefuel()
            }
            this.warmup=repow*rewarmup/r((fp(flp(4),60)/50),2)
        },
        fuel(){
            return this.liquids.get(myliquids.燃油)
        },
        consumefuel(){
                this.liquids.remove(myliquids.燃油,fuellp)
                this.hasconsumed()
        },
        hasconsumed(){
            exfuelmul+=0.01
        },
        reduceexfuelmul(){
            exfuelmul-=exfuelmul*0.01
        },
        hasfuel(){
            return this.fuel()>0
        },
        enoughfuel(){
            return this.hasfuel() && this.fuel()>=fuellp
        },
        refuel(){
            return r(fuellp*exfuelmul*60,1)
        },
        geteff(){
            return r(flp((this.refuel()/60)*4),4)
        },
        getpow(){
            return r((fp(this.geteff(),this.refuel())/50),4)
        },
        getpowmul(){
            return repow/this.getpow()
        },
		getPowerProduction(){
		    return this.block.powerProduction*repow*rewarmup
		},
		handlerepow(){
		    if (this.getpow()==0){
		        if (repow==0){
		            return
		        }
		        if (repow<0.02){
		            repow=0
		            return
		        }
		        repow=lerpDelta(repow,0,0.005)
		        repow-=0.0002
		        return
		    }
		    if (this.getpowmul()<0.99){
		        repow=lerpDelta(repow,this.getpow(),0.001)
		        return
		    }
		    if (this.getpowmul()>1.01){
		        repow=lerpDelta(repow,this.getpow(),0.005)
		        repow-=0.0002
		        return
		    }
		    repow=this.getpow()
		},
		handlewarmup(){
		    if (this.getpow()>0){
		        if (rewarmup>0.99){
		            rewarmup=1
		            return
		        }
		        rewarmup=lerpDelta(rewarmup,1,0.0008)
		        return
		    }
		    if (rewarmup<0.01){
		        rewarmup=0
		        return
		    }
		    rewarmup-=0.001
		    rewarmup=lerpDelta(rewarmup,0,0.0003)
		},
        ambientVolume(){
            return this.warmup*this.block.ambientSoundVolume
        },
    	write(write){
    		this.super$write(write)
    		write.f(end)
    		write.f(fuellp)
    		write.f(exfuelmul)
    		write.f(repow)
    		write.f(rewarmup)
    	},
    	read(read, revision){
    		this.super$read(read, revision)
    		end=read.f()
    		fuellp=read.f()
    		exfuelmul=read.f()
    		repow=read.f()
    		rewarmup=read.f()
    	},
    },航空引擎)
});
