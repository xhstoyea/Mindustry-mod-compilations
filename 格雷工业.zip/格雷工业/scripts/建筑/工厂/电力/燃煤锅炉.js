
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
//~~~~~~~~~~~~~~~
const myItems = require("物品")
const burn=new Map()
burn.set(Items.coal.name,6)
burn.set(Items.sporePod.name,5)
burn.set(Items.pyratite.name,7)
burn.set(myItems.塑料.name,6)
const fuel=[Items.coal,Items.sporePod,Items.pyratite,myItems.塑料]
const 燃煤锅炉 = extend(ConsumeGenerator, '燃煤锅炉', {
    setStats() {
        this.super$setStats()
        this.stats.remove(Stat.input);
        this.stats.add(Stat.input, new JavaAdapter(StatValue,{
            display(table){
            table.add(new LiquidDisplay(Liquids.water,12,true)).padRight(5).left()
            }}))
        this.stats.add(new Stat("燃料与燃值", new StatCat("燃料")), aaa())
    },
})
燃煤锅炉.buildType = prov(() => {
    var burnf
    return new JavaAdapter(ConsumeGenerator.ConsumeGeneratorBuild, {
        acceptItem(source,item) {
            if (this.items.get(item)<20 && burn.has(item.name)){return true}
            else{return false}
		},
		getPowerProduction(){
		    if (this.items.first()!=null){
		        burnf=burn.get(this.items.first().name)
		    }
		    else{burnf=0}
		    return 12.5*burnf/6
		}
    },燃煤锅炉);
});
function aaa() {
    return function (table) {
        for (var i=0;i<fuel.length;i++){
        table.add(new ItemDisplay(fuel[i],0,true)).padRight(5).left()}
    };
}
