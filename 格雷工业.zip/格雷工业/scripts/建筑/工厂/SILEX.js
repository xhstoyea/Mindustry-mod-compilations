function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
const aaaa=[-2,3,-1,3,0,3,1,3,2,3,3,3,3,2,3,1,3,0,3,-1,3,-2,2,-2,1,-2,0,-2,-1,-2,-2,-2,-2,-1,-2,0,-2,1,-2,2]
//~~~~~~~~~~~~~~~
const SILEX = extend(GenericCrafter, 'SILEX', {
	    setStats() {
        this.super$setStats()
        this.stats.add(new Stat("条件", new StatCat("条件")), aaa())
    },
    	setBars() {
		this.super$setBars();
		this.addBar("heat", func(e => new Bar(
			prov(() => "激光通量"),
			prov(() =>  Color.valueOf("ffd06d")),
			floatp(() => e.enabled ? 1 : 0)
		)));
	},
});
SILEX.warmupSpeed = 0
SILEX.privileged=true
//SILEX.configurable = true
SILEX.buildType = prov(() => {
    var other
    var ii=0
    var aa
    var bb
    var d
    var cc=0
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
        updateTile(){
		    this.super$updateTile()
            other = Vars.world.build(this.tileX()+aaaa[2*ii], this.tileY()+aaaa[(2*ii)+1])
           if (other!=null){
            if (other.block.name=="社会主义工业化-FEL激光器"){
            if (other.gettarget()==this && other.getlevel()>0 && other.getallow()){aa=1}
           }}
            if (ii<19){ii=ii+1}
            else {
            if (aa==1){this.enabled=true}
            else{this.enabled=false}
            ii=0
            aa=0}
        }
    },SILEX);
});
function aaa() {
    return function (table) {
table.add("[blue]FEL激光器    [grey]能级:1")
        table.row()
    };
}

