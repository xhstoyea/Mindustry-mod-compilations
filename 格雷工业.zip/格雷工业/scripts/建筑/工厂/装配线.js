function getbyname(name,type){
    if (type=="block"){
        var k=Vars.content.getByName(ContentType.block,name)
        return k}
    if (type=="item"){
        k=Vars.content.getByName(ContentType.item,name)
        return k}
    if (type=="liquid"){
        k=Vars.content.getByName(ContentType.liquid,name)
        return k}
}
//~~~~~~~~~~~~~~~
const recipe = require("数据/装配线").recipe
const 装配线 = extend(BlockProducer, '装配线', {
    setBars() {
		this.super$setBars();
		this.removeBar("progress")
		this.removeBar("liquid")		
		this.addBar("progress", func(e => new Bar(
			prov(() => "进度"),
			prov(() => Pal.ammo),
			floatp(() => e.progress)
		)))
		this.addBar("cryofluid", func(e => new Bar(
			prov(() => Liquids.cryofluid.toString()),
			prov(() => Color.valueOf("00ffff")),
			floatp(() => e.getcryofluid())
		)))
		this.addBar("liquid", func(e => new Bar(
			prov(() => e.getliquiddisplay()[0]),
			prov(() => Color.valueOf("ffd06d")),
			floatp(() => e.getliquiddisplay()[1])
		)))
	},
});
装配线.configurable = true;
装配线.buildType = prov(() => {
    var pro=0
    var tog=-1
    return new JavaAdapter(BlockProducer.BlockProducerBuild, {
    	buildConfiguration(table){
        this.super$buildConfiguration(table)
        var group = new ButtonGroup()
        group.setMinCheckCount(0)
        group.setMaxCheckCount(1)
		table.table(Tex.button,rootTable => {
	//	rootTable.add(Image(getbyname(recipe[tog].out,"block").uiIcon).setScaling(Scaling.fit)).size(30)
	    rootTable.add(tog==-1 ? "无" : getbyname(recipe[tog].out,"block").toString()).update(t => {t.setText(tog==-1 ? "无" : getbyname(recipe[tog].out,"block").localizedName)
	        
	    })
		})
	    table.row()
        table.table(Tex.button,rootTable => {
        for (var i=-1;i<recipe.length;i++){
            (function(i){
        if (i==-1){
            var buttonnone = rootTable.button(Tex.pane,32.5,() => {tog=-1;pro=0}).group(group).get()
            buttonnone.getStyle().up = Styles.black3
            buttonnone.getStyle().down = Styles.flatOver
            buttonnone.getStyle().over = Styles.flatOver;
            buttonnone.getStyle().imageUp = new TextureRegionDrawable(Icon.cancel)
            buttonnone.getStyle().checked = Styles.accentDrawable
            buttonnone.update(() => {
            buttonnone.setChecked(-1==tog)})
            return
        }
        var button = rootTable.button(Tex.pane,32.5,() => {tog=i;pro=0}).tooltip(getbyname(recipe[i].out,"block").localizedName).group(group).get()
        button.getStyle().up = Styles.black3
        button.getStyle().down = Styles.flatOver;
        button.getStyle().over = Styles.flatOver;
        button.getStyle().imageUp = new TextureRegionDrawable(getbyname(recipe[i].out,"block").uiIcon)
        button.update(() => {
            button.getStyle().checked = Styles.accentDrawable
            button.setChecked(i==tog)
            if (i==tog){
            button.getStyle().imageUp = new TextureRegionDrawable(Icon.hammer)
                    }
            else{
            button.getStyle().imageUp = new TextureRegionDrawable(getbyname(recipe[i].out,"block").uiIcon)
            }
        })
        })(i)
            if((i+1)%8==7){rootTable.row()}}})},
        acceptItem(source, item) {
            if (tog==-1){
                return false
            }
            var re=recipe[tog].item
            for (var i=0;i<re.length;i++){
                if (re[i].item==item.name){
                if (this.items.get(item)<re[i].amo*2){
                    return true
                }
                }
            }
            return false
		},
        acceptLiquid(source, liquid) {
            if (liquid.name=="cryofluid" && this.liquids.get(liquid)<120){
                return true
            }
            if (tog==-1){
                return false
            }
            var re=recipe[tog].liquid
            for (var i=0;i<re.length;i++){
                if (re[i].liquid==liquid.name){
                if (this.liquids.get(liquid)<re[i].amo*4){
                    return true
                }
                }
            }
            return false
		},
		getout(){
		    return getbyname(recipe[tog].out,"block")
		},
		hascryofluid(){
		    if (this.liquids.get(Liquids.cryofluid)>0.01){
		        return true
		    }
		    return false
		},
		hasitem(item,amo){
		    return this.items.has(getbyname(item,"item"),amo)
		},
		hasliquid(liquid,amo){
		    return this.liquids.get(getbyname(liquid,"liquid"))>=amo
		},
		checkcryofluid(){
		    if (this.liquids.get(Liquids.cryofluid)>=this.power.status/2){
		        return true
		    }
		    return false
		},
		checkinput(){
		var re=recipe[tog].item
		for (var i=0;i<re.length;i++){
		    if (this.items.get(getbyname(re[i].item,"item"))<re[i].amo){
		        return false
		    }
		}
		re=recipe[tog].liquid
		for (var i=0;i<re.length;i++){
		    if (this.liquids.get(getbyname(re[i].liquid,"liquid"))<re[i].amo){
		        return false
		    }
		}
		return true
		},
		checkoutput(){
		    return this.payload==null
		},
		consume(){
		var re=recipe[tog].item
		for (var i=0;i<re.length;i++){
		    this.items.remove(getbyname(re[i].item,"item"),re[i].amo)
		}
		re=recipe[tog].liquid
		for (var i=0;i<re.length;i++){
		    this.liquids.remove(getbyname(re[i].liquid,"liquid"),re[i].amo)
		}
		},
        updateTile(){
        this.moveOutPayload()
        if (tog==-1){
            this.progress=0
            return}
        this.progress=pro/recipe[tog].time
        if (this.checkinput() && this.checkoutput() && this.checkcryofluid()){
            pro+=this.power.status
            this.liquids.remove(Liquids.cryofluid,this.power.status/2)
            if (pro>=recipe[tog].time){
                pro=0
                this.consume()
                this.payload = new BuildPayload(this.getout(),Team.sharded)
                this.payload.block().placeEffect.at(this.x,this.y,this.payload.size()/10)
            }}
        },
        displayConsumption(table){
        table.left()
        if (tog==-1){
            table.image(Icon.cancel).size(32)}
        else {
            table.add(Image(this.getout().uiIcon).setScaling(Scaling.fit)).size(26)}
        table.add(new ReqImage(new ItemImage(Liquids.cryofluid.uiIcon,0),()=>this.hascryofluid())).size(32)
        if (tog==-1){return}
        for (var i=0;i<recipe[tog].item.length;i++){
            var re=recipe[tog].item
            var item=re[i].item
            var amo=re[i].amo
            table.add(new ReqImage(new ItemImage(getbyname(item,"item").uiIcon,amo),()=>this.hasitem(item,amo))).size(32)
        }
        for (var i=0;i<recipe[tog].liquid.length;i++){
            var re=recipe[tog].liquid
            var liquid=re[i].liquid
            var amo=re[i].amo
            table.add(new ReqImage(new ItemImage(getbyname(liquid,"liquid").uiIcon,amo),()=>this.hasliquid(liquid,amo))).size(32)
        }
        },
        getcryofluid(){
            return this.liquids.get(Liquids.cryofluid)/120
        },
        getliquiddisplay(){
            if (tog==-1){return ["无",0]}
            if (recipe[tog].liquid.length==0){return ["无",0]}
            return ["液体",this.liquids.get(getbyname(recipe[tog].liquid[0].liquid,"liquid"))/(recipe[tog].liquid[0].amo*4)]
        },
    	write(write){
    		this.super$write(write);
    		write.f(tog)
    		write.f(pro)
    	},
    	read(read, revision){
    		this.super$read(read, revision);
    		tog = read.f()
    		pro = read.f()
    	},
    },装配线);
});
