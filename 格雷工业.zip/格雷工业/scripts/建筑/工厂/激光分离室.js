const aaaa=[-2,3,-1,3,0,3,1,3,2,3,3,3,3,2,3,1,3,0,3,-1,3,-2,2,-2,1,-2,0,-2,-1,-2,-2,-2,-2,-1,-2,0,-2,1,-2,2]
const myItems = require("物品")
const outlist=[Items.copper,Items.lead,Items.thorium,myItems.钛晶石,myItems.铂系矿泥,myItems.钨酸盐矿,myItems.二氧化铀,myItems.萤石,myItems.独居石]
const chance=[24,21,14,14,4,7,5,2,2]
//~~~~~~~~~~~~~~~
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
function rand(b){
    return Math.floor(Math.random()*(b+1))
}
function check(a,b){
    return rand(b-1)<=a-1
}
const 激光分离室 = extend(GenericCrafter, '激光分离室', {
	    setStats() {
        this.super$setStats()
        this.stats.add(new Stat("输出", new StatCat("输出")), aaa())
      //  this.stats.add(Stat.input,aaa())
    },
    	setBars() {
		this.super$setBars();
		this.addBar("laser", func(e => new Bar(
			prov(() => "激光通量"),
			prov(() =>  Color.valueOf("ffd06d")),
			floatp(() => e.getthislevel()/2)
		)));
	},
});
激光分离室.warmupSpeed=0.006
激光分离室.consumeLiquid(Liquids.slag,1/3)
激光分离室.privileged=true
激光分离室.configurable = true
激光分离室.buildType = prov(() => {
    var other
    var timer=0
    var realtime=60
    var level=0
    var ii=0,aa=0
    var ban=[]
    var boost=1
    for (var i=0;i<9;i++){ban[i]=false}
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
buildConfiguration(table){
        var group = new ButtonGroup()
        group.setMinCheckCount(0)
        group.setMaxCheckCount(9)
        this.super$buildConfiguration(table)
       // var wui = new TextureRegionDrawable(Tex.whiteui)
        table.table(Tex.button,rootTable => {
        for (var i=0;i<9;i++){
         (function(i){    
        var button = rootTable.button(Tex.pane,32,() => {
            if (ban[i]){ban[i]=false}
            else {ban[i]=true}
        }).tooltip(outlist[i].localizedName).group(group).get()
        button.getStyle().up = Styles.black3
        button.getStyle().down = Styles.flatOver;
        button.getStyle().checked = Styles.accentDrawable
        button.getStyle().over = Styles.flatOver;
        button.getStyle().imageUp = new TextureRegionDrawable(outlist[i].uiIcon)
        button.update(() => {button.setChecked(ban[i])})})(i)}})
},
shouldConsume(){
    return this.items.total()<=30
},
updateTile(){
    this.super$updateTile()
    if (this.warmup>0.1&&this.warmup<0.95){
        this.warmup-=0.004}
    other = Vars.world.build(this.tileX()+aaaa[2*ii], this.tileY()+aaaa[(2*ii)+1])
    if (other!=null){
        if (other.block.name=="社会主义工业化-FEL激光器"){
            if (other.gettarget()==this){if(aa<other.getlevel()){aa=other.getlevel()}}
           }}
    if (ii<19){ii=ii+1}
    else {ii=0;level=aa;aa=0
    if (level<2){level=0}
    else {level-=2}}
    if (this.warmup>0.01){timer+=this.warmup}
    realtime=(60-level*10)/(this.getProgressIncrease(60)*60)
    boost=1
    for (var i=0;i<7;i++){
        if (ban[i]){boost+=0.1}
    }
    if (timer>=realtime/boost){
        timer=0
        for (var i=0;i<level+7;i++){
            if (check(chance[i],40)){
            if (!ban[i]){
                //this.items.add(outlist[i],1)
                this.offload(outlist[i])
            }}        
        }}
    this.dump()
},
getthislevel(){
    return level
},
write(write){
    this.super$write(write);
    for (var i in ban){
        if (ban[i]){write.f(1)}
        else {write.f(0)}
    }
},
read(read, revision){
    this.super$read(read, revision);
    for (var i in ban){
        if (read.f()){ban[i]=true}
        else {ban[i]=false}
    }
},
    },激光分离室);
});
function aaa() {
    return function (table) {
        table.row()
        for (var i=0;i<9;i++){
        table.add("    ")
        table.add(new ItemDisplay(outlist[i],0,true)).padRight(5).left()
        table.add("       ")
        table.add(r(chance[i]*2.5,2).toString()+" %")
        if (i>=7){
            table.add("       ")
            table.add("[grey]能级:"+(i-4))
        }
        table.row()}
    };
}