const orearr = require("矿脉").ore
//~~~~~~~~~~~~~~~
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
function getbyname(name){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
const detecteff=1
const detectspeed=1
const 地震探测仪 = extend(GenericCrafter, '地震探测仪', {
init(){
    this.hasPower = true
    this.consumesPower=true
    this.consumeBuilder.add(extend(ConsumePower, {
        requestedPower(e) {
                if (!e.worked()){
                        return 0
                }
                return 10
            }
        }))
    this.super$init()
},
setBars() {
	this.super$setBars();
	this.removeBar("liquid")
	this.removeBar("items")
    this.addBar("进度", e => new Bar(() => e.displayprocess(), () => Pal.ammo, () => e.getprocess()))
},
});
地震探测仪.configurable = true
地震探测仪.saveConfig=true
地震探测仪.buildType = prov(() => {
    var process=0
    var stage=0
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
buildConfiguration(table){
    table.button("操作", Icon.infoCircle, run(() => {
        var dialog = new BaseDialog("地震探测仪");
        dialog.cont.pane(table => {
            table.add(this.getstr2()).update(t => {t.setText(this.getstr2())})
            table.row()
            table.add(this.getstr()).update(t => {t.setText(this.getstr())})
        })
        dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128);
        dialog.show();
        })).size(100, 50);    
},
acceptItem(source,item){
    if (item.name!="社会主义工业化-硝基炸药"){
        return false
    }
    if (this.items.get(item)>=100){
        return false
    }
    return true
},
updateTile(){
    if (this.worked()){
        if (process==0){
            this.consume()
        }
        this.handleprocess()
        if (process>=20){
            process=0
            stage+=0.01
        }
    }
    if (stage>=1){
        stage=-1
    }
},
handleprocess(){
    process+=this.processincrease()
},
consume(){
    this.items.remove(getbyname("社会主义工业化-硝基炸药"),1)
    Fx.massiveExplosion.at(this.x, this.y)
},
worked(){
    if (this.items.get(getbyname("社会主义工业化-硝基炸药"))<1){
        return false
    }
    if (this.power.status==0){
        return false
    }
    if (stage==-1){
        return false
    }
    return true
},
processincrease(){
    return this.getProgressIncrease(60)*60
},
getprocess(){
    return stage
},
displayprocess(){
    if (stage==-1){
        return "完成"
    }
    return "进度 "+r(stage*100,0)+"%"
},
getstr(){
    var str=""
    if (stage==-1){
    for (var i=0;i<orearr.length;i++){
        var ore=orearr[i]
        str+=ore.type
        str+=" 位于 "
        str+="("+ore.pos[0]+"),"
        str+="("+ore.pos[1]+"),"
        str+="("+ore.pos[2]+"),"
        str+="("+ore.pos[3]+")"
        str+=" 深度 "
        str+=ore.layer+"层"
        str+="\n"
    }
    }
    return str
},
getstr2(){
    var str2=""
    if (stage!=-1){
        str2+="探测中 "+r(stage*100,0)+"%"
        if (!this.worked()){
            str2+="\n不在运行"
        }
        else {
            str2+="\n运行中"
        }
    }
    if (stage==-1){
        str2+="完成\n结果:"
    }
    return str2
},
write(write){
    this.super$write(write)
    write.f(process)
    write.f(stage)
},
read(read, revision){
    this.super$read(read, revision)
    process=read.f()
    stage=read.f()
},
    },地震探测仪);
});