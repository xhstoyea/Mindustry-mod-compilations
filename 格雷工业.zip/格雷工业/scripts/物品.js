function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("二氧化铀")
newItem("钨酸盐矿")
newItem("铂系矿泥")
newItem("钛晶石")
newItem("硫酸盐矿")
newItem("绿柱石")
newItem("萤石")
newItem("独居石")
newItem("沉金石")
newItem("黄石")
newItem("铀")
newItem("铱")
newItem("钨")
newItem("铍")
newItem("钚")
newItem("武器级钚")
newItem("硅岩")
newItem("泰坦合金")
newItem("亚稳定合金")
newItem("塑料")
newItem("硬塑料")
newItem("芯片")
newItem("基元")
newItem("单晶硅")
newItem("CMB钢")
newItem("硝基炸药")
newItem("钻石")
newItem("稀土")