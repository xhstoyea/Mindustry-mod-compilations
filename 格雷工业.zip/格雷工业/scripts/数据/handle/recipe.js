function getbyname(name){
        var k=Vars.content.getByName(ContentType.liquid,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.block,name)
        return k
}
//~~~~~~~~~~~~~~~
//building requirement
var bu=[]
var memo=[]
Vars.content.blocks().each(cons(block => {
        if (block.requirements[0]!=null){
            memo.push(block.requirements)
            bu.push(block)}
        
    }))
//~~~~~~
var con=[]
var requ=[]
requ[0]=memo
requ[1]=bu
//~~~~~~~~
//recipe
var recipe=[]
const bl=[]
function setrecipe(block,type,content){
    var recs=block.getrecm()
    for (var j=0;j<recs.length;j++){
        var inputs=[]
        var oritems=[]
        var orliquids=[]
        var outputs=[]
        var configs=[]
        var rec=recs[j].input.item
        for (var o=0;o<rec.length;o++){
            inputs.push(rec[o].item.name)
            inputs.push(rec[o].amo)
        }
        var rec=recs[j].input.liquid
        for (var o=0;o<rec.length;o++){
            inputs.push(rec[o].liquid.name)
            inputs.push(rec[o].amo)
        }
        var rec=recs[j].input.oritem
        for (var o=0;o<rec.length;o++){
            oritems.push(rec[o].item.name)
            oritems.push(rec[o].amo)
        }
        var rec=recs[j].input.orliquid
        for (var o=0;o<rec.length;o++){
            orliquids.push(rec[o].liquid.name)
            orliquids.push(rec[o].amo)
        }
        var rec=recs[j].output.item
        for (var o=0;o<rec.length;o++){
            outputs.push(rec[o].item.name)
            outputs.push(rec[o].amo)}
        var rec=recs[j].output.result
        for (var o=0;o<rec.length;o++){
            outputs.push(rec[o].item.name)
            outputs.push(0)
        }
        var rec=recs[j].output.productitem
        for (var o=0;o<rec.length;o++){
            outputs.push(rec[o].item.name)
            outputs.push(rec[o].amo)
        }
        var rec=recs[j].output.liquid
        for (var o=0;o<rec.length;o++){
            outputs.push(rec[o].liquid.name)
            outputs.push(rec[o].amo)
        }
        var rec=recs[j].output.productliquid
        for (var o=0;o<rec.length;o++){
            outputs.push(rec[o].liquid.name)
            outputs.push(rec[o].amo)
        }
        if (recs[j].output.power>0){
            outputs.push("power")
            outputs.push(recs[j].output.power)
        }
        if (recs[j].input.tem>0){
            configs.push("炉温")
            configs.push(recs[j].input.tem)
        }
        recipe.push({input:inputs,output:outputs,area:block.name,config:configs})
    }
    if (type=="pop"){
        for (var k=0;k<content;k++){
            recipe.pop()
        }
    }
}
/*getbyname("社会主义工业化-石油分馏塔").consumeItems(ItemStack.with(
    Items.lead, 4,
    Items.sand, 5,
    Items.pyratite, 1
))*/
/*for (var i=0;i<5;i++){
getbyname("社会主义工业化-石油分馏塔").consumeItems(ItemStack.with(Items.copper,4))}*/
Events.on(EventType.ClientLoadEvent, () => {
Vars.content.blocks().each(cons(b => {
if (b.consumers!=null&&b.consumers.length>0){
    var inputs=[]
    var outputs=[]
    for (var j=0;j<b.consumers.length;j++){
    if (b.consumers[j]!=null){
        var consu=b.consumers[j].items
        if (consu!=null){
        for (var i=0;i<consu.length;i++){
            var item=consu[i].item
            var amo=consu[i].amount
            inputs.push(item.name)
            inputs.push(amo)
        }}//物品消耗
        consu=b.consumers[j].liquid
        if (consu!=null){
            var liquid=consu
            var amo=b.consumers[j].amount
            inputs.push(liquid.name)
            inputs.push(amo*60)
        }//单液体消耗
        consu=b.consumers[j].liquids
        if (consu!=null){
        for (var i=0;i<consu.length;i++){
            var liquid=consu[i].liquid
            var amo=consu[i].amount
            inputs.push(liquid.name)
            inputs.push(amo*60)
        }}}}//多液体消耗
        if (b.heatRequirement!=null){
            inputs.push("heat")
            inputs.push(b.heatRequirement)
        }//热量消耗
        if (b.outputItems!=null){
        for (var i=0,out=b.outputItems;i<out.length;i++){
            var item=out[i].item
            var amo=out[i].amount
            outputs.push(item.name)
            outputs.push(amo)
        }
        }//物品输出
        if (b.outputLiquids!=null){
        for (var i=0,out=b.outputLiquids;i<out.length;i++){
            var liquid=out[i].liquid
            var amo=out[i].amount
            outputs.push(liquid.name)
            outputs.push(amo*60)
        }
        }//多液体输出
        else{
        if (b.outputLiquid!=null){
            var liquid=b.outputLiquid.liquid
            var amo=b.outputLiquid.amount
            outputs.push(liquid.name)
            outputs.push(amo*60)
        }}//单液体输出
        if (b.results!=null){
        for (var i=0,out=b.results;i<out.length;i++){
            var item=out[i].item
            var amo=out[i].amount
            outputs.push(item.name)
            outputs.push(amo)
        }
        }//随机物品输出
        if (b.powerProduction>0){
            outputs.push("power")
            outputs.push(b.powerProduction)
        }//电力输出
        if (b.heatOutput!=null){
            outputs.push("heat")
            outputs.push(b.heatOutput)
        }//热量输出
        recipe.push({input:inputs,output:outputs,area:b.name,config:[]})}
if (typeof b.ABL==="function"){
    setrecipe(b)
}
    }))

function findrecipe(block){
    for (var i=0;i<recipe.length;i++){
        var rec=recipe[i]
        if (rec.area==block){
            return i
        }
    }
}
recipe[findrecipe("社会主义工业化-辐照通道")].config=["display",["[accent]需要[blue]RBMK[accent]提供中子辐射"]]
recipe[findrecipe("社会主义工业化-生物培养皿")].config=["display",["[accent]需要阳光"]]
recipe[findrecipe("社会主义工业化-渗析井")].config=["display",["[accent]需要",Image(Blocks.salt.uiIcon)]]
recipe[findrecipe("社会主义工业化-SILEX")].config=["激光",1]
recipe[findrecipe("社会主义工业化-激光分离室")].output=["copper",0,"lead",0,"thorium",0,"社会主义工业化-钛晶石",0,"社会主义工业化-铂系矿泥",0,"社会主义工业化-钨酸盐矿",0,"社会主义工业化-二氧化铀",0,"社会主义工业化-萤石",0,"社会主义工业化-独居石",0]
recipe[findrecipe("社会主义工业化-渗析井")].output=["社会主义工业化-盐水",6]
recipe[findrecipe("社会主义工业化-渗析井")].config=["display",["[accent]需要"+Blocks.salt.localizedName," ",Image(Blocks.salt.uiIcon)]]
recipe.push({input:["water",6],output:["社会主义工业化-微生物悬浊液",6],area:"社会主义工业化-渗析井",config:["display",["[accent]需要"+getbyname("社会主义工业化-泥土").localizedName," ",Image(getbyname("社会主义工业化-泥土").uiIcon)]]})

})

//~~~~~~
exports.recipe = recipe
exports.requ=requ