
module.exports={ RandomLightningBulletType(damage, range, radius, reload, num){
    //return PointBulletType
	return extend(BasicBulletType, {
		hittable: false,
		absorbable: false,
		reflectable: false,
		update(b) {
			this.super$update(b);
			if (b.time >= b.lifetime) return
			if (b.timer.get(reload)) {
				for (let i = 0; i < num; i++) {
					let x = b.x + Mathf.range(range);
					let y = b.y + Mathf.range(range);
					Damage.damage(x, y, radius, damage);
					Fx.steam.at(b.x,b.y)
					Effect.shake(4, 30, x, y);
				}
			}
		}
	})
}
}