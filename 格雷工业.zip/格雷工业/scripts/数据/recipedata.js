var recipe=[]
recipe.push({type:GenericCrafter,crafttype:"normal",build:"社会主义工业化-低温压缩机"})

exports.recipedata = recipe