

function liquid(name){
        var k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
function item(name){
        var k=Vars.content.getByName(ContentType.item,name)
        return k
}

//block
var block=[]
/*{
    type
    name
    description
    size
    health
    hasLiquids
    hasItems
    hasPower
    liquidCapacity
    itemCapacity
    consume
    craftTime
    category
    requirements
    drawer
    research
    craftEffect
    updateEffect
    map
}
*/
block.push({
    type:GenericCrafter,
    name:"低温压缩机",
    description:"使氮气转化为液氮",
    size:3,
    liquidCapacity:120,
    craftTime:60,
    consume:{
        power:3,
        liquid:[
            "nitrogen/1"
        ]
    },
    outputLiquid:[
        "cryofluid/0.5"
    ],
    craftEffect:Fx.steam,
    updateEffect:Fx.plasticburn,
    drawer:[
        new DrawRegion("-bottom"),
        new DrawLiquidTile(liquid("nitrogen"), 2),
        new DrawLiquidTile(liquid("cryofluid"), 1),
        new DrawWeave(),
        new DrawDefault(),
    ],
    requirements:[
		"silicon/100",
		"titanium/180",
		"社会主义工业化-塑料/200",
		"社会主义工业化-铱/50"
    ]
})
block.push({
    type:GenericCrafter,
    name:"氰合成厂",
    description:"在铱-钚催化剂的作用下高效制氰。需在装配线中建造",
    size:3,
    liquidCapacity:120,
    craftTime:60,
    consume:{
        power:7,
        item:[
            "graphite/2"
        ],
        liquid:[
            "nitrogen/1"
        ]
    },
    outputLiquid:[
        "cyanogen/1"
    ],
    drawer:[
        new DrawRegion("-bottom"),
        new DrawCrucibleFlame(),
        new DrawDefault(),
    ],
    requirements:[
		"社会主义工业化-塑料/300",
	    "titanium/200",
	    "社会主义工业化-芯片/100",
	    "社会主义工业化-铱/150",
	    "社会主义工业化-钚/150"
    ]
})
exports.block = block