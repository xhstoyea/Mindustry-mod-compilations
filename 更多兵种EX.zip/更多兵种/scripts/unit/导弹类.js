const 月相 = new MissileUnitType("月相");
const 月相a = new MissileUnitType("月相a");
const 候鸟 = new MissileUnitType("候鸟");
const 阴云 = new MissileUnitType("阴云");