const library = require("MultiCrafter");
//const myliquids = require("液体");
const myitems = require("物品");
const 倾灌机 = library.MultiCrafter(GenericSmelter, GenericCrafter.GenericCrafterBuild, "倾灌机", [
  {
    input: {
    items:["sc-储液罐/1"],//输入物品
    fluids:["water/30"],//输入流体
    power:3//输入能量
    },
    output: {
    items:["sc-储液罐-水"],//输出物品
    //fluids:[],//输出流体
    //"power":5//输出能量
    },
    craftTime:15//生产时间
    },
    
    {
    input: {
    items:["sc-储液罐"],//输入物品
    fluids:["oil/30"],//输入流体
    power:3//输入能量
    },
    output: {
    items:["sc-储液罐-石油"],//输出物品
    //fluids:[],//输出流体
    //"power":5//输出能量
    },
    craftTime:15//生产时间
    },
    
    {
    input: {
    items:["sc-储液罐/1"],//输入物品
    fluids:["slag/30"],//输入流体
    //"power":5//输入能量
    },
    output: {
    items:["sc-储液罐-矿渣"],//输出物品
    //fluids:[],//输出流体
    // "power":5//输出能量
    },
    craftTime:15//生产时间
    },	

    {
    input: {
    items:["sc-储液罐-矿渣/1"],//输入物品       
    power:3//输入能量
    },
    output: {
    // "items":["sc-储液罐-水"],//输出物品
    fluids:["slag/30"],//输出流体
    // "power":5//输出能量
    },
    craftTime:15//生产时间
    },
    
    {
    input: {
    items:["sc-储液罐-水/1"],//输入物品       
    power:3//输入能量
    },
    output: {
    //"items":["sc-储液罐-水"],//输出物品
    fluids:["water/30"],//输出流体
    //"power":5//输出能量
    },
    craftTime:15//生产时间
    },
    
    {
    input: {
    items:["sc-储液罐-石油/1"],//输入物品
              
    power:3//输入能量
    },
    output: {
    //"items":["sc-储液罐-水"],//输出物品
    fluids:["oil/30"],//输出流体
    },
    craftTime:15//生产时间
    },
    
    {
    input: {
    items:["titanium/30","metaglass/40"],//输入物     
    power:3//输入能量
    },
    output: {
    items:["sc-储液罐"],//输出物品
    },
    craftTime:30//生产时间
    },
]);//搬MinecraftMore的