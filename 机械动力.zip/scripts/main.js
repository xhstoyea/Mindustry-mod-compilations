const lib = require("base/机械动力lib")
require("机械飞升")
require("机械崛起")
require("方块/超级火力发电机")
require("提示")
require("方块/末影箱")
//print("流体卸载")
//require("方块/倾灌站")
//require("lib")
//require("方块/核裂")
require("方块/资源传输")
/*const myModName = "JXDL";
Vars.mods.locateMod(myModName).root.child("scripts").findAll().each(i=>{
    if (i.name()!="main.js") require(i.path().replace(Vars.mods.locateModmyModName).root.name()+"/scripts/","").replace(".js",""))
});*/