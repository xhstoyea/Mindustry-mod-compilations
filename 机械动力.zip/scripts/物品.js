exports.储液罐 = (() => {
var myitem = extendContent(Item, '储液罐', {});
return myitem;})();
exports.储液罐-矿渣 = (() => {
var myitem = extendContent(Item, '储液罐-矿渣', {});
return myitem;})();
exports.储液罐-石油 = (() => {
var myitem = extendContent(Item, '储液罐-石油', {});
return myitem;})();
exports.储液罐-水 = (() => {
var myitem = extendContent(Item, '储液罐-水', {});
return myitem;})();