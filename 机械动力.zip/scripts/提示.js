Events.on(EventType.ClientLoadEvent, cons(e => {

    var dialog = new JavaAdapter(BaseDialog, {}, "机械动力");
    var icon =new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find("机械动力-提示", Core.atlas.find("clear")));
    dialog.shown(run(() => {
        dialog.cont.table(Tex.button, cons(t => {
            t.defaults().size(120, 88).right();
            t.button("关闭", icon, Styles.cleart, run(() => {
                dialog.hide();
            }));
        t.add("欢迎游玩，如果\n在游玩的过程中\n发现了bug请\n反馈给作者！！！")
        }));
    }));
    dialog.show();
}));