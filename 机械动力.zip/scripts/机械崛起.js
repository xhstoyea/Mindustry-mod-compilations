const lib = require("base/机械动力lib");

const 机械崛起 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(机械崛起, 5));
        this.super$load();
    }
}, "机械崛起", Planets.sun,  1);
机械崛起.generator = new SerpuloPlanetGenerator();
const sS = require("sectorSize");
sS.planetGrid(机械崛起, 3.3);
机械崛起.allowLaunchSchematics = true
机械崛起.atmosphereColor = Color.valueOf("#006000");
机械崛起.atmosphereRadIn = 0.05;//
机械崛起.atmosphereRadOut = 0.9;//
机械崛起.localizedName = "机械崛起";
机械崛起.visible = true;
机械崛起.bloom = false;
机械崛起.accessible = true;
机械崛起.alwaysUnlocked = true;
机械崛起.startSector = 3;
机械崛起.orbitRadius = 200

const 困难生存 = new SectorPreset("困难生存", 机械崛起, 1);
困难生存.captureWave = 500;
困难生存.alwaysUnlocked = true;
困难生存.addStartingItems = true;
困难生存.difficulty = 10;
困难生存.localizedName = "高危领地"//葱域
