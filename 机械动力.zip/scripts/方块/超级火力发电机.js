const 超级火力发电机 = new ConsumeGenerator("超级火力发电机")

超级火力发电机.consume(new ConsumeItemFlammable())//燃烧性物品
/*

超级火力发电机.consume(new ConsumeItemExplosive())//爆炸性物品*/