const library = require("base/MultiCrafter");
const myitems = require("物品");
const 灌注站 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "倾灌站", [
  {
    input: {
      items: ["titanium/30","metaglass/40"],
      power: 5
    },
    output: {
      items: ["JXDL-储液罐/1"],
    },
    craftTime: 60,
  }, 
  {
    input: {
      items: ["储液罐/1"],     
      liquids: ["slag/30"],
      power: 5
    },
    output: {
      items: ["JXDL-储液罐-矿渣/1"],
    },
    craftTime: 60,
  },
  {
    input: {
      items: ["储液罐/1"],     
      liquids: ["oil/30"],
      power: 5
    },
    output: {
      items: ["JXDL-储液罐-石油/3"],
    },
    craftTime: 60,
  },
  {
    input: {
      items: ["储液罐/1"],     
      liquids: ["water/30"],
      power: 5
    },
    output: {
      items: ["JXDL-储液罐-水/3"],
    },
    craftTime: 60,
  },
{
    input: {
      items: ["储液罐-水/1"],
      power: 5
    },
    output: {
      items: ["JXDL-储液罐/1"],
      liquids: ["water/30"],
    },
    craftTime: 60,
  },
{
    input: {
      items: ["储液罐-矿渣/1"],
      power: 5
    },
    output: {
      items: ["JXDL-储液罐/1"],
      liquids: ["slag/30"],
    },
    craftTime: 60,
  },
{
    input: {
      items: ["储液罐-石油/1"],
      power: 5
    },
    output: {
      items: ["JXDL-储液罐/1"],
      liquids: ["oil/30"],
    },
    craftTime: 60,
  },
  
  
]);