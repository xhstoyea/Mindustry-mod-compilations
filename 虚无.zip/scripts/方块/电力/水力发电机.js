const item = require("物品")

Attribute.add("水");

function DeepWater(floor, amount){
	return floor.attributes.set(Attribute.get("水"), amount / 4);
}
DeepWater(Blocks.deepwater,1.5)
DeepWater(Blocks.water,1)
DeepWater(Blocks.taintedWater,1),
DeepWater(Blocks.deepTaintedWater,1.5)
DeepWater(Blocks.darksandTaintedWater,0.5)
DeepWater(Blocks.sandWater,0.5)
DeepWater(Blocks.darksandWater,0.5)

const 水力发电机 = new ThermalGenerator("水力发电机")
exports.水力发电机 = 水力发电机;
Object.assign(水力发电机,{
    requirements: ItemStack.with(),
	buildVisibility: BuildVisibility.shown,
	category: Category.power,
	powerProduction: 15,
	size: 2,
	floating: true,
	attribute: Attribute.get("水"),
})