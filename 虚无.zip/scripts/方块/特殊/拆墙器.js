const timerBreak = 180;
const maxsize = 1;

const 拆墙器 = extend(Block, "拆墙器", {
    drawPlace(x, y, rotation, valid){
        this.super$drawPlace(x, y, rotation, valid);

        x *= Vars.tilesize;
        y *= Vars.tilesize;
        x += this.offset;
        y += this.offset;
        var rect = Tmp.r2;
        rect.setCentered(x, y, maxsize * Vars.tilesize);
        var len = Vars.tilesize * maxsize;

        rect.x += Geometry.d4x[rotation] * len;
        rect.y += Geometry.d4y[rotation] * len;

        Drawf.dashRect(valid ? Pal.accent : Pal.remove, rect);
    }
});
拆墙器.size = 1;
拆墙器.category = Category.effect;
拆墙器.requirements = ItemStack.with();
拆墙器.buildVisibility = BuildVisibility.shown;
拆墙器.rotate = true; 
拆墙器.drawArrow = false;
拆墙器.update = true;
    拆墙器.solid = true;
        拆墙器.destructible = true;
拆墙器.buildType = prov(() => {
    var timer = 0;

    return extend(Building, {
        updateTile() {
            this.bk();
        },

        bk(){
            var tile = Vars.world.tile(this.tileX() + Geometry.d4x[this.rotation], this.tileY() + Geometry.d4y[this.rotation]);
            if(tile != null && tile.block() != null && tile.build == null && tile.block().solid && !tile.block().breakable && tile.block().size <= maxsize){
                timer += Time.delta;
                if(timer >= timerBreak){
                    Vars.world.tile(tile.x, tile.y).setAir();
                    this.kill();
                }
            }
        },

        draw(){
            this.super$draw();
            var s = Math.ceil((timerBreak - timer)/60);
            var text = "{" + s + "}"

            Fonts.def.draw(text, this.x, this.y, Color.red, 0.35, true, Align.center);
        }
    });
})