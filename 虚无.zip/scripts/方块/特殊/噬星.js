const CoreFrontline = extend(ItemTurret, "噬星", {
	canBreak(tile) {
		return Vars.state.teams.cores(tile.team()).size > 1;
	},
	canReplace(other) {
		return other.alwaysReplace;
	},
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.cores(team).size >= 4 && Vars.state.teams.get(team).getCount(this) < 1;
	},
});