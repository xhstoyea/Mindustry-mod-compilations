const item = require("物品")
const 破裂 = new StatusEffect("破裂")

const 衰弱墙 = new Wall("衰弱墙")
Object.assign(衰弱墙, {
    health: 800,
	size: 1,
	category: Category.defense,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		item.虚空石, 6,
		item.虚空钢, 5,
	),
	});

衰弱墙.buildType = prov(() => extend(Building,{
              draw(){
              this.super$draw();
        Units.nearby(null,this.x,this.y,64,other => {
               if(other.team != this.team)
               {
                  other.apply(破裂,10);
               }
         })
        Draw.color(Color.valueOf('2e2a30'));
        Draw.alpha(0.8);
        Draw.z(Layer.shields);
        Fill.poly(this.x, this.y, 12, 64);
  },
}));
exports.衰弱墙 = 衰弱墙;

const 大型衰弱墙 = new Wall("大型衰弱墙")
Object.assign(大型衰弱墙, {
    health: 3600,
	size: 2,
	category: Category.defense,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		item.虚空石, 28,
		item.虚空钢, 30,
	),
	});

大型衰弱墙.buildType = prov(() => extend(Building,{
              draw(){
              this.super$draw();
        Units.nearby(null,this.x,this.y,128,other => {
               if(other.team != this.team)
               {
                  other.apply(破裂,45);
               }
         })
        Draw.color(Color.valueOf('2e2a30'));
        Draw.alpha(0.8);
        Draw.z(Layer.shields);
        Fill.poly(this.x, this.y, 24, 128);
  },
}));
exports.大型衰弱墙 = 大型衰弱墙;

const 超大型衰弱墙 = new Wall("超大型衰弱墙")
Object.assign(超大型衰弱墙, {
    health: 7500,
	size: 3,
	category: Category.defense,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		item.虚空石, 50,
		item.虚空钢, 40,
	),
	});

超大型衰弱墙.buildType = prov(() => extend(Building,{
              draw(){
              this.super$draw();
        Units.nearby(null,this.x,this.y,256,other => {
               if(other.team != this.team)
               {
                  other.apply(破裂,80);
               }
         })
        Draw.color(Color.valueOf('2e2a30'));
        Draw.alpha(0.8);
        Draw.z(Layer.shields);
        Fill.poly(this.x, this.y, 48, 256);
  },
}));
exports.超大型衰弱墙 = 超大型衰弱墙;