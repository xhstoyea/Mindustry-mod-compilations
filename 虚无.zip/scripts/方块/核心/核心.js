const 可摆放核心 = extend(CoreBlock, "可摆放核心", {
canBreak(){return true;},
canPlaceOn(tile, team){return true;},
//replaceable(){return false;},
});

const CoreFrontline = extend(CoreBlock, "限制性可摆放核心", {
	canBreak(tile) {
		return Vars.state.teams.cores(tile.team()).size > 1;
	},
	canReplace(other) {
		return other.alwaysReplace;
	},
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.cores(team).size < 7;
	}
});
