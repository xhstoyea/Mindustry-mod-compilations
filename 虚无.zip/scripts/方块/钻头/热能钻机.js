const DrillBuild = Drill.DrillBuild;

var heatRequirement = 5;
var overheatScale = 1;
var maxEfficiency = 2.5;

let heatDrill = Object.assign(extend(Drill, "热能钻机", {
    setBars(){
        this.super$setBars();
        
        this.addBar("heat", e => new Bar(
            () => Core.bundle.format("bar.heatpercent", parseInt(e.heat()), parseInt(e.efficiencyScale() * 100)),
            () => Pal.lightOrange,
            () => parseInt(e.heat()) / heatRequirement));
    },
}), {
    size: 4,
    drillTime: 2400,
    tier: 4,
});

heatDrill.setupRequirements(
    Category.production,
    BuildVisibility.shown,
    ItemStack.with()
);

var block = heatDrill;

heatDrill.buildType = () => {
    let sideHeat = new Array(4);
    let heat = 0;

    let build = new JavaAdapter(DrillBuild, HeatConsumer, {
    
        sideHeat(){
            return sideHeat;
        },
        
        heatRequirement(){
            return heatRequirement;
        },
        
        updateTile(){
            heat = this.calculateHeat(sideHeat);

            this.super$updateTile();
        },
        
        warmupTarget(){
            return Mathf.clamp(heat / heatRequirement);
        },
        
        updateEfficiencyMultiplier(){
            this.super$updateEfficiencyMultiplier();
            
            let es = this.efficiencyScale();
        
            this.efficiency *= es;
            this.potentialEfficiency *= es;
        },

        efficiencyScale(){
            let over = Math.max(heat - heatRequirement, 0);
            return Math.min(Mathf.clamp(heat / heatRequirement) + over / heatRequirement * overheatScale, maxEfficiency);
        },
        
        heat(){
            return heat;
        },
        
    }, block);
    
    return build;
}