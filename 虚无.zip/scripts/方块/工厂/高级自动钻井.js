const library = require("base/library");
const myliquids = require("液体");
const myitems = require("物品");
const 高级自动钻井 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "高级自动钻井", [
	{
		input: {
		liquids: ["water/25"],
		power:4,
		},
		output: {
			items: ["copper/1"],
		},
		craftTime: 10,
	},
	{
		input: {
		liquids: ["water/25"],
		power:4,
		},
		output: {
			items: ["lead/1"],
		},
		craftTime: 10,
	},
	{
		input: {
		liquids: ["water/25"],
		power:4,
		},
		output: {
			items: ["sand/1"],
		},
		craftTime: 10,
	},
	{
		input: {
		liquids: ["water/25"],
		power:4,
		},
		output: {
			items: ["coal/1"],
		},
		craftTime: 10,
	},
	{
		input: {
		liquids: ["water/25"],
		power:4,
		},
		output: {
			items: ["titanium/1"],
		},
		craftTime: 10,
	},
	{
		input: {
		liquids: ["water/25"],
		power:4,
		},
		output: {
			items: ["thorium/1"],
		},
		craftTime: 10,
	},
	{
		input: {
		liquids: ["water/25"],
		power:4,
		},
		output: {
			items: ["虚无-铀/1"],
		},
		craftTime: 10,
	},
	{
		input: {
		liquids: ["water/25"],
		power:4,
		},
		output: {
			items: ["虚无-火石矿/1"],
		},
		craftTime: 10,
	},
	{
		input: {
		liquids: ["water/25"],
		power:4,
		},
		output: {
			items: ["虚无-绯红之石/1"],
		},
		craftTime: 10,
	},
	{
		input: {
		liquids: ["water/25"],
		power:4,
		},
		output: {
			items: ["虚无-银/1"],
		},
		craftTime: 10,
	},
	{
		input: {
		liquids: ["water/25"],
		power:4,
		},
		output: {
			items: ["虚无-相位石/1"],
		},
		craftTime: 10,
	},
]);