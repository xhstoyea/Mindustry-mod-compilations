const library = require("base/library");
const myliquids = require("液体");
const myitems = require("物品");
const 补给包组装器 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "补给包组装器", [
	{
		input: {
		items: ["copper/125","lead/100","silicon/100","graphite/100","titanium/100"],
		power:2,
		},
		output: {
			items: ["虚无-应急补给包/1"],
		},
		craftTime: 20,
	},
	{
		input: {
		liquids: ["cryofluid/50"],
		items: ["copper/25",],
		power:2,
		},
		output: {
			items: ["虚无-液体补给包/1"],
		},
		craftTime: 20,
	},
]);