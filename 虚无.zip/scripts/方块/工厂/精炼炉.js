const library = require("base/library");
const myliquids = require("液体");
const myitems = require("物品");
const 精炼炉 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "精炼炉", [
	{
		input: {
		items: ["coal/2","copper/1"],
		power:4,
		},
		output: {
			items: ["虚无-精炼铜/1"],
		},
		craftTime: 20,
	},
	{
		input: {
		items: ["coal/2","lead/1"],
		power:4,
		},
		output: {
			items: ["虚无-精炼铅/1"],
		},
		craftTime: 20,
	},
	{
		input: {
		items: ["coal/2","虚无-石英/1"],
		power:4,
		},
		output: {
			items: ["虚无-精炼石英/1"],
		},
		craftTime: 20,
	},


]);