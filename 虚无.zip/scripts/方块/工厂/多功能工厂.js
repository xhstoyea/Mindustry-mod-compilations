const library = require("base/library");
const myliquids = require("液体");
const myitems = require("物品");
const 多功能工厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "多功能工厂", [
	{
		input: {
		items: ["coal/1","sand/1"],
		power:2,
		},
		output: {
			items: ["silicon/1"],
		},
		craftTime: 60,
	},
	{
		input: {
		items: ["coal/2"],
		power:2,
		},
		output: {
			items: ["graphite/1"],
		},
		craftTime: 60,
	},
	{
		input: {
		items: ["sand/1","lead/1"],
		power:2,
		},
		output: {
			items: ["metaglass/1"],
		},
		craftTime: 10,
	},


]);