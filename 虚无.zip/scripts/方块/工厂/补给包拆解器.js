const library = require("base/library");
const myliquids = require("液体");
const myitems = require("物品");
const 补给包拆解器 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "补给包拆解器", [
	{
		input: {
		items: ["虚无-应急补给包/1"],
		},
		output: {
			items: ["copper/100","lead/100","silicon/100","graphite/100","titanium/100",]
		},
		craftTime: 1,
	},
	{
		input: {
		items: ["虚无-液体补给包/1"],
		power:2,
		},
		output: {
			liquids: ["cryofluid/50"],
		},
		craftTime: 1,
	},
]);