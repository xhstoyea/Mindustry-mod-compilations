const library = require("base/library");
const myliquids = require("液体");
const myitems = require("物品");
const 特殊祭坛 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "特殊祭坛", [
	{
		input: {
			items: ["虚无-虚空钢/2","虚无-虚空石/20"],
			liquids: ["虚无-虚空液/60"],
		},
		output: {
			items: ["虚无-虚空核心/1"],
		},
		craftTime: 20,
	},
	{
		input: {
			items: ["虚无-虚空核心/2"],
		},
		output: {
			items: ["虚无-虚空精华/20"],
		},
		craftTime: 20,
	},
	{
		input: {
			items: ["虚无-虚空核心/2"],
		},
		output: {
			items: ["虚无-未知许可/1"],
		},
		craftTime: 20,
	},


]);