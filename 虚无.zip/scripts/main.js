require("缩放强化");
require("物品");
require("液体");

require("方块/电力/水力发电机");

require("方块/工厂/补给包拆解器");
require("方块/工厂/补给包组装器");
require("方块/工厂/多功能工厂");
require("方块/工厂/高级自动钻井");
require("方块/工厂/精炼炉");
require("方块/工厂/特殊祭坛");
require("方块/工厂/自动钻井");

require("方块/核心/核心");

require("方块/特殊/拆墙器");
require("方块/特殊/噬星");
require("方块/特殊/物品折越台");

require("方块/钻头/热能钻机");

require("方块/wall");