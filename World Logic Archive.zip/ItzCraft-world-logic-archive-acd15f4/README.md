# World Logic Archive

A mod that adds map with world proccesors what can copy everyone
if you want to contribute, suggest wprocs ideas what i should add to map.
