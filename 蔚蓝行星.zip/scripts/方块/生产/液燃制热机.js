let rs = extend(HeatProducer, "液燃制热机", {
	setBars() {
		this.super$setBars();
		this.removeBar("heat");
		this.addBar("heat", func(e => new Bar(
			prov(() => "热量：" + (e.heat * e.itemHeat()).toFixed(2)),
			prov(() => Pal.lightOrange),
			floatp(() => e.heat * e.itemHeat() / e.block.heatOutput)
		)));
	}
});
rs.buildType = prov(() => extend(HeatProducer.HeatProducerBuild, rs, {
	itemHeat() {
		if (this.liquids.current()) {
			return this.liquids.current().flammability;
		} else {
			return 0;
		}
	},
	heat() {
		return this.heat * this.itemHeat();
	}
}));