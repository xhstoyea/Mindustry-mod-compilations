const items = require("ap物品");

const 蓝绒草墙 = new StaticWall("蓝绒草墙");
exports.蓝绒草墙 = 蓝绒草墙;

const 蓝绒草 = new Floor("蓝绒草");
exports.蓝绒草 = 蓝绒草;
Object.assign(蓝绒草, {
	variants: 3,
})

const 墨绿草墙 = new StaticWall("墨绿草墙");
exports.墨绿草墙 = 墨绿草墙;

const 墨绿草 = new Floor("墨绿草");
exports.墨绿草 = 墨绿草;
Object.assign(墨绿草, {
	variants: 3,
})

const 肿瘤墙 = new StaticWall("肿瘤墙");
exports.肿瘤墙 = 肿瘤墙;

const 肿瘤地 = new Floor("肿瘤地");
exports.肿瘤地 = 肿瘤地;
Object.assign(肿瘤地, {
	variants: 3,
	itemDrop: items.生物质,
})

const 沙砾 = new Floor("沙砾");
exports.沙砾 = 沙砾;
Object.assign(沙砾, {
	variants: 3,
})

const 四叶草 = new Prop("四叶草");
exports.四叶草 = 四叶草;
Object.assign(四叶草, {
	variants: 2,
	breakable: true,
	//hasShadow: false,
})

const 瘤池 = new Floor("瘤池");
Object.assign(瘤池, {
	speedMultiplier: 0.5,
	variants: 0,
	statusDuration: 120,
	liquidDrop: Liquids.neoplasm,
	isLiquid: true,
	cacheLayer: CacheLayer.water,
	albedo: 0.9,
	supportsOverlay: true,
	liquidMultiplier: 0.5,
	drownTime: 60 * 1.2,
})

const 沙砾浅滩 = new Floor("沙砾浅滩");
exports.沙砾浅滩 = 沙砾浅滩;
Object.assign(沙砾浅滩, {
	liquidDrop: Liquids.water,
	speedMultiplier: 0.8,
	variants: 0,
	status: StatusEffects.wet,
	statusDuration: 120,
	isLiquid: true,
	cacheLayer: CacheLayer.water,
	albedo: 0.9,
	supportsOverlay: true,
	liquidMultiplier: 1,
})