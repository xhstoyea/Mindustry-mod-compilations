const item = require("ap物品")
const 辐射 = new StatusEffect("辐射")

//钴墙
const 钴墙 = new Wall("钴墙");
exports.钴墙 = 钴墙;
钴墙.researchCostMultiplier = 0.1;
Object.assign(钴墙, {
	health: 440,
	size: 1,
	alwaysUnlocked: false,
	buildVisibility: BuildVisibility.shown,
	category: Category.defense,
	requirements: ItemStack.with(
		item.钴, 6,
	),
})

const 大型钴墙 = new Wall("大型钴墙");
exports.大型钴墙 = 大型钴墙;
Object.assign(大型钴墙, {
	health: 1760,
	armor: 1,
	size: 2,
	alwaysUnlocked: false,
	buildVisibility: BuildVisibility.shown,
	category: Category.defense,
	requirements: ItemStack.with(
		item.钴, 24,
	),
})

//金刚石墙
const 金刚石墙 = new Wall("金刚石墙");
exports.金刚石墙 = 金刚石墙;
Object.assign(金刚石墙, {
	health: 1000,
	size: 1,
	alwaysUnlocked: false,
	buildVisibility: BuildVisibility.shown,
	category: Category.defense,
	requirements: ItemStack.with(
		item.金刚石, 6,
	),
})

const 大型金刚石墙 = new Wall("大型金刚石墙");
exports.大型金刚石墙 = 大型金刚石墙;
Object.assign(大型金刚石墙, {
	health: 4000,
	size: 2,
	alwaysUnlocked: false,
	buildVisibility: BuildVisibility.shown,
	category: Category.defense,
	requirements: ItemStack.with(
		item.金刚石, 24,
	),
})

//氮化硅墙
const 玻璃渣 = Object.assign(new BulletType(0, 0), {
	lifetime: 0,
	hitColor: Color.valueOf("FFFFFF"),
	fragBullets: 5,
	hitEffect: Fx.flakExplosion,
	fragBullet: Object.assign(new BasicBulletType(3, 5), {
		lifetime: 1,
		hitColor: Color.valueOf("FFFFFF"),
		frontColor: Color.valueOf("FFFFFF"),
		backColor: Color.valueOf("FFFFFF"),
		hitEffect: Fx.flakExplosion
	})
})
const 氮化硅墙 = new Wall("氮化硅墙");
氮化硅墙.buildType = prov(() => {
	return extend(Wall.WallBuild, 氮化硅墙, {
		collision(bullet) {
			this.super$collision(bullet);
			玻璃渣.create(this, bullet.x, bullet.y, bullet.rotation() + 90);
			return true
		}
	})
})
Object.assign(氮化硅墙, {
    health: 500,
	size: 1,
	category: Category.defense,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		item.氮化硅, 6,
	),
});
exports.氮化硅墙 = 氮化硅墙;

const 大型氮化硅墙 = new Wall("大型氮化硅墙");
大型氮化硅墙.buildType = prov(() => {
	return extend(Wall.WallBuild, 大型氮化硅墙, {
		collision(bullet) {
			this.super$collision(bullet);
			玻璃渣.create(this, bullet.x, bullet.y, bullet.rotation() + 90);
			return true
		}
	})
})
Object.assign(大型氮化硅墙, {
    health: 2000,
	size: 2,
	category: Category.defense,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		item.氮化硅, 24,
	),
});
exports.大型氮化硅墙 = 大型氮化硅墙;

//钴钢墙
const 钴钢墙 = new Wall("钴钢墙");
exports.钴钢墙 = 钴钢墙;
钴钢墙.researchCostMultiplier = 0.1;
Object.assign(钴钢墙, {
	health: 600,
	size: 1,
	alwaysUnlocked: false,
    absorbLasers: true,
	buildVisibility: BuildVisibility.shown,
	category: Category.defense,
	requirements: ItemStack.with(
		item.钴钢, 6,
	),
})

const 大型钴钢墙 = new Wall("大型钴钢墙");
exports.大型钴钢墙 = 大型钴钢墙;
Object.assign(大型钴钢墙, {
	health: 2400,
	armor: 3,
	size: 2,
	alwaysUnlocked: false,
	absorbLasers: true,
	buildVisibility: BuildVisibility.shown,
	category: Category.defense,
	requirements: ItemStack.with(
		item.钴钢, 24,
	),
})

//巨浪合金墙
const 巨浪合金墙 = new Wall("巨浪合金墙");
exports.巨浪合金墙 = 巨浪合金墙;
巨浪合金墙.researchCostMultiplier = 0.1;
Object.assign(巨浪合金墙, {
	health: 1000,
	armor: 5,
	size: 1,
	alwaysUnlocked: false,
	
	lightningChance : 0.5,
	buildVisibility: BuildVisibility.shown,
	category: Category.defense,
	requirements: ItemStack.with(
		Items.surgeAlloy, 6,
	),
})

const 大型巨浪合金墙 = new Wall("大型巨浪合金墙");
exports.大型巨浪合金墙 = 大型巨浪合金墙;
Object.assign(大型巨浪合金墙, {
	health: 4000,
	armor: 8,
	size: 2,
	alwaysUnlocked: false,
	lightningChance : 0.5,
	buildVisibility: BuildVisibility.shown,
	category: Category.defense,
	requirements: ItemStack.with(
		Items.surgeAlloy, 24,
	),
})

//铀墙
const 铀墙 = new Wall("铀墙")
Object.assign(铀墙, {
    health: 800,
	size: 1,
	category: Category.defense,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		item.铀, 6,
	),
	});

铀墙.buildType = prov(() => extend(Building,{
              draw(){
              this.super$draw();
        Units.nearby(null,this.x,this.y,64,other => {
               if(other.team != this.team)
               {
                  other.apply(辐射,10);
               }
         })
        Draw.color(Color.valueOf('008000'));
        Draw.alpha(0.8);
        Draw.z(Layer.shields);
        Fill.poly(this.x, this.y, 12, 64);
  },
}));
exports.铀墙 = 铀墙;

const 大型铀墙 = new Wall("大型铀墙")
Object.assign(大型铀墙, {
    health: 3200,
	size: 2,
	category: Category.defense,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		item.铀, 24,
	),
	});
大型铀墙.buildType = prov(() => extend(Building,{
              draw(){
              this.super$draw();
        Units.nearby(null,this.x,this.y,128,other => {
               if(other.team != this.team)
               {
                  other.apply(辐射,200);
               }
         })
        Draw.color(Color.valueOf('008000'));
        Draw.alpha(0.8);
        Draw.z(Layer.shields);
        Fill.poly(this.x, this.y, 12, 128);
  },
}));
exports.大型铀墙 = 大型铀墙;

