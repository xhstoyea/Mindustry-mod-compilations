const item = require("ap物品");
const block = require("方块/环境/environment");

//发电机
Attribute.add("水");

function DeepWater(floor, amount){
	return floor.attributes.set(Attribute.get("水"), amount / 4);
}
DeepWater(Blocks.deepwater,1.5)
DeepWater(Blocks.water,1)
DeepWater(Blocks.taintedWater,1),
DeepWater(Blocks.deepTaintedWater,1.5)
DeepWater(Blocks.darksandTaintedWater,0.5)
DeepWater(Blocks.sandWater,0.5)
DeepWater(Blocks.darksandWater,0.5)
DeepWater(block.沙砾浅滩,0.5)

//发电设备
const 潮汐发电机 = new ThermalGenerator("潮汐发电机")
exports.潮汐发电机 = 潮汐发电机;
Object.assign(潮汐发电机,{
    requirements: ItemStack.with(
		item.钴, 60,
		Items.graphite, 40,
	),
	buildVisibility: BuildVisibility.shown,
	category: Category.power,
	powerProduction: 1.5,
	size: 2,
	floating: true,
	attribute: Attribute.get("水"),
})

const 涡轮发电机 = new ConsumeGenerator("涡轮发电机");
exports.涡轮发电机 = 涡轮发电机;
涡轮发电机.buildVisibility = BuildVisibility.shown;
Object.assign(涡轮发电机, {
    requirements: ItemStack.with(
		Items.graphite, 180,
		Items.silicon, 150,
		item.氮化硅, 100,
	)
})

//热量发电机原作者小荔枝
//感谢嗷嗷怪的重制！
const 热量发电机 = Object.assign(
    extend(PowerGenerator, "热量发电机", {
        health: 360,
        size: 3,
        description: "消耗热量加热水来发电。",
        warmupSpeed: 0.4,

        powerProduction: 1,//等效于热效率
        maxHeat: 180,//最多输入热量

        setBars(){
            this.super$setBars();

            this.addBar("heat", entity =>
                new Bar(() =>
                Core.bundle.format("bar.heatpercent", Mathf.round(entity.heat()), Mathf.round(Mathf.clamp(entity.heat() / this.maxHeat) * 100)),
                () => Pal.lightOrange,
                () => entity.heat() / this.maxHeat));
        },
        setStats(){
            this.super$setStats();

            this.stats.add(Stat.input, this.maxHeat, StatUnit.heatUnits);
        }
    }), {
    buildType(){
        var sideHeat = new Array(4);
        var heat = 0, totalProgress = 0, warmup = 0;
        return new JavaAdapter(PowerGenerator.GeneratorBuild, HeatConsumer, {
            updateTile(){
                heat = this.calculateHeat(sideHeat);

                warmup = Mathf.lerpDelta(warmup, this.productionEfficiency > 0 ? 1 : 0, 热量发电机.warmupSpeed);
    
                totalProgress += this.productionEfficiency * Time.delta;
            },
            shouldExplode(){
                return heat > 0;
            },
            totalProgress(){
                return totalProgress;
            },
            warmup(){
                return warmup;
            },
            updateEfficiencyMultiplier(){
                this.efficiency *= Mathf.clamp(heat);
                this.productionEfficiency = this.efficiency * Mathf.clamp(heat, 0, 热量发电机.maxHeat);
            },
            sideHeat(){
                return sideHeat;
            },
            heatRequirement(){
                return 热量发电机.maxHeat;
            },
            heat(){
                return heat;
            },
            write(write){
                this.super$write(write);
    
                write.f(heat);
                write.f(warmup);
            },
            read(read, revision){
                this.super$read(read, revision);
    
                heat = read.f();
                warmup = read.f();
            }
        }, 热量发电机);
    }
});
热量发电机.consumeLiquid(Liquids.water, 3 / 60);
热量发电机.setupRequirements(
    Category.power,
    BuildVisibility.shown,
    ItemStack.with(
        Items.graphite, 220,
        Items.silicon, 150,
		item.氮化硅, 100
    )
);
exports.热量发电机 = 热量发电机;

//电力节点
const 反射节点 = new PowerNode("反射节点");
exports.反射节点 = 反射节点;
Object.assign(反射节点, {
	size: 1,
	maxNodes: 2,
	laserRange: 25,
	health: 40,
	category: Category.power,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		Items.graphite, 5,
	)
})

const 散射节点 = new PowerNode("散射节点");
exports.散射节点 = 散射节点;
Object.assign(散射节点, {
	size: 1,
	maxNodes: 10,
	laserRange: 15,
	health: 40,
	category: Category.power,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		Items.graphite, 3,
		item.钴, 3,
	)
})

//电池
const 电容器 = new Battery("电容器");
exports.电容器 = 电容器;
Object.assign(电容器, {
	baseExplosiveness: 1,
	category: Category.power,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		item.钴, 5,
		Items.silicon, 10,
	)
});
电容器.consumePowerBuffered(5000)

const 蓄电池 = new Battery("蓄电池");
exports.蓄电池 = 蓄电池;
Object.assign(蓄电池, {
    size: 2,
	baseExplosiveness: 4,
	category: Category.power,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		Items.silicon, 20,
		item.氮化硅, 10,
	)
});
蓄电池.consumePowerBuffered(50000)