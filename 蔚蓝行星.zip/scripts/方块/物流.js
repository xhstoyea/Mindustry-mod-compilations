const item = require('ap物品');

const 隔离阀 = new Junction("隔离阀");
exports.隔离阀 = 隔离阀;
Object.assign(隔离阀, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		Items.graphite, 5
	),
	health: 40,
	speed: 20,
})

const 分配阀 = new DuctRouter("分配阀");
exports.分配阀 = 分配阀;
Object.assign(分配阀, {
	category: Category.distribution,
	requirements: ItemStack.with(
		Items.graphite, 5
	),
	health: 40,
	speed: 0.2,
	regionRotated1: 1,
	solid: false,
})

const 路由阀 = new Router("路由阀");
exports.路由阀 = 路由阀;
Object.assign(路由阀, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		Items.graphite, 5
	),
	health: 40,
	speed: 0.2,
	solid: false,
})

const 传送桥 = new BufferedItemBridge("传送桥");
exports.传送桥 = 传送桥;
Object.assign(传送桥, {
	requirements: ItemStack.with(
		Items.graphite, 10,
		item.钴, 5
	),
	health: 40,
	fadeIn: false,
	moveArrows: false,
	range: 5,
	arrowSpacing: 6,
	hasPower:false,
	speed:34,
	bufferCapacity:10,
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
})

const 溢流阀 = new OverflowGate("溢流阀");
exports.溢流阀 = 溢流阀;
Object.assign(溢流阀, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		Items.graphite, 5,
		item.钴, 5
	),
	health: 40,
})

const 反向溢流阀 = new OverflowGate("反向溢流阀");
exports.反向溢流阀 = 反向溢流阀;
Object.assign(反向溢流阀, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		Items.graphite, 5,
		item.钴, 5
	),
	invert: true,
	health: 40,
})

const 反向分类阀 = new Sorter("反向分类阀");
exports.反向分类阀 = 反向分类阀;
Object.assign(反向分类阀, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		Items.graphite, 5,
		item.钴, 5
	),
	health: 40,
	invert: true,
})

const 分类阀 = new Sorter("分类阀");
exports.分类阀 = 分类阀;
Object.assign(分类阀, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		Items.graphite, 5,
		item.钴, 5
	),
	health: 40,
})

const 石墨传送带 = new Conveyor("石墨传送带");
exports.石墨传送带 = 石墨传送带;
石墨传送带.researchCostMultiplier = 0.5;
石墨传送带.junctionReplacement = 隔离阀;
石墨传送带.bridgeReplacement = 传送桥;
Object.assign(石墨传送带, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		Items.graphite, 1
	),
	health: 40,
	speed: 0.047,
	displayedSpeed: 6.3,
});

const 氮化硅传送带 = new Conveyor("氮化硅传送带");
exports.氮化硅传送带 = 氮化硅传送带;
氮化硅传送带.researchCostMultiplier = 0.5;
氮化硅传送带.junctionReplacement = 隔离阀;
氮化硅传送带.bridgeReplacement = 传送桥;
Object.assign(氮化硅传送带, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		Items.graphite, 1,
		item.氮化硅, 1
	),
	health: 60,
	speed: 0.134,
	displayedSpeed: 17.3,
});

const 定向传送带 = new ArmoredConveyor("定向传送带");
exports.定向传送带 = 定向传送带;
定向传送带.researchCostMultiplier = 0.5;
定向传送带.junctionReplacement = 隔离阀;
定向传送带.bridgeReplacement = 传送桥;
Object.assign(定向传送带, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		item.氮化硅, 1,
		item.镉, 1
	),
	health: 120,
	speed: 0.134,
	displayedSpeed: 17.3,
});

const 钴钢传送带 = new StackConveyor("钴钢传送带");
exports.钴钢传送带 = 钴钢传送带;
Object.assign(钴钢传送带, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		item.氮化硅, 1,
		item.钴钢, 2
	),
	health: 80,
	speed: 0.03,
	researchCostMultiplier: 0.5,
	itemCapacity: 10,
});

const 小型质驱 = new MassDriver("小型质驱");
exports.小型质驱 = 小型质驱;
小型质驱.consumePower(1);
Object.assign(小型质驱, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		Items.graphite, 120,
		Items.silicon, 100,
		item.钴钢, 80
	),
	size: 2,
	health: 160,
	reload: 150,
	range: 280,
	hasPower: true,
	itemCapacity: 60,
})