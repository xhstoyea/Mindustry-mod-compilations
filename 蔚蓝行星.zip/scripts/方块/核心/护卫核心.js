const myitems = require("ap物品");

const 护卫 = new UnitType("护卫");
Object.assign(护卫, {
	coreUnitDock: true,
	aiController: UnitTypes.evoke.aiController,
	controller: u => new BuilderAI(true, 384),
	isEnemy: false,
	fogRadius: 0,
	lowAltitude: true,
	flying: true,
	mineSpeed: 6,
	mineHardnessScaling: false,
	mineTier: 2,
	buildSpeed: 1.5,
	drag: 0.05,
	speed: 4,
	rotateSpeed: 15,
	accel: 0.1,
	itemCapacity: 60,
	payloadCapacity: 256,
	health: 300,
	engineOffset: 7,
	hitSize: 10,
	alwaysUnlocked: true,
	targetable: false,
	hittable: false,
	constructor: () => new UnitEntity.create(),
});
护卫.weapons.add(
Object.assign(new Weapon(), {
	shootSound: Sounds.missile,
	top: true,
	mirror: false,
	rotate: false,
	x: 0,
	y: 3,
	reload: 30,
	bullet: Object.assign(new LaserBoltBulletType(), {
		speed: 5,
		lifetime: 32,
		width: 2,
		height: 8,
		ammoMultiplier: 1,
		healPercent: 3,
		backColor: (Color.valueOf('98FFA9FF')),
		collidesGround: true,
		collidesTeam: true,
		damage: 11,
		buildingDamageMultiplier: 0,
		pierceCap: 3,
	})
}));

const 护卫炮台 = extend(ItemTurret, 护卫炮台, {});
Object.assign(护卫炮台, {
	size: 2,
	range: 20,
	reload: 30,
	shootCone: 5,
	inaccuracy: 0,
	rotateSpeed: 8,
	targetAir: true,
	shootSound: Sounds.shootAlt,
	category: Category.turret,
	sprite:护卫炮台,
	solid:false,
})
护卫炮台.drawer = new DrawTurret("透明-");
护卫炮台.ammo(
Items.graphite, Object.assign(new BasicBulletType(3, 20), {
	lifetime: 50,
	speed: 4,
	damage: 25,
	width: 11,
	height: 11,
	collidesTiles: false,
	trailWidth: 2.1,
    trailLength: 10,
}), )

let range = 520; //俩圆半径，炮塔射程

const core = extend(CoreBlock, "护卫核心", {
	drawPlace(x, y, rotation, valid) {
		this.super$drawPlace(x, y, rotation, valid);
		Drawf.dashCircle(x * 8 + this.offset, y * 8 + this.offset, range, Pal.accent);
	}
});
core.buildVisibility = BuildVisibility.shown;
core.update = true; //允许update
core.hasItems = true; //可以有物品流通
core.health = 3000;
core.size = 4;
core.itemCapacity = 8000;
core.unitType = 护卫;
core.unitCapModifier = 18;
core.category = Category.effect;

core.requirements = ItemStack.with(
Items.graphite, 2500,
Items.silicon, 2000,
myitems.镉, 1800,
);

let HealCore = new Effect(100, e =>{
	 Draw.color(Color.valueOf("8BE8AA"));
	 Fill.square(e.x,e.y,e.fslope() * 1.5 + 0.14, 45);
});

core.buildType = prov(() => {
	const p = new BuildPayload(护卫炮台, Team.derelict); //这里写炮塔
	return extend(CoreBlock.CoreBuild, core, {
		updateTile() {
			this.super$updateTile();
			if (this.healthf() < 1) {
				this.heal(5000 / 15000);
				if (this.timer.get(12))
				HealCore.at(this.x + Mathf.range(3 * Vars.tilesize / 2 - 1), this.y + Mathf.range(3 * Vars.tilesize / 2 - 1));
			}
			if (p.build.team != this.team) {
				p.build.team = this.team;
			}
			p.update(null, this);
			if (p.build.acceptItem(this, Items.graphite) && this.team.core()
				.items.get(Items.graphite) >= 1) {
				p.build.handleItem(this, Items.graphite);
				this.team.core()
					.items.remove(Items.graphite, 1);
			}
			p.set(this.x, this.y, p.build.payloadRotation);
		},
		draw() {
			this.super$draw();
			p.draw();
		},
		drawSelect() {
			this.super$drawSelect();
			Drawf.dashCircle(this.x, this.y, range, Pal.accent); //点击时显示的虚线圆
		},
		handleDamage(amount) {
			amount = Math.min(amount * 10, amount + this.block.armor);
			return Damage.applyArmor(amount * 0.9, this.block.armor); //受伤倍率
		}
	})
});
exports.护卫核心 = core;
exports.护卫炮台 = 护卫炮台;

print(护卫炮台);