const 物品 = require("ap物品");

const 气压钻头 = new Drill("气压钻头");
exports.气压钻头 = 气压钻头;
Object.assign(气压钻头, {
    health: 160,
	tier: 2,
	drillTime: 390,
	size: 2,
	alwaysUnlocked: false,
	//hiddenOnPlanets: [Planets.erekir,Planets.serpulo],
	buildVisibility: BuildVisibility.shown,
	category: Category.production,
	requirements: ItemStack.with(
	Items.graphite, 15,
	),
})
气压钻头.consumeLiquid(Liquids.water, 0.05).boost()
气压钻头.researchCostMultiplier = 0.05;