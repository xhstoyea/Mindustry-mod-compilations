const 初代培养机 = new UnitFactory("初代培养机")

let x = [0,4,4,-4,-4], y = [0,-4,4,-4,4];
初代培养机.buildType = prov(() => extend(UnitFactory.UnitFactoryBuild, 初代培养机,{
    draw(){
        this.super$draw();
        
        Draw.z(35.001);
        
        Draw.color(Color.valueOf("68FFCFFF"), 0.65);
        Draw.rect(Core.atlas.find("ap-初代培养机-liquid"), this.x, this.y);
        
        Draw.color(Color.valueOf("68FFCFFF"));
        
        if(Time.time % 30 <= 1){
            for(let i = 0;i < 5;i++){
                x[i] = Mathf.range(8)
                y[i] = Mathf.range(8)
            }
        }
        if(this.progress >= 0.001){
            Lines.stroke(0.2 + (this.progress % 30) / 100);
            for(let i = 0;i < 5;i++){
                Lines.poly(this.x + x[i], this.y + y[i], 8, (this.progress % 30) / 20);
            }
        }
        Draw.color();
        
        if(this.rotation <= 1){
            Draw.rect(Core.atlas.find("ap-初代培养机-out"), this.x, this.y, this.rotation * 90);
        }else{
            Draw.rect(Core.atlas.find("ap-初代培养机-out"), this.x, this.y, this.rotation * 90);
        }
    }
}))