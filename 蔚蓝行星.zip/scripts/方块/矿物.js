const item = require('ap物品')

new OreBlock("钴矿",item.钴);
new OreBlock("镉矿",item.镉);
new OreBlock("铀矿",item.铀);
new OreBlock("石墨矿",Items.graphite);