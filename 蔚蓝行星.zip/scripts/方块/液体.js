const item = require('ap物品');

const 冷凝机 = new GenericCrafter('冷凝机');
exports.冷凝机 = 冷凝机

const 泵 = new Pump("泵");
exports.泵 = 泵;
Object.assign(泵, {
	size: 2,
	pumpAmount: 0.25,
	health: 160,
	liquidCapacity: 30,
	hasPower: true,
	buildVisibility: BuildVisibility.shown,
	category: Category.liquid,
	requirements: ItemStack.with(
		Items.graphite, 60,
		Items.silicon, 50,
	)
})
泵.consumePower(0.3);

const 导管路由器 = new LiquidRouter("导管路由器");
exports.导管路由器 = 导管路由器;
Object.assign(导管路由器, {
    health: 40,
	buildVisibility: BuildVisibility.shown,
	category: Category.liquid,
	requirements: ItemStack.with(
		Items.graphite, 4,
		item.钴, 2,
	),
	liquidCapacity: 20
});

const 导管交叉器 = new LiquidJunction("导管交叉器");
exports.导管交叉器 = 导管交叉器;
Object.assign(导管交叉器, {
    health: 40,
	buildVisibility: BuildVisibility.shown,
	category: Category.liquid,
	requirements: ItemStack.with(
		Items.graphite, 8,
		item.钴, 4
	),
})

const 液体容器 = new LiquidRouter("液体容器");
exports.液体容器 = 液体容器;
Object.assign(液体容器, {
    health: 160,
	buildVisibility: BuildVisibility.shown,
	category: Category.liquid,
	requirements: ItemStack.with(
		Items.graphite, 10,
		item.钴, 15
	),
	liquidCapacity: 800,
	size: 2,
})

const 液体库 = new LiquidRouter("液体库");
exports.液体库 = 液体库;
Object.assign(液体库, {
    health: 360,
	buildVisibility: BuildVisibility.shown,
	category: Category.liquid,
	requirements: ItemStack.with(
		item.钴, 30,
		item.氮化硅, 45
	),
	liquidCapacity: 2000,
	size: 3
})

const 导管桥 = new LiquidBridge("导管桥");
exports.导管桥 = 导管桥;
Object.assign(导管桥, {
	fadeIn: false,
	moveArrows: false,
	hasPower: false,
	range: 5,
	arrowSpacing: 6,
	buildVisibility: BuildVisibility.shown,
	category: Category.liquid,
	requirements: ItemStack.with(
		Items.graphite,10,
		item.钴, 5,
	),
})

const 石墨导管 = new Conduit("石墨导管");
exports.石墨导管 = 石墨导管;
石墨导管.junctionReplacement = 导管交叉器;
石墨导管.bridgeReplacement = 导管桥;
Object.assign(石墨导管, {
	health: 40,
	liquidCapacity: 20,
	liquidPressure: 1.05,
	buildVisibility: BuildVisibility.shown,
	category: Category.liquid,
	requirements: ItemStack.with(
		Items.graphite, 1,
	)
});