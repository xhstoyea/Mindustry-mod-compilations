const nodeProduce = TechTree.nodeProduce;
const nodeRoot = TechTree.nodeRoot;
const node = TechTree.node;

const item = require('ap物品');
const 排序 = require('排序');
const planet = require("莱蒙星/莱蒙");
const 物流 = require('方块/物流');
const 墙 = require('方块/城墙/城墙');
const 钻头 = require('方块/钻头');
const 炮塔 = require("方块/炮塔");
const {恢复核心} = require('方块/核心/恢复核心');
const {护卫核心} = require('方块/核心/护卫核心');
const 电力 = require('方块/电力/电力');
const 液体 = require('方块/液体');
const 沙化机 = require("方块/生产/沙化机");
const maps = require("莱蒙星/莱蒙");


planet.莱蒙.techTree = nodeRoot("Limen", 恢复核心, () => {

    node(物流.石墨传送带, () => {
        node(物流.隔离阀, () => {
            node(物流.传送桥, () => {});
            node(物流.路由阀, () => {});
            node(物流.溢流阀, () => {
                node(物流.反向溢流阀, () => {});
                node(物流.分类阀, () => {
                    node(物流.反向分类阀, () => {});
                });
            });
        });
        node(物流.氮化硅传送带, () => {
            node(物流.小型质驱, () => {});
            node(物流.定向传送带, () => {});
        });
    });

    node(钻头.气压钻头, () => {
        node(沙化机.沙化机, () => {});
        node(液体.冷凝机, () => {
            node(液体.石墨导管, () => {
                node(液体.导管交叉器, () => {
                    node(液体.导管路由器, () => {});
                    node(液体.导管桥, () => {});
                    node(液体.液体容器, () => {
                        node(液体.液体库, () => {});
                    });
                });
            });
            node(液体.泵, () => {});
        });
    });

    node(电力.潮汐发电机, Seq.with(new Objectives.OnSector(maps.荒芜沙漠)), () => {
        node(电力.反射节点, () => {
            node(电力.散射节点, () => {});
            node(电力.电容器, () => {
                node(电力.蓄电池, () => {});
            });
        });
        node(电力.涡轮发电机, () => {
            node(电力.热量发电机, () => {});
        });
    });

    node(墙.钴墙, () => {
        node(墙.大型钴墙, () => {});
        node(墙.金刚石墙, () => {
            node(墙.大型金刚石墙, () => {});
            node(墙.氮化硅墙, () => {
                node(墙.大型氮化硅墙, () => {});
            });
            node(墙.铀墙, () => {
                node(墙.大型铀墙, () => {});
            });
            node(墙.钴钢墙, () => {
                node(墙.巨浪合金墙, () => {
                    node(墙.大型巨浪合金墙, () => {});
                });
                node(墙.大型钴钢墙, () => {});
            });
        });
    });

    nodeProduce(Items.graphite, () => {
        nodeProduce(item.钴, () => {
            nodeProduce(Items.silicon, () => {
                nodeProduce(item.氮化硅, () => {
                    nodeProduce(Items.surgeAlloy, () => {
                        nodeProduce(item.矢量合金, () => {});
                    });
                });
            });
            nodeProduce(item.金刚石, () => {
                nodeProduce(item.镉, () => {
                    nodeProduce(item.钴钢, () => {
                        nodeProduce(item.铀, () => {
                            nodeProduce(Items.phaseFabric, () => {});
                        });
                    });
                });
            });
            nodeProduce(item.生物质, () => {});
        });
        nodeProduce(Items.sand, () => {});
        nodeProduce(Liquids.water, () => {
            nodeProduce(Liquids.hydrogen, () => {});
            nodeProduce(Liquids.cryofluid, () => {});
        });
        nodeProduce(Liquids.nitrogen, () => {});
    });

});

恢复核心.alwaysUnlocked = true;