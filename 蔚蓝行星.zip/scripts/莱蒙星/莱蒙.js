const lib = require("base/aplib");
const 核心 = require("方块/核心/恢复核心");
const 电力 = require("方块/电力/电力");
const 钻头 = require("方块/钻头");
const 物品 = require("ap物品");
const colorSrc = Liquids.water.color;

const 莱蒙 = new Planet("莱蒙", Planets.sun, 1, 2);
Object.assign(莱蒙, {
	generator: extend(SerpuloPlanetGenerator,  {
		getDefaultLoadout() {
			return Schematics.readBase64("bXNjaAF4nGNgZmBmYWDJS8xNZWB7tmDH0/3NDOzFJamJuZkpDFzFyRmpuYklmcnFDNwpqcXJRZkFJZn5eQwMDGw5iUmpOcUMTNGxjAwiiQW6yflFqbrPGhc9XdILNYaBgRGEgAQAcsQgiQ==");
		},
		allowLanding(sector){return false},
getColor(position){
            // 种子 叠加数量 坚持(每次叠加振幅乘率) 频率 坐标
            let noise = Simplex.noise3d(this.seed, 8, 1, 1, position.x, position.y, position.z);
            if(noise > 0.48){
                return Color.valueOf("438E44FF");
            }
            if(noise < 0.48){
                return colorSrc;
            }
        },
        generateSector(sector){
            this.super$generateSector(sector);
        },
    }),

	/*meshLoader: prov(() => new HexMesh(莱蒙, 4)),
	cloudMeshLoader: () => new MultiMesh(
		new HexSkyMesh(莱蒙, 2, 0.15, 0.14, 5, Color.valueOf("FFFFFF"), 2, 0.42, 1, 0.45)
	),*/

        meshLoader: prov(() => new HexMesh(莱蒙, 4)),
        cloudMeshLoader : () => new MultiMesh(
            new HexSkyMesh(莱蒙, 2, 0.15, 0.14, 5, Color.valueOf("88A4FF80"), 2, 0.42, 1, 0.45),
            new HexSkyMesh(莱蒙, 1, 0.6, 0.16, 5, Color.valueOf("88A4FF80"), 2, 0.45, 1, 0.41)
        ),

	atmosphereColor: Color.valueOf("88A4FFFF"),
	atmosphereRadIn: 0.02,
	atmosphereRadOut: 0.3,
	visible: true,
	bloom: false,
	accessible: true,
	alwaysUnlocked: true,
	startSector: 1,
	camRadius: 0.5,
	orbitRadius: 75,
	orbitSpacing: 2,
	orbitTime: 240 * 60,
	rotateTime: 15 * 60,
	defaultCore: 核心.恢复核心,
	iconColor: Color.valueOf("88A4FFFF"),
    clearSectorOnLose: true, 
})

莱蒙.ruleSetter = r => {
	r.attributes.set(Attribute.heat, -0.3);
	r.attributes.set(Attribute.light, -0.3);
}
莱蒙.totalRadius += 2.6;
莱蒙.hiddenItems.addAll(
	Items.scrap,
	Items.copper,
	Items.lead,
	Items.titanium,
	Items.thorium,
	Items.plastanium,
	Items.sporePod,
	Items.blastCompound,
	Items.pyratite,
	Items.metaglass,
	Items.beryllium,
	Items.tungsten,
	Items.oxide,
	Items.carbide,
	Items.fissileMatter,
	Items.dormantCyst
);

Planets.erekir.hiddenItems.addAll(
    物品.钴,
    物品.镉,
    物品.铀,
    物品.氮化硅,
    物品.矢量合金,
    物品.钴钢,
    物品.金刚石
);

莱蒙.ruleSetter = r => {
    r.bannedBlocks.addAll(
        Blocks.phaseWall,
        Blocks.phaseWallLarge,
        Blocks.surgeWall,
        Blocks.surgeWallLarge
)};

exports.莱蒙 = 莱蒙;

const 偏远山谷 = new SectorPreset("偏远山谷", 莱蒙, 1);//名字 星球 区块
偏远山谷.description = "这里位置偏远，敌人很少，且资源充足，是最佳的降落点。尊敬的指挥官，请尽快在这里建造基地以及防线，抵御敌人的进攻！";
偏远山谷.planet = 莱蒙;
偏远山谷.difficulty = 1;//1-10
偏远山谷.alwaysUnlocked = true;//总是解锁
偏远山谷.addStartingItems = false;//允许添加初始资源
偏远山谷.captureWave = 10;//多少波可占领
偏远山谷.localizedName = "偏远山谷";
exports.偏远山谷 = 偏远山谷;
lib.addToResearch(偏远山谷, {
	parent: "groundZero",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});

const 青青草原/*支线*/ = new SectorPreset("青青草原", 莱蒙, 2);//名字 星球 区块
青青草原.description = "这里没有羊村，只有一大批一大批进攻你的敌人。";
青青草原.difficulty = 2;//1-10
青青草原.captureWave = 15;
青青草原.alwaysUnlocked = false;//总是解锁
青青草原.addStartingItems = false;//允许添加初始资源
青青草原.localizedName = "青青草原";
exports.青青草原 = 青青草原;
lib.addToResearch(青青草原, {
	parent: "偏远山谷",
	objectives: Seq.with(
		new Objectives.SectorComplete(偏远山谷))
});

const 荒芜沙漠 = new SectorPreset("荒芜沙漠", 莱蒙, 2);//名字 星球 区块
荒芜沙漠.description = "这里气候干旱，生物难以生存，敌人的防御并不强大，是极好的落脚点。击败敌人，夺取这片沙漠！";
荒芜沙漠.difficulty = 2;//1-10
荒芜沙漠.alwaysUnlocked = false;//总是解锁
荒芜沙漠.addStartingItems = false;//允许添加初始资源
荒芜沙漠.localizedName = "荒芜沙漠";
exports.荒芜沙漠 = 荒芜沙漠;
lib.addToResearch(荒芜沙漠, {
	parent: "偏远山谷",
	objectives: Seq.with(
		new Objectives.SectorComplete(偏远山谷))
});

const 贫瘠荒漠 = new SectorPreset("贫瘠荒漠", 莱蒙, 3);//名字 星球 区块
贫瘠荒漠.description = "一片沙漠，敌人的防御并不强大，夺取这片区域并不难。";
贫瘠荒漠.difficulty = 2;//1-10
贫瘠荒漠.alwaysUnlocked = false;//总是解锁
贫瘠荒漠.addStartingItems = false;//允许添加初始资源
贫瘠荒漠.localizedName = "贫瘠荒漠";
exports.贫瘠荒漠 = 贫瘠荒漠;
lib.addToResearch(贫瘠荒漠, {
	parent: "荒芜沙漠",
	objectives: Seq.with(
		new Objectives.SectorComplete(偏远山谷))
});

const 肥沃草甸 = new SectorPreset("肥沃草甸", 莱蒙, 4);//名字 星球 区块
肥沃草甸.description = "这里气候适宜，矿产丰富。击败敌人的防线，夺取镉矿！";
肥沃草甸.difficulty = 3;//1-10
肥沃草甸.alwaysUnlocked = false;//总是解锁
肥沃草甸.addStartingItems = false;//允许添加初始资源
肥沃草甸.localizedName = "肥沃草甸";
exports.肥沃草甸 = 肥沃草甸;
lib.addToResearch(肥沃草甸, {
	parent: "荒芜沙漠",
	objectives: Seq.with(
		new Objectives.SectorComplete(荒芜沙漠))
});

const 重工园区 = new SectorPreset("重工园区", 莱蒙, 5);//名字 星球 区块
重工园区.description = "这里是敌人的临时工厂，有重武器把守，占领这里，把它变成你的工厂！";
重工园区.difficulty = 4;//1-10
重工园区.alwaysUnlocked = false;//总是解锁
重工园区.addStartingItems = false;//允许添加初始资源
重工园区.localizedName = "重工园区";
exports.重工园区 = 重工园区;
lib.addToResearch(重工园区, {
	parent: "肥沃草甸",
	objectives: Seq.with(
		new Objectives.SectorComplete(肥沃草甸))
});

const 草原要塞 = new SectorPreset("草原要塞", 莱蒙, 7);//名字 星球 区块
草原要塞.description = "这是敌人的资源要塞。请小心：这里的敌人会生产t3单位压制您！请务必再做好防御的同时尽快攻下这片区域！";
草原要塞.difficulty = 5;//1-10
草原要塞.alwaysUnlocked = false;//总是解锁
草原要塞.addStartingItems = false;//允许添加初始资源
草原要塞.localizedName = "草原要塞";
exports.草原要塞 = 草原要塞;
lib.addToResearch(草原要塞, {
	parent: "重工园区",
	objectives: Seq.with(
		new Objectives.SectorComplete(重工园区))
});

//感谢@Qwop-解决bug！
const 感染区 = new SectorPreset("感染区", 莱蒙, 8);//名字 星球 区块
感染区.description = "这是一片被肿瘤感染的沙漠！敌人异常强大！";
感染区.difficulty = 6;//1-10
感染区.alwaysUnlocked = false;//总是解锁
感染区.addStartingItems = false;//允许添加初始资源
感染区.captureWave = 20;//多少波可占领
感染区.localizedName = "感染区";
exports.感染区 = 感染区;
lib.addToResearch(感染区, {
	parent: "重工园区",
	objectives: Seq.with(
		new Objectives.SectorComplete(重工园区))
});

/*const 昏暗森林 = new SectorPreset("昏暗森林", 莱蒙, 4);//名字 星球 区块
昏暗森林.description = "这里矿产丰富，是敌人的重要基地，我们需要夺取这片森林并进一步研究科技！";
昏暗森林.difficulty = 4;//1-10
昏暗森林.alwaysUnlocked = false;//总是解锁
昏暗森林.addStartingItems = false;//允许添加初始资源
昏暗森林.localizedName = "昏暗森林";
exports.昏暗森林 = 昏暗森林;
lib.addToResearch(昏暗森林, {
	parent: "肥沃草甸",
	objectives: Seq.with(
		new Objectives.SectorComplete(肥沃草甸))
});

/*Planets.serpulo.hiddenItems.addAll(
	item.organosand,
	item.biomass,
	item.ossature,
	item.nickel,
	item.manganese,
	item.crystal,
	item.biomassSteel,
	item.organosilicon,
	item.neoplasmSteel,
	item.methylSulfone
);
Planets.erekir.hiddenItems.addAll(
	item.organosand,
	item.biomass,
	item.ossature,
	item.nickel,
	item.manganese,
	item.crystal,
	item.biomassSteel,
	item.organosilicon,
	item.neoplasmSteel,
	item.methylSulfone
);
*/
