require("ap物品");
require("科技树");
require("排序");
require("方块/环境/environment");
require("方块/生产/沙化机");
require("方块/生产/液燃制热机");
require("方块/物流");
require("方块/矿物");
require("方块/核心/恢复核心");
require("方块/核心/护卫核心");
require("方块/城墙/城墙");
require("方块/单位工厂");
require("方块/钻头");
require("方块/液体");
require("方块/炮塔");
require("方块/电力/电力");
require("莱蒙星/莱蒙");

//以下注释为VSHES荔枝独立完成为了让其他蔚蓝开发者同样可以更新开屏显示窗口插件
Events.on(EventType.ClientLoadEvent, cons(e => {
       var dialogo = new BaseDialog("[green]蔚蓝行星\nAzure Planet");//新建一个显示窗口
	dialogo.buttons.button("@close", run(() => {
		dialogo.hide()//退出此界面
	})).size(210, 64);//按钮用原版@close贴图
    dialogo.buttons.button("意见反馈",run(() => {
        Core.app.openURI("https://docs.qq.com/form/page/DQWJIbGVNYmN1TVV2");
    })).size(210,64);/*感谢荔枝的网址按钮*/

    dialogo.cont.pane(table => {//滑动显示
        
        //table.add(Core.bundle.get("mod.ap.update")).left().growX().wrap().width(600).maxWidth(600).pad(4).labelAlign(Align.left).row();
        
		table.image(Core.atlas.find("logo")).left().size(600, 200).pad(3).row();//显示logo图片

		table.add("[green]欢迎游玩蔚蓝行星模组！\n[white]尊敬的指挥官，我们扫描到了一颗被摧毁的星球，发现了残存的工业遗迹、生物实验室和变异生物。尊敬的指挥官，您的任务是探明文明毁灭的原因，改造这片荒凉星球，建立防御系统，平衡工业与生态，重建这片废土，为未来的生命创造新的希望。[yellow]祝你好运，指挥官！\n\n[white]——————————\n请加QQ群获取最新版蔚蓝行星模组。").left().growX().wrap().pad(4).labelAlign(Align.left).row();/*本段介绍作者：小柠檬*/
		 let label = new FLabel("[white]模组官方QQ群: {rainbow}1031044470");
		 table.add(label).left().row();
		 table.add(
		 "[white]——————————\n[green]v109更新内容\n[white]————工厂————\n[white]降低部分工厂造价。\n[yellow]氮化硅窑炉[white]增加生产速度，提高耗电量。\n[yellow]钴钢熔炼炉[white]提高生产效率。\n[yellow]热量路由器[white]新增建筑，将导入的热量平均分配到其他方向。\n[white]————电力————\n[yellow]涡轮发电机[white]修改为普通涡轮发电机，不需要接通电路。\n[white]————钻头————\n[white]————炮塔————\n[white]重绘T4,T5炮塔底座。\n[yellow]烟花[white]增加伤害。\n[white]————城墙————\n[yellow]巨浪合金墙[white]新增城墙，被攻击时发出闪电。\n[white]————物流————\n[white]————单位————\n[white]————辅助————\n[yellow]储存站, 小型储存站[white]加入科技树。\n[yellow]护卫核心[white]加入科技树。\n[white]————地图————\n[white]————其他————\n"
        ).left().growX().wrap().width(580).maxWidth(590).pad(4).labelAlign(Align.left).row();

	}).grow().center().maxWidth(600)

             dialogo.show();
}))

const lib = require("base/wormlib");

const {UnitEngine} = UnitType;

const exampleSnakeEnd = lib.segment("snakeEnd", {}, {});

const exampleSnakeBody = lib.segment("snakeBody", {
    hitSize: 20,
    engineSize: 0,
    offsetSegment: -1,
    health: 600,
    drawCell: false
}, {});

exampleSnakeBody.setEnginesMirror(
    new UnitEngine(10, 0, 3, 0)
);

const exampleSnake = lib.head("snake", {
    body: exampleSnakeBody,
    end: exampleSnakeEnd,
    lengthSnake: 10,
    hitSize: 20,
    speed: 1.5,
    health: 1000,
    drawCell: false
}, {});


const weaponBombBullet = extend(MissileBulletType, 2.7, 12, {
    width: 6,
    height: 8,
    shrinkY: 0,
    drag: -0.003,
    homingRange: 60,
    keepVelocity: false,
    splashDamageRadius: 10,
    splashDamage: 5,
    lifetime: 80,
    trailColor: Color.gray,
    backColor: Pal.bulletYellowBack,
    frontColor: Pal.bulletYellow,
    hitEffect: Fx.blastExplosion,
    despawnEffect: Fx.blastExplosion,
    weaveScale: 8,
    weaveMag: 1
})

const weaponBomb = extend(Weapon, "snakeBody-weapon", {
    reload: 80,
    shots: 1,
    inaccuracy: 4,
    ejectEffect: Fx.casing3,
    shootSound: Sounds.artillery,
    rotate: true,
    shotDelay: 1,
    x: 0,
    y: -8 / 4,
    shootY: 17 / 4,
    mirror: false,
    top: true,
    shootCone: 2,
    bullet: weaponBombBullet
})


exampleSnakeBody.weapons.add(weaponBomb);

const factorySnake = extend(UnitFactory, "factorySnake", {
    size: 3,
    health: 100,
    produceTime: 100
});

factorySnake.plans.add(
    new UnitFactory.UnitPlan(exampleSnake, 2100, ItemStack.with(Items.silicon, 30, Items.metaglass, 20)));

factorySnake.setupRequirements(Category.units, ItemStack.with(Items.graphite, 45));