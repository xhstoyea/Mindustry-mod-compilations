MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000

require("gongchang/WallFactory");

require('txte');
require("ppp");
require("gongchang/box");
