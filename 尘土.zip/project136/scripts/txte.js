//信息栏
//进游戏显示 搬运请勿移除版权等声明信息
Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("前言");//顶部文字，创建新栏
  // dialog.cont.image(Core.atlas.find("尘土-fa")).row();;//顶部图片
    dialog.buttons.defaults().size(210, 64);//默认按钮尺寸（退出信息栏的大概）
    dialog.show();
    dialog.buttons.button("[red]退出", run(() => { //点击按钮执行“”里为按钮名字
        dialog.hide(); //执行隐藏
    })).size(410, 64); //尺寸
    dialog.cont.pane((() => {
   /*新键栏内容*/ var table = new Table();   
   /*栏内容*/table.add("版本：2.0.3.1\n此为尘土的故事剧情集，[red]但因作者js能力欠缺所以暂时未完工，请直接退出").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
table.button("[blue]继续浏览", run(() => {//*新建按钮，点击时执行
    /*新键按钮内容顶部文字*/var dialog2 = new BaseDialog("目录?");
   /*新键栏内容*/ 
   var tablex= new Table();  
  tablex.add("整不出好活，当更新日志用罢（悲)").left().growX().wrap().width(600).maxWidth(600).pad(4).labelAlign(Align.left);
  dialog2.cont.add(new ScrollPane(tablex)).size(1000, 200).row();
  dialog2.cont.image(Core.atlas.find("尘土-zhi")).row();
   table.row();
  
 //  var g = new Table();
   // g.add("测试").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
  ///*新建栏中导入的图片*/dialog2.cont.image(Core.atlas.find("尘土-fafafafafa")).row();;
    dialog2.buttons.defaults().size(210, 64);//默认按钮尺寸
    dialog2.show();
   
   /* dialog2.cont.pane((() => {
       
      
        table.button("立场", run(() => {//新建‘点击按钮’执行
        dialog2.show();
        var dialog2 = new BaseDialog("立场");
     
var table = new Table();   
            var o = new table();
            o.add("测试").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
            table.row();
            dialog2.buttons.button("返回", run(() => {
                  dialog2.hide();
            })).size(210, 64);
           
    })).size(210, 64).row();
    table.button("科技", run(() => {//新建‘点击按钮’执行
        dialog2.show();
        var dialog2 = new BaseDialog("科技");
            var b = new Table();   
            b.add("测试").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
            table.row();
            dialog2.buttons.button("返回", run(() => {//新建‘点击按钮’执行
                dialog2.hide();
            })).size(210, 64);
         
    })).size(210, 64);
    table.button("资料", run(() => {//新建‘点击按钮’执行
        dialog2.show();
        var dialog2 = new BaseDialog("资料");
            var c = new Table();   
            c.add("测试3").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
            table.row();
            dialog2.buttons.button("返回", run(() => {//新建‘点击按钮’执行
                dialog2.hide();
            })).size(210, 64);
      
    })).size(210, 64);
}))*/
dialog2.buttons.button("资料", run(() => {//新建‘点击按钮’执行
      
    var dialog3 = new BaseDialog("资料");
       var table = new Table();   
        table.add("测试3").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
        dialog3.show();
        dialog3.buttons.button("返回", run(() => {//新建‘点击按钮’执行
            dialog3.hide();
        })).size(210, 64);
  
    })).size(210, 64);
    dialog2.buttons.button("世界", run(() => {//新建‘点击按钮’执行
      
        var dialog4 = new BaseDialog("世界");
        dialog4.show();
            var table = new Table(); 
            var m = new Table();   
            m.add("测试3").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
            table.row();
            dialog4.buttons.button("返回", run(() => {//新建‘点击按钮’执行
                dialog4.hide();
            })).size(210, 64);
      
        })).size(210, 64);
    dialog2.buttons.button("返回", run(() => {//新建‘点击按钮’执行
        dialog2.hide();
    })).size(210, 64);
  
        
    })).size(210, 64).row();//*按钮尺寸  

        return table;
    })()).grow().center().maxWidth(620);
   
}));
//新科技作者提供