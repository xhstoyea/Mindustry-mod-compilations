function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("copperWall")
newItem("phaseFabricWall")
newItem("plastaniumWall")
newItem("surgeAlloyWall")
newItem("thoriumWall")
newItem("titaniumWall")
