const library = require("base/library");
const myitems = require("ppp");
const WallFactory = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "WallFactory", [
  {
    input: {
      items: ["copper/24"],  
      liquids: ["water/12"],   
      power: 0.5,
    },
    output: {
      items: ["尘土-copperWall/1"],
    },
    craftTime: 60,
  }, 
  {
    input: {
      items: ["titanium/24"],  
      liquids: ["water/12"],    
      power: 0.5,
    },
    output: {
      items: ["尘土-titaniumWall/1"],
    },
    craftTime: 60,
  },
  {
    input: {
      items: ["plastanium/24"], 
      liquids: ["water/12"],    
      power: 0.5,
    },
    output: {
      items: ["尘土-plastaniumWall/1"],
    },
    craftTime: 60,
  },
  {
    input: {
      items: ["thorium/24"],  
      liquids: ["water/12"],    
      power: 0.5,
    },
    output: {
      items: ["尘土-thoriumWall/1"],
    },
    craftTime: 80,
  },
{
    input: {
      items: ["phase-fabric/24"],    
      liquids: ["water/12"],  
      power: 0.5,
    },
    output: {
      items: ["尘土-phaseFabricWall/1"],
    },
    craftTime: 60,
  },
  {
    input: {
      items: ["surge-alloy/24"],  
      liquids: ["water/12"],    
      power: 0.5,
    },
    output: {
      items: ["尘土-surgeAlloyWall/1"],
    },
    craftTime: 60,
  },
  
  
]);