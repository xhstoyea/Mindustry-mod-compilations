const amongus = Vars.tree.loadSound("amongus")
const zawarudo = Vars.tree.loadSound("zawarudo")

module.exports = {
    amongus: amongus,
    zawarudo: zawarudo
}
