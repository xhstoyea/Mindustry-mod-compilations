const 便携核心 = extend(CoreBlock, "便携核心", {
    
    canBreak(){return true;},
    canReplace(other){return true;},
    canPlaceOn(tile, team){return true;},
});
exports.便携核心 = 便携核心;