const Saibolen = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(Saibolen, 2));
        this.super$load();
    }
}, "Saibolen", Planets.sun, 3, 1);
Saibolen.generator = new SerpuloPlanetGenerator();
Saibolen.atmosphereColor = Color.valueOf("FFFFFF");
Saibolen.atmosphereRadIn = 0.3;
Saibolen.atmosphereRadOut = 0.5;
Saibolen.localizedName = "Saibolen";
Saibolen.startSector = 1;
Saibolen.alwaysUnlocked = true;
Saibolen.orbitRadius = 500;

const 混乱之地 = new SectorPreset("混乱之地", Saibolen, 1);
混乱之地.alwaysUnlocked = true;
混乱之地.difficulty = 13;
混乱之地.localizedName = "混乱之地";
混乱之地.captureWave = 50
exports.混乱之地 = 混乱之地;

const 虚空战线 = new SectorPreset("虚空战线", Saibolen, 1);
虚空战线.alwaysUnlocked = true;
虚空战线.difficulty = 13;
虚空战线.localizedName = "虚空战线";
虚空战线.captureWave = 50
exports.虚空战线 = 虚空战线;

const 血染星河 = new SectorPreset("血染星河", Saibolen, 1);
血染星河.alwaysUnlocked = true;
血染星河.difficulty = 13;
血染星河.localizedName = "血染星河";
血染星河.captureWave = 50
exports.血染星河 = 血染星河;