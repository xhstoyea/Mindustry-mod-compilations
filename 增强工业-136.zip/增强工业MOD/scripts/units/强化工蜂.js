var ax = extendContent(UnitType, '强化工蜂', {});
ax.defaultController = prov(() => new MinerAI());
ax.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));
