var ax = extendContent(UnitType, '工蜂', {});
ax.defaultController = prov(() => new MinerAI());
ax.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));
