var ax = extendContent(UnitType, '重组治疗者', {});
ax.defaultController = prov(() => new RepairAI());
ax.constructor = prov(() => extend(UnitTypes.mega.constructor.get().class, {}));
