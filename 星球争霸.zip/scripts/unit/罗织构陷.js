const lib = require("base/coflib");
const { newUnit, immunities } = require("unit/units");
const status = require("base/cofstatus");
const ability = require("base/ability");
const bullet = require("base/bullet");
const weapons = require("base/weapon");

function tarantula(name) {
	let u = newUnit(name, LegsUnit, {
		health: 57900,
		hitSize: 32,
		armor: 57,
		drag: 0.05,
		speed: 1.08,
		groundLayer: 75,
		rotateSpeed: 3.6,
		legCount: 6,
		legLength: 36,
		stepShake: 0.2,
		legGroupSize: 3,
		legMoveSpace: 1,
		legExtension: -3,
		legBaseOffset: 14,
		legMaxLength: 1.1,
		legMinLength: 0.2,
		legLengthScl: 0.95,
		legForwardScl: 0.9,
		legSplashRange: 12,
		legSplashDamage: 100,
		hovering: true,
		singleTarget: true,
		lockLegBase: true,
		allowLegStep: true,
		outlineColor: lib.C1F1F1F,
		legContinuousMove: true
	});
	u.abilities.add(Object.assign(new RegenAbility(), {
		percentAmount: 1 / 100
	}), ability.DeathGiftAbility(160, status.屠戮, 900, 0.1, 1000));
	return u;
}

let lz = tarantula("罗织");
function strafe(wx, wy, under) {
	return Object.assign(weapons.ArmorWeapon("罗织机枪", Object.assign(bullet.ArmorBrokenBulletType(17, 237, 23, 0.2, 0.1), {
		width: 4,
		height: 32,
		status: status.破甲,
		statusDuration: 20,
		pierceArmor: false,
		pierceDamageFactor: 0.8,
		hitEffect: Fx.hitSquaresColor,
		hitColor: Pal.bulletYellowBack,
		shootEffect: Fx.shootSmokeSquareSparse
	})), {
		x: wx,
		y: wy,
		recoil: 1,
		shake: 3,
		reload: 3,
		shootY: 19,
		rotate: true,
		inaccuracy: 1,
		shootCone: 5,
		rotateSpeed: 3,
		rotationLimit: 25,
		cooldownTime: 65,
		layerOffset: under ? -0.001 : 0,
		shootSound: Sounds.shootSnap
	})
}
lz.weapons.add(strafe(14, 3.25, true), strafe(-8.5, -11.25));

let gx = tarantula("构陷");
function missile(wx, wy, rotation, under) {
	return Object.assign(new Weapon("curse-of-flesh-构陷导弹"), {
		x: wx,
		y: wy,
		recoil: 2,
		shake: 3,
		shootY: 7,
		reload: 150,
		inaccuracy: 5,
		shootCone: 45,
		baseRotation: -rotation,
		cooldownTime: 65,
		shootStatus: status.突袭,
		shootStatusDuration: 120,
		//shoot: new ShootSpread(2, 10),
		layerOffset: under ? -0.001 : 0,
		shootSound: Sounds.missileLarge,
		bullet: Object.assign(new MissileBulletType(0.6, 373, "curse-of-flesh-crystal"), {
			width: 6,
			height: 9,
			hitShake: 3,
			lifetime: 118,
			drag: -0.03,
			makeFire: true,
			despawnShake: 3,
			homingDelay: 55,
			homingRange: 160,
			homingPower: 0.08,
			status: status.熔融,
			statusDuration: 120,
			keepVelocity: false,
			splashDamage: 173,
			splashDamageRadius: 32,
			scaledSplashDamage: true,
			shootEffect: Fx.shootSmokeSquare,
			backColor: lib.Color("F9C27A"),
			frontColor: lib.Color("FFD37F"),
			trailColor: lib.Color("FFD37F"),
			trailLength: 5,
			trailWidth: 2,
			trailChance: 1,
			trailInterval: 12,
			trailRotation: true,
			trailEffect: new MultiEffect(
				Object.assign(new ParticleEffect(), {
					line: true,
					particles: 3,
					lifetime: 45,
					length: 24,
					baseLength: 0,
					lenFrom: 12,
					lenTo: 0,
					cone: 15,
					offsetX: -15,
					lightColor: lib.Color("F9C27A"),
					colorFrom: lib.Color("FFD37F"),
					colorTo: lib.Color("F9C27A")
				}),
				Object.assign(new ParticleEffect(), {
					particles: 1,
					sizeFrom: 3,
					sizeTo: 0,
					cone: 15,
					length: -50,
					lifetime: 30,
					interp: Interp.pow5Out,
					sizeInterp: Interp.pow5In,
					colorFrom: lib.Color("F9C27A"),
					colorTo: lib.Color("FFD37F")
				})
			),
			hitEffect: new MultiEffect(Fx.titanExplosionSmall, Fx.hitSquaresColor),
			hitColor: lib.Color("F9C27A")
		})
	})
}
gx.weapons.add(missile(13.75, 11.5, 15, true), missile(10.5, 0.5, 25), missile(8.25, -13, 35));

immunities(lz);
immunities(gx);