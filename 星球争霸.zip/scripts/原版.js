//仓储
Blocks.unloader.speed = 3;
Blocks.unloader.selectionColumns = 6;

//电力
Blocks.solarPanel.powerProduction = 0.5;

Blocks.largeSolarPanel.powerProduction = 7.5;

//运输
Blocks.conveyor.speed = 0.06;
Blocks.conveyor.displayedSpeed = 8.4;
Blocks.conveyor.placeableLiquid = true;

Blocks.titaniumConveyor.speed = 0.2;
Blocks.titaniumConveyor.displayedSpeed = 24;
Blocks.titaniumConveyor.placeableLiquid = true;

Blocks.armoredConveyor.speed = 0.2;
Blocks.armoredConveyor.displayedSpeed = 24;
Blocks.armoredConveyor.placeableLiquid = true;

Blocks.plastaniumConveyor.itemCapacity = 20;
Blocks.plastaniumConveyor.placeableLiquid = true;

Blocks.itemBridge.range = 6;
Blocks.itemBridge.speed = 24;
Blocks.itemBridge.transportTime = 2.5;
Blocks.itemBridge.bufferCapacity = 20;
Blocks.itemBridge.placeableLiquid = true;

Blocks.phaseConveyor.transportTime = 1.25;

Blocks.junction.speed = 9;

//液体
Blocks.bridgeConduit.range = 6;

//钻头
Blocks.mechanicalDrill.drillTime = 300;
Blocks.pneumaticDrill.drillTime = 200;
Blocks.laserDrill.drillTime = 140;
Blocks.blastDrill.drillTime = 140;