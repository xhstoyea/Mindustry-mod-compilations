const my = require("base/物品");
const lib = require("base/coflib");
const bullet = require("base/bullet");
const status = require("base/cofstatus");
const FX = require("base/effect/fightFx");
let pro = DrawPart.PartProgress;

let 桎梏 = new ItemTurret("桎梏");
桎梏.ammo(
	my.铈凝块, bullet.VerticalBulletType(2400, 300, 240)
)

lib.setBuilding(ItemTurret.ItemTurretBuild, 桎梏, {
	handleBullet(bullet, offsetX, offsetY, angleOffset) {
		Fx.launchPod.at(this);
		this.items.clear();
		let b = this.peekAmmo();
		FX.launchUp.at(this.x, this.y, 0, b.hitColor, {
			region: lib.region("桎梏-pod"),
			timer: new Interval()
		});
		Time.run(FX.launchUp.lifetime + 240, () => {
			let x = this.targetPos.x, y = this.targetPos.y;
			if (Mathf.dst(this.x, this.y, x, y) / this.block.range > 1) {
				let xy = lib.AngleTrns(Angles.angle(this.x, this.y, x, y), this.block.range);
				x = this.x + xy.x;
				y = this.y + xy.y;
			}
			FX.launchDown.at(x, y, 0, b.hitColor, {
				region: lib.region("桎梏-pod"),
				timer: new Interval()
			});
			Time.run(FX.launchDown.lifetime, () => {
				Damage.damage(this.team, x, y, b.splashDamageRadius, b.splashDamage * b.damageMultiplier(), b.splashDamagePierce, b.collidesAir, b.collidesGround, b.scaledSplashDamage, b);
				Fx.titanSmoke.at(x, y, b.hitColor);
				Effect.shake(8, 8, x, y);
			});
		});
	},
	needItem(item) {
		return this.block.consumesItem(item) && this.items.get(item) < this.getMaximumAccepted(item) && !this.block.ammoTypes.get(item);
	},
	acceptItem(source, item) {
		let type = this.block.ammoTypes.get(item);
		return this.needItem(item) || (type != null && this.totalAmmo + type.ammoMultiplier <= this.block.maxAmmo);
	},
	acceptStack(item, amount, source) {
		let type = this.block.ammoTypes.get(item);
		if (this.needItem(item)) return Math.min(this.getMaximumAccepted(item) - this.items.get(item), amount);
		this.super$acceptStack(item, amount, source);
	},
	handleItem(source, item) {
		if (this.block.ammoTypes.get(item)) this.super$handleItem(source, item);
		else if (this.needItem(item)) this.items.add(item, 1);
	},
	removeStack(item, amount) {
		if (this.items == null) return 0;
		amount = Math.min(amount, this.items.get(item));
		this.items.remove(item, amount);
		return amount;
	}
})

桎梏.drawer = (() => {
	const d = new DrawTurret();
	for (let j = 0; j < 4; j++) {
		for (let i = 0; i < 4; i++) {
			let i2 = j * 3 == 0 ? 1 : j * 3 == 9 ? 1 : -1,
				j2 = j - 2 < 0 ? 1 : -1;
			d.parts.add(
				Object.assign(new RegionPart("-aim"), {
					heatProgress: pro.warmup.sin(-(4 - i) * 10, 20, 1),
					rotation: 135 - 90 * j,
					heatLight: true,
					drawRegion: false,
					x: j2 * (0.5 * i + 1) * 32 / (1 - i / 32),
					y: i2 * (0.5 * i + 1) * 32 / (1 - i / 32),
					xScl: 1 - i * 0.15,
					yScl: 1 - i * 0.15,
					heatColor: lib.Color("FFD37F")
				})
			)
		}
	}
	d.parts.add(
		Object.assign(new RegionPart("-glow"), {
			heatProgress: pro.warmup,
			heatColor: lib.F03B0E,
			drawRegion: false
		}),
		Object.assign(new RegionPart("-pod"), {
			progress: pro.reload,
			outline: false,
			under: true,
			color: lib.Color("FFFFFF"),
			colorTo: lib.Color("FFFFFF00"),
			mixColor: lib.Color("FFFFFF00"),
			mixColorTo: lib.Color("FFFFFF")
		})
	)
	return d;
})();