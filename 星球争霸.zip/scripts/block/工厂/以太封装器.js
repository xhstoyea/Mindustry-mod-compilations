const lib = require("base/coflib");

function etherWrapper(name, boost, time) {
	let b = new GenericCrafter(name);
	lib.setBuilding(GenericCrafter.GenericCrafterBuild, b, {
		craft() {
			this.super$craft();
			this.applyBoost(boost, time);
		}
	})
}

etherWrapper("以太封装器", 3, 180);
etherWrapper("以太封装器大", 5, 240);