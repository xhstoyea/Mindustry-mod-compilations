const { Char } = require("planet/查尔");
function newItem(name) {
	exports[name] = new Item(name);
}
function newLiquid(name, type) {
	exports[name] = extend(type ? CellLiquid : Liquid, name, {});
}
newItem("铱板");
newItem("导能回路");
newItem("低温化合物");
newItem("铈");
newItem("铈凝块");
newItem("陶钢");
newItem("生物钢");
newItem("以太能");
newItem("肃正协议");
newLiquid("血水", true);

/*Items.copper.shownPlanets.add(Char);
Items.lead.shownPlanets.add(Char);
Items.metaglass.shownPlanets.add(Char);
Items.graphite.shownPlanets.add(Char);
Items.sand.shownPlanets.add(Char);
Items.coal.shownPlanets.add(Char);
Items.titanium.shownPlanets.add(Char);
Items.thorium.shownPlanets.add(Char);
Items.scrap.shownPlanets.add(Char);
Items.silicon.shownPlanets.add(Char);
Items.plastanium.shownPlanets.add(Char);
Items.phaseFabric.shownPlanets.add(Char);
Items.surgeAlloy.shownPlanets.add(Char);
Items.sporePod.shownPlanets.add(Char);
Items.blastCompound.shownPlanets.add(Char);
Items.pyratite.shownPlanets.add(Char);

Liquids.water.shownPlanets.add(Char);
Liquids.cryofluid.shownPlanets.add(Char);

exports.铱板.shownPlanets.add(Char);
exports.导能回路.shownPlanets.add(Char);
exports.低温化合物.shownPlanets.add(Char);
exports.铈.shownPlanets.add(Char);
exports.铈凝块.shownPlanets.add(Char);
exports.陶钢.shownPlanets.add(Char);
exports.生物钢.shownPlanets.add(Char);
exports.以太能.shownPlanets.add(Char);
exports.肃正协议.shownPlanets.add(Char);*/

/*function newItem(name, color, obj) {
	exports[name] = Object.assign(new Item(name, Color.valueOf(color)), obj);
}
newItem("物品", "123123", {
	cost: 1
});*/

/*物品权重
沙240
铜216
铅144
石墨120
玻璃114
钛102
钍90
铱板78
铈66
硅72
塑钢66
导能回路54
合金42
陶钢36
布24
生物钢3
以太能1*/