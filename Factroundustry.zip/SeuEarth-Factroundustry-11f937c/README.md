# Factroundustry
**Factorio + Sound + Mindustry = Factroundustry**       
A Soundpack that changes all sounds and musics from Factorio.

<a href="https://ibb.co/2ZQ2vx3"><img src="https://i.ibb.co/KKkZ2dx/preview.png" alt="image" border="0"></a>

## Crossover
You can use this with Xeloboyo/Factoriodustry for better experience!

Link: https://github.com/Xeloboyo/Factoriodustry

<a href="https://ibb.co/DQmKm0H"><img src="https://i.ibb.co/M7KNKFx/crossover.png" alt="image" border="0"></a>
