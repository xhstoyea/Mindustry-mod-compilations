MapResizeDialog.minSize = 1
MapResizeDialog.maxSize = 50000
require("moreCore");
require("block/弹药加工厂");
require("block/大型综合高炉");