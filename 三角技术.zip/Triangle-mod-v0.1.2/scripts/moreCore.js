const CoreFrontline = extend(CoreBlock, "哨塔核心", {
//可以拆除
	canBreak(tile) {
		return Vars.state.teams.cores(tile.team()).size > 1;
//判定为同队伍核心数量大于1时可拆除
	},
//能够覆盖
	canReplace(other) {
		return other.alwaysReplace;
//总是能被其他核心覆盖
	},
//能够放置
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.cores(team).size < 8;
//判定为同队伍中的核心数量少于8皆可
	}
});