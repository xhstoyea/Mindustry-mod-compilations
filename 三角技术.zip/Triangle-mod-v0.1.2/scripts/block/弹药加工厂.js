const library = require("base/library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "弹药加工厂", [
	{
		input: {
			items: ["三角-铝/3","三角-氧化铁/5","三角-碳素钢/1"],
			power: 1.5,
		},
		output: {
			items: ["三角-铝热剂/2"],
		},
		craftTime: 60,
	},
	{
		input: {
			items: ["copper/3","blast-compound/5","三角-碳素钢/1"],
			power: 1.5,
		},
		output: {
			items: ["三角-小口径破甲弹/3"],
		},
		craftTime: 90,
	},
	{
		input: {
			items: ["blast-compound/7","三角-碳素钢/2"],
			power: 1.5,
		},
		output: {
			items: ["三角-小口径碎甲弹/3"],
		},
		craftTime: 80,
	},
	{
		input: {
			items: ["blast-compound/10","三角-碳素钢/2"],
			power: 3,
		},
		output: {
			items: ["三角-大口径高爆弹/1"],
		},
		craftTime: 120,
	},
	{
		input: {
			items: ["blast-compound/9","三角-碳素钢/5"],
			power: 3,
		},
		output: {
			items: ["三角-大口径碎甲弹/1"],
		},
		craftTime: 120,
	},
	{
		input: {
			items: ["copper/3","blast-compound/8","三角-碳素钢/3"],
			power: 3,
		},
		output: {
			items: ["三角-大口径破甲弹/1"],
		},
		craftTime: 120,
	},
	{
	    input: {
			items: ["三角-基本集成电路/2","三角-碳素钢/5"],
			power: 2,
		},
		output: {
			items: ["三角-炮射导弹/2"],
		},
		craftTime: 90,
	},
	{
	    input: {
			items: ["三角-基本集成电路/4","三角-碳素钢/5"],
			power: 2,
		},
		output: {
			items: ["三角-电磁脉冲弹/3"],
		},
		craftTime: 100,
	},
]);
