const library = require("base/library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "大型综合高炉", [
	{
		input: {
			items: ["三角-钒钛磁铁矿/150"],
			power: 7.5,
		},
		output: {
			items: ["三角-五氧化二钒/85","三角-碳素钢/45","titanium/20"],
		},
		craftTime: 270,
	},
]);
