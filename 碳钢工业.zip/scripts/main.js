//MapResizeDialog.minSize = 0
//MapResizeDialog.maxSize = 50000
const lib = require("base/lib");
require('独立大核心');
require("工厂/测试js工厂");
require("工厂/测试js发电机");
require("天狼星");
//require("独立科技");
require("强化核心");
require('辅助建筑');
require('缩放强化');