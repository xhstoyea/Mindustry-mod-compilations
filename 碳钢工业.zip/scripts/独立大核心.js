 //   const myitem = require("物品");
    const 独立大核心 = extend(CoreBlock,"独立大核心",{ //定义独立大核心为CoreBlock类且更改属性或添加
       canBreak(tile){
         return true;
       },//retrun返回值为true即为可以拆除反之如果是flase就不能拆
        //但是有个问题,假设你的这个可拆卸核心只有一个,如果你拆卸了游戏就结束了对吧
        //所以我们需要判断,而像素工厂当中有相应的函数可以来判断
        //Vars.state.teams.cores 这个就是判断队伍中的核心的函数
        //所以我们这样子Vars.state.teams.cores(this.team) 但是这样子出来的数据很多,但是我们只需要其中的数量,所以我们用size来获取Vars.state.teams.cores(this.team).size
        //这样子他返回的就是int即为整数那样我们就可以判断就像 Vars.state.teams.cores(this.team).size > 1;这个的意思就是如果队伍中的核心数量大于一个那么就返回true即可以拆除
       canPlaceOn(tile, team, rotation){
         return true;
       }//因为原版的核心需要放置在核心的地基上所以不能直接放置,通过和刚刚一样的方法可以让核心可以放置，如果你有需求自己改就好
      });//以上的为整体
    独立大核心.size = 5;//大小
    独立大核心.health = 5000;//血量
    独立大核心.buildVisibility = BuildVisibility.shown;//在什么时候可见这个一般为shown如果改为sandbox就是在沙盒模式才能看见
    独立大核心.category = Category.effect;//在哪一个选项栏显示
    独立大核心.solid = true;//是否为实体
/*    独立大核心.requirements = ItemStack.with(
      Items.copper, 9000,//制造消耗
      Items.lead, 9000,//制造消耗
      Items.titanium, 3000,//制造消耗
      Items.silicon, 6000,//制造消耗
//      myitem.碳钢, 3000,//制造消耗
    );*/
    独立大核心.name = 独立大核心;//单位容量
    独立大核心.unitType = UnitTypes.beta;//初始单位
    独立大核心.itemCapacity = 2000;//物品容量
    独立大核心.unitCapModifier = 2;//单位容量
    exports.独立大核心 = 独立大核心;//导出然后在main.js里面require 就像require("独立大核心");一样