const library = require("base/library");
const myliquids = require("液体");
const myitems = require("物品");
const 测试js工厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "测试js工厂", [
  {
    input: {//输入，里面可以加物品，液体和电
      items: ["metaglass/2"],     
//      liquids: ["water/60"],
      power: 1,
    },
    output: {//输出，一样
      items: ["thorium/1"],
    },
    craftTime: 60,
  }, 
  //上面括号里算一个合成方式
  
  {
    input: {
      items: ["silicon/2"],     
//      liquids: ["water/60"],
      power: 1,
    },
    output: {
      items: ["surge-alloy/1"],
    },
    craftTime: 60,
  },
  //又一个合成方式
  

]);