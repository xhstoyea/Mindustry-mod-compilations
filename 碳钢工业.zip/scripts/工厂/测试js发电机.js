const library = require("base/library");
const myliquids = require("液体");
const myitems = require("物品");
const 测试js工厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "测试js发电机", [
  {
    input: {
      payloads: ["dagger/1"],     
//      liquids: ["water/60"],
    },
    output: {
      power:2
    },
    craftTime: 60,
  }, 
  {
    input: {
      items: ["silicon/2"],     
//      liquids: ["water/60"],
      power: 1,
    },
    output: {
      items: ["surge-alloy/1"],
    },
    craftTime: 60,
  },

]);