const B1 = extend(LightningBulletType,{})
B1.lightningLength = 10
B1.lightningLengthRand = 2;
B1.damage = 24

const D1 = extend(UnitType, "sa-lt1电流",{}); 
D1.constructor = () => MechUnit.create();
D1.abilities.add((()=>{
var DB = extend(Ability,{
    death(unit){
    B1.create(unit, unit.x, unit.y, unit.rotation)
    B1.create(unit, unit.x, unit.y, unit.rotation + 45)
    B1.create(unit, unit.x, unit.y, unit.rotation - 45)
    B1.create(unit, unit.x, unit.y, unit.rotation + 90)
    B1.create(unit, unit.x, unit.y, unit.rotation - 90)
    B1.create(unit, unit.x, unit.y, unit.rotation + 135)
    B1.create(unit, unit.x, unit.y, unit.rotation - 135)
    B1.create(unit, unit.x, unit.y, unit.rotation + 180)
    }
    })
    return DB
})()
)