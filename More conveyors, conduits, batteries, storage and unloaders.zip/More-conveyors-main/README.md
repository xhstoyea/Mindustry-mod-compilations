# More-conveyors

A mindustry mod that adds a few new blocks.

New armored variants of vanilla distribution blocks.

New armored variants of vanilla liquid distribution blocks.

5 new faster conveyor types

2 new conduits

3 new faster unloaders

1 new larger storage vault

1 new larger storage container

1 new larger liquid tank

2 new batteries

1 new wall that combines the abilities of the Surge Wall, Plastanium Wall and Phase Wall
