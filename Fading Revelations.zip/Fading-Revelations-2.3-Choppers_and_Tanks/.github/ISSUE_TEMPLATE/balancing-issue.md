---
name: Balancing Issue
about: Report a balancing issue
title: Balance Issue
labels: documentation
assignees: Fresh791

---

**What block/unit/etc is the balance issue about?.**
e.g. Unit, KING

**Is the block/unit/etc too strong/too weak?**
too strong / too weak

**By how much should it be buffed/nerfed?**
e.g. Increase HP by 240 or Remove Slow Effect, etc.
