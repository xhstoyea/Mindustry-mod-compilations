[![Github All Releases](https://img.shields.io/github/downloads/EchoVespy/Simplistic/total.svg)]()
![GitHub issues](https://img.shields.io/github/issues/EchoVespy/Simplistic)
# Simplistic

A WIP texture pack made for mindustry.

Simplistic's goal is to get rid of as much detail as possible for every sprite in mindustry, while still retaining an easily recognizable appearance.

Thanks to the Factoriodustry mod and their developers for their code, as this mod is currently using it (although I'd like to change that some point in the future).

EVERYTHING is subject to change, when exactly I do not know.

Texture pack is currently being developed for Mindustry v7.


Fully sprited by EchoVespy.
