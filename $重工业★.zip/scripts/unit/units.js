const lib = require("base/coflib");
const FX = require("base/effect");
const liquid = require("base/液体");
const ability = require("base/ability");
const status = require("base/status");

function newUnit(name, unitType, cons, cons2) {
	const u = extend(UnitType, name, cons || {});
	u.constructor = () => extend(unitType, cons2 || {});
	return exports[name] = u;
}
exports.newUnit = newUnit;
function newUnitList(name, unitType, cons) {
	for (let i = 1; i <= 5; i++) {
		newUnit(name + i, unitType, cons);
	}
}

function parasite(name) {
	let p = newUnit(name, TimedKillUnit, {
		lifetime: 1800,
		flying: true,
		lowAltitude: true,
		circleTarget: true,
		useUnitCap: false,
		createScorch: false,
		playerControllable: false,
		itemCapacity: 0,
		update(unit) {
			this.super$update(unit);
			if (unit.statusBits().get(status.狂乱.id)) return
			unit.apply(status.狂乱, 3600);
		},
		display(unit, table) {
			this.super$display(unit, table);
			table.getChildren().get(1).add(new Bar("存活时间", Pal.accent,() => 1 - unit.fin())).row();
		}
	})
	p.immunities.addAll(StatusEffects.burning, StatusEffects.melting, StatusEffects.wet, StatusEffects.freezing, StatusEffects.sporeSlowed, StatusEffects.sapped, StatusEffects.electrified, status.寄生);
	return p
}

function BottleUnitType(name, lifeTime, damage, range, status, effect, color) {
	let i = 0, dx = 0, dy = 0;
	let u = extend(MissileUnitType, name, {
		health: 10000,
		lifetime: lifeTime,
		speed: 0,
		trailLength: 0,
		flying: false,
		drawCell: false,
		hittable: false,
		targetable: false,
		loopSound: Sounds.none,
		update(unit) {
			this.super$update(unit);
			if ((i += Time.delta) >= 6) {
				Damage.damage(unit.x, unit.y, range, damage);
				Damage.status(null, unit.x, unit.y, range, status, 900, true, true);
				dx = unit.x + Mathf.range(range * 0.6);
				dy = unit.y + Mathf.range(range * 0.7);
				if (Mathf.chance(0.5)) effect.at(dx, dy, color);
				i = 0;
			}
		},
		draw(unit) {
			this.super$draw(unit);
			Draw.color(Pal.accent);
			Draw.z(Layer.effect);
			for (let i = 0; i < 4; i++) {
				let r = Time.time + i * 90;
				Lines.arc(unit.x, unit.y, range, 0.2, r);
			}
		}
	});
	u.immunities.add(status);
	return exports[name] = u;
}

/*flying -> UnitEntity;
mech -> MechUnit;
legs -> LegsUnit;
naval -> UnitWaterMove;
payload -> PayloadUnit;
missile -> TimedKillUnit;
tank -> TankUnit;
hover -> ElevationMoveUnit;
tether -> BuildingTetherPayloadUnit;
crawl -> CrawlUnit;*/

let 飞蠓 = parasite("飞蠓");
let 疟蚊 = parasite("疟蚊");
let 血俎 = parasite("血俎");
newUnit("伊普西龙", PayloadUnit);
newUnit("泽塔", PayloadUnit);
newUnit("欧米茄", UnitEntity, {
	draw(unit) {
		this.super$draw(unit);
		FX.PlayerAim(unit, lib.FF5845);
	}
});
let 雨燕 = newUnit("雨燕", UnitEntity, {
	/*update(unit) {
		this.super$update(unit);
		let range = unit.type.range / 4;
		Groups.bullet.intersect(unit.x - range, unit.y - range, range * 2, range * 2, b => {
			let ang = Angles.angle(b.x, b.y, unit.x, unit.y);
			if (b.team != unit.team) unit.vel.trns(ang + 1, unit.type.speed * unit.speedMultiplier);
		});
	}*/
});
雨燕.abilities.add(ability.RotatorAbility("副螺旋桨", 32, -5, 2, 30, 30, true), ability.RotatorAbility("主螺旋桨", 0, 12, 2, 64, 64));
newUnitList("陆战", MechUnit);
newUnitList("空雷", UnitEntity);
let 冥 = newUnit("冥", UnitEntity);
let 玄 = newUnit("玄", UnitEntity);
let lk = newUnit("无畏", UnitEntity);
lk.abilities.add(Object.assign(new EnergyFieldAbility(0, 60, 0), {
	y: -31.75,
	maxTargets: 0,
	healPercent: 0,
	color: lib.FF5845
}), new ShieldRegenFieldAbility(1000, 12000, 60, 240));

newUnit("羽蛇", UnitEntity);
let 渊狱 = newUnit("渊狱", UnitEntity);
for (let i = 0; i < 4; i++) {
	let fi = i;
	渊狱.abilities.add(Object.assign(extend(ShieldArcAbility, {
		/*update(unit) {
			this.super$update(unit);
			this.angleOffset = (Time.time + 90 * fi) % 360;
			print(this.angleOffset)
		}*/
	}), {
		max: 4500,
		regen: 5,
		cooldown: 60 * 8,
		angleOffset: 90 * i + 45,
		angle: 60,
		radius: 72,
		width: 5,
		whenShooting: false
	}));
}
let RA = Object.assign(new RegenAbility(), {
	percentAmount: 1 / 100
});
let SFA = Object.assign(new StatusFieldAbility(status.杀戮光环, 60, 30, 200), {
	activeEffect: Fx.none
});
let LEA = Object.assign(new LiquidExplodeAbility(), {
	liquid: liquid.血水,
	noiseMag: 8,
});
let SDA = Object.assign(new SpawnDeathAbility(飞蠓, 12, 8), {
	randAmount: 4,
	faceOutwards: true
});

渊狱.abilities.add(RA, SFA);
渊狱.abilities.add(LEA, SDA);

/*{
	"type": "ShieldArcAbility",
	"region": "curse-of-flesh-渊狱护盾l",
	"radius": 60,
	"angle": 136,
	"width": 5,
	"max": 4500,
	"regen": 1.5,
	"cooldown": 480,
	"angleOffset": 80
},
{
	"type": "ShieldArcAbility",
	"region": "curse-of-flesh-渊狱护盾r",
	"radius": 60,
	"angle": 136,
	"width": 5,
	"max": 4500,
	"regen": 1.5,
	"cooldown": 480,
	"angleOffset": -80
},*/
let 黑棘 = newUnit("黑棘", UnitEntity);

let hjxSFA = SFA.copy();
hjxSFA.duration = 600;

let hjxLEA = LEA.copy();
hjxLEA.radAmountScale = 4;

var hjxEFA = Object.assign(new EnergyFieldAbility(225, 30, 240), {
	y: 5.75,
	maxTargets: 20,
	status: status.熔融,
	statusDuration: 120,
	sectors: 4,
	sectorRad: 0.18,
	color: lib.FF5845,
	effectRadius: 4,
	rotateSpeed: 0.5
});

var hjxSDA = Object.assign(new SpawnDeathAbility(黑棘, 0, 0), {
	randAmount: 1,
	faceOutwards: false
});

黑棘.abilities.add(ability.HealthRequireAbility(0.25, StatusEffects.none, status.极速恢复));
黑棘.abilities.addAll(RA, hjxSFA, hjxEFA, hjxLEA, hjxSDA);

let 噬星 = newUnit("噬星", UnitEntity, {
	draw(unit) {
		this.super$draw(unit);
		FX.PlayerAim(unit, lib.FF5845);
	}
})

let sxEFA = hjxEFA.copy();
sxEFA.y = 10.75;
sxEFA.range = 320;
sxEFA.damage = 445;
sxEFA.maxTargets = 40;
sxEFA.sectors = 3;
sxEFA.sectorRad = 0.2;

var sxSDA = hjxSDA.copy();
sxSDA.unit = 噬星;

噬星.abilities.add(ability.HealthRequireAbility(0.4, StatusEffects.none, status.极速恢复), ability.StatusAbility(status.寄生, 360, 300));
噬星.abilities.addAll(RA, hjxSFA, sxEFA, hjxLEA, sxSDA);

let 利维坦 = newUnit("利维坦", UnitEntity, {
	draw(unit) {
		this.super$draw(unit);
		FX.PlayerAim(unit, lib.FF5845);
	}
})

let lwtSDA = sxSDA.copy();
lwtSDA.unit = 利维坦;

利维坦.abilities.add(ability.HealthRequireAbility(0.4, StatusEffects.none, status.极速恢复), ability.StatusAbility(status.寄生, 360, 300));
利维坦.abilities.add(RA, hjxSFA, hjxLEA, lwtSDA)

let thermite = BottleUnitType("bottle", 300, 120, 240, status.熔融, Fx.titanSmoke, lib.FF5845);
newUnit("攻城", TankUnit);
newUnit("洪流", TankUnit);