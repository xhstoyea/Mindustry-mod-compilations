exports.curseFloor = extend(Floor, "诅咒之地", {});

let shaders = Vars.mods.locateMod("curse-of-flesh").root.child("shaders");
let s1 = new Shaders.SurfaceShader(Shaders.getShaderFi("screenspace.vert").readString(), shaders.child("blood.frag").readString())
let m = new CacheLayer.ShaderLayer(s1)
CacheLayer.add(m);
let bloodPool = extend(Floor, "血池", {});
bloodPool.cacheLayer = m;

Attribute.add("ice");
function setAttribute(block, attribute, amount) {
	return block.attributes.set(Attribute.get(attribute), amount);
}

setAttribute(Blocks.snow, "ice", 0.6);
setAttribute(Blocks.iceSnow, "ice", 0.9);
setAttribute(Blocks.ice, "ice", 1.2);
setAttribute(Blocks.sand, Attribute.sand, 0.7);
setAttribute(Blocks.darksand, Attribute.sand, 1.5);

let iceMaker = new AttributeCrafter("低温化合器");
iceMaker.attribute = Attribute.get("ice");