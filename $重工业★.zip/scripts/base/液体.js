function newLiquid(name, type) {
	exports[name] = extend(type ? CellLiquid : Liquid, name, {});
}
newLiquid("血水", true);