function newItem(name) {
	exports[name] = new Item(name);
}
newItem("铱板");
newItem("铈");
newItem("铈凝块");
newItem("导能回路");
newItem("低温化合物");
newItem("陶钢");
newItem("生物钢");
newItem("肃正协议");

/*function newItem(name, color, obj) {
	exports[name] = Object.assign(new Item(name, Color.valueOf(color)), obj);
}
newItem("物品", "123123", {
	cost: 1
});*/