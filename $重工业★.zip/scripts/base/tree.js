const lib = require("base/coflib");
let node = TechTree.node;
let Research = Objectives.Research;
let nodeProduce = TechTree.nodeProduce;
let SectorComplete = Objectives.SectorComplete;

const { 核心装卸器, 核心卸载器, 核心装载器, 液体装卸器 } = require("block/工厂/装卸器核心");
const { 资源装载器, 资源卸载器 } = require("block/工厂/装卸器资源");
const { Back } = require("block/炮塔/传送奇点");
const { 破冰器 } = require("block/杂项/炸弹");

lib.addResearch(核心卸载器, { parent: "unloader", });
lib.addResearch(液体装卸器, { parent: "unloader", });

lib.addResearch(核心装载器, { parent: "核心卸载器", });
lib.addResearch(核心装卸器, { parent: "核心装载器", });
lib.addResearch(资源卸载器, { parent: "核心装卸器", });
lib.addResearch(资源装载器, { parent: "核心装卸器", });

lib.addResearch(Back, { parent: "shock-mine", });
lib.addResearch(破冰器, { parent: "impulse-pump", });

/*
TechTree.nodeRoot("诅咒科技", 舰载机, () => {
	node(核心卸载器);
	node(核心装载器, () => {
		node(核心装卸器, () => {
			node(资源卸载器)
			node(资源装载器)
		})
	});
	node(液体装卸器);
})

function Treenode(Parent, block, requirements, objectives) {
	let parent = TechTree.all.find(node => node.content == Parent);
	let node = new TechTree.TechNode(parent, block, requirements);
	node.objectives.addAll(objectives);
}

Treenode(前置, 当前方块,
	ItemStack.with(
		Items.copper, 20,
		Items.lead, 30
	),
	Seq.with(
		new Research(物品/方块前置),
		new SectorComplete(地图前置)
	)
);*/