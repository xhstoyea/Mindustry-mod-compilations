const lib = require("base/coflib");
const FX = require("base/effect");
const {坍缩牵引} = require("base/status");

exports.AntiBulletType = (bulletDamage, bulletSlowDownScl, bR, interp) => {
	let bulletRadius = bR || 80;
	return extend(BasicBulletType, {
		update(b) {
			this.super$update(b);
			let r1 = Tmp.r1.setSize(bulletRadius * 2).setCenter(b.x, b.y);
			Groups.bullet.intersect(r1.x, r1.y, r1.width, r1.height, bl => {
				if (b.team != bl.team && bl.type.hittable && b.within(bl, bulletRadius)) {
					let inp = (interp || Interp.pow3).apply(Mathf.clamp((bulletRadius - b.dst(bl)) / bulletRadius));
					bl.vel.scl(Mathf.lerp(1, bulletSlowDownScl || 0.5, inp));
					bl.damage -= (bulletDamage || 5) * inp;
					if (bl.damage <= 0) bl.remove();
				}
			})
		}
	})
}

exports.HomingBulletType = (power) => {
	return extend(BasicBulletType, {
		update(b) {
			this.super$update(b);
			if (b.dst(b.owner) > b.owner.block.range * 1.2) {
				b.absorb();
			} else {
				b.vel.setAngle(Angles.moveToward(b.rotation(), b.angleTo(b.owner.targetPos), Time.delta * power));
			}
		}
	})
}

exports.TwoStageBulletType = (range) => {
	return extend(BasicBulletType, {
		drag: 0.01,
		lifetime: 1800,
		update(b) {
			this.super$update(b);
			if (b.time >= 80 / b.speed) return
			let target = Units.closestTarget(b.team, b.x, b.y, range);
			if (target == null) return
			b.vel.trns(Angles.angle(b.x, b.y, target.x, target.y), b.type.speed);
		}
	})
}

exports.FortressBulletType = (range, reload, bullet, num, random, spread) => {
	if (range == 0) range = bullet.speed * bullet.lifetime;
	return extend(BasicBulletType, {
		drag: 0.01,
		damage: 0,
		sprite: "circle",
		hittable: false,
		collides: false,
		absorbable: false,
		reflectable: false,
		update(b) {
			this.super$update(b)
			let target = Units.closestTarget(b.team, b.x, b.y, range);
			if (target != null && b.timer.get (reload)) {
				for (let i = 0; i < num; i++) {
					bullet.create(b, b.x, b.y, Angles.angle(target.x, target.y, b.x, b.y) + Mathf.range(random || 360) + ((i - (num - 1) / 2) * (spread || 0)));
				}
			}
		}
	})
}

exports.RandomLightningBulletType = (damage, range, radius, reload, num, effect) => {
	return extend(BasicBulletType, {
		hittable: false,
		absorbable: false,
		reflectable: false,
		update(b) {
			this.super$update(b);
			if (b.time >= b.lifetime - 30) return
			if (b.timer.get(reload)) {
				for (let i = 0; i < num; i++) {
					let x = b.x + Mathf.range(range);
					let y = b.y + Mathf.range(range);
					Damage.damage(x, y, radius, damage);
					Damage.status(null, x, y, radius, 坍缩牵引, 60, true, true);
					for (let j = 0; j < 3; j++) {
						FX.chainLightning.at(x, y, 0, lib.FF8663, b);
					}
					Sounds.plasmaboom.at(x, y);
					Effect.shake(4, 30, x, y);
					effect.at(x, y);
				}
			}
		}
	})
}

exports.ArmorReductionBulletType = (ard, damage, speed, lifetime) => {
	return extend(BasicBulletType, {
		hitEntity(b, entity, health) {
			this.super$hitEntity(b, entity, health);
			entity.armor -= ard;
		},
		speed: speed,
		damage: damage,
		lifetime: lifetime,
		pierceCap: 2,
		pierceBuilding: true,
		ammoMultiplier: 1
	});
}

exports.ArmorPierceBulletType = (num, damage, speed, lifetime) => {
	return extend(BasicBulletType, {
		hitEntity(b, entity, health) {
			this.super$hitEntity(b, entity, health);
			entity.damagePierce(entity.armor * num);
		},
		speed: speed,
		damage: damage,
		lifetime: lifetime,
		pierceCap: 2,
		pierceBuilding: true,
		ammoMultiplier: 1
	});
}

exports.HarmlessBulletType = () => {
	return extend(BasicBulletType, {
		hitEntity(b, entity, health) {
			this.super$hitEntity(b, entity, health);
			if (entity instanceof Unit) {
				entity.weapons.clear();
			}
		}
	})
}

exports.MindControlBulletType = () => {
	return extend(BasicBulletType, {
		hitEntity(b, entity, health) {
			this.super$hitEntity(b, entity, health);
			if (entity instanceof Unit && entity.healthf() <= 0.05) {
				entity.team = b.team;
				entity.heal();
				Fx.spawn.at(entity.x, entity.y);
			}
		}
	})
}

exports.BlockHoleBulletType = (range, suction /*力度*/ , damage) => {
	return extend(BasicBulletType, {
		shrinkY: 0,
		damage: 0,
		speed: 0,
		hittable: false,
		collides: false,
		absorbable: false,
		reflectable: false,
		update(b) {
			this.super$update(b);
			Units.nearbyEnemies(b.team, b.x, b.y, range, u => {
				let dst = 1 - u.dst(b) / range;
				u.impulse(Tmp.v3.set(b).sub(u).nor().scl(80 * suction * (dst + 1)));
				Damage.status(b.team, b.x, b.y, range, 坍缩牵引, 60, true, true);
				u.damageContinuousPierce((u.maxHealth / 2 / (this.lifetime / 60) + damage) * dst / 60);
			})
		}
	})
}

exports.EnergyFieldBulletType = (range, reload, damage, maxTargets, status, statusDuration, color, hitEffect) => {
	let timer = 0, all = new Seq();
	return extend(BasicBulletType, {
		hittable: false,
		absorbable: false,
		reflectable: false,
		update(b) {
			this.super$update(b);
			if ((timer += Time.delta) >= reload) {
				all.clear();
				Units.nearby(null, b.x, b.y, range, other => {
					if (other.team != b.team) all.add(other);
				});
				Units.nearbyBuildings(b.x, b.y, range, build => {
					if (build.team != b.team) all.add(build);
				});
				all.sort(floatf(e => e.dst2(b.x, b.y)));
				let max = Math.min(all.size, maxTargets);
				for (let i = 0; i < max; i++) {
					let other = all.get(i);
					var absorber = Damage.findAbsorber(b.team, b.x, b.y, other.getX(), other.getY());
					if (absorber != null) other = absorber;
					Fx.chainLightning.at(b.x, b.y, 0, color, other);
					if (hitEffect) {
						hitEffect.at(other);
					} else {
						Fx.hitLaserBlast.at(other.x, other.y, b.angleTo(other), color);
					}
					other.damage(damage);
					if (other instanceof Unit) other.apply(status, statusDuration);
					Sounds.spark.at(b);
				}
				timer = 0;
			}
		}
	})
}

exports.PointLaser = (range, speed) => {
	return extend(PointLaserBulletType, {
		update(b) {
			this.updateTrail(b);
			this.updateHoming(b);
			this.updateWeaving(b);
			this.updateTrailEffects(b);
			this.updateBulletInterval(b);
			if (b.owner instanceof Unit) {
				let u = b.owner;
				let shootLength = Math.min(u.dst(u.aimX, u.aimY), range);
				let curLength = u.dst(b.aimX, b.aimY);
				let resultLength = Mathf.approachDelta(curLength, shootLength, speed);
				let angle = Angles.angle(u.x, u.y, u.aimX, u.aimY);
				Tmp.v1.trns(angle, resultLength).add(u.x, u.y);
				let xy = lib.AngleTrns(angle, range - 1);
				if (curLength > range) {
					b.aimX = u.x + xy.x;
					b.aimY = u.y + xy.y;
				} else {
					b.aimX = Tmp.v1.x;
					b.aimY = Tmp.v1.y;
				}
				if (b.timer.get(0, this.damageInterval)) {
					Damage.collidePoint(b, b.team, this.hitEffect, b.aimX, b.aimY);
				}
				if (b.timer.get(1, this.beamEffectInterval)) {
					this.beamEffect.at(b.aimX, b.aimY, this.beamEffectSize * b.fslope(), this.hitColor);
				}
				if (this.shake != null && this.shake > 0) {
					Effect.shake(this.shake, this.shake, b);
				}
			}
		}
	})
}