function newTurret(name, type) {
	return exports[name] = extend(type, name, {});
}
newTurret("Ω", ItemTurret);
/*
const lib = require("base/coflib")
//光谱.update = true
光谱.configurable = true;
let mass = 0, reload = 120;
lib.setBuilding(PowerTurret.PowerTurretBuild, 光谱, {
	buildConfiguration(table) {
		this.super$buildConfiguration(table)
		table.slider(0, 5, 1, mass, t => {
			mass = t
		}).size(80, 30).row();
		table.add(mass + "").update(t => {
			t.setText(mass + "")
		}).row();
	},
	updateTile() {
		this.super$updateTile();
		reload = reload / mass
	}
})
光谱.reload = reload*/