const lib = require("base/coflib");
const units = require("unit/units");

let minDamage = Stat("minDamage");
let percentDamage = Stat("percentDamage");
let minHealth = Stat("minHealth");
let percentHealth = Stat("percentHealth");
let reduceArmor = Stat("reduceArmor");
let chainDamage = Stat("chainDamage");

function newStatus(name, cons) {
	return exports[name] = extend(StatusEffect, name, cons || {});
}

function PercentStatus(name, percent /*百分比*/ , min /*保底值*/ , obj) {
	return newStatus(name, {
		update(unit, time) {
			this.super$update(unit, time);
			let UMAX = unit.maxHealth / 100 / 60; //每秒1%生命值
			let UP = UMAX * percent, Max = Math.max(UP, Math.abs(min));
			if (min < 0) {
				unit.heal(Math.abs(Max));
			} else {
				unit.damageContinuousPierce(Max);
			}
		},
		setStats() {
			this.super$setStats();
			if (min < 0) {
				this.stats.add(percentHealth, lib.bundle("percentHealth", percent));
				this.stats.add(minHealth, lib.bundle("minHealth", 60 * -min));
			} else {
				this.stats.add(percentDamage, lib.bundle("percentDamage", percent));
				this.stats.add(minDamage, lib.bundle("minDamage", 60 * min));
			}
		},
		init() {
			if (!obj) return
			if (obj.opposite) {
				for (let i = 0; i < obj.opposite.length; i++) {
					this.opposite(obj.opposite[i]);
				}
			}
			if (!obj.affinity) return
			this.affinity(obj.affinity[0], (unit, result, time) => {
				unit.damagePierce(this.transitionDamage);
				obj.affinity[1].at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
				result.set(this, Math.min(time + result.time, 300));
			});
		}
	})
}

function ArmorStatus(name, reduce /*每秒减少护甲量*/ ) {
	let sec = 0;
	return newStatus(name, {
		update(unit, time) {
			this.super$update(unit, time);
			sec++;
			if (time <= 3) {
				unit.armor = unit.type.armor;
				return
			}
			if (sec % (60 / reduce) == 0) unit.armor -= 1;
		},
		setStats() {
			this.super$setStats();
			this.stats.add(reduceArmor, lib.bundle("reduceArmor", reduce));
		}
	})
}

function ChainLightningStatus(name, range, reload, damage, status, statusDuration, color) {
	let timer = 0, all = new Seq();
	newStatus(name, {
		update(unit, time) {
			this.super$update(unit, time);
			if ((timer += Time.delta) >= reload) {
				all.clear();
				Units.nearby(null, unit.x, unit.y, range, other => {
					if (other.team == unit.team) {
						all.add(other);
					}
				});
				all.sort(floatf(e => e.dst2(unit.x, unit.y)));
				if (all.size > 1) {
					let other = all.get(1);
					let absorber = Damage.findAbsorber(Vars.player.unit().team, unit.x, unit.y, other.getX(), other.getY());
					if (absorber != null) {
						other = absorber;
					}
					other.damagePierce(damage);
					if (other instanceof Unit) {
						other.unapply(this);
						other.apply(this, reload + 30);
						other.apply(StatusEffects.unmoving, 30);
						other.apply(StatusEffects.disarmed, 30);
					}
					Sounds.spark.at(unit);
					Fx.chainLightning.at(unit.x, unit.y, 0, color, other);
					Fx.hitLaserBlast.at(other.x, other.y, unit.angleTo(other), color);
				} else {
					unit.apply(status, statusDuration);
					Sounds.pulseBlast.at(unit);
				}
				unit.damagePierce(damage);
				Fx.hitLaserBlast.at(unit.x, unit.y, 0, color);
				timer = 0;
			}
		},
		setStats() {
			this.super$setStats();
			this.stats.add(chainDamage, lib.bundle("chainDamage", damage));
		},
		init() {
			this.affinity(instableEnergy, (unit, result, time) => {
				unit.damagePierce(unit.maxHealth / 100 * 2);
				Fx.dynamicSpikes.wrap(lib.Color("C0ECFF"), unit.hitSize / 2).at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
				result.set(this, Math.min(time + result.time, 60));
			});
		}
	})
}
newStatus("EMP");
newStatus("坍缩牵引");
let opposite = [StatusEffects.wet, StatusEffects.freezing];
let instableEnergy = PercentStatus("不稳定能量", 1, 0.5);
PercentStatus("极速恢复", 1, -6);
let 熔融 = PercentStatus("熔融", 0.5, 0.5, {
	opposite: opposite,
	affinity: [StatusEffects.tarred, Fx.burning]
});
熔融.transitionDamage = 25;
let 蚀骨 = PercentStatus("蚀骨", 2.5, 2.5, {
	opposite: opposite,
	affinity: [StatusEffects.tarred, Fx.burning]
});
蚀骨.transitionDamage = 50;
let 日耀 = PercentStatus("日耀", 5, 5, {
	opposite: opposite,
	affinity: [StatusEffects.tarred, Fx.burning]
});
日耀.transitionDamage = 75;
ArmorStatus("破甲", 8);
newStatus("狂乱");
newStatus("杀戮光环");
let secondaryRadiation = newStatus("次级辐射");
newStatus("原子衰变", {
	update(unit, time) {
		this.super$update(unit, time);
		Damage.damage(unit.x, unit.y, unit.type.hitSize * 1.5, this.damage);
		Damage.status(unit.team, unit.x, unit.y, unit.type.hitSize * 1.5, secondaryRadiation, 300, true, true);
	},
	draw(unit) {
		this.super$draw(unit);
		Draw.z(Layer.shields);
		Draw.color(lib.Color("A170F4CC"));
		Fill.poly(unit.x, unit.y, 16, unit.type.hitSize * 1.5);
	}
});
ChainLightningStatus("连锁闪电", 8 * 30, 60, 75, instableEnergy, 600, lib.Color("C0ECFF"));

let parasite = newStatus("寄生", {
	death(U) {
		for (let i = 0; i < U.hitSize / 24; i++) {
			let unitX = U.x + Mathf.range(U.hitSize), unitY = U.y + Mathf.range(U.hitSize);
			let usb = units.血俎.spawn(U.team == Team.crux ? Team.sharded : Team.crux, unitX, unitY);
			usb.rotation = Angles.angle(U.x, U.y, unitX, unitY);
		}
		for (let i = 0; i < U.hitSize % 24 / 18; i++) {
			let unitX = U.x + Mathf.range(U.hitSize), unitY = U.y + Mathf.range(U.hitSize);
			let usm = units.疟蚊.spawn(U.team == Team.crux ? Team.sharded : Team.crux, unitX, unitY);
			usm.rotation = Angles.angle(U.x, U.y, unitX, unitY);
		}
		for (let i = 0; i < U.hitSize % 18 / 9; i++) {
			let unitX = U.x + Mathf.range(U.hitSize), unitY = U.y + Mathf.range(U.hitSize);
			let uss = units.飞蠓.spawn(U.team == Team.crux ? Team.sharded : Team.crux, unitX, unitY);
			uss.rotation = Angles.angle(U.x, U.y, unitX, unitY);
		}
	}
});
let trigger = Seq.with(parasite);

Events.on(UnitDestroyEvent, e => {
	let U = e.unit;
	let bits = U.statusBits();
	if (bits.isEmpty()) return;
	trigger.each(s => bits.get(s.id), s => {
		s.death(U);
	});
});