const lib = require("base/coflib");
const myItem = require("base/物品");
let damage = 150, cooldown = 300;

let Back = extend(ShockMine, "传送奇点", {
	setStats() {
		this.super$setStats();
		this.stats.add(Stat.damage, damage);
		this.stats.add(Stat.reload, 60 / cooldown, StatUnit.perSecond);
	}
})
lib.setBuilding(ShockMine.ShockMineBuild, Back, {
	unitOn(unit) {
		if (!this.enabled || unit.team == this.team || !this.timer.get(cooldown)) return
		let spawner = Vars.spawner.getSpawns();
		if (spawner.size > 0) {
			let random = Mathf.random(0, spawner.size - 1);
			unit.x = spawner.get(random).x * 8 + Mathf.range(2 * 8);
			unit.y = spawner.get(random).y * 8 + Mathf.range(2 * 8);
			Fx.chainLightning.at(this.x, this.y, 0, Pal.gray, unit);
			unit.damagePierce(damage);
			Sounds.spark.at(this);
		} else {
			this.kill();
		}
	}
});
Back.size = 2;
Back.armor = 4;
Back.health = 480;
Back.update = true;
Back.hasShadow = false;
Back.setupRequirements(
	Category.effect,
	BuildVisibility.shown,
	ItemStack.with(
		myItem.铱板, 35,
		myItem.导能回路, 25,
		Items.phaseFabric, 15
	)
);
exports.Back = Back;