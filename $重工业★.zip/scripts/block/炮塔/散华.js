const color = Items.surgeAlloy.color;
const lib = require("base/coflib");
const FX = require("base/effect");
const bullets = require("base/bullet");

let bu = Object.assign(bullets.TwoStageBulletType(160), {
	damage: 115,
	speed: 6,
	width: 16,
	height: 8,
	backColor: color,
	frontColor: color,
	trailWidth: 2,
	trailLength: 10,
	trailColor: color,
	despawnEffect: new Effect(60, e => {
		Draw.color(color);
		Lines.circle(e.x, e.y, 32 * e.fout(new Interp.PowOut(4)));
	})
});
let bB = Object.assign(bullets.FortressBulletType(240, 6, bu, 4, 0, 90), {
	lifetime: 600,
	speed: 8,
	width: 8,
	height: 8,
	backColor: color,
	frontColor: color,
	despawnEffect: new Effect(120, e => {
		Draw.color(color);
		Lines.circle(e.x, e.y, 32 * e.fout(new Interp.PowOut(4)));
	})
});

const tf = new PowerTurret("散华");
tf.reload = 720;
tf.consumePower(45);
tf.shootType = bB;
tf.range = 640;
tf.size = 4;
tf.recoil = 2;
tf.setupRequirements(
	Category.turret,
	BuildVisibility.sandboxOnly,
	ItemStack.with(
		Items.graphite, 120,
		Items.titanium, 90,
		Items.silicon, 60
	)
);

lib.setBuilding(PowerTurret.PowerTurretBuild, tf, {
	draw() {
		this.super$draw();
		FX.PlayerAim(this, lib.FF5845);
	}
});