const color = Items.surgeAlloy.color;
const lib = require("base/coflib");
const FX = require("base/effect");
const bullets = require("base/bullet");
const bB = Object.assign(bullets.HomingBulletType(4), {
	lifetime: 120,
	speed: 6,
	damage: 45,
	backColor: color,
	frontColor: color,
	width: 16,
	height: 8,
	pierceCap: 2,
	pierceBuilding: true,
	trailWidth: 2,
	trailLength: 10,
	trailColor: color,
	despawnEffect: new Effect(60, e => {
		Draw.color(color);
		Lines.circle(e.x, e.y, 32 * e.fout(new Interp.PowOut(4)));
	}),
	bulletInterval: 15,
	intervalBullets: 4,
	intervalRandomSpread: 30,
	intervalBullet: Object.assign(new BasicBulletType(8, 45), {
		lifetime: 25,
		width: 8,
		height: 4,
		trailWidth: 1,
		trailLength: 5,
		trailColor: color,
		despawnEffect: Fx.flakExplosion
	})
});

const SUT = extend(PowerTurret, "SUT", {
	setBars() {
		this.super$setBars();
		this.addBar("fastReload", func(e => new Bar(
			prov(() => lib.bundle("bar.fastReload", Strings.fixed(e.getTime() * 100, 0))),
			prov(() => lib.Color("FF9C5A")),
			floatp(() => e.getTime())
		)));
	}
});
SUT.reload = 30;
SUT.consumePower(45);
SUT.shootType = bB;
SUT.range = 360;
SUT.size = 4;
SUT.recoil = 2;
SUT.setupRequirements(
	Category.turret,
	BuildVisibility.sandboxOnly,
	ItemStack.with(
		Items.graphite, 120,
		Items.titanium, 90,
		Items.silicon, 60
	)
);

SUT.buildType = () => {
	let time = SUT.reload, minTime = 4;
	return extend(PowerTurret.PowerTurretBuild, SUT, {
		getTime() {
			return (SUT.reload - time) / (SUT.reload - minTime);
		},
		updateTile() {
			this.super$updateTile();
			if (this.timer.get(time)) {
				if (this.isShooting()) {
					this.bullet(bB, 0, 0, 0, null);
					if (time > minTime) time--
				} else {
					if (SUT.reload > time) time++
				}
			}
		},
		draw() {
			this.super$draw();
			FX.PlayerAim(this, lib.FF5845);
		}
	})
};
//Timer.schedule(() => {
	//重复执行的部分
//}, delaySeconds /*第一次执行的时间点*/ , intervalSeconds /*每次执行的时间间隔*/ , repeatCount /*重复执行的次数*/ )