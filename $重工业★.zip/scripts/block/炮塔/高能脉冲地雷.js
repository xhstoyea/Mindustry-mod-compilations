const lib = require("base/coflib")
const status = require("base/status");

let emb = Object.assign(new BasicBulletType(0, 120), {
	instantDisappear: true,
	splashDamage: 480,
	splashDamageRadius: 32,
	status: status.连锁闪电,
	statusDuration: 60,
	ammoMultiplier: 1,
	hitSound: Sounds.plasmaboom,
	hitEffect: Fx.dynamicSpikes.wrap(lib.Color("A9D8FF"), 30)
})
let emp = extend(ShockMine, "高能脉冲地雷", {
	setStats() {
		this.super$setStats();
		this.stats.add(Stat.reload, 60 / 90, StatUnit.perSecond);
		this.stats.add(Stat.ammo, StatValues.ammo(OrderedMap.of(this, emb)));
	}
})
emp.bullet = emb;