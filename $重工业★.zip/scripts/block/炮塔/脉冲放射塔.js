const lib = require("base/coflib");
const pulse = new PowerTurret("脉冲放射塔");
lib.setBuilding(PowerTurret.PowerTurretBuild, pulse, {
	findTarget() {
		this.target = this;
	},
	validateTarget() {
		return true
	}
})