const lib = require("base/coflib");
const pulsar = new PowerTurret("脉冲星");

pulsar.drawer = (() => {
	const d = new DrawTurret();
	for (let i = 0; i < 5; i++) {
		d.parts.add(
			Object.assign(new RegionPart("-aim"), {
				heatProgress: DrawPart.PartProgress.warmup.sin((4 - i) * 10, 20, 1),
				drawRegion: false,
				y: (17.25 + i * 20) / (1 - i * 0.1),
				xScl: 1 - i * 0.1,
				yScl: 1 - i * 0.1,
				heatColor: lib.Color("D1EFFF")
			})
		)
	}
	for (let i = 0; i < 4; i++) {
		lib.DoubleHalo(d, {
			x: -20,
			y: 32,
			moveX: i * 4,
			moveY: i * 10,
			shapeMR: i * -15,
			shapes: 1,
			radius: 0,
			radiusTo: 2 + 3 - i,
			triL: 0,
			triLT: 28 + i * 4,
			haloRot: 45,
			color: lib.Color("8CA9E8"),
			colorTo: lib.Color("D1EFFF")
		})
	}
	d.parts.add(
		Object.assign(new RegionPart("-warmup"), {
			heatProgress: DrawPart.PartProgress.warmup,
			drawRegion: false
		})
	)
	return d;
})();