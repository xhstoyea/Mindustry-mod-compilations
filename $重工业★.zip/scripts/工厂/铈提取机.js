const status = require("base/status");
let range = 40;

let st = new GenericCrafter("铈提取机");
st.buildType = prov(() => {
	let size = 0;
	return extend(GenericCrafter.GenericCrafterBuild, st, {
		updateTile() {
			this.super$updateTile();
			size = this.timeScale > 1 ? Math.min((this.timeScale - 1) / 2 + 1, 2.5) : this.timeScale;
			Damage.status(null, this.x, this.y, range * this.warmup * size, status.次级辐射, 300, true, true);
		},
		draw() {
			this.super$draw();
			Draw.z(Layer.shields);
			Draw.color(Color.valueOf("F9A3C7CC"));
			Fill.poly(this.x, this.y, 16, range * this.warmup * size);
		}
	})
});