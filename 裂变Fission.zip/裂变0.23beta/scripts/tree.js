const nodeRoot = TechTree.nodeRoot;
const nodeProduce = TechTree.nodeProduce;
const node = TechTree.node;
const SectorComplete = Objectives.SectorComplete;
const Research = Objectives.Research;

const planet = require('planet');
const item = require('A基础/item');
const core = require('blocks/GenericCore');

nodeRoot("Sepsnak", core.Gc1GenericCore, () => {
  nodeProduce(item.EliMetal, () => {
  //伊莱金属
    nodeProduce(item.DevonMetal, () => {})
    //德文金属
    nodeProduce(item.YarkMetal, () => {
    //亚克金属
      nodeProduce(item.HilesMetal, () => {
      //海尔斯金属
/*        nodeProduce(item.DahlAlloy, () => {
        //达尔合金
        }) */
      })
    })
    nodeProduce(item.GeigerElement, () => {
    //盖革元素
      nodeProduce(item.EngelElement, () => {
      //恩格尔元素
      })
    })
    nodeProduce(item.TukavenMetal, () => {
    //图卡文金属
      nodeProduce(item.VincennoMetal, () => {
      //文森诺金属
/*        nodeProduce(item.GoreAlloy, () => {
        //戈尔合金
        }) */
      })
    })
  })
})