const lib = require("lib");

const Sepsnak = new Planet("Sepsnak", Planets.sun, 1, 3);
Object.assign(Sepsnak, {
	generator: extend(SerpuloPlanetGenerator,  {
		getDefaultLoadout() {
			return Schematics.readBase64("bXNjaAF4nGNgZmBmZmDJS8xNZWBOLM5g4E5JLU4uyiwoyczPY2BgYMtJTErNKWZgio5lZOBIKk0v1gWpYmBgBCEgAQDukg32");
		},
		allowLanding(sector){return false},
		getColor(position) {
			var depth = Simplex.noise3d(4, 4, 0.56, 1.7, position.x, position.y, position.z) / 2;
			return Color.valueOf("9192A6FF").write(Color.valueOf("C1C4CBFF")).lerp(Color.valueOf("6B698AFF"),Mathf.clamp(Mathf.round(depth, 0.25)));
		}
	}),
	meshLoader: prov(() => new HexMesh(Sepsnak, 4)),
	cloudMeshLoader: () => new MultiMesh(
		new HexSkyMesh(Sepsnak, 2, 0.15, 0.14, 5, Color.valueOf("DADDE6FF"), 2, 0.42, 1, 0.45)
	),
	atmosphereColor: Color.valueOf("D7FFD4D2"),
	landCloudColor: Color.valueOf("D7FFD4D2"),
	atmosphereRadIn: 0.02,
	atmosphereRadOut: 0.3,
	visible: true,
	bloom: false,
	accessible: true,
	alwaysUnlocked: true,
	startSector: 1,
	camRadius: 0.5,
	orbitRadius: 75,
	orbitSpacing: 2,
	orbitTime: 240 * 60,
	rotateTime: 15 * 60,
//	defaultCore: core.coreShard,
	iconColor: Color.valueOf("C1C4CBFF"),
})
Sepsnak.ruleSetter = r => {
	r.attributes.set(Attribute.heat, -0.3);
	r.attributes.set(Attribute.light, -0.3);
}
Sepsnak.totalRadius += 2.6;
Sepsnak.hiddenItems.addAll(
	Items.scrap,
	Items.copper,
	Items.lead,
	Items.titanium,
	Items.thorium,
	Items.silicon,
	Items.plastanium,
	Items.phaseFabric,
	Items.surgeAlloy,
	Items.sporePod,
	Items.sand,
	Items.blastCompound,
	Items.pyratite,
	Items.metaglass,
	Items.beryllium,
	Items.tungsten,
	Items.oxide,
	Items.carbide,
	Items.fissileMatter,
	Items.dormantCyst
);
exports.Sepsnak = Sepsnak;

/*Planets.serpulo.hiddenItems.addAll(
	item.organosand,
	item.biomass,
	item.ossature,
	item.nickel,
	item.manganese,
	item.crystal,
	item.biomassSteel,
	item.organosilicon,
	item.neoplasmSteel,
	item.methylSulfone
);
Planets.erekir.hiddenItems.addAll(
	item.organosand,
	item.biomass,
	item.ossature,
	item.nickel,
	item.manganese,
	item.crystal,
	item.biomassSteel,
	item.organosilicon,
	item.neoplasmSteel,
	item.methylSulfone
);
*/
const map1 = new SectorPreset("幸运点", Sepsnak, 1);//名字 星球 区块
map1.description = "该区块是最佳的降落点 附近有几支来自其他组织的无人机甲小队 看来他们已经捷足先登了\n操控无人机建造工事并占领该区块 不要让组织失望 坚守者";
map1.difficulty = 1;//1-10
map1.alwaysUnlocked = true;//总是解锁
map1.addStartingItems = true;//允许添加初始资源
map1.captureWave = 5;//多少波可占领
map1.localizedName = "幸运点";
exports.map1 = map1;
lib.addToResearch(map1, {
	parent: "groundZero",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});
const map2 = new SectorPreset("辐射山巅", Sepsnak, 100);//名字 星球 区块
map2.description = "根据侦察机送回的图像和矿物样本来看 该区块富含一种未知的放射性元素 暂且命名为“盖革元素” 组织需要更多的样本进行研究 小心对这个区块虎视眈眈的敌人 发挥你在培训基地学到的技巧 合理运用地形来增加优势\n操控无人机建造钻头挖掘更多“盖革元素”并占领该区块";
map2.difficulty = 2;//难度 1-10
map2.alwaysUnlocked = false;//总是解锁
map2.addStartingItems = true;//允许添加初始资源
map2.captureWave = 20;//多少波可占领
map2.localizedName = "辐射山巅";
exports.map2 = map2;
lib.addToResearch(map2, {
	parent: "幸运点",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});
