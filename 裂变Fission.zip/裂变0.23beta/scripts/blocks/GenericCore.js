const item = require("A基础/item");

const Gcu1GenericCoreUnit = new UnitType("Gcu1GenericCoreUnit");
Object.assign(Gcu1GenericCoreUnit, {
	aiController: UnitTypes.alpha.aiController,
	isEnemy: true,
	lowAltitude: true,
	flying: true,
	mineSpeed: 7.9,
	mineHardnessScaling: false,
	mineTier: 1,
	buildSpeed: 1.75,
	drag: 0.05,
	speed: 4,
	rotateSpeed: 15,
	accel: 0.1,
	itemCapacity: 40,
	health: 350,
	engineOffset: 4,
	hitSize: 8,
	alwaysUnlocked: true,
	constructor: () => new UnitEntity.create(),
})
Gcu1GenericCoreUnit.weapons.add(
Object.assign(new Weapon(), {
	top: false,
	mirror: false,
	x: 0,
	y: 0,
	reload: 20,
	ejectEffect: Fx.none,
	recoil: 2,
	shootSound: Sounds.missile,
	inaccuracy: 4,
	alternate: true,
	bullet: Object.assign(new MissileBulletType(4, 12), {
		homingPower: 0.4,
		homingRange: 56,
		lifetime: 60,
		keepVelocity: false,
		shootEffect: Fx.shootSmall,
		smokeEffect: Fx.shootSmallSmoke,
		hitEffect: Fx.blastExplosion,
		despawnEffect: Fx.blastExplosion,
		frontColor: Color.white,
		hitColor: Pal.bulletYellow,
		backColor: Pal.bulletYellowBack,
		trailColor: Pal.bulletYellowBack,
		hitSound: Sounds.none,
		buildingDamageMultiplier: 0.3,
	})
})
)

const Gc1GenericCore = CoreBlock("Gc1GenericCore");
exports.Gc1GenericCore = Gc1GenericCore
Object.assign(Gc1GenericCore, {
	alwaysUnlocked: true,
	isFirstTier: true,
	unitType: Gcu1GenericCoreUnit,
	health: 3200,
	itemCapacity: 4500,
	size: 3,
	unitCapModifier: 15,
	researchCostMultiplier: 1.75,
	buildVisibility: BuildVisibility.shown,
	category: Category.effect,
	requirements: ItemStack.with(
		item.EliMetal, 1200,
		item.YarkMetal, 950,
	)
})