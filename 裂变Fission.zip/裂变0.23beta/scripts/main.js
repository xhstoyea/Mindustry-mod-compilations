require("lib");
require("planet");
require("tree");
require("A基础/item");
require("A基础/environment");
require("A基础/gas");
require("A基础/ore");
require("blocks/GenericCore");