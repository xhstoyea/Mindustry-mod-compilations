//普通环境墙 普通地板
const MarbleStoneWall = new StaticWall("Marble-Stone-Wall");
exports.MarbleStoneWall = MarbleStoneWall;

const MarbleStone = new Floor("Marble-Stone");
exports.MarbleStone = MarbleStone;
Object.assign(MarbleStone, {
	variants: 2,
})
//大理石√
const WhiteStoneWall = new StaticWall("White-Stone-Wall");
exports.WhiteStoneWall = WhiteStoneWall;

const WhiteStone = new Floor("White-Stone");
exports.WhiteStone = WhiteStone;
Object.assign(WhiteStone, {
	variants: 2,
})
//方解石√
const GravelStoneWall = new StaticWall("Gravel-Stone-Wall");
exports.GravelStoneWall = GravelStoneWall;

const GravelStone = new Floor("Gravel-Stone");
exports.GravelStone = GravelStone;
Object.assign(GravelStone, {
	variants: 2,
})
//砾石√
const MudStoneWall = new StaticWall("Mud-Stone-Wall");
exports.MudStoneWall = MudStoneWall;

const MudStone = new Floor("Mud-Stone");
exports.MudStone = MudStone;
Object.assign(MudStone, {
	variants: 2,
})
//泥岩√
const MalmstoneWall = new StaticWall("Malmstone-Wall");
exports.MalmstoneWall = MalmstoneWall;

const Malmstone = new Floor("Malmstone");
exports.Malmstone = Malmstone;
Object.assign(Malmstone, {
	variants: 2,
})
//砂岩
/*const MicaStoneWall = new StaticWall("Mica-Stone-Wall");
exports.MicaStoneWall = MicaStoneWall;

const MicaStone = new Floor("Mica-Stone");
exports.MicaStone = MicaStone;
Object.assign(MicaStone, {
	variants: 2,
})*/
//碳酸盐岩
Attribute.add("NaturalGas");
//喷口
const MudStoneNaturalGasVent = new SteamVent("Mud-Stone-Natural-Gas-Vent")
exports.MudStoneNaturalGasVent = MudStoneNaturalGasVent;
Object.assign(MudStoneNaturalGasVent, {
    parent: MudStone,
    blendGroup: MudStone,
})
MudStoneNaturalGasVent.attributes.set(Attribute.get("NaturalGas"), 1);

const MalmstoneNaturalGasVent = new SteamVent("Malmstone-Natural-Gas-Vent")
exports.MalmstoneNaturalGasVent = MalmstoneNaturalGasVent;
Object.assign(MalmstoneNaturalGasVent, {
    parent: Malmstone,
    blendGroup: Malmstone,
})
MalmstoneNaturalGasVent.attributes.set(Attribute.get("NaturalGas"), 1);
