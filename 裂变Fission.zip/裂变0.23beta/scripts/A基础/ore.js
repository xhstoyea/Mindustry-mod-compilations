const item = require('A基础/item')

new OreBlock("ore-Eli-Metal",item.EliMetal);
new OreBlock("ore-Geiger-Element",item.GeigerElement);
new OreBlock("ore-Yark-Metal",item.YarkMetal);