const NaturalGas = new Liquid("Natural-Gas",Color.valueOf("B5D4FFFF"));
exports.NaturalGas = NaturalGas;
Object.assign(NaturalGas, {
    gas:true,
	temperature:0.2,
	flammability:2,
})