const EliMetal = new Item("Eli-Metal", Color.valueOf("B0BAC9FF"));
exports.EliMetal = EliMetal;
Object.assign(EliMetal, {
	hardness:1,
	cost:0.54,
	healthScaling:0.01,
})
//伊莱金属
const DevonMetal = new Item("Devon-Metal", Color.valueOf("AEB1D3FF"));
exports.DevonMetal = DevonMetal;
Object.assign(DevonMetal, {
	hardness:1,
	cost:0.32,
	healthScaling:0.01,
})
//德文金属
const FaradayMetal = new Item("Faraday-Metal", Color.valueOf("9A9DBFFF"));
exports.FaradayMetal = FaradayMetal;
Object.assign(FaradayMetal, {
	hardness:3,
	cost:0.53,
	healthScaling:0.01,
})
//法拉第金属
const YarkMetal = new Item("Yark-Metal", Color.valueOf("B0BAC0FF"));
exports.YarkMetal = YarkMetal;
Object.assign(YarkMetal, {
	hardness:2,
	cost:0.73,
	healthScaling:0.05,
})
//亚克金属
const CrystalBud = new Item("Crystal-Bud", Color.valueOf("D7D7FFFF"));
exports.CrystalBud = CrystalBud;
Object.assign(CrystalBud, {
	cost:0.34,
	healthScaling:0.04,
})
//晶芽
const glaze = new Item("glaze", Color.valueOf("EBEEF5FF"));
exports.glaze = glaze;
Object.assign(glaze, {
	cost:0.4,
	healthScaling:0.04,
})
//琉璃
const HilesMetal = new Item("Hiles-Metal", Color.valueOf("889BA6FF"));
exports.HilesMetal = HilesMetal;
Object.assign(HilesMetal, {
	hardness:3,
	cost:0.98,
	healthScaling:0.07,
})
//海尔斯金属

/*
const DahlAlloy = new Item("Dahl-Alloy", Color.valueOf("BCAAAAFF"));
exports.DahlAlloy = DahlAlloy;
Object.assign(DahlAlloy, {
    cost:0.79,
    healthScaling:0.12,
})
*/
//达尔合金

const GeigerElement = new Item("Geiger-Element", Color.valueOf("CCFF66FF"));
exports.GeigerElement = GeigerElement;
Object.assign(GeigerElement, {
    radioactivity:0.8,
	hardness:2,
	cost:0.3,
	healthScaling:0.02,
})
//盖革元素
const EngelElement = new Item("Engel-Element", Color.valueOf("99FF66FF"));
exports.EngelElement = EngelElement;
Object.assign(EngelElement, {
    radioactivity:1.7,
	hardness:3,
	cost:0.58,
	healthScaling:0.05,
})
//恩格尔元素
const TukavenMetal = new Item("Tukaven-Metal", Color.valueOf("A18989FF"));
exports.TukavenMetal = TukavenMetal;
Object.assign(TukavenMetal, {
	hardness:3,
	cost:0.97,
	healthScaling:0.07,
})
//图卡汶金属
const VincennoMetal = new Item("Vincenno-Metal", Color.valueOf("8A6565FF"));
exports.VincennoMetal = VincennoMetal;
Object.assign(VincennoMetal, {
	hardness:4,
	cost:1.13,
	healthScaling:0.12,
})
//文森诺金属

/*
const GoreAlloy = new Item("Gore-Alloy", Color.valueOf("BCAAAAFF"));
exports.GoreAlloy = GoreAlloy;
Object.assign(GoreAlloy, {
    cost:1.24,
    healthScaling:0.23,
})
//戈尔合金
*/