const lib = require("lib")
require('techTreeLib');
//require('？/替换背景');
require('？/qwer');
require('？/核心');
require('？/大核心');
require('？/blocks');
require("？/地板");
require("？/Filter");
require('？/墙体拆除器');
require('？/墙体拆除器t2');
require('？/物品');
require('？/修复者AI');
require('？/shield2');
require('sectorSize');
require('？/status');
//require('？/stackBridge');
//删除指定mod
const 大型护盾立场 = new ForceProjector("大型护盾立场");
大型护盾立场.buildType = prov(() => extend(ForceProjector.ForceBuild, 大型护盾立场,{
    updateTile(){
        this.super$updateTile()
        let realRadius = this.realRadius();
        if(!this.broken){
            Groups.bullet.intersect(this.x - realRadius , this.y - realRadius , realRadius * 2 + 12, realRadius * 2 + 12, b => {
                if(b.type.absorbable && b.team != this.team){
                    b.vel.setAngle(b.rotation() + 180);
                    b.team = this.team
                    this.buildup += b.damage * 0.7;
                }
            });
        }
    }
}));
//xvx神魂
//本代码可以塞在任意方块里
//比如墙又或者传送带，又或者核心
//只要这个方块可以刷新，就可以塞并且有效果


const 降临 = extend(ItemTurret, "降临", {});
const 驻扎核心 = extend(CoreBlock, "驻扎核心", {
	canReplace(other) {
		return true;
	}
	});


驻扎核心.buildVisibility = BuildVisibility.shown;
驻扎核心.category = Category.logic;

//这是必需的
驻扎核心.update = true;
//设置方块可使用物品
驻扎核心.hasItems = true;

//设置可使用的弹药
const TItems = [Items.graphite,Items.beryllium]

驻扎核心.buildType = prov(() => {
	//创建多炮塔
	//(方块，队伍(不需要设置))
	const payloads = [
		new BuildPayload(降临, Team.derelict),
					
	];
	const build = extend(CoreBlock.CoreBuild, 驻扎核心, {
		updateTile() {
			this.super$updateTile();

			//可以让炮塔转起来的代码
			//删除注释以使用
			/*for (var i = 0; i < payloads.length; i++) {
                var t = payloads[i];
                var rotation = (360.0 / payloads.length) * i + Time.time;

				//这里的24为距离本体方块中心的多少距离旋转(8为1格)
                t.set(x + Angles.trnsx(rotation, 24), y + Angles.trnsy(rotation, 24), t.build.payloadRotation);
            }*/

			//设置模块
		
			for(var id = 0; id < payloads.length; id++){
				//设置队伍，如果在上面的创建位置设置，无用
                if(payloads[id].build.team != this.team){
                    payloads[id].build.team = this.team;
                }
				
				//执行炮塔更新
                payloads[id].update(null, this);

				//为物品炮塔添加弹药
				//你们需要可自己定义
				for(var i = 0; i < TItems.length; i++){
					if(payloads[id].build.acceptItem(payloads[id].build, TItems[i]) && this.items.get(TItems[i]) >= 1) {
						payloads[id].build.handleItem(payloads[id].build, TItems[i]);
						this.items.remove(TItems[i], 1);
					}
				}
            }

			//设置炮塔的位置
			//有需求你们可以自己定义
			//（x, y, r）
			payloads[0].set(this.x + 0, this.y + 0, payloads[0].build.payloadRotation);

		},
		draw(){
			this.super$draw();

			//执行多炮塔的动画
			for(var i = 0; i < payloads.length; i++){
                payloads[i].draw();
            }
		},
	});

	return build;
});

Events.on(EventType.ClientLoadEvent, () => {

if(Vars.mods.getMod("岩浆工业") != null)Vars.mods.removeMod(Vars.mods.getMod("岩浆工业"));

if(Vars.mods.getMod("虚无") != null)Vars.mods.removeMod(Vars.mods.getMod("虚无"));

if(Vars.mods.getMod("sun1") != null)Vars.mods.removeMod(Vars.mods.getMod("sun1"));

if(Vars.mods.getMod("深海科技") != null)Vars.mods.removeMod(Vars.mods.getMod("深海科技"));

if(Vars.mods.getMod("无限宇宙") != null)Vars.mods.removeMod(Vars.mods.getMod("无限宇宙"));
})