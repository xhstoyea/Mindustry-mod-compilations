function ArmorStatus(name, armor) {
	return extend(StatusEffect,name, {
		update(unit) {
unit.armor = unit.type.armor + armor;
	}});
};
ArmorStatus("装甲强化", 8);
ArmorStatus("装甲弱化", -6);

function ArmorStatusMultiplier(name, armor) {
	return extend(StatusEffect,name, {
		update(unit) {
unit.armor = unit.type.armor * armor;
	}});
};//healthMultiplier
ArmorStatusMultiplier("复合装甲", 1.5);


function HealthStatus(name, hp) {
	return extend(StatusEffect,name, {
		update(unit) {
unit.maxHealth = unit.type.health + hp;
	}});
};
HealthStatus("生命强化", 400);

/*function PercentageStatus(name, percentage) {
	return extend(StatusEffect,name, {
		update(unit) {
unit.damageContinuousPierce = unit.type.health * percentage / 6000
	}});
};
HealthStatus("崩溃", 1);*/