Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("古代科技");
    dialog.buttons.defaults().size(400, 64);
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(400, 64);

    dialog.cont.pane((() => {

        var table = new Table();
        table.add("Information")
        table.row();
        //换行
		table.image(Core.atlas.find("古代科技-logo", Core.atlas.find("clear"))).left().fillX().height(400).width(400).pad(3);
		table.row();
        table.add('[orange]来自' + '德国骨科' + '[][orange]喵子的话:');
        table.row();
        table.add('mod群494527061\n超级发射台！')
        table.row();
    table.button('设定', Icon.infoCircle, run(() => {
    var dialog = new BaseDialog("设定");
    dialog.cont.pane(t => {
        t.add("设定");
        t.row();
        t.button("单位", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("单位");
            dialog.cont.pane(t => {
                t.add("1水(100L) 1热=350摄氏度 1方块为1㎡");
                t.row();
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
            dialog.show();
        })).size(400, 64);
        t.row();

        t.button("Delta科技", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("Delta科技");
            dialog.cont.pane(t => {
                t.add("操控暗物质和暗能量来制作武器或工厂")
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
            dialog.show();
        })).size(400, 64);
        t.row();
        
        t.button("更新介绍 ", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("更新介绍");
            dialog.cont.pane(t => {
                t.add("超级传送带")
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
            dialog.show();
        })).size(400, 64);
        t.row();
        
        t.button("先驱者", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("先驱者");
            dialog.cont.pane(t => {
                t.add("第一个导的那个吗")
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
            dialog.show();
        })).size(400, 64);
        t.row();
        
    });
    dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
    dialog.show();
})).size(400, 64);
        table.row();
    table.button('特别感谢', Icon.infoCircle, run(() => {
    var dialog = new BaseDialog("特别感谢");
    dialog.cont.pane(t => {
        t.add("渐变 铧金 终极幻想作者 RA以及喵喵怪 枕头 小伞 余明等，pardon，感谢大家的支持")
    });
    dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
    dialog.show();
})).size(400, 64);
        table.row();
        return table;
    })()).grow().center().maxWidth(620);
    dialog.show();
}));
//代码来源于铧金工业！