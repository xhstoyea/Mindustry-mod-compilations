const 修复湾 = extend(CoreBlock, "修复湾", 
{
canBreak(){return true;},
canReplace(other){return true;},
canPlaceOn(tile, team){return true;},
});
exports.修复湾 = 修复湾;