var table = new Table();
const control = {
	boosting: false
};
global.boostControl = control;

Events.on(EventType.ClientLoadEvent, cons(e => {
	rebuild();
    //miner大佬NB
	Vars.ui.hudGroup.fill(cons(t => {
		t.right().name = "fuzhu";
		t.add(table);
		 t.addListener(extend(InputListener, {
			 lastx: 1000,
			 lasty: 0,
			 touchDown(event, x, y, pointer, button){
				 var v = t.localToParentCoordinates(Tmp.v1.set(x, y));
				 this.lastx = v.x;
				 this.lasty = v.y;
				 return true;
			 },
	 
			 touchDragged(event, x, y, pointer){
				 var v = t.localToParentCoordinates(Tmp.v1.set(x, y));
				 t.translation.add(v.x - this.lastx, v.y - this.lasty);
				 this.lastx = v.x;
				 this.lasty = v.y;
			 },
		 }));
	}));
}));


function rebuild(){
	table.clear();
    	table.visibility = () => Vars.ui.hudfrag.shown && !Vars.ui.minimapfrag.shown();
    	table.defaults().left();
		table.background(Styles.black6);        
        table.row();
        table.table(cons(buttons => {
        buttons.background(Tex.buttonTrans)

        buttons.button("光照", Styles.togglet, () => {
		Vars.enableLight = !Vars.enableLight;
	}).size(120,30);
	
		buttons.row();

    	buttons.button("阴影", Styles.togglet, () => {
		Vars.enableDarkness = !Vars.enableDarkness;
	}).size(120,30);
	
    	buttons.row();
    	
    	buttons.button("暂停建造", Styles.togglet, () => {
		Vars.control.input.isBuilding = !Vars.control.input.isBuilding;
	}).size(120,55);

	    buttons.row();
	
        const button = buttons.button("关闭助推",Styles.togglet, () => {
		control.boosting = !control.boosting;
		button.setText(control.boosting ? "启动助推" : "关闭助推");
	}).width(120).height(55).get();
    	}));
    };

Events.run(Trigger.update, () => {
	Vars.player.boosting = control.boosting;
});