# Mechy-chaos
![logo](https://github.com/New-guys5634/Mechy-chaos/blob/9d7fb7f1b7c3b8e73da56d87ef224f8e7c519dd8/sprites-override/ui/logo.png)
a new campaign mod
your squad has launched you from UNIDENTIFIED planet after conquering the last bit of mass, your mission is simple destroy the planet but a strange sense led you to land in this planet and loosing all contact with serpulo.

your main mission is to enter REDACTED laboratory to set a contacting point to get rescued

beware though there are entities ready to ruin your base 

he will return v0.19

CREDITS
me: beee or yiu like everything
xb: xb YT or xb6511 unit production oxygen better overall sprite ideas
