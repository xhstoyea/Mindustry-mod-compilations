# TowerDefense
Mindustry mod that adds many new objects and maps

Mod in development, so there isn't many items

Explore sectors to unlock new objects,  
Create the best defense,  
Find the easiest way to win
