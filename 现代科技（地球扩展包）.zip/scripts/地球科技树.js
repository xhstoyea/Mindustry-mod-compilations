const {指挥中心} = require("指挥中心");
const lib = require("lib");
const {地球} = require("地球");
地球.techTree = TechTree.nodeRoot( "地球", 指挥中心, true, run(() => {}));

			