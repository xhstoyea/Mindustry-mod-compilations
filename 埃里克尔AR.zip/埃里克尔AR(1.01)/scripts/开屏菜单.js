
//以下注释为VSHES荔枝独立完成为了让其他蔚蓝开发者同样可以更新开屏显示窗口插件
Events.on(EventType.ClientLoadEvent, cons(e => {
       var dialogo = new BaseDialog("埃里克尔AR\nAzure Planet");//新建一个显示窗口
	dialogo.buttons.button("@close", run(() => {
		dialogo.hide()//退出此界面
	})).size(210, 64);//按钮用原版@close贴图

    dialogo.cont.pane(table => {//滑动显示
        
        table.add(Core.bundle.get("？？？？？？？")).left().growX().wrap().width(600).maxWidth(600).pad(4).labelAlign(Align.left).row();
        
		table.image(Core.atlas.find("erekir")).left().size(600, 200).pad(3).row();//显示logo图片

		table.add("模组的更新幅度比较多，所以原本的0.1直到现在1.0，所以我会尽可能放慢模组的更新，一个大版本就更新几个东西太少，所以我放慢速度。   模组更新了一个炮台，但是炮台数据不对，建议大家不要使用，模组了更新了新的战役区块。    。\n\n——————————\n请加QQ群获取最新版埃里克尔AR模组。").left().growX().wrap().pad(4).labelAlign(Align.left).row();
		 let label = new FLabel("下载本模组的qq群: 791636288");
		 table.add(label).left().row();
		 table.add("本模组了重置了战役区块地图，将按原版。目前这个版本只更新了5个区块；  始发地区，庇护前哨，岩浆湖，交错丘陵，风化山脉；  新的地图已经更改，你的新挑战吧。模组添加。QQ群              791636288                     祝你游玩本模组快乐！"
).left().growX().wrap().width(580).maxWidth(580).pad(4).labelAlign(Align.left).row();

	}).grow().center().maxWidth(600)
	 /*dialogo.cont.button("加入蔚蓝qq群",run(() => {
               Core.app.openURI("https://jq.qq.com/?_wv=1027&k=sEIHp3QY");
             })).size(100,70).pad(2);//添加qq群功能为荔枝VSHES添加*/
             dialogo.show();
}))