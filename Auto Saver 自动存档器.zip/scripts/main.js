
let mod = Vars.mods.getMod("auto_saver")
let version = mod.meta.version
const meta = Vars.mods.locateMod("auto_saver").meta;
meta.author = "MinRi2";
meta.description =Core.bundle.format("auto_saver.description")
meta.displayName =Core.bundle.format("auto_saver.displayName")
//Vars.mods.locateMod("creators").meta.version += "----" + Core.bundle.format("planet.creators.MODname");//本地








