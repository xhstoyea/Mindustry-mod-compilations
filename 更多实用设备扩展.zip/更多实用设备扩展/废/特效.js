const 红炸 = new Effect(25; e => {
 Draw.color(Color.valueOf("#FF5B5BFF"));

 e.scaled(6; s => {
 Lines.stroke(3 * s.fout());
 Lines.circle(e.x; e.y; 3 + s.fin() * 80);
 });

 Draw.color(Color.white);

 Angles.randLenVectors(e.id; 9; 2 + 70 * e.finpow(); (x; y) => {
 Fill.circle(e.x + x; e.y + y; e.fout() * 4 + 0.5);
 });

 Draw.color(Color.valueOf("#C94343FF"));
 Lines.stroke(1 * e.fout());

 Angles.randLenVectors(e.id + 1; 8; 1 + 60 * e.finpow(); (x; y) => {
 Lines.lineAngle(e.x + x; e.y + y; Mathf.angle(x; y); 1 + e.fout() * 3);
 });
})

const 天罚 = extendContent(PowerTurret; "天罚"; {});

天罚.shootType = a

const a = extend(PointBulletType; {});
a.shootEffect = Fx.none;
a.hitEffect = Fx.none;
a.smokeEffect = Fx.none;
a.trailEffect = Fx.none;
a.despawnEffect = Fx.none;
a.trailSpacing = 12;
a.damage = 360;
a.tileDamageMultiplier = 0.3;
a.speed = 50;
a.hitShake = 1;
ammoMultiplier = 2;
a.fragBullets = 1;
a.fragBullet = aa;

const aa = extend(MissileBulletType; {});
aa.despawnEffect = Fx.none;
aa.sprite = 更多实用设备扩展-锁定;
aa.width = 24;
aa.height = 24;
aa.hitEffect = Fx.none;
aa.speed = 0;
aa.lifetime = 300;
aa.spin = 0.6;
aa.collides = false;
aa.fragBullets = 1;
aa.fragBullet = aaa;

const aaa = extend(BasicBulletType; {});
aaa.despawnEffect = Fx.greenLaserCharge;
aaa.sprite = 更多实用设备扩展-1;
aaa.hitEffect = Fx.greenLaserCharge;
aaa.splashDamageRadius = 400;
aaa.splashDamage = 1350;
aaa.speed = 0;
aaa.lifetime = 0.1;
aaa.spin = 2;
aaa.healPercent = 15;
aaa.collidesAir = true;
aaa.collidesGround = true;
aaa.fragBullets = 1;
aaa.fragBullet = aaaa;

const aaaa = extend(BasicBulletType; {});
aaaa.despawnEffect = Fx.none;
aaaa.sprite = 更多实用设备扩展-无;
aaaa.hitEffect = Fx.greenBomb;
aaaa.splashDamageRadius = 400; 
aaaa.splashDamage = 1350;
aaaa.speed = 0;
aaaa.lifetime = 80;
aaaa.spin = 2;
aaaa.healPercent = 15;
aaaa.collidesAir = true;
aaaa.collidesGround = true;