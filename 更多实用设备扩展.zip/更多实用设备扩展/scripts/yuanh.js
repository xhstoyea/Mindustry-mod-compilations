const shootBig3 = new Effect(10, cons(e => {
    Draw.color(Pal.lighterOrange, Pal.lightOrange, e.fin());
    var w = 1.2 + 10 * e.fout();
    Drawf.tri(e.x, e.y, w, 36 * e.fout(), e.rotation);
    Drawf.tri(e.x, e.y, w, 6 * e.fout(), e.rotation + 180);
    }));
const casing4 = new Effect(60,cons(e => {
    Draw.z(Layer.bullet);
    Draw.color(Pal.lightOrange, Pal.lightishGray, Pal.lightishGray, e.fin());
    Draw.alpha(e.fout(0.5));
    var rot = Math.abs(e.rotation) + 90;
    var i = -Mathf.sign(e.rotation);
    var len = (8 + e.finpow() * 9) * i;
    var lr = rot + Mathf.randomSeedRange(e.id + i + 6, 20 * e.fin()) * i;
    Draw.rect(Core.atlas.find("casing"),
    e.x + Angles.trnsx(lr, len) + Mathf.randomSeedRange(e.id + i + 7, 3 * e.fin()),
    e.y + Angles.trnsy(lr, len) + Mathf.randomSeedRange(e.id + i + 8, 3 * e.fin()),
    3.5, 6,
    rot + e.fin() * 50 * i
    );
}));

const tu = new BasicBulletType();
tu.damage = 362;
tu.speed = 8;
tu.lifetime = 50;
tu.hitSize = 8;
tu.width = 20;
tu.height = 28;
tu.shootEffect = shootBig3;
tu.pierceCap = 4;
tu.pierceBuilding = true;
tu.knockback = 0.9;
const sm = new BasicBulletType();
sm.speed = 8;
sm.lifetime = 50;
sm.damage = 196;
sm.hitSize = 5.6;
sm.width = 18;
sm.height = 26;
sm.shootEffect = shootBig3;
sm.ammoMultiplier = 4;
sm.reloadMultiplier = 1.7;
sm.knockback = 0.5;
const liu = new BasicBulletType();
liu.damage = 194;
liu.speed = 8;
liu.lifetime = 50;
liu.hitSize = 5;
liu.width = 19;
liu.height = 27;
liu.frontColor = Pal.lightishOrange;
liu.backColor = Pal.lightOrange;
liu.status = StatusEffects.burning;
liu.hitEffect = new MultiEffect(Fx.hitBulletSmall, Fx.fireHit);
liu.shootEffect = shootBig3;
liu.makeFire = true;
liu.pierceCap = 3;
liu.pierceBuilding = true;
liu.knockback = 0.8;
liu.ammoMultiplier = 3;
liu.splashDamage = 23;
liu.splashDamageRadius = 32;

const yh = extend(ItemTurret, "怨魂", {});
yh.ammo(
    Items.graphite,sm,
    Items.pyratite,liu,
    Items.thorium,tu
    );
yh.ammoUseEffect = casing4;
yh.ammoEjectBack = 4;