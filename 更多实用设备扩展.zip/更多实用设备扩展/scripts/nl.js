const item = require('item');//引用物品
//接口区：
const damage = 120;
const reload = 30;
const range = 400;
const color = Color.valueOf("FFFFC4FF");
const lightningColor = Color.valueOf("FFFFC4FF");
const maxFind = 30;
const sectors = 4;
const sectorRad = 0.14;
const blinkScl = 20;
const rotateSpeed = 5;
const effectRadius = 8;
const hasLightning = true;
const hitLightning = true;
const hitLightnings = 4;
const hitLightningCone = 360;
const hitLightningAngle = 0;
const hitLightningDamage = 5;
const hitLightningLength = 10;
const hasLightningDamage = 5;
const lightningChance = 0.05;
const hasLightningLength = 15;
const hasLightningCone = 360;
const hasLightningAngle = 0;
const shootEffect = se;
const hitEffect = Fx.chainLightning;
const hitStatus = StatusEffects.none;
const hitStatusD = 30;
const dTime = 360;
//接口区↑
//设定区：
  //方块
const /*不建议改>*/nlt /*<不建议改*/ = extend(/*type>*/StorageBlock,/*name>*/"能量迸射塔", {
    setStats() {
        this.super$setStats();
        this.stats.add(Stat.abilities, Core.bundle.format("ability.energyfield",damage,range/8,maxFind));
    },
    drawPlace(x,y,rotation,valid){
        this.super$drawPlace(x,y,rotation,valid);
        Drawf.circles(x*Vars.tilesize, y*Vars.tilesize, range, color);
    }
});
nlt.consumeItem(/*消耗的物品*/item.power, 1/*数量*/);
nlt.itemCapacity = 10;
nlt.update = true;//别改
  //方块↑
const se = new Effect(12, cons(e => {
    Draw.color(color);
    Lines.circle(e.x, e.y, e.fin() * e.rotation);
    Draw.reset();
}))

nlt.buildType = prov(() => {
    //重要的变量》》不要改《《
    var x = 0;
    var y = 0;
    var timer = 0;
    var curStroke = 0;
    var find = false;
    var k = 0;
    var target = new Seq();
    const chargeTime = 20;
    //重要的变量↑》》不要改《《
    return new JavaAdapter(StorageBlock.StorageBuild, {
        draw(){
            this.super$draw();
            if (this.items.get(item.power) >= 1){
            Draw.rect(Core.atlas.find(/*mod名+贴图名*/"更多实用设备扩展-能量迸射塔-top"),this.x,this.y,this.rotation);
            Draw.z(Layer.bullet - 0.001);
            Draw.color(color);
            Tmp.v1.trns(this.rotation - 90, x, y).add(this.x, this.y);
            var rx = Tmp.v1.x;
            var ry = Tmp.v1.y;
            var orbRadius = effectRadius * (1 + Mathf.absin(blinkScl, 0.1));

            Fill.circle(rx, ry, orbRadius);
            Draw.color();
            Fill.circle(rx, ry, orbRadius / 2);

            Lines.stroke((0.7 + Mathf.absin(blinkScl, 0.7)), color);

            for(var i = 0; i < sectors; i++){
                var rot = this.rotation + i * 360/sectors - Time.time * rotateSpeed;
                Lines.arc(rx, ry, orbRadius + 3, sectorRad, rot);
            }

            Lines.stroke(Lines.getStroke() * curStroke);

            if(curStroke > 0){
                for(var i = 0; i < sectors; i++){
                   var rot = this.rotation + i * 360/sectors + Time.time * rotateSpeed;
                   Lines.arc(rx, ry, range, sectorRad, rot);
                }
            }
            Drawf.light(rx, ry, range * 1.5, color, 0.8);
            Draw.reset();
            }
        },
        updateTile() {
            this.super$updateTile();
            if (k = 0) {
                this.consume();
                k = 1;
            };
            if (this.timer.get(dTime)) {
                this.consume();
            };
            if (this.items.get(item.power) >= 1){
            timer = Math.min(timer + Time.delta, reload);
            //Lock multiple (group friend selection)
            curStroke = Mathf.lerpDelta(curStroke, find ? 1 : 0, 0.09);
            if(timer >= reload){
                find = false;
                target.clear();
                Units.nearbyEnemies(this.team, this.x, this.y, range, cons(other => {
                    target.add(other);
                }));
                target.sort(floatf(u => u.dst2(this.x, this.y)));
                var max = Math.min(maxFind, target.size);
                for(var a = 0; a < max; a++){
                    var other = target.get(a);
                    //if(other == null) continue;
                    find = true;
                    se.at(this.x,this.y,range);
                        hitEffect.at(this.x, this.y, 0, lightningColor, other);
                        other.apply(hitStatus, hitStatusD);
                        Damage.damage(this.team,other.x,other.y,8,damage);
                        for(var i = 0; i < hitLightnings&&hitLightning; i++){
                            Lightning.create(this.team, color, hitLightningDamage, other.x, other.y, Mathf.range(hitLightningCone/2)+hitLightningAngle, hitLightningLength);
                        }
                    timer = 0
                }
            }
            if(Mathf.chance(lightningChance)&&hasLightning){
                var a = this.rotation + Mathf.range(hasLightningCone) + hasLightningAngle;
                Lightning.create(this.team, lightningColor, hasLightningDamage, this.x, this.y, a, hasLightningLength);
            }
            }
        },
        drawSelect(){
            this.super$drawSelect();
            Drawf.circles(this.x, this.y, range, color);
        },
        write(write){
            this.super$write(write);
            write.f(curStroke);
        },
        read(read, revision){
            this.super$read(read, revision);
            curStroke = read.f(curStroke);
        }
    },nlt);
});

// 晓伟移植 》禁止删除此注释《