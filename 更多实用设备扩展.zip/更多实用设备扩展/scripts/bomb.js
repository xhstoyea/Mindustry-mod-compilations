const item = require('item');
const Scolor = (r,g,b,a) => {
    return new Color(r,g,b,a)
};
const jhy = Effect(60, cons(e => {
    var col = e.color
    Fill.light(e.x, e.y, 4, e.rotation*e.fout(),45,Color.clear,Scolor(col.r,col.g,col.b,100*e.fin()));
}));
function nearbyTXY (block,rot,amount){
    var nxy = {x:0,y:0};
    switch(rot){
            case 0 :
                nxy.x = 1*amount;
                nxy.y = 0;
            break;
            case 1 :
                nxy.x = 0;
                nxy.y = 1*amount;
            break;
            case 2 :
                nxy.x = -1*amount;
                nxy.y = 0;
            break;
            case 3 :
                nxy.x = 0;
                nxy.y = -1*amount;
            break;
            default : nxy = {x:0,y:0};
        };
    return nxy
};
const hbf = Effect(20, cons(e => {
    Draw.color(e.color);
    Draw.alpha(e.fout());
    Draw.rect(Core.atlas.find("更多实用设备扩展-锎晶炸药-heat"),e.x,e.y,e.rotation);
}));
const hbk = Effect(20, cons(e => {
    Draw.color(e.color);
    Draw.alpha(e.fout());
    Draw.rect(Core.atlas.find("white"),e.x,e.y,e.rotation);
}));
const y = extend(Wall,"锎晶炸药", {
    drawPlace(x,y,rotation,valid){
    this.super$drawPlace(x,y,rotation,valid);
    for (var i = 0;i<4;i++){
    	    for (var l = 1;l<3;l++){
        	var nbX = nearbyTXY(this,i,l).x*8;
        	var nbY = nearbyTXY(this,i,l).y*8;
        	Draw.color(Color.red);
        	Lines.stroke(0.5);
        	Lines.poly(x*Vars.tilesize+nbX, y*Vars.tilesize+nbY, 4, 8*0.7071, 45);
    	    }
    	}
    }
});
y.update = true;
y.rebuildable = false;
y.envEnabled = Env.any;
y.buildType = prov(() => {
    var o = 0;
	const b = extend(Wall.WallBuild, y, {
	updateTile(){
	this.super$updateTile();
	var ttx = this.tileX();
    var tty = this.tileY();
    var tx = this.x;
    var ty = this.y;
	if (this.timer.get(20)){
    	for (var i = 0;i<4;i++){
    	    for (var l = 1;l<3;l++){
        	var nbX = nearbyTXY(this,i,l).x*8;
        	var nbY = nearbyTXY(this,i,l).y*8;
        	var nbTX = nearbyTXY(this,i,l).x;
        	var nbTY = nearbyTXY(this,i,l).y;
        	if (Vars.world.tile(ttx+nbTX, tty+nbTY) != null){
        	hbk.at(tx+nbX, ty+nbY, 1, Tmp.c1.set(Color.red).lerp(Color.red, 0.3));
        	}
            if (o>= 12){
                if (Vars.world.tile(ttx+nbTX, tty+nbTY) != null){
            Vars.world.tile(ttx+nbTX, tty+nbTY).setAir();
            Damage.damage(tx+nbX,ty+nbY,8,10000)
                }
            Effect.shake(5, 240, this);
            this.kill();
                }
    	    }
    	}
    	hbf.at(this.x,this.y,this.rotation,Tmp.c1.set(Color.red).lerp(Color.red, 0.3));
        o += 1;
	};
	},
	drawSelect(){
            this.super$drawSelect();
            for (var i = 0;i<4;i++){
    	    for (var l = 1;l<3;l++){
        	var nbX = nearbyTXY(this,i,l).x*8;
        	var nbY = nearbyTXY(this,i,l).y*8;
        	Draw.color(Color.red);
        	Lines.stroke(0.5);
        	Lines.poly(this.x+nbX, this.y+nbY, 4, 8*0.7071, 45);
    	    }
    	}
        },
	})
	return b
});

const g = extend(Wall,"合聚烯烃钢墙", {});
g.update = true;
g.health = 3240;
g.buildType = prov(() => {
	const b = extend(Wall.WallBuild, g, {
	updateTile(){
	this.super$updateTile();
	Groups.bullet.intersect(this.x-8, this.y-8, 2*8, 2*8, cons(trait =>{
	        if(trait.team != this.team &&trait!=null){
	            trait.absorb();
	            Damage.damage(this.x,this.y,8,trait.type.damage+trait.type.splashDamage/2);
        };
    }));
    Units.nearby(this.x-8,this.y-8,2*8,2*8,cons(other => {
            var overlapDst = (other.hitSize/2 + 2*4) - other.dst(this);
        if(overlapDst > 0){
            if(overlapDst > other.hitSize * 1.5){
            other.kill();
        }else{
            //stop
            other.vel.setZero();
            //get out
            other.move(Tmp.v1.set(other).sub(this).setLength(overlapDst + 0.01));
            if (this.timer.get(60)){
                Damage.damage(other.team,this.x,this.y,8,other.hitSize/8)
            }
            }
        }
    }))
	},
	})
	return b
});

const jhr = 240;
const jhrn = 0.7071;
const jh = extend(StorageBlock,"零点力场", {
    setStats() {
    this.super$setStats();
    this.stats.add(Stat.abilities, Core.bundle.format("ability.jh",90/60,240/8,240/8));
    },
    drawPlace(x,y,rotation,valid){
    this.super$drawPlace(x,y,rotation,valid);
    Draw.color(Color.blue);
    Lines.poly(x*Vars.tilesize, y*Vars.tilesize, 4 , jhr*jhrn, 45);
    }
});
jh.update = true;
jh.consumeItem(item.ld,1);
jh.itemCapacity = 10;
jh.buildType = prov(() => {
    var o = 0;
    var work = false;
    var amout = 2;
	const b = extend(StorageBlock.StorageBuild, jh, {
	drawShield(){
	    Draw.z(Layer.effect);
        Fill.light(this.x, this.y, 4, jhr*jhrn,45,Color.clear,Tmp.c2.set(Scolor(0,0,255,100)));
	},
	draw(){
	    this.super$draw();
	    if (work){
/*        Draw.alpha(1);
        Lines.poly(this.x, this.y, 4, jhr*jhrn, 45);*/
        this.drawShield()
        Draw.z();
        Draw.color(Color.white);
            Draw.rect(Core.atlas.find("更多实用设备扩展-零点力场-light"), this.x, this.y);
        }
        Draw.color();
        Draw.rect(Core.atlas.find("更多实用设备扩展-零点力场-top"), this.x, this.y);
	},
	updateTile(){
	this.super$updateTile();
	if (this.items.get(item.ld) >= 1){
	    work = true
    	if (this.timer.get(90)){
	    jhy.at(this.x,this.y,jhr*jhrn,Color.blue);
	    for (var s = 0;s<jhr/8+ 1;s++){
	    var nsy = s-(jhr/8/2);
	    for (var ss = 0;ss < jhr/8+ 1;ss++){
	        var nsx = ss-(jhr/8/2);
	        var nst = Vars.world.tile(this.tileX() + nsx, this.tileY() + nsy);
            Fires.extinguish(nst,9999);
	};
	};
	    amout += 1;
	};
    	Units.nearbyEnemies(this.team,this.x-jhr/2,this.y-jhr/2,jhr,jhr,cons(other => {
	    other.apply(StatusEffects.freezing, 5);
	}))
	}
	else work = false;
	if (amout == 2) {
	    this.consume();
	    amout = 0;
	};
	//点防力场效果
		/*if (work){
	    Groups.bullet.intersect(this.x - jhr/2, this.y - jhr/2, jhr, jhr, cons(trait =>{
	    if (this.timer.get(10)){
	        if(trait.type.absorbable && trait.team != this.team &&trait!=null){
	            if(trait != null && !trait.isAdded()){
                trait = null;
            };
        if (trait.type.damage>10){
	        trait.type.damage-=10;
        }else{
            jhy.at(trait.x,trait.y,trait.type.hitSize*3*jhrn,Color.blue);
            trait.type.removed(trait);
        };
	    };
        };
    }));
	}*/
	//nnd,做个jb
	},
	drawSelect(){
    this.super$drawSelect();
    Draw.color(Color.blue);
    Lines.poly(this.x, this.y, 4, jhr*jhrn, 45);
        },
	})
	return b
});