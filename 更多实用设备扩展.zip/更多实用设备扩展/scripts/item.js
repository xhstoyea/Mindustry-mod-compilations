const nm = new Item("纳米合金", Color.valueOf("BABABAFF"));
exports.nm = nm;
const power = new Item("能量结晶", Color.valueOf("FFFFC4FF"));
exports.power = power;
const ld = new Item("零点晶体", Color.valueOf("325DE3FF"));
exports.ld = ld;