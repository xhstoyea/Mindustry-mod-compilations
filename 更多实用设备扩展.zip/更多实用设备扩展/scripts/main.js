require('天气发电机');
//require('A');
//require('MultiCrafter');
require('手摇发电机');
require('小型据点核心');
require('block');
require('item');
require('unit');
require('nl');
require('bomb');
require('yuanh');
Vars.mods.locateMod("更多实用设备扩展").meta.description = "（此mod为更多实用设备[EU]扩展) \n 感谢群友？？？、none.、薄荷香草提供的简介以及solsey提供的T3钍反贴图 \n mod主体群：338651136 \n 本mod群：785918006 \n [yellow]关于冲突:[]\n  本mod安分守己，没有更改任何原版内容，[red]不会出现因本mod出现的冲突[]。有？那是你的问题。[red]>>别  来  烦  我<<"