const g = extend(SerpuloPlanetGenerator,{
    getDefaultLoadout(){
        return Schematics.readBase64("蓝图复制到剪贴板的一串")
    }
});
星球.generator = g;