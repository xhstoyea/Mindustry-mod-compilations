const library = require("MultiCrafter");
const 废料加工厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "废料加工厂", [
  {
    input: {
      items: ["scrap/2"],
      power: 0.5,
    },
    output: {
      items: ["copper/1"],
    },
    craftTime: 60,
  }, 
  {
    input: {
      items: ["scrap/2"],
      power: 0.5,
    },
    output: {
      items: ["lead/1"],
    },
    craftTime: 60,
  },
  {
    input: {
      items: ["scrap/3"],
      power: 0.5,
    },
    output: {
      items: ["titanium/1"],
    },
    craftTime: 60,
  },
  {
    input: {
      items: ["scrap/4"],
      power: 0.5,
    },
    output: {
      items: ["thorium/1"],
    },
    craftTime: 60,
  },
  {
    input: {
      items: ["scrap/10"],
      liquids: ["water/3"],
      power: 2,
    },
    output: {
      items: ["copper/4","lead/3","titanium/2"],
    },
    craftTime: 120,
  },
  {
    input: {
      items: ["scrap/12"],
      liquids: ["slag/12"],
      power: 3,
    },
    output: {
      items: ["surge-alloy/1"],
    },
    craftTime: 240,
  },
]);