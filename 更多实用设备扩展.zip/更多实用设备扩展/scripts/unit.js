const mET = (life,color,amout,l,w,cone) => {
    return new Effect(life,cons(e=>{
        for (var i = 0;i<amout;i++){
            var rot = 360/amout*i+Mathf.range(cone/2);
            Draw.color(color);
            Drawf.light(e.x, e.y, l*1.6*e.fout() , color, 0.75*e.fout());
            Drawf.tri(e.x, e.y, w, l*e.fout(), rot);
        }
    }))
};
const snow = mET(60,Color.valueOf("DBE8FFFF"),5,8,2,360);

const dw = extend(UnitType, "单位", {
    draw(b){
    var rad = 50;
    var acol = Color.valueOf("567CFF99");
    var col = Color.valueOf("567CFFFF");

    Draw.z(Layer.effect);
    Fill.light(b.x, b.y, Lines.circleVertices(200), 200 ,Color.clear,Tmp.c2.set(acol));
    Draw.color(col);
    Lines.stroke(1 * 3);
    Lines.circle(b.x, b.y, rad);
    Draw.alpha(0.75);
    Lines.circle(b.x, b.y, rad+50);
    Draw.alpha(1);
    var points = 4;
    var si = Math.sin(Time.time/20);
    for(var i = 0; i < points; i++){
        var angle = i* 360 / points + 45;
        for(var s of Mathf.zeroOne){
            Drawf.tri(b.x + Angles.trnsx(angle, rad), b.y + Angles.trnsy(angle, rad), 6, 100+(100*s*(si+1)), angle + s*180);
            Drawf.tri(b.x + Angles.trnsx(angle+Time.time,rad+100), b.y + Angles.trnsy(angle+Time.time, rad+100), 6, 100 *si, angle+s*180+Time.time + 45);
            Drawf.light(b.x + Angles.trnsx(angle,rad), b.y + Angles.trnsy(angle, rad), 100+(100*s*(si+1)) , col, 1);
            for (var i1 = 0;i1<4;i1++){
        Drawf.tri(b.x + Angles.trnsx(angle+Time.time*2,rad+75*si), b.y + Angles.trnsy(angle+Time.time, rad+75), 6, 100 * si, angle+s*180+Time.time + 45);
        Drawf.tri(b.x + Angles.trnsx(angle-90-Time.time*2,rad+75*si), b.y + Angles.trnsy(angle-90-Time.time, rad+75), 6, 100 * si, angle-90+s*180-Time.time);
        Drawf.light(b.x + Angles.trnsx(angle+Time.time*2,rad+75*si), b.y + Angles.trnsy(angle+Time.time, rad+75), Math.abs(100*si) , col, 1);
        Drawf.light(b.x + Angles.trnsx(angle-90-Time.time*2,rad+75*si), b.y + Angles.trnsy(angle-90-Time.time, rad+75), Math.abs(100*si) , col, 1);
            }
        };
        Drawf.tri(b.x + Angles.trnsx(angle-45,rad+50), b.y + Angles.trnsy(angle-45, rad+50), 6, 100 * 1, angle-45+180);
    };
    for(var ii = 0; ii<2; ii++){
        var angle1 = ii* 360 / 2;
        Drawf.tri(b.x + Angles.trnsx(angle1, rad+50), b.y + Angles.trnsy(angle1, rad+50), 6, 150 * -si, angle1);
        Drawf.light(b.x + Angles.trnsx(angle1, rad+50), b.y + Angles.trnsy(angle1, rad+50), 150 * -si, col, 1);
    };
    Fill.circle(b.x, b.y, 12 * 1);
    Draw.alpha(0.5*1);
    Fill.circle(b.x, b.y, rad);
    Draw.alpha(0.25*1);
    Fill.circle(b.x, b.y, rad+50);
    Draw.color();
    Draw.alpha(1);
    Fill.circle(b.x, b.y, 6 * 1);
    Drawf.light(b.x, b.y, (rad+75) * 1.6 , col, 0.25);
    Drawf.light(b.x, b.y, (rad) * 1.6 , col, 1);
    Drawf.light(b.x, b.y, (rad+50) * 1.6 , col, 0.5);
    },
    update(b){
        const rand = (rRange) => {
            var rxy = {x:0,y:0};
            var rot = Mathf.range(180);
            var rRand = Mathf.range(rRange);
            rxy.x = Angles.trnsx(rot, rRand);
            rxy.y = Angles.trnsy(rot, rRand);
            return rxy
        };
        snow.at(b.x+rand(200).x,b.y+rand(200).y);
    }
});

dw.constructor = prov(() => extend(UnitEntity, {}));
dw.flying = true;
dw.speed = 4;