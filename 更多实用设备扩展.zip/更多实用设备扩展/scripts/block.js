const item = require('item');
const findRegion = (string) => {
    var icon = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find(string));
    return icon
};
const findAtlas = (string) => {
    var icon = Core.atlas.find(string)
    return icon
};
const jhrn = 0.7;
const st = extend(Wall,"石头地板", {});
st.update = true;
st.buildType = prov(() => {
    const b = extend(Wall.WallBuild, st, {
    updateTile(){
        Vars.world.tile(this.tileX(), this.tileY()).setFloor(Blocks.stone);
        Vars.world.tile(this.tileX(), this.tileY()).setAir();
    },
    })
    return b
});
const A = extend(PowerTurret, "小型修复炮塔", {});
A.buildType = prov(() => new JavaAdapter(PowerTurret.PowerTurretBuild, {
    findTarget() {
        var target = Units.findDamagedTile(this.team, this.x, this.y)
        if (target != null && target != this && this.dst(target) <= A.range) {
            this.target = target;
        } else {
            this.super$findTarget();
        }

    },
    validateTarget() {
        return !Units.invalidateTarget(this.target, Team.derelict, this.x, this.y) || this.isControlled() || this.logicControlled();
    },
}, A));

const B = extend(MassDriver, "小型质量驱动器", {});
B.bullet = new MassDriverBolt;
const B1 = extend(MassDriver, "轨道驱动器", {});
B1.bullet = new MassDriverBolt;

const qw = extend(Wall,"气钢墙", {});
qw.buildType = prov(() => {
    const b = extend(Wall.WallBuild, qw, {
    handleDamage(amount){
    if(amount <= 10) {
        Fx.healBlock.at(this.x, this.y, qw.size, Tmp.c1.set(Pal.shield).lerp(Pal.shield, 0.3));
        return amount/(qw.health*0.1);
    };
      return amount - 10;
        },
    })
    return b
});
const lqw = extend(Wall,"大型气钢墙", {});
lqw.buildType = prov(() => {
    const b = extend(Wall.WallBuild, lqw, {
    handleDamage(amount){
    if(amount <= 40) {
        Fx.healBlock.at(this.x, this.y, lqw.size, Tmp.c1.set(Pal.shield).lerp(Pal.shield, 0.3));
        return 4*amount/(lqw.health*0.1);
    };
      return amount - 40;
        },
    })
    return b
});

const xf = extend(MendProjector, '修复发生器', {});
xf.buildType = prov(() => {
    return new JavaAdapter(MendProjector.MendBuild, {
        updateTile(){
            var canHeal = !this.checkSuppression();
            this.smoothEfficiency = Mathf.lerpDelta(this.smoothEfficiency, this.efficiency, 0.08);
            this.heat = Mathf.lerpDelta(this.heat, ((this.efficiency > 0 && canHeal) ? 1 : 0), 0.08);
            this.charge += this.heat * this.delta();
            this.phaseHeat = Mathf.lerpDelta(this.phaseHeat, this.optionalEfficiency, 0.1);
            if(this.optionalEfficiency > 0 && this.timer.get(this.block.useTime) && canHeal){
                this.consume();
            }
            if(this.charge >= this.block.reload && canHeal){
                var realRange = this.range() + this.phaseHeat * this.block.phaseRangeBoost;
                this.charge = 0;
                var healed = false;
                Vars.indexer.eachBlock(this, realRange, b => b.damaged() && !b.isHealSuppressed(), other => {
                    other.heal(other.maxHealth * (this.block.healPercent + this.phaseHeat * this.block.phaseBoost) / 100 * this.efficiency);
                    other.recentlyHealed();
                    Fx.healBlockFull.at(other.x, other.y, other.block.size, this.block.baseColor, other.block);
                });
                Units.nearby(this.team, this.x, this.y, realRange*1.4, cons(other => {
                    if(other.damaged()){
                        Fx.heal.at(other);
                        healed = true;
                    };
                    var hm = other.maxHealth;
                    other.heal(Math.max(hm/100,100));
                }));
                Fx.healWaveDynamic.at(this.x, this.y, realRange*(healed?1.4:1));
            }
        },
        drawSelect(){
            this.super$drawSelect();
            Drawf.circles(this.x, this.y, this.range()*1.4, Pal.heal);
        },
    }, xf);
});

const yszy = extend(Wall,"压缩能量炸药", {});
yszy.update = yszy.configurable = true;
yszy.buildType = prov(() => {
    const r = 40;
    const b = extend(Wall.WallBuild, yszy, {
    updateTile(){
    this.super$updateTile();
    Units.nearbyEnemies(this.team, this.x, this.y, r*2, r*2, cons(evu => {
    if(evu != null && evu.within(this.x, this.y, r)){
        this.kill();
        }
    }));
    },
    buildConfiguration(table){
        table.button(Icon.upOpen, Styles.defaulti, run(() => {
        this.kill();
        })).size(45);
    },
    })
    return b
});
yszy.envEnabled = Env.any;

const zpt = new Effect(30, cons(e => {
    Draw.color(Items.surgeAlloy.color);
for (var i = 0 ; i < 2 ; i++){
    Drawf.tri(e.x, e.y, 10 * e.fout(), 80 - i*30, e.rotation + i*180 + 180);
    Drawf.light(e.x, e.y, 180, Pal.bulletYellowBack, 0.9 * e.fout());
        }}));

const zph = new Effect(30, cons(e => {
    Draw.color(Items.surgeAlloy.color);
    for (var i = 0 ; i < 4 ; i++){
        Drawf.tri(e.x, e.y, 100 + e.fin()*80, 10 * e.fout() , e.rotation + i*90 + 45);
        };
    e.scaled(20, cons(b => {
        Draw.color(Items.surgeAlloy.color);
        Lines.stroke(e.fout() * 2 + 1);
        Lines.circle(e.x, e.y, b.fin() * 40 + 20);
    Drawf.light(e.x, e.y, 180, Pal.bulletYellowBack, 0.9 * e.fout());
        }));
    }));

const zps = new Effect(30, cons(e => {
    Draw.color(Items.surgeAlloy.color);
    for (var i = 0 ; i < 2 ; i++){
        Drawf.tri(e.x, e.y, 13 * e.fout(), 120, e.rotation + 180 * i + 90);
        }
    Draw.color(Items.surgeAlloy.color);
    Drawf.tri(e.x, e.y, 13 * e.fout(), 80, e.rotation + 20);
    Draw.color(Items.surgeAlloy.color);
    Drawf.tri(e.x, e.y, 13 * e.fout(), 80, e.rotation - 20);
    e.scaled(120, cons(b => {
        Draw.color(Items.surgeAlloy.color);
        Lines.stroke(e.fout() * 2 + 1);
        Lines.circle(e.x, e.y, 20);
        }));
    Drawf.light(e.x, e.y, 180, Pal.bulletYellowBack, 0.9 * e.fout());
    }));
    
const zpt1 = new Effect(30, cons(e => {
    Draw.color(item.nm.color);
for (var i = 0 ; i < 2 ; i++){
    Drawf.tri(e.x, e.y, 10 * e.fout(), 80 - i*30, e.rotation + i*180 + 180);
    Drawf.light(e.x, e.y, 180, Pal.bulletYellowBack, 0.9 * e.fout());
        }}));

const zph1 = new Effect(30, cons(e => {
    Draw.color(item.nm.color);
    for (var i = 0 ; i < 4 ; i++){
        Drawf.tri(e.x, e.y, 100 + e.fin()*80, 10 * e.fout() , e.rotation + i*90 + 45);
        };
    e.scaled(20, cons(b => {
        Draw.color(item.nm.color);
        Lines.stroke(e.fout() * 2 + 1);
        Lines.circle(e.x, e.y, b.fin() * 40 + 20);
        }));
    Drawf.light(e.x, e.y, 180, Pal.bulletYellowBack, 0.9 * e.fout());
    }));

const zps1 = new Effect(30, cons(e => {
    Draw.color(item.nm.color);
    for (var i = 0 ; i < 2 ; i++){
        Drawf.tri(e.x, e.y, 13 * e.fout(), 120, e.rotation + 180 * i + 90);
        }
    Draw.color(item.nm.color);
    Drawf.tri(e.x, e.y, 13 * e.fout(), 80, e.rotation + 20);
    Draw.color(item.nm.color);
    Drawf.tri(e.x, e.y, 13 * e.fout(), 80, e.rotation - 20);
    e.scaled(120, cons(b => {
        Draw.color(item.nm.color);
        Lines.stroke(e.fout() * 2 + 1);
        Lines.circle(e.x, e.y, 20);
        }));
    Drawf.light(e.x, e.y, 180, Pal.bulletYellowBack, 0.9 * e.fout());
    }));

const zp = extend(PointBulletType, {});
zp.speed = 1200;
zp.damage = 18200;
zp.trailSpacing = 50;
zp.splashDamage = 620;
zp.splashDamageRadius = 80;
zp.hitShake = 10;
zp.buildingDamageMultiplier = 0.5;
zp.trailEffect = zpt;
zp.hitEffect = zph;
zp.despawnEffect = Fx.none;
zp.shootEffect = zps;
zp.ammoMultiplier = 1;
zp.lightning = 5;
zp.lightningLength = 10;
zp.lightningDamage = 450;

const zp1 = extend(PointBulletType, {});
zp1.speed = 1500;
zp1.damage = 52000;
zp1.trailSpacing = 50;
zp1.splashDamage = 1520;
zp1.splashDamageRadius = 80;
zp1.hitShake = 10;
zp1.buildingDamageMultiplier = 0.5;
zp1.trailEffect = zpt1;
zp1.hitEffect = zph1;
zp1.despawnEffect = Fx.none;
zp1.shootEffect = zps1;
zp1.ammoMultiplier = 1;
zp1.healPercent = 50;
zp1.maxRange = 300;

const zz = extend(ItemTurret,"灾征", {});
zz.ammo(
    Items.surgeAlloy,zp,
    item.nm,zp1
    )
zz.maxAmmo = 120;
zz.shootCone = 2;
zz.shootSound = Sounds.railgun;
zz.coolantMultiplier = 0.4;
zz.health = 3750;
zz.coolantUsage = 2;
zz.consumePower(32);

const core = extend(CoreBlock,"超代核心", {});
core.configurable = true;
core.buildType = prov(() => {
    var nix = 0;
    var niy = 0;
    var nit = null;
    var en = false;
    var ten = false;
    var un = null;
    var recoil = 0;
    var ang = 0;
    var rot = 0;
    var amout = 0;
    var amout1 = 0;
    var recoilOffset = new Vec2();
    var recoilA = 6;
    const b = extend(CoreBlock.CoreBuild, core, {
        updateTile(){
            this.T();
            this.super$updateTile();
            var cores = Vars.state.teams.cores(this.team).size;
                if (this.timer.get(30)){
            this.team.core().items.set(Items.copper, this.items.get(Items.copper) + cores + 2);
            this.team.core().items.set(Items.lead, this.items.get(Items.lead) + cores);
            if (this.items.get(item.ld)>=1&&en){
                for (var i = 0;i<10;i++){
                niy = i-(8/2);
                    for (var l = 0;l < 10;l++){
                    nix = l-(8/2);
                    nit = Vars.world.tile(this.tileX() + nix, this.tileY() + niy);
                    Fires.extinguish(nit,9999);
                    if (amout>=10) {
                        this.team.core().items.set(item.ld, this.items.get(item.ld)-1);
                        amout = 0;
                    }
                };
            };
                amout += 1;
            }
        };
        },
        draw(){
            this.super$draw();
            if (this.items.get(item.ld)>=1&&en){
                Draw.z(Layer.shields);
                Draw.color(Color.blue);
                Fill.poly(this.x, this.y, 4, 10*8*jhrn, 45);
            };
            this.drawTurret();
        },
        drawTurret(){
            Draw.reset();
            Draw.color();
            Draw.z(Layer.turret - 0.02);
            Drawf.shadow(findAtlas("lancer"), this.x + recoilOffset.x - 1, this.y + recoilOffset.y - 1, this.drawrotit());
            Draw.z(Layer.turret + 0.02);
            Draw.color(Pal.turretHeat);
            Draw.alpha(recoil/6);
            Draw.rect(findAtlas("lancer-heat"), this.x + recoilOffset.x, this.y + recoilOffset.y, this.drawrotit())
            Draw.z(Layer.turret);
            Draw.alpha(1);
            Draw.color();
            Draw.rect(findAtlas("lancer"), this.x + recoilOffset.x, this.y + recoilOffset.y, this.drawrotit())
        },
        buildConfiguration(table) {
        this.super$buildConfiguration(table);
        table.table(Tex.button, Cons(table => {
        table.check("", en, b => {
            en = b;
        }).size(45);
        table.check("", ten, b => {
            ten = b;
        }).size(45);
        })).size(95,55);
    },
        T(){
            un = Units.closestTarget(this.team,this.x,this.y,360);
            const bullet = new LaserBulletType(240);
            bullet.length=360;
            recoil = Mathf.lerpDelta(recoil, 0, 0.5);
            recoilOffset.trns(rot, -recoil);
            var shootY = 2 * Vars.tilesize / 2;
            if (un!=null&&this.items.get(item.power)>=1) {
                ang = Angles.angle(this.x,this.y,un.x,un.y);
                rot = Mathf.lerpDelta(rot,ang,0.1);
            };
            if (amout1>=12) {
                        this.team.core().items.set(item.power, this.items.get(item.power)-1);
                        amout1 = 0;
            };
            if (un!=null&&this.timer.get(10)&&ten&&this.items.get(item.power)>=1){
                recoil = recoilA;
                bullet.create(this,this.team,this.x+Angles.trnsx(rot, shootY),this.y+Angles.trnsy(rot, shootY),rot,1,1);
                bullet.shootEffect.at(this.x+Angles.trnsx(rot, shootY),this.y+Angles.trnsy(rot, shootY),rot);
                bullet.smokeEffect.at(this.x+Angles.trnsx(rot, shootY),this.y+Angles.trnsy(rot, shootY),rot);
                amout1+=1;
            };
        },
        drawrotit(){
            return rot-90
        },
        onDestroyed(){
            this.super$onDestroyed();
            Sounds.explosionbig.at(this.x,this.y);
            Effect.shake(6, 16, this.x, this.y);
            Damage.damage(this.x, this.y, 34 * Vars.tilesize, 1250 * 16);
            Fx.impactReactorExplosion.at(this.x, this.y);
        },
        write(write) {
            this.super$write(write);
            write.bool(en);
            write.bool(ten);
            write.f(amout);
            write.f(amout1);
        },
        read(read, revision) {
            this.super$read(read, revision);
            en = read.bool();
            ten = read.bool();
            amout = read.f();
            amout1 = read.f();
        },
    })
    return b
});