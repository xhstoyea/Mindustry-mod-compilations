const library = require("base/library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "furnace", [
	{
		input: {
			items: [ "magic-craft-tungsten-m/2", "magic-craft-iron/2", "magic-craft-manganese/1", "magic-craft-cobalt/1" ],
			power: 4.5,
		},
		output: {
			items: [ "magic-craft-tungstensteel/2" ],
		},
		craftTime: 60,
	},
]);
