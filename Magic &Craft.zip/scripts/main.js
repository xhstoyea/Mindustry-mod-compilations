MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000
require('crafting/furnace');