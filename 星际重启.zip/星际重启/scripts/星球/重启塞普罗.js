onst SFlib = require("base/SFlib");
const 重启塞普罗 = new Planet("重启塞普罗", Planets.sun, 1, 3.3);
重启塞普罗.meshLoader = prov(() => new MultiMesh(
	new HexMesh(重启塞普罗, 8)
));
重启塞普罗.generator = extend(SerpuloPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nA3JMQ6AIBAAwQXFRr9i4XuMBR5XkCAYkP9LphwcbmLO/lHMwRq0SY3vF0sGluRvTQ17XoZNStU9d0na20gDduAHAc0Org==")
	}
});
重启塞普罗.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(重启塞普罗, 2, 0.15, 0.14, 5, Color.valueOf("AC4DC420"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(重启塞普罗, 3, 0.6, 0.15, 5, Color.valueOf("AC4DC4FF"), 2, 0.42, 1.2, 0.45)
));
重启塞普罗.generator = new SerpuloPlanetGenerator();
重启塞普罗.visible = 重启赛普罗.accessible = 重启赛普罗.alwaysUnlocked = true;
重启塞普罗.allowLaunchToNumbered = false
重启塞普罗.clearSectorOnLose = false;
重启塞普罗.tidalLock = false;
重启塞普罗.localizedName = "重启塞普罗";
重启塞普罗.prebuildBase = false;
重启塞普罗.bloom = false;
重启塞普罗.startSector = 1;
重启塞普罗.orbitRadius = 85;
重启塞普罗.clearSectorOnLose = true;
重启塞普罗.enemyCoreSpawnReplace = true;
重启塞普罗.orbitTime = 180 * 60;
重启塞普罗.rotateTime = 90 * 60;
重启塞普罗.atmosphereRadIn = 0.02;
重启塞普罗.atmosphereRadOut = 0.3;
重启塞普罗.atmosphereColor = 重启塞普罗.lightColor = Color.valueOf("AC4DC480");
重启塞普罗.iconColor = Color.valueOf("AC4DC4"),
重启塞普罗.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);

const [1]重启零号地区 = new SectorPreset("[1]重启零号地区", 重启赛普罗, 1);
[1]重启零号地区.description = "[gray]踏上旅程的最佳位置
这里的敌人威胁很小，但资源也少。
尽你所能收集[accent]铅和铜，[gray]出发吧！
0号地区坏消息，由于我们穿越回来这里似乎有些变化。"
[1]重启零号地区.difficulty = 2;
[1]重启零号地区.alwaysUnlocked = false;
[1] 重启零号地区.addStartingItems = true;
[1]重启零号地区.captureWave = 40;
[1]重启零号地区.localizedName = "[1]重启零号地区";
exports.[1]重启零号地区 = 重启零号地区;
SFlib.addToResearch([1]重启零号地区, {
	parent: "planetaryTerminal",
	objectives: Seq.with(
	new Objectives.SectorComplete(SectorPresets.planetaryTerminal))
});

const [2]重启冰冻山脉 = new SectorPreset("[2]重启冰冻山脉", 重启赛普罗, 86);
[2]重启冰冻山脉.description = "[accent][2]冰冻山脉
在通过了[1]零号地区的车印我们来到冰冻山脉根据遗留的信息这里有个堡垒做好准备"
[2]重启冰冻山脉.difficulty = 2;
[2]重启冰冻山脉.alwaysUnlocked = false;
[2]重启冰冻山脉.addStartingItems = true;
[2]重启冰冻山脉.captureWave = 55;
[2]重启冰冻山脉.localizedName = "重启冰冻山脉";
exports.[2]重启冰冻山脉 = [2]重启冰冻山脉;
SFlib.addToResearch([2]重启冰冻山脉, {
	parent: "[1]重启零号地区",
	objectives: Seq.with(
	new Objectives.SectorComplete([1]重启零号地区))
})