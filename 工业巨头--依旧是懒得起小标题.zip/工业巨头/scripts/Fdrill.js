const Fitem = require("Fcrafter")
const F = require("library/func");

const autoSmeltDrill = new Drill("autoSmeltDrill")
const {copper,lead,titanium,thorium} = Items
const {oreCopper,oreLead,oreTitanium,oreThorium,buildModel,smeltModel,buildModelLV2,buildModelLV3,smeltModelLV2,smeltModelLV3,smeltModelCrafter} = Fitem
autoSmeltDrill.buildType = prov(() => {
	return extend(Drill.DrillBuild, autoSmeltDrill, {
		smelt:false,
		updateTile() {
		
			this.smeltItem(oreCopper,copper)
            this.smeltItem(oreLead,lead)
        
        	this.smeltItem(copper,lead)
        	this.smeltItem(lead,copper)
            if(this.smelt){
				this.timeScale *= 0.6
				this.smelt = false
			}
			this.super$updateTile();
		},
		smeltItem(item,aimItem){
			if(this.dominantItem==item&&!this.smelt){
				this.dominantItem=aimItem;
            	this.smelt = true
            }
		}
	})
});

Object.assign(autoSmeltDrill,{
	tier : 2,
	size :2,
	drillTime : 450,
	canOverdrive : false,
	requirements : ItemStack.with(
		buildModel,20,
		smeltModel,1
	),
	category : Category.production,
	buildVisibility : BuildVisibility.shown
})
autoSmeltDrill.consumePower(0.8)
autoSmeltDrill.consumeLiquid(Liquids.water, 0.08).boost()

const slateAutoSmeltDrill = new Drill("slateAutoSmeltDrill");
slateAutoSmeltDrill.buildType = prov(() => {
	return extend(Drill.DrillBuild, slateAutoSmeltDrill, {
		smelt:false,
		updateTile() {
			this.smeltItem(oreCopper,copper)
            this.smeltItem(oreLead,lead)
            this.smeltItem(oreTitanium,titanium)
            if(this.smelt){
				this.timeScale *= 0.7
				this.smelt = false
			}
			this.super$updateTile();
		},
		smeltItem(item,aimItem){
			if(this.dominantItem==item){
				this.dominantItem=aimItem;
            	this.smelt = true
            }
		}
	})
});

Object.assign(slateAutoSmeltDrill,{
	tier : 3,
	size : 3,
	drillTime : 320,
	canOverdrive : false,
	requirements : ItemStack.with(
		buildModelLV2,40,
		smeltModelLV2,1
	),
	category : Category.production,
	buildVisibility : BuildVisibility.shown
})

slateAutoSmeltDrill.consumePower(1.3)
slateAutoSmeltDrill.consumeLiquid(Liquids.water, 0.12).boost()

const carsoAutoSmeltDrill = new Drill("carsoAutoSmeltDrill");
carsoAutoSmeltDrill.buildType = prov(() => {
	return extend(Drill.DrillBuild, carsoAutoSmeltDrill, {
		smelt:false,
		updateTile() {
			this.smeltItem(oreCopper,copper)
            this.smeltItem(oreLead,lead)
            this.smeltItem(oreTitanium,titanium)
            this.smeltItem(oreThorium,thorium)
            if(this.smelt){
				this.timeScale *= 0.8
				this.smelt = false
			}
			this.super$updateTile();
		},
		smeltItem(item,aimItem){
			if(this.dominantItem==item){
				this.dominantItem=aimItem;
            	this.smelt = true
            }
		}
	})
});

Object.assign(carsoAutoSmeltDrill,{
	tier : 4,
	size : 4,
	drillTime : 325,
	canOverdrive : false,
	updateEffect:Fx.pulverizeRed,
	drillEffect:Fx.mineHuge,
	drawRim:true,
	requirements : ItemStack.with(
		buildModelLV3,90,
		smeltModelLV3,1
	),
	category : Category.production,
	buildVisibility : BuildVisibility.shown
})
carsoAutoSmeltDrill.consumePower(2)
carsoAutoSmeltDrill.consumeLiquid(Liquids.water, 0.3).boost()

F.techNode(smeltModelCrafter, autoSmeltDrill, ItemStack.with(
	buildModel,(20*5),
	smeltModel,(1*5)
));

F.techNode(autoSmeltDrill, slateAutoSmeltDrill,ItemStack.with(
	buildModelLV2,(40*5),
	smeltModelLV2,(1*5)
));

F.techNode(slateAutoSmeltDrill, carsoAutoSmeltDrill, ItemStack.with(
	buildModelLV3,(90*5),
	smeltModelLV3,(1*5)
));

function changeDrill(block,timeS){
	block.buildType = prov(() => new JavaAdapter(Drill.DrillBuild, {
		smelt : false,
		updateTile(){
			this.super$updateTile()
			if(this.smelt||this.team.id!=2) return
			this.smeltItem(oreCopper,copper)
			this.smeltItem(oreLead,lead)
			this.smeltItem(oreTitanium,titanium)
			this.smeltItem(oreThorium,thorium)
		},
		smeltItem(item,aimItem){
			if(this.dominantItem==item&&!this.smelt){
					this.dominantItem=aimItem;
	            	this.smelt = true;
	            	this.timeScale *= timeS
	        }
		}
	}, block))
}

changeDrill(Blocks.blastDrill,0.8)
changeDrill(Blocks.laserDrill,0.7)
changeDrill(Blocks.pneumaticDrill,0.6)
changeDrill(Blocks.mechanicalDrill,0.6)