//xvxshenhun@qq.com，使用标注来源（禁止删除注释）
//该js由squirrel&yaddrx2共同修改适应140，但是讨论后决定直接注释(枕头说她不想醒干的)
/*var leftFrag = (fragConfig) => {
    const iconWidth = 46;
    const padding = 4;
    const MARGIN_RIGHT = 314;

    var currentCategory = 0;
    var menuHoverBlock;
    var selectedBlocks = new ObjectMap();
    var scrollPositions = new ObjectFloatMap();
    var blockTable;
    var blockPane;
    var toggler;

    var hide = true;
    
    var IconA = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('工业巨头-on', Core.atlas.find("clear")));
    var IconB = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('工业巨头-off', Core.atlas.find("clear")));

    var fragment;
    function containsContent(content) {
        var found = false;
        var cs = fragConfig.categories;
        loop: for (var i = 0; i < cs.length; i++) {
            var category = cs[i];
            for (var j = 0; j < category.blocks.length; j++) {
                var block = category.blocks[j];
                if (content == block) {
                    found = true;
                    break loop;
                }
            }
        }

        return found;
    }
    function rebuild() {
        if (fragment) {
            currentCategory = 0;
            var index = toggler.getZIndex();
            var group = toggler.parent;
            toggler.remove();
            fragment.build(group);
            toggler.setZIndex(index);
        }
    }
    Events.on(WorldLoadEvent, cons(event => {
        Core.app.post(run(() => {
            rebuild();
        }));
    }));
    Events.on(UnlockEvent, cons(event => {
        if (containsContent(event.content)) {
            rebuild();
        }
    }));

    function unlocked(block) {
        return block.unlockedNow();
    }
    function getSelectedBlock(cat) {
        return selectedBlocks.get(cat, prov(() => {
            var category = fragConfig.categories[cat]
            return category.blocks.find(v => unlocked(v));
        }));
    }
    fragment = new JavaAdapter(FadeInFragment, {
        build(parent) {
            parent.fill(cons(full => {
                toggler = full;
                full.bottom().right().visibility = boolp(() => Vars.ui.hudfrag.shown);
                if (hide) {
                    full.button(IconA, run(() => {
                        hide = false;
                        rebuild();
                    })).width(25).height(50);
                } else {
                    full.button(IconB, run(() => {
                        hide = true;
                        rebuild();
                    })).width(50).height(250).bottom();
                    full.table(cons(frame => {

                        var rebuildCategory = run(() => {

                            blockTable.clear();
                            blockTable.top().margin(5);

                            var index = 0;
                            var group = new ButtonGroup();
                            group.setMinCheckCount(0);

                            var category = fragConfig.categories[currentCategory || 0];
                            for (var j = 0; j < category.blocks.length; j++) {
                                var block = ((sss) => category.blocks[sss])(j);
                                if (!unlocked(block)) { continue; }
                                if (index++ % fragConfig.columns == 0) {
                                    blockTable.row();
                                }

                                var button = ((block) =>
                                    blockTable.button(new TextureRegionDrawable(block.uiIcon), Styles.selecti, run(() => {
                                        if (unlocked(block)) {
                                            if (Core.input.keyDown(Packages.arc.input.KeyCode.shiftLeft) && Fonts.getUnicode(block.name) != 0) {
                                                Core.app.setClipboardText(Fonts.getUnicode(block.name) + "");
                                                Vars.ui.showInfoFade("@copied");
                                            } else {
                                                Vars.control.input.block = Vars.control.input.block == block ? null : block;
                                                selectedBlocks.put(currentCategory, Vars.control.input.block);
                                                hide = false;
                                                rebuild();
                                            }
                                        }
                                    })).size(iconWidth).group(group).name("block-" + block.name).get()
                                )(block);
                                button.resizeImage(32);

                                button.update(((block, button) => run(() => {
                                    var core = Vars.player.core();
                                    var color = (Vars.state.rules.infiniteResources
                                        || (core != null && (core.items.has(block.requirements, Vars.state.rules.buildCostMultiplier) || Vars.state.rules.infiniteResources)))
                                        && Vars.player.isBuilder() ? Color.white : Color.gray;

                                    button.forEach(cons(elem => { elem.setColor(color); }));
                                    button.setChecked(Vars.control.input.block == block);

                                    if (!block.isPlaceable()) {
                                        button.forEach(cons(elem => elem.setColor(Color.darkGray)));
                                    }

                                    button.hovered(run(() => menuHoverBlock = block));
                                    button.exited(run(() => {
                                        if (menuHoverBlock == block) {
                                            menuHoverBlock = null;
                                        }
                                    }));
                                }))(block, button));
                            }

                            if (index < fragConfig.columns) {
                                for (var k = 0; k < fragConfig.columns - index; k++) {
                                    blockTable.add().size(iconWidth);
                                }
                            }
                            blockTable.act(0);
                            blockPane.setScrollYForce(scrollPositions.get(currentCategory, 0));
                            Core.app.post(() => {
                                blockPane.setScrollYForce(scrollPositions.get(currentCategory, 0));
                                blockPane.act(0);
                                blockPane.layout();
                            });

                        });

                        frame.image().color(Pal.gray).colspan(fragConfig.columns).height(padding).growX();
                        frame.row();
                        frame.table(Tex.pane2, cons(blocksSelect => {
                            blocksSelect.margin(padding).marginTop(0);
                            blockPane = blocksSelect.pane(cons(blocks => blockTable = blocks)).height(iconWidth * fragConfig.rows + padding)
                                .update(cons(pane => {
                                    if (pane.hasScroll()) {
                                        var result = Core.scene.hit(Core.input.mouseX(), Core.input.mouseY(), true);
                                        if (result == null || !result.isDescendantOf(pane)) {
                                            Core.scene.setScrollFocus(null);
                                        }
                                    }
                                })).grow().get();
                            blockPane.setStyle(Styles.smallPane);
                            blocksSelect.row();
                            blocksSelect.table(cons(table => {

                                table.image().color(Pal.gray).height(padding).colspan(fragConfig.columns).growX();
                                table.row();
                                table.left().margin(0).defaults().size(iconWidth).left();

                                var group = new ButtonGroup();
                                var index = 0;
                                var cs = fragConfig.categories;
                                for (var i = 0; i < cs.length; i++) {
                                    if (index++ % fragConfig.columns == 0) {
                                        table.row();
                                    }
                                    var category = cs[i];
                                    (cc => {
                                        table.button(category.icon(), Styles.clearNoneTogglei, run(() => {
                                            currentCategory = cc;
                                            if (Vars.control.input.block != null) {
                                                Vars.control.input.block = getSelectedBlock(currentCategory);
                                            }
                                            rebuildCategory.run();
                                        })).group(group).update(cons(v => v.setChecked(currentCategory == v))).name("category-" + cc);
                                    })(i);
                                }
                                if (index < fragConfig.columns) {
                                    for (var k = 0; k < fragConfig.columns - index; k++) {
                                        table.add().size(iconWidth);
                                    }
                                }
                            })).name("inputTable").growX();
                        })).fillY().bottom().touchable(Touchable.enabled);

                        rebuildCategory.run();
                    }));
                }
            }));
        },
    });

    return fragment;
};

Events.on(ClientLoadEvent, cons((e) => {
	
	const buildModelCrafter = Vars.content.block("工业巨头-buildModelCrafter");
	const buildModelUpgrader = Vars.content.block("工业巨头-buildModelUpgrader");
	const buildModelUpgraderLV2 = Vars.content.block("工业巨头-buildModelUpgraderLV2");
	const buildModelUpgraderLV3 = Vars.content.block("工业巨头-buildModelUpgraderLV3");
	const buildModelUpgraderLV4 = Vars.content.block("工业巨头-buildModelUpgraderLV4");
	const copperGearCrafter = Vars.content.block("工业巨头-copperGearCrafter");
	const strongGearCrafter = Vars.content.block("工业巨头-strongGearCrafter");
	const liquidModelCrafter = Vars.content.block("工业巨头-liquidModelCrafter");
	const liquidModelUpgrader = Vars.content.block("工业巨头-liquidModelUpgrader");
	const liquidModelUpgraderLV2 = Vars.content.block("工业巨头-liquidModelUpgraderLV2");
	const craftModelCrafter = Vars.content.block("工业巨头-craftModelCrafter");
	const craftModelUpgrader = Vars.content.block("工业巨头-craftModelUpgrader");
	const craftModelUpgraderLV2 = Vars.content.block("工业巨头-craftModelUpgraderLV2");
	const mineModelCrafter = Vars.content.block("工业巨头-mineModelCrafter");
	const mineModelUpgrader = Vars.content.block("工业巨头-mineModelUpgrader");
	const mineModelUpgraderLV2 = Vars.content.block("工业巨头-mineModelUpgraderLV2");
	const shootModelCrafter = Vars.content.block("工业巨头-shootModelCrafter");
	const shootModelUpgrader = Vars.content.block("工业巨头-shootModelUpgrader");
	const shootModelUpgraderLV2 = Vars.content.block("工业巨头-shootModelUpgraderLV2");
	const shootModelUpgraderLV3 = Vars.content.block("工业巨头-shootModelUpgraderLV3");
	const attackModelCrafter = Vars.content.block("工业巨头-attackModelCrafter");
	const attackModelUpgrader = Vars.content.block("工业巨头-attackModelUpgrader");
	const attackModelUpgraderLV2 = Vars.content.block("工业巨头-attackModelUpgraderLV2");
	const attackModelUpgraderLV3 = Vars.content.block("工业巨头-attackModelUpgraderLV3");
	const attackModelUpgraderLV4 = Vars.content.block("工业巨头-attackModelUpgraderLV4");
	const laserModelCrafter = Vars.content.block("工业巨头-laserModelCrafter");
	const laserModelUpgrader = Vars.content.block("工业巨头-laserModelUpgrader");
	const effectModelCrafter = Vars.content.block("工业巨头-effectModelCrafter");
	const effectModelUpgrader = Vars.content.block("工业巨头-effectModelUpgrader");
	const effectModelUpgraderLV2 = Vars.content.block("工业巨头-effectModelUpgraderLV2");
	const effectModelUpgraderLV3 = Vars.content.block("工业巨头-effectModelUpgraderLV3");
	const effectModelUpgraderLV4 = Vars.content.block("工业巨头-effectModelUpgraderLV4");
	const displayModelCrafter = Vars.content.block("工业巨头-displayModelCrafter");
	const displayModelUpgrader = Vars.content.block("工业巨头-displayModelUpgrader");
	const energyModelCrafter = Vars.content.block("工业巨头-energyModelCrafter");
	const energyModelUpgrader = Vars.content.block("工业巨头-energyModelUpgrader");
	const energyModelUpgraderLV2 = Vars.content.block("工业巨头-energyModelUpgraderLV2");
	const energyModelUpgraderLV3 = Vars.content.block("工业巨头-energyModelUpgraderLV3");
	const copperWireCrafter = Vars.content.block("工业巨头-copperWireCrafter");
	const repairKitCrafter = Vars.content.block("工业巨头-repairKitCrafter");
	const repairKitUpgrader = Vars.content.block("工业巨头-repairKitUpgrader");
	const repairKitUpgraderLV2 = Vars.content.block("工业巨头-repairKitUpgraderLV2");
	const overdriveKitCrafter = Vars.content.block("工业巨头-overdriveKitCrafter");
	const overdriveKitUpgrader = Vars.content.block("工业巨头-overdriveKitUpgrader");
	const overdriveKitUpgraderLV2 = Vars.content.block("工业巨头-overdriveKitUpgraderLV2");
	const siliconWaferCrafter = Vars.content.block("工业巨头-siliconWaferCrafter");
	const siliconBoardCrafter = Vars.content.block("工业巨头-siliconBoardCrafter");
	
	const specialTrafficKitTypeACrafter = Vars.content.block("工业巨头-specialTrafficKitTypeACrafter");
	const specialTrafficKitTypeBCrafter = Vars.content.block("工业巨头-specialTrafficKitTypeBCrafter");
	const specialPlateCrafter = Vars.content.block("工业巨头-specialPlateCrafter");
	const acceleratorCrafter = Vars.content.block("工业巨头-acceleratorCrafter");
	
    var myIcon1 = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('工业巨头-number1', Core.atlas.find("clear")));
    var myIcon2 = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('工业巨头-number2', Core.atlas.find("clear")));
    var myIcon3 = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('工业巨头-number3', Core.atlas.find("clear")));
    var myIcon4 = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('工业巨头-number4', Core.atlas.find("clear")));
    var myIcon5 = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('工业巨头-number5', Core.atlas.find("clear")));
    
    var frag = leftFrag({
        rows: 4,
        columns: 7,
        categories: [
            { icon: () => myIcon1, blocks: [
				buildModelCrafter,
				copperGearCrafter,
				liquidModelCrafter,
				craftModelCrafter,
				mineModelCrafter,
				shootModelCrafter,
				attackModelCrafter,
				laserModelCrafter,
				effectModelCrafter,
				displayModelCrafter,
				energyModelCrafter,
				copperWireCrafter,
				repairKitCrafter,
				overdriveKitCrafter,
				siliconBoardCrafter,
				siliconWaferCrafter
			]},
			
			{ icon: () => myIcon2, blocks: [
				repairKitUpgrader,
				overdriveKitUpgrader,
				strongGearCrafter,
				buildModelUpgrader,
				liquidModelUpgrader,
				craftModelUpgrader,
				mineModelUpgrader,
				shootModelUpgrader,
				attackModelUpgrader,
				laserModelUpgrader,
				effectModelUpgrader,
				displayModelUpgrader,
				energyModelUpgrader,
				acceleratorCrafter
			]},
			
			{ icon: () => myIcon3, blocks: [
				repairKitUpgraderLV2,
				overdriveKitUpgraderLV2,
				buildModelUpgraderLV2,
				liquidModelUpgraderLV2,
				craftModelUpgraderLV2,
				mineModelUpgraderLV2,
				shootModelUpgraderLV2,
				attackModelUpgraderLV2,
				effectModelUpgraderLV2,
				energyModelUpgraderLV2,
				specialPlateCrafter
			]},
			
			{ icon: () => myIcon4, blocks: [
				buildModelUpgraderLV3,
				shootModelUpgraderLV3,
				attackModelUpgraderLV3,
				effectModelUpgraderLV3,
				energyModelUpgraderLV3,
				specialTrafficKitTypeACrafter,
				specialTrafficKitTypeBCrafter
			]},
			
			{ icon: () => myIcon5, blocks: [
				buildModelUpgraderLV4,
				attackModelUpgraderLV4,
				effectModelUpgraderLV4
			]}
        ]
    });
    frag.build(Vars.ui.hudGroup);
}));
*/