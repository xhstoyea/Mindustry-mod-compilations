//xvxshenhun@qq.com，使用标注来源（禁止删除注释）

module.exports = {	
    name: null, 
    techNode(parent2, block, requirements){
        var parent = TechTree.all.find(node => node.content == parent2);
        var node = new TechTree.TechNode(parent, block, requirements);
	}, 

    tex(name) {
	    return Core.atlas.find("工业巨头-" + name);
	}, 

    blends(build, direction) {
	    return PayloadAcceptor.blends(build, direction);
	}, 
	
    node(parent2, block, requirements, objectives){
	    var parent = TechTree.all.find(node => node.content == parent2);
	    var node = new TechTree.TechNode(parent, block, requirements);
	
	    node.objectives.add(objectives);
	}, 

    c(string) {
	    return Color.valueOf(string);
	}, 

    fi(name) {
	    return Vars.content.getByName(ContentType.item, "工业巨头-" + name);
	},

    fs(index) {	
        var spriteName = "工业巨头-" + this.name + index;
	    return spriteName;
	}, 

    fu(name) {
	    return Vars.content.getByName(ContentType.unit, "工业巨头-" + name);
	}, 
	
    fl(name) {
	    return Vars.content.getByName(ContentType.liquid, "工业巨头-" + name);
	}, 

	fb(name) {
	    return Vars.content.getByName(ContentType.block, "工业巨头-" + name);
	}
}
