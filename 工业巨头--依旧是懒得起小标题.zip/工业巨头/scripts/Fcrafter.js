//由yaddrx2进行140适配

const battery = Blocks.battery
battery.update = true
battery.buildType = prov(() => new JavaAdapter(Battery.BatteryBuild, {
	updateTile(){
		if(this.power.status*this.block.consPower.capacity>0.05) this.power.status -= 0.05/this.block.consPower.capacity
	}
}, battery))

const batteryL = Blocks.batteryLarge
batteryL.update = true
batteryL.buildType = prov(() => new JavaAdapter(Battery.BatteryBuild, {
	updateTile(){
		if(this.power.status*this.block.consPower.capacity>0.5) this.power.status -= 0.5/this.block.consPower.capacity
	}
}, batteryL))

const oreCopper = extend(Item,"oreCopper",{});
oreCopper.color = Color.valueOf("FFA500");
oreCopper.cost = 0.2;

const oreLead = extend(Item,"oreLead",{})
oreLead.color = Color.valueOf("9370DB");
oreLead.cost = 0.2;

const oreTitanium = extend(Item,"oreTitanium",{});
oreTitanium.color = Color.valueOf("4169E1");
oreTitanium.hardness = 3;

const oreThorium = extend(Item,"oreThorium",{});
oreThorium.color = Color.valueOf("EE82EE")
oreThorium.hardness = 4;

exports.oreCopper = oreCopper
exports.oreLead = oreLead
exports.oreTitanium = oreTitanium
exports.oreThorium = oreThorium

const copperGear = extend(Item,"copperGear",{});
//copper * 2
copperGear.description = "It is used to turret and conveyor widely.";

const strongGear = extend(Item,"strongGear",{});
// titanium *2

const baseRepairKit = extend(Item,"baseRepairKit",{});
// buildModel *2 ---> *5 

const repairKit = extend(Item,"repairKit",{});
// copperWire *4 + buildModel *2 ---> *3

const advancedRepairKit = extend(Item,"advancedRepairKit",{});
// buildModelLV2 *3 + metagalss*4 ---> *2

const baseOverdriveKit = extend(Item,"baseOverdriveKit",{});
// silicon *2 + graphite *2

const overdriveKit = extend(Item,"overdriveKit",{});
// siliconWafer *4 + titanium *8 ---> *2

const advancedOverdriveKit = extend(Item,"advancedOverdriveKit",{});
// base*2 + thorium*3 + phase-fabric *2 ---> *2

const buildModel = extend(Item,"buildModel",{});
buildModel.cost = 2
// copper *3 + lead *4
const buildModelLV2 = extend(Item,"buildModelLV2",{});
buildModelLV2.cost = 4
//Lv1 + titanium *3 + graphite *4 + silicon *4 
const buildModelLV3 = extend(Item,"buildModelLV3",{});
buildModelLV3.cost = 6
//Lv2 + thorium *3
const buildModelLV4 = extend(Item,"buildModelLV4",{});
buildModelLV4.cost = 8
//Lv3 + plastianum *5
const buildModelLV5 = extend(Item,"buildModelLV5",{});
buildModelLV5.cost = 12
//Lv3 + sugeAlloy * 5

const liquidModel = extend(Item,"liquidModel",{});
// metagalss *2 + lead *2
const liquidModelLV2 = extend(Item,"liquidModelLV2",{});
// Lv1 + silicon *2
const liquidModelLV3 = extend(Item,"liquidModelLV3",{});
// Lv2 + graphite *2 + titanium *2

const shootModel = extend(Item,"shootModel",{});
// copper *13 + lead *12
const shootModelLV2 = extend(Item,"shootModelLV2",{});
// Lv1 + silicon *20 + graphite *20
const shootModelLV3 = extend(Item,"shootModelLV3",{});
// Lv2 + plastianum *30
const shootModelLV4 = extend(Item,"shootModelLV4",{});
// Lv3 + sugeAlloy *30

const laserModel = extend(Item,"laserModel",{});
// shootModelLV2 + metagalss * 10
const laserModelLV2 = extend(Item,"laserModelLV2",{});
// Lv1 + metagalss * 30 + silicon * 20 

const siliconWafer = extend(Item,"siliconWafer",{});
// silicon -> *4
const copperWire = extend(Item,"copperWire",{});
// copper -> *2

const energyModel = extend(Item,"energyModel",{});
// copperWire *3
const energyModelLV2 = extend(Item,"energyModelLV2",{});
// Lv1 +  siliconWafer * 3 + graphite *4
const energyModelLV3 = extend(Item,"energyModelLV3",{});
// Lv2 +  titanium *10 + thorium * 20
const energyModelLV4 = extend(Item,"energyModelLV4",{});
// Lv3 +  plastianum *10 + fabric * 10

const craftModel = extend(Item,"craftModel",{});
craftModel.description = "You can use it to build advanced crafter";
// silicon *5 + graphite *5
const craftModelLV2 = extend(Item,"craftModelLV2",{});
// Lv1 + titanium *10
const craftModelLV3 = extend(Item,"craftModelLV3",{});
// Lv2 + plastianum *5
craftModelLV2.description = craftModelLV3.description = "You can use it to build more advanced crafter";

const specialTrafficKitTypeA = extend(Item,"specialTrafficKitTypeA",{});
// phase-fabric *8

const specialTrafficKitTypeB = extend(Item,"specialTrafficKitTypeB",{});
// plastianum *8

const accelerator = extend(Item,"accelerator",{});
// titanium *2

const specialPlate = extend(Item,"specialPlate",{});
// plastianum *2 + titanium *2

const mineModel = extend(Item,"mineModel",{});
// siliconWafer *3 + graphite *4 + copperWire *3
const mineModelLV2 = extend(Item,"mineModelLV2",{});
// Lv1 + titanium *5
const mineModelLV3 = extend(Item,"mineModelLV3",{});
// Lv2 + thorium * 10 + fabric *1
mineModel.description = mineModelLV2.description = mineModelLV3.description = "You can use it to build better "

const attackModel = extend(Item,"attackModel",{});
// silicon *20 + copperWire *10 + lead *10
const attackModelLV2 = extend(Item,"attackModelLV2",{});
// Lv1 + silicon *20 + graphite *20
const attackModelLV3 = extend(Item,"attackModelLV3",{});
// Lv2 + silicon *90 + metagalss * 50 + titanium *90
const attackModelLV4 = extend(Item,"attackModelLV4",{});
// Lv3 + silicon *750 + titanium *840 + plastianum * 180
const attackModelLV5 = extend(Item,"attackModelLV5",{});
attackModel.description = attackModelLV2.description = attackModelLV3.description = attackModelLV4.description  = attackModelLV5.description = "You can use it to build better unit."
// Lv4 + silicon *1200 + plastianum *800 + surgeAlloy *700 + phase-fabric *500 

const effectModel = extend(Item,"effectModel",{});
// copperWire *10 + graphite *3
const effectModelLV2 = extend(Item,"effectModelLV2",{});
// Lv1 + siliconWafer *8
const effectModelLV3 = extend(Item,"effectModelLV3",{});
// Lv2 + titanium *4
const effectModelLV4 = extend(Item,"effectModelLV4",{});
// Lv3 + thorium * 10
const effectModelLV5 = extend(Item,"effectModelLV5",{});
// Lv4 + plastianum *10
effectModel.description = effectModelLV2.description = effectModelLV3.description = effectModelLV4.description  = effectModelLV5.description = "You can use it to build better unit."

const displayModel = extend(Item,"displayModel",{});
// metaglass *5
const displayModelLV2 = extend(Item,"displayModelLV2",{});
// Lv1 + phase-fabric *4

const siliconBoard  = extend(Item,"siliconBoard",{});
// silicon *2

const smeltModel = extend(Item,"smeltModel",{});
//mineModel *1 + craftModel *1 + titanium *10 + siliconWafer *4

const smeltModelLV2 = extend(Item,"smeltModelLV2",{});
//LV1+thorium *10+ craftModelLV2 *1 + mineModelLV2*1

const smeltModelLV3 = extend(Item,"smeltModelLV3",{});
//LV2+plastanium *5+ craftModelLV3 *1 + mineModelLV3*1

exports.smeltModel = smeltModel
exports.smeltModelLV2 = smeltModelLV2
exports.smeltModelLV3 = smeltModelLV3
exports.buildModel = buildModel
exports.buildModelLV2 = buildModelLV2
exports.buildModelLV3 = buildModelLV3
exports.attackModel = attackModel
exports.attackModelLV2 = attackModelLV2
exports.attackModelLV3 = attackModelLV3
exports.attackModelLV4 = attackModelLV4
exports.attackModelLV5 = attackModelLV5

const slagCondenser = extend(GenericCrafter,"slagCondenser",{});

Object.assign(slagCondenser,{
	size : 1,
	craftTime : 120,
	hasItems : true,
	hasLiquids : true,
	itemCapacity : 10,
	liquidCapacity : 200,
	buildVisibility : BuildVisibility.shown,
	craftEffect : Fx.pulverizeMedium,
	requirements : ItemStack.with(
		oreCopper, 40,
		oreLead, 40
	),
	outputItem : new ItemStack(Items.scrap, 3),
	alwaysUnlocked : true,
	category : Category.crafting
})

const copperFurnace = extend(GenericCrafter,"copperFurnace",{});
Object.assign(copperFurnace,{
	size : 1,
	craftTime : 60,
	hasItems : true,
	hasLiquids : true,
	itemCapacity : 10,
	liquidCapacity : 200,
	buildVisibility : BuildVisibility.shown,
	craftEffect : Fx.pulverizeMedium,
	requirements : ItemStack.with(
		oreCopper, 20,
		oreLead, 20
	),
	outputItem : new ItemStack(Items.copper, 2),
	outputLiquid : new LiquidStack(Liquids.slag,0.03),
	alwaysUnlocked : true,
	category : Category.crafting
})
copperFurnace.consumeItems(
	new ItemStack(Items.coal, 1),
	new ItemStack(oreCopper, 4)
);

const leadFurnace = extend(GenericCrafter,"leadFurnace",{});

Object.assign(leadFurnace,{
	size : 1,
	craftTime : 60,
	hasItems : true,
	hasLiquids : true,
	itemCapacity : 10,
	liquidCapacity : 200,
	buildVisibility : BuildVisibility.shown,
	craftEffect : Fx.pulverizeMedium,
	requirements : ItemStack.with(
		oreCopper, 20,
		oreLead, 20
	),
	outputItem : new ItemStack(Items.lead, 2),
	outputLiquid : new LiquidStack(Liquids.slag,0.03),
	alwaysUnlocked : true,
	category : Category.crafting
})
leadFurnace.consumeItems(
	new ItemStack(Items.coal, 1),
	new ItemStack(oreLead, 4)
);

const titaniumFurnace = extend(GenericCrafter,"titaniumFurnace",{});
const thoriumFurnace = extend(GenericCrafter,"thoriumFurnace",{});

const copperCrafter = extend(GenericCrafter,"copperCrafter",{});
const leadCrafter = extend(GenericCrafter,"leadCrafter",{});
const titaniumCrafter = extend(GenericCrafter,"titaniumCrafter",{});
const thoriumCrafter = extend(GenericCrafter,"thoriumCrafter",{});

const powerNode = extend(PowerNode,"powerNode",{});
const powerNodeLarge = extend(PowerNode,"powerNodeLarge",{});

powerNode.buildType = prov(() => new JavaAdapter(PowerNode.PowerNodeBuild,{
	updateTile(){
		this.super$updateTile();
		
		if(this.timer.get(0,60)){
			this.consume();
		}
	}
},powerNode));
powerNode.consumesPower = true;
powerNode.maxNodes = 5;

powerNodeLarge.buildType = prov(() => new JavaAdapter(PowerNode.PowerNodeBuild,{
	updateTile(){
		this.super$updateTile();
		
		if(this.timer.get(0,30)){
			this.consume();
		}
	}
},powerNodeLarge));
powerNodeLarge.consumesPower = true;
powerNodeLarge.maxNodes = 10;
powerNodeLarge.laserRange = 10;

const F = require("library/func");

const buildModelCrafter = extend(GenericCrafter,"buildModelCrafter",{});

Object.assign(buildModelCrafter,{	
    size : 2,
    craftTime : 60 * 2,
    hasItems : true,
    itemCapacity : 15,
    craftEffect : Fx.pulverizeMedium,
    requirements : ItemStack.with(
	Items.copper, 40, 
	Items.lead, 40
	),
    outputItem : new ItemStack(buildModel, 1),
    category : Category.crafting,
    buildVisibility : BuildVisibility.shown
})
buildModelCrafter.consumeItems(
	new ItemStack(Items.copper, 5),
	new ItemStack(Items.lead, 5)
);

const buildModelUpgrader = extend(GenericCrafter,"buildModelUpgrader",{});
buildModelUpgrader.size = 2;
buildModelUpgrader.craftTime = 60 * 3;
buildModelUpgrader.hasItems = true;
buildModelUpgrader.itemCapacity = 15;
buildModelUpgrader.craftEffect = Fx.pulverizeMedium;
buildModelUpgrader.consumeItems(
	new ItemStack(buildModel, 1),
	new ItemStack(Items.titanium, 4),
	new ItemStack(Items.graphite, 4),
	new ItemStack(Items.silicon, 4)
);
buildModelUpgrader.consumePower(0.5);
buildModelUpgrader.requirements = ItemStack.with(
	buildModel, 40,
	craftModel, 1
);
buildModelUpgrader.outputItem = new ItemStack(buildModelLV2, 1);
buildModelUpgrader.category = Category.crafting;
buildModelUpgrader.buildVisibility = BuildVisibility.shown;

const buildModelUpgraderLV2 = extend(GenericCrafter,"buildModelUpgraderLV2",{});
buildModelUpgraderLV2.size = 2;
buildModelUpgraderLV2.hasItems = true;
buildModelUpgraderLV2.craftTime = 60 * 4;
buildModelUpgraderLV2.itemCapacity = 15;
buildModelUpgraderLV2.craftEffect = Fx.pulverizeMedium;
buildModelUpgraderLV2.consumeItems(
	new ItemStack(buildModelLV2, 1),
	new ItemStack(Items.thorium, 3)
);
buildModelUpgraderLV2.requirements = ItemStack.with(
	buildModelLV2 , 40,
	craftModelLV2, 1
);
buildModelUpgraderLV2.outputItem = new ItemStack(buildModelLV3, 1);
buildModelUpgraderLV2.category = Category.crafting;
buildModelUpgraderLV2.buildVisibility = BuildVisibility.shown;

const buildModelUpgraderLV3 = extend(GenericCrafter,"buildModelUpgraderLV3",{});
buildModelUpgraderLV3.size = 2;
buildModelUpgraderLV3.hasItems = true;
buildModelUpgraderLV3.craftTime = 60 * 5;
buildModelUpgraderLV3.itemCapacity = 15;
buildModelUpgraderLV3.craftEffect = Fx.pulverizeMedium;
buildModelUpgraderLV3.consumeItems(
	new ItemStack(buildModelLV3, 1),
	new ItemStack(Items.plastanium, 5)
);
buildModelUpgraderLV3.requirements = ItemStack.with(
	buildModelLV3 , 40,
	craftModelLV3, 1
);
buildModelUpgraderLV3.outputItem = new ItemStack(buildModelLV4, 1);
buildModelUpgraderLV3.category = Category.crafting;
buildModelUpgraderLV3.buildVisibility = BuildVisibility.shown;

const buildModelUpgraderLV4 = extend(GenericCrafter,"buildModelUpgraderLV4",{});
buildModelUpgraderLV4.size = 2;
buildModelUpgraderLV4.hasItems = true;
buildModelUpgraderLV4.craftTime = 60 * 6;
buildModelUpgraderLV4.itemCapacity = 15;
buildModelUpgraderLV4.craftEffect = Fx.pulverizeMedium;
buildModelUpgraderLV4.consumeItems(
	new ItemStack(buildModelLV4, 1),
	new ItemStack(Items.surgeAlloy, 5)
);
buildModelUpgraderLV4.requirements = ItemStack.with(
	buildModelLV4 , 40,
	craftModelLV3, 10
);
buildModelUpgraderLV4.outputItem = new ItemStack(buildModelLV5, 1);
buildModelUpgraderLV4.category = Category.crafting;
buildModelUpgraderLV4.buildVisibility = BuildVisibility.shown;

const copperGearCrafter = extend(GenericCrafter,"copperGearCrafter",{});
copperGearCrafter.size = 2;
copperGearCrafter.craftTime = 60 * 2;
copperGearCrafter.hasItems = true;
copperGearCrafter.itemCapacity = 12;
copperGearCrafter.craftEffect = Fx.pulverizeMedium;
copperGearCrafter.consumeItems(
	new ItemStack(Items.copper, 4)
);
copperGearCrafter.requirements = ItemStack.with(
	Items.copper, 20, 
	Items.lead, 20
);
copperGearCrafter.outputItem = new ItemStack(copperGear, 2);
copperGearCrafter.category = Category.crafting;
copperGearCrafter.buildVisibility = BuildVisibility.shown;

const siliconBoardCrafter = extend(GenericCrafter,"siliconBoardCrafter",{});
siliconBoardCrafter.size = 2;
siliconBoardCrafter.craftTime = 60 * 2;
siliconBoardCrafter.hasItems = true;
siliconBoardCrafter.itemCapacity = 12;
siliconBoardCrafter.craftEffect = Fx.pulverizeMedium;
siliconBoardCrafter.consumeItems(
	new ItemStack(Items.silicon, 2),
	new ItemStack(copperWire, 2)
);
siliconBoardCrafter.requirements = ItemStack.with(
	buildModel, 15, 
	craftModel, 1
);
siliconBoardCrafter.outputItem = new ItemStack(siliconBoard, 2);
siliconBoardCrafter.category = Category.crafting;
siliconBoardCrafter.buildVisibility = BuildVisibility.shown;

const siliconWaferCrafter = extend(GenericCrafter,"siliconWaferCrafter",{});
siliconWaferCrafter.size = 2;
siliconWaferCrafter.craftTime = 60 * 2;
siliconWaferCrafter.hasItems = true;
siliconWaferCrafter.itemCapacity = 12;
siliconWaferCrafter.craftEffect = Fx.pulverizeMedium;
siliconWaferCrafter.consumeItems(
	new ItemStack(Items.silicon, 1)
);
siliconWaferCrafter.requirements = ItemStack.with(
	buildModel, 15, 
	craftModel, 1
);
siliconWaferCrafter.outputItem = new ItemStack(siliconWafer, 2);
siliconWaferCrafter.category = Category.crafting;
siliconWaferCrafter.buildVisibility = BuildVisibility.shown;

const strongGearCrafter = extend(GenericCrafter,"strongGearCrafter",{});
strongGearCrafter.size = 2;
strongGearCrafter.craftTime = 60;
strongGearCrafter.hasItems = true;
strongGearCrafter.itemCapacity = 12;
strongGearCrafter.craftEffect = Fx.pulverizeMedium;
strongGearCrafter.consumeItems(
	new ItemStack(Items.titanium, 4)
);
strongGearCrafter.requirements = ItemStack.with(
	buildModelLV2, 20, 
	craftModel, 1
);
strongGearCrafter.outputItem = new ItemStack(strongGear, 2);
strongGearCrafter.category = Category.crafting;
strongGearCrafter.buildVisibility = BuildVisibility.shown;

const liquidModelCrafter = extend(GenericCrafter,"liquidModelCrafter",{});
liquidModelCrafter.size = 2;
liquidModelCrafter.craftTime = 60 * 2;
liquidModelCrafter.hasItems = true;
liquidModelCrafter.itemCapacity = 12;
liquidModelCrafter.craftEffect = Fx.pulverizeMedium;
liquidModelCrafter.consumeItems(
	new ItemStack(Items.lead, 2),
	new ItemStack(Items.metaglass, 2)
);
liquidModelCrafter.requirements = ItemStack.with(
	buildModel, 10
);
liquidModelCrafter.outputItem = new ItemStack(liquidModel, 1);
liquidModelCrafter.category = Category.crafting;
liquidModelCrafter.buildVisibility = BuildVisibility.shown;

const liquidModelUpgrader = extend(GenericCrafter,"liquidModelUpgrader",{});
liquidModelUpgrader.size = 2;
liquidModelUpgrader.craftTime = 60 * 3;
liquidModelUpgrader.hasItems = true;
liquidModelUpgrader.itemCapacity = 12;
liquidModelUpgrader.craftEffect = Fx.pulverizeMedium;
liquidModelUpgrader.consumeItems(
	new ItemStack(liquidModel, 1),
	new ItemStack(Items.silicon, 2)
);
liquidModelUpgrader.consumePower(0.5);
liquidModelUpgrader.requirements = ItemStack.with(
	buildModelLV2, 20,
	craftModel, 1
);
liquidModelUpgrader.outputItem = new ItemStack(liquidModelLV2, 1);
liquidModelUpgrader.category = Category.crafting;
liquidModelUpgrader.buildVisibility = BuildVisibility.shown;

const liquidModelUpgraderLV2 = extend(GenericCrafter,"liquidModelUpgraderLV2",{});
liquidModelUpgraderLV2.size = 2;
liquidModelUpgraderLV2.craftTime = 60 * 4;
liquidModelUpgraderLV2.hasItems = true;
liquidModelUpgraderLV2.itemCapacity = 12;
liquidModelUpgraderLV2.craftEffect = Fx.pulverizeMedium;
liquidModelUpgraderLV2.consumeItems(
	new ItemStack(liquidModelLV2, 1),
	new ItemStack(Items.titanium, 2),
	new ItemStack(Items.graphite, 2)
);
liquidModelUpgraderLV2.consumePower(1.5);
liquidModelUpgraderLV2.requirements = ItemStack.with(
	buildModelLV3, 30,
	craftModelLV2, 1
);
liquidModelUpgraderLV2.outputItem = new ItemStack(liquidModelLV3, 1);
liquidModelUpgraderLV2.category = Category.crafting;
liquidModelUpgraderLV2.buildVisibility = BuildVisibility.shown;

const craftModelCrafter = extend(GenericCrafter,"craftModelCrafter",{});
craftModelCrafter.size = 2;
craftModelCrafter.craftTime = 90 * 2;
craftModelCrafter.hasItems = true;
craftModelCrafter.itemCapacity = 12;
craftModelCrafter.craftEffect = Fx.pulverizeMedium;
craftModelCrafter.consumeItems(
	new ItemStack(Items.silicon, 6),
	new ItemStack(Items.graphite, 6)
);
craftModelCrafter.consumePower(1.5);
craftModelCrafter.requirements = ItemStack.with(
	buildModel, 20
);
craftModelCrafter.outputItem = new ItemStack(craftModel, 1);
craftModelCrafter.category = Category.crafting;
craftModelCrafter.buildVisibility = BuildVisibility.shown;

const craftModelUpgrader = extend(GenericCrafter,"craftModelUpgrader",{});
craftModelUpgrader.size = 2;
craftModelUpgrader.craftTime = 90 * 2;
craftModelUpgrader.hasItems = true;
craftModelUpgrader.itemCapacity = 20;
craftModelUpgrader.craftEffect = Fx.pulverizeMedium;
craftModelUpgrader.consumeItems(
	new ItemStack(craftModel, 1),
	new ItemStack(Items.titanium, 10)
);
craftModelUpgrader.consumePower(1.5);
craftModelUpgrader.requirements = ItemStack.with(
	buildModelLV2, 40,
	craftModel, 10
);
craftModelUpgrader.outputItem = new ItemStack(craftModelLV2, 1);
craftModelUpgrader.category = Category.crafting;
craftModelUpgrader.buildVisibility = BuildVisibility.shown;

const craftModelUpgraderLV2 = extend(GenericCrafter,"craftModelUpgraderLV2",{});
craftModelUpgraderLV2.size = 2;
craftModelUpgraderLV2.craftTime = 90 * 2;
craftModelUpgraderLV2.hasItems = true;
craftModelUpgraderLV2.itemCapacity = 12;
craftModelUpgraderLV2.craftEffect = Fx.pulverizeMedium;
craftModelUpgraderLV2.consumeItems(
	new ItemStack(craftModelLV2, 1),
	new ItemStack(Items.plastanium, 5)
);
craftModelUpgraderLV2.consumePower(1.5);
craftModelUpgraderLV2.requirements = ItemStack.with(
	buildModelLV3, 50,
	craftModelLV2, 20
);
craftModelUpgraderLV2.outputItem = new ItemStack(craftModelLV3, 1);
craftModelUpgraderLV2.category = Category.crafting;
craftModelUpgraderLV2.buildVisibility = BuildVisibility.shown;

const mineModelCrafter = extend(GenericCrafter,"mineModelCrafter",{});
mineModelCrafter.size = 2;
mineModelCrafter.craftTime = 90 * 2;
mineModelCrafter.hasItems = true;
mineModelCrafter.itemCapacity = 12;
mineModelCrafter.craftEffect = Fx.pulverizeMedium;
mineModelCrafter.consumeItems(
	new ItemStack(Items.silicon, 6),
	new ItemStack(Items.graphite, 6),
	new ItemStack(copperWire, 3)
);
mineModelCrafter.consumePower(0.5);
mineModelCrafter.requirements = ItemStack.with(
	buildModel, 20,
	craftModel, 1
);
mineModelCrafter.outputItem = new ItemStack(mineModel, 1);
mineModelCrafter.category = Category.crafting;
mineModelCrafter.buildVisibility = BuildVisibility.shown;

const mineModelUpgrader = extend(GenericCrafter,"mineModelUpgrader",{});
mineModelUpgrader.size = 2;
mineModelUpgrader.craftTime = 90 * 3;
mineModelUpgrader.hasItems = true;
mineModelUpgrader.itemCapacity = 20;
mineModelUpgrader.craftEffect = Fx.pulverizeMedium;
mineModelUpgrader.consumeItems(
	new ItemStack(mineModel, 1),
	new ItemStack(Items.titanium, 10),
	new ItemStack(liquidModelLV2, 1)
);
mineModelUpgrader.consumePower(0.5);
mineModelUpgrader.requirements = ItemStack.with(
	buildModelLV2, 20,
	craftModelLV2, 1
);
mineModelUpgrader.outputItem = new ItemStack(mineModelLV2, 1);
mineModelUpgrader.category = Category.crafting;
mineModelUpgrader.buildVisibility = BuildVisibility.shown;

const mineModelUpgraderLV2 = extend(GenericCrafter,"mineModelUpgraderLV2",{});
mineModelUpgraderLV2.size = 3;
mineModelUpgraderLV2.craftTime = 90 * 4;
mineModelUpgraderLV2.hasItems = true;
mineModelUpgraderLV2.itemCapacity = 20;
mineModelUpgraderLV2.craftEffect = Fx.pulverizeMedium;
mineModelUpgraderLV2.consumeItems(
	new ItemStack(mineModelLV2, 1),
	new ItemStack(Items.thorium, 10),
	new ItemStack(liquidModelLV3, 1)
);
mineModelUpgraderLV2.consumePower(1.5);
mineModelUpgraderLV2.requirements = ItemStack.with(
	buildModelLV3, 20,
	craftModelLV3, 1
);
mineModelUpgraderLV2.outputItem = new ItemStack(mineModelLV3, 1);
mineModelUpgraderLV2.category = Category.crafting;
mineModelUpgraderLV2.buildVisibility = BuildVisibility.shown;

const attackModelCrafter = extend(GenericCrafter,"attackModelCrafter",{});
attackModelCrafter.size = 3;
attackModelCrafter.craftTime = 90 * 2;
attackModelCrafter.hasItems = true;
attackModelCrafter.itemCapacity = 40;
attackModelCrafter.craftEffect = Fx.pulverizeMedium;
attackModelCrafter.consumeItems(
	new ItemStack(Items.silicon, 20),
	new ItemStack(Items.lead, 10),
	new ItemStack(copperWire, 10)
);
attackModelCrafter.requirements = ItemStack.with(
	buildModel, 20
);
attackModelCrafter.outputItem = new ItemStack(attackModel, 1);
attackModelCrafter.category = Category.crafting;
attackModelCrafter.buildVisibility = BuildVisibility.shown;

const attackModelUpgrader = extend(GenericCrafter,"attackModelUpgrader",{});
attackModelUpgrader.size = 3;
attackModelUpgrader.craftTime = 90 * 2;
attackModelUpgrader.hasItems = true;
attackModelUpgrader.itemCapacity = 40;
attackModelUpgrader.craftEffect = Fx.pulverizeMedium;
attackModelUpgrader.consumePower(0.5);
attackModelUpgrader.consumeItems(
	new ItemStack(Items.silicon, 20),
	new ItemStack(Items.graphite, 20),
	new ItemStack(attackModel, 1)
);
attackModelUpgrader.requirements = ItemStack.with(
	buildModelLV2, 30,
	craftModel, 1
);
attackModelUpgrader.outputItem = new ItemStack(attackModelLV2, 1);
attackModelUpgrader.category = Category.crafting;
attackModelUpgrader.buildVisibility = BuildVisibility.shown;

const attackModelUpgraderLV2 = extend(GenericCrafter,"attackModelUpgraderLV2",{});
attackModelUpgraderLV2.size = 3;
attackModelUpgraderLV2.craftTime = 90 * 2;
attackModelUpgraderLV2.hasItems = true;
attackModelUpgraderLV2.itemCapacity = 180;
attackModelUpgraderLV2.craftEffect = Fx.pulverizeMedium;
attackModelUpgraderLV2.consumeItems(
	new ItemStack(Items.silicon, 90),
	new ItemStack(Items.titanium, 90),
	new ItemStack(Items.metaglass, 50),
	new ItemStack(attackModelLV2, 1)
);
attackModelUpgraderLV2.consumePower(1.5);
attackModelUpgraderLV2.requirements = ItemStack.with(
	buildModelLV3, 40,
	craftModelLV2, 1
);
attackModelUpgraderLV2.outputItem = new ItemStack(attackModelLV3, 1);
attackModelUpgraderLV2.category = Category.crafting;
attackModelUpgraderLV2.buildVisibility = BuildVisibility.shown;

const attackModelUpgraderLV3 = extend(GenericCrafter,"attackModelUpgraderLV3",{});
attackModelUpgraderLV3.size = 3;
attackModelUpgraderLV3.craftTime = 90 * 4;
attackModelUpgraderLV3.hasItems = true;
attackModelUpgraderLV3.itemCapacity = 1680;
attackModelUpgraderLV3.craftEffect = Fx.pulverizeMedium;
attackModelUpgraderLV3.consumePower(5);
attackModelUpgraderLV3.consumeItems(
	new ItemStack(Items.silicon, 750),
	new ItemStack(Items.titanium, 840),
	new ItemStack(Items.plastanium, 180),
	new ItemStack(attackModelLV3, 1)
);
attackModelUpgraderLV3.requirements = ItemStack.with(
	buildModelLV4, 80,
	craftModelLV3, 1
);
attackModelUpgraderLV3.outputItem = new ItemStack(attackModelLV4, 1);
attackModelUpgraderLV3.category = Category.crafting;
attackModelUpgraderLV3.buildVisibility = BuildVisibility.shown;

const attackModelUpgraderLV4 = extend(GenericCrafter,"attackModelUpgraderLV4",{});
attackModelUpgraderLV4.size = 3;
attackModelUpgraderLV4.craftTime = 90 * 8;
attackModelUpgraderLV4.hasItems = true;
attackModelUpgraderLV4.itemCapacity = 2400;
attackModelUpgraderLV4.craftEffect = Fx.pulverizeMedium;
attackModelUpgraderLV4.consumePower(15);
attackModelUpgraderLV4.consumeItems(
	new ItemStack(Items.silicon, 1200),
	new ItemStack(Items.plastanium, 800),
	new ItemStack(Items.phaseFabric, 500),
	new ItemStack(Items.surgeAlloy, 700),
	new ItemStack(attackModelLV4, 1)
);
attackModelUpgraderLV4.consumePower(1.5);
attackModelUpgraderLV4.requirements = ItemStack.with(
	buildModelLV5, 120,
	craftModelLV3, 30
);
attackModelUpgraderLV4.outputItem = new ItemStack(attackModelLV5, 1);
attackModelUpgraderLV4.category = Category.crafting;
attackModelUpgraderLV4.buildVisibility = BuildVisibility.shown;

const shootModelCrafter = extend(GenericCrafter,"shootModelCrafter",{});
shootModelCrafter.size = 2;
shootModelCrafter.craftTime = 60 * 3;
shootModelCrafter.hasItems = true;
shootModelCrafter.itemCapacity = 26;
shootModelCrafter.craftEffect = Fx.pulverizeMedium;
shootModelCrafter.consumeItems(
	new ItemStack(Items.copper, 13),
	new ItemStack(Items.lead, 12)
);
shootModelCrafter.requirements = ItemStack.with(
	buildModel, 20
);
shootModelCrafter.outputItem = new ItemStack(shootModel, 1);
shootModelCrafter.category = Category.crafting;
shootModelCrafter.buildVisibility = BuildVisibility.shown;

const shootModelUpgrader = extend(GenericCrafter,"shootModelUpgrader",{});
shootModelUpgrader.size = 2;
shootModelUpgrader.craftTime = 60 * 4;
shootModelUpgrader.hasItems = true;
shootModelUpgrader.itemCapacity = 40;
shootModelUpgrader.craftEffect = Fx.pulverizeMedium;
shootModelUpgrader.consumePower(0.5);
shootModelUpgrader.consumeItems(
	new ItemStack(Items.graphite, 20),
	new ItemStack(Items.silicon, 20),
	new ItemStack(shootModel, 1)
);
shootModelUpgrader.requirements = ItemStack.with(
	buildModelLV2, 20,
	craftModel, 1
);
shootModelUpgrader.outputItem = new ItemStack(shootModelLV2, 1);
shootModelUpgrader.category = Category.crafting;
shootModelUpgrader.buildVisibility = BuildVisibility.shown;

const shootModelUpgraderLV2 = extend(GenericCrafter,"shootModelUpgraderLV2",{});
shootModelUpgraderLV2.size = 2;
shootModelUpgraderLV2.craftTime = 60 * 5;
shootModelUpgraderLV2.hasItems = true;
shootModelUpgraderLV2.itemCapacity = 60;
shootModelUpgraderLV2.craftEffect = Fx.pulverizeMedium;
shootModelUpgraderLV2.consumePower(1.5);
shootModelUpgraderLV2.consumeItems(
	new ItemStack(Items.plastanium, 30),
	new ItemStack(shootModelLV2, 1)
);
shootModelUpgraderLV2.requirements = ItemStack.with(
	buildModelLV3, 40,
	craftModelLV2, 1
);
shootModelUpgraderLV2.outputItem = new ItemStack(shootModelLV3, 1);
shootModelUpgraderLV2.category = Category.crafting;
shootModelUpgraderLV2.buildVisibility = BuildVisibility.shown;

const shootModelUpgraderLV3 = extend(GenericCrafter,"shootModelUpgraderLV3",{});
shootModelUpgraderLV3.size = 2;
shootModelUpgraderLV3.craftTime = 60 * 5;
shootModelUpgraderLV3.hasItems = true;
shootModelUpgraderLV3.itemCapacity = 60;
shootModelUpgraderLV3.craftEffect = Fx.pulverizeMedium;
shootModelUpgraderLV3.consumePower(5);
shootModelUpgraderLV3.consumeItems(
	new ItemStack(Items.surgeAlloy, 30),
	new ItemStack(shootModelLV3, 1)
);
shootModelUpgraderLV3.requirements = ItemStack.with(
	buildModelLV4, 80,
	craftModelLV3, 1
);
shootModelUpgraderLV3.outputItem = new ItemStack(shootModelLV4, 1);
shootModelUpgraderLV3.category = Category.crafting;
shootModelUpgraderLV3.buildVisibility = BuildVisibility.shown;

const laserModelCrafter = extend(GenericCrafter,"laserModelCrafter",{});
laserModelCrafter.size = 2;
laserModelCrafter.craftTime = 60 * 4;
laserModelCrafter.hasItems = true;
laserModelCrafter.itemCapacity = 10;
laserModelCrafter.craftEffect = Fx.pulverizeMedium;
laserModelCrafter.consumeItems(
	new ItemStack(shootModelLV2, 1),
	new ItemStack(Items.metaglass, 10)
);
laserModelCrafter.consumePower(1);
laserModelCrafter.requirements = ItemStack.with(
	buildModelLV2, 20,
	craftModel , 1
);
laserModelCrafter.outputItem = new ItemStack(laserModel, 1);
laserModelCrafter.category = Category.crafting;
laserModelCrafter.buildVisibility = BuildVisibility.shown;

const laserModelUpgrader = extend(GenericCrafter,"laserModelUpgrader",{});
laserModelUpgrader.size = 2;
laserModelUpgrader.craftTime = 60 * 4;
laserModelUpgrader.hasItems = true;
laserModelUpgrader.itemCapacity = 10;
laserModelUpgrader.craftEffect = Fx.pulverizeMedium;
laserModelUpgrader.consumeItems(
	new ItemStack(laserModel, 1),
	new ItemStack(Items.metaglass, 30),
	new ItemStack(Items.silicon, 20)
);
laserModelUpgrader.consumePower(1);
laserModelUpgrader.requirements = ItemStack.with(
	buildModelLV3, 30,
	craftModelLV3 , 1
);
laserModelUpgrader.outputItem = new ItemStack(laserModelLV2, 1);
laserModelUpgrader.category = Category.crafting;
laserModelUpgrader.buildVisibility = BuildVisibility.shown;

const effectModelCrafter = extend(GenericCrafter,"effectModelCrafter",{});
effectModelCrafter.size = 2;
effectModelCrafter.craftTime = 60 * 4;
effectModelCrafter.hasItems = true;
effectModelCrafter.itemCapacity = 10;
effectModelCrafter.craftEffect = Fx.pulverizeMedium;
effectModelCrafter.consumeItems(
	new ItemStack(copperWire, 10),
	new ItemStack(Items.graphite, 3)
);
effectModelCrafter.consumePower(0.5);
effectModelCrafter.requirements = ItemStack.with(
	buildModel, 20,
	craftModel , 1
);
effectModelCrafter.outputItem = new ItemStack(effectModel, 1);
effectModelCrafter.category = Category.crafting;
effectModelCrafter.buildVisibility = BuildVisibility.shown;

const effectModelUpgrader = extend(GenericCrafter,"effectModelUpgrader",{});
effectModelUpgrader.size = 2;
effectModelUpgrader.craftTime = 60 * 4;
effectModelUpgrader.hasItems = true;
effectModelUpgrader.itemCapacity = 10;
effectModelUpgrader.craftEffect = Fx.pulverizeMedium;
effectModelUpgrader.consumeItems(
	new ItemStack(effectModel, 1),
	new ItemStack(siliconWafer, 8)
);
effectModelUpgrader.consumePower(1.5);
effectModelUpgrader.requirements = ItemStack.with(
	buildModelLV2, 20,
	craftModelLV2 , 1
);
effectModelUpgrader.outputItem = new ItemStack(effectModelLV2, 1);
effectModelUpgrader.category = Category.crafting;
effectModelUpgrader.buildVisibility = BuildVisibility.shown;

const effectModelUpgraderLV2 = extend(GenericCrafter,"effectModelUpgraderLV2",{});
effectModelUpgraderLV2.size = 2;
effectModelUpgraderLV2.craftTime = 60 * 4;
effectModelUpgraderLV2.hasItems = true;
effectModelUpgraderLV2.itemCapacity = 10;
effectModelUpgraderLV2.craftEffect = Fx.pulverizeMedium;
effectModelUpgraderLV2.consumeItems(
	new ItemStack(effectModelLV2, 1),
	new ItemStack(Items.titanium, 4)
);
effectModelUpgraderLV2.consumePower(2.5);
effectModelUpgraderLV2.requirements = ItemStack.with(
	buildModelLV3, 20,
	craftModelLV3 , 1
);
effectModelUpgraderLV2.outputItem = new ItemStack(effectModelLV3, 1);
effectModelUpgraderLV2.category = Category.crafting;
effectModelUpgraderLV2.buildVisibility = BuildVisibility.shown;

const effectModelUpgraderLV3 = extend(GenericCrafter,"effectModelUpgraderLV3",{});
effectModelUpgraderLV3.size = 2;
effectModelUpgraderLV3.craftTime = 60 * 6;
effectModelUpgraderLV3.hasItems = true;
effectModelUpgraderLV3.itemCapacity = 20;
effectModelUpgraderLV3.craftEffect = Fx.pulverizeMedium;
effectModelUpgraderLV3.consumePower(5);
effectModelUpgraderLV3.consumeItems(
	new ItemStack(effectModelLV3, 1),
	new ItemStack(Items.thorium, 10)
);
effectModelUpgraderLV3.requirements = ItemStack.with(
	buildModelLV4, 40,
	craftModelLV3 , 10
);
effectModelUpgraderLV3.outputItem = new ItemStack(effectModelLV4, 1);
effectModelUpgraderLV3.category = Category.crafting;
effectModelUpgraderLV3.buildVisibility = BuildVisibility.shown;

const effectModelUpgraderLV4 = extend(GenericCrafter,"effectModelUpgraderLV4",{});
effectModelUpgraderLV4.size = 2;
effectModelUpgraderLV4.craftTime = 60 * 8;
effectModelUpgraderLV4.hasItems = true;
effectModelUpgraderLV4.itemCapacity = 20;
effectModelUpgraderLV4.craftEffect = Fx.pulverizeMedium;
effectModelUpgraderLV4.consumePower(15);
effectModelUpgraderLV4.consumeItems(
	new ItemStack(effectModelLV4, 1),
	new ItemStack(Items.plastanium, 10)
);
effectModelUpgraderLV4.requirements = ItemStack.with(
	buildModelLV5, 60,
	craftModelLV3 , 20,
	energyModelLV4, 10
);
effectModelUpgraderLV4.outputItem = new ItemStack(effectModelLV3, 1);
effectModelUpgraderLV4.category = Category.crafting;
effectModelUpgraderLV4.buildVisibility = BuildVisibility.shown;

const displayModelCrafter = extend(GenericCrafter,"displayModelCrafter",{});
displayModelCrafter.size = 2;
displayModelCrafter.craftTime = 60 * 4;
displayModelCrafter.hasItems = true;
displayModelCrafter.itemCapacity = 10;
displayModelCrafter.craftEffect = Fx.pulverizeMedium;
displayModelCrafter.consumeItems(
	new ItemStack(Items.metaglass, 5)
);
displayModelCrafter.consumePower(0.5);
displayModelCrafter.requirements = ItemStack.with(
	buildModel, 10,
	craftModel , 1
);
displayModelCrafter.outputItem = new ItemStack(displayModel, 1);
displayModelCrafter.category = Category.crafting;
displayModelCrafter.buildVisibility = BuildVisibility.shown;

const displayModelUpgrader = extend(GenericCrafter,"displayModelUpgrader",{});
displayModelUpgrader.size = 2;
displayModelUpgrader.craftTime = 60 * 4;
displayModelUpgrader.hasItems = true;
displayModelUpgrader.itemCapacity = 10;
displayModelUpgrader.craftEffect = Fx.pulverizeMedium;
displayModelUpgrader.consumeItems(
	new ItemStack(Items.phaseFabric, 4),
	new ItemStack(displayModel, 1)
);
displayModelUpgrader.consumePower(1.5);
displayModelUpgrader.requirements = ItemStack.with(
	buildModelLV2, 30,
	craftModelLV2 , 1
);
displayModelUpgrader.outputItem = new ItemStack(displayModelLV2, 1);
displayModelUpgrader.category = Category.crafting;
displayModelUpgrader.buildVisibility = BuildVisibility.shown;

const energyModelCrafter = extend(GenericCrafter,"energyModelCrafter",{});
energyModelCrafter.size = 2;
energyModelCrafter.craftTime = 60 * 4;
energyModelCrafter.hasItems = true;
energyModelCrafter.itemCapacity = 10;
energyModelCrafter.craftEffect = Fx.pulverizeMedium;
energyModelCrafter.consumeItems(
	new ItemStack(copperWire, 3)
);
energyModelCrafter.requirements = ItemStack.with(
	buildModel, 10
);
energyModelCrafter.outputItem = new ItemStack(energyModel, 1);
energyModelCrafter.category = Category.crafting;
energyModelCrafter.buildVisibility = BuildVisibility.shown;

const energyModelUpgrader = extend(GenericCrafter,"energyModelUpgrader",{});
energyModelUpgrader.size = 2;
energyModelUpgrader.craftTime = 60 * 5;
energyModelUpgrader.hasItems = true;
energyModelUpgrader.itemCapacity = 10;
energyModelUpgrader.craftEffect = Fx.pulverizeMedium;
energyModelUpgrader.consumeItems(
	new ItemStack(siliconWafer, 3),
	new ItemStack(Items.graphite, 4),
	new ItemStack(energyModel, 1)
);
energyModelUpgrader.requirements = ItemStack.with(
	buildModelLV2, 30,
	craftModel, 1
);
energyModelUpgrader.outputItem = new ItemStack(energyModelLV2, 1);
energyModelUpgrader.category = Category.crafting;
energyModelUpgrader.buildVisibility = BuildVisibility.shown;

const energyModelUpgraderLV2 = extend(GenericCrafter,"energyModelUpgraderLV2",{});
energyModelUpgraderLV2.size = 2;
energyModelUpgraderLV2.craftTime = 60 * 9;
energyModelUpgraderLV2.hasItems = true;
energyModelUpgraderLV2.itemCapacity = 20;
energyModelUpgraderLV2.craftEffect = Fx.pulverizeMedium;
energyModelUpgraderLV2.consumePower(1.5);
energyModelUpgraderLV2.consumeItems(
	new ItemStack(Items.titanium, 10),
	new ItemStack(Items.thorium, 20),
	new ItemStack(energyModelLV2, 1)
);
energyModelUpgraderLV2.requirements = ItemStack.with(
	buildModelLV3, 30,
	craftModelLV2, 1
);
energyModelUpgraderLV2.outputItem = new ItemStack(energyModelLV3, 1);
energyModelUpgraderLV2.category = Category.crafting;
energyModelUpgraderLV2.buildVisibility = BuildVisibility.shown;

const energyModelUpgraderLV3 = extend(GenericCrafter,"energyModelUpgraderLV3",{});
energyModelUpgraderLV3.size = 2;
energyModelUpgraderLV3.craftTime = 60 * 7;
energyModelUpgraderLV3.hasItems = true;
energyModelUpgraderLV3.itemCapacity = 10;
energyModelUpgraderLV3.craftEffect = Fx.pulverizeMedium;
energyModelUpgraderLV3.consumePower(5);
energyModelUpgraderLV3.consumeItems(
	new ItemStack(Items.plastanium, 10),
	new ItemStack(Items.phaseFabric, 10),
	new ItemStack(energyModelLV3, 1)
);
energyModelUpgraderLV3.requirements = ItemStack.with(
	buildModelLV4, 60,
	craftModelLV3, 1
);
energyModelUpgraderLV3.outputItem = new ItemStack(energyModelLV4, 1);
energyModelUpgraderLV3.category = Category.crafting;
energyModelUpgraderLV3.buildVisibility = BuildVisibility.shown;

const smeltModelCrafter = extend(GenericCrafter,"smeltModelCrafter",{});
smeltModelCrafter.size = 2;
smeltModelCrafter.craftTime = 60 * 3;
smeltModelCrafter.hasItems = true;
smeltModelCrafter.itemCapacity = 10;
smeltModelCrafter.craftEffect = Fx.pulverizeMedium;
smeltModelCrafter.consumePower(1);
smeltModelCrafter.consumeItems(
	new ItemStack(Items.titanium, 10),
	new ItemStack(mineModel, 1),
	new ItemStack(craftModel, 1),
	new ItemStack(siliconWafer, 4)
);
smeltModelCrafter.requirements = ItemStack.with(
	buildModel, 20,
	craftModel, 1
);
smeltModelCrafter.outputItem = new ItemStack(smeltModel, 1);
smeltModelCrafter.category = Category.crafting;
smeltModelCrafter.buildVisibility = BuildVisibility.shown;

const smeltModelUpgrader = extend(GenericCrafter,"smeltModelUpgrader",{});
smeltModelUpgrader.size = 3;
smeltModelUpgrader.craftTime = 60 * 8;
smeltModelUpgrader.hasItems = true;
smeltModelUpgrader.itemCapacity = 10;
smeltModelUpgrader.craftEffect = Fx.pulverizeMedium;
smeltModelUpgrader.consumePower(1);
smeltModelUpgrader.consumeItems(
	new ItemStack(Items.thorium, 10),
	new ItemStack(mineModelLV2, 1),
	new ItemStack(craftModelLV2, 1),
	new ItemStack(smeltModel, 1)
);
smeltModelUpgrader.requirements = ItemStack.with(
	buildModelLV2, 45,
	craftModelLV2, 1
);
smeltModelUpgrader.outputItem = new ItemStack(smeltModelLV2, 1);
smeltModelUpgrader.category = Category.crafting;
smeltModelUpgrader.buildVisibility = BuildVisibility.shown;

const smeltModelUpgraderLV2 = extend(GenericCrafter,"smeltModelUpgraderLV2",{});
smeltModelUpgraderLV2.size = 3;
smeltModelUpgraderLV2.craftTime = 60 * 12;
smeltModelUpgraderLV2.hasItems = true;
smeltModelUpgraderLV2.itemCapacity = 10;
smeltModelUpgraderLV2.craftEffect = Fx.pulverizeMedium;
smeltModelUpgraderLV2.consumePower(2);
smeltModelUpgraderLV2.consumeItems(
	new ItemStack(Items.plastanium, 10),
	new ItemStack(mineModelLV3, 1),
	new ItemStack(craftModelLV3, 1),
	new ItemStack(smeltModelLV2, 1)
);
smeltModelUpgraderLV2.requirements = ItemStack.with(
	buildModelLV3, 45,
	craftModelLV3, 1
);
smeltModelUpgraderLV2.outputItem = new ItemStack(smeltModelLV3, 1);
smeltModelUpgraderLV2.category = Category.crafting;
smeltModelUpgraderLV2.buildVisibility = BuildVisibility.shown;

const copperWireCrafter = extend(GenericCrafter,"copperWireCrafter",{});
copperWireCrafter.size = 2;
copperWireCrafter.craftTime = 30;
copperWireCrafter.hasItems = true;
copperWireCrafter.itemCapacity = 10;
copperWireCrafter.craftEffect = Fx.pulverizeMedium;
copperWireCrafter.consumeItems(
	new ItemStack(Items.copper, 2)
);
copperWireCrafter.requirements = ItemStack.with(
	buildModel, 10
);
copperWireCrafter.outputItem = new ItemStack(copperWire, 4);
copperWireCrafter.category = Category.crafting;
copperWireCrafter.buildVisibility = BuildVisibility.shown;

const repairKitCrafter = extend(GenericCrafter,"repairKitCrafter",{});
repairKitCrafter.size = 2;
repairKitCrafter.craftTime = 60 *3;
repairKitCrafter.hasItems = true;
repairKitCrafter.itemCapacity = 10;
repairKitCrafter.craftEffect = Fx.pulverizeMedium;
repairKitCrafter.consumeItems(
	new ItemStack(buildModel, 2)
);
repairKitCrafter.requirements = ItemStack.with(
	buildModel, 10
);
repairKitCrafter.outputItem = new ItemStack(baseRepairKit, 4);
repairKitCrafter.category = Category.crafting;
repairKitCrafter.buildVisibility = BuildVisibility.shown;

const repairKitUpgrader = extend(GenericCrafter,"repairKitUpgrader",{});
repairKitUpgrader.size = 2;
repairKitUpgrader.craftTime = 60 *3;
repairKitUpgrader.hasItems = true;
repairKitUpgrader.itemCapacity = 10;
repairKitUpgrader.craftEffect = Fx.pulverizeMedium;
repairKitUpgrader.consumeItems(
	new ItemStack(buildModel, 2),
	new ItemStack(copperWire, 4)
);
repairKitUpgrader.requirements = ItemStack.with(
	buildModelLV2, 20,
	craftModel, 1
);
repairKitUpgrader.outputItem = new ItemStack(repairKit, 1);
repairKitUpgrader.category = Category.crafting;
repairKitUpgrader.buildVisibility = BuildVisibility.shown;

const repairKitUpgraderLV2 = extend(GenericCrafter,"repairKitUpgraderLV2",{});
repairKitUpgraderLV2.size = 2;
repairKitUpgraderLV2.craftTime = 60 *3;
repairKitUpgraderLV2.hasItems = true;
repairKitUpgraderLV2.itemCapacity = 10;
repairKitUpgraderLV2.craftEffect = Fx.pulverizeMedium;
repairKitUpgraderLV2.consumeItems(
	new ItemStack(buildModelLV2, 3),
	new ItemStack(Items.metaglass, 4)
);
repairKitUpgraderLV2.requirements = ItemStack.with(
	buildModelLV3, 20,
	craftModelLV2, 1
);
repairKitUpgraderLV2.outputItem = new ItemStack(advancedRepairKit, 2);
repairKitUpgraderLV2.category = Category.crafting;
repairKitUpgraderLV2.buildVisibility = BuildVisibility.shown;

const overdriveKitCrafter = extend(GenericCrafter,"overdriveKitCrafter",{});
overdriveKitCrafter.size = 2;
overdriveKitCrafter.craftTime = 60 * 3;
overdriveKitCrafter.hasItems = true;
overdriveKitCrafter.itemCapacity = 10;
overdriveKitCrafter.craftEffect = Fx.pulverizeMedium;
overdriveKitCrafter.consumeItems(
	new ItemStack(Items.silicon, 2),
	new ItemStack(Items.graphite, 2)
);
overdriveKitCrafter.consumePower(1.5);
overdriveKitCrafter.requirements = ItemStack.with(
	buildModelLV2, 20,
	craftModel, 1
);
overdriveKitCrafter.outputItem = new ItemStack(baseOverdriveKit, 1);
overdriveKitCrafter.category = Category.crafting;
overdriveKitCrafter.buildVisibility = BuildVisibility.shown;

const overdriveKitUpgrader = extend(GenericCrafter,"overdriveKitUpgrader",{});
overdriveKitUpgrader.size = 2;
overdriveKitUpgrader.craftTime = 60 * 4;
overdriveKitUpgrader.hasItems = true;
overdriveKitUpgrader.itemCapacity = 10;
overdriveKitUpgrader.craftEffect = Fx.pulverizeMedium;
overdriveKitUpgrader.consumeItems(
	new ItemStack(siliconWafer, 4),
	new ItemStack(Items.titanium, 8)
);
overdriveKitUpgrader.consumePower(2);
overdriveKitUpgrader.requirements = ItemStack.with(
	buildModelLV3, 30,
	craftModelLV2, 1
);
overdriveKitUpgrader.outputItem = new ItemStack(overdriveKit, 2);
overdriveKitUpgrader.category = Category.crafting;
overdriveKitUpgrader.buildVisibility = BuildVisibility.shown;

const overdriveKitUpgraderLV2 = extend(GenericCrafter,"overdriveKitUpgraderLV2",{});
overdriveKitUpgraderLV2.size = 2;
overdriveKitUpgraderLV2.craftTime = 60 * 5;
overdriveKitUpgraderLV2.hasItems = true;
overdriveKitUpgraderLV2.itemCapacity = 10;
overdriveKitUpgraderLV2.craftEffect = Fx.pulverizeMedium;
overdriveKitUpgraderLV2.consumeItems(
	new ItemStack(Items.thorium, 2),
	new ItemStack(Items.phaseFabric, 2),
	new ItemStack(overdriveKit, 2)
);
overdriveKitUpgraderLV2.consumePower(3);
overdriveKitUpgraderLV2.requirements = ItemStack.with(
	buildModelLV4, 30,
	craftModelLV3, 1
);
overdriveKitUpgraderLV2.outputItem = new ItemStack(advancedOverdriveKit, 1);
overdriveKitUpgraderLV2.category = Category.crafting;
overdriveKitUpgraderLV2.buildVisibility = BuildVisibility.shown;

const specialTrafficKitTypeACrafter = extend(GenericCrafter,"specialTrafficKitTypeACrafter",{});
specialTrafficKitTypeACrafter.size = 2;
specialTrafficKitTypeACrafter.craftTime = 60 * 5;
specialTrafficKitTypeACrafter.hasItems = true;
specialTrafficKitTypeACrafter.itemCapacity = 10;
specialTrafficKitTypeACrafter.craftEffect = Fx.pulverizeMedium;
specialTrafficKitTypeACrafter.consumeItems(
	new ItemStack(Items.phaseFabric, 8)
);
specialTrafficKitTypeACrafter.consumePower(3);
specialTrafficKitTypeACrafter.requirements = ItemStack.with(
	buildModelLV4, 30,
	craftModelLV3, 1
);
specialTrafficKitTypeACrafter.outputItem = new ItemStack(specialTrafficKitTypeA, 1);
specialTrafficKitTypeACrafter.category = Category.crafting;
specialTrafficKitTypeACrafter.buildVisibility = BuildVisibility.shown;

const specialTrafficKitTypeBCrafter = extend(GenericCrafter,"specialTrafficKitTypeBCrafter",{});
specialTrafficKitTypeBCrafter.size = 2;
specialTrafficKitTypeBCrafter.craftTime = 60 * 5;
specialTrafficKitTypeBCrafter.hasItems = true;
specialTrafficKitTypeBCrafter.itemCapacity = 10;
specialTrafficKitTypeBCrafter.craftEffect = Fx.pulverizeMedium;
specialTrafficKitTypeBCrafter.consumeItems(
	new ItemStack(Items.plastanium, 8)
);
specialTrafficKitTypeBCrafter.consumePower(3);
specialTrafficKitTypeBCrafter.requirements = ItemStack.with(
	buildModelLV4, 30,
	craftModelLV3, 1
);
specialTrafficKitTypeBCrafter.outputItem = new ItemStack(specialTrafficKitTypeB, 1);
specialTrafficKitTypeBCrafter.category = Category.crafting;
specialTrafficKitTypeBCrafter.buildVisibility = BuildVisibility.shown;

const specialPlateCrafter = extend(GenericCrafter,"specialPlateCrafter",{});
specialPlateCrafter.size = 2;
specialPlateCrafter.craftTime = 60 * 4;
specialPlateCrafter.hasItems = true;
specialPlateCrafter.itemCapacity = 10;
specialPlateCrafter.craftEffect = Fx.pulverizeMedium;
specialPlateCrafter.consumeItems(
	new ItemStack(Items.plastanium, 2),
	new ItemStack(Items.titanium, 2)
);
specialPlateCrafter.consumePower(2);
specialPlateCrafter.requirements = ItemStack.with(
	buildModelLV3, 30,
	craftModelLV2, 1
);
specialPlateCrafter.outputItem = new ItemStack(specialPlate, 1);
specialPlateCrafter.category = Category.crafting;
specialPlateCrafter.buildVisibility = BuildVisibility.shown;

const acceleratorCrafter = extend(GenericCrafter,"acceleratorCrafter",{});
acceleratorCrafter.size = 2;
acceleratorCrafter.craftTime = 60 * 3;
acceleratorCrafter.hasItems = true;
acceleratorCrafter.itemCapacity = 10;
acceleratorCrafter.craftEffect = Fx.pulverizeMedium;
acceleratorCrafter.consumeItems(
	new ItemStack(Items.titanium, 2)
);
acceleratorCrafter.consumePower(0.5);
acceleratorCrafter.requirements = ItemStack.with(
	buildModelLV2, 20,
	craftModel, 1
);
acceleratorCrafter.outputItem = new ItemStack(accelerator, 1);
acceleratorCrafter.category = Category.crafting;
acceleratorCrafter.buildVisibility = BuildVisibility.shown;

F.techNode(Blocks.coreShard, copperFurnace, ItemStack.with(
	oreCopper, (20 * 5),
	oreLead, (20 * 5)
));

F.techNode(Blocks.coreShard, leadFurnace, ItemStack.with(
	oreCopper, (20 * 5),
	oreLead, (20 * 5)
));

F.techNode(copperFurnace, buildModelCrafter, ItemStack.with(
	Items.copper, (40 * 5),
	Items.lead, (40 * 5)
));

F.techNode(buildModelCrafter, buildModelUpgrader, ItemStack.with(
	buildModel, (40 * 5),
	craftModel, (1 * 5)
));

F.techNode(buildModelUpgrader, buildModelUpgraderLV2, ItemStack.with(
	buildModelLV2, (40 * 5),
	craftModelLV2, (1 * 5)
));

F.techNode(buildModelUpgraderLV2, buildModelUpgraderLV3, ItemStack.with(
	buildModelLV3, (40 * 5),
	craftModelLV3, (1 * 5)
));

F.techNode(buildModelUpgraderLV3, buildModelUpgraderLV4, ItemStack.with(
	buildModelLV4, (40 * 5),
	craftModelLV3, (10 * 5)
));

F.techNode(copperFurnace, copperGearCrafter, ItemStack.with(
	Items.copper, (20 * 5),
	Items.lead, (20 * 5)
));

F.techNode(buildModelCrafter, siliconWaferCrafter, ItemStack.with(
	buildModel, 15, 
	craftModel, 1
));

F.techNode(siliconWaferCrafter, siliconBoardCrafter, ItemStack.with(
	buildModel, 15, 
	craftModel, 1
));

F.techNode(copperGearCrafter, strongGearCrafter, ItemStack.with(
	buildModelLV2, (20 * 5),
	craftModel, (1 * 5)
));

F.techNode(buildModelCrafter, liquidModelCrafter, ItemStack.with(
	buildModel, (10 * 5)
));

F.techNode(liquidModelCrafter, liquidModelUpgrader, ItemStack.with(
	buildModelLV2, (20 * 5),
	craftModel, (1 * 5)
));

F.techNode(liquidModelUpgrader, liquidModelUpgraderLV2, ItemStack.with(
	buildModelLV3, (20 * 5),
	craftModelLV2, (1 * 5)
));

F.techNode(buildModelCrafter, craftModelCrafter, ItemStack.with(
	buildModel, (20 * 5)
));

F.techNode(craftModelCrafter, craftModelUpgrader, ItemStack.with(
	buildModelLV2, (40 * 5),
	craftModel, (10 * 5)
));

F.techNode(craftModelUpgrader, craftModelUpgraderLV2, ItemStack.with(
	buildModelLV3, (40 * 5),
	craftModelLV2, (10 * 5)
));

F.techNode(craftModelCrafter, acceleratorCrafter, ItemStack.with(
	buildModelLV2, (20 * 5),
	craftModel, (1 * 5)
));

F.techNode(craftModelUpgrader, specialPlateCrafter, ItemStack.with(
	buildModelLV3, (30 * 5),
	craftModelLV2, (1 * 5)
));

F.techNode(craftModelUpgraderLV2, specialTrafficKitTypeACrafter, ItemStack.with(
	buildModelLV4, (30 * 5),
	craftModelLV3, (1 * 5)
));

F.techNode(craftModelUpgraderLV2, specialTrafficKitTypeBCrafter, ItemStack.with(
	buildModelLV4, (30 * 5),
	craftModelLV3, (1 * 5)
));

F.techNode(buildModelCrafter, mineModelCrafter, ItemStack.with(
	buildModel, (20 * 5),
	craftModel, (1 * 5)
));

F.techNode(mineModelCrafter, mineModelUpgrader, ItemStack.with(
	buildModelLV2, (20 * 5),
	craftModelLV2, (1 * 5)
));

F.techNode(mineModelUpgrader, mineModelUpgraderLV2, ItemStack.with(
	buildModelLV3, (20 * 5),
	craftModelLV3, (1 * 5)
));

F.techNode(buildModelCrafter, attackModelCrafter, ItemStack.with(
	buildModel, (10 * 5)
));

F.techNode(attackModelCrafter, attackModelUpgrader, ItemStack.with(
	buildModelLV2, (30 * 5),
	craftModel, (1 * 5)
));

F.techNode(attackModelUpgrader, attackModelUpgraderLV2, ItemStack.with(
	buildModelLV3, (40 * 5),
	craftModelLV2, (1 * 5)
));

F.techNode(attackModelUpgraderLV2, attackModelUpgraderLV3, ItemStack.with(
	buildModelLV4, (80 * 5),
	craftModelLV3, (1 * 5)
));

F.techNode(attackModelUpgraderLV3, attackModelUpgraderLV4, ItemStack.with(
	buildModelLV5, (120 * 5),
	craftModelLV3, (30 * 5)
));

F.techNode(buildModelCrafter, shootModelCrafter, ItemStack.with(
	buildModel, (20 * 5)
));

F.techNode(shootModelCrafter, shootModelUpgrader, ItemStack.with(
	buildModelLV2, (20 * 5),
	craftModel, (1 * 5)
));

F.techNode(shootModelUpgrader, shootModelUpgraderLV2, ItemStack.with(
	buildModelLV3, (40 * 5),
	craftModelLV2, (1 * 5)
));

F.techNode(shootModelUpgraderLV2, shootModelUpgraderLV3, ItemStack.with(
	buildModelLV4, (80 * 5),
	craftModelLV3, (1 * 5)
));

F.techNode(shootModelCrafter, laserModelCrafter, ItemStack.with(
	buildModelLV2, (20 * 5),
	craftModelLV2, (1 * 5)
));

F.techNode(laserModelCrafter, laserModelUpgrader, ItemStack.with(
	buildModelLV3, (30 * 5),
	craftModelLV3, (1 * 5)
));

F.techNode(buildModelCrafter, effectModelCrafter, ItemStack.with(
	buildModel, (20 * 5),
	craftModel, (1 * 5)
));

F.techNode(effectModelCrafter, effectModelUpgrader, ItemStack.with(
	buildModelLV2, (20 * 5),
	craftModelLV2, (1 * 5)
));

F.techNode(effectModelUpgrader, effectModelUpgraderLV2, ItemStack.with(
	buildModelLV3, (20 * 5),
	craftModelLV3, (1 * 5)
));

F.techNode(effectModelUpgraderLV2, effectModelUpgraderLV3, ItemStack.with(
	buildModelLV4, (40 * 5),
	craftModelLV3, (10 * 5)
));

F.techNode(effectModelUpgraderLV3, effectModelUpgraderLV4, ItemStack.with(
	buildModelLV5, (60 * 5),
	craftModelLV3, (20 * 5),
	energyModelLV4, (10 * 5)
));

F.techNode(buildModelCrafter, displayModelCrafter, ItemStack.with(
	buildModel, (10 * 5),
	craftModel, (1 * 5)
));

F.techNode(displayModelCrafter, displayModelUpgrader, ItemStack.with(
	buildModelLV2, (30 * 5),
	craftModelLV2, (1 * 5)
));

F.techNode(buildModelCrafter, energyModelCrafter, ItemStack.with(
	buildModel, (10 * 5)
));

F.techNode(energyModelCrafter, energyModelUpgrader, ItemStack.with(
	buildModelLV2, (30 * 5),
	craftModel, (1 * 5)
));

F.techNode(energyModelUpgrader, energyModelUpgraderLV2, ItemStack.with(
	buildModelLV3, (30 * 5),
	craftModelLV2, (1 * 5)
));

F.techNode(energyModelUpgraderLV2, energyModelUpgraderLV3, ItemStack.with(
	buildModelLV4, (60 * 5),
	craftModelLV3, (1 * 5)
));

F.techNode(buildModelCrafter, copperWireCrafter, ItemStack.with(
	buildModel, (10 * 5)
));

F.techNode(buildModelCrafter, repairKitCrafter, ItemStack.with(
	buildModel, (10 * 5)
));

F.techNode(buildModelCrafter, repairKitUpgrader, ItemStack.with(
	buildModelLV2, (20 * 5),
	craftModel, (1*5)
));

F.techNode(repairKitUpgrader, repairKitUpgraderLV2, ItemStack.with(
	buildModelLV4, (20 * 5),
	craftModelLV2, (1*5)
));

F.techNode(buildModelCrafter, overdriveKitCrafter, ItemStack.with(
	buildModelLV2, (20 * 5),
	craftModel, (1*5)
));

F.techNode(overdriveKitCrafter, overdriveKitUpgrader, ItemStack.with(
	buildModelLV3, (30 * 5),
	craftModelLV2, (1*5)
));

F.techNode(buildModelCrafter, overdriveKitUpgraderLV2, ItemStack.with(
	buildModelLV4, (30 * 5),
	craftModelLV3, (1*5)
));

F.techNode(copperFurnace, slagCondenser, ItemStack.with(
	oreCopper, (40 * 5),
    oreLead, (40*5)
));

F.techNode(mineModelCrafter, smeltModelCrafter, ItemStack.with(
	buildModel, (20*5),
	craftModel, (1*5)
));

F.techNode(smeltModelCrafter,smeltModelUpgrader, ItemStack.with(
	buildModelLV2, (45*5),
	craftModelLV2, (1*5)
));

F.techNode(smeltModelUpgrader, smeltModelUpgraderLV2, ItemStack.with(
	buildModelLV3, (45*5),
	craftModelLV3, (1*5)
));

exports.smeltModelCrafter = smeltModelCrafter