const {attackModel,attackModelLV2,attackModelLV3,attackModelLV4,attackModelLV5} = require("Fcrafter")

//plum和I hope...提供代码
function resetCons(block,item,amount){
	/*
	var con = block.findConsumer((it) => it instanceof ConsumeItems);
	let origin = Reflect.get(con, "items");
	ovrride = orign.concat(new ItemStack())
		添加消耗
	override = Array.from(orign)
	override.push(new ItemStack())
	
	*/
	let seq = Reflect.get(Block, block, "consumeBuilder");
	seq.clear();
	let override = new Array(new ItemStack(item, amount));
	seq.add(new ConsumeItems(override));
}

resetCons(Blocks.additiveReconstructor,attackModelLV2,1)

resetCons(Blocks.multiplicativeReconstructor,attackModelLV3,1)

resetCons(Blocks.exponentialReconstructor,attackModelLV4,1)

resetCons(Blocks.tetrativeReconstructor,attackModelLV5,1)