Events.on(ContentInitEvent, e => {
    capacity();
});

function capacity(){
    let value = 9999999;
    Vars.content.blocks().each(b => b instanceof CoreBlock, b => b.itemCapacity = value);
}