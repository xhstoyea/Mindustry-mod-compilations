const 前哨基地 = extendContent(CoreBlock, "前哨基地", {
    
    canBreak(){return true;},
    canReplace(other){return true;},
    canPlaceOn(tile, team){return true;},
});
exports.前哨基地 = 前哨基地;