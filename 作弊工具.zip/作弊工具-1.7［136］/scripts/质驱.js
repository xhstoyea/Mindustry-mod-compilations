
const B1 = extend(MassDriver, "轻型电磁弹射器", {});
B1.bullet = new MassDriverBolt;