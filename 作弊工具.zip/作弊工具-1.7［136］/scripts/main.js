/*Events.on(EventType.ClientLoadEvent, cons(e => {

    var dialog = new JavaAdapter(BaseDialog, {}, "'作弊工具");
    var icon =new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find("封面", Core.atlas.find("clear")));
    dialog.shown(run(() => {
        dialog.cont.table(Tex.button, cons(t => {
            t.defaults().size(250, 45).left();
            t.button("返回", icon, Styles.cleart, run(() => {
                dialog.hide();
            }));
        t.add("[red]新增不用电的电磁弹射器")
        }));
    }));
    dialog.show();
}));
*/
require("质驱");
require("lib");
//require("stackBridge");
//require("前哨基地");
//require("供器");