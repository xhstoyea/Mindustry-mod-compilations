# zerg
This mindustry mod allows players to explore a planet named Greavar and defend against indigenous attacks while developing local minerals and researching technology.

## language
- [简体中文](README_zh.md)
- [English](README.md)
- [Français](README_fr.md)
- [Русский язык](README_ru.md)
 
I am looking for volunteers who can translate this mod into this language.