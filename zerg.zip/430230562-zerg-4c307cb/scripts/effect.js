exports.interfere = Object.assign(new WaveEffect(), {
	lifetime: 15,
	sizeFrom: 0,
	sizeTo: 8,
	strokeFrom: 1,
	strokeTo: 0,
	colorFrom: Color.valueOf("665c9f"),
	colorTo: Color.valueOf("bf92f9")
})