# zerg
Ce mindustry mod permet aux joueurs d'explorer une planète appelée greavar et de se défendre contre les attaques autochtones tout en développant des minéraux locaux et des techniques de recherche.

## Langue
- [简体中文](README_zh.md)
- [English](README.md)（WIP）
- [Français](README_fr.md)（WIP）
- [Русский язык](README_ru.md)（WIP）
