//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>
const lib = require('前置/lib')

require("更新记录");

require("前置/特效");
require("前置/ds-global");
require("colors");

require("物品");

require("collos/科技中心");

require("核威慑/电Blocks");
require("collos/反质量发电机");
require("核威慑/工厂Blocks");
require("核威慑/液体Blocks");
require("xvx/multi-crafter");
require("collos/钻头A");
require("collos/钻头B");
require("collos/钻头C");
require("collos/钻头D");
require("collos/离子钻头");
require("核威慑/后勤Blocks");
require("核威慑/其他Blocks");
require("核威慑/增强工厂");
require("方块");

require("xvx/喷火器");
require("塔");
require("collos/激光a");
require("人族/脉冲塔1");
require("人族/脉冲塔2");
require("人族/能量球放射塔");

require("掠夺者/焚烧激光1");
require("掠夺者/焚烧激光2");
require("掠夺者/焚烧激光3");

require("MI/missile-i");
require("MI/missile-ii");
require("MI/missile-iii");

require("核心生产");

require("空投仓/核威慑空投仓");
require("空投仓/空投仓");

require("xvx/multi-crafter2");
require("核威慑/单位工厂AA");
require("人族单位/人族单位");
require("掠夺者/红色的恶魔");

require("xvx/塑钢路由器");

require("虫族/虫单位");
require("虫族/液体炮");
require("虫族/虫洞");

require("AI/核威慑矿机AI");
require("AI/核威慑高阶矿机AI");
require("单位");

require("分类");
//require("分类二");

require("天气");

require('星球/planets');
require("战役");

require("限制");

require("AI/废料矿机");
require("AI/铜矿机");
require("AI/铅矿机");
require("AI/煤矿机");
//require("AI/沙矿机");
require("AI/钛矿机");
require("AI/钍矿机");
require("AI/矿机平台");

require("xvx/xvx神魂");
require("collos/恶魔");

//require("测试/selectivecrafter")

lib.mod.meta.displayName = lib.getMessage('mod', 'displayName');
lib.mod.meta.description = lib.getMessage('mod', 'description');
//lib.mod.meta.version = lib.getMessage('mod', 'version');

UnitTypes.alpha.buildSpeed *= 9.0;
UnitTypes.beta.buildSpeed *= 9.0;
UnitTypes.gamma.buildSpeed *= 9.0;
UnitTypes.nova.buildSpeed *= 9.0;
UnitTypes.pulsar.buildSpeed *= 9.0;
UnitTypes.quasar.buildSpeed *= 9.0;
UnitTypes.spiroct.buildSpeed *= 9.0;
UnitTypes.arkyid.buildSpeed *= 9.0;
UnitTypes.toxopid.buildSpeed *= 9.0;
UnitTypes.poly.buildSpeed *= 9.0;
UnitTypes.mega.buildSpeed *= 9.0;
UnitTypes.quad.buildSpeed *= 9.0;
UnitTypes.oct.buildSpeed *= 9.0;

/*
Blocks.conveyor.unloadable = true;
Blocks.titaniumConveyor.unloadable = true;
Blocks.itemBridge.unloadable = true;
Blocks.phaseConveyor.unloadable = true;
Blocks.conveyor.splitOut = true;
Blocks.titaniumConveyor.splitOut = true;
Blocks.itemBridge.splitOut = true;
Blocks.phaseConveyor.splitOut = true;
Blocks.conveyor.conveyorPlacement = true;
Blocks.titaniumConveyor.conveyorPlacement = true;
Blocks.itemBridge.conveyorPlacement = true;
Blocks.phaseConveyor.conveyorPlacement = true;
*/

Vars.experimental = true;

/*
Events.run(WorldLoadEvent, run(() => {
print("改变出生点：是")
Vars.state.rules.waveTeam = Team.sharded;
}));*/

Blocks.blockForge.alwaysUnlocked = true;
Blocks.blockLoader.alwaysUnlocked = true;
Blocks.blockUnloader.alwaysUnlocked = true;

Blocks.itemSource.requirements = ItemStack.with(Items.scrap, 199999999999);

Events.run(PlayerJoin, run(() => {
/*Events.run(PlayerLeave, run(() => {
	print("您退出服务器,修改初始化")
    Blocks.itemSource.update = true;
	Blocks.itemSource.solidifes = true;
	Blocks.itemSource.configurable = true;
}));
Events.run(PlayerBanEvent, run(() => {
	print("您退出服务器,修改初始化")
    Blocks.itemSource.update = true;
	Blocks.itemSource.solidifes = true;
	Blocks.itemSource.configurable = true;
}));
Events.run(PlayerUnbanEvent, run(() => {
	print("您退出服务器,修改初始化")
    Blocks.itemSource.update = true;
	Blocks.itemSource.solidifes = true;
	Blocks.itemSource.configurable = true;
}));
Events.run(PlayerIpBanEvent, run(() => {
	print("您退出服务器,修改初始化")
    Blocks.itemSource.update = true;
	Blocks.itemSource.solidifes = true;
	Blocks.itemSource.configurable = true;
}));
Events.run(PlayerIpUnbanEvent, run(() => {
	print("您退出服务器,修改初始化")
    Blocks.itemSource.update = true;
	Blocks.itemSource.solidifes = true;
	Blocks.itemSource.configurable = true;
}));*/
print("检测玩家连接：是")
const sad = Vars.state.rules.infiniteResources;
print("检测地图模式："+sad)
if(sad){
	print("物品源修改成功")
	Blocks.itemSource.category = null;
	//Blocks.itemSource.update = false;
	//Blocks.itemSource.solidifes = false;
	//Blocks.itemSource.configurable = false;
}else{
	print("物品源修改失败[不是沙盒模式]")
	Blocks.itemSource.category = Category.distribution;
    //Blocks.itemSource.update = true;
	//Blocks.itemSource.solidifes = true;
	//Blocks.itemSource.configurable = true;
}
}));

Blocks.powerSource.requirements = ItemStack.with(Items.scrap, 199999999999);
Blocks.powerVoid.requirements = ItemStack.with(Items.scrap, 199999999999);
Blocks.itemVoid.requirements = ItemStack.with(Items.scrap, 199999999999);
Blocks.liquidSource.requirements = ItemStack.with(Items.scrap, 199999999999);
Blocks.liquidVoid.requirements = ItemStack.with(Items.scrap, 199999999999);

//Vars.Teams = active.add(get(Team.sharded));

//var avvv = new JavaAdapter.apply(PayloadTurret, {})

/*
const F = require("func");
F.techNode(F.fb("光耀核心"), F.fb("payload-cannon"), ItemStack.with(
	myItems.光耀科技点, 3000
));
F.techNode(F.fb("payload-cannon"), F.fb("payload-catapult"), ItemStack.with(
	myItems.光耀科技点, 5000
));

F.techNode(F.fb("光耀核心"), F.fb("drill-mini"), ItemStack.with(
	myItems.光耀科技点, 2500
));
F.techNode(F.fb("drill-mini"), F.fb("drill-mega"), ItemStack.with(
	myItems.光耀科技点, 4000
));

F.techNode(F.fb("光耀核心"), Blocks.blockForge, ItemStack.with(
	myItems.光耀科技点, 1500
));
F.techNode(Blocks.blockForge, F.fb("block-workshop"), ItemStack.with(
	myItems.光耀科技点, 3500
));
F.techNode(F.fb("block-workshop"), F.fb("block-factory"), ItemStack.with(
	myItems.光耀科技点, 5500
));

F.techNode(Blocks.blockForge, F.fb("cloner"), ItemStack.with(
	myItems.光耀科技点, 2000
));
F.techNode(F.fb("cloner"), F.fb("spinner-alt"), ItemStack.with(
	myItems.光耀科技点, 3500
));

F.techNode(Blocks.blockForge, F.fb("piston"), ItemStack.with(
	myItems.光耀科技点, 1000
));
F.techNode(F.fb("piston"), F.fb("piston-sticky"), ItemStack.with(
	myItems.光耀科技点, 2000
));
F.techNode(F.fb("piston-sticky"), F.fb("spore-slime-sided"), ItemStack.with(
	myItems.光耀科技点, 3000
));
F.techNode(F.fb("piston-sticky"), F.fb("spore-slime"), ItemStack.with(
	myItems.光耀科技点, 2000
));
F.techNode(F.fb("spore-slime"), F.fb("surge-slime"), ItemStack.with(
	myItems.光耀科技点, 3500
));

F.techNode(F.fb("光耀核心"), Blocks.blockLoader, ItemStack.with(
	myItems.光耀科技点, 2000
));
F.techNode(Blocks.blockLoader, F.fb("block-packer"), ItemStack.with(
	myItems.光耀科技点, 5000
));
F.techNode(F.fb("光耀核心"), Blocks.blockUnloader, ItemStack.with(
	myItems.光耀科技点, 2000
));
F.techNode(Blocks.blockUnloader, F.fb("block-unpacker"), ItemStack.with(
	myItems.光耀科技点, 5000
));

F.techNode(F.fb("光耀核心"), F.fb("payload-deconstructor"), ItemStack.with(
	myItems.光耀科技点, 2000
));
F.techNode(F.fb("payload-deconstructor"), F.fb("payload-destroyer"), ItemStack.with(
	myItems.光耀科技点, 4500
));
F.techNode(F.fb("payload-destroyer"), F.fb("payload-eradicator"), ItemStack.with(
	myItems.光耀科技点, 6000
));*/