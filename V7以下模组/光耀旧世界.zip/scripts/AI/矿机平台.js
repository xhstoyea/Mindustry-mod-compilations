//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const UnitPlan = UnitFactory.UnitPlan;

const A = require('AI/废料矿机');
const B = require('AI/铜矿机');
const C = require('AI/铅矿机');
const D = require('AI/煤矿机');
const E = require('AI/钛矿机');
const F = require('AI/钍矿机');

//const Z = require('AI/沙矿机');

const G = require('func');

const dsGlobal = require('前置/ds-global');

const chainer = extend(UnitFactory, "矿机平台", {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	init() {
		chainer.plans = Seq.with(
			new UnitPlan(A.废料矿机, 60 * 2,
				ItemStack.with(
					Items.scrap, 1200, 
					G.fi("普通科技点"), 250
				)),
			new UnitPlan(B.铜矿机, 60 * 6,
				ItemStack.with(
					Items.copper, 1200, 
					G.fi("普通科技点"), 250
				)),
			new UnitPlan(C.铅矿机, 60 * 8,
				ItemStack.with(
					Items.lead, 1200, 
					G.fi("普通科技点"), 250
				)),
			/*new UnitPlan(Z.沙矿机, 60 * 4,
				ItemStack.with(
					Items.sand, 1200, 
					G.fi("普通科技点"), 250
				)),*/
			new UnitPlan(D.煤矿机, 60 * 10,
				ItemStack.with(
					Items.coal, 1200, 
					G.fi("普通科技点"), 250
				)),
			new UnitPlan(E.钛矿机, 60 * 12,
				ItemStack.with(
					Items.titanium, 1200, 
					G.fi("普通科技点"), 250
				)),
			new UnitPlan(F.钍矿机, 60 * 14,
				ItemStack.with(
					Items.thorium, 1200, 
					G.fi("普通科技点"), 250
				)),
		);

		this.super$init();
	},
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
	load() {
		this.super$load();
		this.topRegion = this.outRegion = Core.atlas.find("clear");

		this.region = Core.atlas.find("光耀旧世界-矿机平台-base");
		this.router = Core.atlas.find("光耀旧世界-AR");
		this.surge = Core.atlas.find("光耀旧世界-AR2");

		this.laser = Core.atlas.find("laser");
		this.laserEnd = Core.atlas.find("laser-end");
	}
});
chainer.buildType = () => extend(UnitFactory.UnitFactoryBuild, chainer, {
	draw() {
		const dx = this.x, dy = this.y;
		Draw.rect(chainer.region, dx, dy);
		Draw.z(Layer.turret);

		this.rot = Mathf.lerp(this.rot, Math.min(this.efficiency(), 1) * this.timeScale, 0.02);
		const rot = Time.time * this.rot;
		const chaining = this.cons.valid();

		this.dist = Mathf.lerp(this.dist, this.plan
			? this.plan.type.size / 40
			: 4 * this.rot + 8, 0.04);

		for (var i = 0; i < 8; i++) {
			var angle = rot + 360 * i / 8;
			var x = dx + Angles.trnsx(angle, this.dist);
			var y = dy + Angles.trnsy(angle, this.dist);

			if (chaining) {
				Drawf.laser(this.team, chainer.laser, chainer.laserEnd,
					x, y, dx, dy, Math.sqrt(Math.sin(angle / 50) / 5));
				Draw.rect(chainer.surge, x, y, angle);
			} else {
				Draw.rect(chainer.router, x, y, angle);
			}
		}
	},

	dist: 0,
	rot: 0
});
chainer.localizedName = "矿机平台";
chainer.description = "专门生产专门挖一种矿物的专用矿机";
chainer.buildVisibility = BuildVisibility.shown;
chainer.category = Category.units;
chainer.size = 4;
chainer.consumes.power(15);
chainer.requirements = ItemStack.with(
	Items.copper, 2500, 
	Items.lead, 1500, 
	Items.titanium, 900, 
	Items.thorium, 500, 
	G.fi("Pu"), 25, 
	G.fi("普通科技点"), (60 * 4 * 4)
);
G.techNode(G.fb("作战实验室"), chainer, ItemStack.with(
	Items.copper, 2500 * 10, 
	Items.lead, 1500 * 10, 
	Items.titanium, 900 * 10, 
	Items.thorium, 500 * 10, 
	G.fi("Pu"), 25 * 10
));