//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const myItems = require('物品');

exports.低阶北极光 = (() => {
var MyUnit = extendContent(UnitType, '低阶北极光', {});
MyUnit.constructor = () => extend(UnitWaterMove, {});
F.techNode(F.fb("北极光建造工厂"), MyUnit, ItemStack.with(
	myItems.普通科技点, 2500
));
return MyUnit;
})();
exports.中阶北极光 = (() => {
var MyUnit = extendContent(UnitType, '中阶北极光', {});
MyUnit.constructor = () => extend(UnitWaterMove, {});
F.techNode(exports.低阶北极光, MyUnit, ItemStack.with(
	myItems.普通科技点, 5000
));
return MyUnit;
})();
exports.进阶北极光 = (() => {
var MyUnit = extendContent(UnitType, '进阶北极光', {});
MyUnit.constructor = () => extend(UnitWaterMove, {});
F.techNode(exports.中阶北极光, MyUnit, ItemStack.with(
	myItems.普通科技点, 8500
));
return MyUnit;
})();
exports.高阶北极光 = (() => {
var MyUnit = extendContent(UnitType, '高阶北极光', {});
MyUnit.constructor = () => extend(UnitWaterMove, {});
F.techNode(exports.进阶北极光, MyUnit, ItemStack.with(
	myItems.普通科技点, 13000
));
return MyUnit;
})();

exports.低阶应变者 = (() => {
var MyUnit = extendContent(UnitType, '低阶应变者', {});
MyUnit.constructor = () => extend(LegsUnit, {});
F.techNode(F.fb("应变者建造工厂"), MyUnit, ItemStack.with(
	myItems.普通科技点, 2500
));
return MyUnit;
})();
exports.中阶应变者 = (() => {
var MyUnit = extendContent(UnitType, '中阶应变者', {});
MyUnit.constructor = () => extend(LegsUnit, {});
F.techNode(exports.低阶应变者, MyUnit, ItemStack.with(
	myItems.普通科技点, 5000
));
return MyUnit;
})();
exports.进阶应变者 = (() => {
var MyUnit = extendContent(UnitType, '进阶应变者', {});
MyUnit.constructor = () => extend(LegsUnit, {});
F.techNode(exports.中阶应变者, MyUnit, ItemStack.with(
	myItems.普通科技点, 7500
));
return MyUnit;
})();
exports.高阶应变者 = (() => {
var MyUnit = extendContent(UnitType, '高阶应变者', {});
MyUnit.constructor = () => extend(LegsUnit, {});
F.techNode(exports.进阶应变者, MyUnit, ItemStack.with(
	myItems.普通科技点, 9500
));
return MyUnit;
})();
exports.终阶应变者 = (() => {
var MyUnit = extendContent(UnitType, '终阶应变者', {});
MyUnit.constructor = () => extend(LegsUnit, {});
F.techNode(exports.高阶应变者, MyUnit, ItemStack.with(
	myItems.普通科技点, 16000
));
return MyUnit;
})();

exports.低阶游牧者 = (() => {
var MyUnit = extendContent(UnitType, '低阶游牧者', {});
MyUnit.constructor = () => extend(UnitEntity, {});
F.techNode(F.fb("游牧者建造工厂"), MyUnit, ItemStack.with(
	myItems.普通科技点, 2500
));
return MyUnit;
})();
exports.中阶游牧者 = (() => {
var MyUnit = extendContent(UnitType, '中阶游牧者', {});
MyUnit.constructor = () => extend(UnitEntity, {});
F.techNode(exports.低阶游牧者, MyUnit, ItemStack.with(
	myItems.普通科技点, 5000
));
return MyUnit;
})();
exports.进阶游牧者 = (() => {
var MyUnit = extendContent(UnitType, '进阶游牧者', {});
MyUnit.constructor = () => extend(UnitEntity, {});
F.techNode(exports.中阶游牧者, MyUnit, ItemStack.with(
	myItems.普通科技点, 7500
));
return MyUnit;
})();
exports.高阶游牧者 = (() => {
var MyUnit = extendContent(UnitType, '高阶游牧者', {});
MyUnit.constructor = () => extend(UnitEntity, {});
F.techNode(exports.进阶游牧者, MyUnit, ItemStack.with(
	myItems.普通科技点, 12000
));
return MyUnit;
})();
exports.终阶游牧者 = (() => {
var MyUnit = extendContent(UnitType, '终阶游牧者', {});
MyUnit.constructor = () => extend(UnitEntity, {});
F.techNode(exports.高阶游牧者, MyUnit, ItemStack.with(
	myItems.普通科技点, 15000
));
return MyUnit;
})();