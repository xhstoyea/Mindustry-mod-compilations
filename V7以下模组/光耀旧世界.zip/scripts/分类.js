//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

var leftFrag = (fragConfig) => {
    const iconWidth = 46;
    const padding = 4;
    const MARGIN_RIGHT = 314;

    var currentCategory = 0;
    var menuHoverBlock;
    var selectedBlocks = new ObjectMap();
    var scrollPositions = new ObjectFloatMap();
    var blockTable;
    var blockPane;
    var toggler;

    var hide = true;
    
    var IconA = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('光耀旧世界-开启', Core.atlas.find("clear")));
    var IconB = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('光耀旧世界-关闭', Core.atlas.find("clear")));

    var fragment;
    function containsContent(content) {
        var found = false;
        var cs = fragConfig.categories;
        loop: for (var i = 0; i < cs.length; i++) {
            var category = cs[i];
            for (var j = 0; j < category.blocks.length; j++) {
                var block = category.blocks[j];
                if (content == block) {
                    found = true;
                    break loop;
                }
            }
        }

        return found;
    }
    function rebuild() {
        if (fragment) {
            currentCategory = 0;
            var index = toggler.getZIndex();
            var group = toggler.parent;
            toggler.remove();
            fragment.build(group);
            toggler.setZIndex(index);
        }
    }
    Events.on(WorldLoadEvent, cons(event => {
        Core.app.post(run(() => {
            rebuild();
        }));
    }));
    Events.on(UnlockEvent, cons(event => {
        if (containsContent(event.content)) {
            rebuild();
        }
    }));

    function unlocked(block) {
        return block.unlockedNow();
    }
    function getSelectedBlock(cat) {
        return selectedBlocks.get(cat, prov(() => {
            var category = fragConfig.categories[cat]
            return category.blocks.find(v => unlocked(v));
        }));
    }
    fragment = new JavaAdapter(Fragment, {
        build(parent) {
            parent.fill(cons(full => {
                toggler = full;
                full.bottom().right().visibility = boolp(() => Vars.ui.hudfrag.shown);
                if (hide) {
                    full.button(IconA, run(() => {
                        hide = false;
                        rebuild();
                    })).width(25).height(50);
                } else {
                    full.button(IconB, run(() => {
                        hide = true;
                        rebuild();
                    })).width(50).height(250).bottom();
                    full.table(cons(frame => {

                        var rebuildCategory = run(() => {

                            blockTable.clear();
                            blockTable.top().margin(5);

                            var index = 0;
                            var group = new ButtonGroup();
                            group.setMinCheckCount(0);

                            var category = fragConfig.categories[currentCategory || 0];
                            for (var j = 0; j < category.blocks.length; j++) {
                                var block = ((sss) => category.blocks[sss])(j);
                                if (!unlocked(block)) { continue; }
                                if (index++ % fragConfig.columns == 0) {
                                    blockTable.row();
                                }

                                var button = ((block) =>
                                    blockTable.button(new TextureRegionDrawable(block.icon(Cicon.medium)), Styles.clearTogglei, run(() => {
                                        if (unlocked(block)) {
                                            if (Core.input.keyDown(Packages.arc.input.KeyCode.shiftLeft) && Fonts.getUnicode(block.name) != 0) {
                                                Core.app.setClipboardText(Fonts.getUnicode(block.name) + "");
                                                Vars.ui.showInfoFade("@copied");
                                            } else {
                                                Vars.control.input.block = Vars.control.input.block == block ? null : block;
                                                selectedBlocks.put(currentCategory, Vars.control.input.block);
                                                hide = false;
                                                rebuild();
                                            }
                                        }
                                    })).size(iconWidth).group(group).name("block-" + block.name).get()
                                )(block);
                                button.resizeImage(Cicon.medium.size);

                                button.update(((block, button) => run(() => {
                                    var core = Vars.player.core();
                                    var color = (Vars.state.rules.infiniteResources
                                        || (core != null && (core.items.has(block.requirements, Vars.state.rules.buildCostMultiplier) || Vars.state.rules.infiniteResources)))
                                        && Vars.player.isBuilder() ? Color.white : Color.darkGray;

                                    button.forEach(cons(elem => { elem.setColor(color); }));
                                    button.setChecked(Vars.control.input.block == block);

                                    if (!block.isPlaceable()) {
                                        button.forEach(cons(elem => elem.setColor(Color.darkGray)));
                                    }

                                    button.hovered(run(() => menuHoverBlock = block));
                                    button.exited(run(() => {
                                        if (menuHoverBlock == block) {
                                            menuHoverBlock = null;
                                        }
                                    }));
                                }))(block, button));
                            }

                            if (index < fragConfig.columns) {
                                for (var k = 0; k < fragConfig.columns - index; k++) {
                                    blockTable.add().size(iconWidth);
                                }
                            }
                            blockTable.act(0);
                            blockPane.setScrollYForce(scrollPositions.get(currentCategory, 0));
                            Core.app.post(() => {
                                blockPane.setScrollYForce(scrollPositions.get(currentCategory, 0));
                                blockPane.act(0);
                                blockPane.layout();
                            });

                        });

                        frame.image().color(Pal.spore).colspan(fragConfig.columns).height(padding).growX();
                        frame.row();
                        frame.table(Tex.pane2, cons(blocksSelect => {
                            blocksSelect.margin(padding).marginTop(0);
                            blockPane = blocksSelect.pane(cons(blocks => blockTable = blocks)).height(iconWidth * fragConfig.rows + padding)
                                .update(cons(pane => {
                                    if (pane.hasScroll()) {
                                        var result = Core.scene.hit(Core.input.mouseX(), Core.input.mouseY(), true);
                                        if (result == null || !result.isDescendantOf(pane)) {
                                            Core.scene.setScrollFocus(null);
                                        }
                                    }
                                })).grow().get();
                            blockPane.setStyle(Styles.smallPane);
                            blocksSelect.row();
                            blocksSelect.table(cons(table => {

                                table.image().color(Pal.spore).height(padding).colspan(fragConfig.columns).growX();
                                table.row();
                                table.left().margin(0).defaults().size(iconWidth).left();

                                var group = new ButtonGroup();
                                var index = 0;
                                var cs = fragConfig.categories;
                                for (var i = 0; i < cs.length; i++) {
                                    if (index++ % fragConfig.columns == 0) {
                                        table.row();
                                    }
                                    var category = cs[i];
                                    (cc => {
                                        table.button(category.icon(), Styles.clearToggleTransi, run(() => {
                                            currentCategory = cc;
                                            if (Vars.control.input.block != null) {
                                                Vars.control.input.block = getSelectedBlock(currentCategory);
                                            }
                                            rebuildCategory.run();
                                        })).group(group).update(cons(v => v.setChecked(currentCategory == v))).name("category-" + cc);
                                    })(i);
                                }
                                if (index < fragConfig.columns) {
                                    for (var k = 0; k < fragConfig.columns - index; k++) {
                                        table.add().size(iconWidth);
                                    }
                                }
                            })).name("inputTable").growX();
                        })).fillY().bottom().touchable(Touchable.enabled);

                        rebuildCategory.run();
                    }));
                }
            }));
        },
    });

    return fragment;
};

const 反射盾 = require("掠夺者/反射盾");

Events.on(ClientLoadEvent, cons((e) => {
    const 蛋白质工厂 = Vars.content.getByName(ContentType.block, "光耀旧世界-蛋白质工厂");
    const 虫卵工厂 = Vars.content.block("光耀旧世界-虫卵工厂");
    const DNA工厂 = Vars.content.block("光耀旧世界-DNA工厂");
    const 基因突变物工厂 = Vars.content.block("光耀旧世界-基因突变物工厂");
    const 进阶虫卵工厂 = Vars.content.block("光耀旧世界-进阶虫卵工厂");
	
	const 石墨工厂 = Vars.content.block("光耀旧世界-石墨工厂");
    const 硅工厂 = Vars.content.block("光耀旧世界-硅工厂");
    const 煤炭工厂 = Vars.content.block("光耀旧世界-煤炭工厂");
    const 玻璃工厂 = Vars.content.block("光耀旧世界-玻璃工厂");
    const 钍工厂 = Vars.content.block("光耀旧世界-钍工厂");
    const 孢子工厂 = Vars.content.block("光耀旧世界-孢子工厂");
    const 硫工厂 = Vars.content.block("光耀旧世界-硫工厂");
    const 爆混工厂 = Vars.content.block("光耀旧世界-爆混工厂");
    const 塑钢工厂 = Vars.content.block("光耀旧世界-塑钢工厂");
    const 织布机 = Vars.content.block("光耀旧世界-织布机");
    const 合金工厂 = Vars.content.block("光耀旧世界-合金工厂");
	
    const 石墨工厂x = Vars.content.block("光耀旧世界-石墨工厂x");
    const 硅工厂x = Vars.content.block("光耀旧世界-硅工厂x");
    const 煤炭工厂x = Vars.content.block("光耀旧世界-煤炭工厂x");
    const 玻璃工厂x = Vars.content.block("光耀旧世界-玻璃工厂x");
    const 钍工厂x = Vars.content.block("光耀旧世界-钍工厂x");
    const 孢子工厂x = Vars.content.block("光耀旧世界-孢子工厂x");
    const 硫工厂x = Vars.content.block("光耀旧世界-硫工厂x");
    const 爆混工厂x = Vars.content.block("光耀旧世界-爆混工厂x");
    const 塑钢工厂x = Vars.content.block("光耀旧世界-塑钢工厂x");
    const 织布机x = Vars.content.block("光耀旧世界-织布机x");
    const 合金工厂x = Vars.content.block("光耀旧世界-合金工厂x");
	
	const 强化锡金工厂 = Vars.content.block("光耀旧世界-强化锡金工厂");
    const 能量结晶工厂 = Vars.content.block("光耀旧世界-能量结晶工厂");
    const 能量合金工厂 = Vars.content.block("光耀旧世界-能量合金工厂");
	
	const 电磁银工厂 = Vars.content.block("光耀旧世界-电磁银工厂");
    const 能源水晶工厂 = Vars.content.block("光耀旧世界-能源水晶工厂");
	
	const 蜂群导弹平台 = Vars.content.block("光耀旧世界-蜂群导弹平台");
	const 战术导弹平台 = Vars.content.block("光耀旧世界-战术导弹平台");
	const 战略导弹平台 = Vars.content.block("光耀旧世界-战略导弹平台");
	
	const 光球塔 = Vars.content.block("光耀旧世界-光球塔");
	const 电光塔 = Vars.content.block("光耀旧世界-电光塔");
	const 极光塔 = Vars.content.block("光耀旧世界-极光塔");
	
	const 应变者建造工厂 = Vars.content.block("光耀旧世界-应变者建造工厂");
	const 游牧者建造工厂 = Vars.content.block("光耀旧世界-游牧者建造工厂");
	const 北极光建造工厂 = Vars.content.block("光耀旧世界-北极光建造工厂");
	
	const 人族中阶升级平台 = Vars.content.block("光耀旧世界-人族中阶升级平台");
	const 人族进阶升级平台 = Vars.content.block("光耀旧世界-人族进阶升级平台");
	const 人族高阶升级平台 = Vars.content.block("光耀旧世界-人族高阶升级平台");
	const 人族终阶升级平台 = Vars.content.block("光耀旧世界-人族终阶升级平台");
	
	const 抗火导管 = Vars.content.block("光耀旧世界-抗火导管");
	const 抗火液体路由 = Vars.content.block("光耀旧世界-抗火液体路由");
	const 抗火储蓄罐 = Vars.content.block("光耀旧世界-抗火储蓄罐");
	const 海上运输带 = Vars.content.block("光耀旧世界-海上运输带");
	const 塑钢路由器 = Vars.content.block("光耀旧世界-塑钢路由器");
	
	const 钛化器 = Vars.content.block("光耀旧世界-钛化器");
	const 钛变器 = Vars.content.block("光耀旧世界-钛变器");
	const 废料机 = Vars.content.block("光耀旧世界-废料机");
	const 大型废料机 = Vars.content.block("光耀旧世界-大型废料机");
	
	const 核弹 = Vars.content.getByName(ContentType.block, "光耀旧世界-xvx-fsq");
    const 地雷 = Vars.content.getByName(ContentType.block, "光耀旧世界-hdl");
    const gm = Vars.content.getByName(ContentType.block, "光耀旧世界-伽马射线塔");
	
	const 核心 = Vars.content.getByName(ContentType.block, "光耀旧世界-核心");
	const 大核心 = Vars.content.getByName(ContentType.block, "光耀旧世界-大核心");
	
	const 护盾 = Vars.content.getByName(ContentType.block, "光耀旧世界-hd-x");
	const 超速 = Vars.content.getByName(ContentType.block, "光耀旧世界-cs-x");
	
	const 脉冲塔1 = Vars.content.getByName(ContentType.block, "光耀旧世界-脉冲塔1");
	const 脉冲塔2 = Vars.content.getByName(ContentType.block, "光耀旧世界-脉冲塔2");
	const 能量球放射塔 = Vars.content.getByName(ContentType.block, "光耀旧世界-能量球放射塔");
	
	const 科技中心 = Vars.content.getByName(ContentType.block, "光耀旧世界-科技中心");
	const 作战实验室 = Vars.content.getByName(ContentType.block, "光耀旧世界-作战实验室");
	const 作战研究中心 = Vars.content.getByName(ContentType.block, "光耀旧世界-作战研究中心");
	const 矿坑扩展核心 = Vars.content.getByName(ContentType.block, "光耀旧世界-矿坑扩展核心");
	const 工厂扩展核心 = Vars.content.getByName(ContentType.block, "光耀旧世界-工厂扩展核心");
	
	const 人族基地 = Vars.content.getByName(ContentType.block, "光耀旧世界-人族基地");
	const 人族基地前哨 = Vars.content.getByName(ContentType.block, "光耀旧世界-人族基地前哨");
	const 掠夺者平台 = Vars.content.getByName(ContentType.block, "光耀旧世界-掠夺者平台");
	const 掠夺者平台前哨 = Vars.content.getByName(ContentType.block, "光耀旧世界-掠夺者平台前哨");
	const 虫族母巢 = Vars.content.getByName(ContentType.block, "光耀旧世界-虫族母巢");
	const 虫族母巢前哨 = Vars.content.getByName(ContentType.block, "光耀旧世界-虫族母巢前哨");
	const 暗星空洞 = Vars.content.getByName(ContentType.block, "光耀旧世界-暗星空洞");
	const 暗星空洞前哨 = Vars.content.getByName(ContentType.block, "光耀旧世界-暗星空洞前哨");
	const 光耀核心 = Vars.content.getByName(ContentType.block, "光耀旧世界-光耀核心");
	const 光耀核心前哨 = Vars.content.getByName(ContentType.block, "光耀旧世界-光耀核心前哨");
	
	const 装甲墙 = Vars.content.getByName(ContentType.block, "光耀旧世界-装甲墙");
	const 大型装甲墙 = Vars.content.getByName(ContentType.block, "光耀旧世界-大型装甲墙");
	
	const 矿物废水工厂 = Vars.content.block("光耀旧世界-矿物废水工厂");
	const 机械提速液工厂 = Vars.content.block("光耀旧世界-机械提速液工厂");
	const 电磁脉冲 = Vars.content.block("光耀旧世界-电磁脉冲");
	
	const 红魔单位工厂t1 = Vars.content.block("光耀旧世界-红魔单位工厂t1");
	const 红魔单位工厂t2 = Vars.content.block("光耀旧世界-红魔单位工厂t2");
	const 红魔单位工厂t3 = Vars.content.block("光耀旧世界-红魔单位工厂t3");
	const 红魔单位工厂t4 = Vars.content.block("光耀旧世界-红魔单位工厂t4");
	const 红魔单位工厂t5 = Vars.content.block("光耀旧世界-红魔单位工厂t5");
	
	const eruptori = Vars.content.block("光耀旧世界-eruptor-i");
	const eruptorii = Vars.content.block("光耀旧世界-eruptor-ii");
	const eruptoriii = Vars.content.block("光耀旧世界-eruptor-iii");
	
	const 合成台 = Vars.content.block("光耀旧世界-合成台");
	const 走狗工厂 = Vars.content.block("光耀旧世界-走狗工厂");
	
	const 透明方块 = Vars.content.block("光耀旧世界-透明方块");
	const 空降平台 = Vars.content.block("光耀旧世界-空降平台");
	
	const 方块大炮1 = Vars.content.block("光耀旧世界-payload-cannon");
	const 方块大炮2 = Vars.content.block("光耀旧世界-payload-catapult");
	
	const 激光钻头1 = Vars.content.block("光耀旧世界-drill-mini");
	const 激光钻头2 = Vars.content.block("光耀旧世界-drill-mega");
	
	const 克隆器 = Vars.content.block("光耀旧世界-cloner");
	const 机械臂 = Vars.content.block("光耀旧世界-spinner");
	
	const accel = Vars.content.block("光耀旧世界-accel");
	const 活塞1 = Vars.content.block("光耀旧世界-piston");
	const 活塞2 = Vars.content.block("光耀旧世界-piston-sticky");
	const 活塞3 = Vars.content.block("光耀旧世界-spore-slime-sided");
	
	const naot1 = Vars.content.block("光耀旧世界-spore-slime");
	const naot2 = Vars.content.block("光耀旧世界-surge-slime");
	
	const 方块工厂1 = Blocks.blockForge
	const 方块工厂2 = Vars.content.block("光耀旧世界-block-workshop");
	const 方块工厂3 = Vars.content.block("光耀旧世界-block-factory");
	
	const 方块装载1 = Blocks.blockLoader
	const 方块装载2 = Vars.content.block("光耀旧世界-block-packer");
	const 方块卸载1 = Blocks.blockUnloader
	const 方块卸载2 = Vars.content.block("光耀旧世界-block-unpacker");

	const 方块拆卸1 = Vars.content.block("光耀旧世界-payload-deconstructor");
	const 方块拆卸2 = Vars.content.block("光耀旧世界-payload-destroyer");
	const 方块拆卸3 = Vars.content.block("光耀旧世界-payload-eradicator");
	
	const 吞吐者 = Vars.content.block("光耀旧世界-flood");
	const 虫洞 = Vars.content.block("光耀旧世界-phase-space-bridge");
	
    var myIcon1 = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('光耀旧世界-aa', Core.atlas.find("clear")));
    var myIcon2 = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('光耀旧世界-bb', Core.atlas.find("clear")));
    var myIcon3 = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('光耀旧世界-cc', Core.atlas.find("clear")));
    var myIcon4 = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('光耀旧世界-dd', Core.atlas.find("clear")));
    var myIcon5 = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('光耀旧世界-ee', Core.atlas.find("clear")));
    var myIcon6 = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('光耀旧世界-ff', Core.atlas.find("clear")));
	var myIcon7 = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find('光耀旧世界-admin', Core.atlas.find("clear")));
    var frag = leftFrag({
        rows: 4,
        columns: 7,
        categories: [
            { icon: () => myIcon1, blocks: [
		石墨工厂,
        硅工厂,
        煤炭工厂,
        玻璃工厂,
        钍工厂,
        孢子工厂,
		硫工厂,
        石墨工厂x,
        硅工厂x,
        煤炭工厂x,
        玻璃工厂x,
        钍工厂x,
        孢子工厂x,
		硫工厂x,
        爆混工厂,
        塑钢工厂,
        织布机,
        合金工厂,
		钛化器,
		废料机,
		核心,
        爆混工厂x,
        塑钢工厂x,
        织布机x,
        合金工厂x,
		钛变器,
		大型废料机,
		大核心
        ] },
            { icon: () => myIcon2, blocks: [
        人族基地, 
		人族基地前哨,
		透明方块,
		透明方块,
		强化锡金工厂,
		能量结晶工厂,
		能量合金工厂,
		光球塔,
		电光塔,
		极光塔,
		脉冲塔1,
		脉冲塔2,
		能量球放射塔,
		机械提速液工厂,
		应变者建造工厂,
		游牧者建造工厂,
		北极光建造工厂,
		人族中阶升级平台,
		人族进阶升级平台,
		人族高阶升级平台,
		人族终阶升级平台,
		装甲墙,
		大型装甲墙,
		透明方块,
		透明方块,
		透明方块,
		海上运输带,
		塑钢路由器
        ] },
            { icon: () => myIcon3, blocks: [
		掠夺者平台,
		掠夺者平台前哨,
		透明方块,
		透明方块,
		电磁银工厂,
		能源水晶工厂,
		矿物废水工厂,
		蜂群导弹平台,
		战术导弹平台,
		战略导弹平台,
		eruptori,
		eruptorii,
		eruptoriii,
		透明方块,
		红魔单位工厂t1,
		红魔单位工厂t2,
		红魔单位工厂t3,
		红魔单位工厂t4,
		红魔单位工厂t5,
		电磁脉冲,
		反射盾.电磁反射盾,
		抗火导管,
		抗火液体路由,
		抗火储蓄罐
        ] },
            { icon: () => myIcon4, blocks: [
		虫族母巢,
		虫族母巢前哨,
        蛋白质工厂,
        虫卵工厂,
        进阶虫卵工厂,
        DNA工厂,
        基因突变物工厂,
		走狗工厂,
		透明方块,
		透明方块,
		透明方块,
		透明方块,
		透明方块,
		透明方块,
		吞吐者,
		透明方块,
		透明方块,
		透明方块,
		透明方块,
		透明方块,
		透明方块,
		虫洞
        ] },
            { icon: () => myIcon5, blocks: [
        暗星空洞,
		暗星空洞前哨
        ] },
            { icon: () => myIcon6, blocks: [
        光耀核心,
		光耀核心前哨,
		透明方块,
		激光钻头1,
		激光钻头2,
		方块大炮1,
		方块大炮2,
		方块工厂1,
		方块工厂2,
		方块工厂3,
		透明方块,
		方块拆卸1,
		方块拆卸2,
		方块拆卸3,
		方块装载1,
		方块装载2,
		透明方块,
		方块卸载1,
		方块卸载2,
		透明方块,
		机械臂,
		活塞1,
		活塞2,
		活塞3,
		naot1,
		naot2,
		accel,
		克隆器
        ] },
			{ icon: () => myIcon7, blocks: [
        核弹,
        gm,
        地雷,
		透明方块,
		透明方块,
		透明方块,
		透明方块,
		科技中心,
		作战实验室,
		作战研究中心,
		矿坑扩展核心,
		工厂扩展核心,
		透明方块,
		透明方块,
		超速,
		护盾,
		透明方块,
		透明方块,
		透明方块,
		透明方块,
		透明方块,
		合成台,
		透明方块,
		透明方块,
		透明方块,
		透明方块,
		透明方块,
		空降平台
        ] },
        ]
    });
    frag.build(Vars.ui.hudGroup);
}));
