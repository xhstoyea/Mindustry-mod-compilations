//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const lib = require('前置/lib');

exports.人族科技封锁 = () =>
    Vars.state == null
    || Vars.state.rules.infiniteResources
    || !Vars.player
	|| Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-人族基地前哨"))
    || Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-人族基地"));
	
exports.掠夺者科技封锁 = () =>
    Vars.state == null
    || Vars.state.rules.infiniteResources
    || !Vars.player
	|| Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-掠夺者平台前哨"))
    || Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-掠夺者平台"));
	
exports.虫族科技封锁 = () =>
    Vars.state == null
    || Vars.state.rules.infiniteResources
    || !Vars.player
	|| Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-虫族母巢前哨"))
    || Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-虫族母巢"));
	
exports.暗星科技封锁 = () =>
    Vars.state == null
    || Vars.state.rules.infiniteResources
    || !Vars.player
	|| Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-暗星空洞前哨"))
    || Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-暗星空洞"));
	
exports.光耀科技封锁 = () =>
    Vars.state == null
    || Vars.state.rules.infiniteResources
    || !Vars.player
	|| Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-光耀核心前哨"))
    || Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-光耀核心"));
	
exports.科技中心 = () =>
    Vars.state == null
    || Vars.state.rules.infiniteResources
    || !Vars.player
    || Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-科技中心"));
	
exports.作战实验室 = () =>
    Vars.state == null
    || Vars.state.rules.infiniteResources
    || !Vars.player
    || Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-作战实验室"));
	
exports.作战研究中心 = () =>
    Vars.state == null
    || Vars.state.rules.infiniteResources
    || !Vars.player
    || Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-作战研究中心"));
	
exports.工厂扩展核心 = () =>
    Vars.state == null
    || Vars.state.rules.infiniteResources
    || !Vars.player
    || Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-工厂扩展核心"));
	
exports.矿坑扩展核心 = () =>
    Vars.state == null
    || Vars.state.rules.infiniteResources
    || !Vars.player
    || Vars.player.team().cores().find(boolf(v => v.block.name == lib.modName + "-矿坑扩展核心"));