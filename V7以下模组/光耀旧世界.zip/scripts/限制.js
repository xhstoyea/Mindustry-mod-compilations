//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const dsGlobal = require('前置/ds-global');

function createBuildLimit(limit) {
    const built = {};
    function _init_built_(team) {
        if (!built[team.id]) {
            built[team.id] = 0;
        }
    }
    function canBuild(team) {
        _init_built_(team);
        return built[team.id] < limit;
    }
    function addBuild(team) {
        _init_built_(team);
        return built[team.id]++;
    }
    function removeBuild(team) {
        _init_built_(team);
        return built[team.id]--;
    }
    return {
        canBuild: canBuild,
        addBuild: addBuild,
        removeBuild: removeBuild,
    }
}

const 核弹限制 = createBuildLimit(1);

var 核弹 = extend(NuclearReactor, 'hdl', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
    canPlaceOn(tile, team) {
        if (!核弹限制.canBuild(team)) {
            return false;
        }
        return this.super$canPlaceOn(tile, team);
    },
    drawPlace(x,y,rotation,valid) {
        if (!Vars.world.tile(x, y)) { return; }
        if (!核弹限制.canBuild(Vars.player.team())) {
            this.drawPlaceText(
                Core.bundle.format("message.光耀旧世界.核弹限制",1),
                x, y, valid
            );
        }
    },
});
核弹.category = Category.logic;
核弹.buildCostMultipler = 0.000001;
核弹.buildType = prov(() => {
    return new JavaAdapter(NuclearReactor.NuclearReactorBuild, {
        // create(block, team) {
        //     this.super$create(block, team);
        //     addBuild(team);
        // },
        add() {
            this.super$add();
            if (this.team != Team.derelict) {
                核弹限制.addBuild(this.team);
            }
        },
        readBase(read) {
            this.super$readBase(read);
            if (this.team != Team.derelict) {
                核弹限制.addBuild(this.team);
            }
        },
        remove() {
            if (this.added) { 核弹限制.removeBuild(this.team); }
            this.super$remove();
        },			
		/*onDestroyed() {
			//this.super$onDestroyed;
			Damage.damage(this.x, this.y, 2500, 1500);
			Damage.dynamicExplosion(this.x, this.y, 1000.0, 10000.0, 100.0, 2000.0, true);
		}*/
    }, 核弹);
});


const 超速限制 = createBuildLimit(1);

var 超速 = extend(OverdriveProjector, 'cs-x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
    canPlaceOn(tile, team) {
        if (!超速限制.canBuild(team)) {
            return false;
        }
        return this.super$canPlaceOn(tile, team);
    },
    drawPlace(x,y,rotation,valid) {
        if (!Vars.world.tile(x, y)) { return; }
        if (!超速限制.canBuild(Vars.player.team())) {
            this.drawPlaceText(
                Core.bundle.format("message.光耀旧世界.超速限制",1),
                x, y, valid
            );
        }
    },
});
超速.category = Category.logic;
超速.buildCostMultipler = 0.000001;
超速.buildType = prov(() => {
    return new JavaAdapter(OverdriveProjector.OverdriveBuild, {
        // create(block, team) {
        //     this.super$create(block, team);
        //     addBuild(team);
        // },
        add() {
            this.super$add();
            if (this.team != Team.derelict) {
                超速限制.addBuild(this.team);
            }
        },
        readBase(read) {
            this.super$readBase(read);
            if (this.team != Team.derelict) {
                超速限制.addBuild(this.team);
            }
        },
        remove() {
            if (this.added) { 超速限制.removeBuild(this.team); }
            this.super$remove();
        },
    }, 超速);
});


const 护盾限制 = createBuildLimit(1);

var 护盾 = extend(ForceProjector, 'hd-x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
    canPlaceOn(tile, team) {
        if (!护盾限制.canBuild(team)) {
            return false;
        }
        return this.super$canPlaceOn(tile, team);
    },
    drawPlace(x,y,rotation,valid) {
        if (!Vars.world.tile(x, y)) { return; }
        if (!护盾限制.canBuild(Vars.player.team())) {
            this.drawPlaceText(
                Core.bundle.format("message.光耀旧世界.护盾限制",1),
                x, y, valid
            );
        }
    },
});
护盾.category = Category.logic;
护盾.buildCostMultipler = 0.000001;
护盾.buildType = prov(() => {
    return new JavaAdapter(ForceProjector.ForceBuild, {
        // create(block, team) {
        //     this.super$create(block, team);
        //     addBuild(team);
        // },
        add() {
            this.super$add();
            if (this.team != Team.derelict) {
                护盾限制.addBuild(this.team);
            }
        },
        readBase(read) {
            this.super$readBase(read);
            if (this.team != Team.derelict) {
                护盾限制.addBuild(this.team);
            }
        },
        remove() {
            if (this.added) { 护盾限制.removeBuild(this.team); }
            this.super$remove();
        },
    }, 护盾);
});