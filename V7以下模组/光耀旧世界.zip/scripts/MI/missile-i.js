//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const myItems = require('物品');
const dsGlobal = require('前置/ds-global');

const bul = require("MI/strikeBulletType");
const eff = require("MI/effect");

const trail = eff.trailEffect(50, false, 1);
trail.layer = Layer.bullet;

const boom = eff.scaledLargeBlast(0.5);

const 导弹 = bul.strikeBullet(false, 0, 6, false, false, true);
导弹.width = 6;
导弹.height = 8;
导弹.engineSize = 5;
导弹.trailSize = 0.2;
导弹.bulletOffset = 4;
导弹.damage = 25;
导弹.splashDamage = 72;
导弹.splashDamageRadius = 30;
导弹.speed = 2.4;
导弹.homingPower = 0.035;
导弹.homingRange = 200;
导弹.cooldown = 0.001;
导弹.lifetime = 120;
导弹.elevation = 500;
导弹.riseTime = 40;
导弹.fallTime = 25;
导弹.ammoMultiplier = 6;
导弹.targetRad = 0.5;
导弹.hitSound = Sounds.explosion;
导弹.collidesAir = false;
导弹.hitShake = 3;
导弹.weaveWidth = 12;
导弹.weaveSpeed = 1;
导弹.trailParam = 3;
导弹.trailEffect = trail;
导弹.despawnEffect = boom;

const 蜂群导弹平台 = extendContent(ItemTurret, "蜂群导弹平台", {
  isHidden() { return !dsGlobal.掠夺者科技封锁(); },
  load(){
    this.super$load();
    this.heatRegions = [];
    for(var i = 0; i < 9; i++){
      this.heatRegions[i] = Core.atlas.find("光耀旧世界-missile-i-heat-" + i);
    }
  },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	}
});

蜂群导弹平台.buildType = ent => {
  ent = extendContent(ItemTurret.ItemTurretBuild, 蜂群导弹平台, {
    setEffs(){
      this.heats = [];
      for(var i = 0; i < 9; i++){
        this.heats[i] = 0;
      }
      this.firing = false;
    },
    draw(){
      Draw.rect(蜂群导弹平台.baseRegion, this.x, this.y);
      Draw.rect(蜂群导弹平台.region, this.x, this.y);
      
      for(var i = 0; i < 9; i++){
        if(蜂群导弹平台.heatRegions[i] != Core.atlas.find("error") && this.heats[i] > 0.001){
          Draw.color(蜂群导弹平台.heatColor, this.heats[i]);
          Draw.blend(Blending.additive);
          Draw.rect(蜂群导弹平台.heatRegions[i], this.x, this.y);
          Draw.blend();
          Draw.color();
        }
      }
    },
    updateTile(){
      this.super$updateTile();
      for(var i = 0; i < 9; i++){
        this.heats[i] = Mathf.lerpDelta(this.heats[i], 0, 蜂群导弹平台.cooldown);
      }
    },
    updateCooling(){
      if(!this.firing){
        const liquid = this.liquids.current();
        var maxUsed = 蜂群导弹平台.consumes.get(ConsumeType.liquid).amount;

        var used = Math.min(Math.min(this.liquids.get(liquid), maxUsed * Time.delta), Math.max(0, ((蜂群导弹平台.reloadTime - this.reload) / 蜂群导弹平台.coolantMultiplier) / liquid.heatCapacity)) * this.baseReloadSpeed();
        this.reload += used * liquid.heatCapacity * 蜂群导弹平台.coolantMultiplier;
        this.liquids.remove(liquid, used);

        if(Mathf.chance(0.06 * used)){
          蜂群导弹平台.coolEffect.at(this.x + Mathf.range(蜂群导弹平台.size * Vars.tilesize / 2), this.y + Mathf.range(蜂群导弹平台.size * Vars.tilesize / 2));
        }
      }
    },
    updateShooting(){
      if(this.reload > 蜂群导弹平台.reloadTime && !this.firing){
        var type = this.peekAmmo();
        
        this.shoot(type);
        
        this.reload = 0;
      }else if(!this.firing){
        this.reload += Time.delta * this.peekAmmo().reloadMultiplier * this.baseReloadSpeed();
      }
    },
    shoot(type){
      this.firing = true;
      
      for(var i = 0; i < 蜂群导弹平台.shots; i++){
        const sel = i;
        Time.run(蜂群导弹平台.burstSpacing * i, () => {
          if(!this.isValid() || !this.hasAmmo()) return;
          var x = 蜂群导弹平台.xOffsets[sel] + this.x;
          var y = 蜂群导弹平台.yOffsets[sel] + this.y
          
          type.create(this, this.team, x, y, this.rotation + Mathf.range(蜂群导弹平台.inaccuracy), -1, 1 + Mathf.range(蜂群导弹平台.velocityInaccuracy), 1, [x, y, 0, false]);
          this.effects();
          this.useAmmo();
          this.heats[sel] = 1;
        });
      }
      
      Time.run(蜂群导弹平台.burstSpacing * 蜂群导弹平台.shots, () => {
        this.firing = false;
      });
    }
  });
  ent.setEffs();
  return ent;
};
var offset = 8;
var shift = 1;
蜂群导弹平台.category = Category.logic;
蜂群导弹平台.localizedName = "蜂群导弹平台";
蜂群导弹平台.burstSpacing = 5;
蜂群导弹平台.shots = 9;
蜂群导弹平台.inaccuracy = 45;
蜂群导弹平台.ammo(F.fi("能源水晶"), 导弹);
蜂群导弹平台.shootEffect = Fx.none;
蜂群导弹平台.smokeEffect = Fx.none;
蜂群导弹平台.maxAmmo = 50;
蜂群导弹平台.xOffsets = [-offset, 0, offset, -offset + shift, 0, offset - shift, -offset, 0, offset];
蜂群导弹平台.yOffsets = [offset, offset - shift, offset, 0, 0, 0, -offset, -offset + shift, -offset];
蜂群导弹平台.rotateSpeed = 9999;
蜂群导弹平台.requirements = ItemStack.with(
	F.fi("锡"), 1500, 
	F.fi("白银"), 1200, 
	F.fi("黄金"), 500, 
	myItems.掠夺者科技点, (50 * 3 * 3)
);
F.techNode(F.fb("掠夺者平台"), 蜂群导弹平台, ItemStack.with(
	F.fi("锡"), 1500 * 25, 
	F.fi("白银"), 1200 * 25, 
	F.fi("黄金"), 500 * 25, 
	myItems.普通科技点, (60 * 3 * 3)
));