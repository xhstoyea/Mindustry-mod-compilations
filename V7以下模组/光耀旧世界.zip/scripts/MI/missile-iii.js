//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const myItems = require('物品');
const dsGlobal = require('前置/ds-global');


const bul = require("MI/nukeBulletType");
const type = require("MI/missileTurretType");
const eff = require("MI/effect");

const trail = eff.trailEffect(240, false, 1);
trail.layer = Layer.bullet;

const boom = eff.scaledNuclearExplosion(4, 0.75, 80, true);

const 导弹 = bul.nukeBullet(true, 30, 20, true, true, false);
导弹.sprite = "光耀旧世界-nuke";
导弹.width = 20;
导弹.height = 40;
导弹.riseEngineSize = 24;
导弹.fallEngineSize = 14;
导弹.trailSize = 1;
导弹.bulletOffset = 20;
导弹.damage = 10000;
导弹.splashDamage = 3000;
导弹.splashDamageRadius = 800;
导弹.speed = 1;
导弹.homingPower = 0.05;
导弹.homingRange = 4440;
导弹.lifetime = 6000;
导弹.elevation = 1000;
导弹.riseTime = 300;
导弹.fallTime = 70;
导弹.ammoMultiplier = 1;
导弹.hitSound = Sounds.bang;
导弹.hitShake = 150;
导弹.trailParam = 8;
导弹.targetRad = 2;
导弹.trailChance = 0.2;
导弹.trailEffect = trail;
导弹.riseSpin = 720;
导弹.fallSpin = 180;
导弹.despawnEffect = boom;
导弹.targetPred = (u, x, y) => -u.maxHealth;

const 战略导弹平台 = type.missileTurret(false, ItemTurret, ItemTurret.ItemTurretBuild, "战略导弹平台", {
	isHidden() { return !dsGlobal.掠夺者科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	}
}, {});
战略导弹平台.category = Category.logic;
战略导弹平台.ammo(F.fi("能源水晶"), 导弹);
战略导弹平台.ammoPerShot = 50;
战略导弹平台.maxAmmo = 50;
战略导弹平台.reloadTime = 3000;
战略导弹平台.outlineIcon = false;
战略导弹平台.shootLength = 0;
战略导弹平台.localizedName = "战略导弹平台";
战略导弹平台.requirements = ItemStack.with(
	F.fi("锡"), 2500, 
	F.fi("白银"), 1800, 
	F.fi("黄金"), 750, 
	F.fi("黑金石"), 550, 
	F.fi("电磁银"), 350, 
	myItems.掠夺者科技点, (50 * 7 * 7)
);
F.techNode(F.fb("战术导弹平台"), 战略导弹平台, ItemStack.with(
	F.fi("锡"), 2500 * 25, 
	F.fi("白银"), 1800 * 25, 
	F.fi("黄金"), 750 * 25, 
	F.fi("黑金石"), 550 * 25, 
	F.fi("电磁银"), 350 * 25, 
	myItems.普通科技点, (60 * 7 * 7)
));