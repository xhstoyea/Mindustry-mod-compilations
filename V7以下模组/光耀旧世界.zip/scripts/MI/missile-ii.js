//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const myItems = require('物品');
const dsGlobal = require('前置/ds-global');

const bul = require("MI/nukeBulletType");
const type = require("MI/missileTurretType");
const eff = require("MI/effect");

const trail = eff.trailEffect(120, false, 1);
trail.layer = Layer.bullet;

const boom = eff.scaledLargeBlast(1.5);

const 导弹 = bul.nukeBullet(true, 15, 10, true, true, false);
导弹.sprite = "光耀旧世界-strike";
导弹.riseEngineSize = 16;
导弹.fallEngineSize = 8;
导弹.trailSize = 0.7;
导弹.damage = 80;
导弹.splashDamage = 750;
导弹.splashDamageRadius = 64;
导弹.speed = 1;
导弹.homingPower = 0.05;
导弹.homingRange = 320;
导弹.lifetime = 1000;
导弹.elevation = 600;
导弹.riseTime = 90;
导弹.fallTime = 45;
导弹.hitSound = Sounds.bang;
导弹.hitShake = 8;
导弹.trailParam = 5;
导弹.trailChance = 0.2;
导弹.trailEffect = trail;
导弹.despawnEffect = boom;
导弹.riseSpin = 360;
导弹.fallSpin = 135;
导弹.ammoMultiplier = 1;
导弹.unitSort = (u, x, y) => -u.maxHealth + Mathf.dst2(x, y, u.x, u.y);

const 战术导弹平台 = type.missileTurret(false, ItemTurret, ItemTurret.ItemTurretBuild, "战术导弹平台", {
	isHidden() { return !dsGlobal.掠夺者科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	}
}, {});
战术导弹平台.category = Category.logic;
战术导弹平台.ammo(F.fi("能源水晶"), 导弹);
战术导弹平台.ammoPerShot = 8;
战术导弹平台.maxAmmo = 50;
战术导弹平台.localizedName = "战术导弹平台";
战术导弹平台.unitSort = (u, x, y) => -u.maxHealth;
战术导弹平台.requirements = ItemStack.with(
	F.fi("锡"), 1500, 
	F.fi("白银"), 1200, 
	F.fi("黄金"), 550, 
	F.fi("黑金石"), 350, 
	myItems.掠夺者科技点, (50 * 4 * 4)
);
F.techNode(F.fb("蜂群导弹平台"), 战术导弹平台, ItemStack.with(
	F.fi("锡"), 1500 * 25, 
	F.fi("白银"), 1200 * 25, 
	F.fi("黄金"), 550 * 25, 
	F.fi("黑金石"), 350 * 25, 
	myItems.普通科技点, (60 * 4 * 4)
));