//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const C = require("colors");

const myItems = require('物品');
const 核心 = require('核心生产');

const lib = require('前置/lib');
const dsGlobal = require('前置/ds-global');

const 蛋白质工厂 = extendContent(GenericCrafter, "蛋白质工厂", {
	isHidden() { return !dsGlobal.虫族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
蛋白质工厂.localizedName = "蛋白质工厂";
蛋白质工厂.size = 2;
蛋白质工厂.hasItems = true;
蛋白质工厂.craftTime = 30;
蛋白质工厂.health = 750;
蛋白质工厂.itemCapacity = 50;
蛋白质工厂.drawer = new DrawGlow();
蛋白质工厂.buildVisibility = BuildVisibility.shown;
蛋白质工厂.category = Category.logic;
蛋白质工厂.buildCostMultipler = 0.000001;
蛋白质工厂.outputItem = new ItemStack(myItems.蛋白质, 1);
蛋白质工厂.consumes.items(
	new ItemStack(myItems.血肉, 2)
);
蛋白质工厂.requirements = ItemStack.with(
	myItems.骨物质, 120, 
	myItems.虫族科技点, (50 * 2 * 2)
);

const DNA工厂 = extendContent(GenericCrafter, "DNA工厂", {
	isHidden() { return !dsGlobal.虫族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
DNA工厂.localizedName = "DNA工厂";
DNA工厂.size = 3;
DNA工厂.hasItems = true;
DNA工厂.craftTime = 20;
DNA工厂.health = 1250;
DNA工厂.itemCapacity = 30;
DNA工厂.drawer = new DrawGlow();
DNA工厂.buildVisibility = BuildVisibility.shown;
DNA工厂.category = Category.logic;
DNA工厂.buildCostMultipler = 0.000001;
DNA工厂.outputItem = new ItemStack(myItems.DNA, 1);
DNA工厂.consumes.items(
	new ItemStack(myItems.蛋白质, 15), 
	new ItemStack(myItems.血肉, 15)
);
DNA工厂.requirements = ItemStack.with(
	myItems.灵光, 690, 
	myItems.血肉, 470, 
	myItems.骨物质, 350, 
	myItems.虫族科技点, (50 * 3 * 3)
);

const 虫卵工厂 = extendContent(GenericCrafter, "虫卵工厂", {
	isHidden() { return !dsGlobal.虫族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
虫卵工厂.localizedName = "虫卵工厂";
虫卵工厂.size = 2;
虫卵工厂.hasItems = true;
虫卵工厂.craftTime = 60;
虫卵工厂.health = 800;
虫卵工厂.itemCapacity = 50;
虫卵工厂.drawer = new DrawGlow();
虫卵工厂.buildVisibility = BuildVisibility.shown;
虫卵工厂.category = Category.logic;
虫卵工厂.buildCostMultipler = 0.000001;
虫卵工厂.outputItem = new ItemStack(myItems.虫卵, 1);
虫卵工厂.consumes.items(
	new ItemStack(myItems.骨物质, 1), 
	new ItemStack(myItems.蛋白质, 3), 
	new ItemStack(myItems.灵光, 5)
);
虫卵工厂.requirements = ItemStack.with(
	myItems.血肉, 350, 
	myItems.骨物质, 250, 
	myItems.虫族科技点, (50 * 2 * 2)
);

const 进阶虫卵工厂 = extendContent(GenericCrafter, "进阶虫卵工厂", {
	isHidden() { return !dsGlobal.虫族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
进阶虫卵工厂.localizedName = "进阶虫卵工厂";
进阶虫卵工厂.size = 4;
进阶虫卵工厂.hasItems = true;
进阶虫卵工厂.craftTime = 180;
进阶虫卵工厂.health = 1400;
进阶虫卵工厂.itemCapacity = 50;
进阶虫卵工厂.drawer = new DrawGlow();
进阶虫卵工厂.buildVisibility = BuildVisibility.shown;
进阶虫卵工厂.category = Category.logic;
进阶虫卵工厂.buildCostMultipler = 0.000001;
进阶虫卵工厂.outputItem = new ItemStack(myItems.进阶虫卵, 1);
进阶虫卵工厂.consumes.items(
	new ItemStack(myItems.血肉, 35), 
	new ItemStack(myItems.蛋白质, 25), 
	new ItemStack(myItems.虫卵, 1), 
	new ItemStack(myItems.DNA, 5)
);
进阶虫卵工厂.requirements = ItemStack.with(
	myItems.灵光, 850, 
	myItems.血肉, 680, 
	myItems.骨物质, 550, 
	myItems.虫族科技点, (50 * 4 * 4)
);

const 基因突变物工厂 = extendContent(GenericCrafter, "基因突变物工厂", {
	isHidden() { return !dsGlobal.虫族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
基因突变物工厂.localizedName = "基因突变物工厂";
基因突变物工厂.size = 5;
基因突变物工厂.hasItems = true;
基因突变物工厂.craftTime = 180;
基因突变物工厂.health = 1400;
基因突变物工厂.itemCapacity = 50;
基因突变物工厂.drawer = new DrawGlow();
基因突变物工厂.buildVisibility = BuildVisibility.shown;
基因突变物工厂.category = Category.logic;
基因突变物工厂.buildCostMultipler = 0.000001;
基因突变物工厂.outputItem = new ItemStack(myItems.基因突变物, 1);
基因突变物工厂.mapColor = Color.valueOf("66ffff");
基因突变物工厂.hasColor = true;
基因突变物工厂.outlineColor = Color.valueOf("ff0000");
基因突变物工厂.outlineColor = Color.valueOf("ff0000");
基因突变物工厂.outlineIcon = true;
基因突变物工厂.consumes.items(
	new ItemStack(myItems.虫族进阶科技点, 15), 
	new ItemStack(myItems.DNA, 25), 
	new ItemStack(myItems.蛋白质, 50)
);
基因突变物工厂.requirements = ItemStack.with(
	myItems.灵光, 1350, 
	myItems.血肉, 900, 
	myItems.骨物质, 750, 
	myItems.虫族科技点, (50 * 5 * 5)
);

F.techNode(核心.虫族母巢生产, 蛋白质工厂, ItemStack.with(
	myItems.骨物质, (120 * 25)
));
F.techNode(蛋白质工厂, DNA工厂, ItemStack.with(
	myItems.灵光, (690 * 25), 
	myItems.血肉, (470 * 25), 
	myItems.骨物质, (350 * 25)
));
F.techNode(蛋白质工厂, 虫卵工厂, ItemStack.with(
	myItems.血肉, (350 * 25), 
	myItems.骨物质, (250 * 25)
));
F.techNode(蛋白质工厂, 进阶虫卵工厂, ItemStack.with(
	myItems.灵光, (850 * 25), 
	myItems.血肉, (680 * 25), 
	myItems.骨物质, (550 * 25)
));
F.techNode(DNA工厂, 基因突变物工厂, ItemStack.with(
	myItems.灵光, (1350 * 25), 
	myItems.血肉, (900 * 25), 
	myItems.骨物质, (750 * 25)
));
//
//
//
//
//
exports.强化锡金工厂 = (() => {
const myblock = extendContent(GenericSmelter, "强化锡金工厂", {
	isHidden() { return !dsGlobal.人族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myblock.localizedName = "强化锡金工厂";
myblock.size = 3;
myblock.hasItems = true;
myblock.craftTime = 60;
myblock.health = 800;
myblock.itemCapacity = 50;
myblock.buildVisibility = BuildVisibility.shown;
myblock.category = Category.logic;
myblock.buildCostMultipler = 0.000001;
myblock.consumes.power(10);
myblock.outputItem = new ItemStack(myItems.强化锡金, 1);
myblock.consumes.items(
	new ItemStack(myItems.锡, 4),
	new ItemStack(myItems.黄金, 1),
	new ItemStack(Items.surgeAlloy, 2),
);
myblock.requirements = ItemStack.with(
	Items.graphite, 450, 
	myItems.白银, 350, 
	myItems.锡, 350, 
	myItems.人族科技点, (50 * 3 * 3)
);
myblock.buildType = () => {
	const ent = extendContent(GenericSmelter.SmelterBuild, myblock, {
        draw(){
            this.super$draw();

            if(this.warmup > 0.0 && this.block.flameColor.a > 0.001){
				Draw.color(F.fi("强化锡金").color);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.1)*0.2) * this.warmup);
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-强化锡金工厂-heat"), this.x, this.y);
				Draw.blend();
                Draw.reset();
            }
        }
	});
	return ent;
};
return myblock;
})();

exports.能量结晶工厂 = (() => {
const myblock = extendContent(GenericSmelter, "能量结晶工厂", {
	isHidden() { return !dsGlobal.人族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myblock.localizedName = "能量结晶工厂";
myblock.size = 4;
myblock.hasItems = true;
myblock.craftTime = 240;
myblock.health = 1000;
myblock.itemCapacity = 50;
myblock.buildVisibility = BuildVisibility.shown;
myblock.category = Category.logic;
myblock.buildCostMultipler = 0.000001;
myblock.consumes.power(30);
myblock.outputItem = new ItemStack(myItems.能量结晶, 2);
myblock.consumes.items(
	new ItemStack(Items.surgeAlloy, 2),
	new ItemStack(myItems.强化锡金, 1),
	new ItemStack(myItems.白银, 2),
	new ItemStack(myItems.黄金, 1),
);
myblock.requirements = ItemStack.with(
	Items.graphite, 800, 
	Items.titanium, 650, 
	Items.thorium, 650, 
	myItems.白银, 450, 
	myItems.锡, 450, 
	myItems.黄金, 150, 
	myItems.人族科技点, (50 * 4 * 4)
);
myblock.buildType = () => {
	const ent = extendContent(GenericSmelter.SmelterBuild, myblock, {
        draw(){
            this.super$draw();

            if(this.warmup > 0.0 && this.block.flameColor.a > 0.001){
				Draw.color(F.c("ffdd55"));
				Draw.alpha((0.25 + Mathf.sin(Time.time*0.1)*0.1) * this.warmup);
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-能量结晶工厂-heat"), this.x, this.y);
				Draw.blend();
                Draw.reset();
            }
        }
	});
	return ent;
};
return myblock;
})();

exports.能量合金工厂 = (() => {
const myblock = extendContent(GenericSmelter, "能量合金工厂", {
	isHidden() { return !dsGlobal.人族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
	load() {
		this.super$load();
		this.topRegion = Core.atlas.find("clear");
	}
});
myblock.localizedName = "能量合金工厂";
myblock.size = 3;
myblock.hasItems = true;
myblock.craftTime = 180;
myblock.health = 950;
myblock.itemCapacity = 150;
myblock.buildVisibility = BuildVisibility.shown;
myblock.category = Category.logic;
myblock.consumes.power(15);
myblock.buildCostMultipler = 0.000001;
myblock.outputItem = new ItemStack(myItems.能量合金, 1);
myblock.consumes.items(
	new ItemStack(Items.thorium, 10),
	new ItemStack(Items.surgeAlloy, 5),
	new ItemStack(myItems.黄金, 5)
);
myblock.requirements = ItemStack.with(
	Items.titanium, 500, 
	Items.thorium, 500, 
	myItems.白银, 350, 
	myItems.锡, 350, 
	myItems.人族科技点, (50 * 3 * 3)
);
myblock.buildType = () => {
	const ent = extendContent(GenericSmelter.SmelterBuild, myblock, {
        draw(){
            this.super$draw();

            if(this.warmup > 0.0 && this.block.flameColor.a > 0.001){
				Draw.color(F.fi("能量合金").color);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.2)*0.1) * this.warmup);
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-能量合金工厂-heat"), this.x, this.y);
				Draw.blend();
                Draw.reset();
            }
        }
	});
	return ent;
};
return myblock;
})();

F.techNode(核心.人族基地生产, exports.强化锡金工厂, ItemStack.with(
	Items.graphite, 450 * 25, 
	myItems.白银, 350 * 25, 
	myItems.锡, 350 * 25, 
	myItems.普通科技点, (60 * 3 * 3)
));
F.techNode(exports.强化锡金工厂, exports.能量结晶工厂, ItemStack.with(
	Items.graphite, 800 * 25, 
	Items.titanium, 650 * 25, 
	Items.thorium, 650 * 25, 
	myItems.白银, 450 * 25, 
	myItems.锡, 450 * 25, 
	myItems.黄金, 150 * 25, 
	myItems.普通科技点, (60 * 4 * 4)
));
F.techNode(核心.人族基地生产, exports.能量合金工厂, ItemStack.with(
	Items.titanium, 500 * 25, 
	Items.thorium, 500 * 25, 
	myItems.白银, 350 * 25, 
	myItems.锡, 350 * 25, 
	myItems.普通科技点, (60 * 3 * 3)
));
//
//
//
//
//
exports.电磁银工厂 = (() => {
const myblock = extendContent(GenericSmelter, "电磁银工厂", {
	isHidden() { return !dsGlobal.掠夺者科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
	load() {
		this.super$load();
		this.topRegion = Core.atlas.find("clear");
	}
});
myblock.localizedName = "电磁银工厂";
myblock.size = 3;
myblock.hasItems = true;
myblock.craftTime = 180;
myblock.health = 950;
myblock.itemCapacity = 150;
myblock.buildVisibility = BuildVisibility.shown;
myblock.category = Category.logic;
myblock.consumes.power(30);
myblock.buildCostMultipler = 0.000001;
myblock.outputItem = new ItemStack(myItems.电磁银, 5);
myblock.consumes.items(
	new ItemStack(Items.thorium, 10),
	new ItemStack(Items.surgeAlloy, 5),
	new ItemStack(myItems.白银, 5)
);
myblock.requirements = ItemStack.with(
	Items.titanium, 450, 
	Items.thorium, 450, 
	myItems.白银, 450, 
	myItems.掠夺者科技点, (50 * 3 * 3)
);
myblock.buildType = () => {
	const ent = extendContent(GenericSmelter.SmelterBuild, myblock, {
        draw(){
            this.super$draw();

            if(this.warmup > 0.0 && this.block.flameColor.a > 0.001){
				Draw.color(F.fi("电磁银").color);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.2)*0.1) * this.warmup);
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-电磁银工厂-heat"), this.x, this.y);
				Draw.blend();
                Draw.reset();
            }
        }
	});
	return ent;
};
return myblock;
})();

exports.能源水晶工厂 = (() => {
const myblock = extendContent(GenericSmelter, "能源水晶工厂", {
	isHidden() { return !dsGlobal.掠夺者科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
	load() {
		this.super$load();
		this.topRegion = Core.atlas.find("clear");
	}
});
myblock.localizedName = "能源水晶工厂";
myblock.size = 4;
myblock.hasItems = true;
myblock.craftTime = 240;
myblock.health = 1250;
myblock.itemCapacity = 100;
myblock.buildVisibility = BuildVisibility.shown;
myblock.category = Category.logic;
myblock.consumes.power(50);
myblock.buildCostMultipler = 0.000001;
myblock.outputItem = new ItemStack(myItems.能源水晶, 1);
myblock.consumes.items(
	new ItemStack(Items.blastCompound, 5),
	new ItemStack(myItems.电磁银, 5)
);
myblock.requirements = ItemStack.with(
	myItems.锡, 600, 
	myItems.白银, 600, 
	myItems.黄金, 350, 
	Items.surgeAlloy, 50, 
	myItems.掠夺者科技点, (50 * 4 * 4)
);
myblock.buildType = () => {
	const ent = extendContent(GenericSmelter.SmelterBuild, myblock, {
        draw(){
            this.super$draw();

            if(this.warmup > 0.0 && this.block.flameColor.a > 0.001){
			    Tmp.c1.set(F.c("#ff0000")).lerp(F.c("#ffff00"), Mathf.sin(Time.time*0.2)*0.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.2)*0.1) * this.warmup);
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-能源水晶工厂-heat"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
            }
        }
	});
	return ent;
};
return myblock;
})();

F.techNode(核心.掠夺者平台生产, exports.电磁银工厂, ItemStack.with(
	Items.titanium, 450 * 25, 
	Items.thorium, 450 * 25, 
	myItems.白银, 450 * 25, 
	myItems.普通科技点, (60 * 3 * 3)
));
F.techNode(exports.电磁银工厂, exports.能源水晶工厂, ItemStack.with(
	myItems.锡, 600 * 25, 
	myItems.白银, 600 * 25, 
	myItems.黄金, 350 * 25, 
	Items.surgeAlloy, 50 * 25, 
	myItems.普通科技点, (60 * 4 * 4)
));

//

exports.矿物废水工厂 = (() => {
var myBlock = extendContent(GenericSmelter, '矿物废水工厂', {
	load() {
		this.super$load();
		this.topRegion = Core.atlas.find("clear");
	},
	isHidden() { return !dsGlobal.掠夺者科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
	drawer: new JavaAdapter(DrawBlock, {
        draw(entity) {
            Draw.rect(entity.block.region, entity.x, entity.y, 0);

            Draw.color(entity.block.outputLiquid.liquid.color);
            Draw.alpha(entity.liquids.get(entity.block.outputLiquid.liquid) / entity.block.liquidCapacity);
            Draw.rect(lib.loadRegion("矿物废水工厂-1"), entity.x, entity.y, 0);

            Draw.color(Liquids.slag.color);
            Draw.alpha(entity.liquids.get(Liquids.slag) / entity.block.liquidCapacity);
            Draw.rect(lib.loadRegion("矿物废水工厂-2"), entity.x, entity.y, 0);
        },
    }),
});
myBlock.buildType = () => {
	const ent = extendContent(GenericSmelter.SmelterBuild, myBlock, {
        draw(){
		this.super$draw();
			
		if(this.warmup > 0.0 && this.block.flameColor.a > 0.001){
			Draw.color(myItems.矿物废水.color);
			Draw.alpha((0.5 + Mathf.sin(Time.time*0.5)*0.8) * this.warmup);
			Draw.blend(Blending.additive);
			Draw.rect(Core.atlas.find("光耀旧世界-矿物废水工厂-3"), this.x, this.y);
			Draw.blend();
            Draw.reset();
        }
	}});
	return ent;
};
myBlock.outputLiquid = new LiquidStack(myItems.矿物废水, 25);
myBlock.liquidCapacity = 100;
myBlock.buildCostMultipler = 0.000001;
myBlock.category = Category.logic;
return myBlock;
})();
//
//
//
//
//
//
var wall = (() => {
	const armor = 5;
    const block = extend(Wall, '装甲墙', {
        isHidden() { return !dsGlobal.人族科技封锁(); },
		load(){
			this.super$load();
		},
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
        setStats() {
            this.super$setStats();
            if (armor > 0) this.stats.add(Stat.abilities, lib.getMessage('stat', 'blockArmor', armor));
        },
    })
    lib.setBuildingSimple(block, Wall.WallBuild, {
        damage(amount) {
            amount = Math.max(amount - armor, Vars.minArmorDamage * amount);
            this.super$damage(amount);
        },
		draw(){
			this.super$draw();
			
            Draw.color(Color.valueOf("9999ff"));
            Draw.alpha(Mathf.sin(Time.time*0.04)*1);
            Draw.blend(Blending.additive);
            Draw.rect(Core.atlas.find("光耀旧世界-装甲墙-top"), this.x, this.y);
            Draw.blend();
			Draw.reset();
		}
    });
	block.conveyorPlacement = true;
	block.variants = 0;
    block.size = 1;
    block.health = 950;
    block.requirements = ItemStack.with(myItems.能量合金, 8);
    block.buildVisibility = BuildVisibility.shown;
    block.category = Category.logic;
    return block;
})();

var wallLarge = (() => {
    const armor = 12;
    const block = extend(Wall, '大型装甲墙', {
        isHidden() { return !dsGlobal.人族科技封锁(); },
		load(){
			this.super$load();
		},
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
        setStats() {
            this.super$setStats();
            if (armor > 0) this.stats.add(Stat.abilities, lib.getMessage('stat', 'blockArmor', armor));
        },
    })
    lib.setBuildingSimple(block, Wall.WallBuild, {
        damage(amount) {
            amount = Math.max(amount - armor, Vars.minArmorDamage * amount);
            this.super$damage(amount);
        },
		draw(){
			this.super$draw();
			
            Draw.color(Color.valueOf("9999ff"));
            Draw.alpha(Mathf.sin(Time.time*0.04)*1);
            Draw.blend(Blending.additive);
            Draw.rect(Core.atlas.find("光耀旧世界-大型装甲墙-top"), this.x, this.y);
            Draw.blend();
			Draw.reset();
		}
    });
	block.conveyorPlacement = true;
	block.variants = 0;
    block.size = 2;
    block.health = wall.health * 4;
    block.requirements = ItemStack.with(myItems.能量合金, 35);
    block.buildVisibility = wall.buildVisibility;
    block.category = Category.logic;
    return block;
})();

/////////////////////////////////
exports.透明方块 = (() => {
var myBlock = extendContent(Wall, '透明方块', {
	isHidden() { return !dsGlobal.人族科技封锁() || !dsGlobal.掠夺者科技封锁() || !dsGlobal.虫族科技封锁() || !dsGlobal.暗星科技封锁() || !dsGlobal.光耀科技封锁(); },
});
myBlock.category = Category.logic;
return myBlock;
})();