//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const multiLib = require("前置/多合成前置");

const 合成台 = multiLib.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "合成台", [
  {
    input: {
      items: ["scrap/30", "sand/50"],
      power: 1
    },
    output:{
      items: ["光耀旧世界-废矿/5"]
    },
    craftTime: 60
  },
  {
    input: {
      items: ["scrap/60", "sand/100"],
	  liquids: ["water/15"],
      power: 2
    },
    output:{
      items: ["光耀旧世界-废矿/15"]
    },
    craftTime: 100
  },
  {
    input: {
      items: ["titanium/30", "metaglass/30", "graphite/10"],
      power: 2
    },
    output:{
      items: ["光耀旧世界-白金/5"]
    },
    craftTime: 120
  },
  {
    input: {
      items: ["titanium/60", "metaglass/60", "graphite/20"],
	  liquids: ["water/35"],
      power: 4
    },
    output:{
      items: ["光耀旧世界-白金/15"]
    },
    craftTime: 150
  },
  {
    input: {
      items: ["thorium/50", "coal/50", "spore-pod/10"],
      power: 2
    },
    output:{
      items: ["光耀旧世界-黑金石/5"]
    },
    craftTime: 120
  },
  {
    input: {
      items: ["thorium/100", "coal/100", "spore-pod/20"],
	  liquids: ["water/35"],
      power: 4
    },
    output:{
      items: ["光耀旧世界-黑金石/15"]
    },
    craftTime: 150
  }
], {},
function Extra(){});

合成台.localizedName = "合成台";
合成台.itemCapacity = 350;
合成台.liquidCapacity = 100;
合成台.size = 4;
合成台.health = 850;
合成台.craftEffect = Fx.pulverizeMedium;
合成台.updateEffect = Fx.none;
合成台.dumpToggle = true;
合成台.category = Category.logic;
合成台.buildVisibility = BuildVisibility.shown;
合成台.requirements = ItemStack.with(
	Items.copper, 2950,
	Items.lead, 3650,
	Items.graphite, 2760,
	Items.metaglass, 2460,
	Items.titanium, 2200,
	Items.silicon, 2000
);

F.techNode(F.fb("科技中心"), 合成台, ItemStack.with(
	Items.copper, 2950 * 15,
	Items.lead, 3650 * 15,
	Items.graphite, 2760 * 15,
	Items.metaglass, 2460 * 15,
	Items.titanium, 2200 * 15,
	Items.silicon, 2000 * 15
));