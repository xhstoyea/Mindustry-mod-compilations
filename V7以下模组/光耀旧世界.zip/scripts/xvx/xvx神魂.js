//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const lib = require('前置/lib');

const destruction = new Effect(60, e => {
  Draw.color(Pal.remove);
  Draw.alpha(e.fout());
  Lines.stroke(25 * e.fout());
  Lines.circle(e.x, e.y, e.fin()*300);
  Draw.alpha(1);
  Lines.stroke(50 * e.fout());
  Lines.circle(e.x, e.y, e.fin()*100);

  Angles.randLenVectors(e.id, 50, e.fin()*200, ( x, y ) => {
    Draw.color(Pal.remove, Color.black, e.finpow());
    Fill.circle(e.x + x, e.y + y, 25 * e.fout());
  });
  Angles.randLenVectors(e.id, 50, 200 * e.fin(), e.rotation, 360,(x, y) => {
    Draw.color(Pal.remove);
    Lines.stroke(1);
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fout() * 20);
  });
});

const shitassDeathEffect = new Effect(60, e => {
  Draw.color(Pal.remove);
  Lines.stroke(4 - (4 * e.finpow()));
  Lines.poly(e.x, e.y, 3, e.finpow() * 100, e.finpow() * 360);
  Lines.poly(e.x, e.y, 3, e.finpow() * 100, (0 - e.finpow()) * 360);
});

const deathBulletTrail = new Effect(20, e => {
  Draw.color(Pal.remove);
  Angles.randLenVectors(e.id, 4, 4, (x, y) => {
     Fill.circle(e.x + x, e.y + y, e.fout() * 2);
  });
});

const deathMissileTrail = new Effect(20, e => {
  Draw.color(Pal.remove, Color.black, e.fin());
  Fill.circle(e.x, e.y, e.fout() * 5);
});

const deathMissileHit = new Effect(30, e =>{ 
  Angles.randLenVectors(e.id, 20, 50 * e.finpow(), 
  e.rotation, 200, (x, y) => {
    Draw.color(Pal.remove, Color.black, e.fin());
    Fill.circle(e.x + x, e.y + y, e.fout() * 5);
    Lines.lineAngle(e.x + x * 2, e.y + y * 2, Mathf.angle(x, y), e.fout() * 10 );
  });

  Lines.stroke(5 - e.finpow() * 5);
  Lines.circle(e.x, e.y, e.finpow() * 100);
})

const deathLaserShoot = new Effect(20, e => {
  Draw.color(Color.black);
  Fill.circle(e.x, e.y, 10 * e.fslope());

  Angles.randLenVectors(e.id, 10, 30 - (e.finpow() * 30), (x, y) => {
    Draw.color(Color.black, Pal.remove, e.finpow());
    Fill.circle(e.x + x, e.y + y, e.fin() * 8);
  });
  Draw.color(Pal.remove);
  Fill.circle(e.x, e.y, 8 * e.fslope());
})

const deathHaloShoot = new Effect(45, e => {
  Draw.color(Pal.remove)
  Lines.stroke(e.fout()*2)
  Lines.poly(e.x, e.y, 3, e.fin() * 100, e.fin() * 360)
  Lines.poly(e.x, e.y, 3, e.fin() * 100, e.fout() * 360)

  Draw.alpha(1)
  Fill.poly(e.x, e.y, 3, e.fslope() * 20, e.fout() * 720)
  Fill.poly(e.x, e.y, 3, e.fslope() * 20, e.fin() * 360)
});

const shitassDeathBlaster = extend(Weapon, {
  firstShotDelay: 10,
  x: 15,
  reload: 15,
  mirror: true,
  alternate: true,
  shootStatus: StatusEffects.unmoving,
  shootStatusDuration: 25,
  shootSound: lib.loadSound('deathLaser')
});

const shitassDeathCannon = extend(Weapon, {
  reload: 120,
  x: 10,
  y: 10,
  shots: 3,
  shotDelay: 5,
  spacing: 5,
  mirror: true,
  alternate: true,
  rotate: true,
  shootSound: Sounds.explosion
});

const shitassDeathLauncher = extend(Weapon, {
  reload: 30,
  shots: 6,
  shotDelay: 2,
  spacing:5,
  x: 10,
  y: 0,
  shootSound: Sounds.missile,
  rotate: true,
  mirror: true
});

const shitassHalo = extend(Weapon, {
  shots: 90,
  spacing: 4,
  shotDelay: 0.5,
  reload: 600,
  shootCone: 360,
  x: 0,
  y: 0,
  shootSound: lib.loadSound('deathHalo')
});

// Bullets
const shitassDeathLaser = extend(LaserBulletType, {
  length: 500,
  width: 25,
  lightningSpacing: 15,
  lightningDelay: 0.5,
  lifetime: 15,
  damage: 350,
  lightningColor: Pal.remove,
  colors: [ Pal.remove, Color.white ],
  shootEffect: deathLaserShoot
});

const shitassDeathHalo = extend(LaserBulletType, {
  length: 500,
  width: 25,
  damage: 500,
  shootEffect: deathHaloShoot,
  lifetime: 7.5,
  colors: [ Pal.remove, Color.white ]
});

const shitassDeathMissile = extend(MissileBulletType, {
  draw(b){
    Draw.color(Pal.remove);
    Fill.circle(b.x, b.y, 5);
  },
  damage: 200,
  splashDamage: 100,
  splashDamageRadius: 50,
  speed: 6,
  homingPower: 0.09,
  lifetime: 120,
  trailEffect: deathMissileTrail,
  weaveMag: 0.5,
  hitSound: Sounds.explosion,
  homingRange: 640,
  hitEffect: deathMissileHit
});
const shitassDeathBullet = extend(ArtilleryBulletType, {
  draw(b){
    Draw.color(Color.black);
    Fill.circle(b.x, b.y, 10);
    Draw.color(Pal.remove);
    Fill.circle(b.x, b.y, 8);
  },  
  damage: 500,
  splashDamage: 300,
  splashDamageRadius: 300,
  hitEffect: destruction,
  speed: 4,
  lifetime: 120,
  hitSound:  Sounds.explosionbig,
  lightning: 15,
  lightningLength: 30,
  lightningColor: Pal.remove,
  trailEffect: deathBulletTrail
});

shitassDeathBlaster.bullet = shitassDeathLaser;
shitassHalo.bullet = shitassDeathHalo;
shitassDeathCannon.bullet = shitassDeathBullet;
shitassDeathLauncher.bullet = shitassDeathMissile;

const 防 = require("xvx/伽马射线");

const xvx神魂 = extendContent(UnitType, "xvx神魂", {
	draw(unit){
		this.super$draw(unit);

		Draw.alpha(Mathf.sin(Time.time*0.04)*1);
		Draw.rect(Core.atlas.find("光耀旧世界-xvx神魂-cell0"), unit.x, unit.y);
		
		var z = Draw.z();
        Draw.z(Layer.blockUnder - 0.5);
		Draw.color(unit.team.color);
		Draw.alpha(0.5);
		Draw.rect(Core.atlas.find("光耀旧世界-BOSS贴图-内1"), unit.x, unit.y,  Time.time*0.6);
		Draw.rect(Core.atlas.find("光耀旧世界-BOSS贴图-内2"), unit.x, unit.y,  -Time.time*0.6);
		Draw.rect(Core.atlas.find("光耀旧世界-BOSS贴图-中1"), unit.x, unit.y,  Time.time*0.1);
		Draw.rect(Core.atlas.find("光耀旧世界-BOSS贴图-中2"), unit.x, unit.y,  -Time.time*0.1);
		Draw.rect(Core.atlas.find("光耀旧世界-BOSS贴图-外1"), unit.x, unit.y,  -Time.time*2.0);
		Draw.rect(Core.atlas.find("光耀旧世界-BOSS贴图-外2"), unit.x, unit.y,  -Time.time*1.8);
		Draw.rect(Core.atlas.find("光耀旧世界-BOSS贴图-圈"), unit.x, unit.y);
        Draw.z(z);
	},
	immunities: ObjectSet.with([
        防.die
    ]),
});

xvx神魂.health = 100000;
xvx神魂.speed = 3.5;
xvx神魂.flying = true;
xvx神魂.hitSize = 25;
xvx神魂.itemOffsetY = -11.5;
xvx神魂.engineOffset = 13;
xvx神魂.engineSize = 5;
xvx神魂.itemCapacity = 30000;
xvx神魂.mineSpeed = 1000;
xvx神魂.mineTier = 1000;
xvx神魂.buildSpeed = 1000;
xvx神魂.armor = 50;

xvx神魂.constructor = () => extend(UnitEntity, {})

xvx神魂.weapons.add(
  shitassDeathBlaster,
  shitassDeathCannon,
  shitassDeathLauncher,
  shitassHalo
);
