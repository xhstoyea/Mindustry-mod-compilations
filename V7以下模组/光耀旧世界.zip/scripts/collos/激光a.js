//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const myItems = require('物品');

const dsGlobal = require('前置/ds-global');

//// 
const hitMovingLaser = new Effect(30, e => {
    Angles.randLenVectors(e.id, 3, 4 + e.fin() * 10.0, 0, 360.0, new Floatc2({get(x, y){
        Draw.color(Color.white, F.fi("黄金").color, e.fout());
        Fill.square(e.x + x, e.y + y, 0.5 + e.fout() * 1.2, 45);
	}}))
});
//
const YellowBeamChargeBegin = new Effect(30, 300, e => {
    Draw.color(F.fi("黄金").color, Color.white, e.fin());
    Lines.stroke(e.fin() * 5);
    Lines.circle(e.x, e.y, e.fout() * 60);

    Angles.randLenVectors(e.id, 4, 10 + 80 * e.fout(), e.rotation, 50, new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 24);
    }}));
});
//
const YellowBeamCharge = new Effect(30, 300, e => {
    Draw.color(F.fi("黄金").color, Color.white, e.fin());
    Lines.stroke(e.fin() * 5);
    Lines.circle(e.x, e.y, e.fout() * 60.0);

    Angles.randLenVectors(e.id, 4, 15.0 + 160.0 * e.fout(), e.rotation, 10, new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 32);
    }}));
});
//
const thunderShoot = new Effect(50, e => {
    Angles.randLenVectors(e.id, 6, 10 + e.fin() * 80, e.rotation, 20, new Floatc2({get(x, y){
        Draw.color(Color.white, F.fi("黄金").color, e.fout());
        Fill.square(e.x + x, e.y + y, 0.5 + e.fout() * 2.5, 45);
	}}))
});
//
const dischargeShoot = new Effect(35, e => {
    Angles.randLenVectors(e.id, 6, 4.0 + e.fin() * 30.0, e.rotation, 10, new Floatc2({get(x, y){
        Draw.color(Color.white, F.fi("黄金").color, e.fout());
        Fill.square(e.x + x, e.y + y, 0.4 + e.fout() * 1.5, 45);
	}}))
});
//
const movingLaserOnExtend = new Effect(35, e => {
    Angles.randLenVectors(e.id, 3, 10.0 + e.fin() * 22.0, e.rotation, 10, new Floatc2({get(x, y){
        Draw.color(Color.white, F.fi("黄金").color, e.fout());
        Fill.square(e.x + x, e.y + y, 0.3 + e.fout(), 45);
	}}))
});
//
const YellowBeamFlare = new Effect(30, e => {
  Draw.color(Color.valueOf("FFFFFF44"));
  Draw.alpha(e.fout() * 0.3);
  Draw.blend(Blending.additive);
  Draw.rect("光耀旧世界-smoke", e.x, e.y, e.fin()*800, e.fin()*800*Mathf.random(1.5, 2.0));
  Draw.blend();
});       
      
const YellowBeamFlare2 = new Effect(30, e => {
  Draw.color(Color.valueOf("FFFFFF44"));
  Draw.alpha(e.fout() * 1);
  Draw.blend(Blending.additive);
  Draw.rect("光耀旧世界-smoke", e.x, e.y, 50, 50);
  Draw.blend();
});          
      
const YellowBeamFlare3 = new Effect(30, e => {
  Draw.color(Color.valueOf("FFFFFF44"));
  Draw.alpha(e.fout() * 1);
  Draw.blend(Blending.additive);
  Draw.rect("光耀旧世界-FlareWhite", e.x, e.y, 800*e.fin(), 800*e.fin());
  Draw.blend();
});   

  
const DischargeBullet = extend(BasicBulletType, {
    update(b){
        Lightning.create(b, F.fi("黄金").color, 30.0, b.x, b.y, Mathf.random(360.0), 3.0 + Mathf.random(2.0));
        
        var build = Vars.world.build(b.x, b.y);
        if(build instanceof Wall && build.block.insulated) b.absorb();
    }
});
DischargeBullet.hitEffect = hitMovingLaser;
DischargeBullet.despawnEffect = Fx.none;
DischargeBullet.pierce = false;
DischargeBullet.hittable = false;
DischargeBullet.absorbable = true
DischargeBullet.reflectable = false;
DischargeBullet.damage = 60;
DischargeBullet.speed = 3.0;
DischargeBullet.lifetime = 90;
DischargeBullet.hitSize = 14;
DischargeBullet.width = 15;
DischargeBullet.height = 15;

DischargeBullet.hitColor = F.fi("黄金").color;
DischargeBullet.frontColor = F.fi("黄金").color;
DischargeBullet.backColor = F.fi("黄金").color.cpy().mul(0.8);
 
const Discharge = extendContent(PowerTurret, "光球塔", {
	isHidden() { return !dsGlobal.人族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	}
});
Discharge.shootType = DischargeBullet;
Discharge.shootSound = Sounds.railgun;
Discharge.shootEffect = dischargeShoot;
Discharge.powerUse = 180;
Discharge.reloadTime = 60.0;
Discharge.ammoUseEffect = Fx.none;
Discharge.recoilAmount = 4.0;
Discharge.restitution = 0.03;
Discharge.range = 180.0;
Discharge.size = 3;
Discharge.category = Category.logic;
Discharge.buildVisibility = BuildVisibility.shown;
Discharge.localizedName = "光球塔";
Discharge.requirements = ItemStack.with(
	F.fi("锡"), 1200,
	F.fi("白银"), 750,
	F.fi("黄金"), 450,
	F.fi("强化锡金"), 150,
	myItems.人族科技点, (50 * 3 * 3)
);
F.techNode(F.fb("人族基地"), Discharge, ItemStack.with(
	F.fi("锡"), 1200 * 25,
	F.fi("白银"), 750 * 25,
	F.fi("黄金"), 450 * 25,
	F.fi("强化锡金"), 150 * 25,
	myItems.普通科技点, (60 * 3 * 3)
));

  /////
  /////
  /////
  
const MovingLaser = extend(BasicBulletType, {
    draw(b) {
    	if(b.data == null) return;
    
    	var Beams = b.data[2];
        var alpha = Mathf.clamp(b.time > this.lifetime - 20.0 ? 1.0 - (b.time - (this.lifetime - 20.0)) / 2.0 : 1.0);
    
        for(var i = 0; i < Beams.length; i++) {
            var Beam = Beams[i];
            
            Draw.color(F.fi("黄金").color);
            Draw.alpha((i == 0 || i == Beams.length - 1) ? ((i == Beams.length - 1) ? (Beams[0][4][0]) : (Beams[Beams.length-1][4][1])) : alpha);
            
            Lines.stroke(3.0);
        	Lines.line(Beam[0], Beam[1], Beam[2], Beam[3]);
            Lines.stroke(1.0);
            Draw.alpha(1.0);
            Draw.color();
        } 
    },
 
    update(b){
    	if(b.data == null) return;
    
    	const Beams = b.data[2];
        const PredBeam = Beams[Beams.length - 1];
    
        if(Beams[0][4][1] > 0.21); Beams[0][4][1] -= 0.2 * Time.delta;
        if(Beams[Beams.length-1][4][0] < 0.98); Beams[Beams.length-1][4][0] += 0.2 * Time.delta;
        
    	if(b.data == null) return;
    	if(b.timer.get(1) && b.data[1] > Beams.length * 32.0 && b.data[6]) {
    	    var v = new Vec2();
            
            var realLength = this.findLaserLength(b, 32.0, v);
            v.trns(b.rotation() + Mathf.range(20.0), realLength);
             
            movingLaserOnExtend.at(PredBeam[2], PredBeam[3], Angles.angle(PredBeam[2], PredBeam[3], PredBeam[2] + v.x, PredBeam[3] + v.y));
            Beams.push([PredBeam[2], PredBeam[3], PredBeam[2] + v.x, PredBeam[3] + v.y, [0.0, 1.0]]);
            if(realLength < 32.0) b.data[6] = false;
        };
        
        for(var i = 0; i < Beams.length; i++) { 
            var Beam = Beams[i];
            
	    	Damage.collideLine(b, b.team, Fx.none, Beam[0], Beam[1], Angles.angle(Beam[0], Beam[1], Beam[2], Beam[3]), 24.0);
        }
    },

    findLaserLength(b, length, v){
        var PredBeam = b.data[2][b.data[2].length - 1];
        
        Tmp.v1.trns(Angles.angle(PredBeam[2], PredBeam[3], PredBeam[2] + v.x, PredBeam[3] + v.y), length);

        var furthest = null;

        var found = Vars.world.raycast(
            World.toTile(PredBeam[2]), 
            World.toTile(PredBeam[3]), 
            World.toTile(PredBeam[2] + v.x), 
            World.toTile(PredBeam[3] + v.y), 
            new Geometry.Raycaster({accept: (x, y) => {
                furthest = Vars.world.build(x, y);
                
                if(furthest != null && furthest.team != b.team && (furthest.block.absorbLasers || furthest.block.insulated)) return true;
                return false;
            }}) 
        );

        return found && furthest != null ? Math.max(6.0, Mathf.dst(PredBeam[2], PredBeam[3], furthest.tile.worldx(), furthest.tile.worldy())) : length;
    },
    
    despawned(b) {
        this.hitSound.at(b);
    
    	b.data = null;
    } 
});

MovingLaser.hitColor = F.fi("黄金").color;
MovingLaser.hitEffect = hitMovingLaser;
MovingLaser.despawnEffect = Fx.none;
MovingLaser.pierce = false;
MovingLaser.hittable = false;
MovingLaser.absorbable = false;
MovingLaser.reflectable = false;
MovingLaser.damage = 32;
MovingLaser.speed = 4.8;
MovingLaser.lifetime = 70;
MovingLaser.drawSize = 1500;
 
 const Thunder = extendContent(PowerTurret, "电光塔", {
	isHidden() { return !dsGlobal.人族科技封锁(); },
	load(){
		this.super$load();
		
		this.region = F.tex("电光塔");
		this.baseRegion = F.tex("block-5");
	},
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
	icons(){
		return [
			F.tex("block-5"),
			F.tex("电光塔")
		];
    }
});
Thunder.buildType = () => {
	const ent = extendContent(PowerTurret.PowerTurretBuild, Thunder, {
        bullet(type, angle){
            var bx = this.x + this.block.tr.x;
            var by = this.y + this.block.tr.y;
            
            var lifeScl = type.scaleVelocity ? Mathf.clamp(Mathf.dst(bx, by, this.targetPos.x, this.targetPos.y) / type.range(), this.block.minRange / type.range(), this.blck.range / type.range()) : 1.0;
            var length = 28;
            
            var bu = type.create(this, this.team, bx, by, angle, 1.0 + Mathf.range(this.block.velocityInaccuracy), lifeScl);
            
            var v = new Vec2();
            v.trns(angle, length);
            
            var bx2 = bx + v.x;
            var by2 = by + v.y;
            
            bu.data = [angle, 360.0, [[bx, by, bx2, by2, [0.0, 1.0]]], length, bx, by, true];
        }
	});
	return ent;
};
Thunder.localizedName = "电光塔";
Thunder.shootType = MovingLaser;
Thunder.shootSound = loadSound("movingLaser");
Thunder.shootEffect = thunderShoot;
Thunder.powerUse = 20;
Thunder.reloadTime = 90.0;
Thunder.restitution = 0.01; 
Thunder.ammoUseEffect = Fx.none;
Thunder.recoilAmount = 6.0;
Thunder.range = 360;
Thunder.size = 5;
Thunder.buildCostMultiplier = 0.8;
Thunder.powerUse = 300;
Thunder.category = Category.logic;
Thunder.buildVisibility = BuildVisibility.shown;
Thunder.requirements = ItemStack.with(
	F.fi("锡"), 1500,
	F.fi("白银"), 1350,
	F.fi("黄金"), 1000,
	F.fi("强化锡金"), 750,
	F.fi("能量合金"), 300,
	myItems.人族科技点, (50 * 5 * 5)
);
F.techNode(F.fb("光球塔"), Thunder, ItemStack.with(
	F.fi("锡"), 1500 * 25,
	F.fi("白银"), 1350 * 25,
	F.fi("黄金"), 1000 * 25,
	F.fi("强化锡金"), 750 * 25,
	F.fi("能量合金"), 300 * 25,
	myItems.普通科技点, (60 * 5 * 5)
));
 
////
////
////
const energy = Color.valueOf("FFE93D");

const SunAbsorberLaser = extend(ContinuousLaserBulletType, {
	update: function(b){

		Effect.shake(5.0, 5.0, b.x, b.y);
        
        for(var i = 0; i < 2; i++) {
	        var v = new Vec2();
	        v.trns(b.rotation(), Mathf.random(25.0, 510.0));
	
	        var rot = Mathf.random(1.0) >= 0.5 ? 45 : -45;
	        Lightning.create(b.team, energy, 75, b.x + v.x, b.y + v.y, b.rotation()+(rot), Mathf.random(5, 10));
        };

        if(b.timer.get(1, 8)){
            YellowBeamFlare.at(b.x, b.y, b.rotation());
            YellowBeamFlare2.at(b.x, b.y, b.rotation()); 
            YellowBeamFlare3.at(b.x, b.y, b.rotation()); 
            
            Damage.collideLine(b, b.team, this.hitEffect, b.x, b.y, b.rotation(), 930.0, true);
        }
	}, 

    draw(b){
        /* float realLength = Damage.findLaserLength(b, length); */
        var fout = Mathf.clamp(b.time > b.lifetime - this.fadeTime ? 1.0 - (b.time - (this.lifetime - this.fadeTime)) / this.fadeTime : 1.0);
        var baseLen = /*realLength*/ this.length * fout;

        Lines.lineAngle(b.x, b.y, b.rotation(), baseLen);
        for(var s = 0; s < this.colors.length; s++){
            Draw.color(Tmp.c1.set(this.colors[s]).mul(1.0 + Mathf.absin(Time.time, 1.0, 0.1)));
            for(var i = 0; i < this.tscales.length; i++){
                Tmp.v1.trns(b.rotation() + 180.0, (this.lenscales[i] - 1.0) * 35.0);
                Lines.stroke((this.width + Mathf.absin(Time.time, this.oscScl, this.oscMag)) * fout * this.strokes[s] * this.tscales[i]);
                Lines.lineAngle(b.x + Tmp.v1.x, b.y + Tmp.v1.y, b.rotation(), baseLen * this.lenscales[i], false);
            }
        };

        Tmp.v1.trns(b.rotation(), baseLen * 1.1);

        Drawf.light(b.team, b.x, b.y, b.x + Tmp.v1.x, b.y + Tmp.v1.y, 40, this.lightColor, 0.7);
        Draw.reset();
    } 
});

SunAbsorberLaser.oscScl = 1.2;
SunAbsorberLaser.oscMag = 0.8;
SunAbsorberLaser.length = 600.0;
SunAbsorberLaser.width = 18.0;
SunAbsorberLaser.colors = [Color.valueOf("FFE93D44"), Color.valueOf("FFE93D66"), Color.valueOf("FFF43D99"), Color.white];
SunAbsorberLaser.strokes = [1.0, 0.85, 0.7, 0.5];
SunAbsorberLaser.tscales = [1.4, 1.1, 0.9, 0.55];
SunAbsorberLaser.lenscales = [0.8, 0.92, 0.98, 1.01];
SunAbsorberLaser.damage = 1200;
SunAbsorberLaser.hitEffect = Fx.hitMeltdown;
SunAbsorberLaser.despawnEffect = Fx.none;
SunAbsorberLaser.hitSize = 18.0;
SunAbsorberLaser.drawSize = 700; //570+130
SunAbsorberLaser.shootEffect = Fx.none;
SunAbsorberLaser.smokeEffect = Fx.none;
SunAbsorberLaser.hittable = false;
SunAbsorberLaser.absorbable = false
SunAbsorberLaser.reflectable = false;

const SunAbsorber = extendContent(LaserTurret, "极光塔", {
	isHidden() { return !dsGlobal.人族科技封锁(); },
	load(){
		this.super$load();
		
		this.region = Core.atlas.find(this.name);
		this.baseRegion = Core.atlas.find("光耀旧世界-block-" + this.size);
	},
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
	generateIcons: function(){
		return [
			Core.atlas.find("光耀旧世界-block-" + this.size),
			Core.atlas.find(this.name)
		];
    }
});
SunAbsorber.buildVisibility = BuildVisibility.shown;
SunAbsorber.shootType = SunAbsorberLaser;
SunAbsorber.update = true;
SunAbsorber.size = 8;
SunAbsorber.reloadTime = 1200;

SunAbsorber.chargeTime = 300;
SunAbsorber.chargeEffects = 20;
SunAbsorber.chargeBeginEffect = YellowBeamChargeBegin;
SunAbsorber.chargeBegin = YellowBeamCharge;
SunAbsorber.chargeMaxDelay = 300;

SunAbsorber.coolantMultiplier = 2.0;
SunAbsorber.shootDuration = 600;
SunAbsorber.firingMoveFract = 0.0;
SunAbsorber.hasPower = true;
SunAbsorber.hasLiquids = true;
SunAbsorber.range = 570;
SunAbsorber.ammoUseEffect = Fx.none;
SunAbsorber.rotateSpeed = 0.4;
SunAbsorber.recoilAmount = 5.0;
SunAbsorber.restitution = 0.005;
SunAbsorber.powerUse = 888;
SunAbsorber.buildCostMultiplier = 0.3;
SunAbsorber.consumes.liquid(F.fl("yj"), 1);
SunAbsorber.category = Category.logic;

SunAbsorber.localizedName = "极光塔";

SunAbsorber.activeSound = loadSound("beamLaser");
SunAbsorber.activeSoundVolume = 3.0;
SunAbsorber.shootSound = loadSound("beamShoot");
SunAbsorber.shootShake = 5.0;
SunAbsorber.requirements = ItemStack.with(
	F.fi("锡"), 3500,
	F.fi("白银"), 3000,
	F.fi("黄金"), 2500,
	F.fi("强化锡金"), 1200,
	F.fi("能量合金"), 800,
	F.fi("能量结晶"), 200,
	myItems.人族科技点, (50 * 8 * 8)
);
F.techNode(F.fb("电光塔"), SunAbsorber, ItemStack.with(
	F.fi("锡"), 3500 * 25,
	F.fi("白银"), 3000 * 25,
	F.fi("黄金"), 2500 * 25,
	F.fi("强化锡金"), 1200 * 25,
	F.fi("能量合金"), 800 * 25,
	F.fi("能量结晶"), 200 * 25,
	myItems.普通科技点, (60 * 8 * 8)
));