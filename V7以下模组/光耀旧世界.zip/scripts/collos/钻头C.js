//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const lib = require('前置/lib');
const dsGlobal = require('前置/ds-global');

const F = require("func");

const AX = require('物品');

var rotatorLightRegion;
var block = extendContent(Drill, "drill-c", {
	load() {
        this.super$load();
        rotatorLightRegion = lib.loadRegion('drill-c-rotator-light');
        this.rotatorRegion = lib.loadRegion('drill-c-rotator');
        this.rotatorRegion.packedHeight += 10;
        this.rotatorRegion.packedWidth -= 102;
    },
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	}
});
block.buildVisibility = BuildVisibility.shown;
block.localizedName = "镁铝合金钻头";
block.description = "3级钻头";
block.size = 5;
block.tier = 5;
block.drillTime = 20;
block.drillEffect = Fx.formsmoke;
block.updateEffectChance = 0.01;
block.drawMineItem = true;
block.liquidBoostIntensity = 1.5;
block.drawRim = true;
block.itemCapacity = 50;
block.liquidCapacity = 300;
block.rotateSpeed = 6;
block.warmupSpeed = 0.01;
block.category = Category.production;
block.drawMineItem = true;
block.hasPower = true;
block.canOverdrive = true;
block.heatColor = Color.valueOf("0000ff");
block.hardnessDrillMultiplier = 25;
block.consumes.power(30.5);
block.consumes.liquid(AX.O2y, 0.05).boost();
block.buildCostMultipler = 0.000001;
block.requirements = ItemStack.with(
	F.fi("Mg-Al"), 450, 
	F.fi("Fe-C"), 600, 
	F.fi("普通科技点"), 1500
);

const lightColor = Color.valueOf("0000ff")
lib.setBuildingSimpleAA(block, Drill.DrillBuild, block => ({
    lightup: 0,
    updateTile() {
        if (this.dominantItem == null) {
            return;
        }
        if (this.timer.get(block.timerDump, block.dumpTime)) {
            this.dump(this.dominantItem);
            this.dump(this.dominantItem);
        }
        this.timeDrilled += this.warmup * this.delta();

        if (this.items.total() < block.itemCapacity && this.dominantItems > 0 && this.consValid()) {

            var speed = 1;

            if (this.cons.optionalValid()) {
                speed = block.liquidBoostIntensity;
                this.lightup = Mathf.lerpDelta(this.lightup, 1, block.warmupSpeed);
            } else {
                this.lightup = Mathf.lerpDelta(this.lightup, 0, block.warmupSpeed);
            }

            speed *= this.efficiency(); // Drill slower when not at full power

            this.lastDrillSpeed = (speed * this.dominantItems * this.warmup) / (block.drillTime + block.hardnessDrillMultiplier * this.dominantItem.hardness);
            this.warmup = Mathf.lerpDelta(this.warmup, speed, block.warmupSpeed);
            this.progress += this.delta() * this.dominantItems * speed * this.warmup;

            if (Mathf.chanceDelta(block.updateEffectChance * this.warmup)) {
                block.updateEffect.at(this.x + Mathf.range(block.size * 2), this.y + Mathf.range(block.size * 2));
            }
        } else {
            this.lastDrillSpeed = 0;
            this.warmup = Mathf.lerpDelta(this.warmup, 0, block.warmupSpeed);
            this.lightup = Mathf.lerpDelta(this.lightup, 0, block.warmupSpeed);
            return;
        }

        var delay = block.drillTime + block.hardnessDrillMultiplier * this.dominantItem.hardness;

        if (this.dominantItems > 0 && this.progress >= delay && this.items.total() < block.itemCapacity) {
            const offloadTimes = Math.floor(this.progress / delay);
            for (var i = 0; i < offloadTimes; i++) {
                this.offload(this.dominantItem);
            }

            this.index++;
            this.progress %= delay;

            block.drillEffect.at(this.x + Mathf.range(block.size) * 2, this.y + Mathf.range(block.size) * 2, this.dominantItem.color);
        }
    },
    draw() {
        var s = 0.3
        var ts = 0.6
        Draw.rect(block.region, this.x, this.y)
        this.drawCracks()
        if (block.drawRim) {
            Draw.color(block.heatColor);
            Draw.alpha(this.warmup * ts * (1 - s + Mathf.absin(Time.time, 3, s)));
            Draw.blend(Blending.additive);
            Draw.rect(block.rimRegion, this.x, this.y);
            Draw.blend();
            Draw.color();
        }
        Draw.rect(block.rotatorRegion, this.x, this.y, this.timeDrilled * block.rotateSpeed);

        Draw.rect(block.topRegion, this.x, this.y);

        if (this.dominantItem != null && this.drawMineItem) {
            Draw.color(this.dominantItem.color);
            Draw.rect(block.itemRegion, this.x, this.y);
            Draw.color();
        }

        Draw.z(Layer.effect);
        Draw.color(lightColor);
        Draw.alpha(this.lightup * 0.9);
        Draw.rect(rotatorLightRegion, this.x, this.y, this.timeDrilled * block.rotateSpeed);
        Draw.reset();
    },
}));

exports.drillc = block;