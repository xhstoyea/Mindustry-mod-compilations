//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const dsGlobal = require('前置/ds-global');

const F = require("func");
const C = require('colors');

const LDrill = extendContent(GenericSmelter, "离子钻头", {
    isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	outputsItems(){
		return true;
	},
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
		
		this.bars.add("items", 
            func(e =>
			    new Bar(
                    prov(() => Core.bundle.format("bar.items",
                        e.getStack() != null ? e.items.get(e.getStack().item) : 0)
                    ),
                    prov(() => e.getStack() != null ? e.getStack().item.color : Pal.powerBar),
                    floatp(() => ((this != null && e.getStack() != null) ? (e.items.get(e.getStack().item) / this.itemCapacity) : 0)) 
				)
			)
		)
	}, 

	icons(){
		return [
			F.tex("离子钻头"),
			F.tex("离子钻头-heat"),
			F.tex("离子钻头-rotator")
		]
    }
});

LDrill.buildType = () => {
	const ent = extendContent(GenericSmelter.SmelterBuild, LDrill, {
		init(tile, team, shouldAdd, rotation){
			if(!this.initialized) this.create(tile.block(), team);

			this.setStack(null);
			this.setSequence(0);

			this.rotation = rotation;
			this.tile = tile;
			this.set(tile.drawx(), tile.drawy());
			if(shouldAdd) this.add();
			this.created();

			return this;
		}, 
		
		playerPlaced(config){
			if(this.lastItem != null){
				Core.app.post(run(() => this.configure(this.lastItem.id)));
			}
		},
		       
		shouldConsume(){
	        if(this.getStack() != null && this.items.get(this.getStack().item) >= this.itemCapacity){
	            return false;
	        };
	        return true;
	    },
	
		draw(){
			this.super$draw();
			
			Draw.rect(Core.atlas.find("光耀旧世界-离子钻头"), this.x, this.y);
			Draw.rect(Core.atlas.find("光耀旧世界-离子钻头-rotator"), this.x, this.y, this.totalProgress * 1.6);
            if(this.warmup > 0.0 && this.block.flameColor.a > 0.01){
				Draw.color(C.CFlame);
				Draw.alpha((0.25 + Mathf.sin(Time.time*0.1)*0.1) * this.warmup);
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-离子钻头-heat"), this.x, this.y);
				Draw.blend();
                Draw.reset();
            }
		},
		
		getProgressIncrease(baseTime){
			if(this.getSequence() == 0) return 0;
			return 1 / baseTime * this.delta() * this.efficiency();
		},
		
		buildConfiguration(table){
			var array = [Items.copper, Items.lead, Items.sand, Items.coal, Items.titanium, Items.thorium, Items.scrap, F.fi("Fe"), F.fi("Al"), F.fi("Mg"), F.fi("W"), F.fi("U"), F.fi("kFe"), F.fi("kAl"), F.fi("kMg"), F.fi("kW"), F.fi("kU"), F.fi("白银"), F.fi("锡"), F.fi("黄金")];
			var arcArray = new Packages.arc.struct.Seq(array);
			var stack = this.getStack() == null ? null : this.getStack().item;
			
			ItemSelection.buildTable(table, arcArray, prov(() => stack), cons(item => {
				this.lastItem = item;
				this.configure(item == null ? -1 : item.id);
			}));
		},
		
		configure(value){
			this.progress = 0;
			
			if(value != -1){
				this.setSequence(this.getItemSequence(value));
				var items = new ItemStack(Vars.content.item(value), this.getItemAmount(this.getItemSequence(value)));
				this.setStack(items);
			} else {
				this.setSequence(0);
				this.setStack(null);
			}
		},
		
		getItemAmount(v){
			var a = [20, 270, 270, 300, 240, 210, 180, 300, 240, 270, 210, 180, 150, 120, 135, 105, 90, 75, 105, 90, 75];
			
			return a[v];
		}, 
		
		getItemSequence(v){
			var i = Vars.content.item(v);
			
			if(i == Items.copper) return 1;
			if(i == Items.lead) return 2;
			if(i == Items.sand) return 3;
			if(i == Items.coal) return 4;
			if(i == Items.titanium) return 5;
			if(i == Items.thorium) return 6;
			if(i == Items.scrap) return 7;
			if(i == F.fi("Fe")) return 8;
			if(i == F.fi("Al")) return 9;
			if(i == F.fi("Mg")) return 10;
			if(i == F.fi("W")) return 11;
			if(i == F.fi("U")) return 12;
			if(i == F.fi("kFe")) return 13;
			if(i == F.fi("kAl")) return 14;
			if(i == F.fi("kMg")) return 15;
			if(i == F.fi("kW")) return 16;
			if(i == F.fi("kU")) return 17;
			if(i == F.fi("白银")) return 18;
			if(i == F.fi("锡")) return 19;
			if(i == F.fi("黄金")) return 20;
			return 0;
		},
		
		updateTile(){
			if(this.consValid() && this.getSequence() != 0 && this.getStack() != null && this.items.get(this.getStack().item) < 3000){
	
				this.progress += this.getProgressIncrease(160);
				this.totalProgress += this.delta() * this.warmup;
				this.warmup = Mathf.lerpDelta(this.warmup, 1, 0.02);
	
				if(Mathf.chance(Time.delta * 0.1)){
					Fx.fuelburn.at(this.x + Mathf.range(this.size * 4), this.y + Mathf.range(this.size * 4));
				}
			} else {
				this.warmup = Mathf.lerp(this.warmup, 0, 0.02);
				this.totalProgress += this.delta() * this.warmup;
			};
			
			if(this.progress >= 1) {
				this.consume();
	
				if(this.getStack() != null){
					for(var i = 0; i < this.getStack().amount; i++){
					    if(this.items.get(this.getStack().item) < 3000) this.offload(this.getStack().item);
					}
				};
	
				Fx.smeltsmoke.at(this.x, this.y);
				this.progress = 0;
	        }
	
            if(this.getStack() != null){
                this.dump(this.getStack().item);
            }
		}, 

		writeBase(write){
			this.super$writeBase(write);

			write.s(this.getStack() == null ? -1 : this.getStack().item.id);
		},

		readBase(read){
			this.super$readBase(read);

            var id = read.s();
            
			if(id != -1){
				this._stack = new ItemStack(Vars.content.item(id), this.getItemAmount(this.getItemSequence(id))); 
				this._seq = this.getItemSequence(id);
			}else{
				this._stack = null;
				this._seq = 0;
			};
		},
		
		getStack() {
			return this._stack
		}, 
		
		setStack(a) {
		    this._stack = a
		},
		
		setSequence(a) {
		    this._seq = a
		}, 
		
		getSequence() {
		    return this._seq
		}
	});
	
	return ent;
};

//const contritumLiquid = 10.0/60.0;

LDrill.hasItems = true;
//LDrill.hasLiquids = true;
LDrill.hasPower = true;
LDrill.itemCapacity = 3000;
LDrill.liquidCapacity = 100;
LDrill.buildVisibility = BuildVisibility.shown;
LDrill.health = 4350;
LDrill.size = 8;
LDrill.craftTime = 90;
LDrill.consumes.power(250);
//LDrill.consumes.liquid(F.fl("yj"), contritumLiquid);
LDrill.idleSound = Sounds.respawning;
LDrill.idleSoundVolume = 0.05;
LDrill.saveConfig = true;
LDrill.configurable = true;
LDrill.lastItem = null;
LDrill.category = Category.production;
LDrill.buildCostMultipler = 0.000001;
LDrill.requirements = ItemStack.with(
	F.fi("C60"), 500, 
	F.fi("Ti+"), 2000, 
	F.fi("Fe-C"), 3500, 
	F.fi("xvx-ai"), 100, 
	F.fi("xvx-nqwz"), 50,
	F.fi("Mg-Al"), 2500,
	F.fi("普通科技点"), 3840
);

const lib = require('前置/lib');
const xa = require("collos/钻头A");
const xb = require("collos/钻头B");
const xc = require("collos/钻头C");
const xd = require("collos/钻头D");

lib.addToResearch(xa.drillz, {
	parent: "光耀旧世界-科技中心",
	requirements: ItemStack.with(
	F.fi("Fe"), 4500
    )
});

lib.addToResearch(xb.drillx, {
	parent: xa.drillz.name,
	requirements: ItemStack.with(
	F.fi("Fe-C"), 6500
	)
});

lib.addToResearch(xc.drillc, {
	parent: xb.drillx.name,
	requirements: ItemStack.with(
	F.fi("Mg-Al"), 4500, 
	F.fi("Fe-C"), 6000
    )
});

lib.addToResearch(xd.C60Drill, {
	parent: xc.drillc.name,
	requirements: ItemStack.with(
	F.fi("C60"), 100, 
	F.fi("Ti+"), 4000, 
	F.fi("Fe-C"), 12500, 
	F.fi("Mg-Al"), 6500
	)
});

lib.addToResearch(LDrill, {
	parent: xd.C60Drill.name,
	requirements: ItemStack.with(
	F.fi("C60"), 500 * 10, 
	F.fi("Ti+"), 2000 * 10, 
	F.fi("Fe-C"), 3500 * 10, 
	F.fi("xvx-ai"), 100 * 10, 
	F.fi("xvx-nqwz"), 50 * 10,
	F.fi("Mg-Al"), 2500 * 10
	)
});