//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const lib = require('前置/lib');
const dsGlobal = require('前置/ds-global');

var 走狗 = extendContent(UnitType, '走狗', {});
走狗.constructor = () => extend(MechUnit, {});

var 重载;
var 自动重载;
var 自动重载2;
var 自爆;

var 走狗工厂 = extendContent(Wall, '走狗工厂', {
	isHidden() { return !dsGlobal.虫族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");

	    this.bars.add("生产次数",
            func(e =>
		        new Bar(
					prov(() => "生产次数: " + e.getKil() + e.getWca2()),
			        prov(() => Color.valueOf("#ff3333"), 1),
			        floatp(() => e.getKil() / 9)
	            )
	        )
        )
		this.bars.add("生产时间",
			func(e =>
				new Bar(
					prov(() => "生产进度" + e.getWca()),
					prov(() => Color.valueOf("#ffff77"), 1),
					floatp(() => Math.floor(e.getTimer() / 60) / 15)
				)
			)
		)
		this.bars.add("重载",
			func(e =>
				new Bar(
					prov(() => e.getWca3()),
					prov(() => Color.valueOf("#ffffff"), 1),
					floatp(() => Math.floor(e.getTimer2() / 60) / 20)
				)
			)
		)
    },
	load() {
        重载 = lib.loadRegion("工厂-重载");
        自动重载 = lib.loadRegion("工厂-自动重载");
		自动重载2 = lib.loadRegion("工厂-自动重载2");
        自爆 = lib.loadRegion("工厂-自爆");
		this.super$load();
    },
});
走狗工厂.category = Category.logic;
走狗工厂.configurable = true;
走狗工厂.logicConfigurable = true;

function AIspawn(Unit, Uteam, SpX, SpY, SpR){
	if (Vars.net.client()) {
	return;
	}
	var unit = Unit.create(Uteam);
	unit.set(SpX + Mathf.range(1), SpY + Mathf.range(1));
	unit.rotation = SpR;
	unit.add();
}

走狗工厂.config(java.lang.Integer, lib.cons2((tile, val) => {
	tile.my重载 = val;
}));

lib.setBuilding(走狗工厂, Block => {
	var timer = 0;
	var timer2 = 0;
	var kil = 0;
	var wca = "";
	var wca2 = "/9 :";
	var my重载 = 0;
	var my重载2 = false;
	var my自爆 = false;
	var wca3 = "重载: [#ff0000]OFF";
	return new JavaAdapter(Wall.WallBuild, {
		buildConfiguration(table) {
			table.button(new Packages.arc.scene.style.TextureRegionDrawable(重载), Styles.clearTransi, run(() => { my重载2 = true })).size(40).tooltip("消耗血量制作单位");
			if(my重载 > 0){
				table.button(new Packages.arc.scene.style.TextureRegionDrawable(自动重载2), Styles.clearTransi, run(() => { my重载 += 1 })).size(40).tooltip("点击关闭自动消耗血量制作单位");
			}else{
				table.button(new Packages.arc.scene.style.TextureRegionDrawable(自动重载), Styles.clearTransi, run(() => { my重载 += 1 })).size(40).tooltip("点击开启自动消耗血量制作单位");
			};
            table.button(new Packages.arc.scene.style.TextureRegionDrawable(自爆), Styles.clearTransi, run(() => { my自爆 = true })).size(40).tooltip("自爆");
        },
		draw(){
            this.super$draw();
			
			if(kil <= 0){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-1"), this.x, this.y);
			}
			
			if(kil <= 1){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-2"), this.x, this.y);
			}
			
			if(kil <= 2){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-3"), this.x, this.y);
			}
			
			if(kil <= 3){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-4"), this.x, this.y);
			}
			
			if(kil <= 4){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-5"), this.x, this.y);
			}
			
			if(kil <= 5){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-6"), this.x, this.y);
			}
			
			if(kil <= 6){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-7"), this.x, this.y);
			}
			
			if(kil <= 7){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-8"), this.x, this.y);
			}
			
			if(kil <= 8){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-9"), this.x, this.y);
			}
				
		},
		updateTile(){
		
		if(my自爆){
			this.damage(this.block.health + 1)
			my自爆 = true;
		};
		
		if(kil > 0){
			if(my重载2){
				this.damage(this.block.health / 4)
				kil -= 1;
				my重载2 = false;
			};
		};
		
		if(my重载 >= 2){
			my重载 = 0;
		};
		
		if(kil > 0 && my重载 >= 1){
			wca3 = "重载: [#00FF00]ON";
			timer2 += Time.delta * Vars.state.rules.unitBuildSpeedMultiplier;
			if(timer2 >= 1200){
				this.damage(this.block.health / 4)
				timer2 = 0;
				kil -= 1;
			};
		}else{	
		wca3 = "重载: [#ff0000]OFF";
		};
		if(kil <= 0 && my重载 > 0){
		wca3 = "重载: [#ffff00]暂停";
		};
		
		const CAN = Units.canCreate(this.team, 走狗)
		if(CAN){
			if(kil >= 9){
			wca = "[red][已完成!]";
			}else{	
				timer += Time.delta * Vars.state.rules.unitBuildSpeedMultiplier;
				wca = "";
			}
			
			wca2 = "/9";
			//print(Units.getCap(this.team))
		
			if(kil >= 9){
			}else{	
				if(timer >= 900){
				AIspawn(走狗, this.team, this.x, this.y, this.rotation);
				timer = 0;
				kil += 1;
				};
			}
		}else{
			wca2 = "/9 : [red]MAX";
		}},
		
		getTimer() {
			return timer
		},
		getTimer2() {
			return timer2
		},
		getKil() {
			return kil
		},
		getWca() {
			return wca
		},
		getWca2() {
			return wca2
		},
		getWca3() {
			return wca3
		},
		
		//setMy重载(val) { my重载 = val },
        config() {
            return this.my重载;
        },

		onDestroyed (){
			AIspawn(走狗, this.team, this.x, this.y, this.rotation);
			AIspawn(走狗, this.team, this.x, this.y, this.rotation);
			AIspawn(走狗, this.team, this.x, this.y, this.rotation);
			AIspawn(走狗, this.team, this.x, this.y, this.rotation);
		}
	}, 走狗工厂);	
});
走狗工厂.update = true 
走狗工厂.solid = false;
走狗工厂.placeableLiquid = true;
走狗工厂.health = 500;
走狗工厂.size = 3;
走狗工厂.buildCostMultipler = 0.000001;
走狗工厂.unitCapModifier = 5;