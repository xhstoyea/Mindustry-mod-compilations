//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const dsGlobal = require('前置/ds-global');

exports.fz = (() => {
var myBlock = extendContent(GenericCrafter, 'fz', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});

var myDrawer = new DrawAnimation();
myDrawer.frameCount = 62;
myDrawer.frameSpeed = 5;
myDrawer.sine = false;
myBlock.drawer = myDrawer;

const 特效 = require('前置/特效');
myBlock.craftEffect = 特效.特效A;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.bdPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'bd-Plant', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.C60Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'C60-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.C60Plantz = (() => {
var myBlock = extendContent(GenericSmelter, 'C60-Plant-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.C90Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'C90-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.C90Plantz = (() => {
var myBlock = extendContent(GenericSmelter, 'C90-Plant-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.C902Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'C902-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.C902Plantz = (() => {
var myBlock = extendContent(GenericSmelter, 'C902-Plant-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.工厂扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.FeCPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'Fe-C-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.FeCPlantz = (() => {
var myBlock = extendContent(GenericSmelter, 'Fe-C-Plant-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.ghblPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'ghbl-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.ghblPlantz = (() => {
var myBlock = extendContent(GenericSmelter, 'ghbl-Plant-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.工厂扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.MgAlPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'Mg-Al-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.MgAlPlantz = (() => {
var myBlock = extendContent(GenericSmelter, 'Mg-Al-Plant-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.mtPlant = (() => {
var myBlock = extendContent(Cultivator, 'mt-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.mtPlantz = (() => {
var myBlock = extendContent(Cultivator, 'mt-Plant-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.工厂扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.U235Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'U-235-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.U235Plantz = (() => {
var myBlock = extendContent(GenericSmelter, 'U-235-Plant-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.工厂扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.PuPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'Pu-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.PuPlantz = (() => {
var myBlock = extendContent(GenericSmelter, 'Pu-Plant-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.工厂扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.Pu239Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'Pu-239-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.Pu239Plantz = (() => {
var myBlock = extendContent(GenericSmelter, 'Pu-239-Plant-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.工厂扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.TiPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'Ti+Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.TiPlantz = (() => {
var myBlock = extendContent(GenericSmelter, 'Ti+Plant-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xvxaiPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'xvx-ai-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xvxaiPlantz = (() => {
var myBlock = extendContent(GenericSmelter, 'xvx-ai-Plant-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.工厂扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xvxnqwzPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'xvx-nqwz-Plant', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xvxnqwzPlantz = (() => {
var myBlock = extendContent(GenericSmelter, 'xvx-nqwz-Plant-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心() || !dsGlobal.工厂扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

//大子弹工厂

exports.AhdPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'Ahd-Plant', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.BhdPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'Bhd-Plant', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.fyPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'fy-Plant', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
//子弹工厂
exports.ammoPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'ammo-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.ammo2Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'ammo2-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.ammo3Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'ammo3-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
//炮弹工厂
exports.bulletPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'bullet-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.bullet2Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'bullet2-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.bullet3Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'bullet3-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
//核弹工厂
exports.bombPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'bomb-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.bomb2Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'bomb2-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.bomb3Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'bomb3-Plant', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.bomb4Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'bomb4-Plant', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
//导弹工厂
exports.missilePlant = (() => {
var myBlock = extendContent(GenericSmelter, 'missile-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.missile2Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'missile2-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.missile3Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'missile3-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.missile4Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'missile4-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.missile5Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'missile5-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.missile6Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'missile6-Plant', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.missile7Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'missile7-Plant', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
//燃烧工厂
exports.W1Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'W-1-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.W2Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'W-2-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();