//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const myItems = require('物品');
const dsGlobal = require('前置/ds-global');

//人族
exports.应变者建造工厂 = (() => {
var myBlock = extendContent(UnitFactory, '应变者建造工厂', {
	isHidden() { return !dsGlobal.人族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.category = Category.logic;
myBlock.buildCostMultipler = 0.000001;
F.techNode(F.fb("人族基地"), myBlock, ItemStack.with(
	myItems.锡, 350 * 25,
	myItems.白银, 250 * 25,
	myItems.普通科技点, 3 * 3 * 60
));
return myBlock;
})();
exports.游牧者建造工厂 = (() => {
var myBlock = extendContent(UnitFactory, '游牧者建造工厂', {
	isHidden() { return !dsGlobal.人族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.category = Category.logic;
myBlock.buildCostMultipler = 0.000001;
F.techNode(F.fb("人族基地"), myBlock, ItemStack.with(
	myItems.锡, 350 * 25,
	myItems.白银, 250 * 25,
	myItems.普通科技点, 3 * 3 * 60
));
return myBlock;
})();
exports.北极光建造工厂 = (() => {
var myBlock = extendContent(UnitFactory, '北极光建造工厂', {
	isHidden() { return !dsGlobal.人族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.category = Category.logic;
myBlock.buildCostMultipler = 0.000001;
F.techNode(F.fb("人族基地"), myBlock, ItemStack.with(
	myItems.锡, 350 * 25,
	myItems.白银, 250 * 25,
	myItems.普通科技点, 3 * 3 * 60
));
return myBlock;
})();
//人族
exports.人族中阶升级平台 = (() => {
var myBlock = extendContent(Reconstructor, '人族中阶升级平台', {
	isHidden() { return !dsGlobal.人族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.category = Category.logic;
myBlock.buildCostMultipler = 0.000001;;
F.techNode(F.fb("人族基地"), myBlock, ItemStack.with(
	myItems.锡, 500 * 25,
	myItems.白银, 450 * 25,
	myItems.普通科技点, 3 * 3 * 60
));
return myBlock;
})();
exports.人族进阶升级平台 = (() => {
var myBlock = extendContent(Reconstructor, '人族进阶升级平台', {
	isHidden() { return !dsGlobal.人族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.category = Category.logic;
myBlock.buildCostMultipler = 0.000001;;
F.techNode(exports.人族中阶升级平台, myBlock, ItemStack.with(
	myItems.锡, 950 * 25,
	myItems.白银, 850 * 25,
	myItems.黄金, 650 * 25,
	myItems.强化锡金, 250 * 25,
	myItems.普通科技点, 5 * 5 * 60
));
return myBlock;
})();
exports.人族高阶升级平台 = (() => {
var myBlock = extendContent(Reconstructor, '人族高阶升级平台', {
	isHidden() { return !dsGlobal.人族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.category = Category.logic;
myBlock.buildCostMultipler = 0.000001;;
F.techNode(exports.人族进阶升级平台, myBlock, ItemStack.with(
	myItems.锡, 1500 * 25,
	myItems.白银, 1250 * 25,
	myItems.黄金, 950 * 25,
	myItems.强化锡金, 550 * 25,
	myItems.能量合金, 250 * 25,
	myItems.普通科技点, 7 * 7 * 60
));
return myBlock;
})();
exports.人族终阶升级平台 = (() => {
var myBlock = extendContent(Reconstructor, '人族终阶升级平台', {
	isHidden() { return !dsGlobal.人族科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.category = Category.logic;
myBlock.buildCostMultipler = 0.000001;;
F.techNode(exports.人族高阶升级平台, myBlock, ItemStack.with(
	myItems.锡, 3800 * 25,
	myItems.白银, 3200 * 25,
	myItems.黄金, 2700 * 25,
	myItems.强化锡金, 1500 * 25,
	myItems.能量合金, 850 * 25,
	myItems.能量结晶, 250 * 25,
	myItems.普通科技点, 9 * 9 * 60
));
return myBlock;
})();