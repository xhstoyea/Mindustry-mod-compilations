//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const lib = require('前置/lib');
const dsGlobal = require('前置/ds-global');

exports.CG2 = (() => {
var myBlock = extendContent(BurnerGenerator, 'CG-2', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.PP1 = (() => {
var myBlock = extendContent(BurnerGenerator, 'PP-1', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.tyn1 = (() => {
var myBlock = extendContent(SolarGenerator, 'tyn1', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.tyn2 = (() => {
var myBlock = extendContent(SolarGenerator, 'tyn2', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.tyn3 = (() => {
var myBlock = extendContent(SolarGenerator, 'tyn3', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.tyn4 = (() => {
var myBlock = extendContent(SolarGenerator, 'tyn4', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
//太阳能5级
exports.tyn5 = (() => {
var 增加
var 减少

var myBlock = extendContent(SolarGenerator, 'tyn5', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
		func(e =>
			new Bar(
				prov(() => Math.floor(e.health) + " / " + e.maxHealth),
				prov(() => Color.valueOf("#ff0000"), 1),
				floatp(() => e.healthf()))
			)
		);
		this.bars.add("温度",
            func(e =>
		        new Bar(
					prov(() => "温度: " + Math.floor(e.getWD()) + " / 10000" + e.getWD2()),
			        prov(() => Color.valueOf("#ff3333"), 1),
			        floatp(() => e.getWD() / 10000)
	            )
            )
		);
		this.bars.add("能量等级",
		func(e =>
			new Bar(
				prov(() => "能量等级: " + e.getEFF() + " / 10"),
				prov(() => Color.valueOf("#ff0000"), 1),
				floatp(() => e.getEFF() / 10)
			)
		)
	);
		this.super$setBars();
		this.bars.remove("health");
	},
	load() {
        增加 = lib.loadRegion("工厂-增加");
        减少 = lib.loadRegion("工厂-减少");
		this.super$load();
    },
});

const FFXXAA = new Color.valueOf("ff0000");

lib.setBuilding(myBlock, Block => {
	var WD = 0
	var EFF = 1
	var WD2 = ""
	return new JavaAdapter(SolarGenerator.SolarGeneratorBuild, {
		buildConfiguration(table){
			table.button(new Packages.arc.scene.style.TextureRegionDrawable(增加), Styles.clearTransi, run(() => { EFF += 1 })).size(40).tooltip("增加能量等级");
			table.button(new Packages.arc.scene.style.TextureRegionDrawable(减少), Styles.clearTransi, run(() => { EFF -= 1 })).size(40).tooltip("减少能量等级");
		},
		updateTile(){
		this.super$updateTile();

		if(EFF < 0){
			EFF = 0
		};
		if(EFF > 10){
			EFF = 10
		};

		if(EFF > 1){
			WD += (Time.delta * (EFF * 0.1))
		};

		if(WD > (-1000) && EFF == 1){
			WD -= Time.delta
		};
		if(WD > (-10000) && EFF == 0){
			WD -= (Time.delta * 3.5)
		};
		
		if(WD > 10000){
			WD2 = "[#ff0000]温度超标！！"
			this.damage(((WD - 10000)*0.1) * (EFF * 0.1))
		}else{
			WD2 = ""	
		}
		},
		getPowerProduction(){
            return 86688.5667 * EFF
        },
		getWD() {
			return WD
		},
		getWD2() {
			return WD2
		},
		getEFF() {
			return EFF
		},
        draw(){
            this.super$draw();
			
				/*
			    Tmp.c1.set(F.c("#ff0000")).lerp(F.c("#ffff00"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.1)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光A"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Tmp.c1.set(F.c("#ffff00")).lerp(F.c("#ff0000"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.1)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光B"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				*/
				
				Tmp.c1.set(F.c("#ff0000")).lerp(F.c("#ffff00"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin((Time.time*0.1) * EFF)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光A2"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Tmp.c1.set(F.c("#ffff00")).lerp(F.c("#ff0000"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin((Time.time*0.1) * EFF)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光B2"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Tmp.c1.set(F.c("#9999ff")).lerp(F.c("#00bbff"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin((Time.time*0.1) * EFF)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光AA"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Tmp.c1.set(F.c("#00bbff")).lerp(F.c("#9999ff"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin((Time.time*0.1) * EFF)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光BB"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Tmp.c1.set(F.c("#dddddd")).lerp(F.c("#444444"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin((Time.time*0.1) * EFF)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光AAA"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Tmp.c1.set(F.c("#444444")).lerp(F.c("#dddddd"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin((Time.time*0.1) * EFF)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光BBB"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Draw.color(FFXXAA.cpy().shiftHue(Time.time / 2).shiftValue(Mathf.absin(Time.time, 4, 0.15)));
				Draw.alpha(100);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + 40, this.y + 40, -((Time.time*1.5) * EFF));
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + -40, this.y + -40, -((Time.time*1.5) * EFF));
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + 40, this.y + -40, -((Time.time*1.5) * EFF));
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + -40, this.y + 40, -((Time.time*1.5) * EFF));
				
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + 40, this.y + 40, ((Time.time*1.5) * EFF));
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + -40, this.y + -40, ((Time.time*1.5) * EFF));
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + 40, this.y + -40, ((Time.time*1.5) * EFF));
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + -40, this.y + 40, ((Time.time*1.5) * EFF));
				
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核A"), this.x, this.y, ((Time.time*2.5) * EFF));
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核A"), this.x, this.y, -((Time.time*2.5) * EFF));
				Draw.reset();
				
				Draw.color(F.c("#ffff00"));
				Draw.alpha(0.5 + Mathf.sin((Time.time*0.2) * EFF)*0.1);
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-heat"), this.x, this.y);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-heat2"), this.x, this.y);
				Draw.blend();
                Draw.reset();
				
				/*
				Draw.color(F.c("#000000"));
				Draw.alpha(0.8);
				var dst = Mathf.sin(Time.time*0.1, 6, Vars.tilesize * 16 / 6);
				var rot = Time.time*0.1 + 90;
				Lines.lineAngleCenter(
                this.x + Angles.trnsx(rot, dst),
                this.y + Angles.trnsy(rot, dst),
                rot + 90,
                16 * Vars.tilesize / 3
				);
				Draw.reset();
				*/
        },
		collision(bullet){
			this.super$collision(bullet);
			
			var lightningChance = 0 + (EFF * 0.1)
			var lightningDamage = 10 * EFF
			
			if(lightningChance > 0){
                if(Mathf.chance(lightningChance)){
                    Lightning.create(this.team, F.c("#ff0000"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#ff5511"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#ff8800"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#ffbb00"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#ffff00"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#bbff00"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#77ff00"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#00ff00"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#00ff99"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#00ffcc"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#00ffff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#00bbff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#0066ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#0000ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#5300ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#7700ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#9900ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#cc00ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#ff00ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
					Lightning.create(this.team, F.c("#ff0088"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50+EFF));
                }
            }
			return true
		}
	}, myBlock);
});
myBlock.update = true;
myBlock.configurable = true;
myBlock.logicConfigurable = true;
myBlock.canOverdrive = false;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.fission = (() => {
var myBlock = extendContent(BurnerGenerator, 'fission', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.fusion = (() => {
var myBlock = extendContent(BurnerGenerator, 'fusion', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.HydrogenFusion = (() => {
var myBlock = extendContent(BurnerGenerator, 'HydrogenFusion', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.powerdc = (() => {
var myBlock = extendContent(Battery, 'power-dc', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
myBlock.consumes.powerBuffered(250000);
return myBlock;
})();

exports.powerdcz = (() => {
var myBlock = extendContent(Battery, 'power-dc-z', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
myBlock.consumes.powerBuffered(1000000);
return myBlock;
})();

exports.powerdxg = (() => {
const laserColor1 = new Color.valueOf("ffff00");
const laserColor2 =	new Color.valueOf("ff0000");

var myBlock = extendContent(PowerNode, 'power-dxg', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
	setupColor(){
		Draw.color(laserColor1, laserColor2, 2 + Mathf.absin(3, 0.1));
		Draw.alpha(Renderer.laserOpacity);
    }
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.powergyx = (() => {
const laserColor1 = new Color.valueOf("ffff00");
const laserColor2 =	new Color.valueOf("ff0000");

var myBlock = extendContent(PowerNode, 'power-gyx', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
	setupColor(){
		Draw.color(laserColor1, laserColor2, 2 + Mathf.absin(3, 0.1));
		Draw.alpha(Renderer.laserOpacity);
    }
	/*drawLaser(){
		
        const angle1 = Angles.angle(x1, y1, x2, y2);
        const vx = Mathf.cosDeg(angle1); 
		const vy = Mathf.sinDeg(angle1);
        const len1 = size1 * Vars.tilesize / 2 - 1.5;
		const len2 = size2 * Vars.tilesize / 2 - 1.5;

        Drawf.laser(this.team, laser, laserEnd, x1 + vx*len1, y1 + vy*len1, x2 - vx*len2, y2 - vy*len2, 0.8);
    }*/
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.dr1 = (() => {
var myBlock = extendContent(ThermalGenerator, 'dr1', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.dr2 = (() => {
var myBlock = extendContent(ThermalGenerator, 'dr2', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.dr3 = (() => {
var myBlock = extendContent(ThermalGenerator, 'dr3', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.KZ0 = (() => {
var myBlock = extendContent(NuclearReactor, 'KZ-0', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.KZ1 = (() => {
var myBlock = extendContent(NuclearReactor, 'KZ-1', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.KZ2 = (() => {
var myBlock = extendContent(NuclearReactor, 'KZ-2', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.KZ3 = (() => {
var myBlock = extendContent(ImpactReactor, 'KZ-3', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.KZ4 = (() => {
var myBlock = extendContent(ImpactReactor, 'KZ-4', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.size = 5;
myBlock.health = 65000;
myBlock.category = Category.power;
myBlock.buildVisibility = BuildVisibility.shown;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();