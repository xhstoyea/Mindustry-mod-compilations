//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const dsGlobal = require('前置/ds-global');

exports.ck = (() => {
var myBlock = extendContent(StorageBlock, 'ck', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
	setStats() {
        this.super$setStats();
        this.stats.add(Stat.abilities, "[#ff0000]开启防爆!!!");
    }
});
myBlock.buildType = prov(() => new JavaAdapter(StorageBlock.StorageBuild, {
	onDestroyed() {}
}, myBlock));
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.ckz = (() => {
var myBlock = extendContent(StorageBlock, 'ck-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
		setStats() {
        this.super$setStats();
        this.stats.add(Stat.abilities, "[#ff0000]开启防爆!!!");
    }
});
myBlock.buildType = prov(() => new JavaAdapter(StorageBlock.StorageBuild, {
	onDestroyed() {}
}, myBlock));
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.cs = (() => {
var myBlock = extendContent(OverdriveProjector, 'cs', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.csz = (() => {
var myBlock = extendContent(OverdriveProjector, 'cs-z', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.Inversemassspeed = (() => {
var myBlock = extendContent(OverdriveProjector, 'Inverse-mass-speed', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xf = (() => {
var myBlock = extendContent(MendProjector, 'xf', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xfz = (() => {
var myBlock = extendContent(MendProjector, 'xf-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xvxxfq = (() => {
var myBlock = extendContent(RepairPoint, 'xvx-xfq', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xvxxfqz = (() => {
var myBlock = extendContent(RepairPoint, 'xvx-xfq-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
////单位工厂
exports.飞机框架厂 = (() => {
var myBlock = extendContent(GenericSmelter, '飞机框架厂', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
exports.飞机场 = (() => {
var myBlock = extendContent(UnitFactory, '飞机场', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
exports.重构厂1 = (() => {
var myBlock = extendContent(Reconstructor, '重构厂1', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
exports.重构厂2 = (() => {
var myBlock = extendContent(Reconstructor, '重构厂2', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
exports.重构厂2A = (() => {
var myBlock = extendContent(Reconstructor, '重构厂2A', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
//
exports.hdc = (() => {
var myBlock = extendContent(ForceProjector, 'hd-c', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.hd = (() => {
var myBlock = extendContent(ForceProjector, 'hd', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.hdz = (() => {
var myBlock = extendContent(ForceProjector, 'hd-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
//矿坑
exports.zz = (() => {
var myBlock = extendContent(GenericSmelter, 'z-z', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.zx = (() => {
var myBlock = extendContent(GenericSmelter, 'z-x', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.zc = (() => {
var myBlock = extendContent(GenericSmelter, 'z-c', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.zv = (() => {
var myBlock = extendContent(GenericSmelter, 'z-v', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.zb = (() => {
var myBlock = extendContent(GenericSmelter, 'z-b', {
	isHidden() { return !dsGlobal.科技中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xz = (() => {
var myBlock = extendContent(GenericSmelter, 'x-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xx = (() => {
var myBlock = extendContent(GenericSmelter, 'x-x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xc = (() => {
var myBlock = extendContent(GenericSmelter, 'x-c', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xv = (() => {
var myBlock = extendContent(GenericSmelter, 'x-v', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xb = (() => {
var myBlock = extendContent(GenericSmelter, 'x-b', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
//人族矿坑
exports.小银坑 = (() => {
var myBlock = extendContent(GenericSmelter, '小银坑', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.矿坑扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
exports.小锡坑 = (() => {
var myBlock = extendContent(GenericSmelter, '小锡坑', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.矿坑扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
exports.小金坑 = (() => {
var myBlock = extendContent(GenericSmelter, '小金坑', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.矿坑扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
exports.银坑 = (() => {
var myBlock = extendContent(GenericSmelter, '银坑', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心() || !dsGlobal.矿坑扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
exports.锡坑 = (() => {
var myBlock = extendContent(GenericSmelter, '锡坑', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心() || !dsGlobal.矿坑扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
exports.金坑 = (() => {
var myBlock = extendContent(GenericSmelter, '金坑', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心() || !dsGlobal.矿坑扩展核心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
//防御墙
exports.FeWall = (() => {
var myBlock = extendContent(Wall, 'Fe-Wall', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.FeWallz = (() => {
var myBlock = extendContent(Wall, 'Fe-Wall-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.FeCWall = (() => {
var myBlock = extendContent(Wall, 'Fe-C-Wall', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.FeCWallz = (() => {
var myBlock = extendContent(Wall, 'Fe-C-Wall-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.MgAlWall = (() => {
var myBlock = extendContent(Wall, 'Mg-Al-Wall', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.MgAlWallz = (() => {
var myBlock = extendContent(Wall, 'Mg-Al-Wall-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
////////////////////////////////////////////////
exports.TiWall = (() => {
var myBlock = extendContent(Wall, 'Ti+Wall', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.TiWallz = (() => {
var myBlock = extendContent(Wall, 'Ti+Wall-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.TiWallx = (() => {
var myBlock = extendContent(Wall, 'Ti+Wall-x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.C60Wall = (() => {
var myBlock = extendContent(Wall, 'C60-Wall', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.C60Wallz = (() => {
var myBlock = extendContent(Wall, 'C60-Wall-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xfq = (() => {
var myBlock = extendContent(MendProjector, 'xfq', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xfqz = (() => {
var myBlock = extendContent(MendProjector, 'xfq-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xfqx = (() => {
var myBlock = extendContent(MendProjector, 'xfq-x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();