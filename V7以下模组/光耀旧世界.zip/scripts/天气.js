//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>
	
const wetx = new Effect(80, e => {
    Draw.color(Color.valueOf("66ff66"));
    Draw.alpha(Mathf.clamp(e.fin() * 2));

    Fill.circle(e.x, e.y, e.fout());
});

const fsxa = new StatusEffect('fsxa');
fsxa.color = Color.valueOf("66ff66");
fsxa.damage = 0.03;
fsxa.damageMultiplier = 0.8;
fsxa.healthMultiplier = 0.8;
fsxa.speedMultiplier = 0.95;
fsxa.reloadMultiplier = 0.6;
fsxa.effectChance = 1;
fsxa.effect = wetx;

var fs2 = new ParticleWeather("fs2")
fs2.status = fsxa;
fs2.statusDuration = 600;
fs2.duration = 15 * Time.toMinutes;
fs2.noiseLayers = 3;
fs2.noiseLayerSclM = 0.8;
fs2.noiseLayerAlphaM = 0.7;
fs2.noiseLayerSpeedM = 2;
fs2.noiseLayerSclM = 0.6;
fs2.baseSpeed = 0.01;
fs2.color = Color.valueOf("66ff66");
fs2.noiseColor = Color.valueOf("66ff66");
fs2.noiseScale = 1100;
fs2.noisePath = "fog";
fs2.drawNoise = true;
fs2.useWindVector = false;
fs2.xspeed = 1;
fs2.yspeed = 0.01;
fs2.attrs.set(Attribute.light, -0.9);
fs2.attrs.set(Attribute.spores, 10);
fs2.opacityMultiplier = 0.3;
fs2.localizedName = "[#00FF7F]辐射风暴";

exports.fs2 = fs2;

const 血雨特效 = new Effect(80, e => {
    Draw.color(Color.valueOf("ff0000"));
    Draw.alpha(Mathf.clamp(e.fin() * 2));

    Fill.circle(e.x, e.y, e.fout());
});

const 血雨状态 = new StatusEffect('血雨状态');
血雨状态.healthMultiplier = 2;
血雨状态.speedMultiplier = 1.3;
血雨状态.reloadMultiplier = 1.5;
血雨状态.effectChance = 1;
血雨状态.effect = 血雨特效;

const 血雨 = extendContent(RainWeather, "血雨", {});
血雨.localizedName = "[#ff0000]血雨";
血雨.yspeed = 12.0;
血雨.xspeed = 3.8;
血雨.padding = 21;
血雨.density = 2000;
血雨.stroke = 1.3;
血雨.sizeMin = 10.0;
血雨.sizeMax = 26.0;
血雨.splashTimeScale = 14.0;
血雨.color = Color.valueOf("#FF0007FF");
血雨.opacityMultiplier = 2.0;
血雨.attrs.set(Attribute.water, -0.2);
血雨.attrs.set(Attribute.light, -0.98);
血雨.attrs.set(Attribute.heat, -0.4);
血雨.attrs.set(Attribute.oil, -0.65);
血雨.attrs.set(Attribute.spores, -0.72);
血雨.status = 血雨状态;
血雨.statusDuration = 600;

exports.血雨 = 血雨;