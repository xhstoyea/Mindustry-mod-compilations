//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const dsGlobal = require('前置/ds-global');

exports.红魔单位工厂t1 = (() => {
var myBlock = extendContent(UnitFactory, '红魔单位工厂t1', {
	isHidden() { return !dsGlobal.掠夺者科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.category = Category.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
exports.红魔单位工厂t2 = (() => {
var myBlock = extendContent(Reconstructor, '红魔单位工厂t2', {
	isHidden() { return !dsGlobal.掠夺者科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.category = Category.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
exports.红魔单位工厂t3 = (() => {
var myBlock = extendContent(Reconstructor, '红魔单位工厂t3', {
	isHidden() { return !dsGlobal.掠夺者科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.category = Category.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
exports.红魔单位工厂t4 = (() => {
var myBlock = extendContent(Reconstructor, '红魔单位工厂t4', {
	isHidden() { return !dsGlobal.掠夺者科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.category = Category.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
exports.红魔单位工厂t5 = (() => {
var myBlock = extendContent(Reconstructor, '红魔单位工厂t5', {
	isHidden() { return !dsGlobal.掠夺者科技封锁(); },
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	},
});
myBlock.category = Category.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();


// 红色的恶魔 空
  const reliavent = extend(UnitType, "红魔-空-1", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
  });
  reliavent.constructor = () => extend(UnitEntity, {});

  const siloArray = extend(UnitType, "红魔-空-2", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
  });
  siloArray.constructor = () => extend(UnitEntity, {});
  
  const decimation = extend(UnitType, "红魔-空-3", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
  });
  decimation.constructor = () => extend(UnitEntity, {});

  const carnage = extend(UnitType, "红魔-空-4", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
  });
  carnage.constructor = () => extend(UnitEntity, {});

  const destruction = extend(UnitType, "红魔-空-5", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
    abilities: new Seq([new UnitSpawnAbility(UnitTypes.zenith, 1800, 0, 0), new UnitSpawnAbility(UnitTypes.zenith, 1800, 0, 0)])
  });
  destruction.constructor = () => extend(UnitEntity, {});

// 红色的恶魔 陆

const melter = extend(UnitType, "红魔-陆-1", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
  });
  melter.constructor = () => extend(LegsUnit, {});

const evasculator = extend(UnitType, "红魔-陆-2", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
  });
  evasculator.constructor = () => extend(LegsUnit, {});

  const blaster = extend(UnitType, "红魔-陆-3", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
  });
  blaster.constructor = () => extend(LegsUnit, {});

  const catastrophere = extend(UnitType, "红魔-陆-4", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
  });
  catastrophere.constructor = () => extend(LegsUnit, {});

  const death = extend(UnitType, "红魔-陆-5", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
  });
  death.constructor = () => extend(LegsUnit, {});

// 红色的恶魔 海

const paralysis = extend(UnitType, "红魔-海-1", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
  });
  paralysis.constructor = () => extend(UnitWaterMove, {});

  const ravager = extend(UnitType, "红魔-海-2", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
    abilities: new Seq([new ForceFieldAbility(101.7, 10, 3000, 600)])
  });
  ravager.constructor = () => extend(UnitWaterMove, {});

  const abolisher = extend(UnitType, "红魔-海-3", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
    abilities: new Seq([new UnitSpawnAbility(UnitTypes.flare, 1200, 0, 14)])
  });
  abolisher.constructor = () => extend(UnitWaterMove, {});

  const warmonger = extend(UnitType, "红魔-海-4", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
  });
  warmonger.constructor = () => extend(UnitWaterMove, {});

  const demise = extend(UnitType, "红魔-海-5", {
    immunities: ObjectSet.with([
        StatusEffects.wet,
        StatusEffects.melting,
        StatusEffects.burning,
        StatusEffects.muddy,
        StatusEffects.sapped,
        StatusEffects.sporeSlowed,
        StatusEffects.tarred,
        StatusEffects.shocked,
        StatusEffects.corroded
    ]),
    abilities: new Seq([new UnitSpawnAbility(UnitTypes.flare, 300, 0, -26), new UnitSpawnAbility(UnitTypes.flare, 300, 0, -26), new UnitSpawnAbility(UnitTypes.flare, 300, 0, -26), new ForceFieldAbility(101.7, 16, 10000, 600)])
  });
  demise.constructor = () => extend(UnitWaterMove, {});