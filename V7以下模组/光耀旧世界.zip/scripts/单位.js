//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const myItems = require('物品');

const {
    Al,Fe,Mg,W,U,血肉,骨物质,灵光,白银,黄金,锡
} = myItems;

/*
Events.on(WorldLoadEvent, cons(event => {
    for (var i in Team.baseTeams) {
        var team = Team.baseTeams[i];
        if (!team.data().mineItems.contains(Fe)) {
            team.data().mineItems.add(Fe);
            team.data().mineItems.add(Mg);
            team.data().mineItems.add(W);
            team.data().mineItems.add(Al);
            team.data().mineItems.add(U);
			team.data().mineItems.add(血肉);
            team.data().mineItems.add(骨物质);
            team.data().mineItems.add(灵光);
            team.data().mineItems.add(白银);
            team.data().mineItems.add(黄金);
			team.data().mineItems.add(锡);
        }
    }
}));
*/

var 维修 = extendContent(UnitType, '维修机', {});
维修.ammoType = AmmoTypes.powerLow;
维修.defaultController = prov(() => new RepairAI());
维修.constructor = prov(() => extend(UnitTypes.mega.constructor.get().class, {}));

var 建造 = extendContent(UnitType, '建造机', {});
建造.defaultController = prov(() => new BuilderAI());
建造.constructor = prov(() => extend(UnitTypes.poly.constructor.get().class, {}));
exports.建造 = 建造;

//var 采矿 = extendContent(UnitType, '采矿机', {});
//采矿.defaultController = prov(() => new MinerAI());
//采矿.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));

//var 采矿x = extendContent(UnitType, '进阶采矿机', {});
//采矿x.defaultController = prov(() => new MinerAI());
//采矿x.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));

var boss = extend(StatusEffect, 'boss', {});
boss.color = Color.valueOf("9370DB");
boss.damageMultiplier = 2;
boss.healthMultiplier = 2;
boss.speedMultiplier = 2;
boss.reloadMultiplier = 2;
boss.effectChance = 1;
boss.effect = Fx.overclocked;

var ax = extendContent(UnitType, 'ax', {});
ax.defaultController = prov(() => new MinerAI());
ax.constructor = prov(() => extend(UnitTypes.atrax.constructor.get().class, {}));
//ax.abilities.add(new UnitSpawnAbility(F.fu("采矿"),1000,0,-5 ));
ax.abilities.add(new StatusFieldAbility(boss,180,180,35 ));

var 紫色 = Color.valueOf("9370DB");
var v2 = new AmmoTypes.ItemAmmoType;
v2.item = U;
v2.color = 紫色;
v2.barColor = 紫色;

ax.ammoType = v2;

const 秃鹫 = extend(UnitType, "秃鹫", {
	draw(unit){
		this.super$draw(unit);
		
		Draw.rect(Core.atlas.find("光耀旧世界-秃鹫-rotator"), unit.x, unit.y, Time.time*25);

	}
});
秃鹫.constructor = () => extend(UnitEntity, {})

const 苍鹰 = extend(UnitType, "苍鹰", {
	draw(unit){
		this.super$draw(unit);
		
		Draw.rect(Core.atlas.find("光耀旧世界-苍鹰-rotator"), unit.x, unit.y, Time.time*25);

	}
});
苍鹰.constructor = () => extend(UnitEntity, {})


const 鹰隼 = extend(UnitType, "鹰隼", {
	draw(unit) {
		this.super$draw(unit);
		
		const offset = 1.6 * Vars.tilesize;
		const dist = Math.sqrt(2 * offset * offset)

		const r = unit.rotation;
		const sin = Mathf.sin(r) * dist;
		const cos = Mathf.cos(r) * dist;


		const x1 = -0.225 * offset;
		const y1 = -1.06 * offset;
		Draw.rect(Core.atlas.find("光耀旧世界-鹰隼-rotator-右"),
			unit.x + Angles.trnsx(r, x1, y1),
			unit.y + Angles.trnsy(r, x1, y1),
			r + Time.time * 25);

		const x2 = -0.225 * offset;
		const y2 = 1.06 * offset;
		Draw.rect(Core.atlas.find("光耀旧世界-鹰隼-rotator-左"),
			unit.x + Angles.trnsx(r, x2, y2),
			unit.y + Angles.trnsy(r, x2, y2),
			-(r + Time.time * 25));	
	}
});
鹰隼.constructor = () => extend(UnitEntity, {})

const 鹰隼改 = extend(UnitType, "鹰隼改", {
	draw(unit) {
		this.super$draw(unit);
		
		const offset = 1.6 * Vars.tilesize;
		const dist = Math.sqrt(2 * offset * offset)

		const r = unit.rotation;
		const sin = Mathf.sin(r) * dist;
		const cos = Mathf.cos(r) * dist;


		const x1 = -0.225 * offset;
		const y1 = -1.06 * offset;
		Draw.rect(Core.atlas.find("光耀旧世界-鹰隼改-rotator-右"),
			unit.x + Angles.trnsx(r, x1, y1),
			unit.y + Angles.trnsy(r, x1, y1),
			r + Time.time * 25);

		const x2 = -0.225 * offset;
		const y2 = 1.06 * offset;
		Draw.rect(Core.atlas.find("光耀旧世界-鹰隼改-rotator-左"),
			unit.x + Angles.trnsx(r, x2, y2),
			unit.y + Angles.trnsy(r, x2, y2),
			-(r + Time.time * 25));	
	}
});
鹰隼改.constructor = () => extend(UnitEntity, {})
