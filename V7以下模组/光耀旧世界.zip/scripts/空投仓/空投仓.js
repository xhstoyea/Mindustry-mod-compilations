//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require('func');

exports.空降仓 = (() => {
var myBlock = extendContent(StorageBlock, '空降仓', {
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	}
});
myBlock.itemCapacity = 0;
myBlock.localizedName = "空降仓";
myBlock.size = 3;
myBlock.health = 3000;
myBlock.buildVisibility = BuildVisibility.debugOnly;
myBlock.category = Category.logic;
myBlock.requirements = ItemStack.with(
	F.fi("Al"), 1200,
    F.fi("Fe"), 980,
	F.fi("Mg"), 750,
    F.fi("ghbl"), 400,
	F.fi("C60"), 250,
    F.fi("Fe-C"), 160,
	F.fi("Mg-Al"), 100,
	F.fi("C60"), 30,
    F.fi("Ti+"), 10
);
myBlock.buildType = () => {
	const ent = extendContent(StorageBlock.StorageBuild, myBlock, {
        draw(){
			this.super$draw();
			
            Draw.color(Color.valueOf("ff0000"));
            Draw.alpha(Mathf.sin(Time.time*0.02)*1);
            Draw.blend(Blending.additive);
            Draw.rect(Core.atlas.find("光耀旧世界-空降仓-top"), this.x, this.y);
            Draw.blend();
			Draw.reset();
		}
	});
	return ent;
};
return myBlock;
})();

exports.大型空降仓 = (() => {
var myBlock = extendContent(StorageBlock, '大型空降仓', {
	setBars(){
		this.bars.add("血条",
            func(e =>
		        new Bar(
					prov(() => e.health + " / " + e.maxHealth),
			        prov(() => Color.valueOf("#ff0000"), 1),
			        floatp(() => e.healthf())
	            )
            )
		);
		this.super$setBars();
		this.bars.remove("health");
	}
});
myBlock.itemCapacity = 0;
myBlock.localizedName = "大型空降仓";
myBlock.size = 9;
myBlock.health = 130000;
myBlock.buildVisibility = BuildVisibility.debugOnly;
myBlock.category = Category.logic;
myBlock.requirements = ItemStack.with(
	F.fi("Al"), 1200 * 10,
    F.fi("Fe"), 980 * 10,
	F.fi("Mg"), 750 * 10,
    F.fi("ghbl"), 400 *10,
	F.fi("C60"), 250 * 10,
    F.fi("Fe-C"), 160 * 10,
	F.fi("Mg-Al"), 100 * 10,
	F.fi("C60"), 30 * 10,
    F.fi("Ti+"), 10 * 10
);
myBlock.buildType = () => {
	const ent = extendContent(StorageBlock.StorageBuild, myBlock, {
        draw(){
			this.super$draw();
			
            Draw.color(Color.valueOf("1E90FF"));
            Draw.alpha(Mathf.sin(Time.time*0.02)*1);
            Draw.blend(Blending.additive);
            Draw.rect(Core.atlas.find("光耀旧世界-大型空降仓-top"), this.x, this.y);
            Draw.blend();
			Draw.reset();
		}
	});
	return ent;
};
return myBlock;
})();