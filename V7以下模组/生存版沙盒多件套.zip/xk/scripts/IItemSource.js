const MAXspeed=1000
const IItemSource=extendContent(Unloader,"InfiniteItemSource",{
    canDump:(tile,to,item)=>true,
    update:function(tile){
        const entity=tile.ent();
        if(entity.sortItem==null)return;
        var time=0;
        do{
            entity.items.set(entity.sortItem,1);
            this.tryDump(tile,entity.sortItem);
        }while(entity.items.get(tile.entity.sortItem)==0&&time++<=MAXspeed);
        entity.items.set(entity.sortItem,0);
    },
    draw:function(tile){
        this.super$draw(tile);
        const entity=tile.ent();
        Draw.color(entity.sortItem==null?Color.clear:entity.sortItem.color);
        Draw.rect("center",tile.worldx(),tile.worldy());
        Draw.color();
    }
});
IItemSource.requirements(Category.distribution,BuildVisibility.shown,ItemStack.with());
IItemSource.alwaysUnlocked=true;
IItemSource.health=10000;
IItemSource.localizedName=Core.bundle.get("最终型物品源");
IItemSource.description=Core.bundle.format("效果等于1000个普通物品源",MAXspeed);