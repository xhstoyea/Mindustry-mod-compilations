const MAXrange=1000;
const DamageRange=5;
const IAreaClear=extendContent(Block,"InfiniteAreaClear",{
    buildConfiguration:(tile,table)=>{table.addImageButton(Icon.upOpen,Styles.clearTransi,run(()=>{tile.configure(0)})).size(60);},
    configured:(tile,value)=>{
        const target=Units.closestTarget(tile.getTeam(),tile.drawx(),tile.drawy(),MAXrange*8);
        if(target!=null)
            Damage.damage(tile.getTeam(),target.x,target.y,DamageRange*8,1E15,true);
    },
    drawSelect:function(tile){
        const entity=tile.ent();
        this.super$drawSelect(tile);
        const target=Units.closestTarget(tile.getTeam(),tile.drawx(),tile.drawy(),MAXrange*8);
        if(target!=null){
            Draw.color(Color.valueOf("#ffffff"));
            Drawf.tri(tile.drawx(),tile.drawy(),5,Mathf.dst(tile.drawx(),tile.drawy(),target.x,target.y)*1.3,entity.angleTo(target));
            Fill.circle(tile.drawx(),tile.drawy(),4);
            Lines.stroke(1.725);
            Lines.square(target.x,target.y,22,45+Time.time()*3);
            Lines.square(target.x,target.y,13.45,45-Time.time()*3);
        }
    }
});
IAreaClear.requirements(Category.turret,BuildVisibility.shown,ItemStack.with());
IAreaClear.alwaysUnlocked=true;
IAreaClear.health=10000;
IAreaClear.update=true;
IAreaClear.solid=true;
IAreaClear.configurable=true;
IAreaClear.size=2;
IAreaClear.localizedName=Core.bundle.get("手动AI自爆器");
IAreaClear.description=Core.bundle.format("手动自爆敌人AI",MAXrange,DamageRange);