const IPowerSource=extendContent(PowerSource,"InfinitePowerSource",{
    getPowerProduction:tile=>9223372036854775807
});
IPowerSource.requirements(Category.power,BuildVisibility.shown,ItemStack.with());
IPowerSource.alwaysUnlocked=true;
IPowerSource.maxNodes=1E8;
IPowerSource.laserRange=1E2;
IPowerSource.health=10000;
IPowerSource.localizedName=Core.bundle.get("最终型无限电");
IPowerSource.description=Core.bundle.get("效果等于一大堆普通无限电");
