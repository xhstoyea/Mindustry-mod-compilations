function buttonrun(tile,id){
var units = Vars.content.units();
var unit = units.get(id).create(tile.getTeam());
unit.set(tile.drawx() + Mathf.range(4), tile.drawy() + Mathf.range(4)+20);
unit.add();
}
const 单位生成 = extendContent(MessageBlock, "dwsc", {
 buildConfiguration:function(tile, table){
 var entity = tile.ent();
 var units = Vars.content.units();
 var group = new ButtonGroup();
 var Buttons = new Table();
 Buttons.defaults().size(38);
 group.setMinCheckCount(0);
 for(var i = 0; i < units.size; i++){
 eval("var button =Buttons.addImageButton(TextureRegionDrawable(units.get(i).icon(Cicon.small)), Styles.clearTransi,35, run(() => { entity.message="+i+"; buttonrun(tile,"+i+")})).size(40).group(group)")
if(i % 4 == 3){
Buttons.row();
}
}
table.add(Buttons);
 },
 configured(tile,player,value){
 },
 
draw(tile){

var units = Vars.content.units();
var entity = tile.ent();
if(entity.message!=""&&entity.message!=null){
var region = units.get(Number(entity.message)).icon(Cicon.small);
Draw.rect(region, tile.drawx(), tile.drawy());
}
}
})