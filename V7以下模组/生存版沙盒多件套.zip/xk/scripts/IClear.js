const MAXrange=1000;
const IClear=extendContent(Block,"InfiniteClear",{
    update:tile=>{
        const target=Units.closestTarget(tile.getTeam(),tile.drawx(),tile.drawy(),MAXrange*8);
        if(target!=null)
            Damage.damage(tile.getTeam(),tile.drawx(),tile.drawy(),MAXrange*8,1E15,true);
    }
});
IClear.requirements(Category.turret,BuildVisibility.shown,ItemStack.with());
IClear.alwaysUnlocked=true;
IClear.health=10000;
IClear.update=true;
IClear.solid=true;
IClear.size=2;
IClear.localizedName=Core.bundle.get("自动AI屏蔽器");
IClear.description=Core.bundle.format("全图屏蔽敌人AI",MAXrange);