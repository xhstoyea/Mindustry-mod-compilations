const ILiquidSource=extendContent(LiquidSource,"InfiniteLiquidSource",{});
ILiquidSource.requirements(Category.liquid,BuildVisibility.shown,ItemStack.with());
ILiquidSource.alwaysUnlocked=true;
ILiquidSource.health=10000;
ILiquidSource.localizedName=Core.bundle.get("最终型液体源");
ILiquidSource.description=Core.bundle.get("效果等于1000个普通液体源");