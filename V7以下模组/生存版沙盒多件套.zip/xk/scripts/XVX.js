const MAXspeed=10000
const XVX=extendContent(Unloader,"XVX",{
    canDump:(tile,to,item)=>true,
    update:function(tile){
        const entity=tile.ent();
        if(entity.sortItem==null)return;
        var time=0;
        do{
            entity.items.set(entity.sortItem,1);
            this.tryDump(tile,entity.sortItem);
        }while(entity.items.get(tile.entity.sortItem)==0&&time++<=MAXspeed);
        entity.items.set(entity.sortItem,0);
    },
    draw:function(tile){
        this.super$draw(tile);
        const entity=tile.ent();
        Draw.color(entity.sortItem==null?Color.clear:entity.sortItem.color);
        Draw.rect("center",tile.worldx(),tile.worldy());
        Draw.color();
    }
});
XVX.requirements(Category.distribution,BuildVisibility.shown,ItemStack.with());
XVX.alwaysUnlocked=true;
XVX.health=10000;
XVX.localizedName=Core.bundle.get("究级物品源");
XVX.description=Core.bundle.format("效果1秒几百K应该有了吧",MAXspeed);