//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const lib = require('前置/lib');
const dsGlobal = require('前置/ds-global');

const chanceDeflect = 10;
const deflectAngle = 60;
var deflectSound = Sounds.none;
const shieldColor = Color.valueOf("9999ff");
const shieldColor2 = Color.valueOf("ff0000");

function deflect(building, chanceDeflect, bullet) {
    if (chanceDeflect > 0) {
        const { x, y, team, tile } = building;
        if (bullet.vel.len() <= 0.1 || !bullet.type.reflectable) return false;

        if (!Mathf.chance(chanceDeflect / bullet.damage)) return false;

        deflectSound.at(tile, Mathf.random(0.9, 1.1));

        bullet.vel.x *= -1;
        bullet.vel.y *= -1;
        bullet.vel.setAngle(Mathf.random(deflectAngle) - deflectAngle / 2 + bullet.vel.angle());

        bullet.owner = building;
        bullet.team = team;
        bullet.time = (bullet.time + 1);

        return true;
    }
    return false;
}

const block = new JavaAdapter(ForceProjector, {
    load() {
        this.super$load();
        deflectSound = Sounds.none;
    },
    setStats() {
        this.super$setStats();
        if (chanceDeflect > 0) this.stats.add(Stat.baseDeflectChance, chanceDeflect, StatUnit.none);
    },
    isHidden() { return !dsGlobal.掠夺者科技封锁(); },
}, '反射盾');

block.buildVisibility = BuildVisibility.shown;
block.category = null;
block.size = 3;

const F = require("func");

block.requirements = ItemStack.with(
    F.fi("Mg-Al"), 2500,
	F.fi("C60"), 1000,
	F.fi("Ti+"), 500,
	F.fi("Pu"), 100,
	F.fi("掠夺者科技点"), 3 * 3 * 50
);

block.localizedName = "电磁反射盾";
block.size = 2;
block.radius = 100;
block.phaseRadiusBoost = 100;
block.phaseShieldBoost = 1200;
block.shieldHealth = 800;
block.cooldownNormal = 2.5;
block.cooldownLiquid = 5.5;
block.cooldownBrokenBase = 1;

const myItems = require("物品");

block.consumes.item(myItems.能源水晶).boost();
block.phaseUseTime = 60 * 2;
block.consumes.power(50);

const shieldConsumer = (paramEntity) => cons(trait => {
    if (trait.team != paramEntity.team
        && trait.type.absorbable
        && Intersector.isInsideHexagon(paramEntity.x, paramEntity.y, paramEntity.realRadius() * 2, trait.x, trait.y)) {
        if (!deflect(paramEntity, chanceDeflect, trait)) {
            trait.absorb();
            Fx.absorb.at(trait);
        }
        paramEntity.hit = 1;
        paramEntity.buildup += trait.damage * paramEntity.warmup;
    }
});
lib.setBuildingSimpleAA(block, ForceProjector.ForceBuild, block => ({

    updateTile() {
        const {
            consumes, shieldHealth, phaseShieldBoost, cooldownNormal, cooldownBrokenBase, cooldownLiquid, timerUse, phaseUseTime
        } = this.block;
        const {
            buildup, phaseHeat, broken, team, x, y, warmup
        } = this;

        var phaseValid = consumes.get(ConsumeType.item).valid(this);

        this.phaseHeat = Mathf.lerpDelta(this.phaseHeat, Mathf.num(phaseValid), 0.1);

        if (phaseValid && !this.broken && this.timer.get(timerUse, phaseUseTime) && this.efficiency() > 0) {
            this.consume();
        }

        this.radscl = Mathf.lerpDelta(this.radscl, this.broken ? 0 : this.warmup, 0.05);

        if (Mathf.chanceDelta(this.buildup / this.breakage * 0.1)) {
            Fx.reactorsmoke.at(this.x + Mathf.range(tilesize / 2), this.y + Mathf.range(tilesize / 2));
        }

        this.warmup = Mathf.lerpDelta(this.warmup, this.efficiency(), 0.1);

        if (this.buildup > 0) {
            var scale = !this.broken ? cooldownNormal : cooldownBrokenBase;
            var cons = consumes.get(ConsumeType.liquid);
            if (cons.valid(this)) {
                cons.update(this);
                scale *= (cooldownLiquid * (1 + (this.liquids.current().heatCapacity - 0.4) * 0.9));
            }

            this.buildup -= this.delta() * scale;
        }

        if (this.broken && this.buildup <= 0) {
            this.broken = false;
        }

        if(buildup >= shieldHealth + phaseShieldBoost * phaseHeat && !broken){
            this.broken = true;
            this.buildup = shieldHealth;
            // Fx.shieldBreak.at(x, y, this.realRadius(), team.color);
            Fx.shieldBreak.at(x, y, this.realRadius(), shieldColor);
        }

        if (this.hit > 0) {
            this.hit -= 1 / 5 * Time.delta;
        }

        var realRadius = this.realRadius();

        if (realRadius > 0 && !this.broken) {
            Groups.bullet.intersect(this.x - realRadius, this.y - realRadius, realRadius * 2, realRadius * 2, shieldConsumer(this));
        }
    },
    drawShield() {
        var x = this.x;
        var y = this.y;
        var hit = this.hit;
        if (!this.broken) {
            var radius = this.realRadius();
            Draw.z(Layer.shields);
            Draw.color(shieldColor, shieldColor2, Mathf.clamp(hit));
            if (Core.settings.getBool("animatedshields")) {
                Fill.poly(x, y, 6, radius);
            } else {
                Lines.stroke(1.5);
                Draw.alpha(0.09 + Mathf.clamp(0.08 * hit));
                Fill.poly(x, y, 6, radius);
                Draw.alpha(1);
                Lines.poly(x, y, 6, radius);
                Draw.reset();
            }
        }
        Draw.reset();
    },
}));

F.techNode(F.fb("电磁脉冲"), block, ItemStack.with(
    F.fi("Mg-Al"), 2500 * 25,
	F.fi("C60"), 1000 * 25,
	F.fi("Ti+"), 500 * 25,
	F.fi("Pu"), 100 * 25,
	F.fi("普通科技点"), 3 * 3 * 60
));

exports.电磁反射盾 = block;