//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const lib = require('前置/lib');
const dsGlobal = require('前置/ds-global');

var 走狗 = extendContent(UnitType, '走狗', {});
走狗.constructor = () => extend(MechUnit, {});

var 走狗工厂 = extendContent(Wall, '走狗工厂', {
	isHidden() { return !dsGlobal.虫族科技封锁(); },
	setBars(){
	    this.super$setBars();

	    this.bars.add("生产次数",
            func(e =>
		        new Bar(
					prov(() => "生产次数: " + e.getKil() + "/9"),
			        prov(() => Color.valueOf("#ff3333"), 1),
			        floatp(() => e.getKil() / 9)
	            )
	        )
        )
		this.bars.add("生产时间",
			func(e =>
				new Bar(
					prov(() => "生产进度" + e.getWca()),
					prov(() => Color.valueOf("#ffff77"), 1),
					floatp(() => Math.floor(e.getTimer() / 60) / 15)
				)
			)
		)
    }
});

lib.setBuilding(走狗工厂, Block => {
	var timer = 0;
	var kil = 0;
	var wca = "[red]";
	return new JavaAdapter(Wall.WallBuild, {
		draw(){
            this.super$draw();
			
			if(kil <= 0){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-1"), this.x, this.y);
			}
			
			if(kil <= 1){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-2"), this.x, this.y);
			}
			
			if(kil <= 2){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-3"), this.x, this.y);
			}
			
			if(kil <= 3){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-4"), this.x, this.y);
			}
			
			if(kil <= 4){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-5"), this.x, this.y);
			}
			
			if(kil <= 5){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-6"), this.x, this.y);
			}
			
			if(kil <= 6){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-7"), this.x, this.y);
			}
			
			if(kil <= 7){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-8"), this.x, this.y);
			}
			
			if(kil <= 8){
			}else{
				Draw.rect(Core.atlas.find("光耀旧世界-走狗工厂-9"), this.x, this.y);
			}
				
		},
		updateTile(){
			
		if(kil >= 9){
		wca = "[red][已完成!]";
		}else{	
			timer += Time.delta * Vars.state.rules.unitBuildSpeedMultiplier;
		}
		
		if(kil >= 9){
		}else{	
			if(timer >= 900){
			走狗.spawn(this.team, this.x + Mathf.range(1), this.y + Mathf.range(1));
			timer = 0;
			kil += 1;
			};
		}},
		
		getTimer() {
			return timer
		},
		getKil() {
			return kil
		},
		getWca() {
			return wca
		},

		onDestroyed (){
			走狗.spawn(this.team, this.x + Mathf.range(1), this.y + Mathf.range(1));
			走狗.spawn(this.team, this.x + Mathf.range(1), this.y + Mathf.range(1));
			走狗.spawn(this.team, this.x + Mathf.range(1), this.y + Mathf.range(1));
			走狗.spawn(this.team, this.x + Mathf.range(1), this.y + Mathf.range(1));
		}
	},走狗工厂 );	
});
走狗工厂.update = true 
走狗工厂.solid = false;
走狗工厂.breakable = false;
走狗工厂.placeableLiquid = true;
走狗工厂.health = 500;
走狗工厂.size = 3;
走狗工厂.buildCostMultipler = 0.000001;
走狗工厂.unitCapModifier = 5;