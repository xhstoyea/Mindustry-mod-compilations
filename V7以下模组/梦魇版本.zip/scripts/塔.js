//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const dsGlobal = require('前置/ds-global');

const 电磁脉冲 = extendContent(ItemTurret, "电磁脉冲", {
	isHidden() { return !dsGlobal.人族科技封锁(); },
});

const xvxst = extendContent(ItemTurret, "xvx-st", {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
});
const xvxjqt = extendContent(ItemTurret, "xvx-jqt", {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
});
const xvxhp = extendContent(ItemTurret, "xvx-hp", {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
});
const xvxhdfsj = extendContent(ItemTurret, "xvx-hdfsj", {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
});
const xvxgzddt = extendContent(ItemTurret, "xvx-gzddt", {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
});
const xvxdf = extendContent(PowerTurret, "xvx-df", {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
});
const xvxfkp = extendContent(ItemTurret, "xvx-fkp", {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
});
const W3 = extendContent(ItemTurret, "W-3", {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
});
const bullet3T = extendContent(ItemTurret, "bullet3-T", {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
});

const lib = require('前置/lib');

var 浮游 = extendContent(Item, 'fy', {});

//const emp = require('MI/empSparkBulletType');

const 浮游炮 = extendContent(ItemTurret, 'xvx-fy', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
});
浮游炮.buildCostMultipler = 0.000001;
浮游炮.ammoTypes.put(浮游, (() => {
    var 浮游分裂弹 = new JavaAdapter(BasicBulletType, {}, 3, 1, "光耀旧世界-fyx");
    浮游分裂弹.lifetime=180;
    浮游分裂弹.width=5;
    浮游分裂弹.height=5;
	浮游分裂弹.buildingDamageMultiplier = 0.4
    浮游分裂弹.splashDamageRadius = 50;
    浮游分裂弹.splashDamage = 1;
    浮游分裂弹.backColor = Color.valueOf("63B8FF");
    浮游分裂弹.frontColor = Color.valueOf("63B8FF");
	浮游分裂弹.trailColor = Color.valueOf("63B8FF");
    浮游分裂弹.homingPower = 10;
	浮游分裂弹.homingRange = 200;
	浮游分裂弹.pierce = true;
	浮游分裂弹.collides = true;
	浮游分裂弹.collidesAir = true;
	浮游分裂弹.collidesGround = true;
	浮游分裂弹.collidesTiles = true;
	浮游分裂弹.keepVelocity = false;
	浮游分裂弹.reflectable = true;
	浮游分裂弹.absorbable = true;
	浮游分裂弹.hittable = true;
	浮游分裂弹.smokeEffect = Fx.formsmoke;
	浮游分裂弹.shootEffect = Fx.formsmoke;
	浮游分裂弹.despawnEffect = Fx.plasticExplosionFlak;
	浮游分裂弹.hitEffect = Fx.blastExplosion;
	浮游分裂弹.status = StatusEffects.melting;
	浮游分裂弹.statusDuration = 240;
	浮游分裂弹.hitSize = 5;
	
	var 浮游弹 = new JavaAdapter(BasicBulletType, {}, 6.8, 100, "光耀旧世界-fyx");
    浮游弹.lifetime=600;
	浮游弹.knockback=100;
    浮游弹.width=15;
    浮游弹.height=15;
    浮游弹.splashDamageRadius = 50;
    浮游弹.splashDamage = 100;
    浮游弹.backColor = Color.valueOf("FF0000");
    浮游弹.frontColor = Color.valueOf("63B8FF");
	浮游弹.trailColor = Color.valueOf("63B8FF");
	浮游弹.fragBullets = 5;
    浮游弹.fragVelocityMin = 1;
	浮游弹.fragVelocityMax = 1;
	浮游弹.pierce = false;
	浮游弹.collides = true;
	浮游弹.collidesAir = true;
	浮游弹.collidesTiles = true;
	浮游弹.keepVelocity = false;
	浮游弹.reflectable = false;
	浮游弹.absorbable = true;
	浮游弹.hittable = true;
	浮游弹.hitTiles = true;
	浮游弹.smokeEffect = Fx.formsmoke;
	浮游弹.shootEffect = Fx.formsmoke;
	浮游弹.despawnEffect = Fx.plasticExplosionFlak;
	浮游弹.hitEffect = Fx.blastExplosion;
	浮游弹.status = StatusEffects.melting;
	浮游弹.statusDuration = 600;
	浮游弹.hitSize = 15;
	浮游弹.ammoMultiplier = 1;
	
	浮游弹.fragBullet = 浮游分裂弹;
    return 浮游弹;
})());


function createBuildLimit(limit) {
    const built = {};
    function _init_built_(team) {
        if (!built[team.id]) {
            built[team.id] = 0;
        }
    }
    function canBuild(team) {
        _init_built_(team);
        return built[team.id] < limit;
    }
    function addBuild(team) {
        _init_built_(team);
        return built[team.id]++;
    }
    function removeBuild(team) {
        _init_built_(team);
        return built[team.id]--;
    }
    return {
        canBuild: canBuild,
        addBuild: addBuild,
        removeBuild: removeBuild,
    }
}

var 巨核 = extendContent(Item, 'Ahd', {});
var 辐射弹 = extendContent(Item, 'Bhd', {});

const 导弹器限制 = createBuildLimit(1);

var 导弹器 = extend(ItemTurret, 'xvx-fsq', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
    canPlaceOn(tile, team) {
        if (!导弹器限制.canBuild(team)) {
            return false;
        }
        return this.super$canPlaceOn(tile, team);
    },
    drawPlace(x,y,rotation,valid) {
        if (!Vars.world.tile(x, y)) { return; }
        if (!导弹器限制.canBuild(Vars.player.team())) {
            this.drawPlaceText(
                Core.bundle.format("message.光耀旧世界.导弹器限制",1),
                x, y, valid
            );
        }
    },
});
导弹器.buildCostMultipler = 0.000001;
导弹器.ammoTypes.put(辐射弹, (() => {
    var 小辐射弹 = new JavaAdapter(BasicBulletType, {}, 2, 100, "光耀旧世界-44");
    小辐射弹.lifetime = 10000;
    小辐射弹.width = 15;
    小辐射弹.height = 15;
    小辐射弹.splashDamageRadius = 99999;
    小辐射弹.splashDamage = 5;
    小辐射弹.incendAmount = 60;
    小辐射弹.incendSpread = 100;
	小辐射弹.incendChance = 100;
	小辐射弹.statusDuration = 999999;
	小辐射弹.pierce = false;
	小辐射弹.hittable = false;
	小辐射弹.reflectable = false;
	小辐射弹.absorbable = true;
	小辐射弹.collidesTiles = true;
	小辐射弹.collidesTeam = true;
	小辐射弹.collidesGround = true;
	小辐射弹.collidesAir = true;
	小辐射弹.collides = true;
	小辐射弹.keepVelocity = true;
	小辐射弹.hitTiles = true;
	小辐射弹.status = StatusEffects.corroded;
	小辐射弹.hitSize = 15;
	
	var 大辐射弹 = new JavaAdapter(BasicBulletType, {}, 0.5, 1000, "光耀旧世界-44");
    大辐射弹.lifetime = 10000;
    大辐射弹.width = 200;
    大辐射弹.height = 200;
    大辐射弹.splashDamageRadius = 99999;
    大辐射弹.splashDamage = 0;
	大辐射弹.statusDuration = 9999;
	大辐射弹.pierce = false;
	大辐射弹.hittable = false;
	大辐射弹.reflectable = false;
	大辐射弹.absorbable = false;
	大辐射弹.collidesTiles = true;
	大辐射弹.collidesTeam = false;
	大辐射弹.collidesGround = true;
	大辐射弹.collidesAir = true;
	大辐射弹.collides = true;
	大辐射弹.keepVelocity = true;
	大辐射弹.hitTiles = true;
	大辐射弹.status = StatusEffects.freezing;
	大辐射弹.speedMultiplier = 0.0001;
	大辐射弹.armorMultiplier = 0.0001;
	大辐射弹.effect = Fx.freezing;
	大辐射弹.homingPower = 99999;
	大辐射弹.homingRange = 99999;
	大辐射弹.incendAmount = 10000;
	大辐射弹.incendSpread = 1000000;
	大辐射弹.incendChance = 100;
	大辐射弹.fragBullets = 1000;
	大辐射弹.fragVelocityMin = 1;
	大辐射弹.fragVelocityMax = 20;
	大辐射弹.hitSize = 200;
    大辐射弹.ammoMultiplier = 1;
	
	大辐射弹.fragBullet = 小辐射弹;
    return 大辐射弹;
})());

导弹器.ammoTypes.put(巨核, (() => {
    var 补刀辐射 = new JavaAdapter(BasicBulletType, {}, 1, 1000, "光耀旧世界-55");
    补刀辐射.width = 30;
    补刀辐射.height = 30;
	补刀辐射.ammoMultiplier = 1;
	补刀辐射.inaccuracy = 0;
    补刀辐射.splashDamage = 100;
	补刀辐射.splashDamageRadius = 600;
	补刀辐射.pierce = false;
	补刀辐射.hittable = false;
	补刀辐射.reflectable = false;
	补刀辐射.absorbable = false;
	补刀辐射.collidesTiles = false;
	补刀辐射.collidesTeam = false;
	补刀辐射.collidesGround = false;
	补刀辐射.collidesAir = false;
	补刀辐射.collides = false;
	补刀辐射.keepVelocity = false;
	补刀辐射.lifetime = 120;
	补刀辐射.hitSize = 30;
	
	var 低层爆炸 = new JavaAdapter(BasicBulletType, {}, 1, 10000, "光耀旧世界-33");
    低层爆炸.width = 50;
    低层爆炸.height = 50;
	低层爆炸.ammoMultiplier = 1;
	低层爆炸.inaccuracy = 0;
    低层爆炸.splashDamage = 1000;
	低层爆炸.splashDamageRadius = 120;
	低层爆炸.pierce = false;
	低层爆炸.hittable = false;
	低层爆炸.collidesTiles = true;
	低层爆炸.collidesTeam = false;
	低层爆炸.collidesAir = true;
	低层爆炸.collidesGround = true;
	低层爆炸.collides = true;
	低层爆炸.keepVelocity = true;
	低层爆炸.hitTiles = true;
	低层爆炸.lifetime = 1800;
	低层爆炸.fragBullets = 1;
	低层爆炸.fragVelocityMin = 0;
	低层爆炸.fragVelocityMax = 0;
	低层爆炸.hitSize = 50;
	
	低层爆炸.fragBullet = 补刀辐射;
	
	var 中层光爆 = new JavaAdapter(BasicBulletType, {}, 0.5, 100000, "光耀旧世界-22");
    中层光爆.width = 150;
    中层光爆.height = 150;
	中层光爆.ammoMultiplier = 1;
	中层光爆.inaccuracy = 0;
    中层光爆.splashDamage = 10000;
	中层光爆.splashDamageRadius = 300;
	中层光爆.pierce = false;
	中层光爆.hittable = false;
	中层光爆.collidesTiles = true;
	中层光爆.collidesTeam = false;
	中层光爆.collidesAir = true;
	中层光爆.collidesGround = true;
	中层光爆.collides = true;
	中层光爆.keepVelocity = true;
	中层光爆.hitTiles = true;
	中层光爆.lifetime = 3000;
	中层光爆.fragBullets = 50;
	中层光爆.fragVelocityMin = 1;
	中层光爆.fragVelocityMax = 20;
	中层光爆.hitSize = 150;
	
	中层光爆.fragBullet = 低层爆炸;
	
	var 高层核爆 = new JavaAdapter(BasicBulletType, {}, 0.1, 1000000, "光耀旧世界-11");
    高层核爆.width = 350;
    高层核爆.height = 350;
	高层核爆.ammoMultiplier = 1;
	高层核爆.inaccuracy = 0;
    高层核爆.splashDamage = 100000;
	高层核爆.splashDamageRadius = 600;
	高层核爆.pierce = false;
	高层核爆.hittable = false;
	高层核爆.reflectable = false;
	高层核爆.absorbable = false;
	高层核爆.collidesTiles = true;
	高层核爆.collidesTeam = false;
	高层核爆.collidesGround = true;
	高层核爆.collidesAir = true;
	高层核爆.collides = true;
	高层核爆.keepVelocity = true;
	高层核爆.hitTiles = true;
	高层核爆.lifetime = 6000;
	高层核爆.fragBullets = 50;
	高层核爆.fragVelocityMin = 1;
	高层核爆.fragVelocityMax = 20;
	高层核爆.hitSize = 350;

	高层核爆.fragBullet = 中层光爆;
    return 高层核爆;
})());
导弹器.buildType = prov(() => {
    return new JavaAdapter(ItemTurret.ItemTurretBuild, {
        // create(block, team) {
        //     this.super$create(block, team);
        //     addBuild(team);
        // },
        add() {
            this.super$add();
            if (this.team != Team.derelict) {
                导弹器限制.addBuild(this.team);
            }
        },
        readBase(read) {
            this.super$readBase(read);
            if (this.team != Team.derelict) {
                导弹器限制.addBuild(this.team);
            }
        },
        remove() {
            if (this.added) { 导弹器限制.removeBuild(this.team); }
            this.super$remove();
        },
    }, 导弹器);
});

//const lib = require('前置/lib');
//const blockTypes = require('前置/JSblock');

const items = require('物品');

/*
const kjd = items.普通科技点;
const {
    MgAl,xvxnqwz,Ti,C60,xvxai
} = items;
*/

const sx = require('xvx/伽马射线');

const gmxz = createBuildLimit(100);

var liquidRegion;
var topRegion;
var chargeRegions = []

var gm = extendContent(PowerTurret, '伽马射线塔', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
    load() {
        this.super$load()
		
		this.spaceRegion = Core.atlas.find(this.name + "-space");
		
        liquidRegion = lib.loadRegion('伽马射线塔-liquid')
        topRegion = lib.loadRegion('伽马射线塔-top')
        chargeRegions.push(lib.loadRegion('伽马射线塔-charge-1'))
        chargeRegions.push(lib.loadRegion('伽马射线塔-charge-2'))
        chargeRegions.push(lib.loadRegion('伽马射线塔-charge-3'))
        chargeRegions.push(lib.loadRegion('伽马射线塔-charge-4'))
        chargeRegions.push(lib.loadRegion('伽马射线塔-charge-5'))
        chargeRegions.push(lib.loadRegion('伽马射线塔-charge-6'))
        chargeRegions.push(lib.loadRegion('伽马射线塔-charge-7'))
        chargeRegions.push(lib.loadRegion('伽马射线塔-charge-8'))
        chargeRegions.push(lib.loadRegion('伽马射线塔-charge-9'))
        chargeRegions.push(lib.loadRegion('伽马射线塔-charge-10'))
        chargeRegions.push(lib.loadRegion('伽马射线塔-charge-11'))
    },
    myGetTr2() {
        return this.tr2;
    },
    canPlaceOn(tile, team) {
        if (!gmxz.canBuild(team)) {
            return false;
        }
        return this.super$canPlaceOn(tile, team);
    },
    drawPlace(x,y,rotation,valid) {
        if (!Vars.world.tile(x, y)) { return; }
        if (!gmxz.canBuild(Vars.player.team())) {
            this.drawPlaceText(
                Core.bundle.format("message.光耀旧世界.gmxz",1),
                x, y, valid
            );
        }
    },
});
gm.category = Category.turret;
gm.health = 10000;
gm.reloadTime = 6000;
gm.chargeTime = 0;
gm.chargeMaxDelay = 0;
gm.chargeEffects = 0;
gm.recoilAmount = 2;
gm.cooldown = 0.02;
gm.range = 10000;
gm.recoil = 6;
gm.restitution = 0.01;
gm.shots = 1;
gm.inaccuracy = 0;
gm.rotatespeed = 1;
gm.targetAir = true;
gm.targetGround = true;
gm.shootEffect = Fx.lancerLaserShoot;
gm.smokeEffect = Fx.none;
gm.chargeEffect = Fx.lancerLaserCharge;
gm.chargeBeginEffect = Fx.lancerLaserChargeBegin;
gm.coolantMultiplier = 15;
gm.hasItems = false;
gm.hasLiquids = true;
gm.liquidCapacity = 50;
gm.powerUse = 15000;
gm.buildCostMultipler = 0.000001;
gm.heatColor = Color.valueOf("ff9b59");
gm.requirements = ItemStack.with(
		items.MgAl,190000,
		items.xvxnqwz, 500,
		items.Ti, 90000,
		items.C60, 65000,
		items.xvxai, 800,
		items.普通科技点, 3840
);

const XXVVBB = new Color.valueOf("F08080");

lib.setBuildingSimple(gm, PowerTurret.PowerTurretBuild, {
    add() {
        this.super$add();
        if (this.team != Team.derelict) {
            gmxz.addBuild(this.team);
        }
    },
    readBase(read) {
        this.super$readBase(read);
        if (this.team != Team.derelict) {
            gmxz.addBuild(this.team);
        }
    },
    remove() {
        if (this.added) { gmxz.removeBuild(this.team); }
        this.super$remove();
    },
	draw() {
    this.super$draw();
		      
	Tmp.v1.trns(this.rotation - 90, 0, -this.recoil);
	Tmp.v1.add(this.x, this.y);
      
	Draw.color(XXVVBB.cpy().shiftHue(Time.time / 2).shiftValue(Mathf.absin(Time.time, 4, 0.15)));
	Draw.alpha(1);
	Draw.rect(gm.spaceRegion, Tmp.v1.x, Tmp.v1.y, this.rotation - 90);
	Draw.reset();
		
    const tr2 = gm.myGetTr2();

    Drawf.liquid(liquidRegion, this.x + tr2.x, this.y + tr2.y, this.liquids.total() / gm.liquidCapacity, this.liquids.current().color, this.rotation - 90);
    Draw.rect(topRegion, this.x + tr2.x, this.y + tr2.y, this.rotation - 90);

    const loadPercentLen = Math.max(0, (this.reload / this.block.reloadTime * 1.4 - 0.85)) * chargeRegions.length;
    for (var i = 0; i < chargeRegions.length; i++) {
        Draw.alpha(Interp.pow2In.apply(Mathf.clamp(loadPercentLen - i, 0, 1)));
        Draw.rect(chargeRegions[i], this.x + tr2.x, this.y + tr2.y, this.rotation - 90);
    }},
});
gm.shootType = sx.sx;