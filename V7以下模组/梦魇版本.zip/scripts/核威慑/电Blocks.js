//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const lib = require('前置/lib');
const dsGlobal = require('前置/ds-global');

exports.CG2 = (() => {
var myBlock = extendContent(BurnerGenerator, 'CG-2', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.PP1 = (() => {
var myBlock = extendContent(BurnerGenerator, 'PP-1', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.tyn1 = (() => {
var myBlock = extendContent(SolarGenerator, 'tyn1', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.tyn2 = (() => {
var myBlock = extendContent(SolarGenerator, 'tyn2', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.tyn3 = (() => {
var myBlock = extendContent(SolarGenerator, 'tyn3', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.tyn4 = (() => {
var myBlock = extendContent(SolarGenerator, 'tyn4', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();
//太阳能5级
exports.tyn5 = (() => {
var myBlock = extendContent(SolarGenerator, 'tyn5', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室() || !dsGlobal.作战研究中心(); },
});

const FFXXAA = new Color.valueOf("ff0000");

lib.setBuildingSimple(myBlock, SolarGenerator.SolarGeneratorBuild, {
        draw(){
            this.super$draw();
			
				/*
			    Tmp.c1.set(F.c("#ff0000")).lerp(F.c("#ffff00"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.1)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光A"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Tmp.c1.set(F.c("#ffff00")).lerp(F.c("#ff0000"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.1)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光B"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				*/
				
				Tmp.c1.set(F.c("#ff0000")).lerp(F.c("#ffff00"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.1)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光A2"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Tmp.c1.set(F.c("#ffff00")).lerp(F.c("#ff0000"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.1)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光B2"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Tmp.c1.set(F.c("#9999ff")).lerp(F.c("#00bbff"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.1)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光AA"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Tmp.c1.set(F.c("#00bbff")).lerp(F.c("#9999ff"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.1)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光BB"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Tmp.c1.set(F.c("#dddddd")).lerp(F.c("#444444"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.1)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光AAA"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Tmp.c1.set(F.c("#444444")).lerp(F.c("#dddddd"), Mathf.sin(Time.time*0.1)*2.5+0.5);
	
				Draw.mixcol(Tmp.c1, 1);
				Draw.alpha((0.35 + Mathf.sin(Time.time*0.1)*0.1));
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-发光BBB"), this.x, this.y);
				Draw.blend();
				Draw.mixcol();
                Draw.color();
				
				Draw.color(FFXXAA.cpy().shiftHue(Time.time / 2).shiftValue(Mathf.absin(Time.time, 4, 0.15)));
				Draw.alpha(100);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + 40, this.y + 40, -Time.time*1.5);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + -40, this.y + -40, -Time.time*1.5);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + 40, this.y + -40, -Time.time*1.5);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + -40, this.y + 40, -Time.time*1.5);
				
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + 40, this.y + 40, Time.time*1.5);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + -40, this.y + -40, Time.time*1.5);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + 40, this.y + -40, Time.time*1.5);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核"), this.x + -40, this.y + 40, Time.time*1.5);
				
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核A"), this.x, this.y, Time.time*2.5);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-核A"), this.x, this.y, -Time.time*2.5);
				Draw.reset();
				
				Draw.color(F.c("#ffff00"));
				Draw.alpha(0.5 + Mathf.sin(Time.time*0.2)*0.1);
				Draw.blend(Blending.additive);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-heat"), this.x, this.y);
				Draw.rect(Core.atlas.find("光耀旧世界-tyn5-heat2"), this.x, this.y);
				Draw.blend();
                Draw.reset();
				
				/*
				Draw.color(F.c("#000000"));
				Draw.alpha(0.8);
				var dst = Mathf.sin(Time.time*0.1, 6, Vars.tilesize * 16 / 6);
				var rot = Time.time*0.1 + 90;
				Lines.lineAngleCenter(
                this.x + Angles.trnsx(rot, dst),
                this.y + Angles.trnsy(rot, dst),
                rot + 90,
                16 * Vars.tilesize / 3
				);
				Draw.reset();
				*/
        },
		collision(bullet){
			this.super$collision(bullet);
			
			var lightningChance = 1
			var lightningDamage = 10
			
			if(lightningChance > 0){
                if(Mathf.chance(lightningChance)){
                    Lightning.create(this.team, F.c("#ff0000"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#ff5511"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#ff8800"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#ffbb00"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#ffff00"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#bbff00"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#77ff00"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#00ff00"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#00ff99"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#00ffcc"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#00ffff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#00bbff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#0066ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#0000ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#5300ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#7700ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#9900ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#cc00ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#ff00ff"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
					Lightning.create(this.team, F.c("#ff0088"), lightningDamage, this.x + Mathf.range(60), this.y + Mathf.range(60), bullet.rotation() + 180, 30 + Mathf.range(50));
                }
            }
			return true
		}
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.fission = (() => {
var myBlock = extendContent(BurnerGenerator, 'fission', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.fusion = (() => {
var myBlock = extendContent(BurnerGenerator, 'fusion', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.HydrogenFusion = (() => {
var myBlock = extendContent(BurnerGenerator, 'HydrogenFusion', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.powerdc = (() => {
var myBlock = extendContent(Battery, 'power-dc', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
myBlock.consumes.powerBuffered(250000);
return myBlock;
})();

exports.powerdcz = (() => {
var myBlock = extendContent(Battery, 'power-dc-z', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
myBlock.consumes.powerBuffered(1000000);
return myBlock;
})();

exports.powerdxg = (() => {
const laserColor1 = new Color.valueOf("ffff00");
const laserColor2 =	new Color.valueOf("ff0000");

var myBlock = extendContent(PowerNode, 'power-dxg', {
	isHidden() { return !dsGlobal.科技中心(); },
	setupColor(){
		Draw.color(laserColor1, laserColor2, 2 + Mathf.absin(3, 0.1));
		Draw.alpha(Renderer.laserOpacity);
    }
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.powergyx = (() => {
const laserColor1 = new Color.valueOf("ffff00");
const laserColor2 =	new Color.valueOf("ff0000");

var myBlock = extendContent(PowerNode, 'power-gyx', {
	isHidden() { return !dsGlobal.科技中心(); },
	setupColor(){
		Draw.color(laserColor1, laserColor2, 2 + Mathf.absin(3, 0.1));
		Draw.alpha(Renderer.laserOpacity);
    }
	/*drawLaser(){
		
        const angle1 = Angles.angle(x1, y1, x2, y2);
        const vx = Mathf.cosDeg(angle1); 
		const vy = Mathf.sinDeg(angle1);
        const len1 = size1 * Vars.tilesize / 2 - 1.5;
		const len2 = size2 * Vars.tilesize / 2 - 1.5;

        Drawf.laser(this.team, laser, laserEnd, x1 + vx*len1, y1 + vy*len1, x2 - vx*len2, y2 - vy*len2, 0.8);
    }*/
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.dr1 = (() => {
var myBlock = extendContent(ThermalGenerator, 'dr1', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.dr2 = (() => {
var myBlock = extendContent(ThermalGenerator, 'dr2', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.dr3 = (() => {
var myBlock = extendContent(ThermalGenerator, 'dr3', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.KZ0 = (() => {
var myBlock = extendContent(NuclearReactor, 'KZ-0', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.KZ1 = (() => {
var myBlock = extendContent(NuclearReactor, 'KZ-1', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.KZ2 = (() => {
var myBlock = extendContent(NuclearReactor, 'KZ-2', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.KZ3 = (() => {
var myBlock = extendContent(ImpactReactor, 'KZ-3', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.KZ4 = (() => {
var myBlock = extendContent(ImpactReactor, 'KZ-4', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.size = 5;
myBlock.health = 65000;
myBlock.category = Category.power;
myBlock.buildVisibility = BuildVisibility.shown;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();