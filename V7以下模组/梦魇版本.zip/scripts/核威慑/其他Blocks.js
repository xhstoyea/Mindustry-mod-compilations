//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const lib = require('前置/lib');
const dsGlobal = require('前置/ds-global');

exports.csd = (() => {
var myBlock = extendContent(Conveyor, 'csd', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.csd2 = (() => {
var myBlock = extendContent(ArmoredConveyor, 'csd2', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.海上运输带 = (() => {
var myBlock = extendContent(Conveyor, '海上运输带', {
	isHidden() { return !dsGlobal.人族科技封锁(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.csd3 = (() => {
var myBlock = extendContent(StackConveyor, 'csd3', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.csd4 = (() => {
var myBlock = extendContent(BufferedItemBridge, 'csd4', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.csd5 = (() => {
var myBlock = extendContent(ExtendingItemBridge, 'csd5', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.zq = (() => {
var myBlock = extendContent(MassDriver, 'zq', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.zqz = (() => {
var myBlock = extendContent(MassDriver, 'zq-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xzq = (() => {
var myBlock = extendContent(Unloader, 'xzq', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.ytdg = (() => {
var myBlock = extendContent(Conduit, 'ytdg', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.ytdg2 = (() => {
var myBlock = extendContent(Conduit, 'ytdg2', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.ytdg3 = (() => {
var myBlock = extendContent(ArmoredConduit, 'ytdg3', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.抗火导管 = (() => {
var myBlock = extend(ArmoredConduit, '抗火导管', {
    isHidden() { return !dsGlobal.掠夺者科技封锁(); },
});
myBlock.buildVisibility = BuildVisibility.shown;
myBlock.size = 1;
myBlock.health = 2000;
myBlock.liquidCapacity = 100;
myBlock.liquidPressure = 90;
myBlock.requirements = ItemStack.with(
    F.fi("Mg-Al"), 35,
    F.fi("ghbl"), 80,
    F.fi("掠夺者科技点"), 50
);
myBlock.category = null;

lib.setBuildingSimpleAA(myBlock, ArmoredConduit.ArmoredConduitBuild, block => ({
    moveLiquid(next, liquid) {
        if (!next) { return 0; }

        const hotLine = 0.7;
        const coldLine = 0.55;

        next = next.getLiquidDestination(this, liquid);
        if (next.team == this.team && next.block.hasLiquids && this.liquids.get(liquid) > 0) {
            var ofract = next.liquids.get(liquid) / next.block.liquidCapacity;
            var fract = this.liquids.get(liquid) / this.block.liquidCapacity * this.block.liquidPressure;
            var flow = Math.min(Mathf.clamp(fract - ofract) * this.block.liquidCapacity, this.liquids.get(liquid));
            flow = Math.min(flow, next.block.liquidCapacity - next.liquids.get(liquid));

            if (flow > 0 && ofract <= fract && next.acceptLiquid(this, liquid)) {
                next.handleLiquid(this, liquid, flow);
                this.liquids.remove(liquid, flow);
                return flow;
            } else if (next.liquids.currentAmount() / next.block.liquidCapacity > 0.1 && fract > 0.1) {
                var fx = (this.x + next.x) / 2.0;
                var fy = (this.y + next.y) / 2.0;
                var other = next.liquids.current();
                if ((liquid.temperature > hotLine && other.temperature < coldLine) || (other.temperature > hotLine && liquid.temperature < coldLine)) {
                    this.liquids.remove(liquid, Math.min(this.liquids.get(liquid), hotLine * Time.delta));
                    if (Mathf.chance(0.2 * Time.delta)) {
                        Fx.steam.at(fx, fy);
                    }
                }
            }
        }
    }
}));
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.ytdg4 = (() => {
var myBlock = extendContent(LiquidBridge, 'ytdg4', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.后勤单位工厂 = (() => {
var myBlock = extendContent(UnitFactory, '后勤单位工厂', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();