//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const F = require("func");
const lib = require('前置/lib');
const dsGlobal = require('前置/ds-global');

exports.孢子工厂 = (() => {
var myBlock = extendContent(Cultivator, '孢子工厂', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.孢子工厂x = (() => {
var myBlock = extendContent(Cultivator, '孢子工厂x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.爆混工厂 = (() => {
var myBlock = extendContent(GenericSmelter, '爆混工厂', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.爆混工厂x = (() => {
var myBlock = extendContent(AttributeSmelter, '爆混工厂x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.玻璃工厂 = (() => {
var myBlock = extendContent(GenericSmelter, '玻璃工厂', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.玻璃工厂x = (() => {
var myBlock = extendContent(AttributeSmelter, '玻璃工厂x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.硅工厂 = (() => {
var myBlock = extendContent(GenericSmelter, '硅工厂', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.硅工厂x = (() => {
var myBlock = extendContent(AttributeSmelter, '硅工厂x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.合金工厂 = (() => {
var myBlock = extendContent(GenericSmelter, '合金工厂', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.合金工厂x = (() => {
var myBlock = extendContent(AttributeSmelter, '合金工厂x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.硫工厂 = (() => {
var myBlock = extendContent(GenericSmelter, '硫工厂', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.硫工厂x = (() => {
var myBlock = extendContent(AttributeSmelter, '硫工厂x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.煤炭工厂 = (() => {
var myBlock = extendContent(GenericSmelter, '煤炭工厂', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.煤炭工厂x = (() => {
var myBlock = extendContent(AttributeSmelter, '煤炭工厂x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.attribute = Attribute.spores;
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.石墨工厂 = (() => {
var myBlock = extendContent(GenericSmelter, '石墨工厂', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.石墨工厂x = (() => {
var myBlock = extendContent(AttributeSmelter, '石墨工厂x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.attribute = Attribute.water;
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.塑钢工厂 = (() => {
var myBlock = extendContent(GenericSmelter, '塑钢工厂', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.塑钢工厂x = (() => {
var myBlock = extendContent(AttributeSmelter, '塑钢工厂x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.attribute = Attribute.water;
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.钍工厂 = (() => {
var myBlock = extendContent(GenericSmelter, '钍工厂', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.钍工厂x = (() => {
var myBlock = extendContent(AttributeSmelter, '钍工厂x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.织布机 = (() => {
var myBlock = extendContent(GenericSmelter, '织布机', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.织布机x = (() => {
var myBlock = extendContent(AttributeSmelter, '织布机x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.group = BlockGroup.logic;
myBlock.buildCostMultipler = 0.000001;
myBlock.drawer = new DrawWeave();
return myBlock;
})();

exports.钛化器 = (() => {
const myBlock = extend(Router, "钛化器", {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.chance = 1 / 25;
myBlock.health = 100;
myBlock.size = 1;
myBlock.category = null;
myBlock.buildVisibility = BuildVisibility.shown;
myBlock.localizedName = "钛化器";
myBlock.description = "输入任意资源转化变成钛,\n概率 25:1";
myBlock.details = "需要科技中心以解锁该方块";
myBlock.requirements = ItemStack.with(
	Items.copper, 300,
	Items.lead, 200,
	Items.graphite, 100,
	Items.silicon, 75,
	F.fi("普通科技点"), 100
);
F.techNode(F.fb("矿坑扩展核心"), myBlock, ItemStack.with(
	Items.copper, 3000 * 30,
	Items.lead, 2000 * 30,
	Items.titanium, 1000 * 30,
	Items.graphite, 1000 * 30,
	Items.silicon, 750 * 30
));
lib.setBuildingSimple(myBlock, Router.RouterBuild, {
	handleItem(source, item) {
		if (Mathf.chance(myBlock.chance)) {
			item = Items.titanium;
		}
		this.super$handleItem(source, item);
	},	
	draw(){
        this.super$draw();

		Draw.color(F.c("#66ffff"));
		Draw.alpha(Mathf.sin(Time.time*0.1)*0.2);
		Draw.blend(Blending.additive);
		Draw.rect(Core.atlas.find("光耀旧世界-钛化器-heat"), this.x, this.y);
		Draw.blend();
        Draw.reset();
    }
});
return myBlock;
})();

exports.钛变器 = (() => {
const myBlock = extend(Router, "钛变器", {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.矿坑扩展核心(); },
});
myBlock.chance = 1;
myBlock.health = 500;
myBlock.size = 2;
myBlock.category = null;
myBlock.buildVisibility = BuildVisibility.shown;
myBlock.localizedName = "钛变器";
myBlock.description = "输入任意资源直接变成钛,\n概率 百分百";
myBlock.details = "需要科技中心与矿坑扩展核心以解锁该方块";
myBlock.requirements = ItemStack.with(
	Items.copper, 1500,
	Items.lead, 1000,
	Items.titanium, 500,
	Items.graphite, 500,
	Items.silicon, 375,
	F.fi("普通科技点"), 1000
);
F.techNode(exports.钛化器, myBlock, ItemStack.with(
	Items.copper, 1500 * 30,
	Items.lead, 1000 * 30,
	Items.titanium, 500 * 30,
	Items.graphite, 500 * 30,
	Items.silicon, 375 * 30
));
lib.setBuildingSimple(myBlock, Router.RouterBuild, {
	handleItem(source, item) {
		if (Mathf.chance(myBlock.chance)) {
			item = Items.titanium;
		}
		this.super$handleItem(source, item);
	},	
	draw(){
        this.super$draw();

		Draw.color(F.c("#66ffff"));
		Draw.alpha(Mathf.sin(Time.time*0.1)*0.2);
		Draw.blend(Blending.additive);
		Draw.rect(Core.atlas.find("光耀旧世界-钛变器-heat"), this.x, this.y);
		Draw.blend();
        Draw.reset();
    }
});
return myBlock;
})();