//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const dsGlobal = require('前置/ds-global');

exports.yjPlant = (() => {
var myBlock = extendContent(GenericSmelter, 'yj-Plant', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.机械提速液工厂 = (() => {
var myBlock = extendContent(GenericSmelter, '机械提速液工厂', {
	isHidden() { return !dsGlobal.人族科技封锁(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.H2Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'H2-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.H2Plantz = (() => {
var myBlock = extendContent(GenericSmelter, 'H2-Plant-z', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.O2Plant = (() => {
var myBlock = extendContent(GenericSmelter, 'O2-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.O2Plantz = (() => {
var myBlock = extendContent(GenericSmelter, 'O2-Plant-z', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.HPlant = (() => {
var myBlock = extendContent(Separator, 'H-Plant', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.HPlantzx = (() => {
var myBlock = extendContent(Separator, 'H-Plant-z-x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.HPlantx = (() => {
var myBlock = extendContent(Separator, 'H-Plant-x', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.HPlantxx = (() => {
var myBlock = extendContent(Separator, 'H-Plant-x-x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.icez = (() => {
var myBlock = extendContent(GenericSmelter, 'ice-z', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.icex = (() => {
var myBlock = extendContent(GenericSmelter, 'ice-x', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.icec = (() => {
var myBlock = extendContent(GenericSmelter, 'ice-c', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.cxg = (() => {
var myBlock = extendContent(LiquidRouter, 'cxg', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xvxb = (() => {
var myBlock = extendContent(SolidPump, 'xvx-b', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xvxb0 = (() => {
var myBlock = extendContent(SolidPump, 'xvx-b0', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xvxbz = (() => {
var myBlock = extendContent(Pump, 'xvx-b-z', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xvxbzz = (() => {
var myBlock = extendContent(Pump, 'xvx-b-z-z', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xvxbc = (() => {
var myBlock = extendContent(SolidPump, 'xvx-b-c', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xvxbv = (() => {
var myBlock = extendContent(SolidPump, 'xvx-b-v', {
	isHidden() { return !dsGlobal.科技中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();

exports.xvxbx = (() => {
var myBlock = extendContent(SolidPump, 'xvx-b-x', {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
});
myBlock.buildCostMultipler = 0.000001;
return myBlock;
})();