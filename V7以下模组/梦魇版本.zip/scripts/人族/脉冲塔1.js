//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const fc = require("人族/fc");


const ionisedStatusFX = new Effect(24, e => {
    Draw.color(Color.white, Color.black, e.fin());
    Lines.stroke(e.fin() * 1);
    Lines.circle(e.x, e.y, e.fslope() * 5);
});
const ionisedStatus = extend(StatusEffect, "ionisedStatus", {});
ionisedStatus.speedMultiplier = 0.5;
ionisedStatus.armorMultiplier = 0.5;
ionisedStatus.damage = 0.2;
ionisedStatus.effect = ionisedStatusFX;
ionisedStatus.color  = Color.white;


const puverShoot = new Effect(30, e => {
  Draw.color(Color.valueOf("0A01b7"), Color.valueOf("56D7CA"), e.fslope());
  Draw.alpha(0.5);
  Fill.circle(e.x, e.y, e.fslope() * 5);
  Draw.color(Color.blue, Color.valueOf("0A01b7"), Color.valueOf("0A01b7"), e.fin());
  Angles.randLenVectors(e.id, 8, e.finpow() * 25, e.rotation, 10, (x, y) => {
    Fill.circle(e.x + x, e.y + y, 0.65 + e.fout() * 1.5);
  })
});

const shotTrail = new Effect(10, e => {
  Draw.color(Color.valueOf("0A01b7"), Color.valueOf("56D7CA"), e.fin());
  Lines.stroke(e.fout() * 2);
  Lines.circle(e.x, e.y, e.fin() * 4);
});

const shotHit = new Effect(40, e => {
  Draw.color(Color.valueOf("56D7CA"), Color.valueOf("0A01b7"), e.fin());
  Lines.stroke(e.fout() * 2);
  Lines.circle(e.x, e.y, e.fin() * 4);
});

const blast = new Effect(25, e => {
  Draw.color(Color.valueOf("0A01b7"), Color.valueOf("56D7CA"), e.fin());
  Lines.stroke(e.fin() * 2);
  Lines.circle(e.x, e.y, e.fout() * 2);
});

const shot = extend(MissileBulletType, {
    update(b){
        shotTrail.at(b.x, b.y);
        blastShot.create(b.owner, b.team, b.x, b.y, fc.rotationFC(b.rotation(), 90), fc.helix(7, 3, b.fin()));
        blastShot.create(b.owner, b.team, b.x, b.y, fc.rotationFC(b.rotation(), -90), fc.helix(7, 3, b.fin() ));
    }
});

const blastShot = extend(BasicBulletType, {});

const dsGlobal = require('前置/ds-global');
const puver = extendContent(PowerTurret, "脉冲塔1", {
  isHidden() { return !dsGlobal.人族科技封锁(); },
  icons(){
    return [
      Core.atlas.find("block-2"),
      Core.atlas.find("光耀旧世界-脉冲塔1")
    ];
  }
});

puver.localizedName = "脉冲塔(低级)";

puver.recoil = 1;
puver.restitution = 0.015;
puver.shootType = shot;

shot.damage = 25;
shot.speed = 3;
shot.lifetime = 35;
shot.knockback = 5;
shot.pierce = true;
shot.pierceBuilding = true;
shot.width = 0;
shot.height = 0;
shot.hitSize = 4
shot.collides = true;
shot.collidesTiles = true;
shot.hitEffect = Fx.none;
shot.despawnEffect = shotHit;
shot.shootEffect = puverShoot;
shot.hitSound = Sounds.none;

blastShot.damage = 1;
blastShot.speed = 3;
blastShot.lifetime = 5;
blastShot.knockback = 2;
blastShot.pierce = true;
blastShot.pierceBuilding = true;
blastShot.width = 0;
blastShot.height = 0;
blastShot.hitSize = 4;
blastShot.collides = true;
blastShot.collidesTiles = true;
blastShot.hitEffect = blast;
blastShot.despawnEffect = blast;
blastShot.shootEffect = puverShoot;
blastShot.smokeEffect = Fx.smokeCloud;
blastShot.status = ionisedStatus;
