//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

function createBuildLimit(limit) {
    const built = {};
    function _init_built_(team) {
        if (!built[team.id]) {
            built[team.id] = 0;
        }
    }
    function canBuild(team) {
        _init_built_(team);
        return built[team.id] < limit;
    }
    function addBuild(team) {
        _init_built_(team);
        return built[team.id]++;
    }
    function removeBuild(team) {
        _init_built_(team);
        return built[team.id]--;
    }
    return {
        canBuild: canBuild,
        addBuild: addBuild,
        removeBuild: removeBuild,
    }
}

const F = require("func");
const lib = require('前置/lib');
const dsGlobal = require('前置/ds-global');

const FFXXAA = new Color.valueOf("FFFFBB");
const MyColor = new Color.valueOf("ff8888");

const 特殊方块限制 = createBuildLimit(1);

const 科技中心 = extendContent(CoreBlock, "科技中心", {
	canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
        if (!特殊方块限制.canBuild(team)) {
            return false;
        }
        return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},
    drawPlace(x,y,rotation,valid) {
        if (!Vars.world.tile(x, y)) { return; }
        if (!特殊方块限制.canBuild(Vars.player.team())) {
            this.drawPlaceText(
                Core.bundle.format("message.光耀旧世界.特殊方块限制",1),
                x, y, valid
            );
        }
    },
	setBars(){
        this.super$setBars();
		
		this.stats.add(Stat.basePowerGeneration, "[#ff0000]永久[#ffffff] 500 能量/秒");
		this.bars.add("power",
            func(e =>
		        new Bar(
	                prov(() => Core.bundle.format("bar.poweroutput", Strings.fixed(e.getPowerProduction() * 60, 1))),
			        prov(() => MyColor.cpy().shiftHue(Time.time / 2).shiftValue(Mathf.absin(Time.time, 4, 0.15))), 
					floatp(() => 1.0)
	            )
	        )
        )
    },
	load() {
        this.super$load()
		
		this.spaceRegion = Core.atlas.find(this.name + "-space");
	},
});
科技中心.buildVisibility = BuildVisibility.shown;
科技中心.localizedName = "科技中心";
科技中心.description = "放置以解锁大部分科技";
科技中心.details = "可以当核心用，但是容量少的可怜，消耗单位数量上限2位以作为研究资源";
科技中心.health = 500;
科技中心.size = 4;
科技中心.unitCapModifier = -2;
科技中心.placeableLiquid = true;
科技中心.floating = true;
科技中心.targetable = false;
科技中心.hasItems = true;
科技中心.itemCapacity = 500;
科技中心.hasPower = true;
科技中心.hasLiquids = false;
科技中心.useColor = true;
科技中心.mapColor = Color.valueOf("00FFFF");
科技中心.outlineColor = Color.valueOf("00FFFF");
科技中心.absorbLasers = true;
科技中心.category = null;
科技中心.buildCostMultipler = 0.000001;
科技中心.requirements = ItemStack.with(
	Items.copper, 500, 
	Items.lead, 500, 
	Items.graphite, 500, 
	Items.titanium, 500, 
	Items.silicon, 500
);
F.techNode(Blocks.coreShard, 科技中心, ItemStack.with(
	Items.copper, 500 * 10, 
	Items.lead, 500 * 10, 
	Items.graphite, 500 * 10, 
	Items.titanium, 500 * 10, 
	Items.silicon, 500 * 10
));
lib.setBuildingSimple(科技中心, CoreBlock.CoreBuild, {
	add() {
    this.super$add();
    if (this.team != Team.derelict) {
    特殊方块限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    特殊方块限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 特殊方块限制.removeBuild(this.team); }
    this.super$remove();
    },
	draw() {
    this.super$draw();

	Draw.color(FFXXAA.cpy().shiftHue(Time.time / 2).shiftValue(Mathf.absin(Time.time, 4, 0.15)));
	Draw.alpha(2.5);
	Draw.rect(科技中心.spaceRegion, this.x, this.y);
	Draw.reset();
	
	var z = Draw.z();
        Draw.z(Layer.blockOver);
        Draw.rect(Core.atlas.find("光耀旧世界-科技中心-核"), this.x, this.y, Time.time*3);
        Draw.z(z);
	},

	getPowerProduction(tile){
        return 8.334;
    }
});
exports.科技中心 = 科技中心;

const 特殊方块限制A = createBuildLimit(1);

const 作战实验室 = extendContent(CoreBlock, "作战实验室", {
	canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
        if (!特殊方块限制A.canBuild(team)) {
            return false;
        }
        return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},
    drawPlace(x,y,rotation,valid) {
        if (!Vars.world.tile(x, y)) { return; }
        if (!特殊方块限制A.canBuild(Vars.player.team())) {
            this.drawPlaceText(
                Core.bundle.format("message.光耀旧世界.特殊方块限制",1),
                x, y, valid
            );
        }
    },
	setBars(){
        this.super$setBars();

		this.stats.add(Stat.basePowerGeneration, "[#ff0000]永久[#ffffff] 1000 能量/秒");
		this.bars.add("power",
            func(e =>
		        new Bar(
	                prov(() => Core.bundle.format("bar.poweroutput", Strings.fixed(e.getPowerProduction() * 60, 1))),
			        prov(() => MyColor.cpy().shiftHue(Time.time / 2).shiftValue(Mathf.absin(Time.time, 4, 0.15))), 
					floatp(() => 1.0)
	            )
	        )
        )
    },
	load() {
        this.super$load()
		
		this.spaceRegion = Core.atlas.find(this.name + "-space");
	},
	isHidden() { return !dsGlobal.科技中心(); }
});
作战实验室.buildVisibility = BuildVisibility.shown;
作战实验室.localizedName = "作战实验室";
作战实验室.description = "放置以解锁炮塔，护盾，墙的科技";
作战实验室.details = "可以当核心用，但是容量挺少的，消耗单位数量上限5位以作为研究资源";
作战实验室.health = 1000;
作战实验室.size = 6;
作战实验室.unitCapModifier = -5;
作战实验室.placeableLiquid = true;
作战实验室.floating = true;
作战实验室.targetable = false;
作战实验室.hasItems = true;
作战实验室.itemCapacity = 1000;
作战实验室.hasPower = true;
作战实验室.hasLiquids = false;
作战实验室.useColor = true;
作战实验室.mapColor = Color.valueOf("00FFFF");
作战实验室.outlineColor = Color.valueOf("00FFFF");
作战实验室.absorbLasers = true;
作战实验室.category = null;
作战实验室.buildCostMultipler = 0.000001;
作战实验室.requirements = ItemStack.with(
	Items.copper, 800, 
	Items.lead, 800, 
	Items.graphite, 600, 
	Items.titanium, 500, 
	Items.silicon, 400,
	Items.plastanium, 300, 
	Items.surgeAlloy, 200
);
F.techNode(科技中心, 作战实验室, ItemStack.with(
	Items.copper, 800 * 10, 
	Items.lead, 800 * 10, 
	Items.graphite, 600 * 10, 
	Items.titanium, 500 * 10, 
	Items.silicon, 400 * 10,
	Items.plastanium, 300 * 10, 
	Items.surgeAlloy, 200 * 10
));
lib.setBuildingSimple(作战实验室, CoreBlock.CoreBuild, {
	add() {
    this.super$add();
    if (this.team != Team.derelict) {
    特殊方块限制A.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    特殊方块限制A.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 特殊方块限制A.removeBuild(this.team); }
    this.super$remove();
    },
	draw() {
    this.super$draw();

	Draw.color(FFXXAA.cpy().shiftHue(Time.time / 2).shiftValue(Mathf.absin(Time.time, 4, 0.15)));
	Draw.alpha(2.5);
	Draw.rect(作战实验室.spaceRegion, this.x, this.y);
	Draw.reset();
	
	var z = Draw.z();
        Draw.z(Layer.blockOver);
        Draw.rect(Core.atlas.find("光耀旧世界-作战实验室-核"), this.x, this.y, Time.time*2.5);
        Draw.z(z);
	},

	getPowerProduction(tile){
        return 16.667;
    }
});
exports.作战实验室 = 作战实验室;

const 特殊方块限制B = createBuildLimit(1);

const 作战研究中心 = extendContent(CoreBlock, "作战研究中心", {
	canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
        if (!特殊方块限制B.canBuild(team)) {
            return false;
        }
        return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},
    drawPlace(x,y,rotation,valid) {
        if (!Vars.world.tile(x, y)) { return; }
        if (!特殊方块限制B.canBuild(Vars.player.team())) {
            this.drawPlaceText(
                Core.bundle.format("message.光耀旧世界.特殊方块限制",1),
                x, y, valid
            );
        }
    },
	setBars(){
        this.super$setBars();

		this.stats.add(Stat.basePowerGeneration, "[#ff0000]永久[#ffffff] 2500 能量/秒");
		this.bars.add("power",
            func(e =>
		        new Bar(
	                prov(() => Core.bundle.format("bar.poweroutput", Strings.fixed(e.getPowerProduction() * 60, 1))),
			        prov(() => MyColor.cpy().shiftHue(Time.time / 2).shiftValue(Mathf.absin(Time.time, 4, 0.15))), 
					floatp(() => 1.0)
	            )
	        )
        )
    },
	load() {
        this.super$load()
		
		this.spaceRegion = Core.atlas.find(this.name + "-space");
	},
	isHidden() { return !dsGlobal.科技中心(); }
});
作战研究中心.buildVisibility = BuildVisibility.shown;
作战研究中心.localizedName = "作战研究中心";
作战研究中心.description = "放置以解锁进阶科技";
作战研究中心.details = "可以当核心用，容量还行，消耗单位数量上限8位以作为研究资源";
作战研究中心.health = 2500;
作战研究中心.size = 8;
作战研究中心.unitCapModifier = -8;
作战研究中心.placeableLiquid = true;
作战研究中心.floating = true;
作战研究中心.targetable = false;
作战研究中心.hasItems = true;
作战研究中心.itemCapacity = 2500;
作战研究中心.hasPower = true;
作战研究中心.hasLiquids = false;
作战研究中心.useColor = true;
作战研究中心.mapColor = Color.valueOf("00FFFF");
作战研究中心.outlineColor = Color.valueOf("00FFFF");
作战研究中心.absorbLasers = true;
作战研究中心.category = null;
作战研究中心.buildCostMultipler = 0.000001;
作战研究中心.requirements = ItemStack.with(
	F.fi("Fe"), 3000, 
	F.fi("Mg-Al"), 2000, 
	F.fi("Fe-C"), 2000, 
	F.fi("C60"), 500, 
	F.fi("Ti+"), 500
);
F.techNode(作战实验室, 作战研究中心, ItemStack.with(
	F.fi("Fe"), 3000 * 10, 
	F.fi("Mg-Al"), 2000 * 10, 
	F.fi("Fe-C"), 2000 * 10, 
	F.fi("C60"), 500 * 10, 
	F.fi("Ti+"), 500 * 10
));
lib.setBuildingSimple(作战研究中心, CoreBlock.CoreBuild, {
	add() {
    this.super$add();
    if (this.team != Team.derelict) {
    特殊方块限制B.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    特殊方块限制B.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 特殊方块限制B.removeBuild(this.team); }
    this.super$remove();
    },
	draw() {
    this.super$draw();

	Draw.color(FFXXAA.cpy().shiftHue(Time.time / 2).shiftValue(Mathf.absin(Time.time, 4, 0.15)));
	Draw.alpha(2.5);
	Draw.rect(作战研究中心.spaceRegion, this.x, this.y);
	Draw.reset();
	
	var z = Draw.z();
        Draw.z(Layer.blockOver);
        Draw.rect(Core.atlas.find("光耀旧世界-作战研究中心-核"), this.x, this.y, Time.time*2);
		Draw.rect(Core.atlas.find("光耀旧世界-作战研究中心-反核"), this.x, this.y, -Time.time*4);
        Draw.z(z);
	},

	getPowerProduction(tile){
        return 2500.0/60.0;
    }
});
exports.作战研究中心 = 作战研究中心;

const 工厂扩展核心限制 = createBuildLimit(1);

const 工厂扩展核心 = extendContent(CoreBlock, "工厂扩展核心", {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
        if (!工厂扩展核心限制.canBuild(team)) {
            return false;
        }
        return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},
    drawPlace(x,y,rotation,valid) {
        if (!Vars.world.tile(x, y)) { return; }
        if (!工厂扩展核心限制.canBuild(Vars.player.team())) {
            this.drawPlaceText(
                Core.bundle.format("message.光耀旧世界.特殊方块限制",1),
                x, y, valid
            );
        }
    }
});
工厂扩展核心.buildVisibility = BuildVisibility.shown;
工厂扩展核心.localizedName = "工厂扩展核心";
工厂扩展核心.description = "放置以解锁核威慑相关资源的更多进阶工厂";
工厂扩展核心.details = "可以当核心用，但是容量少的可怜，消耗单位数量上限5位以作为研究资源";
工厂扩展核心.health = 500;
工厂扩展核心.size = 3;
工厂扩展核心.unitCapModifier = -5;
工厂扩展核心.placeableLiquid = true;
工厂扩展核心.floating = true;
工厂扩展核心.targetable = false;
工厂扩展核心.hasItems = true;
工厂扩展核心.itemCapacity = 500;
工厂扩展核心.hasPower = true;
工厂扩展核心.hasLiquids = false;
工厂扩展核心.useColor = true;
工厂扩展核心.mapColor = Color.valueOf("00FFFF");
工厂扩展核心.outlineColor = Color.valueOf("00FFFF");
工厂扩展核心.absorbLasers = true;
工厂扩展核心.category = null;
工厂扩展核心.buildCostMultipler = 0.000001;
工厂扩展核心.requirements = ItemStack.with(
	F.fi("普通科技点"), 40000,
	F.fi("Al"), 30000,
	F.fi("Fe"), 20000,
	F.fi("Mg"), 10000
);
F.techNode(作战研究中心, 工厂扩展核心, ItemStack.with(
	F.fi("普通科技点"), 40000 * 10,
	F.fi("Al"), 30000 * 10,
	F.fi("Fe"), 20000 * 10,
	F.fi("Mg"), 10000 * 10
));
lib.setBuildingSimple(工厂扩展核心, CoreBlock.CoreBuild, {
	add() {
    this.super$add();
    if (this.team != Team.derelict) {
    工厂扩展核心限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    工厂扩展核心限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 工厂扩展核心限制.removeBuild(this.team); }
    this.super$remove();
    },
	draw() {
    this.super$draw();

	Draw.color(F.c("#9955ff"));
	Draw.alpha(0.5 + Mathf.sin(Time.time*0.2)*0.1);
	Draw.blend(Blending.additive);
	Draw.rect(Core.atlas.find("光耀旧世界-工厂扩展核心-发光"), this.x, this.y);
	Draw.blend();
    Draw.reset();
	}
});
exports.工厂扩展核心 = 工厂扩展核心;

const 矿坑扩展核心限制 = createBuildLimit(1);

const 矿坑扩展核心 = extendContent(CoreBlock, "矿坑扩展核心", {
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战研究中心(); },
	canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
        if (!矿坑扩展核心限制.canBuild(team)) {
            return false;
        }
        return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},
    drawPlace(x,y,rotation,valid) {
        if (!Vars.world.tile(x, y)) { return; }
        if (!矿坑扩展核心限制.canBuild(Vars.player.team())) {
            this.drawPlaceText(
                Core.bundle.format("message.光耀旧世界.特殊方块限制",1),
                x, y, valid
            );
        }
    }
});
矿坑扩展核心.buildVisibility = BuildVisibility.shown;
矿坑扩展核心.localizedName = "矿坑扩展核心";
矿坑扩展核心.description = "放置以解锁更多矿坑";
矿坑扩展核心.details = "可以当核心用，但是容量少的可怜，消耗单位数量上限4位以作为研究资源";
矿坑扩展核心.health = 500;
矿坑扩展核心.size = 3;
矿坑扩展核心.unitCapModifier = -4;
矿坑扩展核心.placeableLiquid = true;
矿坑扩展核心.floating = true;
矿坑扩展核心.targetable = false;
矿坑扩展核心.hasItems = true;
矿坑扩展核心.itemCapacity = 500;
矿坑扩展核心.hasPower = true;
矿坑扩展核心.hasLiquids = false;
矿坑扩展核心.useColor = true;
矿坑扩展核心.mapColor = Color.valueOf("00FFFF");
矿坑扩展核心.outlineColor = Color.valueOf("00FFFF");
矿坑扩展核心.absorbLasers = true;
矿坑扩展核心.category = null;
矿坑扩展核心.buildCostMultipler = 0.000001;
矿坑扩展核心.requirements = ItemStack.with(
	F.fi("普通科技点"), 40000,
	F.fi("Al"), 30000,
	F.fi("Fe"), 20000,
	F.fi("Mg"), 10000
);
F.techNode(作战研究中心, 矿坑扩展核心, ItemStack.with(
	F.fi("普通科技点"), 40000 * 10,
	F.fi("Al"), 30000 * 10,
	F.fi("Fe"), 20000 * 10,
	F.fi("Mg"), 10000 * 10
));
lib.setBuildingSimple(矿坑扩展核心, CoreBlock.CoreBuild, {
	add() {
    this.super$add();
    if (this.team != Team.derelict) {
    矿坑扩展核心限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    矿坑扩展核心限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 矿坑扩展核心限制.removeBuild(this.team); }
    this.super$remove();
    },
	draw() {
    this.super$draw();

	Draw.color(F.c("#0066ff"));
	Draw.alpha(0.5 + Mathf.sin(Time.time*0.2)*0.1);
	Draw.blend(Blending.additive);
	Draw.rect(Core.atlas.find("光耀旧世界-矿坑扩展核心-发光"), this.x, this.y);
	Draw.blend();
    Draw.reset();
	}
});
exports.矿坑扩展核心 = 矿坑扩展核心;