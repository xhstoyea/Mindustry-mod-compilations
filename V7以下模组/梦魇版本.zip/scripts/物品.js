//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const lib = require("前置/lib");

exports.科技颜色 = Color.valueOf("ffffff");
exports.虫族科技点 = (() => {
var myitem = extendContent(Item, '虫族科技点', {});
myitem.color = exports.科技颜色;
myitem.cost = 1;
myitem.hardness = 1;
return myitem;
})();

exports.虫族进阶科技点 = (() => {
var myitem = extendContent(Item, '虫族进阶科技点', {});
myitem.color = exports.科技颜色;
myitem.cost = 1;
myitem.hardness = 1;
return myitem;
})();

exports.人族科技点 = (() => {
var myitem = extendContent(Item, '人族科技点', {});
myitem.color = exports.科技颜色;
myitem.cost = 1;
myitem.hardness = 1;
return myitem;
})();

exports.人族进阶科技点 = (() => {
var myitem = extendContent(Item, '人族进阶科技点', {});
myitem.color = exports.科技颜色;
myitem.cost = 1;
myitem.hardness = 1;
return myitem;
})();

exports.掠夺者科技点 = (() => {
var myitem = extendContent(Item, '掠夺者科技点', {});
myitem.color = exports.科技颜色;
myitem.cost = 1;
myitem.hardness = 1;
return myitem;
})();

exports.掠夺者进阶科技点 = (() => {
var myitem = extendContent(Item, '掠夺者进阶科技点', {});
myitem.color = exports.科技颜色;
myitem.cost = 1;
myitem.hardness = 1;
return myitem;
})();

exports.光耀科技点 = (() => {
var myitem = extendContent(Item, '光耀科技点', {});
myitem.color = exports.科技颜色;
myitem.cost = 1;
myitem.hardness = 1;
return myitem;
})();

exports.光耀进阶科技点 = (() => {
var myitem = extendContent(Item, '光耀进阶科技点', {});
myitem.color = exports.科技颜色;
myitem.cost = 1;
myitem.hardness = 1;
return myitem;
})();

exports.暗星科技点 = (() => {
var myitem = extendContent(Item, '暗星科技点', {});
myitem.color = exports.科技颜色;
myitem.cost = 1;
myitem.hardness = 1;
return myitem;
})();

exports.暗星进阶科技点 = (() => {
var myitem = extendContent(Item, '暗星进阶科技点', {});
myitem.color = exports.科技颜色;
myitem.cost = 1;
myitem.hardness = 1;
return myitem;
})();

exports.普通科技点 = (() => {
var myitem = extendContent(Item, '普通科技点', {});
myitem.color = exports.科技颜色;
myitem.cost = 1;
myitem.hardness = 1;
return myitem;
})();

const F = require("func");
F.techNode(Blocks.coreNucleus, F.fi("普通科技点"), ItemStack.with(
		Items.surgeAlloy, 648
));
F.techNode(F.fi("普通科技点"), F.fi("人族科技点"), ItemStack.with(
		F.fi("普通科技点"), 5000
));
F.techNode(F.fi("人族科技点"), F.fi("人族进阶科技点"), ItemStack.with(
		F.fi("普通科技点"), 10000,
		F.fi("人族科技点"), 5000
));
F.techNode(F.fi("普通科技点"), F.fi("掠夺者科技点"), ItemStack.with(
		F.fi("普通科技点"), 5000
));
F.techNode(F.fi("掠夺者科技点"), F.fi("掠夺者进阶科技点"), ItemStack.with(
		F.fi("普通科技点"), 10000,
		F.fi("掠夺者科技点"), 5000
));
F.techNode(F.fi("普通科技点"), F.fi("虫族科技点"), ItemStack.with(
		F.fi("普通科技点"), 5000
));
F.techNode(F.fi("虫族科技点"), F.fi("虫族进阶科技点"), ItemStack.with(
		F.fi("普通科技点"), 10000,
		F.fi("虫族科技点"), 5000
));
F.techNode(F.fi("普通科技点"), F.fi("暗星科技点"), ItemStack.with(
		F.fi("普通科技点"), 5000
));
F.techNode(F.fi("暗星科技点"), F.fi("暗星进阶科技点"), ItemStack.with(
		F.fi("普通科技点"), 10000,
		F.fi("暗星科技点"), 5000
));
F.techNode(F.fi("普通科技点"), F.fi("光耀科技点"), ItemStack.with(
		F.fi("普通科技点"), 5000
));
F.techNode(F.fi("光耀科技点"), F.fi("光耀进阶科技点"), ItemStack.with(
		F.fi("普通科技点"), 10000,
		F.fi("光耀科技点"), 5000
));

exports.Al = (() => {
var myitem = extendContent(Item, 'Al', {});
return myitem;
})();

exports.Fe = (() => {
var myitem = extendContent(Item, 'Fe', {});
return myitem;
})();

exports.Mg = (() => {
var myitem = extendContent(Item, 'Mg', {});
return myitem;
})();

exports.W = (() => {
var myitem = extendContent(Item, 'W', {});
return myitem;
})();

exports.U = (() => {
var myitem = extendContent(Item, 'U', {});
return myitem;
})();

exports.kAl = (() => {
var myitem = extendContent(Item, 'kAl', {});
return myitem;
})();

exports.kFe = (() => {
var myitem = extendContent(Item, 'kFe', {});
return myitem;
})();

exports.kMg = (() => {
var myitem = extendContent(Item, 'kMg', {});
return myitem;
})();

exports.kW = (() => {
var myitem = extendContent(Item, 'kW', {});
return myitem;
})();

exports.kU = (() => {
var myitem = extendContent(Item, 'kU', {});
return myitem;
})();

exports.MgAl = (() => {
var myitem = extendContent(Item, 'Mg-Al', {});
return myitem;
})();

exports.xvxnqwz = (() => {
var myitem = extendContent(Item, 'xvx-nqwz', {});
return myitem;
})();

exports.Ti = (() => {
var myitem = extendContent(Item, 'Ti+', {});
return myitem;
})();

exports.C60 = (() => {
var myitem = extendContent(Item, 'C60', {});
return myitem;
})();

exports.C90 = (() => {
var myitem = extendContent(Item, 'C90', {});
return myitem;
})();

exports.xvxai = (() => {
var myitem = extendContent(Item, 'xvx-ai', {});
return myitem;
})();

exports.FeC = (() => {
var myitem = extendContent(Item, 'Fe-C', {});
return myitem;
})();

exports.ghbl = (() => {
var myitem = extendContent(Item, 'ghbl', {});
return myitem;
})();

exports.Inversemass = (() => {
var myitem = extendContent(Item, 'Inverse-mass', {});
return myitem;
})();

exports.ice = (() => {
var myitem = extendContent(Item, 'ice', {});
return myitem;
})();

exports.C902 = (() => {
var myitem = extendContent(Item, 'C902', {});
return myitem;
})();

exports.Pu = (() => {
var myitem = extendContent(Item, 'Pu', {});
return myitem;
})();

exports.Pu239 = (() => {
var myitem = extendContent(Item, 'Pu-239', {});
return myitem;
})();

exports.U235 = (() => {
var myitem = extendContent(Item, 'U-235', {});
return myitem;
})();

exports.missile = (() => {
var myitem = extendContent(Item, 'missile', {});
return myitem;
})();
exports.missile2 = (() => {
var myitem = extendContent(Item, 'missile2', {});
return myitem;
})();

exports.禁止 = (() => {
var myitem = extendContent(Item, '禁止', {});
return myitem;
})();

const C = require("colors");
function newItem(name, color, hardness, cost, flammability, radioactivity, explosiveness){
    const item = extendContent(Item, name, {});
	item.color = Color.valueOf(color);
	item.hardness = hardness;
	item.cost = cost;
	item.flammability = flammability;
	item.radioactivity = radioactivity;
	item.explosiveness = explosiveness;
	return item;
}

const DNA = newItem("DNA", C.DNA, 1, 1, 0, 0.0, 0.0);
const 血肉 = newItem("血肉", C.血肉, 2.0, 2, 0.28, 0.0, 0.0);
const 灵光 = newItem("灵光", C.灵光, 1.0, 1, 0.0, 0.0, 0.0);
const 进阶虫卵 = newItem("进阶虫卵", C.虫卵, 4, 4, 2.1, 0.0, 0.0);
const 虫卵 = newItem("虫卵", C.虫卵, 2, 2, 1.7, 0.0, 0.0);
const 基因突变物 = newItem("基因突变物", C.基因突变物, 3, 3, 1.5, 0.0, 0.0);
const 骨物质 = newItem("骨物质", C.骨物质, 3.0, 3, 0.1, 0.0, 0.0);
const 蛋白质 = newItem("蛋白质", C.蛋白质, 1, 1, 1.8, 0.0, 0.0);

exports.DNA = DNA;
exports.血肉 = 血肉;
exports.灵光 = 灵光;
exports.进阶虫卵 = 进阶虫卵;
exports.虫卵 = 虫卵;
exports.基因突变物 = 基因突变物;
exports.骨物质 = 骨物质;
exports.蛋白质 = 蛋白质;

F.techNode(F.fi("虫族科技点"), F.fi("DNA"), ItemStack.with(
		F.fi("虫族科技点"), 2000
));
F.techNode(F.fi("虫族科技点"), F.fi("血肉"), ItemStack.with(
		F.fi("虫族科技点"), 1000
));
F.techNode(F.fi("虫族科技点"), F.fi("灵光"), ItemStack.with(
		F.fi("虫族科技点"), 1000
));
F.techNode(F.fi("虫族科技点"), F.fi("虫卵"), ItemStack.with(
		F.fi("虫族科技点"), 2000
));
F.techNode(F.fi("虫卵"), F.fi("进阶虫卵"), ItemStack.with(
		F.fi("虫族科技点"), 3000
));
F.techNode(F.fi("DNA"), F.fi("基因突变物"), ItemStack.with(
		F.fi("虫族科技点"), 3000
));
F.techNode(F.fi("虫族科技点"), F.fi("骨物质"), ItemStack.with(
		F.fi("虫族科技点"), 1000
));
F.techNode(F.fi("虫族科技点"), F.fi("蛋白质"), ItemStack.with(
		F.fi("虫族科技点"), 2000
));

function no(name, item, variants) {
    const ore = extendContent(OreBlock, name, {});
    ore.itemDrop = item;
	ore.variants = variants;
}

no("ore-骨物质", 骨物质, 3);
no("ore-灵光", 灵光, 1);

const 血肉地板 = extendContent(Floor, "血肉地板", {});
血肉地板.itemDrop = 血肉;
血肉地板.playerUnmineable = true;
血肉地板.variants = 6;

//核威慑液体
exports.Wa = (() => {
var myliquid = extendContent(Liquid, 'Wa', {});
return myliquid;
})();

exports.H2y = (() => {
var myliquid = extendContent(Liquid, 'H2y', {});
return myliquid;
})();

exports.O2y = (() => {
var myliquid = extendContent(Liquid, 'O2y', {});
return myliquid;
})();

exports.yj = (() => {
var myliquid = extendContent(Liquid, 'yj', {});
return myliquid;
})();

//通用物品
exports.白银 = (() => {
var myitem = extendContent(Item, '白银', {});
myitem.color = Color.valueOf("bbffee");
myitem.cost = 1;
myitem.hardness = 4;
return myitem;
})();

exports.锡 = (() => {
var myitem = extendContent(Item, '锡', {});
myitem.color = Color.valueOf("ffddaa");
myitem.cost = 1;
myitem.hardness = 4;
return myitem;
})();

exports.黄金 = (() => {
var myitem = extendContent(Item, '黄金', {});
myitem.color = Color.valueOf("ffff77");
myitem.cost = 1;
myitem.hardness = 5;
return myitem;
})();

exports.k白银 = (() => {
var myitem = extendContent(Item, 'k白银', {});
return myitem;
})();

exports.k锡 = (() => {
var myitem = extendContent(Item, 'k锡', {});
return myitem;
})();

exports.k黄金 = (() => {
var myitem = extendContent(Item, 'k黄金', {});
return myitem;
})();

F.techNode(F.fi("人族科技点"), F.fi("白银"), ItemStack.with(
		F.fi("普通科技点"), 15000
));
F.techNode(F.fi("白银"), F.fi("锡"), ItemStack.with(
		F.fi("普通科技点"), 25000
));
F.techNode(F.fi("锡"), F.fi("黄金"), ItemStack.with(
		F.fi("普通科技点"), 50000
));

//no("ore-白银", exports.白银, 3);
//no("ore-黄金", exports.黄金, 3);
//no("ore-锡", exports.锡, 3);

//人族物品
exports.白金 = (() => {
var myitem = extendContent(Item, '白金', {});
myitem.color = Color.valueOf("aaffee");
myitem.cost = 1;
myitem.hardness = 5;
return myitem;
})();

exports.能量结晶 = (() => {
var myitem = extendContent(Item, '能量结晶', {});
myitem.color = Color.valueOf("ffff00");
myitem.cost = 1;
myitem.hardness = 5;
return myitem;
})();

exports.能量合金 = (() => {
var myitem = extendContent(Item, '能量合金', {});
myitem.color = Color.valueOf("eeee00");
myitem.cost = 1;
myitem.hardness = 5;
return myitem;
})();

exports.强化锡金 = (() => {
var myitem = extendContent(Item, '强化锡金', {});
myitem.color = Color.valueOf("ffffbb");
myitem.cost = 1;
myitem.hardness = 5;
return myitem;
})();

F.techNode(F.fi("人族科技点"), F.fi("白金"), ItemStack.with(
		F.fi("普通科技点"), 5000,
		F.fi("人族科技点"), 2500
));
F.techNode(F.fi("白金"), F.fi("强化锡金"), ItemStack.with(
		F.fi("普通科技点"), 8000,
		F.fi("人族科技点"), 5000
));
F.techNode(F.fi("强化锡金"), F.fi("能量结晶"), ItemStack.with(
		F.fi("普通科技点"), 25000,
		F.fi("人族科技点"), 10000
));
F.techNode(F.fi("白金"), F.fi("能量合金"), ItemStack.with(
		F.fi("普通科技点"), 8000,
		F.fi("人族科技点"), 5000
));

exports.机械提速液 = (() => {
var myLiquid = new Liquid("机械提速液", Color.valueOf("FFFF00"))
myLiquid.localizedName = "机械提速液";
myLiquid.alwaysUnlocked = true;
myLiquid.flammability = 0;
myLiquid.temperature = 0;
myLiquid.explosiveness = 0;
myLiquid.temperature = 0;
myLiquid.viscosity = 0;
myLiquid.heatCapacity = 388;
myLiquid.effect = StatusEffects.freezing;
myLiquid.lightColor = Color.valueOf("FFFF00");
myLiquid.barColor = Color.valueOf("FFFF00");
return myLiquid;
})();

//掠夺者物品
exports.黑金石 = (() => {
var myitem = extendContent(Item, '黑金石', {});
myitem.color = Color.valueOf("ffb7dd");
myitem.cost = 1;
myitem.hardness = 5;
return myitem;
})();

exports.能源水晶 = (() => {
var myitem = extendContent(Item, '能源水晶', {});
myitem.color = Color.valueOf("ff8888");
myitem.cost = 1;
myitem.hardness = 5;
return myitem;
})();

exports.废矿 = (() => {
var myitem = extendContent(Item, '废矿', {});
myitem.color = Color.valueOf("ff8800");
myitem.cost = 1;
myitem.hardness = 3;
return myitem;
})();

exports.电磁银 = (() => {
var myitem = extendContent(Item, '电磁银', {});
myitem.color = Color.valueOf("dddddd");
myitem.cost = 1;
myitem.hardness = 5;
return myitem;
})();

F.techNode(F.fi("掠夺者科技点"), F.fi("黑金石"), ItemStack.with(
		F.fi("普通科技点"), 5000,
		F.fi("掠夺者科技点"), 2500
));
F.techNode(F.fi("黑金石"), F.fi("电磁银"), ItemStack.with(
		F.fi("普通科技点"), 8000,
		F.fi("掠夺者科技点"), 5000
));
F.techNode(F.fi("电磁银"), F.fi("能源水晶"), ItemStack.with(
		F.fi("普通科技点"), 25000,
		F.fi("掠夺者科技点"), 10000
));
F.techNode(F.fi("黑金石"), F.fi("废矿"), ItemStack.with(
		F.fi("普通科技点"), 5000,
		F.fi("掠夺者科技点"), 2500
));

exports.矿物废水 = (() => {
var myLiquid = new Liquid("矿物废水", Color.valueOf("ff8800"))
myLiquid.localizedName = "矿物废水";
myLiquid.alwaysUnlocked = true;
myLiquid.temperature = 2;
myLiquid.viscosity = 0.85;
myLiquid.effect = StatusEffects.melting;
myLiquid.lightColor = Color.valueOf("ff8800");
return myLiquid;
})();