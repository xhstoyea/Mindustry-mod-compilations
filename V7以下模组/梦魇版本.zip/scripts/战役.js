//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

/*
const qszd = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(qszd, 2));
        this.super$load();
    }
}, "起始之地", Planets.sun, 1, 1);
qszd.localizedName = "[#bbffee]起始之地";
qszd.generator = new SerpuloPlanetGenerator();
qszd.atmosphereColor = Color.valueOf("3db899");
//qszd.lightColor = Color.block.cpy();
qszd.startSector = 1;
qszd.atmosphereRadIn = 0.02;
qszd.atmosphereRadOut = 0.1;
qszd.visible = true;
qszd.bloom = false;
qszd.accessible = true;
qszd.rotateTime = 24 * 60;
qszd.orbitRadius = 35;

var yj = Planet("yj", qszd, 0, 0.1);
yj.bloom = true;
yj.accessible = false;
yj.localizedName = "月镜-卫星";
yj.orbitRadius = 2.5;
*/

const planet = require('星球/planets');

const qd = SectorPreset("qd", planet.detritus, 250);
qd.difficulty = 1;
qd.localizedName = "[#ccddff]起点";

const F = require("func");
const lib = require('前置/lib');

lib.addToResearch(qd, {
    parent: 'core-foundation',
    objectives: Seq.with(
		new Objectives.Produce(Items.sporePod),
		new Objectives.Produce(Liquids.slag),
		new Objectives.Research(F.fb("dgc2")),
		new Objectives.Research(F.fb("schxckj")),
		new Objectives.SectorComplete(SectorPresets.craters),
        new Objectives.SectorComplete(SectorPresets.frozenForest)
    )
});