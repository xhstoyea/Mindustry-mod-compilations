//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const lib = require('前置/lib');
const C = require("colors");
const YXYX = Color.valueOf("ffff77");

const 光圈 = lib.newEffect(20, (e) => {
            Draw.color(YXYX, YXYX, e.fin());
            Lines.stroke(1 + e.fout());
            Lines.circle(e.x, e.y, e.fin() * 20);
        });

exports.光圈 = 光圈;

const 颜色特效 = Color.valueOf("9f88ff");

const 特效A = new Effect (100, e => {
    Draw.color(颜色特效);
    Lines.stroke(e.fout() * 3);
    Lines.circle(e.x, e.y, 10 + e.fin() * 10);

    Angles.randLenVectors(e.id, 30, 5 + 25 * e.fin(), (x, y) => {
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 5 + 2);
    });
});

exports.特效A = 特效A;

const greenTinyHit = new Effect(10, e => {
    Draw.color(Pal.heal);
    Lines.stroke(1.2 * e.fout());
    Lines.circle(e.x, e.y, 0.8 + e.finpow() * 3.6);
});

exports.greenTinyHit = greenTinyHit;

const redArtilleryHit = new Effect(14, e => {
    Draw.color(C.unitOrangeLight, C.unitOrangeDark, e.fin());
    Lines.stroke(0.5 + e.fout() * 2.2);
    Lines.circle(e.x, e.y, e.fin() * 80.0);

    Angles.randLenVectors(e.id, 8, 5.6 + e.fin() * 25.0, new Floatc2({get(x, y){
        var ang = Mathf.angle(x, y);
        Lines.lineAngle(e.x + x, e.y + y, ang, e.fout() * 14.5 + 3.0);
	}}))
}); 

exports.redArtilleryHit = redArtilleryHit;

const laserAdditionalEffect = new Effect(15, e => {
    Draw.color(C.unitOrangeLight, C.unitOrangeDark, e.fin());
    Fill.square(e.x , e.y, 0.8 + e.fout() * 2.0, Mathf.randomSeedRange(e.id, 360));
});

const leviathanLaserCharge = new Effect(50, 100, e => {
    Draw.color(C.unitOrangeLight, C.unitOrangeDark);
	Angles.randLenVectors(e.id * 11, 30, e.fin() * 200, e.rotation, 360.0, new Floatc2({get(x, y){
		Fill.circle(e.x + x, e.y + y, e.fout() * 8.0 + 1.5);
    }}));

    Lines.stroke(e.fout() * 14.0);
    Lines.circle(e.x, e.y, 16.0 + e.fin() * 200.0);
});

const Distance = 30 + 30 + 30*Vars.tilesize;
const yellowBallCharge = new Effect(120, Distance, e => {
    Draw.color(C.energy);
    Lines.stroke(e.fin() * 5.0);
    Lines.circle(e.x, e.y, 20.0 + e.fout() * 140.0);

    Angles.randLenVectors(e.id, 30, 80.0 * e.fout(), new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fin() * 10.0);
    }}));

    Draw.color(C.energyLight);
    Fill.circle(e.x, e.y, e.fin() * 30.0);

    Draw.color();
    Fill.circle(e.x, e.y, e.fin() * 15);
});

const energyShootsAngle = [-50, -25, 25, 50];
const energyShootsWidth = [7.6, 9.8, 9.8, 7.6];
const energyShootsHeight = [15.4, 22.8, 22.8, 15.4];
const energyShrapnelShoot = new Effect(8, e => {
    for(var i = 0; i < 4; i++) {
	    Draw.color(C.unitOrangeLight, C.unitOrangeDark, e.fout());
	    Drawf.tri(e.x, e.y, 
            energyShootsWidth[i], 
            energyShootsHeight[i],
            e.rotation+(energyShootsAngle[i])
        );
    } 
});

const energyShrapnelSmoke = new Effect(20, e => {
    Angles.randLenVectors(e.id, 10, 6 + e.fin() * 200, e.rotation, 10, new Floatc2({get(x, y){
        Draw.color(C.unitOrangeLight, C.unitOrangeDark, e.fout());
        Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 1.1, 45);
	}}))
});

exports.laserAdditionalEffect = laserAdditionalEffect;
exports.leviathanLaserCharge = leviathanLaserCharge;
exports.yellowBallCharge = yellowBallCharge;
exports.energyShrapnelShoot = energyShrapnelShoot;
exports.energyShrapnelSmoke = energyShrapnelSmoke;

const burningIntensiveEffect = new Effect(55, e => {
    Draw.color(Pal.lightFlame, Pal.darkFlame, Color.gray, e.fin());
    Angles.randLenVectors(e.id, 3, 2.0 + e.fin() * 6.0, 90.0, 15.0, new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, 0.4 + e.fout() * 1.6);
	}}))
});
const burningIntensiverEffect = new Effect(55, e => {
    Draw.color(Pal.lightFlame, Pal.darkFlame, Color.gray, e.fin());
    Angles.randLenVectors(e.id, 3, 3.0 + e.fin() * 8.0, 90.0, 25.0, new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, 0.6 + e.fout() * 2.0);
	}}))
});

exports.burningIntensiverEffect = burningIntensiverEffect;
exports.burningIntensiveEffect = burningIntensiveEffect;