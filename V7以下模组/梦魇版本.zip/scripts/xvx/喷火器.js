//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const sporefireFx = new Effect(20, e => {
    Draw.color(Color.blue, Color.purple, e.fin());
    Fill.circle(e.x, e.y, e.fslope() * 4);
    Fill.circle(e.x, e.y, e.fout() * 2);
    Draw.color(Color.purple, Color.white, e.fin());
    Lines.stroke(e.fslope() * 2);
    Lines.circle(e.x, e.y, e.fin() * 6);
    Draw.color(Color.white, Color.purple, e.fin());
    Lines.stroke(e.fin() * 2); 
});

const sporefire = extend(StatusEffect, "sporefire", {});
sporefire.speedMultiplier = 0.6;
sporefire.armorMultiplier = 0.75;
sporefire.damage = 1;
sporefire.effect = sporefireFx;
sporefire.color = Color.white;

const firehitFx = new Effect(25, e => {
  Draw.color(Pal.lightPyraFlame, Color.orange, Pal.darkPyraFlame, e.fin());
  Angles.randLenVectors(e.id, 10, e.finpow() * 110, e.rotation, 10, (x, y) => {
    Fill.circle(e.x + x, e.y + y, 0.65 + e.fout() * 2);
  })
});

const sporeShoot = new Effect(35, e => {
  Draw.color(Pal.spore, Color.purple, Color.white , e.fin());
  Angles.randLenVectors(e.id, 10, e.finpow() * 140, e.rotation, 24, (x, y) => {
    Fill.circle(e.x + x, e.y + y, 0.65 + e.fout() * 2);
  })
});

/*
const firelandFx = new Effect(20, e => {
  Draw.color(Pal.lightPyraFlame, Color.orange, Pal.darkPyraFlame, e.fin());
  Angles.randLenVectors(e.id, 3, e.finpow() * 5, e.rotation, 3, (x, y) => {
    Fill.circle(e.x + x, e.y + y, 0.65 + e.fout() * 0.4);
  })
});
*/

const flCoalfrag = extend(LiquidBulletType, {});
const flCoal = extend(BasicBulletType, {});
flCoal.speed = 9;
flCoal.damage = 5;
flCoal.hitSize = 6;
flCoal.width = 1;
flCoal.height = 1;
flCoal.inaccuracy = 15;
flCoal.lifetime = 14;
flCoal.knockback = 0;
flCoal.shootSound = Sounds.flame2;
flCoal.shootEffect = firehitFx;
flCoal.despawnEffect = Fx.none;
flCoal.hitEffect = Fx.none;
flCoal.trailEffect = Fx.none;
flCoal.collides = true;
flCoal.collidesTiles = true;
flCoal.colidesAir = true;
flCoal.ammoMultiplier = 1;
flCoal.pierce = true;
flCoal.incendAmount = 1;
//flCoal.fragBullets = 2;
//flCoal.fragBullet = flCoalfrag;

const flSpore = extend(BasicBulletType, {});
flSpore.speed = 9;
flSpore.damage = 200;
flSpore.hitSize = 6;
flSpore.width = 0;
flSpore.height = 0;
flSpore.inaccuracy = 15;
flSpore.lifetime = 17;
flSpore.knockback = 0;
flSpore.shootSound = Sounds.flame2;
flSpore.shootEffect = sporeShoot;
flSpore.despawnEffect = Fx.none;
flSpore.hitEffect = Fx.none;
flSpore.status = sporefire;
flSpore.statusDuration = 600;
flSpore.trailEffect = Fx.none;
flSpore.collides = true;
flSpore.collidesTiles = true;
flSpore.colidesAir = true;
flSpore.ammoMultiplier = 1;
flSpore.pierce = true;
flSpore.pierceBuilding = true;

/*
flCoalfrag.liquid = Liquids.oil;
flCoalfrag.speed = 4;
flCoalfrag.damage = 5;
flCoalfrag.width = 5;
flCoalfrag.height = 5;
flCoalfrag.lifetime = 1;
flCoalfrag.knockback = 0;
flCoalfrag.despawnEffect = Fx.none;
flCoalfrag.hitEffect = firelandFx;
flCoalfrag.status = statuses.hellfire;
flCoalfrag.fragBullet = Bullets.standardCopper;
*/

const F = require("func");
const dsGlobal = require('前置/ds-global');

const helgravator = extendContent(ItemTurret, "xvx-phq",{
	isHidden() { return !dsGlobal.科技中心() || !dsGlobal.作战实验室(); },
	init(){
		this.super$init();
	},
	icons(){
		return [
		Core.atlas.find("block-2"),
		Core.atlas.find("光耀旧世界-xvx-phq")
		];
	}
});
helgravator.buildCostMultipler = 0.000001;
helgravator.ammo(F.fi("C90"), flCoal, F.fi("xvx-nqwz"), flSpore)