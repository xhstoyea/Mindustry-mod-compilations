//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const die = extend(StatusEffect, 'die', {});
//die.color = Color.valueOf("9370DB");
die.damage = 35;
die.damageMultiplier = 0;
die.speedMultiplier = 0;
die.reloadMultiplier = 0;
die.effectChance = 2;
die.effect = Fx.vtolHover;

exports.die = die;

exports.sx = (() => {
var sx  = new LaserBulletType(100);
sx.hitEffect = Fx.hitLancer;
sx.despawnEffect = Fx.none;
sx.length = 6000;
sx.width = 65;
//sx.lengthFalloff = 10;

sx.sideAngle = 45;
sx.sideWidth = 2;
sx.sideLength = 100;

sx.lightningSpacing = 15;
sx.lightningLength = 5;
sx.lightningDelay = 0.1;
sx.lightningLengthRand = 15;
sx.lightningDamage = 100;
sx.lightningAngleRand = 1314;

sx.colors = [Color.valueOf("F0808044"), Color.valueOf("CD5C5C66"), Color.valueOf("FF000099"), Color.white];
sx.lightColor = Color.valueOf("FFE4E1");
sx.lightningColor = Color.valueOf("FFE4E1");
/*
sx.lightningSpacing = 10;
sx.lightningDelay = 10;
sx.lightningAngleRand = 100;
sx.hitSize = 35;
*/
sx.lifetime = 200;

//sx.drawSize = 35;

sx.collidesGround = true;
sx.collidesAir = true;
sx.keepVelocity = false;
sx.collides = true;
sx.pierce = true;
sx.hittable = false;
sx.absorbable = false;

sx.status = die;
sx.statusDuration = 600;
return sx;
})();