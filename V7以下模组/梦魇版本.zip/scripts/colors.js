//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const DNA = Color.valueOf("ffffff");
const 血肉 = Color.valueOf("ff0000");
const 灵光 = Color.valueOf("e8ccff");
const 虫卵 = Color.valueOf("00ff00");
const 基因突变物 = Color.valueOf("ffff00");
const 骨物质 = Color.valueOf("aaaaaa");
const 蛋白质 = Color.valueOf("dddddd");

const CFlame = Color.valueOf("99ff99");

exports.DNA = DNA;
exports.血肉 = 血肉;
exports.灵光 = 灵光;
exports.虫卵 = 虫卵;
exports.基因突变物 = 基因突变物;
exports.骨物质 = 骨物质;
exports.蛋白质 = 蛋白质;

exports.CFlame = CFlame;

const unitOrangeDark = Color.valueOf("C05D5C");
const unitOrange = Color.valueOf("E58575");
const unitOrangeLight = Color.valueOf("F6AE7B");

const energy = Color.valueOf("FFE93D");
const energyLight = Color.valueOf("#FFEF75");

exports.energy = energy;
exports.energyLight = energyLight;

exports.unitOrangeDark = unitOrangeDark;
exports.unitOrange = unitOrange;
exports.unitOrangeLight = unitOrangeLight;