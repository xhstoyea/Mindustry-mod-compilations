//xvxshenhun@qq.com，使用请标来源，（禁止删除本注释）<我没有把js加密算不错了(狗头)>

const myUnits = require('单位');

function createBuildLimit(limit) {
    const built = {};
    function _init_built_(team) {
        if (!built[team.id]) {
            built[team.id] = 0;
        }
    }
    function canBuild(team) {
        _init_built_(team);
        return built[team.id] < limit;
    }
    function addBuild(team) {
        _init_built_(team);
        return built[team.id]++;
    }
    function removeBuild(team) {
        _init_built_(team);
        return built[team.id]--;
    }
    return {
        canBuild: canBuild,
        addBuild: addBuild,
        removeBuild: removeBuild,
    }
}

const dsGlobal = require('前置/ds-global');

const 核心限制 = createBuildLimit(100);
const myItems = require('物品');

const 核心生产 = extendContent(CoreBlock, "核心", {
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
        if (!核心限制.canBuild(team)) {
            return false;
        }
        return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},
    drawPlace(x,y,rotation,valid) {
        if (!Vars.world.tile(x, y)) { return; }
        if (!核心限制.canBuild(Vars.player.team())) {
            this.drawPlaceText(
                Core.bundle.format("message.光耀旧世界.核心限制",100),
                x, y, valid
            );
        }
    },
	setStats() {
        this.super$setStats();
        this.stats.add(Stat.abilities, "[#ff0000]开启防爆!!!");
    }
});
核心生产.buildType = prov(() => new JavaAdapter(CoreBlock.CoreBuild, {
    updateTile() {
    this.super$updateTile();
    if (this.timer.get(0, 5)) {
    this.handleItem(this, myItems.普通科技点)
    }},
    add() {
    this.super$add();
    if (this.team != Team.derelict) {
    核心限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    核心限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 核心限制.removeBuild(this.team); }
    this.super$remove();
    },
	onDestroyed() {}
}, 核心生产));
核心生产.unitType = myUnits.建造;
核心生产.canOverdrive = false;
核心生产.details = "防爆开启，该核心被破坏以后不会爆炸";
exports.核心生产 = 核心生产;

const 大核心限制 = createBuildLimit(10);

const 大核心生产 = extendContent(CoreBlock, "大核心", {
	isHidden() { return !dsGlobal.科技中心(); },
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size < 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
    if (!大核心限制.canBuild(team)) {
    return false;
    }
    return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},

    drawPlace(x,y,rotation,valid) {
    if (!Vars.world.tile(x, y)) { return; }
    if (!大核心限制.canBuild(Vars.player.team())) {
    this.drawPlaceText(
    Core.bundle.format("message.光耀旧世界.大核心限制",10),
    x, y, valid
    );
    }},
	setStats() {
        this.super$setStats();
        this.stats.add(Stat.abilities, "[#ff0000]开启防爆!!!");
    }
});
大核心生产.buildType = prov(() => new JavaAdapter(CoreBlock.CoreBuild, {
    add() {
    this.super$add();
    if (this.team != Team.derelict) {
    大核心限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    大核心限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 大核心限制.removeBuild(this.team); }
    this.super$remove();
    },
    updateTile() {
        this.super$updateTile();
        if (this.timer.get(1, 1)) {
            this.handleItem(this, myItems.普通科技点)}
        if (this.timer.get(0, 1)) {
            this.handleItem(this, myItems.普通科技点)}
    },
	onDestroyed() {}
}, 大核心生产));
大核心生产.unitType = myUnits.建造;
大核心生产.canOverdrive = false;
大核心生产.details = "防爆开启，该核心被破坏以后不会爆炸";
exports.大核心生产 = 大核心生产;

const 人族核心限制 = createBuildLimit(1);

const 人族基地生产 = extendContent(CoreBlock, "人族基地", {
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size < 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
    if (!人族核心限制.canBuild(team)) {
    return false;
    }
    return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},

    drawPlace(x,y,rotation,valid) {
    if (!Vars.world.tile(x, y)) { return; }
    if (!人族核心限制.canBuild(Vars.player.team())) {
    this.drawPlaceText(
    Core.bundle.format("message.光耀旧世界.人族核心限制",1),
    x, y, valid
    );
    }},
});
人族基地生产.buildType = prov(() => new JavaAdapter(CoreBlock.CoreBuild, {
    add() {
    this.super$add();
    if (this.team != Team.derelict) {
    人族核心限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    人族核心限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 人族核心限制.removeBuild(this.team); }
    this.super$remove();
    },
    updateTile() {
        this.super$updateTile();
        if (this.timer.get(1, 6)) {
            this.handleItem(this, myItems.人族科技点)}
        if (this.timer.get(0, 30)) {
            this.handleItem(this, myItems.人族进阶科技点)}
    },
}, 人族基地生产));
人族基地生产.unitType = myUnits.建造;
人族基地生产.canOverdrive = false;
exports.人族基地生产 = 人族基地生产;

const 掠夺者核心限制 = createBuildLimit(1);

const 掠夺者平台生产 = extendContent(CoreBlock, "掠夺者平台", {
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size < 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
    if (!掠夺者核心限制.canBuild(team)) {
    return false;
    }
    return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},

    drawPlace(x,y,rotation,valid) {
    if (!Vars.world.tile(x, y)) { return; }
    if (!掠夺者核心限制.canBuild(Vars.player.team())) {
    this.drawPlaceText(
    Core.bundle.format("message.光耀旧世界.掠夺者核心限制",1),
    x, y, valid
    );
    }},
});
掠夺者平台生产.buildType = prov(() => new JavaAdapter(CoreBlock.CoreBuild, {
    add() {
    this.super$add();
    if (this.team != Team.derelict) {
    掠夺者核心限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    掠夺者核心限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 掠夺者核心限制.removeBuild(this.team); }
    this.super$remove();
    },
    updateTile() {
        this.super$updateTile();
        if (this.timer.get(1, 6)) {
            this.handleItem(this, myItems.掠夺者科技点)}
        if (this.timer.get(0, 30)) {
            this.handleItem(this, myItems.掠夺者进阶科技点)}
    },
}, 掠夺者平台生产));
掠夺者平台生产.unitType = myUnits.建造;
掠夺者平台生产.canOverdrive = false;
exports.掠夺者平台生产 = 掠夺者平台生产;

const 虫族核心限制 = createBuildLimit(1);

const 虫族母巢生产 = extendContent(CoreBlock, "虫族母巢", {
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size < 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
    if (!虫族核心限制.canBuild(team)) {
    return false;
    }
    return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},

    drawPlace(x,y,rotation,valid) {
    if (!Vars.world.tile(x, y)) { return; }
    if (!虫族核心限制.canBuild(Vars.player.team())) {
    this.drawPlaceText(
    Core.bundle.format("message.光耀旧世界.虫族核心限制",1),
    x, y, valid
    );
    }},
});
虫族母巢生产.buildType = prov(() => new JavaAdapter(CoreBlock.CoreBuild, {
    add() {
    this.super$add();
    if (this.team != Team.derelict) {
    虫族核心限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    虫族核心限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 虫族核心限制.removeBuild(this.team); }
    this.super$remove();
    },
    updateTile() {
        this.super$updateTile();
        if (this.timer.get(1, 6)) {
            this.handleItem(this, myItems.虫族科技点)}
        if (this.timer.get(0, 30)) {
            this.handleItem(this, myItems.虫族进阶科技点)}
    },
}, 虫族母巢生产));
虫族母巢生产.unitType = myUnits.建造;
虫族母巢生产.canOverdrive = false;
exports.虫族母巢生产 = 虫族母巢生产;

const 暗星核心限制 = createBuildLimit(1);

const 暗星空洞生产 = extendContent(CoreBlock, "暗星空洞", {
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size < 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
    if (!暗星核心限制.canBuild(team)) {
    return false;
    }
    return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},

    drawPlace(x,y,rotation,valid) {
    if (!Vars.world.tile(x, y)) { return; }
    if (!暗星核心限制.canBuild(Vars.player.team())) {
    this.drawPlaceText(
    Core.bundle.format("message.光耀旧世界.暗星核心限制",1),
    x, y, valid
    );
    }},
});
暗星空洞生产.buildType = prov(() => new JavaAdapter(CoreBlock.CoreBuild, {
    add() {
    this.super$add();
    if (this.team != Team.derelict) {
    暗星核心限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    暗星核心限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 暗星核心限制.removeBuild(this.team); }
    this.super$remove();
    },
    updateTile() {
        this.super$updateTile();
        if (this.timer.get(1, 6)) {
            this.handleItem(this, myItems.暗星科技点)}
        if (this.timer.get(0, 30)) {
            this.handleItem(this, myItems.暗星进阶科技点)}
    },
}, 暗星空洞生产));
暗星空洞生产.unitType = myUnits.建造;
暗星空洞生产.canOverdrive = false;
exports.暗星空洞生产 = 暗星空洞生产;

const 光耀核心限制 = createBuildLimit(1);

const 光耀核心生产 = extendContent(CoreBlock, "光耀核心", {
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size < 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
    if (!光耀核心限制.canBuild(team)) {
    return false;
    }
    return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},

    drawPlace(x,y,rotation,valid) {
    if (!Vars.world.tile(x, y)) { return; }
    if (!光耀核心限制.canBuild(Vars.player.team())) {
    this.drawPlaceText(
    Core.bundle.format("message.光耀旧世界.光耀核心限制",1),
    x, y, valid
    );
    }},
});
光耀核心生产.buildType = prov(() => new JavaAdapter(CoreBlock.CoreBuild, {
    add() {
    this.super$add();
    if (this.team != Team.derelict) {
    光耀核心限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    光耀核心限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 光耀核心限制.removeBuild(this.team); }
    this.super$remove();
    },
    updateTile() {
        this.super$updateTile();
        if (this.timer.get(1, 6)) {
            this.handleItem(this, myItems.光耀科技点)}
        if (this.timer.get(0, 30)) {
            this.handleItem(this, myItems.光耀进阶科技点)}
    },
}, 光耀核心生产));
光耀核心生产.unitType = myUnits.建造;
光耀核心生产.canOverdrive = false;
exports.光耀核心生产 = 光耀核心生产;

const 人族前哨限制 = createBuildLimit(10);

const 小人族基地生产 = extendContent(CoreBlock, "人族基地前哨", {
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
    if (!人族前哨限制.canBuild(team)) {
    return false;
    }
    return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},

    drawPlace(x,y,rotation,valid) {
    if (!Vars.world.tile(x, y)) { return; }
    if (!人族前哨限制.canBuild(Vars.player.team())) {
    this.drawPlaceText(
    Core.bundle.format("message.光耀旧世界.人族前哨限制",10),
    x, y, valid
    );
    }},
});
小人族基地生产.buildType = prov(() => new JavaAdapter(CoreBlock.CoreBuild, {
    add() {
    this.super$add();
    if (this.team != Team.derelict) {
    人族前哨限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    人族前哨限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 人族前哨限制.removeBuild(this.team); }
    this.super$remove();
    },
    updateTile() {
        this.super$updateTile();
        if (this.timer.get(0, 30)) {
            this.handleItem(this, myItems.人族科技点)}
    },
}, 小人族基地生产));
小人族基地生产.unitType = myUnits.建造;
小人族基地生产.canOverdrive = false;
exports.小人族基地生产 = 小人族基地生产;

const 掠夺者前哨限制 = createBuildLimit(10);

const 小掠夺者平台生产 = extendContent(CoreBlock, "掠夺者平台前哨", {
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
    if (!掠夺者前哨限制.canBuild(team)) {
    return false;
    }
    return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},

    drawPlace(x,y,rotation,valid) {
    if (!Vars.world.tile(x, y)) { return; }
    if (!掠夺者前哨限制.canBuild(Vars.player.team())) {
    this.drawPlaceText(
    Core.bundle.format("message.光耀旧世界.掠夺者前哨限制",10),
    x, y, valid
    );
    }},
});
小掠夺者平台生产.buildType = prov(() => new JavaAdapter(CoreBlock.CoreBuild, {
    add() {
    this.super$add();
    if (this.team != Team.derelict) {
    掠夺者前哨限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    掠夺者前哨限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 掠夺者前哨限制.removeBuild(this.team); }
    this.super$remove();
    },
    updateTile() {
        this.super$updateTile();
        if (this.timer.get(0, 30)) {
            this.handleItem(this, myItems.掠夺者科技点)}
    },
}, 小掠夺者平台生产));
小掠夺者平台生产.unitType = myUnits.建造;
小掠夺者平台生产.canOverdrive = false;
exports.小掠夺者平台生产 = 小掠夺者平台生产;

const 虫族前哨限制 = createBuildLimit(10);

const 小虫族母巢生产 = extendContent(CoreBlock, "虫族母巢前哨", {
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
    if (!虫族前哨限制.canBuild(team)) {
    return false;
    }
    return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},

    drawPlace(x,y,rotation,valid) {
    if (!Vars.world.tile(x, y)) { return; }
    if (!虫族前哨限制.canBuild(Vars.player.team())) {
    this.drawPlaceText(
    Core.bundle.format("message.光耀旧世界.虫族前哨限制",10),
    x, y, valid
    );
    }},
});
小虫族母巢生产.buildType = prov(() => new JavaAdapter(CoreBlock.CoreBuild, {
    add() {
    this.super$add();
    if (this.team != Team.derelict) {
    虫族前哨限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    虫族前哨限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 虫族前哨限制.removeBuild(this.team); }
    this.super$remove();
    },
    updateTile() {
        this.super$updateTile();
        if (this.timer.get(0, 30)) {
            this.handleItem(this, myItems.虫族科技点)}
    },
}, 小虫族母巢生产));
小虫族母巢生产.unitType = myUnits.建造;
小虫族母巢生产.canOverdrive = false;
exports.小虫族母巢生产 = 小虫族母巢生产;

const 暗星前哨限制 = createBuildLimit(10);

const 小暗星空洞生产 = extendContent(CoreBlock, "暗星空洞前哨", {
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
    if (!暗星前哨限制.canBuild(team)) {
    return false;
    }
    return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},

    drawPlace(x,y,rotation,valid) {
    if (!Vars.world.tile(x, y)) { return; }
    if (!暗星前哨限制.canBuild(Vars.player.team())) {
    this.drawPlaceText(
    Core.bundle.format("message.光耀旧世界.暗星前哨限制",10),
    x, y, valid
    );
    }},
});
小暗星空洞生产.buildType = prov(() => new JavaAdapter(CoreBlock.CoreBuild, {
    add() {
    this.super$add();
    if (this.team != Team.derelict) {
    暗星前哨限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    暗星前哨限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 暗星前哨限制.removeBuild(this.team); }
    this.super$remove();
    },
    updateTile() {
        this.super$updateTile();
        if (this.timer.get(0, 30)) {
            this.handleItem(this, myItems.暗星科技点)}
    },
}, 小暗星空洞生产));
小暗星空洞生产.unitType = myUnits.建造;
小暗星空洞生产.canOverdrive = false;
exports.小暗星空洞生产 = 小暗星空洞生产;

const 光耀前哨限制 = createBuildLimit(10);

const 小光耀核心生产 = extendContent(CoreBlock, "光耀核心前哨", {
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) {
    if (!光耀前哨限制.canBuild(team)) {
    return false;
    }
    return true;
    },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},

    drawPlace(x,y,rotation,valid) {
    if (!Vars.world.tile(x, y)) { return; }
    if (!光耀前哨限制.canBuild(Vars.player.team())) {
    this.drawPlaceText(
    Core.bundle.format("message.光耀旧世界.光耀前哨限制",10),
    x, y, valid
    );
    }},
});
小光耀核心生产.buildType = prov(() => new JavaAdapter(CoreBlock.CoreBuild, {
    add() {
    this.super$add();
    if (this.team != Team.derelict) {
    光耀前哨限制.addBuild(this.team);
    }},
    readBase(read) {
    this.super$readBase(read);
    if (this.team != Team.derelict) {
    光耀前哨限制.addBuild(this.team);
    }},
    remove() {
    if (this.added) { 光耀前哨限制.removeBuild(this.team); }
    this.super$remove();
    },
    updateTile() {
        this.super$updateTile();
        if (this.timer.get(0, 30)) {
            this.handleItem(this, myItems.光耀科技点)}
    },
}, 小光耀核心生产));
小光耀核心生产.unitType = myUnits.建造;
小光耀核心生产.canOverdrive = false;
exports.小光耀核心生产 = 小光耀核心生产;

const F = require("func");

虫族母巢生产.localizedName = "虫族母巢";
虫族母巢生产.description = "虫族核心基地，最重要的核心，核心会快速生产虫族科技点，缓慢生产进阶点,该核心只能建造一个";
虫族母巢生产.itemCapacity = 500000;
虫族母巢生产.hasItems = true;
虫族母巢生产.health = 250000;
虫族母巢生产.size = 10;
虫族母巢生产.unitCapModifier = 120;
虫族母巢生产.buildVisibility = BuildVisibility.shown;
虫族母巢生产.category = null;
虫族母巢生产.buildCostMultipler = 0.000001;
虫族母巢生产.requirements = ItemStack.with(
	F.fi("禁止"), 666666
	//F.fi("血肉"), 5000, 
	//F.fi("蛋白质"), 3500, 
	//F.fi("骨物质"), 3500, 
	//F.fi("虫卵"), 1200, 
	//F.fi("灵光"), 5000
);
F.techNode(Blocks.coreShard, 虫族母巢生产, ItemStack.with(
	Items.copper, 10
	//F.fi("血肉"), 125000, 
	//F.fi("蛋白质"), 87500, 
	//F.fi("骨物质"), 87500, 
	//F.fi("虫卵"), 30000, 
	//F.fi("灵光"), 125000
));

小虫族母巢生产.localizedName = "虫族巢穴";
小虫族母巢生产.description = "虫族基地，核心会生产虫族科技点，该核心只能建造十个";
小虫族母巢生产.itemCapacity = 10000;
小虫族母巢生产.hasItems = true;
小虫族母巢生产.health = 50000;
小虫族母巢生产.size = 6;
小虫族母巢生产.unitCapModifier = 50;
小虫族母巢生产.buildVisibility = BuildVisibility.shown;
小虫族母巢生产.category = null;
小虫族母巢生产.buildCostMultipler = 0.000001;
小虫族母巢生产.requirements = ItemStack.with(
	F.fi("禁止"), 666666
	//F.fi("血肉"), 1700, 
	//F.fi("蛋白质"), 1100, 
	//F.fi("骨物质"), 1100, 
	//F.fi("虫卵"), 400, 
	//F.fi("灵光"), 1700
);
F.techNode(虫族母巢生产, 小虫族母巢生产, ItemStack.with(
	F.fi("禁止"), 666666
	//F.fi("血肉"), 42500, 
	//F.fi("蛋白质"), 27500, 
	//F.fi("骨物质"), 27500, 
	//F.fi("虫卵"), 10000, 
	//F.fi("灵光"), 42500
));

人族基地生产.localizedName = "人族基地";
人族基地生产.description = "人族核心基地，最重要的核心，核心会快速生产人族科技点，缓慢生产进阶点,该核心只能建造一个";
人族基地生产.itemCapacity = 500000;
人族基地生产.hasItems = true;
人族基地生产.health = 250000;
人族基地生产.size = 10;
人族基地生产.unitCapModifier = 120;
人族基地生产.buildVisibility = BuildVisibility.shown;
人族基地生产.category = null;
人族基地生产.buildCostMultipler = 0.000001;
人族基地生产.requirements = ItemStack.with(
	F.fi("禁止"), 666666
	//F.fi("Mg-Al"), 2800, 
	//F.fi("Fe-C"), 4000, 
	//F.fi("Fe"), 8000, 
	//F.fi("C60"), 1350, 
	//F.fi("Ti+"), 1000
);
F.techNode(Blocks.coreShard, 人族基地生产, ItemStack.with(
	Items.copper, 10
	//F.fi("Mg-Al"), 70000, 
	//F.fi("Fe-C"), 100000, 
	//F.fi("Fe"), 200000, 
	//F.fi("C60"), 33750, 
	//F.fi("Ti+"), 25000
));

小人族基地生产.localizedName = "人族前哨基地";
小人族基地生产.description = "人族基地，核心会生产人族科技点，该核心只能建造十个";
小人族基地生产.itemCapacity = 10000;
小人族基地生产.hasItems = true;
小人族基地生产.health = 50000;
小人族基地生产.size = 6;
小人族基地生产.unitCapModifier = 50;
小人族基地生产.buildVisibility = BuildVisibility.shown;
小人族基地生产.category = null;
小人族基地生产.buildCostMultipler = 0.000001;
小人族基地生产.requirements = ItemStack.with(
	F.fi("Mg-Al"), 930, 
	F.fi("Fe-C"), 1350, 
	F.fi("Fe"), 2700, 
	F.fi("C60"), 450, 
	F.fi("Ti+"), 330
);
F.techNode(人族基地生产, 小人族基地生产, ItemStack.with(
	F.fi("Mg-Al"), 23250, 
	F.fi("Fe-C"), 33750, 
	F.fi("Fe"), 67500, 
	F.fi("C60"), 111250, 
	F.fi("Ti+"), 8250
));

掠夺者平台生产.localizedName = "掠夺者平台";
掠夺者平台生产.description = "掠夺者核心基地，最重要的核心，核心会快速生产掠夺者科技点，缓慢生产进阶点,该核心只能建造一个";
掠夺者平台生产.itemCapacity = 500000;
掠夺者平台生产.hasItems = true;
掠夺者平台生产.health = 250000;
掠夺者平台生产.size = 10;
掠夺者平台生产.unitCapModifier = 120;
掠夺者平台生产.buildVisibility = BuildVisibility.shown;
掠夺者平台生产.category = null;
掠夺者平台生产.buildCostMultipler = 0.000001;
掠夺者平台生产.requirements = ItemStack.with(
	F.fi("禁止"), 666666
);
F.techNode(Blocks.coreShard, 掠夺者平台生产, ItemStack.with(
	Items.copper, 10
));

//
F.techNode(掠夺者平台生产, F.fb("抗火导管"), ItemStack.with(
	F.fi("Mg-Al"), 35 * 25,
    F.fi("ghbl"), 80 * 25,
    F.fi("普通科技点"), 60
));

小掠夺者平台生产.localizedName = "小型掠夺者平台";
小掠夺者平台生产.description = "掠夺者基地，核心会生产掠夺者科技点，该核心只能建造十个";
小掠夺者平台生产.itemCapacity = 10000;
小掠夺者平台生产.hasItems = true;
小掠夺者平台生产.health = 50000;
小掠夺者平台生产.size = 6;
小掠夺者平台生产.unitCapModifier = 50;
小掠夺者平台生产.buildVisibility = BuildVisibility.shown;
小掠夺者平台生产.category = null;
小掠夺者平台生产.buildCostMultipler = 0.000001;
小掠夺者平台生产.requirements = ItemStack.with(
	F.fi("Mg-Al"), 930, 
	F.fi("Fe-C"), 1350, 
	F.fi("Fe"), 2700, 
	F.fi("C60"), 450, 
	F.fi("Ti+"), 330
);
F.techNode(掠夺者平台生产, 小掠夺者平台生产, ItemStack.with(
	F.fi("Mg-Al"), 23250, 
	F.fi("Fe-C"), 33750, 
	F.fi("Fe"), 67500, 
	F.fi("C60"), 111250, 
	F.fi("Ti+"), 8250
));

光耀核心生产.localizedName = "光耀核心";
光耀核心生产.description = "光耀核心基地，最重要的核心，核心会快速生产光耀科技点，缓慢生产进阶点,该核心只能建造一个";
光耀核心生产.itemCapacity = 500000;
光耀核心生产.hasItems = true;
光耀核心生产.health = 250000;
光耀核心生产.size = 10;
光耀核心生产.unitCapModifier = 120;
光耀核心生产.buildVisibility = BuildVisibility.shown;
光耀核心生产.category = null;
光耀核心生产.buildCostMultipler = 0.000001;
光耀核心生产.requirements = ItemStack.with(
	F.fi("禁止"), 666666
);
F.techNode(Blocks.coreShard, 光耀核心生产, ItemStack.with(
	Items.copper, 10
));

小光耀核心生产.localizedName = "小型光耀核心";
小光耀核心生产.description = "光耀基地，核心会生产光耀科技点，该核心只能建造十个";
小光耀核心生产.itemCapacity = 10000;
小光耀核心生产.hasItems = true;
小光耀核心生产.health = 50000;
小光耀核心生产.size = 6;
小光耀核心生产.unitCapModifier = 50;
小光耀核心生产.buildVisibility = BuildVisibility.shown;
小光耀核心生产.category = null;
小光耀核心生产.buildCostMultipler = 0.000001;
小光耀核心生产.requirements = ItemStack.with(
	F.fi("禁止"), 666666
);
F.techNode(光耀核心生产, 小光耀核心生产, ItemStack.with(
	F.fi("禁止"), 666666
));

暗星空洞生产.localizedName = "暗星空洞";
暗星空洞生产.description = "暗星核心基地，最重要的核心，核心会快速生产暗星科技点，缓慢生产进阶点，该核心只能建造一个";
暗星空洞生产.itemCapacity = 500000;
暗星空洞生产.hasItems = true;
暗星空洞生产.health = 250000;
暗星空洞生产.size = 10;
暗星空洞生产.unitCapModifier = 120;
暗星空洞生产.buildVisibility = BuildVisibility.shown;
暗星空洞生产.category = null;
暗星空洞生产.buildCostMultipler = 0.000001;
暗星空洞生产.requirements = ItemStack.with(
	F.fi("禁止"), 666666
);
F.techNode(Blocks.coreShard, 暗星空洞生产, ItemStack.with(
	Items.copper, 10
));

小暗星空洞生产.localizedName = "小型暗星空洞";
小暗星空洞生产.description = "暗星基地，核心会生产暗星科技点，该核心只能建造十个";
小暗星空洞生产.itemCapacity = 10000;
小暗星空洞生产.hasItems = true;
小暗星空洞生产.health = 50000;
小暗星空洞生产.size = 6;
小暗星空洞生产.unitCapModifier = 50;
小暗星空洞生产.buildVisibility = BuildVisibility.shown;
小暗星空洞生产.category = null;
小暗星空洞生产.buildCostMultipler = 0.000001;
小暗星空洞生产.requirements = ItemStack.with(
	F.fi("禁止"), 666666
);
F.techNode(暗星空洞生产, 小暗星空洞生产, ItemStack.with(
	F.fi("禁止"), 666666
));