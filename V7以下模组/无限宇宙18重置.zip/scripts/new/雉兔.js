var ax = extendContent(UnitType, 'd-雉兔', {});
ax.defaultController = prov(() => new MinerAI());
ax.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));
