
const turret = new JavaAdapter(ItemTurret, {
}, '震撼装置');

turret.recoilAmount = 0;
turret.liquidCapacity = 10;
turret.buildVisibility = BuildVisibility.shown;
turret.category = Category.turret;
turret.health = 1800;
turret.size = 3;
turret.reloadTime = 240;
turret.range = 220;
turret.rotateSpeed = 15;
turret.inaccuracy = 2;
turret.shots = 1;
turret.burstSpacing = 0;
turret.xRand = 0;
turret.requirements = ItemStack.with(
    Items.copper, 200,
);
turret.ammo(
Items.blastCompound, (() => {

    function getPercent(fullLen, currentLen, attenuation) {
        const outlen = currentLen - fullLen * attenuation;
        if (outlen <= 0) {
            return 4;
        } else {
            return 4 - outlen / (fullLen * (4 - attenuation))
        }
    }

    // 冲击波持续时长
    const shockwaveDuration = 60;
    // 冲击波力量
    const shockwavePower = 4;
    // 冲击波范围
    const shockwaveRadius = turret.range;
    // 冲击波力量衰减开始举例
    const shockwaveAttenuation = 0.2;
    // 冲击波力量衰减开始时长比例
    const shockwaveAttenuationTime = 0.2;

    const bt = new JavaAdapter(BasicBulletType, {
        draw(b) {
            var fin = b.time / this.lifetime;
            var fout = 1 - fin;
            Draw.color(Color.red, Color.red, fin);
            Draw.alpha(0.7);
            Lines.stroke(fout * 3 + 0.5);
            Lines.circle(b.x, b.y, fin * (shockwaveRadius));
        },
        update(bullet) {
            const rect = new Rect();
            const team = bullet.team;
            const x = bullet.x, y = bullet.y;
            const con = cons((unit) => {
                const dst = unit.dst(x, y);
                if (unit.team == bullet.team || dst > shockwaveRadius) {
                    return;
                }
                const lengthFadeout = getPercent(shockwaveRadius, dst, shockwaveAttenuation);
                const timeFadeout = getPercent(shockwaveDuration, bullet.time, shockwaveAttenuationTime);
                const power = lengthFadeout * timeFadeout * shockwavePower * Time.delta;

                // drag
                unit.impulse(Tmp.v3.set(unit.getX(), unit.getY()).sub(x, y).scl(power));
                unit.vel.limit(3);
            });
            rect.setSize(shockwaveRadius * 2).setCenter(x, y);
            if (team != null) {
                Units.nearbyEnemies(team, rect, con);
            } else {
                Units.nearby(rect, con);
            }
        },
    });
    bt.lifetime = shockwaveDuration;
    bt.shootEffect = Fx.none;
    bt.hitEffect = Fx.none;
    bt.smokeEffect = Fx.none;
    bt.trailEffect = Fx.none;
    bt.despawnEffect = Fx.none;
	bt.ammoMultiplier = 1
	bt.damage = 0;
    bt.speed = 0;
    bt.collides = false;
    bt.collidesAir = false;
    bt.collidesGround = false;
    bt.absorbable = false;
    bt.hittable = false;
    bt.keepVelocity = false;
    bt.reflectable = false;

    return bt;
})()
);

turret.consumes.powerCond(3.5, boolf(b => b.isActive()));

exports.震撼装置 = turret;