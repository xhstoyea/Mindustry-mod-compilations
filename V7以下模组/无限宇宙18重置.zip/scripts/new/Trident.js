var ax = extendContent(UnitType, 'q-Trident', {});
ax.defaultController = prov(() => new BuilderAI());
ax.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));
