/*
    * @guiY
    * @Extra mod <https://github.com/guiYMOUR/mindustry-Extra-Utilities-mod>
*/
const range = 58;//blocks
const knockback = 2;
const reloadTime = 90;
const shootEffect = Fx.shootBig2;
const smokeEffect = Fx.shootBigSmoke2;
const receiveEffect = Fx.mineBig;
const shootSound = Sounds.shootBig;
const shake = 2;
const translation = 5;
const minDistribute = 150;

const waterBullet = extend(BasicBulletType,{
    hit(b){    },
    update(b){
        var owner = b.owner;
        var other = Vars.world.build(owner.link);
        if(other == null) b.remove();
        if(other != null && b.within(other, 16) && b.team == other.team){
            receiveEffect.at(b);
            b.remove();
            Effect.shake(shake, shake, b);
            other.setReload(1);
            other.liquids.add(owner.getL(), owner.getA());
        }
    },
    draw(b){
        Draw.color(b.owner.getL().color);
        Draw.rect(this.backRegion, b.x, b.y, this.width, this.height, b.rotation() - 90);
        Draw.rect(this.frontRegion, b.x, b.y, this.width, this.height, b.rotation() - 90);

        Draw.reset();
    },
    despawned(b){    },
});
waterBullet.lifetime = 200;
waterBullet.width = 14;
waterBullet.height = 16;
waterBullet.shrinkY = 0;
waterBullet.damage = 0;
waterBullet.speed = 6;
waterBullet.collidesTiles = false;
waterBullet.pierce = true;
waterBullet.pierceBuilding = true;

const driver = extendContent(LiquidExtendingBridge, "ld", {
    drawBridge(req, ox, oy, flip){ },
    drawPlace(x, y, rotation, valid){
        Drawf.dashCircle(x * Vars.tilesize, y * Vars.tilesize, range * Vars.tilesize, Pal.accent);
    },
    linkValid(tile, other, checkDouble){
        if(other == null || tile == null || other == tile) return false;
        if(Math.pow(other.x - tile.x, 2) + Math.pow(other.y - tile.y, 2) > Math.pow(range + 0.5, 2)) return false;
        return ((other.block() == tile.block() && tile.block() == this) || (!(tile.block() instanceof ItemBridge) && other.block() == this))
            && (other.team == tile.team || tile.block() != this)
            && (!checkDouble || other.build.link != tile.pos());
    },
    findLink(x, y){ return null },
});
driver.buildType = prov(() => {
    var rotation = 90;
    var reload = 0;
    var bullet = null;
    var amount = 0;
    var liquid = null;
    var tr = new Vec2();
    return new JavaAdapter(LiquidExtendingBridge.LiquidExtendingBridgeBuild, {
        getR(){
            return rotation;
        },
        setR(v){
            rotation = v;
        },
        setReload(v){
            reload = v;
        },
        getA(){
            return amount;
        },
        setA(v){
            amount = v;
        },
        getL(){
            return liquid;
        },
        setL(v){
            liquid = v;
        },
        updateTile(){
            if(reload > 0){
                reload = Mathf.clamp(reload - this.edelta() / reloadTime);
            }
            const other = Vars.world.build(this.link);
            if(other != null && this.block.linkValid(this.tile, other.tile)){
                if(this.liquids.get(this.liquids.current()) > minDistribute){
                if(Vars.world.build(other.link) == null || other.liquids.get(other.liquids.current()) < minDistribute){
                    other.setR(Mathf.slerpDelta(other.getR(), other.angleTo(this), 0.125 * other.power.status));
                } else {
                    var others = Vars.world.build(other.link);
                    other.setR(Mathf.slerpDelta(other.getR(), other.angleTo(others), 0.125 * other.power.status));
                }
                this.setR(Mathf.slerpDelta(this.getR(), this.angleTo(other), 0.125 * this.power.status));
                }
                var targetRotation = this.angleTo(other);
                if(this.liquids.total() > minDistribute && other.liquids.total() < other.block.liquidCapacity && Vars.world.build(this.link) != null && Angles.near(this.getR(), targetRotation, 1) && Angles.near(other.getR(), targetRotation + 180, 1) && reload == 0){
                    this.setL(this.liquids.current());
                    this.setA(this.liquids.total()); 
                    this.shoot(other);
                }
            }
            if (other != null && other.link != null && Vars.world.build(other.link) == null) {
                other.dumpLiquid(other.liquids.current());
            }
        },
        shoot(target){
            reload = 1;
            this.bullet(waterBullet, this.getR());
            tr.trns(this.getR(), this.block.size * Vars.tilesize / 2);
            bullet.set(this.x + tr.x, this.y + tr.y);
            var angle = this.angleTo(target);
            shootEffect.at(this.x + Angles.trnsx(angle, translation),
            this.y + Angles.trnsy(angle, translation), angle);

            smokeEffect.at(this.x + Angles.trnsx(angle, translation),
            this.y + Angles.trnsy(angle, translation), angle);

            Effect.shake(shake, shake, this);
            
            shootSound.at(this.tile, Mathf.random(0.9, 1.1));
            this.liquids.remove(this.getL(), this.getA());
        },
        bullet(type, angle){
            tr.trns(angle, this.block.size * Vars.tilesize / 2);
            bullet = type.create(this.tile.build, this.team, this.x + tr.x, this.y + tr.y, angle);
        },
        drawSelect(){    },
        drawConfigure() {
            const sin = Mathf.absin(Time.time, 6, 1);

            Draw.color(Pal.accent);
            Lines.stroke(1);
            Drawf.circles(this.x, this.y, (this.block.size / 2 + 1) * Vars.tilesize + sin - 2, Pal.accent);
            const other = Vars.world.build(this.link);
            if(other != null){
                Drawf.circles(other.x, other.y, (this.block.size / 2 + 1) * Vars.tilesize + sin - 2, Pal.place);
                Drawf.arrow(this.x, this.y, other.x, other.y, this.block.size * Vars.tilesize + sin, 4 + sin, Pal.accent);
            }
            Drawf.dashCircle(this.x, this.y, range * Vars.tilesize, Pal.accent);
        },
        canDumpLiquid(to, liquid){
             return Vars.world.build(this.link) == null;
        },
        draw(){
            Draw.rect(Core.atlas.find("无限宇宙-ld-base"),this.x,this.y);
            var region = Core.atlas.find("无限宇宙-ld-region");
            var liquidRegion = Core.atlas.find("无限宇宙-ld-liquid");
            var top = Core.atlas.find("无限宇宙-ld-top");
            var bottom = Core.atlas.find("无限宇宙-ld-bottom");
            Draw.z(Layer.turret);

            Drawf.shadow(region,
            this.x + Angles.trnsx(rotation + 180, reload * knockback) - (this.block.size / 2),
            this.y + Angles.trnsy(rotation + 180, reload * knockback) - (this.block.size / 2), rotation - 90);
            Draw.rect(bottom,
            this.x + Angles.trnsx(rotation + 180, reload * knockback),
            this.y + Angles.trnsy(rotation + 180, reload * knockback), rotation - 90);
            Draw.rect(region,
            this.x + Angles.trnsx(rotation + 180, reload * knockback),
            this.y + Angles.trnsy(rotation + 180, reload * knockback), rotation - 90);
            Draw.color(this.liquids.current().color);
            Draw.alpha(Math.min(this.liquids.get(this.liquids.current()) / this.block.liquidCapacity, 1));
            Draw.rect(liquidRegion,
            this.x + Angles.trnsx(rotation + 180, reload * knockback),
            this.y + Angles.trnsy(rotation + 180, reload * knockback), rotation - 90);
            Draw.color();
            Draw.alpha(1);
            Draw.rect(top,
            this.x + Angles.trnsx(rotation + 180, reload * knockback),
            this.y + Angles.trnsy(rotation + 180, reload * knockback), rotation - 90);
        },
        acceptLiquid(source, liquid){
            if(this.team != source.team || !this.block.hasLiquids) return false;
            var other = Vars.world.tile(this.link);
            return other != null && this.block.linkValid(this.tile, other) && this.liquids.total() < this.block.liquidCapacity;
        },
        write(write) {
            this.super$write(write);
            write.f(rotation);
            write.f(reload);
        },
        read(read, revision) {
            this.super$read(read, revision);
            rotation = read.f();
            reload = read.f();
        },
    }, driver);
});
driver.hasPower = true;
driver.consumes.power(1.8);
driver.size = 3;
driver.liquidCapacity = 300;
driver.requirements = ItemStack.with(
    Items.metaglass, 70,
    Items.silicon, 77,
    Items.titanium, 60,
    Items.thorium, 35
);
driver.buildVisibility = BuildVisibility.shown;
driver.category = Category.liquid;
driver.localizedName = "液体驱动器";