var ax = extendContent(UnitType, 'm-主宰', {});
ax.defaultController = prov(() => new BuilderAI());
ax.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));
