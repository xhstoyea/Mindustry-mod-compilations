var ax = extendContent(UnitType, 'e-猎豹', {});
ax.defaultController = prov(() => new MinerAI());
ax.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));
