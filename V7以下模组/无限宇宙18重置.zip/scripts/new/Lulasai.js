const 二 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(二, 4));
        this.super$load();
    }
}, "二", Planets.sun, 3, 1);
二.generator = new SerpuloPlanetGenerator();
二.atmosphereColor = Color.valueOf("008B8B");
二.atmosphereRadIn = 0.02;
二.atmosphereRadOut = 0.1;
二.localizedName = "卢拉塞";
二.startSector = 1;
二.orbitRadius = 40;


const 首撞区 = new SectorPreset("首撞区", 二, 1);
首撞区.alwaysUnlocked = true;
首撞区.captureWave = 226;
首撞区.difficulty = 10;
首撞区.localizedName = "首撞区";
exports.首撞区 = 首撞区;
