var ax = extendContent(UnitType, 'aa-标枪', {});
ax.defaultController = prov(() => new RepairAI());
ax.constructor = prov(() => extend(UnitTypes.risso.constructor.get().class, {}));
