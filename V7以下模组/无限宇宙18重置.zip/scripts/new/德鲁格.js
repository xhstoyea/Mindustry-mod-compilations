var ax = extendContent(UnitType, 'c-德鲁格', {});
ax.defaultController = prov(() => new MinerAI());
ax.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));
