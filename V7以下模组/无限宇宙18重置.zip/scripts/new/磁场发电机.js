//代码来自梦境mod
const 磁场发电机 = extendContent(SolarGenerator, '磁场发电机', {
	setBars(){
		//this.bars.add('poweroutput', new Func(){get:entity => new Bar(prov(() => Core.bundle.format("bar.poweroutput", (entity.getPowerProduction() * 60 * entity.timeScale() + '').replace(/(?<=\.\d)\d*/g, ''))), prov(() => Pal.powerBar), new Floatp(){get:() => 1.0})});
	}
});
磁场发电机.localizedName = '磁场发电机';
磁场发电机.buildVisibility = BuildVisibility.shown;
磁场发电机.category = Category.power;
磁场发电机.update = 磁场发电机.configurable = 磁场发电机.hasPower = true;
磁场发电机.powerProduction = 6000;//电量上限，1:60
磁场发电机.buildType = prov(() => extend(Building, {
	productionEfficiency:0,
	update(){
		if(this.productionEfficiency > 1) this.productionEfficiency -= 8; // 每帧减少的量
	},
	buildConfiguration(table){
		table.button(Icon.upOpen, Styles.clearTransi, run(() => {
			if(this.productionEfficiency <= 1) this.productionEfficiency += 240; // 每下增加的量
		})).size(45);
	},
	getPowerProduction(){
		return this.productionEfficiency;
	},
	write(write){
		this.super$write(write);
		write.f(this.productionEfficiency);
	},
	read(read, revision){
		this.super$read(read, revision);
		this.productionEfficiency = read.f();
	}
}));
