Events.on(EventType.ClientLoadEvent, cons(e => {

    var dialog = new JavaAdapter(BaseDialog, {}, "Mindustry地狱插件0.1");
    var icon =new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find("btm-speedUp", Core.atlas.find("clear")));
    dialog.shown(run(() => {
        dialog.cont.table(Tex.button, cons(t => {
            t.defaults().size(250, 45).left();
            t.button("知道了", icon, Styles.cleart, run(() => {
                dialog.hide();
            }));
        t.add("本mod将会极大程度增加游戏难度，/n[red]请谨慎游玩")
        }));
    }));
    dialog.show();
}));




