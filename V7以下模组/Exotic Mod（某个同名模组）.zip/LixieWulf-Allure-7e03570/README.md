# Exotic Mod
Authors: 

  K103908

  BlueWolf

  MEEP Of Faith

  AndromedaFallen

---

We got together over Discord to bring you this interesting and overpowered mod. We hope you enjoy it!
The first 6.0 release is here. Much of the content is unfinished or needs refining. 

---

Discord: [this dingus link](https://discord.gg/M3hm5z6nm6)

  BlueWolf: BlueWolf#3682

  MEEP Of Faith: MEEP of Faith#7277 

  AndromedaFallen: AndromedaFallen#0001

  K103908: keeps changing his discord username like mad and so it's impossible to list.

---

Bring any questions to BlueWolf, as she's been the one actually working on the mod as of recent times.
