var lib = require('fllib');
var type = require('all/type');
const mmd = type.mmd;
var mMach = require('unit/mmj');
const mms = extend(BasicBulletType, {
    despawned(b){
        
        for(var i = 0; i < this.fragBullets; i++){
            var len = Mathf.random(1, 7);
            var a = b.rotation() + Mathf.range(this.fragCone/2) + this.fragAngle;
            mmd.create(b, b.x + Angles.trnsx(a, len), b.y + Angles.trnsy(a, len), a, Mathf.random(this.fragVelocityMin, this.fragVelocityMax), Mathf.random(this.fragLifeMin, this.fragLifeMax));
        }
    }
});
mms.damage = 0;
mms.speed = 10;
mms.lifetime = 1;
mms.collidesTiles = true;
mms.collides = true;
mms.fragLifeMin = 0.3;
mms.fragBullets = 2;
///
const flhx = extendContent(CoreBlock, "flhx", {
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) { return true; },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},

    drawPlace(x, y, rotation, valid) {},
});
lib.setBuildingSimple(flhx, CoreBlock.CoreBuild, {
    damage(damage) {
        this.super$damage(damage);
        if(Mathf.chance(0.1)){
            mms.create(this, this.x, this.y , 0);
        }
    }
});
flhx.unitType = mMach.mmj;
