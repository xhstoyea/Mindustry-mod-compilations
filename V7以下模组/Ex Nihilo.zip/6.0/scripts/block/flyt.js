//guiY
var lib = require('fllib');

const blockT = extendContent(LiquidSource, 'flyt', {
    setStats(){
		this.super$setStats();
		
		//this.stats.remove(Stat.productionTime);
		this.stats.add(Stat.productionTime, "40liquids/s");
	}
});
lib.setBuildingSimple(blockT, LiquidSource.LiquidSourceBuild, {
    ///
    updateTile(){
        if(this.source == null){
            //this.super$updateTile();
            this.liquids.clear();
        }else{
        if(this.consValid()){
            if(this.timer.get((30 / this.power.status) / this.timeScale)){
                if(this.liquids.total() < 40){
                    this.liquids.add(this.source, 20);
                    this.consume();
                }
            }
            this.dumpLiquid(this.source);
        }
        }
    }
});
//blockT.buildType = prov(() => new JavaAdapter(UnloaderBuild,overrides,blockT));
blockT.liquidCapacity = 40;
blockT.size = 1;
//blockT.progress = 20;
blockT.hasLiquids = true;
blockT.hasPower = true;
//blockT.requirements(Category.effect, ItemStack.with());
//blockT.consumes.power(2);
//blockT.consumes.items(new ItemStack(item, 1));

