/*
*@author <guiY>
*/
var lib = require('fllib');

const size = Vars.content.items().size;

const mmz = extendContent(Drill, "mmz", {});
lib.setBuildingSimple(mmz, Drill.DrillBuild, {
    _p : Math.floor(Math.random() * size),
    updateTile(){
        if(this.dominantItem == null) return;
        if(this.dominantItem != Items.scrap){
            this.super$updateTile();
        } else {
            this._p = Math.floor(Math.random() * size);
            if(this.timer.get(this.block.timerDump, this.block.dumpTime)){
                this.dump();
            }
            this.timeDrilled += this.warmup * this.delta();
            if(this.items.total() < this.block.itemCapacity && this.dominantItems > 0 && this.consValid()){
                var speed = 1;
                if(this.cons.optionalValid()){
                    speed = this.block.liquidBoostIntensity;
                }
                speed *= this.efficiency();
                this.lastDrillSpeed = (speed * this.dominantItems * this.warmup) / (this.block.drillTime + this.block.hardnessDrillMultiplier * this.dominantItem.hardness);
                this.warmup = Mathf.lerpDelta(this.warmup, speed, this.block.warmupSpeed);
                this.progress += this.delta() * this.dominantItems * speed * this.warmup;
                if(Mathf.chanceDelta(this.block.updateEffectChance * this.warmup))
                    this.block.updateEffect.at(this.x + Mathf.range(this.block.size * 2), this.y + Mathf.range(this.block.size * 2));
            }else{
                this.lastDrillSpeed = 0;
                this.warmup = Mathf.lerpDelta(this.warmup, 0, this.block.warmupSpeed);
                return;
            }
            var delay = this.block.drillTime + this.block.hardnessDrillMultiplier * this.dominantItem.hardness;
            if(this.dominantItems > 0 && this.progress >= delay && this.items.total() < this.block.itemCapacity){
                this.offload(Vars.content.items().get(this._p));
                this.index ++;
                this.progress %= delay;
            }
        }
    },
    drawSelect(){
        if(this.dominantItem != Items.scrap){
            this.super$drawSelect();
        } else {
            if(this.dominantItem != null){
                var dx = this.x - this.block.size * Vars.tilesize/2;
                var dy = this.y + this.block.size * Vars.tilesize/2;
                Draw.mixcol(Color.darkGray, 1);
                Draw.rect(Vars.content.items().get(this._p).icon(Cicon.small), dx, dy - 1);
                Draw.reset();
                Draw.rect(Vars.content.items().get(this._p).icon(Cicon.small), dx, dy);
            }
        }
    },
});
