//guiY
//搬运请加批注，谢谢各位(不加视为cheat)
//不加密，因为你不一定搬得走，真正厉害的人是不会搬的，早自己写了[滑稽]
///这是大墙
const lib = require('fllib');
const lightningChance = 0.5;
const lightningDamage = 40;
const lightningLength = 34;
//const chanceDeflect = Number.MAX_VALUE;
///护盾相关
const effectColor = Color.valueOf("606060");
const effectColor2 = Color.valueOf("ffffff");
const shieldRange = 150;//盾范围
const findRange = 12;
///
const eff1 = lib.newEffect(35, (e) => {
			Draw.color(effectColor);
			Lines.stroke(e.fout() * 4); 
			Lines.poly(e.x, e.y, 6, shieldRange * 0.525 + 75 * e.fin());
		});
const shieldDefense = lib.newEffect(20, (e) => {
	Draw.color(effectColor);
	Lines.stroke(e.fslope() * 2.5);
	Lines.poly(e.x, e.y, 6, 4 * e.fout() + 16);
	const d = new Floatc2({get(x, y){
		Lines.poly(e.x + x, e.y + y, 6, 4 * e.fout() + 4);
	}})
	Angles.randLenVectors(e.id, 2, 32 * e.fin(), 0, 360,d);
});
const sh = extend(BasicBulletType,{
	update(b){
		const realRange = shieldRange * b.fout();
		Groups.bullet.intersect(b.x - realRange, b.y - realRange, realRange * 2, realRange * 2, cons(trait =>{
			if(trait.type.absorbable && trait.team != b.team && Intersector.isInsideHexagon(trait.getX(), trait.getY(), realRange, b.x, b.y) ){
				trait.absorb();
				shieldDefense.at(trait);
			}
        }));
	},
	init(b){
		if(b == null)return;
		eff1.at(b.x, b.y, b.fout(), effectColor);
	},
	draw(b){
		Draw.color(effectColor);
		Lines.stroke(b.fout() * 3); 
		Lines.poly(b.x, b.y, 6, (shieldRange * 0.525) * b.fout() * b.fout());
		Draw.alpha(b.fout() * b.fout() * 0.3);
		Fill.poly(b.x, b.y, 6, (shieldRange * 0.525) * b.fout() * b.fout());
	}
});
sh.damage = 0;
sh.speed = 0;
sh.lifetime = 90;
sh.despawnEffect = Fx.none;
///
///自愈相关
const cureRatio = 0.02;
const cureReload = 120;
const baseColor = Color.valueOf("aacccc");
const phaseColor = Color.valueOf("de98b0");
///
///墙
const allWallLage = extendContent(Wall,"awl",{});
allWallLage.size = 2;
allWallLage.health = 3600;
allWallLage.lightningChance = lightningChance;
allWallLage.lightningDamage = lightningDamage;
allWallLage.lightningLength = lightningLength;
//allWallLage.chanceDeflect = chanceDeflect;
//allWallLage.flashHit = true;
allWallLage.absorbLasers = true;
allWallLage.insulated = true;

///覆盖
lib.setBuilding(allWallLage, (wall) => {
    
    //var hit = 1;
    var dam = 0;
    function getDam(){ return dam; };
    function setDam(value){ dam = value; };
    return new JavaAdapter(Building, {
        damage(damage){
            this.super$damage(damage);
            setDam(dam + 1 * 0.035);
        },
        collision(bullet){
            this.super$collision(bullet);
            

            ///闪电
            if(lightningChance > 0){
                if(Mathf.chance(lightningChance)){
                    Lightning.create(this.team, effectColor, lightningDamage, this.x, this.y, bullet.rotation() + 180, lightningLength);
                    Sounds.spark.at(this.tile, Mathf.random(0.9, 1.1));
                }
            }
            return true;
        },
        draw(){
            this.super$draw();
            if(this.damaged()){
                if(this.timer.get(cureReload / this.timeScale)){
                    this.heal(cureRatio * this.block.health);
                    Fx.healBlockFull.at(this.x, this.y, this.block.size, Tmp.c1.set(baseColor).lerp(phaseColor, 0.3));
                }
            }
            if(getDam() >= 1){
                sh.create(this, this.team, this.x, this.y, 0, 0, Mathf.random(1,2));
                setDam(0);
		    }
		    Draw.color(Color.valueOf("ffa652"));
                Draw.alpha(dam);
                Draw.rect(Core.atlas.find("fl-awl-s"), this.tile.drawx(), this.tile.drawy());
                Draw.color();
        },
        write(writer) {
            this.super$write(writer);
            writer.f(dam);
        },
        read(reader, revision) {
            this.super$read(reader, revision);
            dam = reader.f();
        },
    })
});