//guiY
var lib = require('fllib');
//var si = null;
const aa = Items.scrap;
const blockType = extendContent(Unloader, 'fl', {
    setBars() {
        this.super$setBars();

        this.bars.add("capacity", lib.func((e) => new Bar(
            prov(() => Core.bundle.format("bar.capacity", UI.formatAmount(e.block.itemCapacity))),
            prov(() => Pal.items),
            floatp(() => e.items.total() / (e.block.itemCapacity * Vars.content.items().count(boolf(i => i.unlockedNow()))))
        )));
    },
    setStats(){
        this.super$setStats();
        this.stats.add(Stat.productionTime, "0.5/s");
        for(var i = 0; i < Vars.content.items().size; i++){
            this.stats.add(Stat.output, Vars.content.items().get(i));
            this.stats.add(Stat.output, "/");
        }
    }
});
lib.setBuildingSimple(blockType, Unloader.UnloaderBuild, {
    _si : null,
    updateTile(){
        
        if(this._si != null){
            if(this.sortItem != this._si){
                this.items.remove(this._si, this.items.get(this._si));
            }
        }
        if(this.consValid() && this.sortItem != aa && this.items.total() <= 10 && this.sortItem != null){
            this._si = this.sortItem;
            if(this.timer.get((30 / this.power.status) / this.timeScale)){
                this.consume();
                this.items.add(this.sortItem, 1);
                    
            }
        }
        if(this.sortItem != null){
            if(this.items.get(this.sortItem)){
                this.dump(this.sortItem)
            }
        }
    }
});
blockType.itemCapacity = 10;
blockType.size = 2;
blockType.hasItems = true;
blockType.hasPower = true;
blockType.unloadable = true;
