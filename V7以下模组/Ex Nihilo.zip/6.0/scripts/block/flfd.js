//guiY
//thanks 滞人
const lib = require('fllib');

const healed = new IntSet();

(() => {

    function powerToText(power) {
        var s = power + "";
        if (s.length > 4) {
            return s.slice(0, s.length - 2);
        } else if (s.length > 2) {
            return s.slice(0, s.length - 2) + '.' + s.slice(s.length - 2, s.length);
        } else if (s.length == 2) {
            return "0." + s;
        } else {
            return "0.0" + s;
        }
    }

    var up1    ;
    var up2    ;
    //var up3    ;
    //var up4    ;
    var down1  ;
    var down2  ;
    var down3  ;
    //var down4  ;

    const MAX = 1000 * 100;
    const MIN = 40;
    const baseConsTime = 120;
    
    //var enabled = false;
    // 使用数组下标获取；存储的是乘以 100 的数字
    const commandMap = [1, 10, 100, 1000, 1000000];

    var lastNumber = 40;

    //const range = 120;
    const reload = 30;
    const baseColor = Color.valueOf("feb380");
    const phaseColor = Color.valueOf("ff9ed5");

    const INIT_MASK = 10000;

    var blockType = extendContent(ItemLiquidGenerator, "flfd", {
        load() {
            up1 =   lib.loadRegion("up1");
            up2 =   lib.loadRegion("up2");
            //up3 =   lib.loadRegion("up3");
            //up4 =   lib.loadRegion("up4");
            down1 = lib.loadRegion("down1");
            down2 = lib.loadRegion("down2");
            down3 = lib.loadRegion("down3");
            //down4 = lib.loadRegion("down4");
            this.super$load();
        }
        
        /*drawPlace(x, y, rotation, valid) {
            const tilesize = Vars.tilesize;
            Drawf.dashCircle(x * tilesize + this.offset, y * tilesize + this.offset, range, Pal.accent);
        },*/
    });
    /*blockType.update = true;
    blockType.solid = true;*/
    blockType.consumesPower = false;
    blockType.outputsPower = true;
    blockType.configurable = true;

    lib.setBuilding(blockType, (block) => {
        /*var heat = 0;
        var charge = 1;
        var phaseHeat = 0;*/
        // 存储的是乘以 100 的整数
        var powerTo = 40;
        var originTime = Math.floor(baseConsTime / Math.pow(powerTo, 0.5));
        var consTime = Math.floor(originTime * Math.pow(baseConsTime, 0.5));
        var enabled = false;
        /*function getHeat() { return heat; };
        function getCharge() { return charge; };
        function getPhaseHeat() { return phaseHeat; };*/
        function getPowerTo() { return powerTo; };
        //function getPowerToDecimal() { return powerTo / 100; };
        function getPowerToText() { return new Packages.java.lang.String(powerToText(powerTo * 100)); };
        /*function setHeat(v) { heat = v; };
        function setCharge(v) { charge = v; };
        function setPhaseHeat(v) { phaseHeat = v; };*/
        function setPowerTo(v) { powerTo = v; };

        return new JavaAdapter(Building, {
            playerPlaced() {
                // 算出最少需要多少次可以达到 lastNumber ，并发送指定次数个 configure
                Core.app.post(run(() => this.configure(lastNumber + INIT_MASK)));
            },
            buildConfiguration(table) {
                table.button(new Packages.arc.scene.style.TextureRegionDrawable(up1), Styles.clearTransi, run(() => { this.configure(1) })).size(40).tooltip("+10");
                table.button(new Packages.arc.scene.style.TextureRegionDrawable(up2), Styles.clearTransi, run(() => { this.configure(2) })).size(40).tooltip("+100");
                //table.button(new Packages.arc.scene.style.TextureRegionDrawable(up3), Styles.clearTransi, run(() => { this.configure(2) })).size(40).tooltip(lib.getMessage("message", "projector-up-3"));
                //table.button(new Packages.arc.scene.style.TextureRegionDrawable(up4), Styles.clearTransi, run(() => { this.configure(3) })).size(40).tooltip(lib.getMessage("message", "projector-up-4"));
                table.row();
                table.button(new Packages.arc.scene.style.TextureRegionDrawable(down1), Styles.clearTransi, run(() => { this.configure(101) })).size(40).tooltip("-10");
                table.button(new Packages.arc.scene.style.TextureRegionDrawable(down2), Styles.clearTransi, run(() => { this.configure(102) })).size(40).tooltip("-100");
                table.button(new Packages.arc.scene.style.TextureRegionDrawable(down3), Styles.clearTransi, run(() => { this.configure(104) })).size(40).tooltip("reset");
                //table.button(new Packages.arc.scene.style.TextureRegionDrawable(down4), Styles.clearTransi, run(() => { this.configure(103) })).size(40).tooltip(lib.getMessage("message", "projector-down-4"));
            },
            configured(player, value) {
                // 小于 100 视为减小命令，大于 1000000（七位数）视为初始化
                if (value > INIT_MASK) {
                    setPowerTo(value - INIT_MASK);
                } else if (value >= 100) {
                    var commandVal = commandMap[value - 100];
                    var result = Math.max(MIN, getPowerTo() - commandVal);
                    setPowerTo(result);
                    lastNumber = getPowerTo();
                } else {
                    var commandVal = commandMap[value];
                    var result = Math.min(MAX, getPowerTo() + commandVal);
                    setPowerTo(result);
                    lastNumber = getPowerTo();
                }
                //this.getPowerProduction(){return value;}
            },
            /*drawLight(){
                Drawf.light(this.team, this.x, this.y, 50 * this.efficiency(), baseColor, 0.7 * this.efficiency());
            },
            drawSelect(){
                var realRange = range;
                Vars.indexer.eachBlock(this, realRange, boolf(other => other.block.canOverdrive), cons(other => {
                    var tmp = Tmp.c1.set(baseColor);
                    tmp.a = Mathf.absin(4, 1);
                    Drawf.selected(other, tmp);
                }));
                Drawf.dashCircle(this.x, this.y, realRange, baseColor);
            },*/
            draw(){
                this.super$draw();
                const tilesize = Vars.tilesize;
                var f = 1 - (Time.time / 100) % 1;

                /*Draw.color(baseColor, phaseColor, getPhaseHeat());
                Draw.alpha(getHeat() * Mathf.absin(Time.time, 10, 1) * 0.5);
                Draw.rect(this.topRegion, this.tile.drawx(), this.tile.drawy());
                Draw.alpha(1);
                Lines.stroke((2 * f + 0.2) * getHeat());
                Lines.square(this.tile.drawx(), this.tile.drawy(), (1 - f) * 8);*/

                var font = Fonts.def;
                font.draw(getPowerToText(), this.x, this.y + 1.5, Color.orange, 0.14, false, Align.center);

                Draw.reset();
                if(this.consValid()){
                    originTime = Math.floor(baseConsTime / Math.pow(powerTo, 0.5));
                    consTime = Math.floor(originTime * Math.pow(baseConsTime, 0.5));
                    if(this.timer.get(consTime)){
                        this.consume();
                    }
                    enabled = true;
                }
                else{
                    enabled = false;
                }
            },
            getPowerProduction(tile){
                /*if(this.consValid()){
                    if(this.timer.get(Math.ceil(baseConsTime / (Math.pow(powerTo, 0.5)) * Math.pow(baseConsTime, 0.5))){
                        this.consume();
                    }*/
                    return enabled ? powerTo/60 : 0;
                //}
           },
            /*updateTile(){
                this.super$updateTile();
                if(this.consValid()){
                    if(this.timer.get(120)){
                        this.consume();
                    }
                    enabled = true;
                }else{
                    enabled = false;
                }
            }*/
            write(writer) {
                this.super$write(writer);
                //writer.f(heat);
                //writer.f(phaseHeat);
                writer.f(powerTo);
            },
            read(reader, revision) {
                this.super$read(reader, revision);
                //heat = reader.f();
                //phaseHeat = reader.f();
                powerTo = reader.f();
            },
        });
    });
})();
