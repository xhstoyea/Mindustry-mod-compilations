//guiY
//妙妙炮v3.0
//搬运请加批注，谢谢各位(不加视为cheat)
//不加密，因为简单，而且想了解有多少子弹的可以康康
//有用原版力墙才有特效，子弹力墙特效我写好了
var i = Math.floor(Math.random() * 20);
///
const lib = require('fllib');
const type = require('all/type');
const bt = type.allBulletType;
const mmd = type.mmd;
///
const turret = extendContent(Turret, 'mmp', {
    setStats(){
		this.super$setStats();
		
        this.stats.add(Stat.damage, "[#FF0000]???(oh no)");
	},
});

lib.setBuildingSimple(turret, Turret.TurretBuild, {
    b: i,
    j: 0,
    shoot(type){
        this.super$shoot(type);
        this.b = Math.floor(Math.random() * (bt.length - 2));
        this.j++;
        if(this.j >= 12){
            this.consume();
            this.j = 0;
        }
    },
    hasAmmo() { return this.consValid(); },
    peekAmmo() { return bt[this.b]; },
    useAmmo() { return bt[this.b]; },
    
});

//turret.targetInterval = 0;
