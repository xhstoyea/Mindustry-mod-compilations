//xvxshenhun@qq.com，使用标注来源（禁止删除注释）
//感谢xvx大佬提供主交互界面js（等什么？直接表白[滑稽]）

const meta = Vars.mods.locateMod("fl").meta;
meta.displayName = "[#FFFF00]Ex [#FF7000]Nihilo";


Events.on(EventType.ClientLoadEvent, cons(e => {

    var dialog = new JavaAdapter(BaseDialog, {}, "部分测试\nMindCraft mod 群:513165958");
    var adminIcon =new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find("fl-admin", Core.atlas.find("clear")));
    dialog.shown(run(() => {
        dialog.cont.table(Tex.button, cons(t => {
            t.defaults().size(250, 45).left();
            t.button("☞返回☜", adminIcon, Styles.cleart, run(() => {
                dialog.hide();
            }));
        t.add("原废料生万物\n©Ex Nihilo无中生有\n加入神奇的妙妙钻头\n修复部分数据\n꧁反馈请加群:513165958꧂\nExtra Utilities mod同群")
        }));
    }));
    dialog.show();
}));