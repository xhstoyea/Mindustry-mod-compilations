//guiY
const lib = require('fllib');
const type = require('all/type');
const mmd = type.mmd;
const ability = require('all/ability');
///
const w = extend(Weapon, {});

    w.name = lib.aModName + '-' + "mmw";
    w.length = 3;
    w.reload = 45;
    w.bullet = mmd;
    w.rotate = true;//是否自由旋转(炮塔效果)
    w.rotateSpeed = 4;
    w.x = 7;
    w.y = 2;
/*MinerAI
RepairAI
BuilderAI*///AI分类
const mmj = extendContent(UnitType, 'mmj', {});
mmj.abilities.add(ability.ColourfulForceFieldAbility(44, 2, 1500, 400));
mmj.constructor = prov(() => extend(UnitTypes.alpha.constructor.get().class, {}));
//AI类型
mmj.defaultController = prov(() => new BuilderAI());
mmj.localizedName = "妙妙机甲";
mmj.description = "妙啊";
mmj.weapons.add(w);
//mmj.weapons.add(w2);再加一个这样写
mmj.flying = true;
mmj.speed = 50;
mmj.hitSize = 12;
mmj.accel = 0.01;
mmj.rotateSpeed = 20;
mmj.baseRotateSpeed = 20;
mmj.drag = 0.1;
mmj.mass = 31210;
mmj.shake = 3;
mmj.health = 1000;
mmj.mineSpeed = 200;
mmj.mineTier = 2147483647;
mmj.buildSpeed = Infinity;
mmj.itemCapacity = 100;
mmj.engineOffset = 5;
mmj.engineSize = 3;
mmj.rotateShooting = false;
mmj.payloadCapacity = (200 * 200) * (8 * 8);
mmj.ammoCapacity = 200000000;
mmj.ammoResupplyAmount = 1;
mmj.commandLimit = 8;

exports.mmj = mmj;