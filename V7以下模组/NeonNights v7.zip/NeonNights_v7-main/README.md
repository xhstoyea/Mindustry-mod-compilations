# NeonNights v7
 Mindustry Texture Pack
 Made by !ereHyddeS and Antlrr, with the help of Woop.
 Seddy left the team, but this doesn't mean that his contributions aren't important.
 This texture pack was made mostly by him so go follow him.
![NeonNights](https://user-images.githubusercontent.com/87564635/126493609-689ef70b-8dfc-465a-9bb1-f1b7fd55e979.jpg)

