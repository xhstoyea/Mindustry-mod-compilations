MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 9999