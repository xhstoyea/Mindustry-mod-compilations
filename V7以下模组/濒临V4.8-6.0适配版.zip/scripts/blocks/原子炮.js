const annolaserhit = newEffect(25,e => {
	
})
const annolasershoot = newEffect(25,e => {
Draw.color(Color.valueOf("#B3DBFF"));
    //Drawf.tri(e.x, e.y, 5, 60 * e.fin(), e.rotation + 45);
    //Drawf.tri(e.x, e.y, 5, 60 * e.fin(), e.rotation + 135);
    //Drawf.tri(e.x, e.y, 5, 60 * e.fin(), e.rotation + 225);
    //Drawf.tri(e.x, e.y, 5, 60 * e.fin(), e.rotation + 315);
    
    Fill.circle(e.x, e.y, e.fout() * 11);
    Draw.color(Color.valueOf("#ffffff"));
    Fill.circle(e.x, e.y, e.fout() * 6)
    
    
})


const 原子炮tmpColor = Color();
const 原子炮colors = [Color.valueOf("#A6D2FF55"), Color.valueOf("#B3DBFF"), Color.valueOf("#DDF0FF"), Color.valueOf("ffffff")];
const 原子炮tscales = [1,0.8,0.5,0.2];
const 原子炮strokes = [1,0.5,0.3];
const 原子炮lenscales = [1.0125,1.02,1.025,1.0275];
const 原子炮length = 400;
const 原子炮激光 = extend(BasicBulletType,{
    update(b){
        if(Mathf.chance(Time.delta() * 0.2)){
            for (var i = 0; i < Mathf.random(4); i++) {
                Lightning.create(Team.derelict,Color.valueOf("B3DBFF"), 2, b.x, b.y,Mathf.random(360), Mathf.random(25)); 
            }
                    
        }
        if(Mathf.chance(Time.delta() * 0.3)){
            for (var i = 0; i < Mathf.random(2); i++) {
                Lightning.create(Team.derelict,Color.valueOf("#B3DBFF"), 5, b.x, b.y,Mathf.random(360), 6); 
            }
        }
        
        
        Effects.shake(1, 1, b.x, b.y);
        const target = Units.closestTarget(b.getTeam(), b.x,b.y,400)
        if (target != null) {
            if(b.timer.get(1, 1)){
            	
            Effects.effect(annolasershoot,Color.valueOf("C2FF8300"), b.x, b.y, b.rot());
                Damage.collideLine(b, b.getTeam(), annolaserhit, b.x, b.y, b.rot(), Mathf.dst(b.x,b.y,target.x,target.y), true);
                for (var i = 0; i < Mathf.random(3); i++) {
                Lightning.create(b.getTeam(),Color.valueOf("B3DBFF"), 30, target.x,target.y,Mathf.random(360), Mathf.random(30)); 
                }
            }

        }
        
    },
   /* hit(b,hitx,hity){
       Effects.effect(newEffect(25,e => {
	Draw.color(Color.valueOf("#B3DBFF"));
    Fill.circle(e.x, e.y, e.fout() * 22);
    Draw.color(Color.valueOf("#ffffff"));
    Fill.circle(e.x, e.y, e.fout() * 14);
	Draw.color(Color.valueOf("#B3DBFF"));
	Lines.stroke(e.fout() * 3);
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 12 + 1.5);
	}})
             Angles.randLenVectors(e.id, 8, 1+50 * e.fin(),e.rotation, 200,d);
             Draw.color(Color.valueOf("#B3DBFF"),Color.valueOf("#ffffff"),e.fin());
             Lines.stroke(e.fout() * 3 + 0.5 );
             Lines.circle(e.x, e.y, e.fin() * 32);
             
           
}),Color.valueOf("#B3DBFF00"), hitx, hity);
    },*/
    draw(b){
        const target = Units.closestTarget(b.getTeam(), b.x,b.y,400)
        var baseLen = 0 * b.fout();
        if (target != null) {
            baseLen = (Mathf.dst(b.x,b.y,target.x,target.y)) * b.fout();
        }

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for(var s = 0; s < 原子炮colors.length; s++){
            Draw.color(原子炮tmpColor.set(原子炮colors[s]).mul(1 + Mathf.absin(Time.time(), 1, 0.1)));
            for(var i = 0; i < 原子炮tscales.length; i++){
                //Tmp.v1.trns(b.rot() + 180, (lenscales[i] - 1) * 35);
                Lines.stroke((12 + Mathf.absin(Time.time(), 0.8, 1.5)) * b.fout() * 原子炮strokes[s] * 原子炮tscales[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * 原子炮lenscales[i]);
            }
        }
        Draw.reset();
    }
})
原子炮激光.damage = 21000000000000;

原子炮激光.despawnEffect = Fx.none;
原子炮激光.shootEffect = newEffect(25,e => {

    });
原子炮激光.hitSize = 4;
原子炮激光.drawSize = 420;
原子炮激光.lifetime = 16;
原子炮激光.pierce = true;
原子炮激光.hitEffect = newEffect(25,e => {
	Draw.color(Color.valueOf("#B3DBFF"));
    Fill.circle(e.x, e.y, e.fout() * 22);
    Draw.color(Color.valueOf("#ffffff"));
    Fill.circle(e.x, e.y, e.fout() * 14);
	Draw.color(Color.valueOf("#B3DBFF"));
	Lines.stroke(e.fout() * 3);
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 12 + 1.5);
	}})
             Angles.randLenVectors(e.id, 5, 1+65 * e.fin(),e.rotation, 140,d);
           //  Draw.color(Color.valueOf("#B3DBFF"),Color.valueOf("#ffffff"),e.fin());
             //Lines.stroke(e.fout() * 3 + 0.5 );
             //Lines.circle(e.x, e.y, e.fin() * 32);
             
           
})
const 原子激光器 = extendContent(LaserTurret,"原子激光器",{
turnToTarget(tile,targetRot){
        const entity = tile.ent();
 
        entity.rotation = Mathf.slerpDelta(entity.rotation, entity.angleTo(entity.target), 0.60);
    }
})
原子激光器.shootCone = 8;
原子激光器.recoil = 4;
原子激光器.size = 4;
原子激光器.shootShake = 3
原子激光器.range = 400
原子激光器.firingMoveFract = 4
原子激光器.shootDuration = 360
原子激光器.activeSound = Sounds.beam;
原子激光器.activeSoundVolume = 3
原子激光器.shootType = 原子炮激光

原子激光器.shootEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("#B3DBFF"));
	Lines.stroke(e.fout() * 3);
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 12 + 1.5);
	}})
             Angles.randLenVectors(e.id, 5, 1+65 * e.fin(),e.rotation, 28
,d);
           //  Draw.color(Color.valueOf("#B3DBFF"),Color.valueOf("#ffffff"),e.fin());
             Lines.stroke(e.fout() * 3 + 0.5 );
             Lines.circle(e.x, e.y, e.fin() * 40);
             
           
})