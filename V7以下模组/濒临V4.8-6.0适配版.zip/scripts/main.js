if(typeof(require) !== "undefined"){ 
	require("blocks/反物质炮");
	require("blocks/激光");
	require("blocks/原子炮");
	
}
 

