let mono = new UnitType("重型德鲁格采矿无人机");

mono.defaultController = prov(() => extend(MinerAI, {}));

mono.flying = true;
mono.drag = 0.06;
mono.accel = 0.12;
mono.speed = 2;
mono.health = 200;
mono.engineSize = 2;
mono.engineOffset = 6;
mono.itemCapacity = 90;
mono.range = 50;

mono.mineTier = 4;
mono.mineSpeed = 8;

mono.constructor = UnitTypes.mono.constructor;
Time.run(1, run(() => print(mono.icon(Cicon.full))));