Time.run(1, run(() => {
	let frag = new BaseDialog('开挂属性开关');
	frag.cont.defaults().width(200).left();
	frag.cont.check('红队核心自爆', Core.settings.get(modName + '-红队核心自爆', true), new Boolc({get:b => Core.settings.put(modName + '-红队核心自爆', b)})).row();
	frag.cont.check('黄队核心填充资源', Core.settings.get(modName + '-黄队核心填充资源', true), new Boolc({get:b => Core.settings.put(modName + '-黄队核心填充资源', b)})).row();
	frag.cont.check('玩家无限资源', Core.settings.get(modName + '-玩家无限资源', true), new Boolc({get:b => Core.settings.put(modName + '-玩家无限资源', b)})).row();
	frag.cont.table(cons(t => t.label(() => '每帧跳波波数(0禁用):' + Core.settings.get(modName + '-每帧跳波波数', 0)) && t.slider(0, 10, 1, +Core.settings.get(modName + '-每帧跳波波数', 0), new Floatc({get:n => Core.settings.put(modName + '-每帧跳波波数', '' + n)})).padLeft(10))).left().row();
	frag.cont.button('解锁全科技', run(() => TechTree.all.toArray().forEach(n => n.content.unlock())));
	frag.addCloseButton();
	frag.show();
	let t = new Table;
	t.update(t => {
		if(Vars.state.isMenu()) return;
		if(Core.settings.get(modName + '-红队核心自爆', true)){
			Team.get(2).cores().toArray().forEach(c => c.kill());
		}
		if(Core.settings.get(modName + '-黄队核心填充资源', true)){
			let core = Team.get(1).core();
			if(core != null) for(let i of Vars.content.items().toArray()) core.items.set(i, core.storageCapacity);
		}
		if(Core.settings.get(modName + '-玩家无限资源', true)){
			Vars.state.rules.infiniteResources = true;
		}
		if(Core.settings.get(modName + '-每帧跳波波数', 0) > 0){
			Vars.state.wave += +Core.settings.get(modName + '-每帧跳波波数', 0);
		}
	});
	Core.scene.add(t);
}));