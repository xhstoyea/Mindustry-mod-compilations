

    /*const 曙光 = extendContent(UnitType,"曙光",{
});
    曙光.constructor = prov(() => extend(CommanderMechUnit, {}));
    
    const 曙光 = extendContent(UnitType,"曙光",{
});
    曙光.constructor = prov(() => extend(MechUnit, {}));*/
    
    const 黎明 = extendContent(UnitType,"黎明",{});
    黎明.constructor = prov(() => extend(PayloadUnit, {}));
    黎明.ammoType = AmmoTypes.powerLow;
    
    
    
    //Mech;
    //Unit;
    //Builder;
    //Miner;
    //BuilderMinerUnit;
    //BuilderUnit;