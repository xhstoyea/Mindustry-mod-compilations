const 曙光炮 = extendContent(Weapon,"曙光炮",{

})
曙光炮.bullet = 光;
曙光炮.length = 10;
曙光炮.shots = 1;
曙光炮.velocityRnd = 0;
曙光炮.shotDelay = 5;
曙光炮.spacing = 0.25;
曙光炮.recoil = 1.5;
曙光炮.width = 7.25;
曙光炮.reload = 85;
曙光炮.inaccuracy = 1.75;
曙光炮.alternate = true;
//曙光炮.range = 340;
曙光炮.ejectEffect = newEffect(16,e => {
	Draw.color(Color.valueOf("#A0CCFF"),Color.valueOf("#DBEDFF"),e.fin());
	Lines.stroke(e.fin() * 1.25);
    Lines.circle(e.x, e.y, e.fout() * 22);
             });
曙光炮.shootSound = Sounds.laser;



const 曙光 = extendContent(UnitType,"曙光",{
	updateAlt(player){
		if(player.boostHeat >= 0.1) return;
		this.hitsize = 120
		
},
	load(){
		this.weapon.load();
		this.region = Core.atlas.find(this.name);
		this.weapon.region = Core.atlas.find("计划战争_零度-曙光炮-equip");
	},
	}
)
曙光.weapon = 曙光炮;
曙光.weaponOffsetX = 10.50;
曙光.health = 1200;
曙光.localizedName = Core.bundle.get("UnitType.曙光.name");
曙光.mass = 60;
曙光.speed = 1.50;
曙光.boostSpeed = 0.80;
曙光.drag = 0.15;
曙光.buildPower = 1000;
曙光.itemCapacity = 1800;
曙光.engineOffset = 5.5;
曙光.engineSize = 0.1;
曙光.engineColor = Color.valueOf("#74A9FF"),
曙光.flying = true,
曙光.drawCell = true,
曙光.drillPower = 1000,
曙光.mineSpeed = 2300,
曙光.weaponOffsetY = -0.75