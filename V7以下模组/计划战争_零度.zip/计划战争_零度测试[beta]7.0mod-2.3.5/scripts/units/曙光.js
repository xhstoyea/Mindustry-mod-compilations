

    /*const 曙光 = extendContent(UnitType,"曙光",{
});
    曙光.constructor = prov(() => extend(CommanderMechUnit, {}));
    
    const 曙光 = extendContent(UnitType,"曙光",{
});
    曙光.constructor = prov(() => extend(MechUnit, {}));*/
    /*
    const 曙光 = extendContent(UnitType,"曙光",{
});
    曙光.constructor = prov(() => extend(PayloadUnit, {}));
    曙光.drawShields = false,
    曙光.targetflag = BlockFlag.repair;
    曙光.ammoType = AmmoTypes.powerLow;
    曙光.constructor = prov(() => extend(UnitTypes.zenith.constructor.get().class, {}));
    曙光.abilities.add(new ForceFieldAbility(20, 3,500,1000);
    */
    
    
    
    
    var 曙光 = extendContent(UnitType, '曙光', {});
曙光.drawShields = false;
曙光.abilities.add(new ForceFieldAbility(20,20,500,1000));
曙光.constructor = prov(() => extend(UnitTypes.dagger.constructor.get().class, {}));