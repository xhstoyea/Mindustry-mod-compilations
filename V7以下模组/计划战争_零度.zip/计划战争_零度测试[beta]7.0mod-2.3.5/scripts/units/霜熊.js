

    /*const 曙光 = extendContent(UnitType,"曙光",{
});
    曙光.constructor = prov(() => extend(CommanderMechUnit, {}));
    
    const 曙光 = extendContent(UnitType,"曙光",{
});
    曙光.constructor = prov(() => extend(MechUnit, {}));*/
    
    const 霜熊 = extendContent(UnitType,"霜熊",{
});
    霜熊.constructor = prov(() => extend(PayloadUnit, {}));