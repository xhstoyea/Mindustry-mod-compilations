

    /*const 曙光 = extendContent(UnitType,"曙光",{
});
    曙光.constructor = prov(() => extend(CommanderMechUnit, {}));
    
    const 曙光 = extendContent(UnitType,"曙光",{
});
    曙光.constructor = prov(() => extend(MechUnit, {}));*/
    
    const 岁月 = extendContent(UnitType,"岁月",{
});
    岁月.constructor = prov(() => extend(PayloadUnit, {}));