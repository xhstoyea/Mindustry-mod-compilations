

    /*const 曙光 = extendContent(UnitType,"曙光",{
});
    曙光.constructor = prov(() => extend(CommanderMechUnit, {}));
    
    const 曙光 = extendContent(UnitType,"曙光",{
});
    曙光.constructor = prov(() => extend(MechUnit, {}));*/
    
    const 珍珠 = extendContent(UnitType,"珍珠",{
});
    珍珠.constructor = prov(() => extend(PayloadUnit, {}));
    
    
    //在v6.0_beta-115更新后的constructor:
    //PayloadUnit