

    /*const 曙光 = extendContent(UnitType,"曙光",{
});
    曙光.constructor = prov(() => extend(CommanderMechUnit, {}));
    
    const 曙光 = extendContent(UnitType,"曙光",{
});
    曙光.constructor = prov(() => extend(MechUnit, {}));*/
    
    const 罗撒斯 = extendContent(UnitType,"罗撒斯",{
});
    
    罗撒斯.constructor = prov(() => extend(PayloadUnit, {}));
    //罗撒斯.constructor = prov(() => extend(BuilderMinerUnit, {}));