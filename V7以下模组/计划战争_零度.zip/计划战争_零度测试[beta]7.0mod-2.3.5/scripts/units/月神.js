 
 
 
 
 const 月神 = extendContent(Legs,"月神",{});
 
 
 
 
 /*
    const 月神 = extendContent(LegUnit,"月神",{});
月神.constructor = prov(() => extend(legs, {}));
    
/*月神.groundLayer = Layer.legs;
月神.legCount = 4;
    
//    "type": "LegsUnit",
//fuck = MADE(cao(() =! simaanuke(tamade,{}));
    
    //PayloadUnit
    
    //groundLayer = Layer.legUnit - 1;
    
    /*
    
            toxopid = new UnitType("toxopid"){{
            drag = 0.1f;
            speed = 0.5f;
            hitSize = 21f;
            health = 22000;
            armor = 13f;

            rotateSpeed = 1.9f;

            legCount = 8;
            legMoveSpace = 0.8f;
            legPairOffset = 3;
            legLength = 75f;
            legExtension = -20;
            legBaseOffset = 8f;
            landShake = 1f;
            legSpeed = 0.1f;
            legLengthScl = 0.93f;
            rippleScale = 3f;
            legSpeed = 0.19f;
            ammoType = AmmoTypes.powerHigh;
            buildSpeed = 1f;

            legSplashDamage = 80;
            legSplashRange = 60;

            hovering = true;
            allowLegStep = true;
            visualElevation = 0.95f;
            groundLayer = Layer.legUnit;
            
            
            
            
            
            
            */