  
  
    /*if(typeof(require) !== "undefined"){
    require("units/曙光");
    }*/
    
    
    
    
    //block
    

    //airs
    require('units/曙光');
    require('units/黎明');
    require('units/珍珠');
    require('units/霜熊');
    require('units/岁月');
    require('units/罗撒斯');
    
    //blocks
    require('blocks/plan晶体实验室');
    require('blocks/plan晶体淬炼工厂');
    require('blocks/硫化物量产工厂');
    require('blocks/爆炸混合物量产工厂');
    require('blocks/终端核心共生装置');
    require('blocks/小型质量驱动器');
    //require('blocks/plan晶体第二实验室');
    //legs
    //require('units/月神');
    
    //ground
    //require('units/曙光');
    
    //require('units/OH-NO');
    
    //恒星
    require('球/第二恒星');
    //require('球/0274');
    //require('球/第三恒星');
    
    //行星
    require('球/凝视');
    //require('球/遇见');
    
    //天气
    //require('天气/酸雨');
    //物品
    require('晶体');
    
    //状态
    //require('状态/debuff');
    
    
    //require('状态/PLAN辐射');
    //require('buff/晕眩');
    //require('buff/恐惧');
    
    