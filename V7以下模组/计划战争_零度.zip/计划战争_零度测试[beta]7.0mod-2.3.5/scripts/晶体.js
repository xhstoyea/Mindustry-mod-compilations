exports.plan晶体 = (() => {
var myitem = extendContent(Item, 'plan晶体', {});
return myitem;
})();

exports.plan零能晶体 = (() => {
var myitem = extendContent(Item, 'plan零能晶体', {});
return myitem;
})();

exports.铁锭 = (() => {
var myitem = extendContent(Item, '铁锭', {});
return myitem;
})();

exports.铝锭 = (() => {
var myitem = extendContent(Item, '铝锭', {});
return myitem;
})();

exports.金锭 = (() => {
var myitem = extendContent(Item, '金锭', {});
return myitem;
})();

exports.钬锭 = (() => {
var myitem = extendContent(Item, '钬锭', {});
return myitem;
})();

exports.CannedIndustrialWastewater = (() => {
var myitem = extendContent(Item, 'CannedIndustrialWastewater', {});
return myitem;
})();


//exports.核打击音效 = (() => {
//var mysound = extendContent(Sound, '核打击音效', {});
//return mysound;
//})();



exports.工业废水 = (() => {
var myliquid = extendContent(Liquid, '工业废水', {});
return myliquid;
})();

exports.纯净水 = (() => {
var myliquid = extendContent(Liquid, '纯净水', {});
return myliquid;
})();
/*

exports.thorium = (() => {
var myitem = extendContent(Item, 'thorium', {});
return myitem;
})();

exports.sand = (() => {
var myitem = extendContent(Item, 'sand', {});
return myitem;
})();


exports.coal = (() => {
var myitem = extendContent(Item, 'coal', {});
return myitem;
})();

exports.surge-alloy = (() => {
var myitem = extendContent(Item, 'surge-alloy', {});
return myitem;
})();

exports.blast-compound = (() => {
var myitem = extendContent(Item, 'blast-compound', {});
return myitem;
})();

exports.pyratite = (() => {
var myitem = extendContent(Item, 'pyratite', {});
return myitem;
})();
*/
/*
exports.rbq = (() => {
var myrbq = extendContent(Rbq, 'rbq', {});
return myrbq;
})();
*/