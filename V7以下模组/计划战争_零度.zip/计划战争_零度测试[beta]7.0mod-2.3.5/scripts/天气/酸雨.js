//xvxshenhun@qq.com，使用标注来源（禁止删除注释）

exports.酸雨1 = (() => {
var 酸雨0 = extend(StatusEffect, '酸雨', {});
酸雨0.color = Color.valueOf("4FFF6FFF");
酸雨0.damage = 1.5;
酸雨0.damageMultiplier = 0.4;
酸雨0.healthMultiplier = 0.4;
酸雨0.speedMultiplier = 0.12;
酸雨0.reloadMultiplier = 0.12;
酸雨0.effectChance = 2;
酸雨0.effect = Fx.melting;

//melting

//freezing

var 酸雨1 = new RainWeather("酸雨")
酸雨1.status = 酸雨0;
酸雨1.statusDuration = 600;
酸雨1.duration = 15 * Time.toMinutes;
//酸雨1.noiseLayers = 3;
//酸雨1.noiseLayerSclM = 0.8;
//酸雨1.noiseLayerAlphaM = 0.7;
//酸雨1.noiseLayerSpeedM = 2;
//酸雨1.noiseLayerSclM = 0.6;
酸雨1.baseSpeed = 0.1;
酸雨1.color = Color.valueOf("66ff66");
酸雨1.noiseColor = Color.valueOf("66ff66");
酸雨1.noiseScale = 1100;
酸雨1.noisePath = "fog";
酸雨1.drawNoise = true;
酸雨1.useWindVector = false;
酸雨1.xspeed = 1;
酸雨1.yspeed = 0.5;
酸雨1.attrs.set(Attribute.light, -1.5);
酸雨1.attrs.set(Attribute.spores, 1);
酸雨1.opacityMultiplier = 0.3;
酸雨1.localizedName = Core.bundle.format("计划战争_零度.酸雨");
return 酸雨1;
})();


/*
        rain = new RainWeather("rain"){{
            attrs.set(Attribute.light, -0.2f);
            attrs.set(Attribute.water, 0.2f);
            status = StatusEffects.wet;
            sound = Sounds.rain;
            soundVol = 0.25f;
        }};
        */