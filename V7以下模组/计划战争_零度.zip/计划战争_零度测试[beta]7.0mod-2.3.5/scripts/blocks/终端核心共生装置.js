//xvxshenhun@qq.com，使用标注来源（禁止删除注释）

//const 核心限制 = createBuildLimit(100);

const 终端核心共生装置 = extendContent(CoreBlock, "终端核心共生装置", {
    
    canBreak(){return true;},
    canReplace(other){return true;},
    canPlaceOn(tile, team){return true;},
});

//终端核心共生装置.unitType = UnitTypes.曙光;
exports.终端核心共生装置 = 终端核心共生装置;


/*
    canBreak() { return true; },
    canReplace(other) { return true; },
*
    

        canBreak() { return Vars.state.teams.cores(Vars.player.team()).size > 1; },
    canReplace(other) { return true.alwaysReplace; },
*/