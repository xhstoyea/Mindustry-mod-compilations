const jtsy = extend(GenericCrafter, "plan晶体实验室", {});
const drawer = new DrawAnimation();
drawer.frameCount = 11;
jtsy.drawer = drawer;