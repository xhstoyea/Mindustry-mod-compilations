


const llc = extend(GenericCrafter, "硫化物量产工厂", {});
const drawer = new DrawAnimation();
drawer.frameCount = 4;
drawer.sine = true;
llc.drawer = drawer;