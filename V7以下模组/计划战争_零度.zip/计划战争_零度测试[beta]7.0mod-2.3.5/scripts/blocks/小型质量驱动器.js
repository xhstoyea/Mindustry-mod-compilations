const 小型质量驱动器 = extend(MassDriver, "小型质量驱动器", {});
小型质量驱动器.bullet = new MassDriverBolt
exports.小型质量驱动器 = 小型质量驱动器;