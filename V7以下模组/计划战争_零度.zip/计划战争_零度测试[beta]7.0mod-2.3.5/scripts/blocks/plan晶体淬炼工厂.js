const jtcl = extend(GenericCrafter, "plan晶体淬炼工厂", {});
const drawer = new DrawAnimation();
drawer.frameCount = 19;
drawer.sine = false;
jtcl.drawer = drawer;