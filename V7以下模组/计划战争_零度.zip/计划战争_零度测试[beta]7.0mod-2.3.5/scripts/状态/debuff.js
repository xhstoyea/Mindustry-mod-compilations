
const 能量过载 = new extend(StatusEffect, '能量过载', {});
能量过载.color = Color.valueOf("12D9E3FF");
能量过载.damage = 10;
能量过载.damageMultiplier = 1.5;
能量过载.healthMultiplier = 0.4;
能量过载.speedMultiplier = -1;
能量过载.reloadMultiplier = 0.02;
能量过载.effectChance = 100;
能量过载.effect = Fx.sapped;








//melting
//corroded
//freezing
/*
        rain = new RainWeather("rain"){{
            attrs.set(Attribute.light, -0.2f);
            attrs.set(Attribute.water, 0.2f);
            status = StatusEffects.wet;
            sound = Sounds.rain;
            soundVol = 0.25f;
        }};
        */