const 第三恒星 = new JavaAdapter(Planet, {},
"第三恒星", Planets.sun, 0, 6);
第三恒星.bloom = true;
第三恒星.accessible = true;
第三恒星.visible = true;
第三恒星.orbitRadius = 50;
    第三恒星.meshLoader = () => new SunMesh(第三恒星, 5, 6, 3.4, 2.8, 1.3, 0.8, 1.1,
        Color.valueOf("FF6B6BFF"),
        Color.valueOf("FF7676FF"),
        Color.valueOf("FF7373FF"),
        Color.valueOf("F54B4BFF"),
        Color.valueOf("EF3737FF"),
        Color.valueOf("DF1E1EFF")
    );
    /*
    FF9D9DFF;1
    FF8989FF;1.2
    FF7373FF;1.4
    
    F54B4BFF;2.4
    EF3737FF;2.6
    DF1E1EFF;2.8*/