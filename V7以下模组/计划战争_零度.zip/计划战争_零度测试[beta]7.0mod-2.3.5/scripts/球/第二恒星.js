const 第二恒星 = new JavaAdapter(Planet, {},
"第二恒星(欢迎起名/641660274)", Planets.sun, 0, 2);
第二恒星.bloom = true;
第二恒星.accessible = true;
第二恒星.visible = true;
第二恒星.orbitRadius = 35;
    第二恒星.meshLoader = () => new SunMesh(第二恒星, 4, 6, 2.8, 1.4, 1.8, 1.4, 1.1,
        Color.valueOf("8FFBFFFF"),
        Color.valueOf("5AAAFF"),
        Color.valueOf("4CA3FF"),
        Color.valueOf("488CD6"),
        Color.valueOf("90C6FF"),
        Color.valueOf("B2D7FF")
    );
const PLAN0A1W = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(PLAN0A1W, 6));
        this.super$load();
    }
},
"PLAN0A1W", 第二恒星, 2, 1);
PLAN0A1W.localizedName = Core.bundle.format("计划战争_零度.PLAN0A1W");
PLAN0A1W.generator = new SerpuloPlanetGenerator();
PLAN0A1W.atmosphereColor = Color.valueOf("3c1b8f");
//PLAN0A1W.lightColor = Color.block.cpy();
PLAN0A1W.startSector = 9;
PLAN0A1W.atmosphereRadIn = 0.02;
PLAN0A1W.atmosphereRadOut = 0.29;
PLAN0A1W.visible = true;
PLAN0A1W.bloom = true;
PLAN0A1W.accessible = true;
PLAN0A1W.rotateTime = 10 * 50;
PLAN0A1W.orbitRadius = 6;

const 满目星空 = SectorPreset("满目星空", PLAN0A1W, 9);
满目星空.difficulty = 3;
满目星空.alwaysUnlocked = true;
满目星空.addStartingItems = true;
满目星空.captureWave = 200;
满目星空.localizedName = Core.bundle.format("计划战争_零度.满目星空");


const PLAN1S2E = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(PLAN1S2E, 8));
        this.super$load();
    }
}, 
"PLAN1S2E", 第二恒星, 3, 1);
PLAN1S2E.localizedName = Core.bundle.format("计划战争_零度.PLAN1S2E");
PLAN1S2E.generator = new SerpuloPlanetGenerator();
PLAN1S2E.atmosphereColor = Color.valueOf("3c1b8f");
//PLAN1S2E.lightColor = Color.block.cpy();
PLAN1S2E.startSector = 80;
PLAN1S2E.atmosphereRadIn = 0.02;
PLAN1S2E.atmosphereRadOut = 0.32;
PLAN1S2E.visible = true;
//PLAN1S2E.bloom = true;
PLAN1S2E.accessible = true;
PLAN1S2E.rotateTime = 60 * 120;
PLAN1S2E.orbitRadius = 18;

const 方块战 = SectorPreset("方块战", PLAN1S2E, 4);
方块战.difficulty = 8;
方块战.alwaysUnlocked = true;
方块战.captureWave = 60;
方块战.localizedName = Core.bundle.format("计划战争_零度.方块战");

const 生命区 = SectorPreset("生命区", PLAN1S2E, 8);
生命区.difficulty = 16;
生命区.alwaysUnlocked = true;
生命区.captureWave = 120;
生命区.localizedName = Core.bundle.format("计划战争_零度.生命区");

const 极寒之地 = SectorPreset("极寒之地", PLAN1S2E, 2);
极寒之地.difficulty = 2;
极寒之地.alwaysUnlocked = true;
极寒之地.captureWave = 200;
极寒之地.localizedName = Core.bundle.format("计划战争_零度.极寒之地");

const 肝帝之城 = SectorPreset("肝帝之城", PLAN1S2E, 9);
肝帝之城.difficulty = 9;
肝帝之城.alwaysUnlocked = true;
肝帝之城.captureWave = 0;
肝帝之城.localizedName = Core.bundle.format("计划战争_零度.肝帝之城");




/*
    第二恒星.meshLoader = () => new SunMesh(第二恒星, 0.33, 2.8, 3.4, 3.3, 1.0, 0.8, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6,
        Color.valueOf("7DBBFFFF"),
        Color.valueOf("5AAAFFFF"),
        Color.valueOf("4CA3FFFF"),
        Color.valueOf("488CD6FF"),
        Color.valueOf("90C6FFFF"),
        Color.valueOf("B2D7FFFF"),
        Color.valueOf("CBE4FFFF"),
        Color.valueOf("CCD5FFFF"),
        Color.valueOf("C2CDFFFF"),
        Color.valueOf("B4C0F6FF"),
        Color.valueOf("E6EAFFFF"),
        Color.valueOf("D5DBF9FF")
    );*/
    
    
    /*
        第二恒星.meshLoader = () => new SunMesh(第二恒星, 2.8,2.6, 0.4, 1.6, 1.3, 0.8,1.02,
        Color.valueOf("8FFBFFFF"),
        Color.valueOf("70E7EBFF"),
        Color.valueOf("61D7DBFF"),
        Color.valueOf("4ACBD0FF"),
        Color.valueOf("32B7BCFF"),
        Color.valueOf("1DCFD6FF")
    );
    */
/*
        serpulo = new Planet("serpulo", sun, 3, 1){{
            generator = new SerpuloPlanetGenerator();
            meshLoader = () -> new HexMesh(this, 6);
            atmosphereColor = Color.valueOf("3c1b8f");
            atmosphereRadIn = 0.02f;
            atmosphereRadOut = 0.3f;
            startSector = 15;
        }};
    }
}

/*
//xvxshenhun@qq.com，使用标注来源（禁止删除注释）
const 凝视 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(凝视, 7));
        this.super$load();
    }
}, "凝视", Planets.serpulo, 1, 1);

凝视.localizedName = Core.bundle.format("planet.计划战争_零度.凝视");
凝视.generator = new SerpuloPlanetGenerator();
凝视.atmosphereColor = Color.valueOf("3c1b8f");
//凝视.lightColor = Color.block.cpy();
凝视.startSector = 1;
凝视.atmosphereRadIn = 0.03;
凝视.atmosphereRadOut = 0.5;
凝视.visible = true;
凝视.bloom = true;
凝视.accessible = true;
凝视.rotateTime = 10 * 50;
凝视.orbitRadius = 5;
/*
        serpulo = new Planet("serpulo", sun, 3, 1){{
            generator = new SerpuloPlanetGenerator();
            meshLoader = () -> new HexMesh(this, 6);
            atmosphereColor = Color.valueOf("3c1b8f");
            atmosphereRadIn = 0.02f;
            atmosphereRadOut = 0.3f;
            startSector = 15;






const 满目星空 = SectorPreset("满目星空", 凝视, 1);
满目星空.difficulty = 2;
满目星空.alwaysUnlocked = true;
满目星空.captureWave = 5;
满目星空.localizedName = Core.bundle.format("计划战争_零度.满目星空");
const 南海 = SectorPreset("南海", 凝视, 2);
南海.difficulty = 3;
南海.alwaysUnlocked = true;
南海.captureWave = 30;
南海.localizedName = Core.bundle.format("计划战争_零度.南海");
/*
var 眼 = Planet("眼", 凝视, 0, 0.1);
眼.bloom = true;
眼.accessible = false;
眼.localizedName = "眼";
眼.orbitRadius = 2.5;

var 水泥星 = Planet("水泥星", sun, 0, 0.1);
水泥星.bloom = true;
水泥星.atmosphereColor = Color.valueOf("E5E5E5");
水泥星.accessible = false;
水泥星.localizedName = "水泥星";
水泥星.orbitRadius = 5.5;


const 水泥星 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(水泥星, 6));
        this.super$load();
    }
}, "水泥星", Planets.sun, 0.2, 0.2);

水泥星.localizedName = Core.bundle.format("planet.计划战争_零度.水泥星");
水泥星.generator = new SerpuloPlanetGenerator();
水泥星.atmosphereColor = Color.valueOf("E5E5E5");
//水泥星.lightColor = Color.block.cpy();
水泥星.startSector = 0;
水泥星.atmosphereRadIn = 0.02;
水泥星.atmosphereRadOut = 0.1;
水泥星.visible = true;
水泥星.bloom = true;
水泥星.accessible = false;
水泥星.rotateTime = 10 * 60;
水泥星.orbitRadius = 3;
*/