//xvxshenhun@qq.com，使用标注来源（禁止删除注释）

const 凝视 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(凝视, 7));
        this.super$load();
    }
},
"凝视", Planets.sun, 2, 1);
凝视.localizedName = Core.bundle.format("计划战争_零度.凝视");
凝视.generator = new SerpuloPlanetGenerator();
凝视.atmosphereColor = Color.valueOf("189B2CFF");
//凝视.lightColor = Color.block.cpy();
凝视.startSector = 1;
凝视.atmosphereRadIn = 0.03;
凝视.atmosphereRadOut = 0.32;
凝视.visible = true;
凝视.bloom = true;
凝视.accessible = true;
凝视.rotateTime = 10 * 50;
凝视.orbitRadius = 20;

const 满目沙子 = SectorPreset("满目沙子", 凝视, 1);
满目沙子.difficulty = 2;
满目沙子.alwaysUnlocked = true;
满目沙子.captureWave = 5;
满目沙子.localizedName = Core.bundle.format("计划战争_零度.满目沙子");

const 南海 = SectorPreset("南海", 凝视, 23);
南海.difficulty = 2;
南海.alwaysUnlocked = true;
南海.captureWave = 30;
南海.localizedName = Core.bundle.format("计划战争_零度.南海");