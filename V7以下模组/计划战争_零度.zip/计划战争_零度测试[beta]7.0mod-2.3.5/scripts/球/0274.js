const 彩虹恒星 = new JavaAdapter(Planet, {},
"彩虹恒星", Planets.sun, 0, 0.8);
彩虹恒星.bloom = true;
彩虹恒星.accessible = true;
彩虹恒星.visible = true;
彩虹恒星.orbitRadius = 50;
    彩虹恒星.meshLoader = () => new SunMesh(彩虹恒星, 2, 3, 1.0, 1.0, 1.0, 1.0, 1.0,
        Color.valueOf("FF0000FF"),
        Color.valueOf("FFA900FF"),
        Color.valueOf("FFF600FF"),
        Color.valueOf("0EFF00FF"),
        Color.valueOf("00FFE1FF"),
        Color.valueOf("0053FFFF")
    );
    
const 彩虹卫星A = new JavaAdapter(Planet, {},
"彩虹卫星A", 彩虹恒星, 0, 0.8);
彩虹卫星A.bloom = true;
彩虹卫星A.accessible = false;
彩虹卫星A.visible = true;
彩虹卫星A.orbitRadius = 10;
    彩虹卫星A.meshLoader = () => new SunMesh(彩虹卫星A, 2, 3, 1.0, 1.0, 1.0, 1.0, 1.0,
        Color.valueOf("FF0000FF"),
        Color.valueOf("FFA900FF"),
        Color.valueOf("FFF600FF"),
        Color.valueOf("0EFF00FF"),
        Color.valueOf("00FFE1FF"),
        Color.valueOf("0053FFFF")
    );
    
const 彩虹卫星B = new JavaAdapter(Planet, {},
"彩虹卫星B", 彩虹恒星, 0, 0.8);
彩虹卫星B.bloom = true;
彩虹卫星B.accessible = false;
彩虹卫星B.visible = true;
彩虹卫星B.orbitRadius = 12;
    彩虹卫星B.meshLoader = () => new SunMesh(彩虹卫星B, 2, 3, 1.0, 1.0, 1.0, 1.0, 1.0,
        Color.valueOf("FF0000FF"),
        Color.valueOf("FFA900FF"),
        Color.valueOf("FFF600FF"),
        Color.valueOf("0EFF00FF"),
        Color.valueOf("00FFE1FF"),
        Color.valueOf("0053FFFF")
    );
    
const 彩虹卫星C = new JavaAdapter(Planet, {},
"彩虹卫星C", 彩虹恒星, 0, 0.8);
彩虹卫星C.bloom = true;
彩虹卫星C.accessible = false;
彩虹卫星C.visible = true;
彩虹卫星C.orbitRadius = 14;
    彩虹卫星C.meshLoader = () => new SunMesh(彩虹卫星C, 2, 3, 1.0, 1.0, 1.0, 1.0, 1.0,
        Color.valueOf("FF0000FF"),
        Color.valueOf("FFA900FF"),
        Color.valueOf("FFF600FF"),
        Color.valueOf("0EFF00FF"),
        Color.valueOf("00FFE1FF"),
        Color.valueOf("0053FFFF")
    );
    
const 彩虹卫星D = new JavaAdapter(Planet, {},
"彩虹卫星D", 彩虹恒星, 0, 0.8);
彩虹卫星D.bloom = true;
彩虹卫星D.accessible = false;
彩虹卫星D.visible = true;
彩虹卫星D.orbitRadius = 16;
    彩虹卫星D.meshLoader = () => new SunMesh(彩虹卫星D, 2, 3, 1.0, 1.0, 1.0, 1.0, 1.0,
        Color.valueOf("FF0000FF"),
        Color.valueOf("FFA900FF"),
        Color.valueOf("FFF600FF"),
        Color.valueOf("0EFF00FF"),
        Color.valueOf("00FFE1FF"),
        Color.valueOf("0053FFFF")
    );
    
const 彩虹卫星E = new JavaAdapter(Planet, {},
"彩虹卫星E", 彩虹恒星, 0, 0.8);
彩虹卫星E.bloom = true;
彩虹卫星E.accessible = false;
彩虹卫星E.visible = true;
彩虹卫星E.orbitRadius = 18;
    彩虹卫星E.meshLoader = () => new SunMesh(彩虹卫星E, 2, 3, 1.0, 1.0, 1.0, 1.0, 1.0,
        Color.valueOf("FF0000FF"),
        Color.valueOf("FFA900FF"),
        Color.valueOf("FFF600FF"),
        Color.valueOf("0EFF00FF"),
        Color.valueOf("00FFE1FF"),
        Color.valueOf("0053FFFF")
    );
    /*
    红 = FF0000FF
    橙 = FFA900FF
    黄 = FFF600FF
    绿 = 0EFF00FF
    青 = 00FFE1FF
    蓝 = 0053FFFF
    紫 = B400FFFF
    
    
    
    
    
    
    
    /*
    FF9D9DFF;1
    FF8989FF;1.2
    FF7373FF;1.4
    
    F54B4BFF;2.4
    EF3737FF;2.6
    DF1E1EFF;2.8*/