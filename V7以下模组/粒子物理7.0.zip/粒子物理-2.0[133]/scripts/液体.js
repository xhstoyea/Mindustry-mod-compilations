const CSTEffects = this.global.CSTEffects;
const CSTStatus = this.global.CSTStatus;

exports.beta富能液 = (() => {
var myliquid = extendContent(Liquid, 'beta富能液', {});
myliquid.localizedName = "beta富能液"
myliquid.description = "由于能量溢出，即使是液氮的冷却，对能液也是杯水车薪"
myliquid.color = Color.valueOf("E6E8FA");
myliquid.heatCapacity = 1.1
return myliquid;
})();

exports.液态氮 = (() => {
var myliquid = extendContent(Liquid, '液态氮', {});
myliquid.localizedName = "液态氮"
myliquid.description = "超低温流体，高级冷却剂"
myliquid.color = Color.valueOf("00ffff");
myliquid.effect =StatusEffects.freezing
myliquid.heatCapacity = 1.5
return myliquid;
})();

/*
exports.污水 = (() => {
var myliquid = extendContent(Liquid, '污水', {});
myliquid.localizedName = "污水"
myliquid.description = "遭受污染的水，需要经过处理才能正常使用"
myliquid.color = Color.valueOf("5B488D");
myliquid.effect = StatusEffects.wet
myliquid.heatCapacity = 0.34
return myliquid;
})();
*/