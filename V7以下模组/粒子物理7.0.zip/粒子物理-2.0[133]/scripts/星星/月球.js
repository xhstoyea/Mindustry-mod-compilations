const 月球 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(月球, 4));
        this.super$load();
    }
}, "月球", Planets.sun, 3, 1);
月球.generator = new SerpuloPlanetGenerator();
月球.atmosphereColor = Color.valueOf("85b7f2");
月球.atmosphereRadIn = 0.1
月球.atmosphereRadOut = 0.3
月球.localizedName = "月球lz";
月球.startSector = 1;
月球.orbitRadius = 7;
月球.alwaysUnlocked =true;

const 聚集地 = new SectorPreset("聚集地", 月球, 1);
聚集地.alwaysUnlocked = true;
聚集地.difficulty = 10
聚集地.localizedName = "聚集地";
exports.聚集地 = 聚集地;

const 地下墓地 = new SectorPreset("地下墓地",月球, 2);
地下墓地.alwaysUnlocked = true;
地下墓地.difficulty = 10
地下墓地.localizedName = "地下墓地";
exports.地下墓地 = 地下墓地;

const 流油谷 = new SectorPreset("流油谷", 月球, 3);
流油谷.difficulty = 10
流油谷.alwaysUnlocked = true;
流油谷.addStartingItems = true;
流油谷.localizedName = "流油谷"

/*
        serpulo = new Planet("serpulo", sun, 3, 1){{
            generator = new SerpuloPlanetGenerator();
            meshLoader = () -> new HexMesh(this, 6);
            atmosphereColor = Color.valueOf("3c1b8f");
            atmosphereRadIn = 0.02f;
            atmosphereRadOut = 0.3f;
            startSector = 15;
            alwaysUnlocked = true;*/