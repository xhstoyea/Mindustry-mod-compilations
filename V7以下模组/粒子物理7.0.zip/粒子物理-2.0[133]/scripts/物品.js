exports.粒子防护板 = (() => {
var myitem = extendContent(Item, '粒子防护板', {});
return myitem;
})();

exports.记忆金属 = (() => {
var myitem = extendContent(Item, '记忆金属', {});
return myitem;
})();

exports.量子合金 = (() => {
var myitem = extendContent(Item, '量子合金', {});
return myitem;
})();

exports.混合板 = (() => {
var myitem = extendContent(Item, '混合板', {});
return myitem;
})();

exports.铀 = (() => {
var myitem = extendContent(Item, '铀', {});
return myitem;
})();

exports.重核 = (() => {
var myitem = extendContent(Item, '重核', {});
return myitem;
})();


