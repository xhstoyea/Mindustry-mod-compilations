const B = extend(MassDriver, "微型电磁弹射器", {});
B.bullet = new MassDriverBolt;
const B1 = extend(MassDriver, "轻型电磁弹射器", {});
B1.bullet = new MassDriverBolt;