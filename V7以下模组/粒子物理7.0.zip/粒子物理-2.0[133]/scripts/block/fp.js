const fp = extendContent(ForceProjector, "fp", {});
fp.buildType = prov(() => {
    return new JavaAdapter(ForceProjector.ForceBuild, {
        drawShield(){
            if(!this.broken){
                var radius = this.realRadius();

                Draw.z(Layer.shields);

                Draw.color(Color.valueOf("000000FF")/*这里是你要的颜色*/, Color.white, Mathf.clamp(this.hit));

                if(Core.settings.getBool("animatedshields")){
                    Fill.poly(this.x, this.y, 6, radius);
                }else{
                    Lines.stroke(1.5);
                    Draw.alpha(0.09 + Mathf.clamp(0.08 * this.hit));
                    Fill.poly(this.x, this.y, 6, radius);
                    Draw.alpha(1);
                    Lines.poly(this.x, this.y, 6, radius);
                    Draw.reset();
                }
            }

            Draw.reset();
        }
    }, fp);
});


fp.buildVisibility = BuildVisibility.shown;
fp.health =9600;
fp.size=8;
fp.radius=300;
fp.phaseUseTime=120;
fp.phaseRadiusBoost=120;
fp.basePowerDraw=50;
fp.shieldHealth=150000;
fp.phaseShieldBoost=300000;
fp.cooldownLiquid=5.5;
fp.cooldownNormal=13.9;
fp.cooldownBrokenBase=8.4;
fp.basePowerDraw=10;
fp.category = Category.effect;

//其实完全可以去json里面定义