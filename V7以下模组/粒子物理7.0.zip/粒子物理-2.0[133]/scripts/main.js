/*Events.on(EventType.ClientLoadEvent, cons(e => {

    var dialog = new JavaAdapter(BaseDialog, {}, "粒子物理7.0");
    var icon =new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find("btm-speedUp", Core.atlas.find("clear")));
    dialog.shown(run(() => {
        dialog.cont.table(Tex.button, cons(t => {
            t.defaults().size(250, 45).left();
            t.button("返回", icon, Styles.cleart, run(() => {
                dialog.hide();
            }));
        t.add("贴图更换（感谢萝卜）\n删除部分内容\n新增原型天启激光器\n   高能射线炮\n[green]可能导致存档丢失，酌情更新\n本人概不负责\n[red]英译标题由@年年有鱼制作\n这是最后一个版本粒子物理\n将不再更新\n[red]我QQ171864117或者 \n[green]粒子物理mod交流群\n212635451\n——正常的石墨烯")
        }));
    }));
    dialog.show();
}));*/
//require("block/driver");
require("block/LB");
require("block/fp");
require("und");
require("lib");
//require("星星/月球");
require("物品");
require("液体");
//require("block/物品合成器");
require("block/质驱");
/*require("blocks/石墨棒压机");
require("blocks/记忆合金锻造厂");
require("blocks/闪电炮");
require("blocks/夸克整合器");*/
/*require("unit/天启者")*/
	/*require("大型量子核心");*/






