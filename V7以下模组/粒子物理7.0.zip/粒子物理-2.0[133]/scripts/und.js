//guiY
//可以选择完全不改，或可以改个名字，json名字和引号里的那个一样
/*
使用指南
I. json不需要type
II. 你只需要导入并修改json即可
III. js导入选择
    1. 你的mod里有main.js
        复制这个文件到你的script里，再复制main.js里的内容到你的main.js里
    2. 你的mod没有main.js
        直接复制两个文件到你的script里，如果要加入其他js，直接在main里写require即可，不会可以问
*/
const und = extendContent(Unloader, "und", {});
und.buildType = prov(() => {
    var ts = 1;
    var td = 0;
    return new JavaAdapter(Unloader.UnloaderBuild, {
        delta(){
            return Time.delta * ts;
        },
        applyBoost(intensity, duration){
            if(intensity >= ts){
                td = Math.max(td, duration);
            }
            ts = Math.max(ts, intensity);
        },
        updateTile(){
            if(td > 0){
                td -= Time.delta;
                if(td <= 0){
                    ts = 1;
                }
            }
            this.timeScale = Math.max(ts * this.power.status, 0.001);
            this.timeScaleDuration = td / Math.max(this.power.status, 0.001);
            if(this.power.status >= 0.001){
                this.super$updateTile();
            }
        },
    }, und);
});