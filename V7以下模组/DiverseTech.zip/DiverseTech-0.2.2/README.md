![Logo](logo.png)

## The Mod:
Innovate & Research new Technologies that will blow up your mind!

## v0.2:
A smaller update that took some months... But don't worry, this is just the beginning of an entire project that won't be so small because uh, there is a Trello full of amazing ideas that are coming in the next updates! Thank you so much for playing this mod. Don't forget to give it a star here in GitHub!

## The Future:
### Thematic Updates:

Thematic? Yes!

Development gets easier and interesting when updates are thematic, the content goes deeper and deeper in the topic. Future updates (> v0.2) will be perhaps thematic and of course, special!
