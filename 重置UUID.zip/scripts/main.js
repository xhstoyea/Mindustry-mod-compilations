Events.on(EventType.ClientLoadEvent,()=>{
    Vars.ui.showConfirm(
        "重置UUID",
        "点击确定[red]重置UUID[],不影响战役.\n[yellow]确定前应当了解该操作的后果[]\n若想避免该弹窗,请禁用该MOD",
        ()=>{Core.settings.remove("uuid")}
    )
})