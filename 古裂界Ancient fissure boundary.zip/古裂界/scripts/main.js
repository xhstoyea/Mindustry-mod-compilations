MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000
require("辅助/缩放");
require("单位/copters");
//#########################################//娱乐
require("娱乐/破墙仪");
require("娱乐/反引力");
require("娱乐/正引力");


















//注我拿的是蔚蓝行星的
//以下注释为VSHES荔枝独立完成为了让其他蔚蓝开发者同样可以更新开屏显示窗口插件
Events.on(EventType.ClientLoadEvent, cons(e => {
       var dialogo = new BaseDialog("[green]古裂界\nGIJ");//新建一个显示窗口
	dialogo.buttons.button("@close", run(() => {
		dialogo.hide()//退出此界面
	})).size(210, 64);//按钮用原版@close贴图

    dialogo.cont.pane(table => {//滑动显示
        
		table.image(Core.atlas.find("logo")).left().size(600, 100).pad(3).row();//显示logo图片

		table.add("[#8800CCFF]欢迎游玩古裂界模组！\n[white]本模组添加了一个新的行星<恶普莱克尔>\n赛普罗准备着计划，飞向新行星，建造生物研究实验室，看看什么生物！").left().growX().wrap().pad(4).labelAlign(Align.left).row();
		 let label = new FLabel("[white]模组QQ群: {rainbow}292950475");
		 table.add(label).left().row();
		 table.add("[green]v0.8更新内容:\n更新了一些单位\n增加了几个炮台\n修改了一些贴图\n修改了虫族属性\n增加了一个大型单位\n修改了一些单位的贴图"
).left().growX().wrap().width(580).maxWidth(580).pad(4).labelAlign(Align.left).row();

	}).grow().center().maxWidth(600)
             dialogo.show();
}))