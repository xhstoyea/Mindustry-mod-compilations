function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("火药")
newItem("宏电合金")
newItem("骨头")
newItem("营养块")