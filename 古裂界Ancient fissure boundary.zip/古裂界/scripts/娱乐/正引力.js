// 引入名为 "base/coflib" 的模块
const lib = require("base/coflib");

// 定义范围为 8 * 20
let range = 8 * 20;

// 创建一个名为 "正引力" 的新方块
let deflection = lib.newBlock("正引力", {
    // 绘制放置位置的方法
    drawPlace(x, y, rotation, valid) {
        // 调用父类的 drawPlace 方法
        this.super$drawPlace(x, y, rotation, valid);
        // 绘制一个虚线圆来表示范围
        Drawf.dashCircle(x * 8 + this.offset, y * 8 + this.offset, range, Pal.accent);
    },
    // 设置方块统计信息的方法
    setStats() {
        // 调用父类的 setStats 方法
        this.super$setStats();
        // 添加范围统计信息
        this.stats.add(Stat.range, range / 8, StatUnit.blocks);
    },
    // 设置条目的方法
    setBars() {
        // 调用父类的 setBars 方法
        this.super$setBars();
        // 移除 "power" 条目
        this.removeBar("power");
        // 添加一个名为 "Power" 的条目
        this.addBar("Power", func(e => new Bar(
            prov(() => lib.bundle("bar.ownPower", Strings.fixed(e.getMP() * -0.5 * 2, 0))), // 有负数的是引力
            prov(() => Pal.powerBar),
            floatp(() => e.getMP())
        )));
    }
});

// 设置方块的生命值
deflection.health = 240;
// 表示具有电力相关功能
deflection.hasPower = true;
// 建筑可见性为仅沙盒模式
deflection.buildVisibility = BuildVisibility.sandboxOnly;

// 定义消耗电力的方式
deflection.consPower = extend(ConsumePower, {
    // 请求的电力计算方法
    requestedPower(entity) {
        if (entity.block.consPower == this) return entity.getMass() * 2;
        else return 0
    }
});

// 定义方块的建造类型
deflection.buildType = prov(() => {
    let mp = 1, mass = 1, Switch = true;
    return extend(Building, {
        // 获取质量的方法
        getMass() {
            return mass;
        },
        // 获取 MP（可能是某种能量值）的方法
        getMP() {
            return mass * this.power.status;
        },
        // 绘制选择框的方法
        drawSelect() {
            this.super$drawSelect();
            // 绘制选择框时也绘制范围的虚线圆
            Drawf.dashCircle(this.x, this.y, range, Pal.accent);
        },
        // 更新方块的方法
        updateTile() {
            mp = mass * this.power.status;
            if (this.enabled) {
                this.block.consPower.capacity = mp * -1; // 引力大小
                // 对范围内的子弹进行处理
                Groups.bullet.intersect(this.x - range, this.y - range, range * 2, range * 2, b => {
                    let ang = Angles.angle(this.x, this.y, b.x, b.y),
                        ang1 = Angles.angle(b.x, b.y, this.x, this.y);
                    if (b.team!= this.team) b.vel.rotateTo(Switch? ang1 : ang, -0.5 * mp);
                });
            }
        },
        // 获取状态的方法
        status() {
            return this.power.status > 0? BlockStatus.active : BlockStatus.noInput;
        },
        // 写入数据的方法
        write(write) {
            this.super$write(write);
            write.f(mass);
            write.bool(Switch);
        },
        // 读取数据的方法
        read(read, revision) {
            this.super$read(read, revision);
            mass = read.f();
            Switch = read.bool();
        }
    })
})
