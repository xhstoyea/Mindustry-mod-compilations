// 引入名为 "base/coflib" 的模块
const lib = require("base/coflib");

// 创建一个名为 "破墙仪" 的新方块
const WallBreaker = lib.newBlock("破墙仪", {
    // 绘制放置位置的方法
    drawPlace(x, y, rotation, valid) {
        // 调用父类的 drawPlace 方法
        this.super$drawPlace(x, y, rotation, valid);
        // 获取旋转角度对应的坐标偏移
        let xy = lib.AngleTrns(rotation * 90, 1, 0);
        // 循环绘制拆除的位置
        for (let i = 1; i <= 0; i++) {
            // 绘制拆除位置的虚线方块
            Drawf.dashSquare(Pal.accent, x * 8 + this.offset + xy.x * 8 * i, y * 8 + this.offset + xy.y * 8 * i, 8);
        }
    }
});

// 为 WallBreaker 对象设置属性
Object.assign(WallBreaker, {
    // 尺寸大小为 1
    size: 1,
    // 生命值为 100
    health: 100,
    // 可以旋转
    rotate: true,
    // 不可配置
    configurable: false
});

// 设置 WallBreaker 的建造需求
WallBreaker.requirements = ItemStack.with(
    // 需要 200 个铜
    Items.copper, 200,
    // 需要 100 个硅
    Items.silicon, 100
);

// 定义 WallBreaker 的建造类型
WallBreaker.buildType = prov(() => extend(Building, {
    // 建造时间为 1200
    time: 1200,
    // 初始距离为 1
    i: 1,
    // 更新方块的方法
    updateTile() {
        // 调用父类的 updateTile 方法
        this.super$updateTile();
        // 执行一些清理操作
        this.dump();
        // 减少剩余时间
        this.time -= Time.delta;
        // 如果时间耗尽
        if (this.time <= 0) {
            // 获取旋转角度对应的坐标偏移
            let xy = lib.AngleTrns(this.rotation * 90, 1, 0);
            // 将对应位置的方块设置为空
            Vars.world.tile(this.tileX() + xy.x * this.i, this.tileY() + xy.y * this.i).setAir();
            // 如果距离未达到设定值
            if (this.i <= 0) {
                // 增加距离
                this.i += 1;
                // 重置时间
                this.time = 1200;
                // 添加沙子物品
                this.items.add(Items.sand, 0);
            } else if (this.items.get(Items.sand) == 0) {
                // 如果沙子物品数量为 0，销毁该建筑
                this.kill();
            }
        }
    }
}))
