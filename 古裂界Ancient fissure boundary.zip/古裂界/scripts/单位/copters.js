//Galahad
const 空1 = extend(UnitType, "空1", {
	draw(unit) {
		this.super$draw(unit);
		Draw.rect(
			"古裂界-空1-转",
			unit.x + Angles.trnsx(unit.rotation - 90, 0, 0),
			unit.y + Angles.trnsy(unit.rotation - 90, 0, 0),
			Time.time * 10
		);
		Draw.rect(
			"古裂界-空1-转",
			unit.x + Angles.trnsx(unit.rotation - 90, 0, 0),
			unit.y + Angles.trnsy(unit.rotation - 90, 0, 0),
			Time.time * -10
		);
	}
});
//Galahad
const 空2 = extend(UnitType, "空2", {
	draw(unit) {
		this.super$draw(unit);
		Draw.rect(
			"古裂界-空2-转",
			unit.x + Angles.trnsx(unit.rotation - 90, 0, 0),
			unit.y + Angles.trnsy(unit.rotation - 90, 0, 0),
			Time.time * 10
		);
		Draw.rect(
			"古裂界-空2-转",
			unit.x + Angles.trnsx(unit.rotation - 90, 0, 0),
			unit.y + Angles.trnsy(unit.rotation - 90, 0, 0),
			Time.time * -10
		);
	}
});
//Galahad
const 空3 = extend(UnitType, "空3", {
	draw(unit) {
		this.super$draw(unit);
		Draw.rect(
			"古裂界-空3-转",
			unit.x + Angles.trnsx(unit.rotation - 90, 0, 0),
			unit.y + Angles.trnsy(unit.rotation - 90, 0, 0),
			Time.time * 10
		);
		Draw.rect(
			"古裂界-空3-转",
			unit.x + Angles.trnsx(unit.rotation - 90, 0, 0),
			unit.y + Angles.trnsy(unit.rotation - 90, 0, 0),
			Time.time * -10
		);
	}
});
//Galahad
const 空4 = extend(UnitType, "空4", {
	draw(unit) {
		this.super$draw(unit);
		Draw.rect(
			"古裂界-空4-转",
			unit.x + Angles.trnsx(unit.rotation - 90, 0, 0),
			unit.y + Angles.trnsy(unit.rotation - 90, 0, 0),
			Time.time * 10
		);
		Draw.rect(
			"古裂界-空4-转",
			unit.x + Angles.trnsx(unit.rotation - 90, 0, 0),
			unit.y + Angles.trnsy(unit.rotation - 90, 0, 0),
			Time.time * -10
		);
	}
});
//Galahad
const 空5 = extend(UnitType, "空5", {
	draw(unit) {
		this.super$draw(unit);
		Draw.rect(
			"古裂界-空5-转",
			unit.x + Angles.trnsx(unit.rotation - 90, 0, 0),
			unit.y + Angles.trnsy(unit.rotation - 90, 0, 0),
			Time.time * 10
		);
		Draw.rect(
			"古裂界-空5-转",
			unit.x + Angles.trnsx(unit.rotation - 90, 0, 0),
			unit.y + Angles.trnsy(unit.rotation - 90, 0, 0),
			Time.time * -10
		);
	}
});
//Galahad
const 空6 = extend(UnitType, "空6", {
	draw(unit) {
		this.super$draw(unit);
		Draw.rect(
			"古裂界-空6-转",
			unit.x + Angles.trnsx(unit.rotation - 90, 0, 0),
			unit.y + Angles.trnsy(unit.rotation - 90, 0, 0),
			Time.time * 10
		);
		Draw.rect(
			"古裂界-空6-转",
			unit.x + Angles.trnsx(unit.rotation - 90, 0, 0),
			unit.y + Angles.trnsy(unit.rotation - 90, 0, 0),
			Time.time * -10
		);
	}
});

//Lancelot
//Thanks to evl#8935 for helping me with these!!
//Need to figure out how to make this modular

//constructor
空1.constructor = () => extend(UnitEntity, {});
空2.constructor = () => extend(UnitEntity, {});
空3.constructor = () => extend(UnitEntity, {});
空4.constructor = () => extend(UnitEntity, {});
空5.constructor = () => extend(UnitEntity, {});
空6.constructor = () => extend(UnitEntity, {});