// 从 "planet/恶普莱克尔" 模块中导入名为 "Char" 的对象
const { Char } = require("planet/恶普莱克尔");

// 扩展 "Planet" 类创建一个新的对象 "p"，命名为 "恶普莱克尔星环"，并以 "Char" 为基础，设置一些初始属性
const p = extend(Planet, "恶普莱克尔星环", Char, 0.1, {
    // 星球的缩放比例为 1
    scale: 1,
    // 星球的基础块类型为 Blocks.snow
    base: Blocks.snow,
    // 星球的色调为 Blocks.ice
    tint: Blocks.ice,
    // 色调阈值为 0.5
    tintThresh: 0.5,
    // 陨石的数量为 300
    pieces: 50
});

// 设置 "p" 对象的本地化名称为 "恶普莱克尔星环"
p.localizedName = "恶普莱克尔星环";
// 轨道半径设置为 0
p.orbitRadius = 0;
// 表示星球没有大气层
p.hasAtmosphere = false;
// 相机半径设置为星球的缩放比例
p.camRadius = p.scale;
// 最小缩放比例设置为 0.01
p.minZoom = 0.01;
// 表示星球不可访问
p.accessible = false;
// 向 "p" 对象的 "sectors" 集合添加一个新的 "Sector" 对象，参数为 "p" 和新创建的 "PlanetGrid.Ptile(0, 0)"
p.sectors.add(new Sector(p, new PlanetGrid.Ptile(0, 0)));
// 设置 "p" 对象的生成器为新创建的 "AsteroidGenerator" 对象
p.generator = new AsteroidGenerator();

// 定义 "p" 对象的 "meshLoader" 函数
p.meshLoader = () => {
    // 创建一个新的 "Seq" 对象来存储网格
    let meshes = new Seq();
    // 获取 "p" 对象的色调对应的颜色映射
    let tinted = p.tint.mapColor;
    // 获取 "p" 对象的基础对应的颜色映射
    let color = p.base.mapColor;
    // 创建一个基于 "p" 对象的 ID 加 2 的随机数生成器
    let rand = new Rand(p.id + 2);

    // 循环生成陨石网格，循环次数为陨石的数量
    for (let j = 0; j < p.pieces; j++) {
        // 创建一个新的二维向量 "v2"
        let v2 = new Vec2();
        // 将 "v2" 设置为随机方向，并设置长度在 0.7 到 1.3 之间的随机值
        v2.setToRandomDirection().setLength(rand.random(0.7, 1.3));  // 表示宽度
        // 创建另一个二维向量 "v22"，其 y 坐标为 "v2" 的 y 坐标，x 坐标为 -0.1 到 0.1 之间的随机值
        let v22 = new Vec2(v2.y, rand.random(-0.1, 0.1)); 
        // 将 "v22" 旋转 60 度  // 表示倾斜角度
        v22.rotate(0); 
        // 向 "meshes" 中添加一个新的 "MatMesh" 对象
        meshes.add(new MatMesh(
            // 创建一个 "NoiseMesh" 对象，传入相关参数
            new NoiseMesh(p, j + 1, 1, 0.022 + rand.random(0.039) * p.scale, 2, 0.6, 0.38, 20, color, tinted, 3, 0.6, 0.38, p.tintThresh),
            // 创建一个 "Mat3D" 对象并设置其平移值，基于 "v2" 和 "v22" 的坐标并乘以 5 来确定整体大小
            new Mat3D().setToTranslation(new Vec3(v2.x, v22.x, v22.y).scl(5)) 
        ));
    };

    // 返回一个新的 "JavaAdapter" 对象，用于处理网格的渲染
    return new JavaAdapter(GenericMesh, {
        // 将 "meshes" 转换为数组并设置为 "meshes" 属性
        meshes: meshes.toArray(),
        // 定义渲染函数
        render(params, projection, transform) {
            // 遍历 "meshes" 中的每个网格并进行渲染
            for (let v of this.meshes) {
                v.render(params, projection, transform);
            }
        }
    });
};
