
(() => {
var time = 300;
var dps = 0, array = [];

let dps测试 = extend(Block, 'dps测试', {});

let display = {};

dps测试.buildType = prov(() => extend(Building, {
	dps:display,
	dpsLoad(){
		this.dps = display = extend(Table, {
			damage:null, dps:null
		})
		this.dps.left().defaults().left();
		this.dps.update(run(() => {
			this.dps.color.a = Vars.state.isMenu() || ++time > 300 ? 0 : 1;
		}));
		this.dps.touchable = Touchable.disabled;
		this.dps.setFillParent(true);
		this.dps.table(Styles.black5, cons(t => {
			t.defaults().left();
			this.dps.damage = t.add('').get();
			t.row();
			this.dps.dps = t.add('', Color.orange).get();
		}));
		Core.scene.add(this.dps);
	},
	updateTile(){
		if(!(display instanceof Table)) this.dpsLoad();
		if(this.team.id != 3) this.team = Team.get(3);
		array.push(dps);
		if(array.length > 60) array.splice(0, 1);
		dps = 0;
		let t = array.reduce((pre, cur) => pre + cur);
		display.dps.setText(' dps:' + t.toFixed(1));
		t ? time = 0 : '';
	},
	damage(a, b){
		if (typeof a == "object" && typeof b == "number") a = b;
		if (a == 0) return;
		display.damage.setText(' 伤害:' + a.toFixed(1));
		time = 0;
		dps += isNaN(a) ? 0 : a;
	},
	onDeath(){this.damage(Infinity);},
	remove(){this.damage(Infinity);}
}));

dps测试.size = 2;
dps测试.health = 100000;
dps测试.update = true;
dps测试.localizedName = 'dps测试';
dps测试.category = Category.effect;
dps测试.buildVisibility = BuildVisibility.shown;

})()