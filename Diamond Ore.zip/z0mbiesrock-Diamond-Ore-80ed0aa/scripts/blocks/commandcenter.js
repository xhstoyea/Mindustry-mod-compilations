const reCC = extend(CommandCenter, "reinforced-command-center", {
});
reCC.flags = EnumSet.of(BlockFlag.rally);