require('js');//地图全开
require('js2');//缩放
require('js3');//服务器
Blocks.coreShard.requirements = ItemStack.with();
require('js4');//对话框
MapResizeDialog.minSize = 0;
MapResizeDialog.maxSize = 10001;
