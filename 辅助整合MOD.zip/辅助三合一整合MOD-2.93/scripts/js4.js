Events.on(EventType.ClientLoadEvent, cons(e => {

    Vars.ui.settings = new SettingsMenuDialog();

    var dialog = new JavaAdapter(BaseDialog, {}, "辅助整合MOD");
    dialog.shown(run(() => {
        dialog.cont.table(Tex.button, cons(t => {
            t.defaults().size(280, 60).left();
            t.button("关闭", Icon.trash, Styles.cleart, run(() => {
                dialog.hide();
            }));
            t.add("本辅助mod整合了\n缩放加强\n汉译蓝图\n中国服务器大厅(微泽)\n星球随机地图全开");
        }));
    }));

    dialog.show();
}))