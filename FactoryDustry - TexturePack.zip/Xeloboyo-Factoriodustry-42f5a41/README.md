# Pixel Texturepack Mindustry
A texturepack for mindustry, <h2><b>currently in dev, there are missing things</b></h2>

Access Trello:
https://trello.com/invite/b/4OhnrdkU/26bae77d18289eeeefaa080ef7611dab/texturepack-todolist

![d263](https://user-images.githubusercontent.com/13158938/149653710-5c1e34f7-9cd3-4577-95ca-cc3d66a14c9f.gif)
<a href="https://ibb.co/zPsDPmY"><img src="https://i.ibb.co/mhJghRw/image.png" alt="image" border="0"></a>
<a href="https://ibb.co/BqQ23TD"><img src="https://i.ibb.co/t8vpKYf/image.png" alt="image" border="0"></a>
<a href="https://ibb.co/nzDcpCY"><img src="https://i.ibb.co/J5z7ZQG/image.png" alt="image" border="0"></a>
<a href="https://ibb.co/TWB45Pc"><img src="https://i.ibb.co/g4MSCty/image.png" alt="image" border="0"></a>\

Credit to Vozduh for some of the of the sprites <3

