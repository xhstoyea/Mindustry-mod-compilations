Events.on(EventType.ClientLoadEvent, cons(e => {
	const dialog = new BaseDialog(Core.bundle.get("report"));

	dialog.buttons.button("@close", run(() => {
		dialog.hide();
	})).size(210, 64);
	dialog.buttons.button(Core.bundle.get("list"), run(() => {
		const list = new BaseDialog(Core.bundle.get("list"));
		
		list.buttons.button("@close", run(() => {
		    dialog.hide();
		    list.hide();
	    })).size(210, 64);
	    
	    list.cont.pane(table => {
	        table.add(Core.bundle.get("list.code")).left().growX().wrap().width(420).maxWidth(420).pad(4).labelAlign(Align.left).row();
	        table.add(Core.bundle.get("list.sprites")).left().growX().wrap().width(420).maxWidth(420).pad(4).labelAlign(Align.left).row();
	        table.add(Core.bundle.get("list.idea")).left().growX().wrap().width(420).maxWidth(420).pad(4).labelAlign(Align.left).row();
	    })
	    
	    list.show()
	    
	})).size(210, 64);
	
	dialog.cont.pane(table => {
		table.image(Core.atlas.find("sun-sun")).size(284,284).pad(3).row();
		
		table.add(Core.bundle.get("report.sub")).left().growX().wrap().width(420).maxWidth(420).pad(4).labelAlign(Align.left).row();
	})
	dialog.show()
}))