const light = new UnitType("日光");
exports.light = light;
Object.assign(light,{
	constructor: () => new UnitEntity.create(),
	shadowElevation: 0.1,
	useEngineElevation: false,
	groundLayer: 81,
	controller: UnitTypes.flare.controller,
})
light.abilities.add(
	Object.assign(new MoveEffectAbility(), {
	x: 0,
	y: -5,
	teamColor: true,
	effect: Fx.missileTrailShort,
	interval: 3,
	effectParam: 3,
	}),
);

light.parts.add(
Object.assign(new HoverPart(),{
	x: 0,
	y: -0.5,
	mirror: false,
	radius: 12,
	phase: 60,
	stroke: 3,
	circles: 3,
	layerOffset: -0.001,
	color: Color.valueOf("FFCD66"),
}),
);