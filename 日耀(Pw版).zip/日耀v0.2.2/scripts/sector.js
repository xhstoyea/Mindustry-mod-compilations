const lib = require("sectorSize");
const core = require("block/core");

lib.planetGrid(Planets.sun, 2);
Planets.sun.alwaysUnlocked = true;
Planets.sun.radius = 1.125;
Planets.sun.camRadius = -0.25;
Planets.sun.accessible = true;
Planets.sun.allowLaunchLoadout = true;
Planets.sun.allowLaunchSchematics = true;
Planets.sun.clearSectorOnLose = true;
Planets.sun.launchCapacityMultiplier = 0.8;
Planets.sun.defaultCore = core.floater;
Planets.sun.generator = extend(SerpuloPlanetGenerator,{
    allowLanding(sector){return false},
    getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgYmBiZmDJS8xNZWBJzi9KZeBOSS1OLsosKMnMz2NgYGDLSUxKzSlmYIqOZWTgLi7N003LyU8sSS0CyjEyQAAAQ6YPuQ==");
	 }
});
Planets.sun.iconColor = Color.valueOf("ff9966");
Planets.sun.hiddenItems = new Seq.with(
	Items.scrap,
	Items.copper,
	Items.lead,
	Items.titanium,
	Items.thorium,
	Items.plastanium,
	Items.phaseFabric,
	Items.sporePod,
	Items.sand,
	Items.blastCompound,
	Items.pyratite,
	Items.metaglass,
	Items.beryllium,
	Items.oxide,
	Items.carbide,
	Items.fissileMatter,
	Items.dormantCyst
);

const 试验区 = new SectorPreset("试验区",Planets.sun,0);
exports.试验区 = 试验区;
Object.assign(试验区,{
	captureWave: 10,
	difficulty: 2,
	addStartingItems: true,
	alwaysUnlocked: true,
	startWaveTimeMultiplier: 3,
});

const sector1 = new SectorPreset("sector1",Planets.sun,1)
exports.sector1 = sector1;
Object.assign(sector1,{
    captureWave: 20,
	difficulty: 4,
	startWaveTimeMultiplier: 4,
})

const 黑石城 = new SectorPreset("黑石城",Planets.sun,2);
exports.黑石城 = 黑石城;
Object.assign(黑石城,{
    captureWave: 0,
	difficulty: 7,
	startWaveTimeMultiplier: 4,
})