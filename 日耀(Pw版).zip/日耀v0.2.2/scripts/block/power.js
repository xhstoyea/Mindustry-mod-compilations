const item = require("item");
const env = require("block/environment");

Attribute.add("slag");

env.slag.attributes.set(Attribute.get("slag"), 2.5 / 4);
Blocks.slag.attributes.set(Attribute.get("slag"), 1 / 4);

const generator = new ThermalGenerator("矿渣发电机")
exports.generator = generator;
Object.assign(generator,{
    powerProduction: 2.1,
    attribute: Attribute.get("slag"),
    generateEffect: Fx.redgeneratespark,
    effectChance: 0.011,
    size: 2,
    floating: true,
    ambientSound: Sounds.hum,
    ambientSoundVolume: 0.06,
    buildVisibility: BuildVisibility.shown,
	category: Category.power,
	requirements: ItemStack.with(
		item.obsidian, 75,
		Items.silicon, 25,
	)
})