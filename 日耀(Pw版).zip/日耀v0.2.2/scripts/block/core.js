const item = require("item");
const env = require("block/environment")

UnitTypes.alpha.itemCapacity = 200;

const floater = extend(CoreBlock,"floater",{
	canPlaceOn(tile,team,rotation){
	    return Vars.state.teams.cores(tile.team()).size < 5
	}
});
exports.floater = floater;
Object.assign(floater,{
	health: 2500,
	size: 2,
	alwaysUnlocked: true,
	armor: 1,
	itemCapacity: 3500,
	unitType: UnitTypes.evoke,
	
	unitCapModifier: 15,
	
	replaceable: true,
	floating: true,
	placeableLiquid: true,
	
	buildVisibility: BuildVisibility.shown,
	category: Category.effect,
	requirements: ItemStack.with(
		item.obsidian, 1000,
		Items.silicon, 300,
	)
})

const floater2 = new CoreBlock("floater2");
exports.floater2 = floater2;
Object.assign(floater2,{
    health: 3750,
	size: 3,
	armor: 2,
	itemCapacity: 4500,
	unitType: UnitTypes.evoke,
	
	unitCapModifier: 15,
	
	replaceable: true,
	floating: true,
	placeableLiquid: true,
	
	buildVisibility: BuildVisibility.shown,
	category: Category.effect,
	requirements: ItemStack.with(
		item.obsidian, 2000,
		Items.silicon, 2500,
		item.diamond, 1000
	)
})

const floater3 = new CoreBlock("floater3");
exports.floater3 = floater3;
Object.assign(floater3,{
    health: 4275,
	size: 4,
	armor: 4,
	itemCapacity: 6000,
	unitType: UnitTypes.evoke,
	
	unitCapModifier: 15,
	
	replaceable: true,
	floating: true,
	placeableLiquid: true,
	
	buildVisibility: BuildVisibility.shown,
	category: Category.effect,
	requirements: ItemStack.with(
		item.obsidian, 3500,
		Items.silicon, 4500,
		item.diamond, 2000,
		item.carbon, 2500,
		item.combinedSteel, 1500,
	)
})

const floor = Object.assign(new Floor("floor"),{
	variants: 2,
})
exports.floor = floor;

const plate = new Block("plate");
exports.plate = plate;
Object.assign(plate,{
	update: true,
	floating: true,
	placeableLiquid: true,
	createRubble: false,
	rebuildable: false,
	alwaysUnlocked: true,
	breakSound: Sounds.none,
	buildVisibility: BuildVisibility.shown,
	category: Category.effect,
	requirements: ItemStack.with(
		item.obsidian, 1,
	)
})
plate.buildType = prov(() => extend(Building,{
	updateTile(){
		this.tile.circle(15.5, cons(tile => {
			if(tile.block() === floater){
				this.tile.setFloor(floor);
			}
		}))
		this.tile.circle(20.5, cons(tile => {
			if(tile.block() === floater2){
				this.tile.setFloor(floor);
			}
		}))
		this.tile.circle(35.5, cons(tile => {
			if(tile.block() === floater3){
				this.tile.setFloor(floor);
			}
		}))
		this.tile.setAir();
	}
}))

const column = new Block("column");
Object.assign(column,{
    buildVisibility: BuildVisibility.shown,
    category: Category.effect,
    update: true,
    alwaysUnlocked: true,
})

column.buildType = prov(() => extend(Building,{
    i:0,
    updateTile(){
        this.i += Time.delta
    
        if(this.i >= 3 * 60){
            this.tile.circle(5, cons(tile => {
                if(tile.block() == Blocks.coreShard){
                    tile.setBlock(floater,this.team);
                }
            }))
            this.tile.setAir();
        }
    }
}))