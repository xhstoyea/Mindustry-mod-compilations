const item = require("item");
const liquid = require("liquid");

const flintOre = new StaticWall("flint-ore");
Object.assign(flintOre,{
    variants: 0,
	itemDrop: item.flint,
})

const slag = new Floor("slag-floor")
exports.slag = slag
Object.assign(slag,{
    drownTime: 230,
    status: StatusEffects.melting,
    statusDuration: 240,
    speedMultiplier: 0.19,
    variants: 0,
    liquidDrop: liquid.slag,
    isLiquid: true,
    cacheLayer: CacheLayer.slag,

    emitLight: true,
    lightRadius: 40,
    lightColor: Color.valueOf("f0511d66"),
})
slag.attributes.set(Attribute.heat, 0.8);