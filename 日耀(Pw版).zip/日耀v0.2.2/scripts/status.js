const parasitism = new StatusEffect("寄生")
exports.parasitism = parasitism;
Object.assign(parasitism,{
	color: Color.valueOf("1cdeff"),
	effect: Fx.mineSmall,
	damageMultiplier: 0.95,
	healthMultiplier: 0.45,
	reloadMultiplier: 1.25,
	speedMultiplier: 1.1,
	damage: 5,
	permanent: true,
})

const slowII = new StatusEffect("缓慢II")
exports.slowII = slowII;
Object.assign(slowII,{
	color: Color.valueOf("646464"),
	effect: Fx.mineSmall,
	speedMultiplier: 0.1,
	permanent: false,
})