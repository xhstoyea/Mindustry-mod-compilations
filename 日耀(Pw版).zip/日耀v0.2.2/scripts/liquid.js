const steam = new Liquid("蒸汽",Color.valueOf("596ab87f"))
exports.steam = steam;
Object.assign(steam,{
	gas: true,
	temperature: 1,
})

const Hydrogenperoxide = new Liquid("联氢",Color.valueOf("596ab87f"))
exports.Hydrogenperoxide = Hydrogenperoxide;
Object.assign(Hydrogenperoxide,{
	gas: true,
	temperature: 1,
})
const carbonDioxide = new Liquid("二氧化碳",Color.valueOf("ffffff"));
exports.carbonDioxide = carbonDioxide;
Object.assign(carbonDioxide,{
    gas: true,
})

const slag = new Liquid("矿渣",Color.valueOf("ff9966"));
exports.slag = slag
Object.assign(slag,{
    temperature: 1,
    viscosity: 0.7,
    effect: StatusEffects.melting,
    lightColor: Color.valueOf("f0511d66"),
})