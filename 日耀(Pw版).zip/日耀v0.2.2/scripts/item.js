const obsidian = new Item("黑曜石",Color.valueOf("404040"));
exports.obsidian = obsidian;
Object.assign(obsidian,{
	cost: 1.5,
	healthScaling: 0.5,
	flammability: 0.1,
})

const flint = new Item("炎岩",Color.valueOf("feae34"));
exports.flint = flint;
Object.assign(flint,{
	flammability: 2,
})

const powder = new Item("粉末",Color.valueOf("404040"));
exports.powder = powder;

const organics = new Item("有机质",Color.valueOf("ad2121"));
exports.organics = organics;
Object.assign(organics,{
    flammability: 1.7,
})

const biomass = new Item("生物质",Color.valueOf("32ad21"));
exports.biomass = biomass;
Object.assign(biomass,{
    flammability: 2.2,
    cost: 1,
})

const fungus = new Item("真菌",Color.valueOf("68386c"));
exports.fungus = fungus;
Object.assign(fungus,{
	buildable: false,
})

const crystal = new Item("结晶体",Color.valueOf("60496d"));
exports.crystal = crystal;

const carbon = new Item("碳",Color.valueOf("333333"));
exports.carbon = carbon;

const calcium = new Item("钙",Color.valueOf("ffffff"));
exports.calcium = calcium;

const diamond = new Item("金刚石",Color.valueOf("07d3e1"));
exports.diamond = diamond;

const combinedSteel = new Item("化合钢",Color.valueOf("07e03a"));
exports.combinedSteel = combinedSteel;

const nuclearore = new Item("核原矿",Color.valueOf("07e03a"));
exports.nuclearore = nuclearore;

const Fusionmaterial = new Item("聚变物",Color.valueOf("07e03a"));
exports.Fusionmaterial = Fusionmaterial;

const fissionproduct = new Item("裂变物",Color.valueOf("07e03a"));
exports.fissionproduct = fissionproduct;

const Decaysubstance = new Item("衰变物",Color.valueOf("07e03a"));
exports.Decaysubstance = Decaysubstance;

const Integratednuclearmaterials = new Item("整合核料",Color.valueOf("07e03a"));
exports.Integratednuclearmaterials = Integratednuclearmaterials;

const atom = new Item("原子",Color.valueOf("07e03a"));
exports.atom = atom;

const electron = new Item("电子",Color.valueOf("07e03a"));
exports.electron = electron;

const Atomicnucleus = new Item("原子核",Color.valueOf("07e03a"));
exports.Atomicnucleus = Atomicnucleus;

const proton = new Item("质子",Color.valueOf("07e03a"));
exports.proton = proton;

const neutron = new Item("中子",Color.valueOf("07e03a"));
exports.neutron = neutron;

const Protoncluster = new Item("质子集群",Color.valueOf("07e03a"));
exports.Protoncluster = Protoncluster;

const Neutroncluster = new Item("中子集群",Color.valueOf("07e03a"));
exports.Neutroncluster = Neutroncluster;

const Darkneutrinonucleus = new Item("暗微子核",Color.valueOf("07e03a"));
exports.Darkneutrinonucleus = Darkneutrinonucleus;

const Darkneutrino = new Item("暗微子",Color.valueOf("07e03a"));
exports.Darkneutrino = Darkneutrino;

const Darkmatter = new Item("暗物质",Color.valueOf("07e03a"));
exports.Darkmatter = Darkmatter;

const electroplatedSteel = Item("电镀钢",Color.valueOf("1b77ef"));
Object.assign(electroplatedSteel,{
    frames:25,
	transitionFrames:1,
	frameTime:2,
})
exports.electroplatedSteel = electroplatedSteel;