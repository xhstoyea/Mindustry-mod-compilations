const nodeRoot = TechTree.nodeRoot;
const nodeProduce = TechTree.nodeProduce
const node = TechTree.node;
const SectorComplete = Objectives.SectorComplete;

const core = require("block/core");
const power = require("block/power");

const item = require("item");
const liquid = require("liquid");
const sector = require("sector");

Planets.sun.techTree = nodeRoot("sun", core.floater, () => {
	node(core.plate, () => {}),
	nodeProduce(Liquids.slag, () => {
        nodeProduce(item.obsidian, () => {
            nodeProduce(item.flint, () => {}),
    	    nodeProduce(item.powder, () => {
    	        nodeProduce(item.organics, () => {
    	            nodeProduce(item.biomass, () => {
    	                nodeProduce(item.fungus, () => {
    	                    nodeProduce(Liquids.oil, () => {
    	                        nodeProduce(item.crystal, () => {
    	                            nodeProduce(item.carbon, () => {
    		                            nodeProduce(item.diamond, () => {}),
    		                            nodeProduce(liquid.carbonDioxide, () => {})
    		                        }),
    		                        nodeProduce(item.calcium, () => {})
    	                        })
    	                    })
    	                })
    	            })
    	        })
    	    }),
    	    nodeProduce(Liquids.water,() => {
    	        nodeProduce(Liquids.ozone,() => {}),
    	        nodeProduce(Liquids.hydrogen,() => {})
    	    })
    	}),
    	nodeProduce(liquid.slag, () => {}),
    	nodeProduce(Items.tungsten, () => {
    	    nodeProduce(Items.surgeAlloy, () => {
    	        nodeProduce(item.combinedSteel,() => {}),
    	        nodeProduce(item.electroplatedSteel, () => {})
    	    })
    	})
	}),
	node(sector.试验区, () => {
	    node(sector.sector1,Seq.with(
	        new SectorComplete(sector.试验区)
	    ),() => {
	        node(sector.黑石城,Seq.with(
	            new SectorComplete(sector.sector1)
	        ),() => {})
	    })
	}),
	node(power.generator, () => {}),
	node(core.floater2,() => {
	    node(core.floater3,() => {})
	})
})