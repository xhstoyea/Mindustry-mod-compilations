const lib = require("前置/coflib");
let range = 3;

let 矿物生成器装置 = lib.newBlock("炸矿机", {});
lib.setBuilding(Building, 矿物生成器装置, {
	buildConfiguration(table) {
		let amount = 0, num = 3;
		Vars.content.blocks().each(block => {
			if (block instanceof OreBlock && !block.wallOre) {
				table.button(Core.atlas.drawable(block.itemDrop.uiIcon), Styles.cleari, run(() => {
					this.tile.circle(range, cons(tile => {
						tile.setOverlay(block)
					}));
					this.kill();
				})).size(45);
				amount++;
				if (amount % num == 0) table.row()
			}
		})
	}
})
Object.assign(炸矿机, {
	size: 1,
	health: 100,
	rotate: true,
	configurable: false
});
矿物生成器装置.alwaysUnlocked = true,
矿物生成器装置.buildVisibility = BuildVisibility.shown;
炸矿机.requirements = ItemStack.with(
	my.贤者之石, 25,
	my.物质, 1,
);
