const lib = require("前置/coflib");
const blood = require("特种/含护盾物质建筑");

function HighWall(name, con) {
	const b = extend(Wall, name, con);
	b.update = true;
	b.category = Category.defense;
	//b.buildVisibility = BuildVisibility.sandboxOnly;
	let size = b.size * 0.6;
	lib.setBuilding(Wall.WallBuild, b, {
		updateTile() {
			this.super$updateTile();
			/*Groups.bullet.intersect(this.x - size, this.y - size, size * 8, size * 8, b => {
				if (b.team != this.team) {
					b.absorb();
					this.damage(b.type.damage + b.type.splashDamage / 2);
				}
			})*/
			Units.nearbyEnemies(this.team, this.x, this.y, size * 8, u => {
				let ang = Angles.angle(this.x, this.y, u.x, u.y),
					vec = new Vec2();
				vec.trns(ang, 1);
				u.vel.add(vec);
			})
		}
	})
	return b
}

const hw = HighWall("高墙", {});
hw.health = 400

const hwl = HighWall("高墙大", {});
hwl.health = 1600
hwl.size = 2