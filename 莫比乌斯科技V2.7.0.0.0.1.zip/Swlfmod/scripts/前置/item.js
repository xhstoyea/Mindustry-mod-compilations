function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("速度物质")
newItem("护盾物质")
newItem("构筑物质")
newItem("阴影合金")
newItem("莫比乌斯合金")
newItem("莫比乌斯燃料")
newItem("贤者之石")
newItem("错误物质")
newItem("传颂之物")
newItem("物质")
