const lib = require("前置/coflib");
let node = TechTree.node;
let Research = Objectives.Research;
let nodeProduce = TechTree.nodeProduce;
let SectorComplete = Objectives.SectorComplete;

const { sf } = require("特种/炸矿机");


lib.addResearch(sf, { parent: "shock-mine", });

/*
let 舰载机 = new UnitType("舰载机");
舰载机.constructor = () => extend(UnitEntity, {});
舰载机.alwaysUnlocked = true;
TechTree.nodeRoot("诅咒科技", 舰载机, () => {
	node(核心卸载器);
	node(核心装载器, () => {
		node(核心装卸器, () => {
			node(资源卸载器)
			node(资源装载器)
		})
	});
	node(液体装卸器);
})

function Treenode(Parent, block, requirements, objectives) {
	let parent = TechTree.all.find(node => node.content == Parent);
	let node = new TechTree.TechNode(parent, block, requirements);
	node.objectives.addAll(objectives);
}

Treenode(前置, 当前方块,
	ItemStack.with(
		Items.copper, 20,
		Items.lead, 30
	),
	Seq.with(
		new Research(物品/方块前置),
		new SectorComplete(地图前置)
	)
);*/