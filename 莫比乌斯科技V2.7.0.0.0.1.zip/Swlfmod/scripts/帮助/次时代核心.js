//xvx神魂
//本代码可以塞在任意方块里
//比如墙又或者传送带，又或者核心
//只要这个方块可以刷新，就可以塞并且有效果

//感谢神魂（来自年年有鱼）
const 哭鬼 = extend(ItemTurret, "哭鬼", {});

const 核心构筑塔 = extend(BuildTurret, "核心构筑塔", {});


const myitems = require("前置/item");


const 次时代核心 = extend(CoreBlock, "次时代核心", {
	canReplace(other) {
		return true;
	}
	});


次时代核心.buildVisibility = BuildVisibility.shown;
次时代核心.category = Category.logic;

//这是必需的
次时代核心.update = true;
//设置方块可使用物品
次时代核心.hasItems = true;

//设置可使用的弹药
const TItems = [myitems.阴影合金]

次时代核心.buildType = prov(() => {
	//创建多炮塔
	//(方块，队伍(不需要设置))
	const payloads = [
		new BuildPayload(哭鬼, Team.derelict),
		new BuildPayload(核心构筑塔, Team.derelict),
	];
	const build = extend(CoreBlock.CoreBuild, 次时代核心, {
		updateTile() {
			this.super$updateTile();

			//可以让炮塔转起来的代码
			//删除注释以使用
			/*for (var i = 0; i < payloads.length; i++) {
                var t = payloads[i];
                var rotation = (360.0 / payloads.length) * i + Time.time;

				//这里的24为距离本体方块中心的多少距离旋转(8为1格)
                t.set(x + Angles.trnsx(rotation, 24), y + Angles.trnsy(rotation, 24), t.build.payloadRotation);
            }*/

			//设置模块
		
			for(var id = 0; id < payloads.length; id++){
				//设置队伍，如果在上面的创建位置设置，无用
                if(payloads[id].build.team != this.team){
                    payloads[id].build.team = this.team;
                }
				
				//执行炮塔更新
                payloads[id].update(null, this);

				//为物品炮塔添加弹药
				//你们需要可自己定义
				for(var i = 0; i < TItems.length; i++){
					if(payloads[id].build.acceptItem(payloads[id].build, TItems[i]) && this.items.get(TItems[i]) >= 1) {
						payloads[id].build.handleItem(payloads[id].build, TItems[i]);
						this.items.remove(TItems[i], 1);
					}
				}
            }

			//设置炮塔的位置
			//有需求你们可以自己定义
			//（x, y, r）
			payloads[0].set(this.x + 0, this.y + 0, payloads[0].build.payloadRotation);
			payloads[1].set(this.x + 16, this.y + 16, payloads[1].build.payloadRotation);
					
		},
		draw(){
			this.super$draw();

			//执行多炮塔的动画
			for(var i = 0; i < payloads.length; i++){
                payloads[i].draw();
            }
		},
	});

	return build;
});