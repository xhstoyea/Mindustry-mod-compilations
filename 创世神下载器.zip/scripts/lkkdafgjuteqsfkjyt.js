let https222 = "http://sd674971336.ysepan.com"
let https333 = "https://github.com/no9527dada/CT-origin/releases"
let https111 = "https://jq.qq.com/?_wv=1027&k=oygqLbJ5";
Events.on(EventType.ClientLoadEvent, cons(e => {
    var kaiping = new BaseDialog('创世神mod更新器');
    kaiping.cont.pane((() => {

        var table = new Table();
        table.add('谢谢使用创世神mod更新器\n点击下方按钮进行下载\n加载创世神后可以禁用本MOD').left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();

    table.button(Core.bundle.format("9527http222"), run(() => {
    if (!Core.app.openURI(https222)) {
        Vars.ui.showErrorMessage("@linkfail");
        Core.app.setClipboardText(https222);
    }
})).size(510, 64);
table.row();
table.button(Core.bundle.format("9527http333"), run(() => {
    if (!Core.app.openURI(https333)) {
        Vars.ui.showErrorMessage("@linkfail");
        Core.app.setClipboardText(https222);
    }
})).size(510, 64).row();
table.button(Core.bundle.format("9527http111"), run(() => {
    if (!Core.app.openURI(https333)) {
        Vars.ui.showErrorMessage("@linkfail");
        Core.app.setClipboardText(https111);
    }
})).size(510, 64).row();
return table;
})()).grow().center().maxWidth(770);
kaiping.addCloseListener();//按esc关闭
kaiping.buttons.button("@close", run(() => {
    kaiping.hide();
})).size(100, 64);
kaiping.show();
}));
