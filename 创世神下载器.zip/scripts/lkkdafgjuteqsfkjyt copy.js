let https222 = "http://sd674971336.ysepan.com"
Events.on(EventType.ClientLoadEvent, cons(e => {
    var kaiping = new BaseDialog('下载器');
    kaiping.cont.pane((() => {

        var table = new Table();
        table.add(Core.bundle.format("independent_txt")).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();

    table.button(Core.bundle.format("9527http"), run(() => {
    if (!Core.app.openURI(https222)) {
        Vars.ui.showErrorMessage("@linkfail");
        Core.app.setClipboardText(https222);
    }
})).size(210, 64);
table.row();


return table;
})()).grow().center().maxWidth(770);
kaiping.addCloseListener();//按esc关闭
kaiping.buttons.button("@close", run(() => {
    kaiping.hide();
})).size(100, 64);
kaiping.show();
}));
