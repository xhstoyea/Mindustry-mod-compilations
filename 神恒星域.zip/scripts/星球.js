const lib = require("blib"); // 引入一个名为"lib"的模块
const dsdplanets = DSDPlanets;
const 埃维加斯 = new Planet("埃维加斯", dsdplanets.dsdsun, 1, 2.1);
// 创建一个行星。
// 它位于，半径，距离。

埃维加斯.meshLoader = prov(() => new MultiMesh(
    new HexMesh(埃维加斯, 5)
));
// 设置行星"-埃里克尔"的网格加载器，使用HexMesh创建一个六边形网格。

埃维加斯.generator = extend(ErekirPlanetGenerator, {
    getDefaultLoadout() {
        return Schematics.readBase64("bXNjaAF4nGNgYWBhZmDJS8xNZeB5Or/v6YKFzxbseLq/mYE7JbU4uSizoCQzP4+BgYEtJzEpNaeYgSk6lpGBJzm/KFU3KbEYKskIQkACAAynFxI=");
    }
});
// 设置行星的生成器，并扩展自ErekirPlanetGenerator。
// 定义了getDefaultLoadout()方法，返回一个经Base64编码的字符串作为默认装备。
 埃维加斯.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(埃维加斯, 2, 0.15, 0.14, 5, Color.valueOf("C09854FF"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(埃维加斯, 3, 0.6, 0.15, 5, Color.valueOf("D4B98AFF"), 2, 0.42, 1.2, 0.45)
));
 
 
// 设置行星的云层网格加载器，使用HexSkyMesh创建两个云层。

埃维加斯.visible = 埃维加斯.accessible = 埃维加斯.alwaysUnlocked = true;
// 将行星设置为可见、可访问和始终解锁。

埃维加斯.clearSectorOnLose = true;
// 设置行星在失败时是否重置区块。

埃维加斯.tidalLock = false;
// 设置行星是否有潮汐锁定。
埃维加斯.prebuildBase = true;
//埃维加斯.prebuildBase: true, // 是否需要像e星那样帅气的着陆建筑特效
埃维加斯.defaultAttributes.set(Attribute.heat, 0.8);
// 设置行星的默认热量属性为0.8。

埃维加斯.updateLighting = false;
// 设置行星的光照更新为关闭。

埃维加斯.lightSrcTo = 0.2;
埃维加斯.lightDstFrom = 0.1;
// 设置行星的光源参数。
埃维加斯.allowLaunchToNumbered = false;//是否允许数字区块发射

埃维加斯.defaultEnv = Env.scorching | Env.terrestrial;
// 设置行星的默认环境类型为scorching和terrestrial。

埃维加斯.defaultCore = Blocks.coreBastion;
// 设置行星的默认核心方块类型为coreBastion。

埃维加斯.localizedName = "埃维加斯";
// 设置行星"MEE-埃里克尔"的本地化名称。

//埃维加斯.prebuildBase = false;
// 设置行星是否有预建基地。

埃维加斯.bloom = false;
// 设置行星是否使用泛光效果。

埃维加斯.startSector = 20;
// 设置行星的起始区块。

埃维加斯.orbitRadius = 24;
// 设置行星的轨道半径为。

埃维加斯.atmosphereRadIn = 0.02;
埃维加斯.atmosphereRadOut = 0.3;
// 设置行星的大气层的内外半径。

埃维加斯.atmosphereColor = 埃维加斯.lightColor = Color.valueOf("E6881CFF");
// 设置行星的大气层和光照颜色。

埃维加斯.iconColor = Color.valueOf("E6881CFF"),
// 设置行星的图标颜色。

埃维加斯.hiddenItems.addAll(Items.serpuloItems).removeAll(Items.erekirItems);
// 将serpuloItems添加到行星的隐藏物品列表，并移除erekirI

const 碳岩裂谷 = new SectorPreset("碳岩裂谷",埃维加斯, 20);
碳岩裂谷.alwaysUnlocked = false;//默认解锁此区块
碳岩裂谷.difficulty = 5;//难度
//碳岩裂谷.captureWave = 0;//敌人波数
碳岩裂谷.description = "探测敌方建筑，发起进攻。";//统计资料顶上的简介
碳岩裂谷.localizedName = "碳岩裂谷";//区块名
lib.addToResearch(碳岩裂谷, {
        parent: Blocks.coreBastion,
        /*objectives: Seq.with(
            new Objectives.SectorComplete(map1),
        ),*/
    });
exports.碳岩裂谷 = 碳岩裂谷//地图排序

const  黄石裂隙= new SectorPreset("黄石裂隙",埃维加斯, 26);
黄石裂隙.alwaysUnlocked = false;//默认解锁此区块
黄石裂隙.difficulty = 4;//难度
黄石裂隙.captureWave = 45;//敌人波数
黄石裂隙.description = "雷达检测到该区块未有敌方核心，但敌人数量居多。做好防御";//统计资料顶上的简介
黄石裂隙.localizedName = "黄石裂隙";//区块名
lib.addToResearch(黄石裂隙, {
        parent: 碳岩裂谷,
        objectives: Seq.with(
            new Objectives.SectorComplete(碳岩裂谷),
        ),
    });
exports.黄石裂隙 = 黄石裂隙//地图排序            
const  破裂碎山= new SectorPreset("破裂碎山",埃维加斯, 72);
破裂碎山.alwaysUnlocked = false;//默认解锁此区块
破裂碎山.difficulty = 5;//难度
//破裂碎山.captureWave = 20;//敌人波数
破裂碎山.description = "该区块资源分布多个大小岛屿上，并且敌人的出兵很快来袭。尽快做好防御进攻";//统计资料顶上的简介
破裂碎山.localizedName = "破裂碎山";//区块名
lib.addToResearch(破裂碎山, {
        parent: 黄石裂隙,
        objectives: Seq.with(
            new Objectives.SectorComplete(黄石裂隙),
        ),
    });
exports. 破裂碎山 = 破裂碎山//地图排序            
const  碳晶裂谷= new SectorPreset("碳晶裂谷",埃维加斯, 35);
碳晶裂谷.alwaysUnlocked = false;//默认解锁此区块
碳晶裂谷.difficulty = 3;//难度
//破裂碎山.captureWave = 20;//敌人波数
碳晶裂谷.description = "该区块敌方基地分布在多个空间，同时解锁新的建筑。";//统计资料顶上的简介
碳晶裂谷.localizedName = "碳晶裂谷";//区块名
lib.addToResearch(碳晶裂谷, {
        parent: 破裂碎山,
        objectives: Seq.with(
            new Objectives.SectorComplete(破裂碎山),
        ),
    });
exports. 碳晶裂谷 = 碳晶裂谷//地图排序

const  芳石峡谷= new SectorPreset("芳石峡谷",埃维加斯, 78);
芳石峡谷.alwaysUnlocked = false;//默认解锁此区块
芳石峡谷.difficulty = 6;//难度
//破裂碎山.captureWave = 20;//敌人波数
芳石峡谷.description = "该地图敌方基地有大型导弹塔，敌方会出大量的兵。做好防御进攻";//统计资料顶上的简介
芳石峡谷.localizedName = "芳石峡谷";//区块名
lib.addToResearch(芳石峡谷, {
        parent: 破裂碎山,
        objectives: Seq.with(
            new Objectives.SectorComplete(碳晶裂谷),
        ),
    });
exports. 芳石峡谷= 芳石峡谷//地图排序

const 风蚀山谷 = new SectorPreset("风蚀山谷",埃维加斯, 3);
风蚀山谷.alwaysUnlocked = false;//默认解锁此区块
风蚀山谷.difficulty = 6;//难度
风蚀山谷.captureWave = 12;//敌人波数
风蚀山谷.description = "该区块未检测到敌方核心，前期敌方气息较弱。后期敌人气息较强。";//统计资料顶上的简介
风蚀山谷.localizedName = "风蚀山谷";//区块名
lib.addToResearch(风蚀山谷, {
        parent: 芳石峡谷,
        objectives: Seq.with(
            new Objectives.SectorComplete(芳石峡谷),
        ),
    });
exports. 风蚀山谷= 风蚀山谷//地图排序

const  平行裂谷= new SectorPreset("平行裂谷",埃维加斯, 57);
平行裂谷.alwaysUnlocked = false;//默认解锁此区块
平行裂谷.difficulty = 2;//难度
//破裂碎山.captureWave = 20;//敌人波数
平行裂谷.description = "降落之后要研究新的工厂。";//统计资料顶上的简介
平行裂谷.localizedName = "平行裂谷";//区块名
lib.addToResearch(平行裂谷, {
        parent: 风蚀山谷,
        objectives: Seq.with(
            new Objectives.SectorComplete(风蚀山谷),
        ),
    });
exports. 平行裂谷= 平行裂谷//地图排序

const  碳石要塞= new SectorPreset("碳石要塞",埃维加斯, 57);
碳石要塞.alwaysUnlocked = false;//默认解锁此区块
碳石要塞.difficulty = 7;//难度
//破裂碎山.captureWave = 20;//敌人波数
碳石要塞.description = "降落该区块后，立即建造防御。敌方有两座超远距离导弹塔。";//统计资料顶上的简介
碳石要塞.localizedName = "碳石要塞";//区块名
lib.addToResearch(碳石要塞, {
        parent: 风蚀山谷,
        objectives: Seq.with(
            new Objectives.SectorComplete(平行裂谷),
        ),
    });
exports. 碳石要塞= 碳石要塞//地图排序