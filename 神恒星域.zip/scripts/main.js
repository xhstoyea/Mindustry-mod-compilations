
function CreatorsPackage(name) {
 	var p = Packages.rhino.NativeJavaPackage(name, Vars.mods.mainLoader());
 	Packages.rhino.ScriptRuntime.setObjectProtoAndParent(p, Vars.mods.scripts.scope)
 	return p
 }
 
 Vars.renderer.minZoom = 0.5;
 Vars.renderer.maxZoom = 25;
//视野缩放
 MapResizeDialog.minSize = 0
 MapResizeDialog.maxSize = 99999
//地图
 var DSD = CreatorsPackage('dsd')
 importPackage(DSD)
 importPackage(DSD.content)
 //importPackage(TDCreatorsJavaPack.vv)



 ModJS.RunName.add("神恒星域")
 ModJS.DawnRun.add(run(() => {
require("blib");
require("lib");
require("区块编号");
//require("星球1");
//require("核心");
require("星球");
}));

