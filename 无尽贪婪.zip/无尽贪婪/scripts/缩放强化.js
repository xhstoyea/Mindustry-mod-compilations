//Le Zooom
const minZoomLim = 0.01;
const maxZoomLim = 100;

function updateZoom(min, max){
	Vars.renderer.minZoom = min;
	Vars.renderer.maxZoom = max;
}

if(!Vars.headless){
	updateZoom(minZoomLim, maxZoomLim);
}