# Letter Sound Effect
![h](https://repository-images.githubusercontent.com/343412426/468f6e00-7ae0-11eb-8325-8c6c3bbfe5a5)
A Soundpack that changes all sounds into TTS sam voice in Mindustry.

TTS, or text-to-speech, is the digitized audio rendering of computer text into speech. TTS software can "read" text from a document, Web page or e-Book, generating synthesized speech through a computer's speakers. Proofreading with TTS allows the author to catch awkward phrases, missing words or pacing problems.

**WARNING: Will be VERY loud if you are playing with this!**
