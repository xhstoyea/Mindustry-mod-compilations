let damageReduce = Stat("damageReduce");

const 破位墙 = extend(ShieldWall,"破位墙",{
    update: true,
    setStats(){
		this.super$setStats();
		this.stats.addPercent(damageReduce, 0.8)
	}
})
破位墙.buildType = prov(() => extend(ShieldWall.ShieldWallBuild,大型破位墙,{
    updateTile(){
        this.super$updateTile();
        
        Groups.bullet.intersect(this.x - 12, this.y - 12, 24, 24, b => {
            if(b.team != this.team){
b.damage = b.type.damage * 0.8
            }
        })
    }
}))

const 大型破位墙 = extend(ShieldWall,"大型破位墙",{
    update: true,
    setStats(){
		this.super$setStats();
		this.stats.addPercent(damageReduce, 0.8)
	}
})
大型破位墙.buildType = prov(() => extend(ShieldWall.ShieldWallBuild,大型破位墙,{
    updateTile(){
        this.super$updateTile();
        
        Groups.bullet.intersect(this.x - 20, this.y - 20, 40, 40, b => {
            if(b.team != this.team){
b.damage = b.type.damage * 0.8
            }
        })
    }
}))