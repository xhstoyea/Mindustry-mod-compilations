function SuperStorage(name) {

let block = extend(StorageBlock, name, {setStats) {

this.superssetStatsO

this.stats.remov(tat.itemCpcy

});

block.requirements = [];

block.category = Category.effec

block.buildVisibility = BuildVisibility.shown;

block.buildType = 0 => {

return extend(StorageBlock StorageBuild, block, {acceptltem(source, item) {

let core = this.team.coreO;

iF (core == nul) {

return false;

else {

this.items = core.items;

return core.acceptltem(sourc, item);

handleltem(source, item) {

iF (this.acceptltem(source, item)) {

this.team.core).handlelm item);

});

SuperStorage("核外奇点",);
//代码来自古代科技