const my = require("base/物品");
const lib = require("base/coflib");
const FX = require("base/effect");
const status = require("base/status");
let FF5845 = lib.FF5845, F03B0E = lib.Color("F03B0E");

function dm(size) {
	return new MultiEffect(
		Fx.dynamicSpikes.wrap(Pal.redLight, size),
		Fx.mineImpactWave.wrap(Pal.redLight, size * 1.5)
	)
}

let bu = Object.assign(extend(PointBulletType, {}), {
	lifetime: 6,
	speed: 160,
	ammoMultiplier: 1,
	shootEffect: dm(30),
	status: status.终焉,
	statusDuration: 60,
	splashDamage: 14400,
	splashDamageRadius: 128,
	trailSpacing: 24,
	trailEffect: Object.assign(new ParticleEffect(), {
		region: "curse-of-flesh-aim",
		baseRotation: -90,
		particles: 1,
		length: 1,
		baseLength: 1,
		lifetime: 45,
		sizeFrom: 40,
		sizeTo: 0,
		colorFrom: Pal.lightOrange,
		colorTo: Pal.redLight,
		cone: 0
	}),
	smokeEffect: Fx.mineImpact.wrap(Pal.redLight),
	hitEffect: dm(120),
	fragBullets: 8,
	fragVelocityMin: 0.5,
	fragBullet: Object.assign(extend(PointBulletType, {}), {
		lifetime: 24,
		speed: 8,
		status: status.终焉,
		statusDuration: 45,
		splashDamage: 7200,
		splashDamageRadius: 64,
		trailEffect: Fx.disperseTrail,
		despawnShake: 4,
		despawnSound: Sounds.plasmaboom,
		despawnEffect: dm(60),
		fragBullets: 4,
		hitEffect: Fx.titanExplosion.wrap(Pal.redLight),
		fragBullet: Object.assign(extend(PointBulletType, {}), {
			lifetime: 12,
			speed: 8,
			status: StatusEffects.melting,
			statusDuration: 30,
			splashDamage: 3600,
			splashDamageRadius: 32,
			trailEffect: Fx.disperseTrail,
			despawnShake: 4,
			despawnSound: Sounds.plasmaboom,
			despawnEffect: dm(30)
		})
	})
})

const 流年 = extend(PowerTurret, "流年", {});
Object.assign(流年, {
	health: 1056000,
	armor: 24,
	size: 16,
	range: 3840,
	reload: 60,
	shake: 8,
	shootY: 12,
	shootCone: 1,
	rotateSpeed: 0.5,
	recoil: 8,
	recoilTime: 90,
	cooldownTime: 120,
	canOverdrive: false,
	minWarmup: 0.99,
	shootWarmupSpeed: 0.016,
	unitSort: UnitSorts.strongest,
	ammoUseEffect: FX.casing8Double,
	shootSound: Sounds.malignShoot,
	shootType: bu
});
流年.consumePower(4000);
流年.setupRequirements(
	Category.turret,
	BuildVisibility.shown,
	ItemStack.with(
		my.铝, 12000,
		my,镍, 18000,
		Items.graphite, 18000,
		items.silicon, 15000,
		item.surge-alloy, 10000,
		items.phase-fabric, 10000,
		my.钋, 12000,
		my.破位物, 5000,
		my.羲和合金, 8000,
	)
);

lib.setBuilding(PowerTurret.PowerTurretBuild, 流年, {
	draw() {
		this.super$draw();
		FX.PlayerAim(this, FF5845);
	}
})

流年.drawer = (() => {
	const d = new DrawTurret();
	for (let i = 0; i < 5; i++) {
		d.parts.add(
			Object.assign(new RegionPart("-glow"), {
				progress: DrawPart.PartProgress.warmup.delay(i / 8),
				heatProgress: DrawPart.PartProgress.warmup.sin((4 - i) * 10, 10, 1),
				under: true,
				mirror: true,
				moveX: -6,
				moveY: 11 * i,
				layerOffset: -0.0001,
				turretHeatLayer: 50 - 0.0001,
				moves: Seq.with(new DrawPart.PartMove(DrawPart.PartProgress.recoil.delay((4 - i) / 8), 0, 0, -15)),
				color: lib.Color("FF9C5A"),
				heatColor: F03B0E
			})
		)
	}
	for (let i = 0; i < 8; i++) {
		lib.DoubleHalo(d, {
			progress: DrawPart.PartProgress.warmup.sin(i * 10, 20, 0.6), //频率/速度/进度
			x: 34 + i * 2,
			y: 32 - i * 8,
			shapes: 1,
			radius: 3.5 + i * 0.2,
			triL: 3,
			triLT: 8 + 2 * i,
			haloRot: -45,
			color: FF5845,
			colorTo: Pal.redLight
		})
	}
	d.parts.add(
		Object.assign(new RegionPart("-side-l"), {
			heatProgress: DrawPart.PartProgress.warmup,
			under: true,
			moveX: -1.75,
			moveY: 1,
			children: Seq.with(
				Object.assign(new RegionPart("-top-l"), {
					heatProgress: DrawPart.PartProgress.warmup,
					under: true,
					moveY: 32.5,
					layerOffset: -0.0001
				}),
				Object.assign(new RegionPart("-sidep-l"), {
					under: true,
					drawRegion: false,
					heatColor: F03B0E
				})
			),
			heatColor: F03B0E
		}),
		Object.assign(new RegionPart("-side-r"), {
			heatProgress: DrawPart.PartProgress.warmup,
			under: true,
			moveX: 1.75,
			moveY: 1,
			children: Seq.with(
				Object.assign(new RegionPart("-top-r"), {
					heatProgress: DrawPart.PartProgress.warmup,
					under: true,
					moveY: 32.5,
					layerOffset: -0.0001
				}),
				Object.assign(new RegionPart("-sidep-r"), {
					under: true,
					drawRegion: false,
					heatColor: F03B0E
				})
			),
			heatColor: F03B0E
		})
	)
	return d;
})();