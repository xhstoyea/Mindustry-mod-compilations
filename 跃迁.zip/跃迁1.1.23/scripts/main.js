MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000
const lib = require("lib")
require('？/核外奇点');
require('？/缩放强化');
require("？/wall");

require("block/炮塔/清算");

Vars.maxSchematicSize = 128;
if (!Vars.headless) {
	Vars.renderer.minZoom = 0.1;
	Vars.renderer.maxZoom = 50;
}