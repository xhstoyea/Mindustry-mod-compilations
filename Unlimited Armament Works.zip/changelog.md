# Update 0.7.8.2
 Includes balance changes to turrets, factories, and units.
 
## Turrets
1. **Shot-Cannons**
   - All Shot-Cannons shots spread angle is increased.
   - **Buckshot** can now use graphite as munition.
   - **Buckshot, Tempest, and Strikeforce** has been resprited
2. **Snipers**
    - **Solo** rate of fire is reduced  
    - **Solo and Longsword** has been resprited
3. **Machine Guns**
    - **Spitfire** has been resprited

## Units
1. All unit outlines are now auto generated.
2. **Aglovale** Missile launcher rate of fire is reduced.
3. **Corsair** Bomb targeting adjusted, should be less likely to miss.

## Crafting
1. **Carburizing Furnace** now no longer use steam, it uses power instead, 