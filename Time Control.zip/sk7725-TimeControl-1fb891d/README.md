# TimeControl
Speeds up or slows down Mindustry.   

Supports `x1/256` ~ `x256`. Simply drag the slider to adjust the speed.
Click/tap on 'x#' to shrink the ui. Click/tap on the button to adjust the speed, hold to expand back to full size.

Not intended for multiplayer use.
