# Toggle Editor Mode
[![Github All Releases](https://img.shields.io/github/downloads/electricgun/toggle-editor-mode/total.svg)]() <br> <br>
Click button to enable Editor mode on Singleplayer and Sandbox.
<br>
Does not work on Multiplayer and Campaign.
<br>
<br>
Changelog:
<br>
Taken account for Testing Utilities and Time Control panels.
<br>
Fixed crashing when entering edit mode
<br>
Fixed delay
<br>
etc
