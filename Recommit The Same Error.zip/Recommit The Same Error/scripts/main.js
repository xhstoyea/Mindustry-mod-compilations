Vars.renderer.minZoom = 0.03;
Vars.renderer.maxZoom = 150;
