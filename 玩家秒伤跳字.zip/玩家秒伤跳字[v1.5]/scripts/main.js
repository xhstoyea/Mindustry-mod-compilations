let mod = Vars.mods.getMod(modName);

mod.meta.author = "[yellow]miner";
mod.meta.description = 
"显示[accent]玩家每秒受到的伤害[white]" + 
"v1.2: 暂停不记时间 显伤更加明显 更改错误的计时" + 
"v1.5: 改名为玩家秒伤跳字, 跳字更丝滑" + 
"\nminer的mod群:757679470";

let numberEffect = new Effect(80, container => {
    let {x, y, color, life, lifetime, rotation, data} = container;
    let {font, number, jump, scale, alpha} = data;
    
    const {v1, v2, v3, v4, v5, v6} = Tmp;
    
    const fin = container.fin();
    
    const easeOutDown = Bezier.cubic(v1, fin, 
        v2.set(1, 1),
        v3.set(0.565, 1), 
        v4.set(0.39, 0.575), 
        v5.set(0.5, 0.5),
        v6).y;
    const easeOutExpo = Bezier.cubic(v1, fin, 
        v2.set(0, 0),
        v3.set(0.19, 1), 
        v4.set(0.22, 1), 
        v5.set(1, 1),
        v6).y;
        
    alpha *= easeOutDown;
    scale *= easeOutDown;
    
    const yOffset = jump * easeOutExpo,
        xOffset = yOffset * Math.tan(rotation * Mathf.degRad);
        
    const fy = y + yOffset,
        fx = x + xOffset;
                        
    Tmp.c1.set(color).a = alpha;
    
    Draw.z(Layer.overlayUI);
    font.draw(Strings.autoFixed(number, 1), fx, fy, Tmp.c1, scale, false, Align.center);
    Draw.reset();
});

function NumberEffectData(font, number, jump, scale, alpha){
    this.font = font;
    this.number = number;
    this.jump = jump;
    this.scale = scale;
    this.alpha = alpha;
}

let lastHealth = -1;
let lastUnit = null;
let scale = Scl.scl(1);

let time = 0;
let keeping = false;
Events.run(Trigger.update, () => {
    if(Vars.state.isPaused()){
        return;
    }

    let unit = Vars.player.unit();
    if(lastUnit == null || lastUnit != unit){
        lastUnit = unit
        if(lastUnit != null){
            lastHealth = unit.health;
            scale = Mathf.clamp(unit.hitSize / 64 / Scl.scl(1), 1/4/Scl.scl(1), 1/2/Scl.scl(1));
        }
        return;
    }
    
    let {health, hitSize} = unit;
    if(lastHealth == health){
        return;
    }else if(!keeping){
        time = 0;
        keeping = true;
    }
    
    if(keeping){
        time += Time.delta / 60;
        if(time < 1){
            return;
        }
    }
            
    let change = health - lastHealth;
            
    numberEffect.at(unit.x, unit.y + hitSize * Mathf.random(0.5, 0.8), 
    Mathf.range(45), 
    change < 0 ? Pal.health : Pal.heal, 
    new NumberEffectData(Fonts.outline, change, Mathf.random(8, 12), scale, 1));
    
    lastHealth = health;
    keeping = false;
})