const 年兽 = extend(UnitType,"年兽",{
    i : 0,
    update(unit){
        this.super$update(unit);
        
        this.i -= Time.delta
        
        if(this.i <= 0){
            this.i = 180 * 60;
            Vars.tree.loadSound("年兽").stop();
            
            Vars.tree.loadSound("年兽").play();
        }
    }
})
年兽.constructor = () => new LegsUnit.create()