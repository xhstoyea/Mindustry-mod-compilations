# Upgraded-Blocks
This Mindustry mod will add alternate blocks which will be better then their analogues, but also will be cost more resources to build.
Most of additional blocks will be batteries, containers, etc. 
But it will not be any turrets or something like this 
<p></p>
Contribution:
You can make sprites for mod and if your sprite will be good I'll replace my sprite with your. Of course I'll write that sprite was made by you (if i added your sprite)
