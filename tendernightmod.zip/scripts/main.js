function ModPackage(name) {
    var p = Packages.rhino.NativeJavaPackage(name, Vars.mods.mainLoader());
    Packages.rhino.ScriptRuntime.setObjectProtoAndParent(p, Vars.mods.scripts.scope)
	return p
}

var TnJavaPack = ModPackage('tn')
importPackage(TnJavaPack)
importPackage(TnJavaPack.content)
importPackage(TnJavaPack.core)

importPackage(TnJavaPack.lib)
importPackage(TnJavaPack.lib.entity)
importPackage(TnJavaPack.lib.entity.lib)

importPackage(TnJavaPack.ui)

importPackage(TnJavaPack.ui.draw)

importPackage(TnJavaPack.ui.mdt)
importPackage(TnJavaPack.ui.mdt.coredisplay)

importPackage(TnJavaPack.ui.mod)
importPackage(TnJavaPack.ui.mod.update)

importPackage(TnJavaPack.world)

importPackage(TnJavaPack.world.block)
importPackage(TnJavaPack.world.block.ai)
importPackage(TnJavaPack.world.block.drill)
importPackage(TnJavaPack.world.planet)
importPackage(TnJavaPack.world.production)
importPackage(TnJavaPack.world.production.multi)
importPackage(TnJavaPack.world.unit)
importPackage(TnJavaPack.world.unit.item)
importPackage(TnJavaPack.world.unit.veteran)
importPackage(TnJavaPack.world.unit.stealth)

/*if(OS.isAndroid){

}else{
    let cx = Seq([Packages.rhino.Context]).get(0);
    let field = cx.getDeclaredField("applicationClassLoader");
    field.setAccessible(true)
    field.set(Vars.mods.getScripts().context, Vars.mods.mainLoader());
}*/