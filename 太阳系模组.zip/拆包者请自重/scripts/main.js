Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("[yellow]太阳系模组信息栏");
    dialog.cont.image(Core.atlas.find("太阳系模组-logo")).row();;
    dialog.buttons.defaults().size(210, 64);
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(210, 64);
    dialog.cont.pane((() => {
        var table = new Table();   
         table.add("[yellow]欢迎游玩本模组 \n本模组英文名为Solar System Mod,简称SSM\n[blue]本模组由一只ZZ君（脚本），睿智梓菜（编剧/总策划），小马哥（贴图//已退出工作室）钍糯米（贴图）大饭猫猫（测试）小初（贴图）小朱哥（策划//已退出工作室），共同开发，\n[red]模组开发初期就只有一只ZZ君一人负责脚本和贴图（我的贴图就是歌姬吧）如觉侮眼，请另玩高模\n[red]本模组因在开发初期时借鉴了饱和火力部分贴图和Json如觉不妥请联系删除或修改\n[grey]／／实际上都是用的弃用贴图[red]\n[red]（作者QQ:3509967106）\n最后一次更新时间：25/2/2023 \n [blue]模组QQ群:[green]774757128\n下滑还有剧情\n背景音乐分别为：［Fallback］friskmegalovania（决意）（bysiroa）\nxpart/xpart2\n   JasonHuang-冬之花（交响乐版shortver）\n   His Theme (他的主题)（已购版权）\n[grey]／／话说我又没商用买版权来做甚\n[blue]更新日志可以在模组简介里查看").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
table.button("[yellow]工作室招收", run(() => {
    var dialog2 = new BaseDialog("[yellow]招收各路神仙大佬");
    var table = new Table();
    dialog2.cont.image(Core.atlas.find("太阳系模组-二维码")).row();;
    dialog2.buttons.defaults().size(210, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 64);
       dialog2.show();
    })).size(210, 64).row();
table.button("[red]关于火星剧情", run(() => {
    var dialog2 = new BaseDialog("[red]剧情介绍,向右滑可以看到更多");
    var table = new Table();
	
	var t = new Table();
	t.add("[red]仍旧是那样红色的饱含氧化铁的土壤，Y国的\n14号火星载人考察船着陆，几个宇\n航员走了出来。即使是第114次载人登陆火星\n做考察，也依旧要进行火星土壤取样、岩石取样和矿物取样。2090年的发现表明火星上有丰富的矿藏，包括但不限于铀、银、铜、铅等等。随着航天技术不断发展，一些国家为了提高登陆火星带来的收益，\n便私自开采火星上的矿物。虽然这已经遭到联合国的强烈谴责，但仍有不少国家顶风作案。对此，联合国发布了提案：《火星考察船私自开采矿物解决办法》。提案中说道：”对一切以考察的名义开采火星矿层的考察船将给予警告，如有不从者一律击毁。”这就封死了一些小国家的矿物来源，但又有什么办法呢？\n吉米是个新手，在别人采集样本的时候，他一直惊异于火星的景色：幽暗无比的外太空就像一块幕布，而他足下的火星地表就像被光照射的舞台。外太空和火星地表的颜色、亮度反差着实令他震惊和陶醉。\n“别看了，干活吧！不是让你出来旅游的，速战速撅！”队长拍了拍吉米的肩膀催促道。\n他们本就是违法的“以考察的名义开采火星矿层”的考察船，但是有M国撑腰壮胆，联合国也管不着，只好作罢。\n底层探测器正在往火壤深处钻去，不一会儿就遇到了固态岩层，但这次的岩层硬度好像更高了，探测器无法再继续深入，于是提前自毁。一次性的探测器自毁是很正常的事，见其他队员的探测器都没问题，于是连带着岩层硬度提升一块儿，吉米都没有当回事，也没有报告给队长。于是，挖掘正常进行。\n大约到地表-50米深度的时候，钻头的挖掘速度慢了下来。随着时间推移，钻头速度越来越慢，挖掘几乎停止。队长发现不对劲，赶忙前去查看：钻头被拆除后，一块黑色的“铁板”赫然出现在眼前，上面已经被钻头钻出来了一个大洞，发着淡淡的蓝光。线路不停的闪烁着电弧。洞里还在往外喷着空气……空气！\n队长意识到了什么，急忙让队员们上飞船，但吉米还在不断的调试硬件——显然，他还没有意识到事情的严重性。好容易让大家上了飞船，但起飞没一会儿，队长就收到了警告：要求着陆接受检查。\n突然，那架飞船冒起浓烟，径直向地面撞去。队长没有继续看，而是迅速加速飞船。\n\n“因为资源匮乏，他们停止了一切向往探索的活动。现如今，我们激怒了他们，给他们打开了通往宇宙的大门……”\n\n好景不长，一个核动力被摧毁，飞船也迫降在了火星地表——沙子掩埋之下，一个人类废弃基地的轮廓显现出来。\n\n“我们要活下来，他们将会倾尽全力、用尽资源向外前进，用更少的资源夺来更多的资源——这将是他们的生死之战，是两个临近文明之间的战役……”队长临死前这样说。");
    dialog2.cont.add(new ScrollPane(t)).size(500, 900).row();
    dialog2.buttons.defaults().size(210, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 64);
       dialog2.show();
    })).size(210, 64);
    table.button("[red]小[yellow]彩[blue]蛋", run(() => {
   var dialog2 = new BaseDialog("114514");
   var table = new Teble();
   var e = new Teble();
   e.add("514");
   dialog2.cont.add(new ScrollPane(e)).size(500, 900).row();
    dialog2.buttons.defaults().size(210, 64);
   dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 64);
       dialog2.show();
    })).size(210, 64);
    return table;
    
    })()).grow().center().maxWidth(620);
    dialog.show();
}));

MapResizeDialog.minSize = 0;
MapResizeDialog.maxSize = 10001;
require('base/item')
require('辅助/超代核心');
require('辅助/服务器');
require('辅助/远征一号');
require('辅助/前哨核心');
require('辅助/时间控制');
require('辅助/缩放强化');
require('辅助/材料颜色');
//require('辅助/替换背景');
require('辅助/资源显示');
require('星球/mars');
require('星球/earth');
require('独立科技树');
