const lib = require("base/lib");
const item = require("base/item");

const mars = new Planet("mars", Planets.sun, 1, 3.3);
mars.meshLoader = prov(() => new MultiMesh(
	new HexMesh(mars, 8)
));

mars.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(mars, 2, 0.15, 0.14, 5, Color.valueOf("F5560060"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(mars, 3, 0.6, 0.15, 5, Color.valueOf("F5560060"), 2, 0.42, 1.2, 0.45)
));
mars.generator = extend(SerpuloPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgYWBhZmDJS8xNZeB5sX/O032NT3Y0PO3fzsCdklqcXJRZUJKZn8fAwMCWk5iUmlPMwBQdy8gg83TJqpczNj/fvPvZioXPd7foouhkYGAEISABAOilJlk=")
	}
});

iconColor: Color.valueOf("7d4dff"),

mars.generator = new SerpuloPlanetGenerator();
mars.visible = mars.accessible = mars.alwaysUnlocked =  true;
mars.clearSectorOnLose = false;
mars.tidalLock = false;
mars.localizedName = "火星";
mars.bloom = false;
mars.startSector = 1;
mars.orbitRadius = 95;
mars.orbitTime = 180 * 60;
mars.rotateTime = 90 * 60;
mars.atmosphereRadIn = 0.02;
mars.atmosphereRadOut = 0.3;
mars.atmosphereColor = mars.lightColor = Color.valueOf("F5560090");
mars.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);
exports.mars = mars;
mars.allowLaunchLoadout = true

const 远征一号 = extend(CoreBlock, "远征二号", {});
//const a = new Core("远征一号")
mars.defaultCore = 远征一号;

const 初始地区 = new SectorPreset("初始地区", mars, 1);
初始地区.description = "这里将是火星之旅的开端";
初始地区.difficulty = 1;
初始地区.alwaysUnlocked = true;
初始地区.addStartingItems = true;
初始地区.captureWave = 1;
初始地区.localizedName = "初始地区";
exports.初始地区 = 初始地区;
lib.addToResearch(初始地区, {
	parent: "groundZero",
	objectives: Seq.with(
	new Objectives.SectorComplete(SectorPresets.groundZero))
});

const 火星文明 = new SectorPreset("火星文明", mars, 2);
火星文明.description = "我们竟然在火星上发现了文明本以为是赛普罗星上的敌人登陆了火星，没想到竟然是火星上的文明，虽然按照常规知识，我们还只知道火星在很久以前才出现过一次生命体，但是眼前的场景让我们非常的棘手利用我们现有的科技碾碎他们";
火星文明.difficulty = 1;
火星文明.alwaysUnlocked = false;
火星文明.addStartingItems = false;
火星文明.captureWave = 5;
火星文明.localizedName = "火星文明";
exports.火星文明 = 火星文明;
lib.addToResearch(火星文明, {
	parent: "初始地区",
	objectives: Seq.with(
	new Objectives.SectorComplete(初始地区))
});

const 火星基地 = new SectorPreset("火星基地", mars, 22);
火星基地.description = "这所基地是我方早期探索星际时留下的小型基地但在很久以前就已经被攻陷了，狡猾的敌人将基地占为己有，拿下他";
火星基地.difficulty = 2;
火星基地.alwaysUnlocked = false;
火星基地.addStartingItems = false;
火星基地.captureWave = 0;
火星基地.localizedName = "火星基地";
exports.火星基地 = 火星基地;
lib.addToResearch(火星基地, {
	parent: "火星文明",
	objectives: Seq.with(
	new Objectives.SectorComplete(火星文明))
});

const 星际仓库 = new SectorPreset("星际仓库", mars, 150);
星际仓库.description = "这里貌似是一个星际仓库，我们的资源已所剩无几，攻陷他";
星际仓库.difficulty = 6;
星际仓库.alwaysUnlocked = false;
星际仓库.addStartingItems = false;
星际仓库.captureWave = 0;
星际仓库.localizedName = "星际仓库";
exports.星际仓库 = 星际仓库;
lib.addToResearch(星际仓库, {
	parent: "火星基地",
objectives: Seq.with(
	new Objectives.SectorComplete(火星基地))
});

const 火星人的阴谋 = new SectorPreset("火星人的阴谋", mars, 68);
火星人的阴谋.description = "这是一个阴谋!我们被火星人算计了，现在四周都被包围了，坚持住";
火星人的阴谋.difficulty = 8;
火星人的阴谋.alwaysUnlocked = false;
火星人的阴谋.addStartingItems = false;
火星人的阴谋.captureWave = 45;
火星人的阴谋.localizedName = "火星人的阴谋";
exports.火星人的阴谋 = 火星人的阴谋;
lib.addToResearch(火星人的阴谋, {
	parent: "星际仓库",
objectives: Seq.with(
	new Objectives.SectorComplete(星际仓库))
});