function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("土钢")
newItem("熔岩矿")
newItem("锂")
newItem("银矿")
newItem("稀土")