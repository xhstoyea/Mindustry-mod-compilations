const mars = require("星球/mars")
const planet = require("星球/mars");
const core = require("星球/mars");
const item = require("base/item");

const node = TechTree.node;

planet.mars.techTree = TechTree.nodeRoot("mars",core.远征一号,()=>{
/*node(热力钻头, () => {
		node(铅传送带, () => {
		node(小钢炮, () => {
		node(绝热装甲导管, () =>{
		node(太阳能板, () =>{
		      });
		    });
		  });
		});
	});*/
});
/*const nodeRoot = TechTree.nodeRoot;
const nodeProduce = TechTree.nodeProduce;
const node = TechTree.node;
const SectorComplete = Objectives.SectorComplete;
const Research = Objectives.Research;

const planet = require('mars');
const core = require('mars');

nodeRoot("远征一号", core.远征一号, () => {
})*/