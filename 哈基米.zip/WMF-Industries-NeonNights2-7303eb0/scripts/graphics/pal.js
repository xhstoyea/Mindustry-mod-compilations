Events.on(ClientLoadEvent, b  => {
    Pal.heal = Color.valueOf("6cf5d7");
    Pal.sap = Color.valueOf("814c9e");
    Pal.sapBullet = Color.valueOf("f17afa");
    Pal.sapBulletBack = Color.valueOf("7343bf");
    Pal.suppress = Color.valueOf("d17aff");
    Pal.techBlue = Color.valueOf("7485e8");
});