const endfieldprelude = Vars.mods.locateMod("icbm").meta;

require("blocks/西格马差分机");
require("blocks/大型西格马差分机");
require("blocks/营造法式");
require("blocks/铁匠工坊");
require("blocks/手工工会");

require("blocks/贸易集中站点");
require("blocks/选矿设备I");
require("blocks/砖厂");
require("blocks/海水蒸发池");
require("blocks/燃烧器");
require("blocks/碳化塔");
require("blocks/高炉I");
require("blocks/回转炉I");
require("blocks/铸造器I");
require("blocks/制造站I");
require("blocks/球磨机");
require("blocks/回转窑");

require("blocks/建材厂");
require("blocks/高炉II");
require("blocks/回转炉II");
require("blocks/铸造器II");
require("blocks/制造站II");
require("blocks/化工厂I");
require("blocks/电弧炉I");
require("blocks/电碳化塔");
require("blocks/电解装置");
require("blocks/氨合成器");
require("blocks/大气分离器");

require("blocks/PWR");
require("blocks/蒸汽轮机");
require("blocks/阿尔斯通蒸汽轮机");
require("blocks/冷凝塔");

require("其它/飒-library");
require("其它/钠墙");

endfieldprelude.displayName = Core.bundle.get("mod.icbm.name");
endfieldprelude.author = Core.bundle.get("mod.icbm.author");
endfieldprelude.description = Core.bundle.get("mod.icbm.description");
endfieldprelude.subtitle = Core.bundle.get("mod.icbm.subtitle");