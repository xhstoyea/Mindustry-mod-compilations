
function SodiumWallBuild() {
    this.updateTile = function(){
        if(this._timer < 6){this._timer += 1}else{
            this.艹();
            this._timer = 0;
        };//1秒更新10次
    };
    
    this.艹 = function(){
        Fx.explosion.at(this.x, this.y);
        Damage.damage(null,this.x,this.y,80,2400,true,true,true);
    };
    
    this._timer = 0;
}

function SodiumWallBlock() {
    this.init = function() {
        this.update = true;
        this.super$init();
    };
    
    this.setStats = function() {
        this.super$setStats();
        this.stats.add(Stat.abilities, new JavaAdapter(StatValue, {
            display(table) {
                table.table(Styles.none, function(groupTable) {
                    groupTable.table(Styles.grayPanel, function(view) {
                        view.add().size(8).row();
                        view.add("[accent]  该墙遇到水时会发生剧烈爆炸").left().row();
                        view.add("[lightgray]    爆炸造成无视敌我的范围伤害").left().row();
                        view.add("[white]    爆炸伤害: 2400  爆炸范围: 80").left().row();
                        view.add("[gray]    * 也许可以放在阵地之前用波浪激活  ").left().row();
                        view.add("[lightgray]    碱金属较软，所以该墙血量不高").left().row();
                        view.add().size(12).row();
                    });
                })
            }
        }))
    };
    
}

function cloneObject(obj) {
    var clone = {};
    for(var i in obj) {
        if(typeof obj[i] == "object" && obj[i] != null) clone[i] = cloneObject(obj[i]);
        else clone[i] = obj[i];
    }
    return clone;
}

module.exports = {
    SodiumWall(name, def, ExtraEntityDef) {
        const block = new SodiumWallBlock();
        Object.assign(block, def);
        const SodiumWall = extend(Wall, name, block);
        SodiumWall.buildType = () => extend(Wall.WallBuild, SodiumWall, Object.assign(new SodiumWallBuild(), typeof ExtraEntityDef == "function" ? new ExtraEntityDef() : cloneObject(ExtraEntityDef)));
        return SodiumWall;
    }
};

const furnace = module.exports.SodiumWall("钠墙");