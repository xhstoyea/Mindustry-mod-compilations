/*
* 参照《明日方舟》中斩业星熊的天赋设计的一个防御型建筑所需的lib
* 为了体现整活大部分变量名采用了中文~
*
* 该文件的版权归属鹰角网络所有
*/

/**
* @author < 冰汐Angel >
*/

function 飒Build() {
    this.updateTile = function(){
        if(!this._被初始化){
            this._护甲 = this.block.get面板().护甲;
            this._被初始化 = true;
        };
        if(this._更新计时器 < 6){this._更新计时器 += 1}else{
            this.计算护甲();
            this.计算回复();
            this._更新计时器 = 0;
        };//1秒更新10次
    };
    
    this.计算护甲 = function(){
        if(this.health == this.maxHealth){return};
        if(this.health <= this.maxHealth * this.block.get天赋().护甲提高阈值 / 100) {
            this._护甲 = this.block.get面板().护甲 * (1 + this.block.get天赋().护甲提高上限 / 100);
        }else{
            var 比例 = (this.maxHealth - this.health) / (this.maxHealth * (1 - this.block.get天赋().护甲提高阈值 / 100));
            this._护甲 = this.block.get面板().护甲 * (1 + this.block.get天赋().护甲提高上限 / 100 * 比例);
        }
    };
    
    this.计算回复 = function(){
        if(this._回复计时器 >= 10 * this.block.get天赋().我执回复等待间隔){
            this._处于我执状态 = false;
            this._我执伤害累计 = 0;
            var 恢复量 = this.maxHealth * this.block.get天赋().我执恢复速率 / 1000;
            if(this.health <= this.maxHealth - 恢复量){this.health += 恢复量}else{this.health = this.maxHealth};
            this._回复计时器 -= 1;
        };
        this._回复计时器 += 1;
    };
    
    this.damaged = function(){
        if(!this._处于我执状态 && this.health < this.maxHealth){return true};
        return false
    }
    
    this.damage = function(x, y, damage) {
        //获取伤害的接口排在第三
        if(damage == null){return};
        this._回复计时器 = 0;
        var 受到伤害 = damage * (1 - this._护甲 / 100);
        if(this._处于我执状态){
            this._我执伤害累计 += 受到伤害;
            Fx.placeBlock.at(this.x, this.y, 2);
            if(this._我执伤害累计 >= this.maxHealth * this.block.get天赋().我执可承受生命倍率 / 100){this.kill()};
        }else{
            this.health -= 受到伤害;
            if(this.health <= 0){
                this.health = 1;
                this._处于我执状态 = true;
            }
        }
    };
    
    this._被初始化 = false;
    this.get被初始化 = function() {
        return this._被初始化;
    };
    this._更新计时器 = 0;
    this.get更新计时器 = function() {
        return this._更新计时器;
    };
    this._护甲 = 0;
    this.get护甲 = function() {
        return this._护甲;
    };
    this._回复计时器 = 0;
    this.get回复计时器 = function() {
        return this._回复计时器;
    };
    this._处于我执状态 = false;
    this.get处于我执状态 = function() {
        return this._处于我执状态;
    };
    this._我执伤害累计 = 0;
    this.get我执伤害累计 = function() {
        return this._我执伤害累计;
    };
    
    飒Build.prototype.write = function(write) {
        this.super$write(write);
        write.bool(this._被初始化);
        write.i(this._更新计时器);
        write.f(this._护甲);
        write.i(this._回复计时器);
        write.bool(this._处于我执状态);
        write.f(this._我执伤害累计);
    };

    飒Build.prototype.read = function(read, revision) {
        this.super$read(read, revision);
        this._被初始化 = read.bool();
        this._更新计时器 = read.i();
        this._护甲 = read.f();
        this._回复计时器 = read.i();
        this._处于我执状态 = read.bool();
        this._我执伤害累计 = read.f();
    };
}

function 飒Block() {
    // 初始化参数
    var 面板 = {};
    this.get面板 = function(){return 面板};
    var 天赋 = {};
    this.get天赋 = function(){return 天赋};
    
    this.init = function() {
        this.update = true;//墙体默认是不会自动调用updateTile的，需要手动打开
        面板 = {
            护甲: this.面板信息.护甲 || 15,
        };
        天赋 = {
            //业火
            我执可承受生命倍率: this.天赋信息.我执可承受生命倍率 || 200,
            我执回复等待间隔: this.天赋信息.我执回复等待间隔 || 5,
            我执恢复速率: this.天赋信息.我执恢复速率 || 5,
            //鬼之架势
            护甲提高阈值: this.天赋信息.护甲提高阈值 || 30,
            护甲提高上限: this.天赋信息.护甲提高上限 || 50,
        };
        this.super$init();
    };
    
    this.setStats = function() {
        this.super$setStats();
        this.stats.add(Stat.armor, 面板.护甲);
        this.stats.add(Stat.abilities, new JavaAdapter(StatValue, {
            display(table) {
                table.table(Styles.none, function(groupTable) {
                    groupTable.table(Styles.grayPanel, function(view) {
                        view.add().size(8).row();
                        view.add("[accent]  业火: 血量小于0时不被破坏，而是进入我执状态  ").left().row();
                        view.add("[lightgray]    我执期间无法被治疗，受到的伤害持续积累").left().row();
                        view.add("[lightgray]    积累至生命上限的 " + 天赋.我执可承受生命倍率 + "% 时被破坏").left().row();
                        view.add("[lightgray]    " + 天赋.我执回复等待间隔 + "秒 内未受到伤害时每秒恢复 " + 天赋.我执恢复速率 + "% 血量").left().row();
                        view.add("[lightgray]    血量大于0时退出我执状态").left().row();
                        view.add().size(12).row();
                    });
                    groupTable.add(" ").row();
                    groupTable.add(" ").row();
                    groupTable.table(Styles.grayPanel, function(view) {
                        view.add().size(8).row();
                        view.add("[accent]  鬼之架势: 随着血量降低护甲提高").left().row();
                        view.add("[lightgray]    血量低于 " + 天赋.护甲提高阈值 + "% 时达到护甲提高上限，为 " + 天赋.护甲提高上限 + "%  ").left().row();
                        view.add("[gray]    * 这里的护甲为百分比减伤").left().row();
                        view.add().size(12).row();
                    });
                })
            }
        }))
    };
    
    this.setBars = function() {
        this.super$setBars();
        //this.removeBar("health");
        
        this.addBar("血条", entity => new Bar(
            () => {if(entity.get处于我执状态()){return "承受上限: " + Math.floor(entity.maxHealth * 天赋.我执可承受生命倍率 / 100 - entity.get我执伤害累计())}else{return "血量: " + Math.floor(entity.health)}},
            () => {if(entity.get处于我执状态()){return Color.valueOf("1313d8")}else{return Color.valueOf("d82626")}},
            () => {if(entity.get处于我执状态()){return 1 - entity.get我执伤害累计() / (entity.maxHealth * 天赋.我执可承受生命倍率 / 100)}else{return entity.health / entity.maxHealth}},
        ));
    };
}

function cloneObject(obj) {
    var clone = {};
    for(var i in obj) {
        if(typeof obj[i] == "object" && obj[i] != null) clone[i] = cloneObject(obj[i]);
        else clone[i] = obj[i];
    }
    return clone;
}

module.exports = {
    飒(name, 面板, 天赋, def, ExtraEntityDef) {
        const block = new 飒Block();
        Object.assign(block, def);
        const 飒 = extend(Wall, name, block);
        飒.buildType = () => extend(Wall.WallBuild, 飒, Object.assign(new 飒Build(), typeof ExtraEntityDef == "function" ? new ExtraEntityDef() : cloneObject(ExtraEntityDef)));
        飒.面板信息 = 面板;
        飒.天赋信息 = 天赋;
        return 飒;
    }
};

const 面板 = {
    护甲: 15,
};

const 天赋 = {
    我执可承受生命倍率: 200,
    我执回复等待间隔: 5,
    我执恢复速率: 5,
    
    护甲提高阈值: 30,
    护甲提高上限: 50,
};

const furnace = module.exports.飒("飒墙",面板,天赋);