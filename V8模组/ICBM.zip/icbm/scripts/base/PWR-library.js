/*
* 这是通用反应堆系列的第一弹
* 压水式反应堆-PWR
* 你可以用这个文件随意改造属于你自己的压水式反应堆
* 并且进行了尽可能详尽的注释以方便学习
*/

/**
* @author < 冰汐Angel UR-PWR 1.1 >
*/

//这个函数定义了多配方合成器的实体行为，它是合成器的核心逻辑。
function PWRBuild() {
    //燃料捧方案检查
    this.FuelRodOrder = function(){
        if(this._FuelRodin < 0){return false};
        return true;
    };
    //冷却剂方案检查
    this.CoolantinOrder = function(){
        if(this._Coolantin < 0){return false};
        return true;
    };
    //核心燃料棒非空检查，非空返回true
    this.CorenotNull = function(){
        if(this._FuelRodAmoumt == 0){return false};
        return true;
    };
    this.FuelRodCache = function(){if(this._FuelRodin < 0){return false}else if(this.items.get(this.block.getFuelRodSupport()[this._FuelRodin]) > 0){return true}else{return false}};
    //堆芯冷却剂非空检查，非空返回true
    this.ReactorCorenotNull = function(){
        if(this._CoreCoolantVolume == 0){return false};
        return true;
    };
    //二回路非空检查，非空返回true
    this.ECnotNull = function(){
        if(this._Coolantin < 0){return false};
        if(this.liquids.get(this.block.getCoolantsSupport()[this._Coolantin]) == 0){return false};
        return true;
    };
    //堆芯冷却剂未满检查，已满返回true
    this.ReactorCorenotFull = function(){
        if(this._CoreCoolantVolume < this.block.getModel().MaxCoreCoolant){return false};
        return true;
    };
    //二回路输入未满检查，已满返回true
    this.ECInputnotFull = function(){
        var ECI = this.liquids.get(this.block.getCoolantsSupport()[this._Coolantin]);
        if(ECI < this.block.liquidCapacity){return false};
        return true;
    };
    //二回路输出未满检查，已满返回true
    this.ECOutputnotFull = function(){
        var ECO = this.liquids.get(this.block.getHeatedUp()[this._Coolantin]);
        if(ECO < this.block.liquidCapacity){return false};
        return true;
    };
    //蒸汽泄漏检查
    this.RuningState0 = function(){
        if (this._ReactorCoreP > (this.block.getModel().MaxPressure + this.block.getModel().MinPressure) / 2){
            var AccidentRandom = Math.random() * 100000;
            if (AccidentRandom < 5){
                this.health -= 800;
                this._RuningState[0] = true;
            }
        }
        if(this.health >= this.maxHealth - 10){this._RuningState[0] = false};
    };
    //蒸汽爆炸检查
    this.RuningState1 = function(){
        if (this._ReactorCoreP > this.block.getModel().MaxPressure){
            this._RuningState[1] = true;
            this._CoreSteamVolume = 0;
            this._ReactorCoreP = 0.1;
            Damage.damage(null,this.x,this.y,180,600,true,true,true);
            Fx.reactorExplosion.at(this.x, this.y);
        }
    };
    //核心熔毁检查
    this.RuningState2 = function(){
        if(this._CoreTemperature > 2760){
            this._RuningState[2] = true;
            Damage.damage(null,this.x,this.y,80,2400,true,true,true);
            Fx.reactorExplosion.at(this.x, this.y);
        }
    };
    //核心融毁后
    this.RuningStateAfter = function(){
        this.heatGenerate();// 核心融毁后仍然会产生热量
        this.computeCoreTemperature();
        if(this._CoreTemperature > 500){var baseDamage = Math.log10(this._CoreTemperature - 500)}else{var baseDamage = 2};
        Damage.damage(null,this.x,this.y,240,baseDamage,true,true,true);
    };
    //供电端离线检查
    this.RuningState3 = function(){
        if(this._RPS < 15){
            this._RuningState[3] = true;
        }else{
            if(this._InternalWaterPump){this._RPS -= 3};
            if(this._WaterPump){this._PRS -= 2};
            if(this._ExhaustValve){this._RPS -= 3};
            this._RuningState[3] = false;
        }
    };
    
    //每帧更新实体
    this.updateTile = function(){
        if(this._RuningState[2]){this.RuningStateAfter();return};
        
        //向核心内添加燃料棒
        if(this._RefuelingDevice && this.FuelRodOrder() && this._FuelRodAmoumt < this.block.getModel().MaxFuelRod){this.FuelRodFilling()};
        //向核心内添加硼酸水
        if(this._InternalWaterPump && !this.ReactorCorenotFull()){this.CoreCoolantinOrder()};
        //向反应堆内电源充电，按840千瓦充电，总蓄电量0.18兆瓦时
        if(this.power !== null && this._RPS < 180000 && this.block.getModel().needPower){this._RPS += 14 * this.power.status};
        //输出乏燃料与热冷却剂，乏燃料无法输出强制停堆
        if(this.FuelRodOrder() && this.items.get(this.block.getSpentFuel()[this._FuelRodin]) > 0 && !this._RuningState[3]){if(this.put(this.block.getSpentFuel()[this._FuelRodin])){this.items.remove(this.block.getSpentFuel()[this._FuelRodin],1)}else if(this.items.get(this.block.getSpentFuel()[this._FuelRodin]) >= this.getMaximumAccepted(this.items.get(this.block.getSpentFuel()[this._FuelRodin]))){this._ControlRodLevel = 0}};
        if(this.CoolantinOrder() && this.liquids.get(this.block.getHeatedUp()[this._Coolantin]) > 0 && !this._RuningState[3]){var maxOutput = Math.min(this.liquids.get(this.block.getHeatedUp()[this._Coolantin]), 60);if (this.dumpLiquid(this.block.getHeatedUp()[this._Coolantin],maxOutput)){this.liquids.remove(this.block.getHeatedUp()[this._Coolantin],maxOutput)}};
        
        //排气阀排出蒸汽
        if(this._ExhaustValve && this._CoreSteamVolume > 0.01  && !this._RuningState[3]){this._CoreSteamVolume -= 0.01};
        if(this._CoreSteamVolume < 0.01){this._CoreSteamVolume = 0};
        //蒸汽泄漏时自扣血
        if(this._RuningState[0]){this.health -= 2;if(this.health <= 0){this.kill()};this._CoreSteamVolume -= 0.01};
        //蒸汽爆炸后堆芯内水蒸发
        if(this._RuningState[1] && this._ReactorCoreTemperature > 100){this._CoreCoolantVolume -= 1;this._ReactorCoreHA -= 4200 * 70;this._CoreSteamVolume += 1};
        //检查反应堆供电状态
        if(this.block.getModel().needPower){this.RuningState3()};
        
        //检查反应堆状态
        if(this._BriefingTimer < 0){this.computeRuningState();this._BriefingTimer = 1}else{this._BriefingTimer -= 1/60};
        //移动控制棒
        if(!this._RuningState[3]){this._ControlRod = this._ControlRodLevel * 5 + (this._ControlRod - this._ControlRodLevel * 5) * Math.exp(-1 /600);if(this.block.getModel().needPower){this._RPS -= 2 * (this._ControlRod - this._ControlRodLevel) / 100}};
        
        //热量产生,消耗燃料棒
        if(this.CorenotNull()){this.heatGenerate()};
        //判断核心融毁
        if(this.CorenotNull() && !this._RuningState[2]){this.RuningState2()};
        //计算堆芯压力
        if(this.ReactorCorenotNull()){this.computeCorePressure()};
        //判断蒸汽泄漏和蒸汽爆炸
        if(this._CoreSteamVolume > 0){this.RuningState0();this.RuningState1()};
        //热量传导
        if(this.CorenotNull() && this.ReactorCorenotNull()){this.heatConduction0to1()};
        if(this._CoreCoolantVolume > 50 && this.ECnotNull()){this.heatConduction1to2()};
        if(this.ECnotNull() && !this.ECOutputnotFull() && this._WaterPump){this.heatConduction2to()}else{this._OutputSpeed = 0};
        
        //更新温度
        if(this.CorenotNull()){this.computeCoreTemperature()}else{this._CoreTemperature = 0};
        if(this.ReactorCorenotNull()){this.computeReactorCoreTemperature()}else{this._ReactorCoreTemperature = 0}
        if(this.ECnotNull()){this.computeECTemperature()}else{this._ECTemperature = 0}
    };
    
    //记录反应堆运行状态，记录器每秒更新一次
    //I.蒸汽泄漏，蒸汽爆炸，核心融毁
    //II.供电端离线，核心温度过高，堆芯压力过高，堆芯水量不足，堆芯温度过高
    this._BriefingTimer = 0;
    this._RuningState = [false,false,false,false,false,false,false,false];
    this._RuningStateblBriefing = "正常";
    this._RuningStateblAssessment = 0;
    this.getRuningState = function(){return this._RuningState};
    this.getRuningStateblBriefing = function(){return this._RuningStateblBriefing};
    this.getRuningStateblAssessment  = function(){return this._RuningStateblAssessment};
    this.computeRuningState = function(){
        if(this._RuningState[2]){this._RuningStateblBriefing = "核心融毁";this._RuningStateblAssessment = 2;return};
        if(this._RuningState[1]){this._RuningStateblBriefing = "蒸汽爆炸";this._RuningStateblAssessment = 2;return};
        if(this._RuningState[0]){this._RuningStateblBriefing = "蒸汽泄漏";this._RuningStateblAssessment = 2;return};
        if(this._RuningState[3]){this._RuningStateblBriefing = "供电不足";this._RuningStateblAssessment = 1;return};
        if(this.getCoreTemperature() > 2560){this._RuningStateblBriefing = "核心温度过高";this._RuningStateblAssessment = 1;this._RuningState[4] = true;return}else{this._RuningState[4] = false};
        if(this.getReactorCoreP() > (this.block.getModel().MaxPressure + this.block.getModel().MinPressure) / 2){this._RuningStateblBriefing = "堆心压力过高";this._RuningStateblAssessment = 1;this._RuningState[5] = true;return}else{this._RuningState[5] = false};
        if(this.getCoreWaterVolume() < this.block.getModel().MaxCoreCoolant){this._RuningStateblBriefing = "堆芯水量不足";this._RuningStateblAssessment = 1;this._RuningState[6] = true;return}else{this._RuningState[6] = false};
        if(this.getReactorCoreTemperature() > 335){this._RuningStateblBriefing = "堆芯温度过高";this._RuningStateblAssessment = 1;this._RuningState[7] = true;return}else{this._RuningState[7] = false};
        this._RuningStateblBriefing = "正常";
        this._RuningStateblAssessment = 0;
    };
    
    //换料器添加燃料棒
    this._FillingTimer = 0;
    this.FuelRodFilling = function(){
        if(!this.block.getModel().needPower || !this._RuningState[3]){
            this._FillingTimer = Math.max(0, this._FillingTimer - 1/60);
            if(this.block.getModel().needPower){this._RPS -= 1};
            if (this._FillingTimer <= 0) {
                if (this.items.get(this.block.getFuelRodSupport()[this._FuelRodin]) > 0){
                    this.items.remove(this.block.getFuelRodSupport()[this._FuelRodin], 1);
                    this._FuelRodAmoumt += 1;
                    this._FillingTimer = 3;
                }
            }
        }
    };
    
    //注水器添加硼酸水
    this.CoreCoolantinOrder = function(){
        if(!this.block.getModel().needPower || !this._RuningState[3]){
            if(this.liquids.get(Vars.content.getByName(ContentType.liquid,this.block.getModel().CoreCoolant)) > 0.8){
                this.liquids.remove(Vars.content.getByName(ContentType.liquid,this.block.getModel().CoreCoolant),0.8 * Math.exp(-(Math.log(100) / 3) * (this._ReactorCoreP - 15)));
                this._CoreCoolantVolume += 0.04 * Math.exp(-(Math.log(100) / 3) * (this._ReactorCoreP - 15));
            };
            if(this._CoreCoolantVolume > this.block.getModel().MaxCoreCoolant - 0.04){
                this._CoreCoolantVolume = this.block.getModel().MaxCoreCoolant;
            }
        }
    };
    
    //中子通量产生，产热计算，消耗计算
    this.heatGenerate = function(){
        var fuelrods = this.block.getFuelRods()[this._FuelRodin];
        var receivedFlux = this._Flux * this._ControlRod / 100;
        this._CoreHA += receivedFlux * fuelrods.HurtperFlux;
        if(fuelrods.Functions[0] == 0){
            var releasedFlux = fuelrods.Functions[1] * this._ControlRod / 100;
        }else if(fuelrods.Functions[0] == 1){
            var releasedFlux = Math.log10(receivedFlux / fuelrods.Functions[1] + fuelrods.Functions[2]) * fuelrods.Functions[3];
        }else if(fuelrods.Functions[0] == 2){
            var releasedFlux = Math.sqrt(receivedFlux + fuelrods.Functions[1]) * fuelrods.Functions[2];
        }else if(fuelrods.Functions[0] == 3){
            var releasedFlux = receivedFlux * fuelrods.Functions[1] + fuelrods.Functions[2];
        }
        this._Flux = releasedFlux * this._FuelRodAmoumt + this._NeutronSource;
        //燃料棒消耗
        this._FuelRodinUsed += receivedFlux;
        if(this._FuelRodinUsed > 10000000000 * fuelrods.Durable){
            this._FuelRodAmoumt -= 1;
            this.items.add(this.block.getSpentFuel()[this._FuelRodin], 1);
            this._FuelRodinUsed = 0;
        };
    };
    
    //堆芯压力推算，堆芯蒸汽积量推算
    this.computeCorePressure = function(){
        if(!this.ReactorCorenotFull() && this._ReactorCoreTemperature > 343){
            this._CoreCoolantVolume -= 1;
            this._ReactorCoreHA -= 4200 * 313;
            this._CoreSteamVolume += 1;
        }else if(this.ReactorCorenotFull() && this._ReactorCoreTemperature > 343){
            this._CoreCoolantVolume -= 1;
            this._ReactorCoreHA -= 4200 * 313;
            this._CoreSteamVolume += 1;
        };
        if(this._CoreSteamVolume !== 0){
            var Steammol = this._CoreSteamVolume * 1000 * 0.018
            var SteamP = Steammol * 8.314 * (this._ReactorCoreTemperature + 273.15) / (this.block.getModel().MaxCoreCoolant - this._CoreCoolantVolume);
            if(!this._RuningState[1]){this._ReactorCoreP = SteamP / 1000000 + this.block.getModel().MinPressure};
        };
    };
    
    //核心向堆芯导热推算
    this.heatConduction0to1 = function(){
        var heatConductionNumber = this.block.getModel().Parameter[1] * this.block.getModel().Parameter[2] * this._FuelRodAmoumt * (this._CoreCoolantVolume / this.block.getModel().MaxCoreCoolant) *(this._CoreTemperature - this._ReactorCoreTemperature) / 60;
        this._CoreHA -= heatConductionNumber;
        this._ReactorCoreHA += heatConductionNumber;
    };
    
    //堆芯向二回路导热推算
    this.heatConduction1to2 = function(){
        var percentage = this.liquids.get(this.block.getCoolantsSupport()[this._Coolantin]) / this.block.liquidCapacity;
        var heatConductionNumber = this.block.getModel().Parameter[3] * this.block.getModel().Parameter[4] * percentage * (this._ReactorCoreTemperature - this._ECTemperature) / 60;
        this._ReactorCoreHA -= heatConductionNumber;
        this._ECHA += heatConductionNumber;
    };
    
    //二回路热量导出推算(能按公式把热量换到这里来，当然是尽量全部转化了)
    this.heatConduction2to = function(){
        var coolants = this.block.getCoolants()[this._Coolantin];
        if(this._ECTemperature < coolants.BoilingPoint){this._OutputSpeed = 0;return}; //沸点不够直接返回
        var ECHAsave = coolants.ThermalCapacity * 50 * (coolants.BoilingPoint - 30) * this.liquids.get(this.block.getCoolantsSupport()[this._Coolantin]); //计算应保留的积热
        var ECHAOutput = this._ECHA - ECHAsave; //计算应输出的积热
        var minOutputNeed = coolants.ThermalCapacity * 50 * (coolants.BoilingPoint - 30) / 10; //计算进行0.1每单位输出所需的最小热值
        if(ECHAOutput < minOutputNeed){this._OutputSpeed = 0;return}else{
            this._OutputSpeed = Math.floor(ECHAOutput / minOutputNeed / 60); //计算输出的速度
            this.liquids.remove(this.block.getCoolantsSupport()[this._Coolantin], this._OutputSpeed * 0.1)
            this.handleLiquid(this,this.block.getHeatedUp()[this._Coolantin], this._OutputSpeed * 0.05); //增加热冷却剂，这里取一半是因为不知道为什么输出会翻倍
            this._ECHA -= this._OutputSpeed * minOutputNeed; //减少消耗的热值
        }//应输出的积热大于进行每单位输出所需的最小热值时，开始输出
    };
    
    //输出速度
    this._OutputSpeed = 0;
    this.getOutputSpeed = function(){
        return this._OutputSpeed;
    };
    
    //核心温度推算
    this.computeCoreTemperature = function(){
        this._CoreTemperature = this._CoreHA / 165 / this._FuelRodAmoumt + 30;
    };
    
    //堆芯温度推算
    this.computeReactorCoreTemperature = function(){
        this._ReactorCoreTemperature = this._ReactorCoreHA / 4200 / this._CoreCoolantVolume + 30;
    };
    
    //二回路温度推算
    this.computeECTemperature = function(){
        var thermalcapacity = this.block.getCoolants()[this._Coolantin].ThermalCapacity;
        this._ECTemperature = this._ECHA / (thermalcapacity * 50) / this.liquids.get(this.block.getCoolantsSupport()[this._Coolantin]) + 30;
    };
    
    //快速切换燃料棒，冷却剂界面
    this.buildConfiguration = function(table) {
        table.table(cons(buttonTable => {
            buttonTable.add("[accent]快速燃料棒切换  换料器:").left().padRight(5);
            var switchButton = buttonTable.button(Tex.pane, Styles.clearTogglei, 40, () => {
                this._RefuelingDevice = !this._RefuelingDevice;
            }).get();
            switchButton.update(() => {
                switchButton.clearChildren();
                if (this._RefuelingDevice) {
                    switchButton.add("已启用").color(Color.green);
                } else {
                    switchButton.add("已禁用").color(Color.red);
                }
            });
        })).left().row();
        table.add("[lightgray]只能在核心空置时切换").left().row();
        //table.add("当前使用的燃料棒方案序号: " + this._FuelRodin).left().row();
        var buttonGroup1 = table.table(Styles.none, buttonTable => {
            var group1 = new ButtonGroup();
            group1.setMinCheckCount(0);
            group1.setMaxCheckCount(1);        
            for(var i = 0; i < this.block.getFuelRodSupport().length; i++) {
                (function(i, that) {
                    var button = buttonTable.button(Tex.pane, 40, () => {
                        if(!that.CorenotNull()) {
                            that._FuelRodin = i;
                        }
                    }).group(group1).get();               
                    button.getStyle().up = Styles.black3;
                    button.getStyle().down = Styles.flatOver;
                    button.getStyle().checked = Styles.accentDrawable;
                    //button.getStyle().setDisabled = Styles.flatOver;
                    button.getStyle().imageUp = new TextureRegionDrawable(that.block.getFuelRodSupport()[i].uiIcon);
                    button.update(() => {
                        button.setChecked(i == that._FuelRodin);
                        button.setDisabled(that.CorenotNull() || that.FuelRodCache());
                    });
                })(i, this);
            };
        }).left().get();    
        table.row();
        table.table(cons(buttonTable => {
            buttonTable.add("[accent]快速冷却剂切换  换水泵:").left().padRight(5);
            var switchButton = buttonTable.button(Tex.pane, Styles.clearTogglei, 40, () => {
                this._WaterPump = !this._WaterPump;
            }).get();
            switchButton.update(() => {
                switchButton.clearChildren();
                if (this._WaterPump) {
                    switchButton.add("已启用").color(Color.green);
                } else {
                    switchButton.add("已禁用").color(Color.red);
                }
            });
        })).left().row();
        table.add("[lightgray]只能在换热空置时切换").left().row();
        //table.add("当前使用的冷却剂方案序号: " + this._Coolantin).left().row();
        var buttonGroup2 = table.table(Styles.none, buttonTable => {
            var group2 = new ButtonGroup();
            group2.setMinCheckCount(0);
            group2.setMaxCheckCount(1);        
            for(var i = 0; i < this.block.getCoolantsSupport().length; i++) {
                (function(i, that) {
                    var button = buttonTable.button(Tex.pane, 40, () => {
                        if(!that.ECnotNull()) {
                            that._Coolantin = i;
                        }
                    }).group(group2).get();               
                    button.getStyle().up = Styles.black3;
                    button.getStyle().down = Styles.flatOver;
                    button.getStyle().checked = Styles.accentDrawable;
                    button.getStyle().imageUp = new TextureRegionDrawable(that.block.getCoolantsSupport()[i].uiIcon);
                    button.update(() => {
                        button.setChecked(i == that._Coolantin);
                        button.setDisabled(that.ECnotNull());
                    });
                })(i, this);
            };
        }).left().get();
        table.row();
        var controlRow = table.table().left().get();
        controlRow.defaults().padRight(4);
        controlRow.add("[accent]注水器:").left();
        var waterPumpButton = controlRow.button(Tex.pane, Styles.clearTogglei, 40, () => {
            this._InternalWaterPump = !this._InternalWaterPump;
        }).get();
        waterPumpButton.update(() => {
            waterPumpButton.clearChildren();
            if (this._InternalWaterPump) {
                waterPumpButton.add("已启用").color(Color.green);
            } else {
                waterPumpButton.add("已禁用").color(Color.red);
            }
        });
        controlRow.add().width(10);
        controlRow.add("[accent]排气阀:").left();
        var exhaustButton = controlRow.button(Tex.pane, Styles.clearTogglei, 40, () => {
            this._ExhaustValve = !this._ExhaustValve;
        }).get();
        exhaustButton.update(() => {
            exhaustButton.clearChildren();
            if (this._ExhaustValve) {
                exhaustButton.add("已启用").color(Color.green);
            } else {
                exhaustButton.add("已禁用").color(Color.red);
            }
        });
        controlRow.add().width(10);
        controlRow.add("[accent]中子源:").left();
        var NeutronSourceSud = controlRow.button(Tex.pane, Styles.clearTogglei, 40, () => {
            this._NeutronSource -= 5;
            if(this._NeutronSource < 0){this._NeutronSource = 0};
        }).get();
        NeutronSourceSud.update(() => {
            NeutronSourceSud.clearChildren();
            NeutronSourceSud.add(" < ").color(Color.yellow);
        });
        controlRow.defaults().padRight(2);
        var NeutronSourceButton = controlRow.button(Tex.pane, Styles.clearTogglei, 40, () => {
            this._NeutronSource += 1;
            if(this._NeutronSource > 50){this._NeutronSource = 10};
        }).get();
        NeutronSourceButton.update(() => {
            NeutronSourceButton.clearChildren();
            NeutronSourceButton.add("  " + this._NeutronSource + "  ").color(Color.yellow);
        });
        controlRow.defaults().padRight(2);
        var NeutronSourceAdd = controlRow.button(Tex.pane, Styles.clearTogglei, 40, () => {
            this._NeutronSource += 5;
            if(this._NeutronSource > 50){this._NeutronSource = 50};
        }).get();
        NeutronSourceAdd.update(() => {
            NeutronSourceAdd.clearChildren();
            NeutronSourceAdd.add(" > ").color(Color.yellow);
        });
        table.row();
        table.add("[accent]控制棒:").left().row();
        var buttonGroup3 = table.table(Styles.none, buttonTable => {
        var group3 = new ButtonGroup();
        group3.setMinCheckCount(0);
        group3.setMaxCheckCount(1);
            for(var i = 0; i < 21; i++) {
               (function(i, that) {
                    var button = buttonTable.button(Tex.pane, 20, () => {
                        that._ControlRodLevel = i;
                    }).group(group3).get();
                    button.getStyle().up = Styles.black3;
                    button.getStyle().down = Styles.flatOver;
                    button.getStyle().checked = Styles.accentDrawable;
                    button.getStyle().imageUp = Styles.none;
                    button.update(() => {
                       button.setChecked(i == that._ControlRodLevel);
                    });
                })(i, this);
            };
        }).left().get();
        
    };
    
    //物品输入检查
    this.acceptItem = function(source, item){
        if(this.FuelRodOrder()){
            var fuelRod = this.block.getFuelRodSupport()[this._FuelRodin];
            if(item !== fuelRod) return false;
            return this.items.get(item) < this.getMaximumAccepted(item);
        };
        return false;
    };
    
    //流体输入检查
    this.acceptLiquid = function(source, liquid) {
        var acceptliquid = false
        if(this._WaterPump){
            var corecoolant = Vars.content.getByName(ContentType.liquid,this.block.getModel().CoreCoolant);
            if(liquid == corecoolant) acceptliquid = true;
            if(acceptliquid) return this.liquids.get(liquid) < this.block.liquidCapacity;
        };
        if(this.CoolantinOrder() && this._WaterPump){
            var coolant = this.block.getCoolantsSupport()[this._Coolantin];
            if(liquid == coolant) acceptliquid = true;
            if(acceptliquid) return this.liquids.get(liquid) < this.block.liquidCapacity;
        };
        return false;
    };
    
    //中子通量
    this._Flux = 0;
    this.getFlux = function() {
        return this._Flux;
    };
    //中子源
    this._NeutronSource = 10;
    this.getNeutronSource = function() {
        return this._NeutronSource;
    };
    //控制棒的预定等级
    this._ControlRodLevel = 0;
    this.getControlRodLevel = function() {
        return this._ControlRodLevel;
    };
    //控制棒的拔出程度
    this._ControlRod = 0;
    this.getControlRod = function() {
        return this._ControlRod;
    };
    //燃料棒数量
    this._FuelRodAmoumt = 0;
    this.getFuelRodAmoumt = function() {
        return this._FuelRodAmoumt;
    };
    //当前燃料棒消耗
    this._FuelRodinUsed = 0;
    this.FuelRodinUsed = function() {
        return this._FuelRodinUsed;
    };
    //核心内装填的燃料棒种类
    this._FuelRodin = -1;
    this.getFuelRodin = function() {
        return this._FuelRodin;
    };
    //二回路使用的冷却剂种类
    this._Coolantin = -1;
    this.getCoolantin = function() {
        return this._Coolantin;
    };
    //排气阀 Exhaust Valve
    this._ExhaustValve = false;
    this.getExhaustValve = function() {
        return this._ExhaustValve;
    };
    //核心积热(KJ) Core Heat Accumulation
    this._CoreHA = 0;
    this.getCoreHA = function() {
        return this._CoreHA;
    };
    //核心温度
    this._CoreTemperature = 30;
    this.getCoreTemperature = function() {
        return this._CoreTemperature;
    };
    //堆芯积热(KJ) Reactor Core Heat Accumulation
    this._ReactorCoreHA = 0;
    this.getReactorCoreHA = function() {
        return this._ReactorCoreHA;
    };
    //堆芯温度
    this._ReactorCoreTemperature = 30;
    this.getReactorCoreTemperature = function() {
        return this._ReactorCoreTemperature;
    };
    //堆芯压力 Reactor Core Pressure
    this._ReactorCoreP = 15;
    this.getReactorCoreP = function() {
        return this._ReactorCoreP;
    };
    //堆芯冷却剂量(t) Core Coolant Volume
    this._CoreCoolantVolume = 0;
    this.getCoreWaterVolume = function() {
        return this._CoreCoolantVolume;
    };
    //堆芯蒸汽积量(t) Core Steam Volume
    this._CoreSteamVolume = 0;
    this.getCoreSteamVolume = function() {
        return this._CoreSteamVolume;
    };
    //二回路积热(外循环，KJ) External Circulation Heat Accumulation
    this._ECHA = 0;
    this.getECHA = function() {
        return this._ECHA;
    };
    //二回路温度
    this._ECTemperature = 30;
    this.getECTemperature = function() {
        return this._ECTemperature;
    };
    //换料器 Refueling Device
    this._RefuelingDevice = false;
    this.getRefuelingDevice = function() {
        return this._RefuelingDevice;
    };
    //注水器 InternalWaterPump
    this._InternalWaterPump = false;
    this.getInternalWaterPump = function() {
        return this._InternalWaterPump;
    };
    //换水泵 WaterPump
    this._WaterPump = false;
    this.getWaterPump = function() {
        return this._WaterPump;
    };
    //预备电源 Reserve Power Supply
    this._RPS = 0;
    this.getRPS = function() {
        return this._RPS;
    };
    
    this.write = function(write) {
    this.super$write(write);
    write.f(this._Flux);
    write.i(this._NeutronSource);
    write.f(this._ControlRodLevel);
    write.f(this._ControlRod);
    write.i(this._FuelRodAmoumt);
    write.d(this._FuelRodinUsed);
    write.i(this._FuelRodin);
    write.i(this._Coolantin);
    write.bool(this._ExhaustValve);
    write.f(this._CoreHA);
    write.f(this._CoreTemperature);
    write.f(this._ReactorCoreHA);
    write.f(this._ReactorCoreTemperature);
    write.f(this._ReactorCoreP);
    write.f(this._CoreCoolantVolume);
    write.f(this._CoreSteamVolume);
    write.f(this._ECHA);
    write.f(this._ECTemperature);
    write.bool(this._RefuelingDevice);
    write.bool(this._WaterPump);
    write.bool(this._InternalWaterPump);
    write.i(this._RPS);
    write.i(this._OutputSpeed);
    };

    this.read = function(read, revision) {
    this.super$read(read, revision);
    this._Flux = read.f();
    this._NeutronSource = read.i();
    this._ControlRodLevel = read.f();
    this._ControlRod = read.f();
    this._FuelRodAmoumt = read.i();
    this._FuelRodinUsed = read.d();
    this._FuelRodin = read.i();
    this._Coolantin = read.i();
    this._ExhaustValve = read.bool();
    this._CoreHA = read.f();
    this._CoreTemperature = read.f();
    this._ReactorCoreHA = read.f();
    this._ReactorCoreTemperature = read.f();
    this._ReactorCoreP = read.f();
    this._CoreCoolantVolume = read.f();
    this._CoreSteamVolume = read.f();
    this._ECHA = read.f();
    this._ECTemperature = read.f();
    this._RefuelingDevice = read.bool();
    this._WaterPump = read.bool();
    this._InternalWaterPump = read.bool();
    this._RPS = read.i();
    this._OutputSpeed = read.i();
    };
};

//这个函数定义了多配方合成器的方块（Block）行为。
function PWRBlock() {
    // 初始化型号参数
    var Model = {};
    this.getModel = function(){return Model};
    // 初始化燃料棒详情表
    var FuelRods = [];
    this.getFuelRods = function(){return FuelRods};
    //初始化冷却剂详情表
    var Coolants = [];
    this.getCoolants = function(){return Coolants};
    // 初始化受支持燃料棒表
    var FuelRodSupportSet = [];
    this.getFuelRodSupport = function(){return FuelRodSupportSet};
    // 初始化乏燃料表
    var SpentFuelSet = [];
    this.getSpentFuel = function(){return SpentFuelSet};
    // 初始化受支持冷却剂表
    var CoolantsSupportSet = [];
    this.getCoolantsSupport = function(){return CoolantsSupportSet};
    // 初始化热冷却剂表
    var HeatedUpSet = [];
    this.getHeatedUp = function(){return HeatedUpSet};
    
    //这里不用管
    this._invFrag = extend(BlockInventoryFragment,{_built: false,isBuilt(){return this._built},visible: false,isShown(){return this.visible},showFor(t){this.visible = true;this.super$showFor(t)},hide(){this.visible = false;this.super$hide()},build(parent){this._built = true;this.super$build(parent)}});
    this.getInvFrag = function(){return this._invFrag};
    
    //初始化方块，解析配方
    this.init = function() {
        
        var pwr = this.pwrModel;
        Model = {
            MinPressure: pwr.MinPressure || 0, //堆芯初始压力
            MaxPressure: pwr.MaxPressure || 0, //堆芯最大压力
            MaxFuelRod: pwr.MaxFuelRod || 0, //堆芯燃料棒容量
            MaxCoreCoolant: pwr.MaxCoreCoolant || 0, //堆芯冷却器容量
            CoreCoolant: pwr.CoreCoolant || "", //堆芯冷却剂
            Parameter: pwr.Parameter || [], //参数组
            needPower: pwr.needPower || false, //运行是否耗电
        };
        if(Model.needPower){
            this.consumesPower = true;
            this.consumeBuilder.add(extend(ConsumePower, {
                requestedPower(entity) {
                    if(entity.getRPS() < 180000) return 14;
                    return 0;
                }
            }));
        }
        for(var i = 0; i < this.pwrFuelRods.length; i++) {
            var pwr = this.pwrFuelRods[i];
            FuelRods[i] = {
                FuelRodSupport: pwr.FuelRodSupport || "", //受支持的燃料棒
                SpentFuel: pwr.SpentFuel || "", //对应的乏燃料
                RadiationFunction: pwr.RadiationFunction || "", //函数类型评估
                Functions: pwr.Functions || [], //函数对应的重要参数
                HurtperFlux: pwr.HurtperFlux || 0,//每接收中子通量产生的热值(KJ)
                Durable: pwr.Durable || 0, //耐用性(倍)
            };
            FuelRodSupportSet.push(Vars.content.getByName(ContentType.item,FuelRods[i].FuelRodSupport));
            SpentFuelSet.push(Vars.content.getByName(ContentType.item,FuelRods[i].SpentFuel));
        };
        for(var i = 0; i < this.pwrCoolants.length; i++) {
            var pwr = this.pwrCoolants[i];
            Coolants[i] = {
                CoolantsSupport: pwr.CoolantsSupport || "", //受支持的冷却剂
                HeatedUp: pwr.HeatedUp || "", //对应的热冷却剂
                BoilingPoint: pwr.BoilingPoint || 0,//冷却剂的沸点
                ThermalCapacity: pwr.ThermalCapacity || 0, //冷却剂的热容量(KJ/.KG*'C)
            }
            CoolantsSupportSet.push(Vars.content.getByName(ContentType.liquid,Coolants[i].CoolantsSupport));
            HeatedUpSet.push(Vars.content.getByName(ContentType.liquid,Coolants[i].HeatedUp));
        };
        this.super$init();
    };
    
    this.setStats = function() {
        this.super$setStats();
        if(Model.needPower){this.stats.add(Stat.powerUse,600,StatUnit.powerSecond)};
        this.stats.remove(Stat.productionTime);
        this.stats.add(Stat.input, new JavaAdapter(StatValue, {
            display(table) {
                table.table(Styles.none, function(groupTable) {
                    groupTable.table(Styles.grayPanel, function(view) {
                        view.add().size(8).row();
                        view.add("[accent]堆芯参数 ").left().row();
                        view.add().size(12).row();
                        view.add("[lightgrey]  运行压力: " + Model.MinPressure + " 兆帕").left().row();
                        view.add("[lightgrey]  极限压力: " + Model.MaxPressure + " 兆帕").left().row();
                        view.add("[lightgrey]  燃料棒容量: " + Model.MaxFuelRod + " 组").left().row();
                        view.add("[lightgrey]  冷却剂容量: " + Model.MaxCoreCoolant + " 吨").left().row();
                        view.add("[lightgrey]  冷却剂: ").left().row();
                        view.add(new StatValues.displayLiquid(Vars.content.getByName(ContentType.liquid,Model.CoreCoolant), 1 , false)).left().row();
                        if(Model.needPower){view.add("[white]  运行需要电力维持").left().row()};
                        //view.add("[grey]  比热容: " + Model.Parameter / 1000 + " KJ/KG*'C").left().row();
                    }).pad(7).left().row();
                    for(var f = 0; f < FuelRods.length; f++){
                        groupTable.table(Styles.none, function(view) {
                            if(f == 0){
                                view.add().size(8).row();
                                view.add("[accent]受支持的燃料棒: ").left().row();
                                view.add().size(12).row();
                            };
                            view.table(Styles.grayPanel, function(part) {
                                part.add(new StatValues.displayItem(FuelRodSupportSet[f], 1, true)).left().row();
                                part.add("[lightgrey]  对应乏燃料").left().row();
                                part.add(new StatValues.displayItem(SpentFuelSet[f], 1, true)).left().row();
                                part.add("[lightgrey]  函数类型").left().row();
                                part.add("    " + FuelRods[f].RadiationFunction).left().row();
                                if(FuelRods[f].Functions[0] == 0){
                                    part.add("[grey]    " + FuelRods[f].Functions[1]).left().row(); //CONSTANT
                                }else if(FuelRods[f].Functions[0] == 1){
                                    part.add("[grey]    log10(x / " + FuelRods[f].Functions[1] + " + " + FuelRods[f].Functions[2] + ") * " + FuelRods[f].Functions[3]).left().row(); //LOGARITHMIC
                                }else if(FuelRods[f].Functions[0] == 2){
                                    part.add("[grey]    sqrt(x + " + FuelRods[f].Functions[1] + ") * " + FuelRods[f].Functions[2]).left().row(); //SQUARE ROOT
                                }else if(FuelRods[f].Functions[0] == 3){
                                    part.add("[grey]    x * " + FuelRods[f].Functions[1] + " + " + FuelRods[f].Functions[2]).left().row(); //LINEAR
                                };
                                part.add("[lightgrey]  热值产量/接收通量: " + FuelRods[f].HurtperFlux + " KJ").left().row();
                                part.add("[lightgrey]  耐用性: " + FuelRods[f].Durable + " 倍").left().row();
                            })
                        }).pad(7).left().row();
                    };
                    for(var c = 0; c < Coolants.length; c++){
                        groupTable.table(Styles.none, function(view) {
                            if(c == 0){
                                view.add().size(8).row();
                                view.add("[accent]受支持的冷却剂: ").left().row();
                                view.add("[grey]二回路冷却剂").left().row();
                                view.add().size(12).row();
                            };
                            view.table(Styles.grayPanel, function(part) {
                                part.add(new StatValues.displayLiquid(CoolantsSupportSet[c], 1 , false)).left().row();
                                part.add("[lightgrey]  对应热冷却剂").left().row();
                                part.add(new StatValues.displayLiquid(HeatedUpSet[c], 1 , false)).left().row();
                                part.add("[lightgrey]  冷却剂参数").left().row();
                                part.add("[grey]    沸点: " + Coolants[c].BoilingPoint + " 'C").left().row();
                                part.add("[grey]    热容: " + Coolants[c].ThermalCapacity + " KJ/ KG*'C").left().row();
                            })
                        }).pad(7).left().row();
                    };
                })
            }
        }));
    };
    
    // 设置进度条
    this.setBars = function() {
        this.super$setBars();
        this.removeBar("liquid");
        this.removeBar("items");
        this.removeBar("power");
        
        if(this.getModel().needPower){
            this.addBar("power", entity => new Bar(
                () => "反应堆内电源",
                () => Color.valueOf("ddaa33"),
                () => entity.getRPS() / 180000,
            ));
        };
        
        this.addBar("Running", entity => new Bar(
            () => entity.getRuningStateblBriefing(),
            () => {if(entity.getRuningStateblAssessment() == 2){return Color.valueOf("c01818")}else if(entity.getRuningStateblAssessment() == 1){return Color.valueOf("fafa20")}else{return Color.valueOf("12de12")}},
            () => 1,
        ));
        
        this.addBar("FuelRod", entity => new Bar(
            () => "燃料棒数量",
            () => Color.valueOf("265626"),
            () => entity.getFuelRodAmoumt() / entity.block.getModel().MaxFuelRod,
        ));
        
        this.addBar("FuelRodUsed", entity => new Bar(
            () => {if(entity.FuelRodOrder()){return "当前燃料棒消耗: " + Math.floor(entity.FuelRodinUsed() / (100000000 * FuelRods[entity.getFuelRodin()].Durable)) + " %"}else{return "未装载燃料棒"}},
            () => Color.valueOf("265626"),
            () => {if(entity.FuelRodOrder()){return 1 - entity.FuelRodinUsed() / (10000000000 * FuelRods[entity.getFuelRodin()].Durable)}else{return 0}},
        ));
        
        this.addBar("ControlRod", entity => new Bar(
            () => "控制棒拨出程度",
            () => Color.valueOf("565656"),
            () => 1 - entity.getControlRod() / 100,
        ));
        
        this.addBar("Flux", entity => new Bar(
            () => "中子通量: " + Math.floor(entity.getFlux()),
            () => Color.valueOf("e9e9ab"),
            () => entity.getFlux() / 100000,
        ));
        
        this.addBar("CoreHA", entity => new Bar(
            () => "核心温度: " + Math.floor(entity.getCoreTemperature()) + " 'C",
            () => Color.valueOf("c12626"),
            () => entity.getCoreTemperature() / 2660,
        ));
        
        this.addBar("ReactorCoreP", entity => new Bar(
            () => "堆芯压力: " + Math.round(entity.getReactorCoreP() * 10) / 10 + " 兆帕",
            () => Color.valueOf("dfdfdf"),
            () => (entity.getReactorCoreP() - 14.8) / (entity.block.getModel().MaxPressure - entity.block.getModel().MinPressure),
        ));
        
        this.addBar("CoreWaterVolume", entity => new Bar(
            () => "堆芯水量",
            () => Color.valueOf("2323ef"),
            () => entity.getCoreWaterVolume() / entity.block.getModel().MaxCoreCoolant,
        ));
        
        this.addBar("ReactorCoreHA", entity => new Bar(
            () => "堆芯温度: " + Math.floor(entity.getReactorCoreTemperature()) + " 'C",
            () => Color.valueOf("c12626"),
            () => entity.getReactorCoreTemperature() / 340,
        ));
        
        this.addBar("ECHA", entity => new Bar(
            () => "换热温度: " + Math.floor(entity.getECTemperature()) + " 'C",
            () => Color.valueOf("c12626"),
            () => entity.getECTemperature() / 300,
        ));
        
        this.addBar("EC", entity => new Bar(
            () => "换热容量",
            () => {if(entity.getCoolantin() < 0) return Color.valueOf("000000");var coolant = entity.block.getCoolantsSupport()[entity.getCoolantin()];return coolant.barColor == null ? coolant.color : coolant.barColor},
            () => {if(entity.getCoolantin() < 0) return 0;var coolant = entity.block.getCoolantsSupport()[entity.getCoolantin()];return entity.liquids.get(coolant) / entity.block.liquidCapacity},
        ));

        this.addBar("outputspeed", entity => new Bar(
            () => "输出速率: " + entity.getOutputSpeed() * 6 + " /秒",
            () => {if(entity.getCoolantin() < 0) return Color.valueOf("000000");var heated = entity.block.getHeatedUp()[entity.getCoolantin()];return heated.barColor == null ? heated.color : heated.barColor},
            () => {if(entity.getCoolantin() < 0) return 0;var heated = entity.block.getHeatedUp()[entity.getCoolantin()];return entity.liquids.get(heated) / entity.block.liquidCapacity},
        ));
        
    };
}

function cloneObject(obj) {
    var clone = {};
    for(var i in obj) {
        if(typeof obj[i] == "object" && obj[i] != null) clone[i] = cloneObject(obj[i]);
        else clone[i] = obj[i];
    }
    return clone;
}//深拷贝对象，用于复制额外的实体定义。

//模块导出
module.exports = {
    PWR(Type, EntityType, name, model, fuelrods, coolants, def, ExtraEntityDef) {
        const block = new PWRBlock();// 创建PWRBlock实例
        Object.assign(block, def);// 将传入的def属性复制到block
        const pwr = extend(Type, name, block);//使用传入的Type（如Block）创建新方块
        pwr.buildType = () => extend(EntityType, pwr, Object.assign(new PWRBuild(), typeof ExtraEntityDef == "function" ? new ExtraEntityDef() : cloneObject(ExtraEntityDef)));// 设置方块的构建类型（即实体类型），组合了PWRBuild和额外定义
        pwr.configurable = true;// 设置方块可配置
        pwr.hasItems = true;// 设置方块有物品
        pwr.hasLiquids = true;// 设置方块有流体
        pwr.hasPower = true;// 设置方块有功率
        pwr.pwrModel = model;// 传入的型号参数
        pwr.pwrFuelRods = fuelrods;// 传入的配方数组
        pwr.pwrCoolants = coolants;// 传入的冷却剂数组
        pwr.saveConfig = true;// 保存配置
        return pwr;
    }
}
