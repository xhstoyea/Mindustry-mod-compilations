
function TradeBuild() {
    
    //实体创建的第一帧更新
    this.Init = function(){
        if(this.block.getModel().RegionalRestrictions){
            this._RegionalRestrictions = true;
            
        }else{
            //初始化价格变动量表
            for(var i = 0;i < this.block.getOrders().length;i++){
                this._PriceVariationlist.push(0);
            };
            //初始化实际价格表
            for(var i = 0;i < this.block.getOrders().length;i++){
                this._ActualPrice.push(this.block.getPricelist()[i]);
            };
            
        }
    };
    
    this._Timer = 0;
    //每帧更新实体
    this.updateTile = function(){
        if(!this._init){this.Init();this._init = true};//只调用一次(无语)
        this._Timer += 1;
        if(this._Timer < 60){return}else{this._Timer = 0};
        if(this._RegionalRestrictions){
            this._turnover0();
        }else{
            this._turnover1();
        }//实际每秒刷新一次
    };
    
    //区域限制更新
    this._turnover0 = function(){
        
    };
    //不受区域限制更新
    this._turnover1 = function(){
        if(this._turnover1Timer1 > 0){this._turnover1Timer1 -= 1}else{this._turnover1Timer1 = 0};//更新贸易冷却时间
        if(this._turnover1Timer2 >= 60){
            for(var i = 0;i < this._PriceVariationlist.length;i++){
                if(!this.block.getBSlist()[i]){
                    this._PriceVariationlist[i] -= this.block.getModel().DeflationRate;
                    if(this._PriceVariationlist[i] < 0){this._PriceVariationlist[i] = 0};
                };//买入降低通膨
                if(this.block.getBSlist()[i]){
                    this._PriceVariationlist[i] -= this.block.getModel().InflationRate;
                    if(this._PriceVariationlist[i] < 0){this._PriceVariationlist[i] = 0};
                };//售出降低紧缩
                if(!this.block.getBSlist()[i]){
                    this._ActualPrice[i] = Math.floor(this.block.getPricelist()[i] * (1 + this._PriceVariationlist[i]));
                };//买入价格增长
                if(this.block.getBSlist()[i]){
                    this._ActualPrice[i] = Math.floor(this.block.getPricelist()[i] / (1 + this._PriceVariationlist[i]));
                };//售出价格降低
            };//更新货物价格
            this._turnover1Timer2 = 0;
        }else{this._turnover1Timer2 += 1};
    };
    
    //创建贸易界面
    this.buildConfiguration = function(table) {
        table.table(cons(buttonTable => {
            buttonTable.add("[accent]该贸易站本位货币: ").left().row();
            buttonTable.add(new StatValues.displayItem(this.block.getStandard(), this.block.getBPP(), true)).left().row();
            buttonTable.add("[grey]整数付清 不设找补").left();
            buttonTable.add("[grey]离柜概不退换").left().row();
            //buttonTable.add("[white]贸易冷却时间: " + this._turnover1Timer1 + " [white]秒").left().row();
            var group = new ButtonGroup();
            group.setMinCheckCount(0);
            group.setMaxCheckCount(1);
            for(var i = 0; i < this.block.getOrders().length; i++) {
                (function(i, that) {
                    var button = buttonTable.button(Tex.pane, 40, () => {
                        if(that._RegionalRestrictions){
                            that.delivery0();
                        }else{
                            that.delivery1(that.block.getBSlist()[i],that.block.getGoodslist()[i],that.block.getTradeVolumelist()[i],i);
                        };
                    }).group(group).get();
                    button.getStyle().up = Styles.black3;
                    button.getStyle().down = Styles.flatOver;
                    button.getStyle().checked = Styles.accentDrawable;
                    button.update(() => {
                        button.setDisabled(that._turnover1Timer1 > 0);
                        button.clearChildren();
                        button.table(cons(innerTable => {
                            if(that.block.getBSlist()[i]){
                                innerTable.add("[green]售出  " + "[accent]价格: " + that._ActualPrice[i]).left().row();
                            }else{
                                innerTable.add("[red]买进  " + "[accent]价格: " + that._ActualPrice[i]).left().row();
                            };
                            innerTable.add(new StatValues.displayItem(that.block.getGoodslist()[i], that.block.getTradeVolumelist()[i], true));
                        }));
                    });
                    if(i % 3 == 2){
                        buttonTable.row();
                    };
                })(i, this);
            };
        }));
    };
    
    //区域限制交割
    this.delivery0 = function(){
        
    };
    
    //不受区域限制交割(买卖/货物/数量/单号)
    this.delivery1 = function(bs,m,n,i){
        if(bs){
            if(this.items.get(this.block.getStandard()) >= this.getMaximumAccepted(this.block.getStandard())){return};//判断货物是否超载
            var legalTender = Math.floor(this._ActualPrice[i] / this.block.getBPP());
            if(this.items.get(m) < n){return};//计算货物是否足够
            this.items.remove(m,n);//一手交货
            this.items.add(this.block.getStandard(),legalTender);//一手交钱
            this._PriceVariationlist[i] += this.block.getModel().DeflationRate * this.block.getSusceptiblelist()[i];//影响市场
            this._ActualPrice[i] = Math.floor(this.block.getPricelist()[i] / (1 + this._PriceVariationlist[i]));//更新价格
        }else{
            if(this.items.get(m) >= this.getMaximumAccepted(m)){return};//判断货物是否超载
            var legalTender = Math.ceil(this._ActualPrice[i] / this.block.getBPP());
            if(this.items.get(this.block.getStandard()) < legalTender){return};//计算法币是否足够
            this.items.remove(this.block.getStandard(),legalTender);//一手交钱
            this.items.add(m,n);//一手交货
            this._PriceVariationlist[i] += this.block.getModel().InflationRate * this.block.getSusceptiblelist()[i];//影响市场
            this._ActualPrice[i] = Math.floor(this.block.getPricelist()[i] * (1 + this._PriceVariationlist[i]));//更新价格
        };
        this._turnover1Timer1 = this.block.getModel().CoolingTime * 60;
    };
    
    //物品输入检查
    this.acceptItem = function(source, item){
        return this.items.get(item) < this.getMaximumAccepted(item);
        return false;
    };
    
    //被初始化
    this._init = false;
    //不受区域限制 价格变动量
    this._PriceVariationlist = [];
    this.getPriceVariationlist = function(){return this._PriceVariationlist};
    //区域限制记录
    this._RegionalRestrictions = false;
    this.getRegionalRestrictions = function(){return this._RegionalRestrictions};
    //不受区域限制 实际价格
    this._ActualPrice = [];
    this.getActualPrice = function(){return this._ActualPrice};
    //不受区域限制 贸易更新时间
    this._turnover1Timer1 = 0;
    this.getturnover1Timer1 = function(){return this._turnover1Timer1};
    //不受区域限制 价格更新时间
    this._turnover1Timer2 = 0;
    this.getturnover1Timer2 = function(){return this._turnover1Timer2};
    
    this.write = function(write) {
        write.bool(this._init);
        write.i(this._PriceVariationlist.length);
        for (var i = 0; i < this._PriceVariationlist.length; i++) {
            write.f(this._PriceVariationlist[i]);
        }
        write.bool(this._RegionalRestrictions);
        write.i(this._ActualPrice.length);
        for (var i = 0; i < this._ActualPrice.length; i++) {
            write.f(this._ActualPrice[i]);
        }
        write.f(this._turnover1Timer1);
        write.f(this._turnover1Timer2);
    };

    this.read = function(read, revision) {
        this._init = read.bool();
        var priceVarLength = read.i();
        this._PriceVariationlist = [];
        for (var i = 0; i < priceVarLength; i++) {
            this._PriceVariationlist.push(read.f());
        }
        this._RegionalRestrictions = read.bool();
        var actualPriceLength = read.i();
        this._ActualPrice = [];
        for (var i = 0; i < actualPriceLength; i++) {
            this._ActualPrice.push(read.f());
        }
        this._turnover1Timer1 = read.f();
        this._turnover1Timer2 = read.f();
    };
}

function TradeBlock() {
    //初始化贸易参数
    var Model = {};
    this.getModel = function(){return Model};
    //初始化订单数组
    var Orders = [];
    this.getOrders = function(){return Orders};
    //初始化本位货币
    var Standard = "";
    this.getStandard = function(){return Standard};
    //初始化本位货币购买力
    var BPP = 0;
    this.getBPP = function(){return BPP};
    //初始化买卖表
    var BSlist = [];
    this.getBSlist = function(){return BSlist};
    //初始化买卖物表
    var Goodslist = [];
    this.getGoodslist = function(){return Goodslist};
    //初始化买卖量表
    var TradeVolumelist = [];
    this.getTradeVolumelist = function(){return TradeVolumelist};
    //初始化价格浮动系数表
    var Susceptiblelist = [];
    this.getSusceptiblelist = function(){return Susceptiblelist};
    //初始化标价表
    var Pricelist = [];
    this.getPricelist = function(){return Pricelist};
    
    //这里不用管
    this._invFrag = extend(BlockInventoryFragment,{_built: false,isBuilt(){return this._built},visible: false,isShown(){return this.visible},showFor(t){this.visible = true;this.super$showFor(t)},hide(){this.visible = false;this.super$hide()},build(parent){this._built = true;this.super$build(parent)}});
    this.getInvFrag = function(){return this._invFrag};
    
    //初始化方块，解析配方
    this.init = function() {
        Model = {
            Standard: this.Model.Standard || "",//本位货币
            BasicPurchasingPower: this.Model.BasicPurchasingPower || 0,//基础购买力
            InflationRate: this.Model.InflationRate || 0,//通货膨胀率
            DeflationRate: this.Model.DeflationRate || 0,//通货紧缩率
            CoolingTime: this.Model.CoolingTime || 0,//贸易冷却时间
            RegionalRestrictions: this.Model.RegionalRestrictions || false,//区域限制
        };
        Standard = Vars.content.getByName(ContentType.item,Model.Standard);
        BPP = Model.BasicPurchasingPower;
        for(var i = 0;i < this.Orders.length; i++) {
            var order = this.Orders[i];
            Orders[i] = {
                BuyorSell: order.BuyorSell || false,//买/卖
                Goods: order.Goods || "",//买卖物
                TradeVolume: order.TradeVolume || 0,//贸易量
                Susceptible: order.Susceptible || 0,//价格浮动系数
                Price: order.Price || 0,//标准价格
                //Group: order.Group || "",//贸易分组
            }
            BSlist.push(Orders[i].BuyorSell);
            Goodslist.push(Vars.content.getByName(ContentType.item,Orders[i].Goods));
            TradeVolumelist.push(Orders[i].TradeVolume);
            Susceptiblelist.push(Orders[i].Susceptible);
            Pricelist.push(Orders[i].Price);
        };
        this.super$init();
    };
    
    this.setStats = function() {
        this.super$setStats();
        this.stats.remove(Stat.productionTime);
        this.stats.add(Stat.input, new JavaAdapter(StatValue, {
            display(table) {
                table.table(Styles.none,function(groupTable) {
                    groupTable.table(Styles.grayPanel, function(view) {
                        view.add().size(8).row();
                        view.add("[accent]贸易站规模数据").left().row();
                        view.add().size(12).row();
                        view.add("[lightgrey]  本位货币: ").left().row();
                        view.add(new StatValues.displayItem(Standard, 1, true)).left().row();
                        view.add("[lightgrey]  货币购买力: " + Model.BasicPurchasingPower).left().row();
                        view.add("[lightgrey]  通货膨胀率: " + Model.InflationRate * 100 + "% /times * min").left().row();
                        view.add("[lightgrey]  通货紧缩率: " + Model.DeflationRate * 100 + "% /times * min").left().row();
                        view.add("[lightgrey]  贸易冷却时间: " + Model.CoolingTime + "min").left().row();
                        if(Model.RegionalRestrictions){view.add("[white]  区域内该贸易站共享冷却时间").left().row()}
                    }).pad(7).left().row();
                    groupTable.table(Styles.none, function(orders) {
                        for(var o = 0;o < Orders.length; o++){
                            orders.table(Styles.grayPanel, function(view) {
                                if(BSlist[o]){var ov = "[green]售出"}else{var ov = "[red]买进"};
                                view.add(ov).left().row();
                                view.add("[white]货物: ").left().row();
                                view.add(new StatValues.displayItem(Goodslist[o], TradeVolumelist[o], true)).left().row();
                                view.add("[white]标价: " + Pricelist[o]).left().row();
                            }).padRight(20);
                            if(o % 3 == 2){
                                orders.row();
                            }
                        }
                    })
                })
            }
        }))
    };
                        
                        
}

function cloneObject(obj) {
    var clone = {};
    for(var i in obj) {
        if(typeof obj[i] == "object" && obj[i] != null) clone[i] = cloneObject(obj[i]);
        else clone[i] = obj[i];
    }
    return clone;
}//深拷贝对象，用于复制额外的实体定义。

//模块导出
module.exports = {
    Trade(Type, EntityType, name, model, orders, def, ExtraEntityDef) {
        const block = new TradeBlock();// 创建tradeBlock实例
        Object.assign(block, def);// 将传入的def属性复制到block
        const trade = extend(Type, name, block);//使用传入的Type（如Block）创建新方块
        trade.buildType = () => extend(EntityType, trade, Object.assign(new TradeBuild(), typeof ExtraEntityDef == "function" ? new ExtraEntityDef() : cloneObject(ExtraEntityDef)));// 设置方块的构建类型（即实体类型），组合了TradeBuild和额外定义
        trade.configurable = true;// 设置方块可配置
        trade.hasItems = true;// 设置方块有物品
        trade.hasLiquids = true;// 设置方块有流体
        trade.hasPower = true;// 设置方块有功率
        trade.Model = model;// 传入的贸易参数
        trade.Orders = orders;// 传入的订单数组
        trade.saveConfig = true;// 保存配置
        return trade;
    }
}