const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"回转窑", [
    {
		input: {
			items: ["icbm-水泥生料/12","coal/4"],
			power: 0.2,
		},
		output: {
		    items: ["icbm-水泥熟料/12","icbm-矿渣/2"],
		},
        craftTime: 960,
        title: "水泥生产",
	},
	{
		input: {
			items: ["coal/16"],
			power: 0.2,
		},
		output: {
		    items: ["icbm-石墨骨料/12","icbm-矿渣/1"],
		},
        craftTime: 960,
        title: "石墨生产",
	},
	{
		input: {
			items: ["icbm-氢氧化铝/12","coal/4"],
			power: 0.2,
		},
		output: {
		    items: ["icbm-氧化铝/12","icbm-矿渣/2"],
		},
        craftTime: 960,
        title: "铝生产",
	},
	{
		input: {
		    items: ["coal/4"],
			liquids: ["icbm-锌溶液/45"],
			power: 0.2,
		},
		output: {
		    items: ["icbm-氧化锌/6","icbm-矿渣/4"],
		},
        craftTime: 720,
        title: "火法制锌",
	},
	],
);