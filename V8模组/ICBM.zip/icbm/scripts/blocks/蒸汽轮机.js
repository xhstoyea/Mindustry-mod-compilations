const library = require("base/ParameterCrafter-library");
const furnace = library.ParameterCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"蒸汽轮机", [
    {
		input: {
			liquids: ["icbm-超高压蒸汽/1.5"],
		},
		output: {
			liquids: ["icbm-高压蒸汽/1.5"],
			power: 57.5,
		},
        craftTime: 18,
        Enrichmentbegin: 30,
        RERDRthreshold: 30,
        RERDRspeed: 4,
	},
    {
		input: {
			liquids: ["icbm-高压蒸汽/1.5"],
		},
		output: {
			liquids: ["icbm-蒸汽/1.5"],
			power: 55,
		},
        craftTime: 18,
        Enrichmentbegin: 30,
        RERDRthreshold: 30,
        RERDRspeed: 4,
	},
	{
		input: {
			liquids: ["icbm-蒸汽/1.5"],
		},
		output: {
		    liquids: ["icbm-低压蒸汽/1.5"],
		    power: 52.5, //即31.5兆瓦
		},
        craftTime: 18,
        Enrichmentbegin: 30,
        RERDRthreshold: 30,
        RERDRspeed: 4,
	},//每秒处理250千克蒸汽，52.5兆瓦，热效率60%，十千瓦=电单位
	],
);