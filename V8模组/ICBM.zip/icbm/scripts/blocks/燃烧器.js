const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"燃烧器", [
    {
		input: {
			items: ["icbm-芒硝/3","icbm-石灰石/3","coal/4"],
		},
		output: {
		    items: ["icbm-矿渣/6"],
		    liquids: ["icbm-碳酸钠炉气/15"],
		},
        craftTime: 360,
        title: "硫酸钠石灰石混合锻烧",
        group: "路布兰制碱法",
	},
	{
		input: {
			items: ["pyratite/3"],
		},
		output: {
		    items: ["icbm-矿渣/1"],
		    liquids: ["icbm-二氧化硫/10"],
		},
        craftTime: 180,
        title: "硫燃烧",
        group: "硫酸制造",
	},
	],
);