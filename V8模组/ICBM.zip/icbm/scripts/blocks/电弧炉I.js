const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"电弧炉I", [
    {
		input: {
			items: ["icbm-铁精矿/10","icbm-石灰石/2","icbm-工业石墨/2"],
			power: 20
		},
		output: {
		    items: ["icbm-矿渣/2"],
			liquids: ["icbm-铁水/45"],
		},
        craftTime: 960,
        title: "铁冶炼",
        group: "电弧冶炼技术I",
	},
	{
		input: {
			items: ["icbm-铜精矿/10","icbm-石灰石/2","icbm-工业石墨/2"],
			power: 20
		},
		output: {
		    items: ["icbm-矿渣/2"],
			liquids: ["icbm-铜水/45"],
		},
        craftTime: 960,
        title: "铜冶炼",
        group: "电弧冶炼技术I",
	},
	{
	    input: {
			items: ["icbm-石英砂/12","icbm-石灰石/1","icbm-碳酸钠/1","icbm-工业石墨/2"],
			power: 12
		},
		output: {
		    items: ["icbm-矿渣/2"],
			liquids: ["icbm-熔融玻璃/45"],
		},
		stages: [
		    {
		        title: "原料融化",
    		    weight: 30
		    },
		    {
		        title: "澄清处理",
    		    weight: 10
		    },
		    {
		        title: "均化处理",
    		    weight: 10
		    },
		],
        craftTime: 1440,
        title: "玻璃制造",
        group: "电弧冶炼技术I",
	},
	{
	    input: {
			items: ["icbm-生石灰/10","icbm-工业石墨/6"],
			power: 15
		},
		output: {
		    items: ["icbm-矿渣/2"],
		    liquids: ["icbm-熔融电石/45"],
		},
        craftTime: 960,
        title: "电石制造",
        group: "电弧冶炼技术I",
	},
	{
		input: {
			items: ["icbm-氧化铝/10","icbm-工业石墨/2"],
			power: 18
		},
		output: {
		    items: ["icbm-矿渣/2"],
			liquids: ["icbm-铝水/45"],
		},
        craftTime: 960,
        title: "铝熔炼",
        group: "电弧冶炼技术II",
	},
	{
		input: {
			items: ["icbm-精铬铁矿/12","icbm-工业石墨/6"],
			power: 16
		},
		output: {
		    items: ["icbm-矿渣/2"],
			liquids: ["icbm-熔融铬铁/50"],
		},
        craftTime: 960,
        title: "高碳铬铁冶炼",
        group: "电弧冶炼技术II",
	},
	{
		input: {
			items: ["icbm-高碳铬铁/10","icbm-工业石墨/2"],
			liquids: ["icbm-氧气/5","icbm-氩气/1"],
			power: 20
		},
		output: {
		    items: ["icbm-矿渣/2"],
			liquids: ["icbm-不锈钢水/45"],
		},
        craftTime: 960,
        title: "不锈钢冶炼",
        group: "电弧冶炼技术II",
	},
	],
);