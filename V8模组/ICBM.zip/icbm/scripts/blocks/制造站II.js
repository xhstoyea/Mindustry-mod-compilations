const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"制造站II", [
	{
		input: {
		    items: ["icbm-钢锭/6"],
		    power: 0.5
		},
		output: {
			items: ["icbm-机械零件I/12"],
	    },
        craftTime: 360,
        title: "钢制工件生产",
        group: "金属加工",
	},
	{
		input: {
		    items: ["icbm-机械零件I/8","icbm-混凝土楼板/4"],
		    power: 1
		},
		output: {
			items: ["icbm-机械组件I/2"],
	    },
        craftTime: 360,
        title: "机械组件生产I",
        group: "金属加工",
	},
	{
		input: {
		    items: ["icbm-机械零件I/4","icbm-不锈钢锭/2","icbm-混凝土楼板/4"],
		    power: 1
		},
		output: {
			items: ["icbm-机械组件I/3"],
	    },
        craftTime: 360,
        title: "机械组件生产II",
        group: "金属加工",
	},
	{
		input: {
		    items: ["icbm-不锈钢锭/4"],
		    liquids: ["icbm-乙炔/5"],
		    power: 0.5
		},
		output: {
			items: ["icbm-机械零件II/8"],
	    },
        craftTime: 360,
        title: "不锈钢工件生产",
        group: "金属加工",
	},
	{
		input: {
		    items: ["icbm-机械零件II/4","icbm-不锈钢锭/2","icbm-混凝土楼板/4"],
		    power: 1
		},
		output: {
			items: ["icbm-机械组件II/3"],
	    },
        craftTime: 480,
        title: "重型机械组件生产",
        group: "金属加工",
	},
	{
		input: {
		    items: ["icbm-铜锭/6","icbm-玻璃件/3"],
		    power: 0.5
		},
		output: {
			items: ["icbm-电子元件I/3"],
	    },
        craftTime: 360,
        title: "电子元件生产",
        group: "电气加工",
	},
	],
);