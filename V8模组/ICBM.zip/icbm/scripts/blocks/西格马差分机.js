const library = require("base/ParameterCrafter-library");
const furnace = library.ParameterCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"西格马差分机", [
    {
		input: {
			items: ["copper/8"],
		},
		output: {
			items: ["icbm-铜精矿/20","icbm-铁精矿/15","scrap/35"],
		},
        craftTime: 480,
        craftbyWeight: true,
        craftTimes: 8,
        title: "铜纤石分离",
	},
	{
		input: {
			items: ["lead/8"],
		},
		output: {
			items: ["icbm-铅精矿/25","icbm-锌焙砂/15","icbm-粗银/1","scrap/35"],
		},
        craftTime: 480,
        craftbyWeight: true,
        craftTimes: 8,
        title: "铅碌石分离",
	},
	{
		input: {
			items: ["titanium/8"],
		},
		output: {
			items: ["icbm-海棉钛/20","icbm-铁精矿/15","scrap/35"],
		},
        craftTime: 480,
        craftbyWeight: true,
        craftTimes: 8,
        title: "钛砇石分离",
	},
	{
		input: {
			items: ["thorium/8"],
		},
		output: {
			items: ["icbm-独居石/40","icbm-铀矿石/1","scrap/35"],
		},
        craftTime: 480,
        craftbyWeight: true,
        craftTimes: 8,
        title: "钍因石分离",
	},
	],
);