const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"回转炉I", [
    {
		input: {
			items: ["icbm-铁锭/12","coal/6"],
		},
		output: {
		    items: ["icbm-矿渣/6"],
			liquids: ["icbm-钢水/45"],
		},
		stages: [
		    {
		        title: "熔融精炼",
    		    weight: 40
		    },
		    {
		        title: "吹气降碳",
    		    weight: 30
		    }
		],
        craftTime: 1440,
        title: "钢冶炼",
        group: "初步精炼技术I",
	},
	{
	    input: {
			items: ["icbm-热玻璃件/12","coal/2"],
		},
		output: {
		    items: ["icbm-玻璃件/12","icbm-矿渣/1"],
		},
		stages: [
		    {
		        title: "退火",
    		    weight: 20
		    },
		],
		craftTime: 1440,
	    title: "玻璃退火",
        group: "初步精炼技术I",
	},
	{
	    input: {
			items: ["coal/4"],
			liquids: ["icbm-氢氧化钙溶液/30"],
		},
		output: {
		    items: ["icbm-氢氧化钙/2","icbm-矿渣/2",],
		},
		craftTime: 720,
	    title: "氢氧化钙制造",
        group: "初步精炼技术I",
	}
	],
);