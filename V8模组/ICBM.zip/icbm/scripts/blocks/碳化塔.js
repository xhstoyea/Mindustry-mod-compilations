const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"碳化塔", [
	{
		input: {
		    items: ["coal/4"],
		    liquids: ["icbm-氢氧化钙溶液/30"/*,"icbm-二氧化碳/10"*/],
		},
		output: {
			items: ["icbm-碳酸钙/2","icbm-矿渣/2"],
			liquids: ["icbm-废水/20"],
	    },
        craftTime: 720,
        title: "碳酸钙制造",
	},//小型碳化塔是用煤顺便碳化的(？)
	{
		input: {
		    items: ["coal/4"],
		    liquids: ["icbm-氨盐水/20","icbm-氢氧化钙溶液/10"],
		},
		output: {
			items: ["icbm-碳酸氢钠/2","icbm-矿渣/2"],
			liquids: ["icbm-废水/20","icbm-氨气/5"],
	    },
        craftTime: 720,
        title: "碳酸氢钠制造",
	},
	],
);