const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"高炉II", [
	{
		input: {
			items: ["icbm-铁精矿/36","icbm-石灰石/8","coal/20"],
		},
		output: {
		    items: ["icbm-矿渣/24"],
			liquids: ["icbm-铁水/135"],
		},
		stages: [
		    {
		        title: "第一次冶炼",
    		    weight: 30
		    },
		    {
		        title: "第二次冶练",
    		    weight: 30
		    }
		],
        craftTime: 1440,
        title: "铁冶炼",
        group: "冶炼技术I",
	},
	{
		input: {
			items: ["icbm-铜精矿/36","icbm-石灰石/8","coal/20"],
		},
		output: {
		    items: ["icbm-矿渣/24"],
			liquids: ["icbm-铜水/135"],
		},
		stages: [
		    {
		        title: "第一次冶炼",
    		    weight: 30
		    },
		    {
		        title: "第二次冶练",
    		    weight: 30
		    }
		],
        craftTime: 1440,
        title: "铜冶炼",
        group: "冶炼技术I",
	},
	{
		input: {
			items: ["icbm-石灰石/36","coal/24"],
		},
		output: {
		    items: ["icbm-生石灰/32","icbm-矿渣/16"],
		    liquids: ["icbm-二氧化碳/60"],
		},
        craftTime: 1440,
        title: "石灰石锻烧",
        group: "冶炼技术I",
	},
	{
	    input: {
			items: ["icbm-石英砂/36","icbm-石灰石/4","icbm-碳酸钠/4","coal/20"],
		},
		output: {
		    items: ["icbm-矿渣/24"],
			liquids: ["icbm-熔融玻璃/135"],
		},
		stages: [
		    {
		        title: "原料融化",
    		    weight: 30
		    },
		    {
		        title: "澄清处理",
    		    weight: 10
		    },
		    {
		        title: "均化处理",
    		    weight: 10
		    },
		],
        craftTime: 1440,
        title: "玻璃制造",
        group: "冶炼技术I",
	},
	{
		input: {
			items: ["icbm-碳酸氢钠/32","coal/12"],
		},
		output: {
		    items: ["icbm-碳酸钠/30","icbm-矿渣/6"],
		},
        craftTime: 1440,
        title: "碳酸氢钠锻烧",
        group: "索尔维制碱法",
	},
	{
	    input: {
			items: ["icbm-氧化铝/32","coal/12"],
		},
		output: {
		    liquids: ["icbm-铝水/135"],
		    items: ["icbm-矿渣/6"],
		},
        craftTime: 1440,
        title: "铝熔炼",
        group: "冶炼技术II",
	},
	{
	    input: {
			items: ["icbm-氧化锌/24","coal/20"],
		},
		output: {
		    items: ["icbm-锌锭/18","icbm-矿渣/16"],
		},
        craftTime: 1440,
        title: "火法制锌",
        group: "冶炼技术II",
	},
	{
	    input: {
			items: ["icbm-生石灰/32","coal/24"],
		},
		output: {
		    items: ["icbm-矿渣/26"],
		    liquids: ["icbm-熔融电石/90"],
		},
        craftTime: 1440,
        title: "电石制造",
        group: "冶炼技术II",
	},
	],
);