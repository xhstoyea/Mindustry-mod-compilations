const library = require("base/ParameterCrafter-library");
const furnace = library.ParameterCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"海水蒸发池", [
    {
		input: {
			liquids: ["icbm-海水/60"],
		},
		output: {
		    items: ["icbm-粗盐/1"],
			liquids: ["icbm-卤水/55"],
		},
        craftTime: 180,
        Enrichmentbegin: 10,
        RERDRthreshold: 80,
        RERDRspeed: 1,
        title: "海水蒸发",
	},
	{
		input: {
		    items: ["icbm-粗盐/2","icbm-氢氧化钙/1"],
			liquids: ["water/30"],
		},
		output: {
		    items: ["icbm-氢氧化镁/1","icbm-碳酸钙/1"],
			liquids: ["icbm-盐水/30"],
		},
        craftTime: 180,
        Enrichmentbegin: 10,
        RERDRthreshold: 80,
        RERDRspeed: 1,
        title: "粗盐除杂",
	},
	{
		input: {
		    items: ["icbm-生石灰/2"],
			liquids: ["water/30"],
		},
		output: {
			liquids: ["icbm-氢氧化钙溶液/30"],
		},
        craftTime: 180,
        Enrichmentbegin: 5,
        RERDRthreshold: 5,
        RERDRspeed: 20,
        title: "石灰溶解",
	},
	],
);