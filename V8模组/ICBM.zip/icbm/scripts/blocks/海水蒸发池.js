const library = require("base/ParameterCrafter-library");
const furnace = library.ParameterCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"海水蒸发池", [
    {
		input: {
			liquids: ["icbm-海水/60"],
		},
		output: {
		    items: ["icbm-粗盐/1"],
			liquids: ["icbm-卤水/55"],
		},
        craftTime: 360,
        Enrichmentbegin: 10,
        RERDRthreshold: 80,
        RERDRspeed: 1,
        title: "海水蒸发",
	},
	{
		input: {
		    items: ["icbm-粗盐/3","icbm-氢氧化钙/1"],
			liquids: ["water/40"],
		},
		output: {
		    items: ["icbm-氢氧化镁/1","icbm-碳酸钙/1"],
			liquids: ["icbm-饱和盐水/20"],
		},
        craftTime: 360,
        Enrichmentbegin: 10,
        RERDRthreshold: 80,
        RERDRspeed: 1,
        title: "粗盐除杂",
	},
	{
		input: {
			liquids: ["icbm-饱和盐水/10"],
		},
		output: {
		    items: ["icbm-氯化钠/1"],
		},
        craftTime: 180,
        Enrichmentbegin: 10,
        RERDRthreshold: 80,
        RERDRspeed: 1,
        title: "精盐凉晒",
	},
	{
		input: {
		    items: ["icbm-生石灰/2"],
			liquids: ["water/30"],
		},
		output: {
			liquids: ["icbm-氢氧化钙溶液/30"],
		},
        craftTime: 180,
        Enrichmentbegin: 5,
        RERDRthreshold: 5,
        RERDRspeed: 20,
        title: "石灰溶解",
	},
	{
		input: {
			liquids: ["water/10","icbm-碳酸钠炉气/10"],
		},
		output: {
			items: ["icbm-碳酸钠/1"],
			liquids: ["icbm-废水/5"],
	    },
        craftTime: 180,
        Enrichmentbegin: 5,
        RERDRthreshold: 5,
        RERDRspeed: 20,
        title: "路布兰制碱法",
	},
	{
		input: {
			liquids: ["icbm-饱和盐水/10","icbm-氨气/5"],
		},
		output: {
		    liquids: ["icbm-氨盐水/10"],
		},
        craftTime: 180,
        Enrichmentbegin: 10,
        RERDRthreshold: 80,
        RERDRspeed: 1,
        title: "索尔维制碱法",
	},
	],
);