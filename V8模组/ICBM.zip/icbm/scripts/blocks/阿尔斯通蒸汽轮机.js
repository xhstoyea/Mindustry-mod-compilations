const library = require("base/ParameterCrafter-library");
const furnace = library.ParameterCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"阿尔斯通蒸汽轮机", [
    {
		input: {
			liquids: ["icbm-超高压蒸汽/11.2"],
		},
		output: {
			liquids: ["icbm-低压蒸汽/11.2"],
			power: 2916.5,
		},
        craftTime: 6,
        Enrichmentbegin: 30,
        RERDRthreshold: 30,
        RERDRspeed: 1,
	},
	],//效率约50%，净输出1750兆瓦
);