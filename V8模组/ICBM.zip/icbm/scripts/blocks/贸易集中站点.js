const library = require("base/Trade-library");

const model = {
    Standard: "icbm-银锭",
    BasicPurchasingPower: 10,
    InflationRate: 0.05,
    DeflationRate: 0.05,
    CoolingTime: 0.25,
    RegionalRestrictions: false,
}

const orders = [
    {
        BuyorSell: true,
        Goods: "icbm-粗银",
        TradeVolume: 50,
        Susceptible: 0,
        Price: 100,
    },
    {
        BuyorSell: true,
        Goods: "icbm-瓷器",
        TradeVolume: 30,
        Susceptible: 2,
        Price: 200,
    },
    {
        BuyorSell: true,
        Goods: "icbm-铅糖",
        TradeVolume: 60,
        Susceptible: 10,
        Price: 60,
    },
    {
        BuyorSell: false,
        Goods: "icbm-石灰石",
        TradeVolume: 50,
        Susceptible: 1,
        Price: 20,
    },
    {
        BuyorSell: false,
        Goods: "icbm-粗盐",
        TradeVolume: 50,
        Susceptible: 1,
        Price: 20,
    },
    {
        BuyorSell: false,
        Goods: "coal",
        TradeVolume: 50,
        Susceptible: 1,
        Price: 20,
    },
    {
        BuyorSell: false,
        Goods: "icbm-石膏",
        TradeVolume: 50,
        Susceptible: 1,
        Price: 20,
    },
    {
        BuyorSell: false,
        Goods: "icbm-芒硝",
        TradeVolume: 50,
        Susceptible: 1,
        Price: 20,
    },
    {
        BuyorSell: false,
        Goods: "icbm-粘土",
        TradeVolume: 50,
        Susceptible: 1,
        Price: 20,
    },
    {
        BuyorSell: false,
        Goods: "icbm-铁精矿",
        TradeVolume: 50,
        Susceptible: 1,
        Price: 30,
    },
    {
        BuyorSell: false,
        Goods: "icbm-铜精矿",
        TradeVolume: 50,
        Susceptible: 1,
        Price: 30,
    },
    {
        BuyorSell: false,
        Goods: "icbm-精铬铁矿",
        TradeVolume: 50,
        Susceptible: 2,
        Price: 50,
    },
    {
        BuyorSell: false,
        Goods: "icbm-铝土矿",
        TradeVolume: 50,
        Susceptible: 1,
        Price: 40,
    },
]

const furnace = library.Trade(GenericCrafter,GenericCrafter.GenericCrafterBuild,"贸易集中站点",model,orders);