const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"电碳化塔", [
	{
		input: {
		    liquids: ["icbm-氢氧化钙溶液/30","icbm-二氧化碳/10"],
		    power: 2,
		},
		output: {
			items: ["icbm-碳酸钙/2"],
			liquids: ["icbm-废水/20"],
	    },
        craftTime: 360,
        title: "碳酸钙制造",
	},
	{
		input: {
		    liquids: ["icbm-氨盐水/20","icbm-氢氧化钙溶液/10","icbm-二氧化碳/10"],
		    power: 2,
		},
		output: {
			items: ["icbm-碳酸氢钠/2"],
			liquids: ["icbm-废水/20","icbm-氨气/5"],
	    },
        craftTime: 360,
        title: "碳酸氢钠制造",
	},
	],
);