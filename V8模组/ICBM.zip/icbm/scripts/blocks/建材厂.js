const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"建材厂", [
	{
		input: {
		    items: ["icbm-水泥/4","sand/8","scrap/16"],
			liquids: ["water/20"],
			power: 2.5
		},
		output: {
			items: ["icbm-混凝土楼板/30"],
	    },
        craftTime: 480,
        title: "废料混凝土",
        group: "混凝土制造",
	},
	{
		input: {
		    items: ["icbm-水泥/4","sand/8","icbm-矿渣/16"],
			liquids: ["water/20"],
		    power: 2.5
		},
		output: {
			items: ["icbm-混凝土楼板/30"],
	    },
        craftTime: 480,
        title: "矿渣混凝土",
        group: "混凝土制造",
	},
	{
		input: {
		    items: ["icbm-混凝土楼板/30","icbm-钢锭/12"],
		    power: 3
		},
		output: {
			items: ["icbm-建材I/30"],
	    },
        craftTime: 960,
        title: "基础建材生产",
        group: "建材制造",
	},
	{
		input: {
		    items: ["icbm-建材I/30","icbm-电子元件I/12"],
		    power: 4
		},
		output: {
			items: ["icbm-建材II/30"],
	    },
        craftTime: 960,
        title: "电气建筑建材生产",
        group: "建材制造",
	},
	],
);