const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"营造法式", [
	{
		input: {
		    items: ["sand/4","scrap/4","coal/4"],
			liquids: ["water/10"],
		},
		output: {
			items: ["icbm-混凝土楼板/3"],
	    },
        craftTime: 600,
        title: "砖块制造",
	},
	{
		input: {
		    items: ["icbm-混凝土楼板/3","copper/3"],
		},
		output: {
			items: ["icbm-建材I/2"],
	    },
        craftTime: 600,
        title: "建材制造",
	},
	],
);