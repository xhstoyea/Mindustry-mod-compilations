const library = require("base/ParameterCrafter-library");
const furnace = library.ParameterCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"选矿设备I", [
    {
		input: {
			items: ["sand/8"],
			liquids: ["water/12"],
		},
		output: {
			items: ["icbm-石英砂/60","scrap/30"],
		},
        craftTime: 480,
        craftbyWeight: true,
        craftTimes: 8,
        title: "石英砂提纯",
	},
	],
);