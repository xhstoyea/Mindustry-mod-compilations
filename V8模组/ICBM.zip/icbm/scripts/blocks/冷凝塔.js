const library = require("base/ParameterCrafter-library");
const furnace = library.ParameterCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"冷凝塔", [
    {
		input: {
			liquids: ["icbm-低压蒸汽/2"],
		},
		output: {
			liquids: ["water/1.6"],
		},
        craftTime: 12,
        Enrichmentbegin: 5,
        RERDRthreshold: 5,
        RERDRspeed: 4,
	},
	],
);