
	
	{
		input: {
			items: ["beryllium/8"],
		},
		output: {
			items: [/*"icbm-铍矿石/10","icbm-铝土矿石/20",*/"scrap/35"],
		},
        craftTime: 480,
        craftbyWeight: true,
        craftTimes: 8,
        title: "铍柱石分离",
	},
	{
		input: {
			items: ["tungsten/8"],
		},
		output: {
			items: [/*"icbm-钨矿石/20",*/"icbm-铁精矿/20","scrap/35"],
		},
        craftTime: 480,
        craftbyWeight: true,
        craftTimes: 8,
        title: "钨冈石分离",
	},