const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"砖厂", [
	{
		input: {
		    items: ["icbm-石灰石/16","coal/8"],
			liquids: ["water/20"],
		},
		output: {
			items: ["icbm-混凝土楼板/12"],
	    },
        craftTime: 1080,
        title: "砖块制造I",
	},
	{
		input: {
		    items: ["icbm-混凝土楼板/16","icbm-铁锭/8"],
		},
		output: {
			items: ["icbm-建材I/12"],
	    },
        craftTime: 540,
        title: "建材制造I",
	},
	],
);