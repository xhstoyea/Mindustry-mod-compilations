const library = require("base/PWR-library");

const model = {
    MinPressure: 15,
    MaxPressure: 17,
    MaxFuelRod: 60,
    MaxCoreCoolant: 200,
    CoreCoolant: "icbm-硼酸水",
    Parameter: [4200,0.8,24,5,8000],
    needPower: true,
}

const fuelrods = [
    {
        FuelRodSupport: "icbm-低丰度U235核燃料组件",
        SpentFuel: "icbm-低丰度U235核燃料组件(乏-热)",
        RadiationFunction: "[green]SAFE/LOGARITHMIC",
        Functions: [1,2400,1,150],
        HurtperFlux: 1,
        Durable: 1,
	},//大约214兆瓦
	{
        FuelRodSupport: "icbm-MOX核燃料组件",
        SpentFuel: "icbm-MOX核燃料组件(乏-热)",
        RadiationFunction: "[yellow]MEDIUM/LOGARITHMIC",
        Functions: [1,2400,1,180],
        HurtperFlux: 1,
        Durable: 0.8,
	},//大约344兆瓦
	{
        FuelRodSupport: "thorium",
        SpentFuel: "scrap",
        RadiationFunction: "[green]SAFE/SQUARE ROOT",
        Functions: [2,15,5],
        HurtperFlux: 0.03,
        Durable: 0.015,
	},//大约162兆瓦
	{
        FuelRodSupport: "phase-fabric",
        SpentFuel: "silicon",
        RadiationFunction: "[green]SAFE/CONSTANT",
        Functions: [0,160],
        HurtperFlux: 0.3,
        Durable: 1.5,
	},//大约173兆瓦
	{
        FuelRodSupport: "surge-alloy",
        SpentFuel: "metaglass",
        RadiationFunction: "[red]DANGEROUS/LINEAR",
        Functions: [3,0.02,0.5],
        HurtperFlux: 4,
        Durable: 0.6,
	},//安全运行大约400兆瓦
]
const coolants = [
    {
        CoolantsSupport: "water",
        HeatedUp: "icbm-蒸汽",
        BoilingPoint: 160,
        ThermalCapacity: 4.2,
    },
        {
        CoolantsSupport: "water",
        HeatedUp: "icbm-高压蒸汽",
        BoilingPoint: 210,
        ThermalCapacity: 4.2,
    },
    {
        CoolantsSupport: "water",
        HeatedUp: "icbm-超高压蒸汽",
        BoilingPoint: 260,
        ThermalCapacity: 4.2,
    },
]

const furnace = library.PWR(GenericCrafter,GenericCrafter.GenericCrafterBuild,"PWR",model,fuelrods,coolants);