const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"制造站I", [
	{
		input: {
		    items: ["coal/2","icbm-铁锭/4"],
		},
		output: {
			items: ["icbm-机械零件I/6"],
	    },
        craftTime: 360,
        title: "铁制工件生产",
        group: "金属加工",
	},
	{
		input: {
		    items: ["coal/2","icbm-钢锭/4"],
		},
		output: {
			items: ["icbm-机械零件I/8"],
	    },
        craftTime: 360,
        title: "钢制工件生产",
        group: "金属加工",
	},
	{
		input: {
		    items: ["coal/2","icbm-机械零件I/4","icbm-混凝土楼板/2"],
		},
		output: {
			items: ["icbm-机械组件I/1"],
	    },
        craftTime: 360,
        title: "机械组件生产",
        group: "金属加工",
	},
	{
		input: {
		    items: ["coal/2","icbm-铜锭/4","icbm-玻璃件/2"],
		},
		output: {
			items: ["icbm-电子元件I/1"],
	    },
        craftTime: 360,
        title: "电子元件生产",
        group: "电气加工",
	},
	],
);