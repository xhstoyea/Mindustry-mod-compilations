const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"球磨机", [
	{
		input: {
		    items: ["icbm-石灰石/6","icbm-粘土/6"],
		    power: 1
		},
		output: {
			items: ["icbm-水泥生料/12"],
	    },
        craftTime: 480,
        title: "生料制备",
        group: "水泥生产",
	},
	{
		input: {
		    items: ["icbm-水泥熟料/12","icbm-石膏/4"],
		    power: 1
		},
		output: {
			items: ["icbm-水泥/16"],
	    },
        craftTime: 480,
        title: "粉磨熟料",
        group: "水泥生产",
	},
	{
		input: {
		    items: ["icbm-石墨骨料/12"],
		    power: 1
		},
		output: {
			items: ["icbm-粉碎石墨骨料/12"],
	    },
        craftTime: 480,
        title: "粉磨骨料",
        group: "石墨生产",
	},
	{
		input: {
		    items: ["icbm-铁精矿/8"],
		    power: 1
		},
		output: {
			items: ["icbm-铁基催化剂/8"],
	    },
        craftTime: 240,
        title: "粉磨熟料",
        group: "铁基催化剂生产",
	},
	],
);