const library = require("base/ParameterCrafter-library");
const furnace = library.ParameterCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"氨合成器", [
    {
		input: {
		    items: ["icbm-铁基催化剂/1"],
			liquids: ["nitrogen/2","hydrogen/6"],
			power: 6,
		},
		output: {
		    items: ["icbm-铁基催化剂/98"],
			liquids: ["icbm-氨气/4"],
		},
        craftTime: 20,
        craftbyWeight: true,
        Enrichmentbegin: 80,
        RERDRthreshold: 80,
        RERDRspeed: 2,
        title: "氨合成",
	},
	],
);