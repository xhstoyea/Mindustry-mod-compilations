const library = require("base/ParameterCrafter-library");
const furnace = library.ParameterCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"电解装置", [
    {
		input: {
		    items: ["icbm-粗铜/27"],
			liquids: ["water/40"],
			power: 15
		},
		output: {
		    items: ["icbm-铜锭/21"],
			liquids: ["icbm-废水/40"],
		},
        craftTime: 720,
        Enrichmentbegin: 80,
        RERDRthreshold: 80,
        RERDRspeed: 20,
        title: "一般电解",
        group: "铜精炼",
	},
	{
		input: {
		    items: ["icbm-粗铜/27"],
			liquids: ["water/20","icbm-硫酸/20"],
			power: 12
		},
		output: {
		    items: ["icbm-铜锭/27"],
			liquids: ["icbm-废水/40"],
		},
        craftTime: 720,
        Enrichmentbegin: 80,
        RERDRthreshold: 80,
        RERDRspeed: 20,
        title: "硫酸电解",
        group: "铜精炼",
	},
	{
		input: {
			liquids: ["icbm-饱和盐水/20"],
			power: 12.5
		},
		output: {
		    items: ["icbm-氢氧化钠/2"],
			liquids: ["hydrogen/5","icbm-氯气/5"],
		},
        craftTime: 360,
        Enrichmentbegin: 80,
        RERDRthreshold: 80,
        RERDRspeed: 20,
        title: "食盐水电解",
        group: "氯碱工业",
	},
	{
		input: {
			liquids: ["water/2"],
			power: 18
		},
		output: {
			liquids: ["hydrogen/2","icbm-氧气/1"],
		},
        craftTime: 36,
        Enrichmentbegin: 80,
        RERDRthreshold: 80,
        RERDRspeed: 20,
        title: "水电解",
	},
	{
		input: {
			liquids: ["icbm-铝水/135"],
			power: 20
		},
		output: {
			items: ["icbm-铝锭/27"],
		},
        craftTime: 720,
        Enrichmentbegin: 80,
        RERDRthreshold: 80,
        RERDRspeed: 20,
        title: "氧化铝电解",
	},
	{
		input: {
		    items: ["icbm-锌焙砂/24"],
			liquids: ["water/50","icbm-硫酸/40"],
			power: 9
		},
		output: {
		    items: ["icbm-矿渣/12"],
			liquids: ["icbm-锌溶液/90"],
		},
        craftTime: 720,
        Enrichmentbegin: 80,
        RERDRthreshold: 80,
        RERDRspeed: 20,
        title: "电解浸取",
        group: "锌生产",
	},
	{
		input: {
			liquids: ["icbm-锌溶液/90","icbm-硫酸/30"],
			power: 16
		},
		output: {
		    items: ["icbm-锌锭/15","icbm-矿渣/3"],
		    liquids: ["icbm-废水/90"],
		},
        craftTime: 720,
        Enrichmentbegin: 80,
        RERDRthreshold: 80,
        RERDRspeed: 20,
        title: "湿法制锌",
        group: "锌生产",
	},
	{
		input: {
		    items: ["icbm-钢锭/24","icbm-锌锭/4"],
			liquids: ["icbm-硫酸/20","water/20"],
			power: 22
		},
		output: {
		    items: ["icbm-不锈钢锭/24"],
		},
        craftTime: 720,
        Enrichmentbegin: 80,
        RERDRthreshold: 80,
        RERDRspeed: 20,
        title: "清洗钢板，在熔融锌中镀锌",
        group: "镀锌钢生产",
	},
	],
);