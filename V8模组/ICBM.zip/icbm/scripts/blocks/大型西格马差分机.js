const library = require("base/ParameterCrafter-library");
const furnace = library.ParameterCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"大型西格马差分机", [
    {
		input: {
			items: ["copper/18"],
			power: 4
		},
		output: {
			items: ["icbm-铜精矿/40","icbm-铁精矿/35","scrap/15"],
		},
        craftTime: 480,
        craftbyWeight: true,
        craftTimes: 18,
        title: "铜纤石分离",
	},
	{
		input: {
			items: ["lead/18"],
			power: 4
		},
		output: {
			items: ["icbm-铅精矿/35","icbm-锌焙砂/25","icbm-粗银/2","scrap/15"],
		},
        craftTime: 480,
        craftbyWeight: true,
        craftTimes: 18,
        title: "铅碌石分离",
	},
	{
		input: {
			items: ["titanium/18"],
			power: 4
		},
		output: {
			items: ["icbm-海棉钛/45","icbm-铁精矿/30","scrap/15"],
		},
        craftTime: 480,
        craftbyWeight: true,
        craftTimes: 18,
        title: "钛砇石分离",
	},
	{
		input: {
			items: ["thorium/18"],
			power: 4
		},
		output: {
			items: ["icbm-独居石/70","icbm-铀矿石/2","scrap/15"],
		},
        craftTime: 480,
        craftbyWeight: true,
        craftTimes: 18,
        title: "钍因石分离",
	},
	],
);