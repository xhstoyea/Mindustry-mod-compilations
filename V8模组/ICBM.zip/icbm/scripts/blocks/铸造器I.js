const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"铸造器I", [
    {
		input: {
			liquids: ["icbm-铁水/30"],
		},
		output: {
		    items: ["icbm-铁锭/6"],
		},
        craftTime: 1440,
        title: "铁锭铸造",
        group: "初步铸造技术",
	},
	{
		input: {
			liquids: ["icbm-铜水/30","water/10"],
		},
		output: {
		    items: ["icbm-粗铜/6"],
		},
        craftTime: 1440,
        title: "铜锭铸造",
        group: "初步铸造技术",
	},
	{
		input: {
			liquids: ["icbm-钢水/30"],
		},
		output: {
		    items: ["icbm-钢锭/6"],
		},
        craftTime: 1440,
        title: "钢锭铸造",
        group: "初步铸造技术",
	},
	{
		input: {
			liquids: ["icbm-熔融玻璃/30"],
		},
		output: {
		    items: ["icbm-热玻璃件/6"],
		},
        craftTime: 720,
        title: "玻璃件定型",
        group: "初步铸造技术",
	},
	],
);