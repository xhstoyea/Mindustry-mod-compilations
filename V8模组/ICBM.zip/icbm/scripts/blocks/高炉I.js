const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"高炉I", [
    {
		input: {
			items: ["icbm-铁精矿/18","coal/12"],
		},
		output: {
		    items: ["icbm-矿渣/15"],
			liquids: ["icbm-铁水/45"],
		},
		stages: [
		    {
		        title: "第一次冶炼",
    		    weight: 30
		    },
		    {
		        title: "第二次冶练",
    		    weight: 30
		    }
		],
        craftTime: 1440,
        title: "铁冶炼",
        group: "初步冶炼技术I",
	},
	{
		input: {
			items: ["icbm-铜精矿/18","coal/12"],
		},
		output: {
		    items: ["icbm-矿渣/15"],
			liquids: ["icbm-铜水/45"],
		},
		stages: [
		    {
		        title: "第一次冶炼",
    		    weight: 30
		    },
		    {
		        title: "第二次冶练",
    		    weight: 30
		    }
		],
        craftTime: 1440,
        title: "铜冶炼",
        group: "初步冶炼技术I",
	},
	{
		input: {
			items: ["icbm-石灰石/18","coal/12"],
		},
		output: {
		    items: ["icbm-生石灰/15","icbm-矿渣/9"],
		},
        craftTime: 1440,
        title: "石灰石锻烧",
        group: "初步冶炼技术I",
	},
	{
		input: {
			items: ["icbm-铁精矿/18","icbm-石灰石/4","coal/10"],
		},
		output: {
		    items: ["icbm-矿渣/12"],
			liquids: ["icbm-铁水/60"],
		},
		stages: [
		    {
		        title: "第一次冶炼",
    		    weight: 30
		    },
		    {
		        title: "第二次冶练",
    		    weight: 30
		    }
		],
        craftTime: 1440,
        title: "铁冶炼",
        group: "初步冶炼技术II",
	},
	{
		input: {
			items: ["icbm-铜精矿/18","icbm-石灰石/4","coal/10"],
		},
		output: {
		    items: ["icbm-矿渣/12"],
			liquids: ["icbm-铜水/60"],
		},
		stages: [
		    {
		        title: "第一次冶炼",
    		    weight: 30
		    },
		    {
		        title: "第二次冶练",
    		    weight: 30
		    }
		],
        craftTime: 1440,
        title: "铜冶炼",
        group: "初步冶炼技术II",
	},
	{
	    input: {
			items: ["icbm-石英砂/18","icbm-石灰石/2","icbm-碳酸钠/2","coal/10"],
		},
		output: {
		    items: ["icbm-矿渣/12"],
			liquids: ["icbm-熔融玻璃/60"],
		},
		stages: [
		    {
		        title: "原料融化",
    		    weight: 30
		    },
		    {
		        title: "澄清处理",
    		    weight: 10
		    },
		    {
		        title: "均化处理",
    		    weight: 10
		    },
		],
        craftTime: 1440,
        title: "玻璃制造",
        group: "初步冶炼技术II",
	},
	],
);