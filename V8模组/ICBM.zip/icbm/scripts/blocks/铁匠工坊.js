const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"铁匠工坊", [
	{
		input: {
		    items: ["icbm-铁精矿/8","coal/6"],
		},
		output: {
			items: ["icbm-矿渣/7"],
			liquids: ["icbm-铁水/20"],
	    },
        craftTime: 720,
        title: "冶铁",
        group: "初步冶炼",
	},
	{
		input: {
		    items: ["icbm-铜精矿/8","coal/6"],
		},
		output: {
			items: ["icbm-矿渣/7"],
			liquids: ["icbm-铜水/20"],
	    },
        craftTime: 720,
        title: "冶铜",
        group: "初步冶炼",
	},
	{
		input: {
		    liquids: ["icbm-铁水/20"],
		},
		output: {
			items: ["icbm-铁锭/4"],
	    },
        craftTime: 720,
        title: "铸铁",
        group: "初步铸造",
	},
		{
		input: {
		    liquids: ["icbm-铜水/20"],
		},
		output: {
			items: ["icbm-粗铜/3"],
	    },
        craftTime: 720,
        title: "铸铜",
        group: "初步铸造",
	},
	{
		input: {
		    items: ["icbm-铁锭/3","coal/3"],
		    liquids: ["water/10"],
		},
		output: {
			items: ["icbm-钢锭/2"],
	    },
        craftTime: 720,
        title: "回转炼钢",
        group: "初步精炼",
	},
		{
		input: {
		    items: ["icbm-粗铜/3","coal/3"],
		    liquids: ["water/10"],
		},
		output: {
			items: ["icbm-铜锭/2"],
	    },
        craftTime: 720,
        title: "回转炼铜",
        group: "初步精炼",
	},
	],
);