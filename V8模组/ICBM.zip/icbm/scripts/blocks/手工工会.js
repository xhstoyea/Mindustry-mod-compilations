const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"手工工会", [
	{
		input: {
		    items: ["icbm-铁锭/1"],
		},
		output: {
			items: ["icbm-机械零件I/1"],
	    },
        craftTime: 180,
        title: "铁制工件生产",
        group: "基础金属加工",
	},
	{
		input: {
		    items: ["icbm-钢锭/2"],
		},
		output: {
			items: ["icbm-机械零件I/3"],
	    },
        craftTime: 360,
        title: "钢制工件生产",
        group: "基础金属加工",
	},
	{
		input: {
		    items: ["icbm-机械零件I/4","icbm-混凝土楼板/2"],
		},
		output: {
			items: ["icbm-机械组件I/1"],
	    },
        craftTime: 720,
        title: "机械组件生产",
        group: "基础金属加工",
	},
	{
		input: {
		    items: ["icbm-粗银/3","coal/2"],
		},
		output: {
			items: ["icbm-银锭/1","icbm-矿渣/2"],
	    },
        craftTime: 720,
        title: "炼银术",
        group: "商品制造",
	},
	{
		input: {
		    items: ["icbm-铅精矿/12","spore-pod/16","coal/4"],
		},
		output: {
			items: ["icbm-铅糖/10","icbm-矿渣/2"],
	    },
        craftTime: 1800,
        title: "醋酸铅生产",
        group: "商品制造",
	},
	{
		input: {
		    items: ["metaglass/6","icbm-碳酸钠/1","coal/2"],
		},
		output: {
			items: ["icbm-玻璃件/4","icbm-矿渣/2"],
	    },
        craftTime: 360,
        title: "玻璃件制造",
        group: "资源利用",
	},
	],
);