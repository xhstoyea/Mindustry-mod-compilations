const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"手工工会", [
	{
		input: {
		    items: ["icbm-铁锭/1"],
		},
		output: {
			items: ["icbm-机械零件I/1"],
	    },
        craftTime: 180,
        title: "铁制工件生产",
        group: "基础金属加工",
	},
	{
		input: {
		    items: ["icbm-钢锭/2"],
		},
		output: {
			items: ["icbm-机械零件I/3"],
	    },
        craftTime: 360,
        title: "钢制工件生产",
        group: "基础金属加工",
	},
	{
		input: {
		    items: ["icbm-机械零件I/4","icbm-混凝土楼板/2"],
		},
		output: {
			items: ["icbm-机械组件I/1"],
	    },
        craftTime: 720,
        title: "机械组件生产",
        group: "基础金属加工",
	},
	/*{
		input: {
		    items: ["icbm-机械零件I/4","icbm-混凝土楼板/2"],
		},
		output: {
			items: ["icbm-机械组件I/1"],
	    },
        craftTime: 720,
        title: "玻璃",
        group: "材料研究",
	},*/
	{
		input: {
		    items: ["lead/12","spore-pod/16"],
		},
		output: {
			items: ["icbm-铅糖/10"],
	    },
        craftTime: 1800,
        title: "醋酸铅生产",
        group: "商品制造",
	},
	],
);