const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"回转炉II", [
    {
		input: {
			items: ["icbm-铁锭/27","coal/12"],
			liquids: ["icbm-氧气/10"],
			power: 0.2
		},
		output: {
		    items: ["icbm-矿渣/9"],
			liquids: ["icbm-钢水/120"],
		},
		stages: [
		    {
		        title: "熔融精炼",
    		    weight: 40
		    },
		    {
		        title: "吹气降碳",
    		    weight: 30
		    }
		],
        craftTime: 1440,
        title: "钢冶炼",
        group: "精炼技术I",
	},
	{
	    input: {
			items: ["icbm-热玻璃件/27","coal/2"],
			power: 0.2
		},
		output: {
		    items: ["icbm-玻璃件/27","icbm-矿渣/1"],
		},
		stages: [
		    {
		        title: "退火",
    		    weight: 20
		    },
		],
		craftTime: 1440,
	    title: "玻璃退火",
        group: "精炼技术I",
	},
	{
	    input: {
			items: ["coal/6"],
			liquids: ["icbm-氢氧化钙溶液/60"],
			power: 0.2
		},
		output: {
		    items: ["icbm-氢氧化钙/4","icbm-矿渣/3",],
		},
		craftTime: 720,
	    title: "氢氧化钙制造",
        group: "精炼技术I",
	},
	{
	    input: {
			items: ["icbm-热不锈钢胚/27","coal/2"],
			power: 0.2
		},
		output: {
		    items: ["icbm-不锈钢锭/27","icbm-矿渣/1"],
		},
		stages: [
		    {
		        title: "退火",
    		    weight: 20
		    },
		],
		craftTime: 1440,
	    title: "不锈钢退火",
        group: "精炼技术II",
	},
	],
);