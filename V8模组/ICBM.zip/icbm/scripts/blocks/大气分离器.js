const library = require("base/ParameterCrafter-library");
const furnace = library.ParameterCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"大气分离器", [
    {
		input: {
			power: 2
		},
		output: {
			liquids: ["icbm-压缩大气/1"],
		},
        craftTime: 12,
        title: "大气压缩",
	},
    {
		input: {
		    liquids: ["icbm-压缩大气/1"],
			power: 2
		},
		output: {
			liquids: ["icbm-氧气/0.2","nitrogen/0.7","icbm-氩气/0.01"],
		},
        craftTime: 12,
        Enrichmentbegin: 50,
        RERDRthreshold: 98,
        RERDRspeed: 2,
        title: "大气分离",
	},
	],
);