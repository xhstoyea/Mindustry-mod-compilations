const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"化工厂I", [
    {
		input: {
			liquids: ["icbm-碳酸钠炉气/90","water/20"],
		    power: 5
		},
		output: {
			items: ["icbm-碳酸钠/12"],
	    },
        craftTime: 720,
        title: "碳酸钠提取",
        group: "路布兰制碱法",
	},
	{
		input: {
			liquids: ["icbm-二氧化硫/20","water/20"],
		    power: 7.5
		},
		output: {
			liquids: ["icbm-硫酸/20"],
	    },
	    stages: [
		    {
		        title: "传化为三氧化硫",
    		    weight: 30
		    },
		    {
		        title: "三氧化硫吸收",
    		    weight: 20
		    }
		],
        craftTime: 480,
        title: "硫酸制造",
	},
	{
		input: {
		    items: ["icbm-粉碎石墨骨料/12"],
		    power: 9
		},
		output: {
		    items: ["icbm-工业石墨/10"],
	    },
        craftTime: 360,
        title: "石墨制造",
	},
	{
		input: {
		    items: ["icbm-碳化钙/9"],
			liquids: ["water/45"],
		    power: 0.75
		},
		output: {
		    items: ["icbm-氢氧化钙/9"],
			liquids: ["icbm-乙炔/45"],
	    },
        craftTime: 360,
        title: "乙炔制造",
	},
	{
		input: {
		    items: ["icbm-铝土矿/12","icbm-氢氧化钠/1"],
			liquids: ["water/60"],
		    power: 6
		},
		output: {
		    items: ["icbm-氢氧化铝/6"],
			liquids: ["icbm-红色废液/40"],
	    },
        craftTime: 480,
        title: "铝土矿提炼",
	},
	],
);