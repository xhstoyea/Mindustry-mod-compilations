const library = require("base/MultiCrafter-library");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"铸造器II", [
    {
		input: {
			liquids: ["icbm-铁水/135","water/30"],
		},
		output: {
		    items: ["icbm-铁锭/27"],
		},
        craftTime: 1440,
        title: "铁锭铸造",
        group: "铸造技术",
	},
	{
		input: {
			liquids: ["icbm-铜水/135","water/40"],
		},
		output: {
		    items: ["icbm-粗铜/27"],
		},
        craftTime: 1440,
        title: "铜锭铸造",
        group: "铸造技术",
	},
	{
		input: {
			liquids: ["icbm-钢水/135","water/30"],
		},
		output: {
		    items: ["icbm-钢锭/27"],
		},
        craftTime: 1440,
        title: "钢锭铸造",
        group: "铸造技术",
	},
	{
		input: {
			liquids: ["icbm-熔融铬铁/135"],
		},
		output: {
		    items: ["icbm-高碳铬铁/27"],
		},
        craftTime: 1440,
        title: "高碳铬铁铸造",
        group: "铸造技术",
	},
	{
		input: {
			liquids: ["icbm-不锈钢水/135"],
		},
		output: {
		    items: ["icbm-热不锈钢胚/27"],
		},
        craftTime: 720,
        title: "不锈钢铸造",
        group: "铸造技术",
	},
	{
		input: {
			liquids: ["icbm-熔融玻璃/135"],
		},
		output: {
		    items: ["icbm-热玻璃件/27"],
		},
        craftTime: 720,
        title: "玻璃件定型",
        group: "铸造技术",
	},
	{
		input: {
			liquids: ["icbm-熔融电石/135"],
		},
		output: {
		    items: ["icbm-碳化钙/27"],
		},
        craftTime: 1440,
        title: "电石生产",
        group: "铸造技术",
	},
	],
);