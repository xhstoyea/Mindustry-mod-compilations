const 初代核心 = extend(CoreBlock, "初代核心", {});
exports.初代核心 = 初代核心;
初代核心.category = Category.logic;



const 单位扩充器 = extend(CoreBlock, "单位扩充器", {    canBreak() { return Vars.state.teams.cores(Vars.player.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
	canPlaceOn(tile, team) {
		return Vars.state.teams.cores(team).size < 6;
	},
});
exports.单位扩充器 = 单位扩充器;
单位扩充器.category = Category.logic;

const 次代核心 = extend(CoreBlock, "次代核心", {});
exports.次代核心 = 次代核心;
次代核心.category = Category.logic;

const 重代核心 = extend(CoreBlock, "重代核心", {});
exports.重代核心 = 重代核心;
重代核心.category = Category.logic;




