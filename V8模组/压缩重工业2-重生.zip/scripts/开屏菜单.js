//以下注释为VSHES荔枝独立完成为了让其他开发者同样可以更新开屏显示窗口插件
Events.on(EventType.ClientLoadEvent, cons(e => {
	var dialog = new BaseDialog("[#FF0000FF]压缩重工业");//新建一个显示窗口
	
	dialog.buttons.button("@close", run(() => {
		dialog.hide()//退出此界面
	})).size(128, 64);//按钮用原版@close贴图
		 dialog.cont.button("加入压缩重工业qq群",run(() => {
               Core.app.openURI("http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=-eKzGPr7Bcx0bN3CBfEWpJtwhbTN-7M_&authKey=2IX%2FqIV4eWx3MnEB%2Bh3HccLtE%2FJfACb8lYcDmJSJ1Cs77H2CfX7vULp1yVUPQ4IQ&noverify=0&group_code=219595677");
             })).size(110,70).pad(3);//添加qq群功能为荔枝VSHES添加
		dialog.cont.pane((() => {
			var table = new Table();
			table.add("Hello，这里是压缩工业的第二部 ，具备149以及BE适配 同时剧情将会更加完善 也会将第一部的部分情况给修复！                              本模组主要有很多人制作 主要人员就是  刘  因为刘是原作者  其次就是群作者(1)其主要更新压缩重工业第一部 以及一些提供贴图的成员                      并且本模组目前处于测试内容！            *代表主线 #代表支线 cvd代表挑战").left().growX().wrap().width(340).maxWidth(340).pad(4).labelAlign(Align.left);
			table.row();
			return table;
		})()).grow().center().maxWidth(340);
           dialog.show();
}))
