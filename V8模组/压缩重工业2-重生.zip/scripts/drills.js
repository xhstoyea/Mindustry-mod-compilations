const 铁钻头 = extend(Drill, "铁钻头", {});
exports.铁钻头 = 铁钻头;
铁钻头.category = Category.logic;

const 铜钻头 = extend(Drill, "铜钻头", {});
exports.铜钻头 = 铜钻头;
铜钻头.category = Category.logic;

const 抽水机 = extend(SolidPump, "抽水机", {});
exports.抽水机 = 抽水机;
抽水机.category = Category.logic;