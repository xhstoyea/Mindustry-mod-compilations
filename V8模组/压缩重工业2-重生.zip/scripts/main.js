Vars.renderer.minZoom = 0.1;//最小缩放尺寸
Vars.renderer.maxZoom = 30;//最大缩放尺寸
//Vars.maxSchematicSize = 99;
require("核心");
require("星球");//运行js
require("mapTechTree");
require("library");
require("科技树");
require("物品");
//require("运输");
//require("炮");
require("单位");
//require("单位工厂");
//require("工厂");
require("地形加成");
//require("drills");
require('开屏菜单')
require('工厂')
require('时间加速')