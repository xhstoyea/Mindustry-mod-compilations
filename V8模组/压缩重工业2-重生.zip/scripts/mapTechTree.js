const lib = require("lib");
const {map1,map2,map3,map4,map5,map6,map7,map8,map9,map10,map11,map12,map13,map14} = require('星球');
const {初代核心} = require('核心');




Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map1, {
        parent: '初代核心',
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map2, {
        parent: 'Welcome',
        objectives: Seq.with(
            new Objectives.SectorComplete(map1),
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map3, {
        parent: '岩浆湖',
        objectives: Seq.with(
            new Objectives.SectorComplete(map2),
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map4, {
        parent: '岩浆湖',
        objectives: Seq.with(
            new Objectives.SectorComplete(map2),
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map5, {
        parent: '沿岸点',
        objectives: Seq.with(
            new Objectives.SectorComplete(map3),
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map6, {
        parent: '熔桨溪流',
        objectives: Seq.with(
            new Objectives.SectorComplete(map5),
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map7, {
        parent: '边缘矿区',
        objectives: Seq.with(
            new Objectives.SectorComplete(map6),
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map8, {
        parent: '边缘矿区',
        objectives: Seq.with(
            new Objectives.SectorComplete(map6),
        ),
    });
}))

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map9, {
        parent: '山区',
        objectives: Seq.with(
            new Objectives.SectorComplete(map8),
        ),
    });
}))

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map10, {
        parent: 'Welcome',
        objectives: Seq.with(
            new Objectives.SectorComplete(map8),
        ),
    });
}))

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map11, {
        parent: '冰川地下',
        objectives: Seq.with(
            new Objectives.SectorComplete(map9),
        ),
    });
}))

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map12, {
        parent: '冰川地下',
        objectives: Seq.with(
            new Objectives.SectorComplete(map11),
        ),
    });
}))

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map13, {
        parent: '核爆区',
        objectives: Seq.with(
            new Objectives.SectorComplete(map10),
        ),
    });
}))

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map14, {
        parent: '核爆区',
        objectives: Seq.with(
            new Objectives.SectorComplete(map10),
        ),
    });
}))