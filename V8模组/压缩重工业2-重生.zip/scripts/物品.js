function newItem(name) {
	exports[name] = extend(Item, name, {});
}
function newCellLiquid(name) {
	exports[name] = extend(CellLiquid, name, {});
}
function newLiquid(name) {
	exports[name] = extend(Liquid, name, {});
}
function newBlock(name) {
	exports[name] = extend(Block, name, {});
}
//Item——————————————————
newItem("错误")
newItem("压缩铜")
newItem("压缩铅")
newItem("碳化物")
newItem("压缩石墨")
newItem("压缩玻璃")
newItem("压缩塑钢")
newItem("压缩相织布")
newItem("压缩巨浪合金")
newItem("二重压缩铜")
newItem("铱")
newItem("压缩钛")
newItem("压缩硅")
//ltem——————————————————