function newUnit(name, unitType) {
	const u = extend(UnitType, name, {});
	u.constructor = () => extend(unitType, {});
	return exports[name] = u;
}

/*"flying" -> UnitEntity;
"mech" -> MechUnit;
"legs" -> LegsUnit;
"naval" -> UnitWaterMove;
"payload" -> PayloadUnit;
"missile" -> TimedKillUnit;
"tank" -> TankUnit;
"hover" -> ElevationMoveUnit;
"tether" -> BuildingTetherPayloadUnit;
"crawl" -> CrawlUnit;*/