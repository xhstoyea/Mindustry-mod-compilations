const {初代核心} = require('核心');
const lib = require("lib");
const {斯特文} = require('星球');
斯特文.techTree = TechTree.nodeRoot( "压缩重工业2-重生", 初代核心, true, run(() => {}));

			