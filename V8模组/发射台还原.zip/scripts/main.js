
let mod = Vars.mods.getMod("v7launchpad")
let version = mod.meta.version
const meta = Vars.mods.locateMod("v7launchpad").meta;

meta.author = "[pink]N[cyan]O [red]95[violet]27";