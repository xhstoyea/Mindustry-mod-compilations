const ArmorConfigAbility = () => { //开始
    var armorEffectRegion;
    var armorRegion;
    var healthMultiplier = 10;
    var warmup = 0;
    var z = Layer.effect;

    return extend(Ability, {
        localized() {
            return "重型装甲（ArmorConfigAbility）" //能力名称.
        },
        update(unit){
            this.super$update(unit);

            warmup = Mathf.lerpDelta(warmup, unit.isShooting ? 1 : 0, 0.1); //开火激发
            unit.healthMultiplier += warmup * healthMultiplier;

            
            
        },
        draw(unit){
            //Color.valueOf(ColorArmor)
            armorEffectRegion = Core.atlas.find(unit.type.name + "-armor-effect", unit.type.region);
           // armorRegion = Core.atlas.find(unit.type.name + "-armor", unit.type.region);
            armorRegion = Core.atlas.find(unit.type.name + "-armor", unit.type.region);
            Draw.alpha(warmup);
            Draw.rect(armorRegion, unit.x, unit.y, unit.rotation - 90);

            if(warmup > 0.001){
                Draw.draw(z <= 0 ? Draw.z() : z, () => {
                    Shaders.armor.progress = warmup;
                    Shaders.armor.region = armorEffectRegion;
                    Shaders.armor.time = Time.time / 10;
                    

                    Draw.color(Pal.accent);//ColorArmor);
                    //Shaders.armor.color.set(Pal.accent).a = warmup;
                    Draw.shader(Shaders.armor);
                    Draw.rect(Shaders.armor.region, unit.x, unit.y, unit.rotation - 90);
                    Draw.shader();
                    Draw.reset();
                })

            }
        },
    });
}
exports.ArmorConfigAbility = ArmorConfigAbility;
//#fed37f

// --- ShockWave Constructor ---
const ShockWaveLightning = (Unit, Damage, LightningLengthRand, LightningLength) => {
    var unit = Unit;
    Lightning.create(unit.team, Pal.lancerLaser, Damage * Vars.state.rules.playerDamageMultiplier, unit.getX(), unit.getY(), Mathf.random(LightningLengthRand), LightningLength);
    Lightning.create(unit.team, Pal.lancerLaser, Damage * Vars.state.rules.playerDamageMultiplier, unit.getX(), unit.getY(), Mathf.random(LightningLengthRand), LightningLength);
    Lightning.create(unit.team, Pal.lancerLaser, Damage * Vars.state.rules.playerDamageMultiplier, unit.getX(), unit.getY(), Mathf.random(LightningLengthRand), LightningLength);
    Lightning.create(unit.team, Pal.lancerLaser, Damage * Vars.state.rules.playerDamageMultiplier, unit.getX(), unit.getY(), Mathf.random(LightningLengthRand), LightningLength);
    Lightning.create(unit.team, Pal.lancerLaser, Damage * Vars.state.rules.playerDamageMultiplier, unit.getX(), unit.getY(), Mathf.random(LightningLengthRand), LightningLength);
    Lightning.create(unit.team, Pal.lancerLaser, Damage * Vars.state.rules.playerDamageMultiplier, unit.getX(), unit.getY(), Mathf.random(LightningLengthRand), LightningLength);
    Lightning.create(unit.team, Pal.lancerLaser, Damage * Vars.state.rules.playerDamageMultiplier, unit.getX(), unit.getY(), Mathf.random(LightningLengthRand), LightningLength);
}
const ShockWaveLanding = (cooldown) => { //Use legacy style format combined with new style
    var onGroundAlready = true;
    return extend(Ability, {
        localized() {
            return "着陆爆能（Discharge）" //Name of the ability lolz.
        },
        update(unit){
            if(unit.isGrounded()){
                if(onGroundAlready == false){
                    Fx.landShock.at(unit);
                    onGroundAlready = true;
                    ShockWaveLightning(unit, 17, 360, 16);
                }
            } else {
                onGroundAlready = false
            }
        },
        draw(unit){

        }

    });
}
exports.ShockWaveLanding = ShockWaveLanding;

const 激光助推器 = () => { //开始
    var healthMultiplier = 1;
    var speedMultiplier = 5;
    var reloadMultiplier = 2;
    var warmup = 0;

    return extend(Ability, {
        localized() {
            return "激光助推器（LaserBooster）" //能力名称.
        },
        update(unit){
            this.super$update(unit);

            warmup = Mathf.lerpDelta(warmup, unit.isShooting ? 1 : 0, 0.1); //开火激发
            unit.speedMultiplier += warmup * speedMultiplier;
            unit.reloadMultiplier += warmup * reloadMultiplier;
        }
    });
}

exports.激光助推器 = 激光助推器;
