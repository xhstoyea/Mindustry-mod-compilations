
Vars.renderer.minZoom = 0.3;
Vars.renderer.maxZoom = 6;
MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000

const Ability = require("单位/能力")
//单位能力部分

const jave = extend(UnitType, "javelin-ship", {
});
jave.abilities.add(MoveLightningAbility(3, 10, 0.35, 10, 3.6, 6, Color.valueOf("b2c6d2"), "战术单位拓展-javelin-ship-shield")); //这里是用于给Javelin上正前方的盾用的
jave.constructor = () => extend(UnitEntity, {});

const omega = extend(UnitType, "omega-mech", {
}); //Omega机甲连接部分
omega.abilities.add(Ability.ArmorConfigAbility());
omega.constructor = () => extend(MechUnit, {});

const javemech = extend(UnitType, "delta-mech", {
}); //Delta机甲连接部分
javemech.abilities.add(Ability.ShockWaveLanding()); 
javemech.constructor = () => extend(MechUnit, {});

const 亡魂 = extend(UnitType, "亡魂", {
}); //连接部分
亡魂.abilities.add(Ability.激光助推器());
亡魂.constructor = () => extend(UnitEntity, {});

require("方块/战术核心")
require("方块/机甲平台1")
require("方块/机甲平台2")
require("方块/机甲平台3")
require("方块/机甲平台4")
require("方块/机甲平台5")
require("方块/机甲平台6")
require("方块/机甲平台7")
require("方块/机甲平台8")

//队伍
/*
const target = "manifold";
const baseColor = Color.valueOf("96a0be");
let palette = [
Color.valueOf("c6d4ff"),
baseColor,
Color.valueOf("394462")
];
let palettei = [
Color.valueOf("c6d4ff").rgba(),
baseColor.rgba(),
Color.valueOf("606d90").rgba()
];

Events.on(ContentInitEvent, () => {

  let fonts = [Fonts.def, Fonts.outline];
  let ch = Fonts.getUnicode(target);

  let size = Mathf.round(Fonts.def.getData().lineHeight / Fonts.def.getData().scaleY);
  let tex = Core.atlas.find("战术单位拓展-DPPF");
  let out = Scaling.fit.apply(tex.width, tex.height, size, size);

  for(let font of fonts){
    let list = Reflect.get(Font, font, "regions");
    list.add(tex);
    Reflect.set(Font, font, "regions", list);

    let glyph = font.getData().getGlyph(ch);
    glyph.page = 1;

    glyph.id = ch;
    glyph.srcX = glyph.srcY = 0;
//    glyph.width = out.x;
//    glyph.height = out.y;
    glyph.width = 24
    glyph.height = 24
    glyph.u = tex.u;
    glyph.v = tex.v2;
    glyph.u2 = tex.u2;
    glyph.v2 = tex.v;
    glyph.xoffset = 0;
    glyph.yoffset = -size;
    glyph.xadvance = size;
    glyph.kerning = null;
    glyph.fixedWidth = true;

    //font.getData().setGlyphRegion(glyph, tex);
  }

  const DPPF = Team.get(5);
  DPPF.name = "DPPF";
  //DPPF.color.set(Color.valueOf("87ceeb"));
  Reflect.set(Team, DPPF, "color", baseColor);

  let newPal = Reflect.get(Team, DPPF, "palette");
  newPal[0] = palette[0];
  newPal[1] = palette[1];
  newPal[2] = palette[2];
  Reflect.set(Team, DPPF, "palette", newPal);
  let newI = Reflect.get(Team, DPPF, "palettei");
  newI[0] = palettei[0];
  newI[1] = palettei[1];
  newI[2] = palettei[2];
  Reflect.set(Team, DPPF, "palettei", newI);

  DPPF.hasPalette = true;
  DPPF.emoji = Fonts.getUnicodeStr(target);
});
*/