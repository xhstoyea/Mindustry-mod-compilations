const 机甲平台1 = extend(CoreBlock, "机甲平台1", {
    canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
    canPlaceOn(tile, team) { return Vars.state.teams.cores(team).size < 99;
    },
});