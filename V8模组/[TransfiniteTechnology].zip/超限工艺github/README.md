# TTmod
A story-rich mod
Includes 13 main campaign chapters and one side campaign chapter
Overhauls the original planet Cypro
Adds new factions
A large number of new buildings and units
We welcome everyone to try it out
（The storyline is currently only available in Chinese.）
（The Mod has not yet been translated into English or other languages.）

一个剧情向模组
内含12章主线战役和1张支线战役
在原版星球赛普罗的基础上进行了覆盖
新增额外的势力
大量的全新建筑以及单位
欢迎各位游玩
（剧情目前只有中文）
（模组尚未制作英文及其他语言的翻译）