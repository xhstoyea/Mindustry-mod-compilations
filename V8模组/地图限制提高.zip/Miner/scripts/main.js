Events.on(EventType.ClientLoadEvent, e => {
	MapResizeDialog.maxSize = 999999;
	
	let editor = Vars.ui.editor;
	let resizeDialog = Reflect.get(editor, "resizeDialog");
	let cont = resizeDialog.cont;
	
	resizeDialog.shown(() => {
		let table = resizeDialog.cont.getChildren().get(0);
		table.getCells().each(cell => cell.maxTextLength(6));
	});
});