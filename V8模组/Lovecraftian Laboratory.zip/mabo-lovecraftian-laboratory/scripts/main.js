/*
  ========================================
  Section: Definition
  ========================================
*/


  if(require("lovec/run/RUN_version").checkVersion("loveclab", [
    "lovec", 100.25081201,
  ])) return;


  /* <---------- import ----------> */


  const VARGEN = require("lovec/glb/GLB_varGen");


  const MDL_cond = require("lovec/mdl/MDL_cond");
  const MDL_content = require("lovec/mdl/MDL_content");
  const MDL_event = require("lovec/mdl/MDL_event");
  const MDL_util = require("lovec/mdl/MDL_util");


  /* <---------- load ----------> */


  const CT_RS_baseItem = require("loveclab/ct/CT_RS_baseItem");
  const CT_RS_oreItem = require("loveclab/ct/CT_RS_oreItem");
  const CT_RS_wasteItem = require("loveclab/ct/CT_RS_wasteItem");
  const CT_RS_chunksItem = require("loveclab/ct/CT_RS_chunksItem");
  const CT_RS_dustItem = require("loveclab/ct/CT_RS_dustItem");


  const CT_RS_baseFluid = require("loveclab/ct/CT_RS_baseFluid");
  const CT_RS_intermediateFluid = require("loveclab/ct/CT_RS_intermediateFluid");


  const CT_RS_abstractFluid = require("loveclab/ct/CT_RS_abstractFluid");


  const CT_ENV_dirtFloor = require("loveclab/ct/CT_ENV_dirtFloor");
  const CT_ENV_grassFloor = require("loveclab/ct/CT_ENV_grassFloor");
  const CT_ENV_sandFloor = require("loveclab/ct/CT_ENV_sandFloor");
  const CT_ENV_rockFloor = require("loveclab/ct/CT_ENV_rockFloor");
  const CT_ENV_gravelFloor = require("loveclab/ct/CT_ENV_gravelFloor");
  const CT_ENV_riverFloor = require("loveclab/ct/CT_ENV_riverFloor");
  const CT_ENV_seaFloor = require("loveclab/ct/CT_ENV_seaFloor");
  const CT_ENV_puddleFloor = require("loveclab/ct/CT_ENV_puddleFloor");
  const CT_ENV_lavaFloor = require("loveclab/ct/CT_ENV_lavaFloor");
  const CT_ENV_vent = require("loveclab/ct/CT_ENV_vent");
  const CT_ENV_wall = require("loveclab/ct/CT_ENV_wall");
  const CT_ENV_heap = require("loveclab/ct/CT_ENV_heap");
  const CT_ENV_tree = require("loveclab/ct/CT_ENV_tree");
  const CT_ENV_ore = require("loveclab/ct/CT_ENV_ore");
  const CT_ENV_deposit = require("loveclab/ct/CT_ENV_deposit");


  const CT_BLK_core = require("loveclab/ct/CT_BLK_core");


  const CT_STA_baseStatus = require("loveclab/ct/CT_STA_baseStatus");
  const CT_STA_fadeStatus = require("loveclab/ct/CT_STA_fadeStatus");
  const CT_STA_liquidStatus = require("loveclab/ct/CT_STA_liquidStatus");
  const CT_STA_burstStatus = require("loveclab/ct/CT_STA_burstStatus");
  const CT_STA_deathStatus = require("loveclab/ct/CT_STA_deathStatus");


/*
  ========================================
  Section: Application
  ========================================
*/


  MDL_util.setMod_localization("loveclab");


  MDL_event._c_onLoad(() => {


    // Set up shown contents on Lovec planets, no need for blocks and units
    Vars.content.items().each(itm => MDL_content._mod(itm) === "loveclab" && !MDL_cond._isIntmd(itm), itm => {
      itm.shownPlanets.addAll(VARGEN.lovecPlas);
      itm.databaseTabs.addAll(VARGEN.lovecPlas);
    });
    Vars.content.liquids().each(liq => MDL_content._mod(liq) === "loveclab" && !MDL_cond._isIntmd(liq), liq => {
      liq.shownPlanets.addAll(VARGEN.lovecPlas);
      liq.databaseTabs.addAll(VARGEN.lovecPlas);
    });


  }, 41987772);
