/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/env/ENV_wall");


  /* <---------- auxilliary ----------> */


  function _std(nmFlr) {
    return {
      flr: nmFlr,
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(t) {
        this.super$drawBase(t);
        TEMPLATE.drawBase(this, t);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- env0wall ----------> */


  /* dirt */


  /* grass */


  /* sand */


  const env0wall_sand = extend(StaticWall, "env0wall-sand", _std("loveclab-env0flr-sand"));
  exports.env0wall_sand = env0wall_sand;


  /* rock */


  const env0wall_rockBiologicalSedimentaryGray = extend(StaticWall, "env0wall-rock-biological-sedimentary-gray", _std("loveclab-env0flr-rock-biological-sedimentary-gray"));
  exports.env0wall_rockBiologicalSedimentaryGray = env0wall_rockBiologicalSedimentaryGray;
