/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/sta/STA_fadeStatus");


  /* <---------- auxilliary ----------> */


  function _std(nmReg, fadeColor) {
    return {
      fadeReg: nmReg, fadeColor: Object.val(fadeColor, Color.white),
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(unit, time) {
        this.super$update(unit, time);
        TEMPLATE.update(this, unit, time);
      },
      draw(unit) {
        this.super$draw(unit);
        TEMPLATE.draw(this, unit);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- sta ----------> */


  const sta_stunned = extend(StatusEffect, "sta-stunned", _std("lovec-reg0sta-sta-stunned"));
  exports.sta_stunned = sta_stunned;
