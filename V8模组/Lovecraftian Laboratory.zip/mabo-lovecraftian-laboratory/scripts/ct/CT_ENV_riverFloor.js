/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/env/ENV_riverFloor");


  /* <---------- auxilliary ----------> */


  function _std() {
    return {
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(t) {
        this.super$drawBase(t);
        TEMPLATE.drawBase(this, t);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      ex_getMatGrp() {
        return TEMPLATE.ex_getMatGrp(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- env0flr ----------> */


  const env0liq_water = extend(Floor, "env0liq-water", _std());
  exports.env0liq_water = env0liq_water;


  const env0liq_waterShallow = extend(Floor, "env0liq-water-shallow", _std());
  exports.env0liq_waterShallow = env0liq_waterShallow;


  const env0liq_swampWater = extend(Floor, "env0liq-swamp-water", _std());
  exports.env0liq_swampWater = env0liq_swampWater;


  const env0liq_swampWaterShallow = extend(Floor, "env0liq-swamp-water-shallow", _std());
  exports.env0liq_swampWaterShallow = env0liq_swampWaterShallow;
