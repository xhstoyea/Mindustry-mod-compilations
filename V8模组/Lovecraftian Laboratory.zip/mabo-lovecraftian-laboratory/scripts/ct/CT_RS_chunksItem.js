/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/rs/RS_chunksItem");


  /* <---------- auxilliary ----------> */


  function _std(intmdParent, hasReg) {
    return {
      alts: 0,
      intmdParent: intmdParent, useParentRegion: !hasReg,
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      ex_getParent() {
        return TEMPLATE.ex_getParent(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- item0int ----------> */


  /* barium */


  const item0int0chunks_barite = extend(Item, "item0int0chunks-barite", _std("loveclab-item0ore-barite"));
  exports.item0int0chunks_barite = item0int0chunks_barite;


  /* silicon */


  const item0int0chunks_silicaStone = extend(Item, "item0int0chunks-silica-stone", _std("loveclab-item0ore-silica-stone"));
  exports.item0int0chunks_silicaStone = item0int0chunks_silicaStone;


  /* rock */


  const item0int0chunks_dolomite = extend(Item, "item0int0chunks-dolomite", _std("loveclab-item0ore-dolomite"));
  exports.item0int0chunks_dolomite = item0int0chunks_dolomite;


  const item0int0chunks_gypsum = extend(Item, "item0int0chunks-gypsum", _std("loveclab-item0ore-gypsum"));
  exports.item0int0chunks_gypsum = item0int0chunks_gypsum;


  const item0int0chunks_limestone = extend(Item, "item0int0chunks-limestone", _std("loveclab-item0ore-limestone"));
  exports.item0int0chunks_limestone = item0int0chunks_limestone;
