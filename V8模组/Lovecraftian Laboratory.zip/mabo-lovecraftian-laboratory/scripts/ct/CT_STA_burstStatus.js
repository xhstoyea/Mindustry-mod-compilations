/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/sta/STA_burstStatus");
  const EFF = require("lovec/glb/GLB_eff");


  /* <---------- auxilliary ----------> */


  function _std(eff, effP, burstTime, extendTimeGetter, burstDmg, burstDmgPerc, burstScr, burstEff, burstEffColor) {
    return {
      justApplied: false, burstTime: Object.val(burstTime, 0.0),
      extendTimeGetter: Object.val(extendTimeGetter, function(unit, time) {}),
      burstDamage: Object.val(burstDmg, 0.0), burstDamagePerc: Object.val(burstDmgPerc, 0.0),
      burstScr: Object.val(burstScr, function(unit) {}),
      burstEff: Object.val(burstEff, Fx.none), burstEffColor: Object.val(burstEffColor, Color.white),
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(unit, time) {
        this.super$update(unit, time);
        TEMPLATE.update(this, unit, time);
      },
      applied(unit, time, isExtend) {
        this.super$applied(unit, time, isExtend);
        TEMPLATE.applied(this, unit, time, isExtend);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      ex_isStackSta() {
        return TEMPLATE.ex_isStackSta(this);
      },
      ex_getBurstTime() {
        return TEMPLATE.ex_getBurstTime(this);
      },
      // @SPEC
      effect: Object.val(eff, Fx.none), effectChance: Object.val(effP, 0.02),
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- sta0bur ----------> */


  const sta0bur_overheated = extend(StatusEffect, "sta0bur-overheated", _std(Fx.burning, 0.004, 7200.0, function(unit, time) {

    return 1800.0;

  }, 260.0, 0.01, function(unit) {

    unit.apply(StatusEffects.melting, 480.0);

  }, EFF.circlePulseDynamic, Color.valueOf("ffc455")));
  exports.sta0bur_overheated = sta0bur_overheated;
