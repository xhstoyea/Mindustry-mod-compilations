/*
  ========================================
  Section: Definition
  ========================================
*/


  /* ----------------------------------------
   * NOTE:
   *
   * Cores here are roots of planet tech trees.
   * For upgraded cores, move to ProjReind.
   * ---------------------------------------- */


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/blk/BLK_core");


  /* <---------- auxilliary ----------> */


  function _std() {
    return {
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawPlace(tx, ty, rot, valid) {
        this.super$drawPlace(tx, ty, rot, valid);
        TEMPLATE.drawPlace(this, tx, ty, rot, valid);
      },
      setBars() {
        this.super$setBars();
        TEMPLATE.setBars(this);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
    };
  };


  function _std_b() {
    return {
      created() {
        this.super$created();
        TEMPLATE.created(this);
      },
      onDestroyed() {
        this.super$onDestroyed();
        TEMPLATE.onDestroyed(this);
      },
      updateTile() {
        this.super$updateTile();
        TEMPLATE.updateTile(this);
      },
      onProximityUpdate() {
        this.super$onProximityUpdate();
        TEMPLATE.onProximityUpdate(this);
      },
      draw() {
        this.super$draw();
        TEMPLATE.draw(this);
      },
      drawSelect() {
        this.super$drawSelect();
        TEMPLATE.drawSelect(this);
      },
      acceptItem(b_f, itm) {
        if(!this.super$acceptItem(b_f, itm)) return false;
        if(!TEMPLATE.acceptItem(this, b_f, itm)) return false;
        return true;
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- eff0core ----------> */


  const eff0Core_ash = extend(CoreBlock, "eff0core-ash", _std());
  eff0Core_ash.buildType = () => extend(CoreBlock.CoreBuild, eff0Core_ash, _std_b());
  exports.eff0Core_ash = eff0Core_ash;
