/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/env/ENV_vent");


  /* <---------- auxilliary ----------> */


  function _std(ventSize, nmLiq, randRegs, randRegDenom, randRegOffs) {
    return {
      armor: ventSize == null ? 3 : ventSize,
      liq: nmLiq,
      pons2: null,
      offDraw: 0.0,
      drawnMap: new ObjectMap(),
      randRegs: Object.val(randRegs, []),
      randRegDenom: Object.val(randRegDenom, 80),
      randRegOffs: Object.val(randRegOffs, [0, 0]),
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(t) {
        TEMPLATE.drawBase(this, t);
      },
      isCenterVent(t) {
        return TEMPLATE.isCenterVent(this, t);
      },
      renderUpdate(renderState) {
        TEMPLATE.renderUpdate(this, renderState);
      },
      checkAdjacent(t) {
        return TEMPLATE.checkAdjacent(this, t);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      ex_getMatGrp() {
        return TEMPLATE.ex_getMatGrp(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- env0vent (steam) ----------> */


  /* sand */


  const env0vent_steamSand = extend(SteamVent, "env0vent-steam-sand", _std(2, "loveclab-gas0misc-steam"));
  exports.env0vent_steamSand = env0vent_steamSand;


  /* rock */


  const env0vent_steamRockBiologicalSedimentaryGray = extend(SteamVent, "env0vent-steam-rock-biological-sedimentary-gray", _std(2, "loveclab-gas0misc-steam"));
  exports.env0vent_steamRockBiologicalSedimentaryGray = env0vent_steamRockBiologicalSedimentaryGray;
