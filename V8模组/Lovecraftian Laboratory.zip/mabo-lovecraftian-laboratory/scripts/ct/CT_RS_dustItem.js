/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/rs/RS_dustItem");


  /* <---------- auxilliary ----------> */


  function _std(intmdParent, hasReg) {
    return {
      alts: 0,
      intmdParent: intmdParent, useParentRegion: !hasReg,
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      ex_getParent() {
        return TEMPLATE.ex_getParent(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- item0int ----------> */


  const item0int0dust_sand = extend(Item, "item0int0dust-sand", _std("loveclab-item0ore-sand"));
  exports.item0int0dust_sand = item0int0dust_sand;


  /* carbon */


  const item0int0dust_rawCoal = extend(Item, "item0int0dust-raw-coal", _std("loveclab-item0ore-raw-coal"));
  exports.item0int0dust_rawCoal = item0int0dust_rawCoal;


  /* copper */


  const item0int0dust_azurite = extend(Item, "item0int0dust-azurite", _std("loveclab-item0ore-azurite"));
  exports.item0int0dust_azurite = item0int0dust_azurite;


  const item0int0dust_chalcopyrite = extend(Item, "item0int0dust-chalcopyrite", _std("loveclab-item0ore-chalcopyrite"));
  exports.item0int0dust_chalcopyrite = item0int0dust_chalcopyrite;


  const item0int0dust_malachite = extend(Item, "item0int0dust-malachite", _std("loveclab-item0ore-malachite"));
  exports.item0int0dust_malachite = item0int0dust_malachite;


  const item0int0dust_nativeCopper = extend(Item, "item0int0dust-native-copper", _std("loveclab-item0ore-native-copper"));
  exports.item0int0dust_nativeCopper = item0int0dust_nativeCopper;


  /* iron */


  const item0int0dust_hematite = extend(Item, "item0int0dust-hematite", _std("loveclab-item0ore-hematite"));
  exports.item0int0dust_hematite = item0int0dust_hematite;


  const item0int0dust_limonite = extend(Item, "item0int0dust-limonite", _std("loveclab-item0ore-limonite"));
  exports.item0int0dust_limonite = item0int0dust_limonite;


  const item0int0dust_magnetite = extend(Item, "item0int0dust-magnetite", _std("loveclab-item0ore-magnetite"));
  exports.item0int0dust_magnetite = item0int0dust_magnetite;


  const item0int0dust_pyrite = extend(Item, "item0int0dust-pyrite", _std("loveclab-item0ore-pyrite"));
  exports.item0int0dust_pyrite = item0int0dust_pyrite;


  /* lead */


  const item0int0dust_galena = extend(Item, "item0int0dust-galena", _std("loveclab-item0ore-galena"));
  exports.item0int0dust_galena = item0int0dust_galena;


  /* manganese */


  const item0int0dust_psilomelane = extend(Item, "item0int0dust-psilomelane", _std("loveclab-item0ore-psilomelane"));
  exports.item0int0dust_psilomelane = item0int0dust_psilomelane;


  const item0int0dust_pyrolusite = extend(Item, "item0int0dust-pyrolusite", _std("loveclab-item0ore-pyrolusite"));
  exports.item0int0dust_pyrolusite = item0int0dust_pyrolusite;


  /* tin */


  const item0int0dust_cassiterite = extend(Item, "item0int0dust-cassiterite", _std("loveclab-item0ore-cassiterite"));
  exports.item0int0dust_cassiterite = item0int0dust_cassiterite;


  /* zinc */


  const item0int0dust_sphalerite = extend(Item, "item0int0dust-sphalerite", _std("loveclab-item0ore-sphalerite"));
  exports.item0int0dust_sphalerite = item0int0dust_sphalerite;


  /* rock */


  const item0int0dust_rockMetamorphic = extend(Item, "item0int0dust-rock-metamorphic", _std("loveclab-item0ore-rock-metamorphic"));
  exports.item0int0dust_rockMetamorphic = item0int0dust_rockMetamorphic;


  const item0int0dust_rockBiologicalSedimentary = extend(Item, "item0int0dust-rock-biological-sedimentary", _std("loveclab-item0ore-rock-biological-sedimentary"));
  exports.item0int0dust_rockBiologicalSedimentary = item0int0dust_rockBiologicalSedimentary;
