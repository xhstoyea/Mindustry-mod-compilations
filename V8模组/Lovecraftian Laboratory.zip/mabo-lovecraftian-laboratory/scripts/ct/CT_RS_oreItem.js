/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/rs/RS_oreItem");


  /* <---------- auxilliary ----------> */


  function _std() {
    return {
      alts: 0,
      sintTemp: 0.0,
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- item0ore ----------> */


  /* carbon */


  const item0chem_peat = extend(Item, "item0chem-peat", _std());
  exports.item0chem_peat = item0chem_peat;


  const item0chem_lignite = extend(Item, "item0chem-lignite", _std());
  exports.item0chem_lignite = item0chem_lignite;


  const item0ore_rawCoal = extend(Item, "item0ore-raw-coal", _std());
  exports.item0ore_rawCoal = item0ore_rawCoal;


  const item0chem_anthracite = extend(Item, "item0chem-anthracite", _std());
  exports.item0chem_anthracite = item0chem_anthracite;


  const item0ore_crudeGraphite = extend(Item, "item0ore-crude-graphite", _std());
  exports.item0ore_crudeGraphite = item0ore_crudeGraphite;


  /* barium */


  const item0ore_barite = extend(Item, "item0ore-barite", _std());
  exports.item0ore_barite = item0ore_barite;


  /* copper */


  const item0ore_azurite = extend(Item, "item0ore-azurite", _std());
  exports.item0ore_azurite = item0ore_azurite;


  const item0ore_chalcopyrite = extend(Item, "item0ore-chalcopyrite", _std());
  exports.item0ore_chalcopyrite = item0ore_chalcopyrite;


  const item0ore_malachite = extend(Item, "item0ore-malachite", _std());
  exports.item0ore_malachite = item0ore_malachite;


  const item0ore_nativeCopper = extend(Item, "item0ore-native-copper", _std());
  exports.item0ore_nativeCopper = item0ore_nativeCopper;


  /* iron */


  const item0ore_hematite = extend(Item, "item0ore-hematite", _std());
  exports.item0ore_hematite = item0ore_hematite;


  const item0ore_limonite = extend(Item, "item0ore-limonite", _std());
  exports.item0ore_limonite = item0ore_limonite;


  const item0ore_magnetite = extend(Item, "item0ore-magnetite", _std());
  exports.item0ore_magnetite = item0ore_magnetite;


  const item0ore_meteoricIron = extend(Item, "item0ore-meteoric-iron", _std());
  exports.item0ore_meteoricIron = item0ore_meteoricIron;


  const item0ore_pyrite = extend(Item, "item0ore-pyrite", _std());
  exports.item0ore_pyrite = item0ore_pyrite;


  /* lead */


  const item0ore_galena = extend(Item, "item0ore-galena", _std());
  exports.item0ore_galena = item0ore_galena;


  /* manganese */


  const item0ore_psilomelane = extend(Item, "item0ore-psilomelane", _std());
  exports.item0ore_psilomelane = item0ore_psilomelane;


  const item0ore_pyrolusite = extend(Item, "item0ore-pyrolusite", _std());
  exports.item0ore_pyrolusite = item0ore_pyrolusite;


  /* silicon */


  const item0ore_silicaStone = extend(Item, "item0ore-silica-stone", _std());
  exports.item0ore_silicaStone = item0ore_silicaStone;


  /* tin */


  const item0ore_cassiterite = extend(Item, "item0ore-cassiterite", _std());
  exports.item0ore_cassiterite = item0ore_cassiterite;


  /* zinc */


  const item0ore_sphalerite = extend(Item, "item0ore-sphalerite", _std());
  exports.item0ore_sphalerite = item0ore_sphalerite;


  /* misc */


  const item0ore_clay = extend(Item, "item0ore-clay", _std());
  exports.item0ore_clay = item0ore_clay;


  const item0ore_sand = extend(Item, "item0ore-sand", _std());
  exports.item0ore_sand = item0ore_sand;


  const item0ore_sandRiver = extend(Item, "item0ore-sand-river", _std());
  exports.item0ore_sandRiver = item0ore_sandRiver;


  const item0ore_sandSea = extend(Item, "item0ore-sand-sea", _std());
  exports.item0ore_sandSea = item0ore_sandSea;


  /* rock */


  const item0ore_dolomite = extend(Item, "item0ore-dolomite", _std());
  exports.item0ore_dolomite = item0ore_dolomite;


  const item0ore_gypsum = extend(Item, "item0ore-gypsum", _std());
  exports.item0ore_gypsum = item0ore_gypsum;


  const item0ore_limestone = extend(Item, "item0ore-limestone", _std());
  exports.item0ore_limestone = item0ore_limestone;


  const item0ore_rockLava = extend(Item, "item0ore-rock-lava", _std());
  exports.item0ore_rockLava = item0ore_rockLava;


  const item0ore_rockMetamorphic = extend(Item, "item0ore-rock-metamorphic", _std());
  exports.item0ore_rockMetamorphic = item0ore_rockMetamorphic;


  const item0ore_rockPlutonic = extend(Item, "item0ore-rock-plutonic", _std());
  exports.item0ore_rockPlutonic = item0ore_rockPlutonic;


  const item0ore_rockBiologicalSedimentary = extend(Item, "item0ore-rock-biological-sedimentary", _std());
  exports.item0ore_rockBiologicalSedimentary = item0ore_rockBiologicalSedimentary;
