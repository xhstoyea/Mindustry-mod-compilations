/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/rs/RS_baseFluid");


  /* <---------- import ----------> */


  function _std() {
    return {
      alts: 0,
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(puddle) {
        this.super$update(puddle);
        TEMPLATE.update(this, puddle);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
      willBoil() {
        return TEMPLATE.willBoil(this);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- liq0ore ----------> */


  const liq0ore_water = extend(Liquid, "liq0ore-water", _std());
  exports.liq0ore_water = liq0ore_water;


  const liq0ore_seaWater = extend(Liquid, "liq0ore-sea-water", _std());
  exports.liq0ore_seaWater = liq0ore_seaWater;


  const liq0ore_brine = extend(Liquid, "liq0ore-brine", _std());
  exports.liq0ore_brine = liq0ore_brine;


  /* <---------- gas0misc ----------> */


  const gas0misc_air = extend(Liquid, "gas0misc-air", _std());
  exports.gas0misc_air = gas0misc_air;


  const gas0misc_steam = extend(Liquid, "gas0misc-steam", _std());
  exports.gas0misc_steam = gas0misc_steam;
