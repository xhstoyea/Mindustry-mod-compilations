/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/rs/RS_intermediateFluid");


  /* <---------- auxilliary ----------> */


  function _std(intmdParent, hasReg, intmdTag) {
    return {
      alts: 0,
      intmdParent: intmdParent, useParentRegion: !hasReg,
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(puddle) {
        this.super$update(puddle);
        TEMPLATE.update(this, puddle);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
      willBoil() {
        return TEMPLATE.willBoil(this);
      },
      // @SPEC
      ex_getTags: intmdTag == null ?
        function() {return TEMPLATE.ex_getTags(this)} :
        function() {return TEMPLATE.ex_getTags(this).pushAll(intmdTag)},
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- gas0int ----------> */


  const gas0int_airClean = extend(Liquid, "gas0int-air-clean", _std("loveclab-gas0misc-air", false, "rs-clean"));
  exports.gas0int_airClean = gas0int_airClean;
