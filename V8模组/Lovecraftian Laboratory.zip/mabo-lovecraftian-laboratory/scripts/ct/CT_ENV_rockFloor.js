/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/env/ENV_rockFloor");


  /* <---------- auxilliary ----------> */


  function _std(randRegs, randRegDenom, randRegOffs) {
    return {
      randRegs: Object.val(randRegs, []),
      randRegDenom: Object.val(randRegDenom, 80),
      randRegOffs: Object.val(randRegOffs, [0, 0]),
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(t) {
        this.super$drawBase(t);
        TEMPLATE.drawBase(this, t);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      ex_getMatGrp() {
        return TEMPLATE.ex_getMatGrp(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- env0flr ----------> */


  const env0flr_rockMetamorphicGray = extend(Floor, "env0flr-rock-metamorphic-gray", _std(["rock"]));
  exports.env0flr_rockMetamorphicGray = env0flr_rockMetamorphicGray;


  const env0flr_rockBiologicalSedimentaryGray = extend(Floor, "env0flr-rock-biological-sedimentary-gray", _std(["rock"]));
  exports.env0flr_rockBiologicalSedimentaryGray = env0flr_rockBiologicalSedimentaryGray;
