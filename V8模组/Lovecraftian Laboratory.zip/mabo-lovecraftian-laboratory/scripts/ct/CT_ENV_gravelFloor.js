/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/env/ENV_gravelFloor");


  /* <---------- auxilliary ----------> */


  function _std(randRegs, randRegDenom, randRegOffs) {
    return {
      randRegs: Object.val(randRegs, []),
      randRegDenom: Object.val(randRegDenom, 80),
      randRegOffs: Object.val(randRegOffs, [0, 0]),
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(t) {
        this.super$drawBase(t);
        TEMPLATE.drawBase(this, t);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      ex_getMatGrp() {
        return TEMPLATE.ex_getMatGrp(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- env0flr ----------> */


  const env0flr_rockMetamorphicGrayCracked = extend(Floor, "env0flr-rock-metamorphic-gray-cracked", _std());
  exports.env0flr_rockMetamorphicGrayCracked = env0flr_rockMetamorphicGrayCracked;


  const env0flr_rockBiologicalSedimentaryGrayCracked = extend(Floor, "env0flr-rock-biological-sedimentary-gray-cracked", _std());
  exports.env0flr_rockBiologicalSedimentaryGrayCracked = env0flr_rockBiologicalSedimentaryGrayCracked;
