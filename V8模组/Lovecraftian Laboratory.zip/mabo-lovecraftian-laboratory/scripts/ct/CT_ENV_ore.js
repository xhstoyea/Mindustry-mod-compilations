/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/env/ENV_ore");


  /* <---------- auxilliary ----------> */


  function _std() {
    return {
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(t) {
        this.super$drawBase(t);
        TEMPLATE.drawBase(this, t);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- env0ore ----------> */


  /* carbon */


  const env0ore_lignite = extend(OreBlock, "env0ore-lignite", _std());
  exports.env0ore_lignite = env0ore_lignite;


  const env0ore_crudeGraphite = extend(OreBlock, "env0ore-crude-graphite", _std());
  exports.env0ore_crudeGraphite = env0ore_crudeGraphite;


  /* copper */


  const env0ore_malachite = extend(OreBlock, "env0ore-malachite", _std());
  exports.env0ore_malachite = env0ore_malachite;


  const env0ore_nativeCopper = extend(OreBlock, "env0ore-native-copper", _std());
  exports.env0ore_nativeCopper = env0ore_nativeCopper;


  /* lead */


  const env0ore_galena = extend(OreBlock, "env0ore-galena", _std());
  exports.env0ore_galena = env0ore_galena;


  /* tin */


  const env0ore_cassiterite = extend(OreBlock, "env0ore-cassiterite", _std());
  exports.env0ore_cassiterite = env0ore_cassiterite;


  /* zinc */


  const env0ore_sphalerite = extend(OreBlock, "env0ore-sphalerite", _std());
  exports.env0ore_sphalerite = env0ore_sphalerite;
