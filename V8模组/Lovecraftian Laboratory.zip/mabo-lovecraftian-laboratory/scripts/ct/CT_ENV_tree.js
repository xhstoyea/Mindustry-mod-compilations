/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/env/ENV_tree");


  /* <---------- auxilliary ----------> */


  function _std(treeLay, hidable) {
    return {
      armor: treeLay == null ? 76.0 : treeLay, hidable: hidable == null ? false : hidable, drawTup: null,
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(t) {
        TEMPLATE.drawBase(this, t);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      ex_getTreeGrp() {
        return TEMPLATE.ex_getTreeGrp(this);
      },
      ex_getHidable() {
        return TEMPLATE.ex_getHidable(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- env0tree (dirt) ----------> */


  const env0tree_brownSnake = extend(TreeBlock, "env0tree-brown-snake", _std(76.51));
  exports.env0tree_brownSnake = env0tree_brownSnake;
