/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/sta/STA_deathStatus");
  const VAR = require("lovec/glb/GLB_var");


  const MDL_call = require("lovec/mdl/MDL_call");
  const MDL_cond = require("lovec/mdl/MDL_cond");


  /* <---------- auxilliary ----------> */


  function _std(killedScr) {
    return {
      killedScr: Object.val(killedScr, function(unit) {}),
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(unit, time) {
        this.super$update(unit, time);
        TEMPLATE.update(this, unit, time);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- sta0death ----------> */


  const sta0death_recycleMark = extend(StatusEffect, "sta0death-recycle-mark", _std(function(unit) {
    if(!MDL_cond._isNonRobot(unit.type)) MDL_call.spawnLoot(
      unit.x,
      unit.y,
      Vars.content.item(!MDL_cond._isLovecUnit(unit.type) ? "scrap" : "loveclab-item0was-scrap-steel"),
      Math.pow(unit.hitSize, 1.95).randFreq(0.3),
    );
  }));
  exports.sta0death_recycleMark = sta0death_recycleMark;
