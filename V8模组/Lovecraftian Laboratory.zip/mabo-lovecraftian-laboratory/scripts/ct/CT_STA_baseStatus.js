/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/sta/STA_baseStatus");
  const EFF = require("lovec/glb/GLB_eff");


  /* <---------- auxilliary ----------> */


  function _std(eff, effP) {
    return {
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(unit, time) {
        this.super$update(unit, time);
        TEMPLATE.update(this, unit, time);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      // @SPEC
      effect: Object.val(eff, Fx.none), effectChance: Object.val(effP, 0.02),
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- sta ----------> */


  const sta_damaged = extend(StatusEffect, "sta-damaged", _std(EFF.unitDamagedSmog, 0.08));
  exports.sta_damaged = sta_damaged;


  const sta_severelyDamaged = extend(StatusEffect, "sta-severely-damaged", _std(EFF.unitDamagedSmog, 0.3));
  exports.sta_severelyDamaged = sta_severelyDamaged;


  const sta_slightlyInjured = extend(StatusEffect, "sta-slightly-injured", _std());
  exports.sta_slightlyInjured = sta_slightlyInjured;


  const sta_injured = extend(StatusEffect, "sta-injured", _std());
  exports.sta_injured = sta_injured;


  const sta_heavilyInjured = extend(StatusEffect, "sta-heavily-injured", _std());
  exports.sta_heavilyInjured = sta_heavilyInjured;


  const sta_hiddenWell = extend(StatusEffect, "sta-hidden-well", _std());
  exports.sta_hiddenWell = sta_hiddenWell;
