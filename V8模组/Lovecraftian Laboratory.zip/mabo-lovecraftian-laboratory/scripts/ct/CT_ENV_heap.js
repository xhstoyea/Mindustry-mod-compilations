/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/env/ENV_heap");


  /* <---------- auxilliary ----------> */


  function _std(nmFlr) {
    return {
      flr: nmFlr,
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(t) {
        this.super$drawBase(t);
        TEMPLATE.drawBase(this, t);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- env0heap ----------> */


  /* dirt */


  /* grass */


  /* sand */


  const env0heap_sand = extend(TallBlock, "env0heap-sand", _std("loveclab-env0flr-sand"));
  exports.env0heap_sand = env0heap_sand;


  /* rock */


  const env0heap_rockBiologicalSedimentaryGray = extend(TallBlock, "env0heap-rock-biological-sedimentary-gray", _std("loveclab-env0flr-rock-biological-sedimentary-gray"));
  exports.env0heap_rockBiologicalSedimentaryGray = env0heap_rockBiologicalSedimentaryGray;
