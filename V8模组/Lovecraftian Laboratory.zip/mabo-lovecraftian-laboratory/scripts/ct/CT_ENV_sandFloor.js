/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/env/ENV_sandFloor");


  /* <---------- auxilliary ----------> */


  function _std(randRegs, randRegDenom, randRegOffs) {
    return {
      randRegs: Object.val(randRegs, []),
      randRegDenom: Object.val(randRegDenom, 80),
      randRegOffs: Object.val(randRegOffs, [0, 0]),
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(t) {
        this.super$drawBase(t);
        TEMPLATE.drawBase(this, t);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      ex_getMatGrp() {
        return TEMPLATE.ex_getMatGrp(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- env0flr ----------> */


  const env0flr_sand = extend(Floor, "env0flr-sand", _std(["rock-sand"], 80, [20, 0]));
  exports.env0flr_sand = env0flr_sand;
