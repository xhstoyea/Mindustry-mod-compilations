/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/env/ENV_deposit");


  /* <---------- auxilliary ----------> */


  function _std() {
    return {
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(t) {
        this.super$drawBase(t);
        TEMPLATE.drawBase(this, t);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- env0depo ----------> */


  /* carbon */


  const env0depo_rawCoal = extend(TallBlock, "env0depo-raw-coal", _std());
  exports.env0depo_rawCoal = env0depo_rawCoal;


  const env0depo_anthracite = extend(TallBlock, "env0depo-anthracite", _std());
  exports.env0depo_anthracite = env0depo_anthracite;


  /* barium */


  const env0depo_barite = extend(TallBlock, "env0depo-barite", _std());
  exports.env0depo_barite = env0depo_barite;


  /* silicon */


  const env0depo_silicaStone = extend(TallBlock, "env0depo-silica-stone", _std());
  exports.env0depo_silicaStone = env0depo_silicaStone;


  /* rock */


  const env0depo_dolomite = extend(TallBlock, "env0depo-dolomite", _std());
  exports.env0depo_dolomite = env0depo_dolomite;


  const env0depo_gypsum = extend(TallBlock, "env0depo-gypsum", _std());
  exports.env0depo_gypsum = env0depo_gypsum;


  const env0depo_limestone = extend(TallBlock, "env0depo-limestone", _std());
  exports.env0depo_limestone = env0depo_limestone;
