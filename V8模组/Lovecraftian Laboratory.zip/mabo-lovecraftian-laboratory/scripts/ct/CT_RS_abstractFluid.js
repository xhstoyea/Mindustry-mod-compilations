/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/rs/RS_abstractFluid");


  /* <---------- import ----------> */


  function _std() {
    return {
      alts: 0,
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(puddle) {
        this.super$update(puddle);
        TEMPLATE.update(this, puddle);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- aux0aux ----------> */


  /* primary */


  const aux0aux_pressure = extend(Liquid, "aux0aux-pressure", _std());
  exports.aux0aux_pressure = aux0aux_pressure;


  const aux0aux_vacuum = extend(Liquid, "aux0aux-vacuum", _std());
  exports.aux0aux_vacuum = aux0aux_vacuum;


  const aux0aux_heat = extend(Liquid, "aux0aux-heat", _std());
  exports.aux0aux_heat = aux0aux_heat;


  const aux0aux_torque = extend(Liquid, "aux0aux-torque", _std());
  exports.aux0aux_torque = aux0aux_torque;


  /* misc */


  const aux0aux_dustRecycling = extend(Liquid, "aux0aux-dust-recycling", _std());
  exports.aux0aux_dustRecycling = aux0aux_dustRecycling;


  const aux0aux_pump = extend(Liquid, "aux0aux-pump", _std());
  exports.aux0aux_pump = aux0aux_pump;


  const aux0aux_vibrationScreen = extend(Liquid, "aux0aux-vibration-screen", _std());
  exports.aux0aux_vibrationScreen = aux0aux_vibrationScreen;
