/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/rs/RS_wasteItem");


  /* <---------- auxilliary ----------> */


  function _std() {
    return {
      alts: 0,
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- item0was ----------> */


  const item0was_scrapSteel = extend(Item, "item0was-scrap-steel", _std());
  exports.item0was_scrapSteel = item0was_scrapSteel;


  const item0was_slag = extend(Item, "item0was-slag", _std());
  exports.item0was_slag = item0was_slag;
