/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/env/ENV_dirtFloor");


  /* <---------- auxilliary ----------> */


  function _std(randRegs, randRegDenom, randRegOffs) {
    return {
      randRegs: Object.val(randRegs, []),
      randRegDenom: Object.val(randRegDenom, 80),
      randRegOffs: Object.val(randRegOffs, [0, 0]),
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(t) {
        this.super$drawBase(t);
        TEMPLATE.drawBase(this, t);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      ex_getMatGrp() {
        return TEMPLATE.ex_getMatGrp(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- env0flr ----------> */


  const env0flr_clay = extend(Floor, "env0flr-clay", _std());
  exports.env0flr_clay = env0flr_clay;


  const env0flr_dirt = extend(Floor, "env0flr-dirt", _std(["rock"]));
  exports.env0flr_dirt = env0flr_dirt;


  const env0flr_mud = extend(Floor, "env0flr-mud", _std(["rock"]));
  exports.env0flr_mud = env0flr_mud;
