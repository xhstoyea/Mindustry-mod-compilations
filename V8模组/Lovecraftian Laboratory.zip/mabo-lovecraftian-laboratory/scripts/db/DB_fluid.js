const db = {


  "param": {


    "dens": [],


    "boil": [],


    "fHeat": [

      /* <---------- gas0misc ----------> */

      "loveclab-gas0misc-steam", 100.0,

    ],


    "visc": [],


    "corrosion": [

      /* <---------- liq0ore ----------> */

      "loveclab-liq0ore-sea-water", 0.7,

    ],


  },


  "group": {


    "elementary": {


      "brine": [

        /* <---------- liq0ore ----------> */

        "loveclab-liq0ore-sea-water",
        "loveclab-liq0ore-brine",

      ],


      "acidAq": [],


      "baseAq": [],


      "acidGas": [],


      "baseGas": [],


      "acidSub": [],


      "baseSub": [],


      "alc": [],


      "acidAlc": [],


      "baseAlc": [],


      "oil": [],


      "acidOil": [],


      "baseOil": [],


      "slurry": [],


      "acidSlurry": [],


      "baseSlurry": [],


      "melt": [],


      "sMelt": [],


    },


    "fTag": {


      "chloric": [],


      "fluoric": [],


      "oxidative": [],


      "reductive": [],


      "dehydrative": [],


      "unstable": [],


    },


    "aqueous": [

      /* <---------- liq0ore ----------> */

      "loveclab-liq0ore-water",

      /* <---------- liq0was ----------> */

      "loveclab-liq0was-waste-water",

      /* <---------- gas0misc ----------> */

      "loveclab-gas0misc-steam",

    ],


  },


};
exports.db = db;
