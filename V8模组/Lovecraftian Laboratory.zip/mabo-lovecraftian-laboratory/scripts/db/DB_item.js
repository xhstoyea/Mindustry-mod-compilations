const db = {


  "param": {


    "fuel": {


      "point": [

        /* <---------- item0bio ----------> */

        "loveclab-item0bio-log", 8.0,
        "loveclab-item0bio-timber", 20.0,
        "loveclab-item0bio-sawdust", 5.0,
        "loveclab-item0bio-charcoal", 20.0,

        /* <---------- item0chem ----------> */

        /* carbon */

        "loveclab-item0chem-peat", 5.0,
        "loveclab-item0chem-lignite", 10.0,
        "loveclab-item0chem-coal", 20.0,
        "loveclab-item0chem-anthracite", 30.0,
        "loveclab-item0chem-semicoke", 20.0,
        "loveclab-item0chem-coke", 25.0,

      ],


      "level": [

        /* <---------- item0bio ----------> */

        "loveclab-item0bio-log", 3.25,
        "loveclab-item0bio-timber", 5.0,
        "loveclab-item0bio-sawdust", 8.0,
        "loveclab-item0bio-charcoal", 10.0,

        /* <---------- item0chem ----------> */

        /* carbon */

        "loveclab-item0chem-peat", 6.5,
        "loveclab-item0chem-lignite", 6.5,
        "loveclab-item0chem-coal", 8.0,
        "loveclab-item0chem-anthracite", 11.5,
        "loveclab-item0chem-semicoke", 8.5,
        "loveclab-item0chem-coke", 12.5,

      ],


      "fCons": [


        /* <---------- gas0ore ----------> */

        "loveclab-gas0ore-natural-gas", 0.1,

        /* <---------- gas0chem (inorganic) ----------> */

        /* elementary */

        "loveclab-gas0chem-hydrogen", 0.15,

        /* <---------- gas0chem (organic) ----------> */

        /* alkane */

        "loveclab-gas0chem-butane", 0.1,
        "loveclab-gas0chem-ethane", 0.1,
        "loveclab-gas0chem-methane", 0.1,
        "loveclab-gas0chem-propane", 0.1,

        /* alkene */

        "loveclab-gas0chem-acetylene", 0.1,
        "loveclab-gas0chem-propylene", 0.1,


      ],


      "fLevel": [

        /* <---------- gas0ore ----------> */

        "loveclab-gas0ore-natural-gas", 25.0,

        /* <---------- gas0chem (inorganic) ----------> */

        /* elementary */

        "loveclab-gas0chem-hydrogen", 23.0,

        /* <---------- gas0chem (organic) ----------> */

        /* alkane */

        "loveclab-gas0chem-butane", 19.0,
        "loveclab-gas0chem-ethane", 19.0,
        "loveclab-gas0chem-methane", 26.0,
        "loveclab-gas0chem-propane", 24.0,

        /* alkene */

        "loveclab-gas0chem-acetylene", 27.0,
        "loveclab-gas0chem-propylene", 26.0,

      ],


    },


    "hardness": [

      /* carbon */

      "loveclab-item0chem-peat", 1,
      "loveclab-item0chem-lignite", 1,
      "loveclab-item0ore-raw-coal", 2,
      "loveclab-item0chem-anthracite", 2,
      "loveclab-item0ore-crude-graphite", 2,

      /* barium */

      "loveclab-item0ore-barite", 3,

      /* copper */

      "loveclab-item0ore-azurite", 4,
      "loveclab-item0ore-chalcopyrite", 4,
      "loveclab-item0ore-native-copper", 3,
      "loveclab-item0ore-malachite", 4,

      /* iron */

      "loveclab-item0ore-hematite", 6,
      "loveclab-item0ore-limonite", 4,
      "loveclab-item0ore-magnetite", 6,
      "loveclab-item0ore-meteoric-iron", 6,
      "loveclab-item0ore-pyrite", 6,

      /* lead */

      "loveclab-item0ore-galena", 3,

      /* manganese */

      "loveclab-item0ore-psilomelane", 5,
      "loveclab-item0ore-pyrolusite", 1,

      /* silicon */

      "loveclab-item0ore-silica-stone", 4,

      /* tin */

      "loveclab-item0ore-cassiterite", 6,

      /* zinc */

      "loveclab-item0ore-sphalerite", 4,

      /* misc */

      "loveclab-item0ore-clay", 1,

      /* rock */

      "loveclab-item0ore-dolomite", 4,
      "loveclab-item0ore-gypsum", 2,
      "loveclab-item0ore-limestone", 2,
      "loveclab-item0ore-rock-clastic", 2,
      "loveclab-item0ore-rock-evaporite", 2,
      "loveclab-item0ore-rock-hypabyssal", 6,
      "loveclab-item0ore-rock-lava", 6,
      "loveclab-item0ore-rock-metamorphic", 4,
      "loveclab-item0ore-rock-plutonic", 6,
      "loveclab-item0ore-rock-biological-sedimentary", 4,
      "loveclab-item0ore-rock-clastic-sedimentary", 1,

    ],


    "sintTemp": [

      /* <---------- item0ore ----------> */

      /* copper */

      "loveclab-item0ore-azurite", 160.0,
      "loveclab-item0ore-chalcopyrite", 750.0,
      "loveclab-item0ore-native-copper", 950.0,
      "loveclab-item0ore-malachite", 160.0,

      /* iron */

      "loveclab-item0ore-hematite", 1450.0,
      "loveclab-item0ore-limonite", 1100.0,
      "loveclab-item0ore-magnetite", 1520.0,
      "loveclab-item0ore-meteoric-iron", 1500.0,
      "loveclab-item0ore-pyrite", 1050.0,

      /* lead */

      "loveclab-item0ore-galena", 1050.0,

      /* manganese */

      "loveclab-item0ore-psilomelane", 1600.0,
      "loveclab-item0ore-pyrolusite", 500.0,

      /* tin */

      "loveclab-item0ore-cassiterite", 1550.0,

      /* zinc */

      "loveclab-item0ore-sphalerite", 370.0,

      /* <---------- item0chem ----------> */

      /* elementary */

      "loveclab-item0chem-copper", 1050.0,
      "loveclab-item0chem-lead", 320.0,
      "loveclab-item0chem-nickel", 1450.0,
      "loveclab-item0chem-tin", 230.0,
      "loveclab-item-chem-zinc", 420.0,

    ],


  },


  "group": {


    "sand": [

      "loveclab-item0ore-sand",
      "loveclab-item0ore-sand-river",
      "loveclab-item0ore-sand-sea",

    ],


    "aggregate": [

      "loveclab-item0ore-rock-clastic", 1.0,
      "loveclab-item0ore-rock-hypabyssal", 1.0,
      "loveclab-item0ore-rock-lava", 1.0,
      "loveclab-item0ore-rock-plutonic", 1.0,
      "loveclab-item0ore-rock-clastic-sedimentary", 1.0,

      "loveclab-item0was-slag", 2.0,

    ],


    "denaturing": [],


  },


};
exports.db = db;
