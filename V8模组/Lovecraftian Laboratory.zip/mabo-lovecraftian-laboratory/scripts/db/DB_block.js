db = {


  "map": {


    "faction": [


      "loveclab-eff0core-ash", "outpost-military",


    ],


  },


};
exports.db = db;
