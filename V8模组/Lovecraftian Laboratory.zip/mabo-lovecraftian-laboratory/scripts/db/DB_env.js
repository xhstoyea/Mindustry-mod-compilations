const db = {


  "param": {


    "pla": {


      "wind": [

        "loveclab-pla0ter-anthimyst", 1.0,

      ],


    },


    "map": {


      "weArr": [],


    },


  },


  "nodeRootNameMap": [

    "loveclab-eff0core-ash", "loveclab-pla0ter-anthimyst",

  ],


};
exports.db = db;
