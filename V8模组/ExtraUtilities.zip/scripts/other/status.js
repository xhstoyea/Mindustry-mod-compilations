const lib = require("blib");
const status = lib.getClass("ExtraUtilities.content.EUStatusEffects");
global.status = status;
module.exports = status;