let 暴君 = new ErekirUnitType("暴君");
暴君.constructor = prov(() => extend(UnitTypes.conquer.constructor.get().class, {}));

//需求：命中大体积单位产生额外溅射
//圆形溅射伤害：基础伤害 * 目标体积;  注：伤害仅与命中目标的体积有关
//破片溅射数目：基础数目 + 目标体积  / 10（向上取整）

//圆形溅射范围最小值
const rangeMin = 24;
//范围比例
const rangeScl = 2.2;
//基础溅射伤害
const baseDamage = 40;

let 圆溅effect = new MultiEffect(
    new Effect(20, e => {
        if(e.data === null) return;

        let len = 24;
        if(e.data instanceof Unit) len = e.data.type.hitSize * rangeScl * e.fin();
        else if(e.data instanceof Building) len = e.data.type.size * rangeScl * e.fin();

        len = Math.max(rangeMin,len);

        Draw.color(Color.valueOf("ffdfb0"));
        Lines.stroke(3 * e.fout());
        Lines.circle(e.x,e.y,len);
    })
    
)

let 主武hit = extend(ParticleEffect,{
    interp : Interp.circleOut,
    sizeInterp : Interp.pow10In,
    lifetime : 240,
    cone : 360,
    particles : 12,

    baseLength : 8,
    length : 64,
    sizeFrom : 12,
    sizeTo : 8,
    colorFrom : Color.valueOf("ffdfb080"),
    colorTo : Color.valueOf("ffdfb000")
})

let 主武子弹 = extend(BasicBulletType,{
    sprite: "mee-抹除子弹",
    height: 72,
    width: 24,
    trailColor: Color.valueOf("ffdfb0"),
    trailLength: 16,
    trailWidth: 4,

    speed: 14,
    lifetime: 45,
    reflectable: false,
    absorbable:false,

    damage: 1850,
    pierce: true,
    pierceCap : 2,
    pierceArmor: true,
    pierceBuilding: true,

    hitEffect : 主武hit,
    despawnEffect : 主武hit,

    hitEntity(b,entity,health){
        this.super$hitEntity(b,entity,health);
        if(entity instanceof Unit){
            Damage.damage(b.team,entity.x,entity.y,entity.type.hitSize * rangeScl,baseDamage * b.damageMultiplier() * entity.type.hitSize,true, true,true,false,b);
            圆溅effect.at(entity.x,entity.y,0,entity);
        } else if(entity instanceof Building && entity.block != null) {
            Damage.damage(b.team,entity.x,entity.y,entity.type.size * rangeScl,baseDamage * b.damageMultiplier() * entity.type.size * entity.type.size,true, true,true,false,b);
            圆溅effect.at(entity.x,entity.y,0,entity);
        }
    }
})
const 暴君主炮 = extend(Weapon, "mee-暴君主炮",{
    mirror: false,
    rotate: true,
    rotateSpeed: 0.8,
    x: 0,
    y: 0,
    shootY:24,
    reload: 240,
    shake:42,
    bullet: 主武子弹,
    shoot: Object.assign(new ShootBarrel(), {
        barrels: [
            -10, 0, 0,
            10,0,0
        ]
    })
    //shootSound:"暴君主炮-shoot"
})

暴君.weapons.add(暴君主炮);
//暴君.weapons.add(暴君副武);
exports.暴君 = 暴君;