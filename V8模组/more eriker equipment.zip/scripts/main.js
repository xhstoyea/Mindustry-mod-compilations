
//来自九二零的代码
require("units/暴君");

