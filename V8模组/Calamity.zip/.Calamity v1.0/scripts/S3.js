/*pardon改进了这个文件*/
const core = require("core");

const S3 = new Planet("S3", Planets.sun,5);
S3.radius = 5;
S3.orbitSpacing = 600;
S3.bloom = true;
S3.accessible = true
S3.visible = true;
S3.localizedName = "[#FFC64C]S3"
S3.orbitRadius = 690; //公转半径
S3.orbitTime = 2400 * 60; //公转一圈时间
S3.rotateTime = 24 * 60; //自转一圈时间
S3.meshLoader = () => new SunMesh(S3,3, 6, 3.4, 2.8, 1.3, 0.8, 1.1,
    Color.valueOf("FF7A38"),
    Color.valueOf("FF9638"),
    Color.valueOf("FFC64C"),
    Color.valueOf("FFC64C"),
    Color.valueOf("FFE371"),
    Color.valueOf("F4EE8E")
);

const V3 = new Planet("V3", S3 , 1, 4);

V3.meshLoader = prov(() => new MultiMesh(
    new NoiseMesh(V3,0,5,0.94,1,0.0001,0.0001,1,Color.valueOf("28ab99"),Color.valueOf("28ab99"),1,1,1,1),
    new NoiseMesh(V3,0,6,0.94,4.6,0.9,0.7,1,Color.valueOf("d3ae8d"),Color.valueOf("9192ab"),1,1,1.8,1),
    new NoiseMesh(V3,0,6,0.895,4.6,0.9,0.7,1.5,Color.valueOf("6aa95a"),Color.valueOf("80cb71"),4,1,1.8,1),
    new NoiseMesh(V3,0,6,0.83,4.6,0.9,0.7,2.2,Color.valueOf("c1c4cb"),Color.valueOf("525252"),4,1,0.7,1),
    new NoiseMesh(V3,0,6,0.74,4.6,0.9,0.7,3.3,Color.valueOf("d1efff"),Color.valueOf("d1efff"),4,1,1.8,1)
));
V3.cloudMeshLoader = prov(() => new MultiMesh(
    new HexSkyMesh(V3,0,3,0.1,6,Color.valueOf("e8effa88"),3,0.3,1,0.43),
    new HexSkyMesh(V3,0,2,0.11,6,Color.valueOf("e8effabb"),3,0.5,0.9,0.43),
    new HexSkyMesh(V3,0,-2,0.034,5,Color.valueOf("35bda8"),0.4,0.2,0.2,0.4)
))
V3.generator = extend(ErekirPlanetGenerator,{
getDefaultLoadout(){
return Schematics.readBase64("bXNjaAF4nGNgYWBhZmDJS8xNZeDOL8pMz8zTTc4vAnJSUouTizILSjLz8xgYGNhyEpNSc4oZmKJjGRlEkhNzEnMzSyp1kXUwMDCCEJAAANOhFfM=");
		}//核心默认蓝图
	});
//星球生成器（塞）

V3.defaultCore = core.originCore;
//V3.solarSystem = "[#FFC64C]S3";//系统
V3.visible = true;//可见
V3.tidalLock = false;//潮汐锁定
V3.accessible = false;//在行星菜单可见
V3.alwaysUnlocked = false;//总是解锁
V3.allowLaunchLoadout = false;//可携带初始物资
V3.clearSectorOnLose = true; //重置战败区块
V3.localizedName = "维托斯普"; //名字
V3.bloom = true; //启用Bloom渲染效果
V3.startSector = 15; //初始区块
V3.allowLaunchSchematics = false;//
V3.orbitRadius = 60; //公转半径
V3.orbitTime = 240 * 60; //公转一圈时间
V3.rotateTime = 24 * 60; //自转一圈时间
V3.atmosphereRadIn = 0.05; //进入大气层距离
V3.atmosphereRadOut = 0.5; //离开大气层距离
V3.allowWaves = true;//存在后台模拟
V3.allowWaveSimulation = true;//后台波次模拟
V3.allowSectorInvasion = true;//区块入侵
//V3.atmosphereColor = V3.lightColor = Color.valueOf("BCCEE3FF"); //大气层 发光颜色
/*V3.hiddenItems.addAll(
    Items.copper,
    Items.lead,
    Items.titanium,
    Items.thorium,
    Items.beryllium,
    Items.oxide,
    Items.carbide
)*/
exports.V3 = V3

