const nickel = new Item('nickel');
exports.nickel = nickel
const chromium = new Item('chromium');
exports.chromium = chromium
const uraniumMine = new Item('uraniumine');
exports.uraniumMine = uraniumMine
const uranium = new Item('uranium');
exports.uranium = uranium
const osmiridiumMine = new Item('osmiridiumine');
exports.osmiridiumMine = osmiridiumMine
const iridium = new Item('iridium');
exports.iridium = iridium
const osmium = new Item('osmium');
exports.osmium = osmium

const lithium = new Item('lithium');
exports.lithium = lithium
const plutonium = new Item('plutonium');
exports.plutonium = plutonium

const processorJunior = new Item('processor-junior');
exports.processorJunior = processorJunior
const processorSenior = new Item('processor-senior');
exports.processorSenior = processorSenior
const selfHealingAlloy = new Item('self-healing-alloy');
exports.selfHealingAlloy = selfHealingAlloy
const resonantCrystal = new Item('resonant-crystal');
exports.resonantCrystal = resonantCrystal

const wulfrumSchematics = new Item('wulfrum-schematics');
exports.wulfrumSchematics = wulfrumSchematics
const wulfrumSteel = new Item('wulfrum-steel');
exports.wulfrumSteel = wulfrumSteel
const energyCore = new Item('energy-core');
exports.energyCore = energyCore
