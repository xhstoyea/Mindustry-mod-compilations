const items = require("items");

Events.on(EventType.ClientLoadEvent, e => {
    Vars.renderer.planets.cam.far = 2400;
});
Planets.sun.radius = 92;
Planets.sun.orbitSpacing = 3000;
Planets.sun.accessible = true;
Planets.sun.alwaysUnlocked = true;
Planets.sun.visible = true;
Planets.sun.localizedName = "[#FFC64C]Lacinia";
Planets.sun.minZoom=0.1;
Planets.sun.grid = PlanetGrid.create(1);
Planets.sun.sectors.ensureCapacity(Planets.sun.grid.tiles.length);
for(let i = 0; i < Planets.sun.grid.tiles.length; i++){
                Planets.sun.sectors.add(new Sector(Planets.sun, Planets.sun.grid.tiles[i]));
            };

/*Planets.serpulo.hiddenItems.addAll(
    items.nickel,
    items.chromium,
    items.iridium,
    items.osmium,
    items.uranium,
)*/
Planets.erekir.orbitRadius = 130; //公转半径
/*Planets.erekir.hiddenItems.addAll(
    items.nickel,
    items.chromium,
    items.iridium,
    items.osmium,
    items.uranium,
)*/
Planets.tantros.orbitRadius = 350; //公转半径
Planets.tantros.visible = true;//可见
//Planets.tantros.accessible = false;//在行星菜单可见
//Planets.tantros.localizedName = "坦特罗斯"; //名字
//Planets.tantros.alwaysUnlocked = true;//解锁
