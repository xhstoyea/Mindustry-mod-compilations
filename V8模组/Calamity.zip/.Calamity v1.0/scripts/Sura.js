/*pardon改进了这个文件*/
const items = require("items");
const liquids = require("liquids");
const core = require("core");

const Sura = new Planet("Sura", Planets.sun,5);
Sura.radius = 5;
Sura.orbitSpacing = 600;
Sura.bloom = true;
Sura.accessible = true
Sura.visible = true;
Sura.localizedName = "[#FFC64C]Sura"
Sura.orbitRadius = 470;
Sura.orbitTime = 2400 * 60;
Sura.rotateTime = 24 * 60;
Sura.meshLoader = () => new SunMesh(Sura,3, 6, 3.4, 2.8, 1.3, 0.8, 1.1,
    Color.valueOf("FF7A38"),
    Color.valueOf("FF9638"),
    Color.valueOf("FFC64C"),
    Color.valueOf("FFC64C"),
    Color.valueOf("FFE371"),
    Color.valueOf("F4EE8E")
);

/*const wulfrum = extend(Team,100,"wulfrum", Color.valueOf("55FBA5FF"),{})
exports.wulfrum = wulfrum;
*/

const Vitospp = new Planet("Vitospp", Sura , 1, 4);

Vitospp.meshLoader = prov(() => new MultiMesh(
    new NoiseMesh(Vitospp,0,5,0.94,1,0.0001,0.0001,1,Color.valueOf("28ab99"),Color.valueOf("28ab99"),1,1,1,1),
    new NoiseMesh(Vitospp,0,6,0.94,4.6,0.9,0.7,1,Color.valueOf("d3ae8d"),Color.valueOf("9192ab"),1,1,1.8,1),
    new NoiseMesh(Vitospp,0,6,0.895,4.6,0.9,0.7,1.5,Color.valueOf("6aa95a"),Color.valueOf("80cb71"),4,1,1.8,1),
    new NoiseMesh(Vitospp,0,6,0.83,4.6,0.9,0.7,2.2,Color.valueOf("c1c4cb"),Color.valueOf("525252"),4,1,0.7,1),
    new NoiseMesh(Vitospp,0,6,0.74,4.6,0.9,0.7,3.3,Color.valueOf("d1efff"),Color.valueOf("d1efff"),4,1,1.8,1)
));
Vitospp.cloudMeshLoader = prov(() => new MultiMesh(
    new HexSkyMesh(Vitospp,0,3,0.1,6,Color.valueOf("e8effa88"),3,0.3,1,0.43),
    new HexSkyMesh(Vitospp,0,2,0.11,6,Color.valueOf("e8effabb"),3,0.5,0.9,0.43),
    new HexSkyMesh(Vitospp,0,-2,0.034,5,Color.valueOf("35bda8"),0.4,0.2,0.2,0.4)
))
Vitospp.generator = extend(ErekirPlanetGenerator,{
getDefaultLoadout(){
return Schematics.readBase64("bXNjaAF4nGNgYWBhZmDJS8xNZeDOL8pMz8zTTc4vAnJSUouTizILSjLz8xgYGNhyEpNSc4oZmKJjGRlEkhNzEnMzSyp1kXUwMDCCEJAAANOhFfM=");
		}//核心默认蓝图
	});
//星球生成器（塞）

Vitospp.defaultCore = core.originCore;
//Vitospp.solarSystem = "[#FFC64C]Sura";//系统
Vitospp.visible = true;
Vitospp.tidalLock = false;
Vitospp.accessible = true;
Vitospp.alwaysUnlocked = true;
Vitospp.allowLaunchLoadout = false;//可携带初始物资
Vitospp.clearSectorOnLose = true; //重置战败区块
Vitospp.localizedName = "维托斯普"; //名字
Vitospp.bloom = true; //启用Bloom渲染效果
Vitospp.startSector = 15; //初始区块
Vitospp.allowLaunchSchematics = false;//
Vitospp.orbitRadius = 50; //公转半径
Vitospp.orbitTime = 60 * 60; //公转一圈时间
Vitospp.rotateTime = 24 * 60; //自转一圈时间
Vitospp.atmosphereRadIn = 0.05; //进入大气层距离
Vitospp.atmosphereRadOut = 0.5; //离开大气层距离
Vitospp.allowWaves = true;//存在后台模拟
Vitospp.allowWaveSimulation = true;//后台波次模拟
Vitospp.allowSectorInvasion = true;
Vitospp.allowCampaignRules = true;
Vitospp.allowLaunchToNumbered = false;//解锁数字区
//Vitospp.atmosphereColor = Vitospp.lightColor = Color.valueOf("BCCEE3FF"); //大气层 发光颜色
/*Vitospp.hiddenItems.addAll(
    Items.copper,
    Items.lead,
    Items.titanium,
    Items.thorium,
    Items.beryllium,
    Items.oxide,
    Items.carbide
)*/
exports.Vitospp = Vitospp

const nodeRoot = TechTree.nodeRoot;
const nodeProduce = TechTree.nodeProduce;
const node = TechTree.node;
const SectorComplete = Objectives.SectorComplete;
const Research = Objectives.Research;

/*Vitospp.techTree = TechTree.nodeRoot("钨钢科技",core.wulfrumCore ,() => {

nodeProduce(Items.tungsten, () => {
nodeProduce(items.wulfrumSteel , () => {
nodeProduce(items.energyCore , () => {})
})

nodeProduce(Items.sand, () => {
nodeProduce(Items.graphite, () => {
nodeProduce(Items.silicon, () => {})
})
})
})
}),*/

Vitospp.techTree = TechTree.nodeRoot("维托斯普",core.originCore ,() => {

nodeProduce(items.nickel, () => {

nodeProduce(Items.tungsten, () => {
nodeProduce(items.chromium, () => {
nodeProduce(items.selfHealingAlloy, () => {
}),

nodeProduce(items.osmiridiumMine, () => {
nodeProduce(items.iridium, () => {}),
nodeProduce(items.osmium, () => {})
}),

nodeProduce(items.uraniumMine, () => {
nodeProduce(items.uranium, () => {
nodeProduce(Items.phaseFabric, () => {}),
nodeProduce(items.plutonium, () => {
nodeProduce(items.resonantCrystal, () => {})
})
})
})
})
}),

nodeProduce(Liquids.water, () => {
nodeProduce(Items.sporePod, () => {}),
nodeProduce(items.lithium, () => {}),
nodeProduce(Liquids.hydrogen, () => {
nodeProduce(Liquids.cryofluid, () => {}),

nodeProduce(Liquids.ozone, () => {
nodeProduce(liquids.helium, () => {}),
nodeProduce(Liquids.nitrogen, () => {
nodeProduce(Liquids.cyanogen, () => {})
})
})
})
}),

nodeProduce(Items.sand, () => {

nodeProduce(Items.metaglass, () => {}),

nodeProduce(Items.scrap, () => {
nodeProduce(Liquids.slag, () => {
nodeProduce(Items.surgeAlloy, () => {})
})
}),

nodeProduce(Items.coal, () => {
nodeProduce(Items.graphite, () => {
nodeProduce(Items.plastanium, () => {}),
nodeProduce(Items.silicon, () => {
nodeProduce(items.processorJunior, () => {
nodeProduce(items.processorSenior , () => {})
})
})
})
}),

nodeProduce(Liquids.oil, () => {
nodeProduce(Items.pyratite, () => {
nodeProduce(Items.blastCompound, () => {})
})
})
})
})
})