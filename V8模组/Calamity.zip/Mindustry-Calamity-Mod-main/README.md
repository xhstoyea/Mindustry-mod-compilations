# Mindustry Calamity MOD

---

![Logo](github-pictures/logo.png)

**WUIFRUM COMING**

**A mod built in [Mindustry](https://github.com/Anuken/Mindustry) using the old lore of the Terraria [Calamity](https://github.com/CalamityTeam/CalamityModPublic) Mod as its backstory.**

**Powered by *[Undaria](https://github.com/Undaria)* **

---

## Community
+ **Discord Server**

  [![Discord](https://shields.io/)](https://discord.gg/zB9Kf5ZWCG)

+ **QQ Group | QQ群**

  ![QQ](github-pictures/qq-code.png)

---

## Overview
</div>

- Over 300 pieces of unique and fresh content, including blocks, units, items and more
- 165 environmental blocks
- 6 campaign sectors. 
- 61 units
- 2 techtrees
<br>
<br>

<div align = center>
