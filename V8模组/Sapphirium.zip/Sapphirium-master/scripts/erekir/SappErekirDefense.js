const sapphireRestorer = extend(MendProjector, "sapphire-restorer", {});
const energyFieldEr = extend(UnitCargoLoader, "energy-field-projector-erekir", {});