package ice.classes.blocks.environment;

import mindustry.world.Tile;

public interface EnvUpdate {
    void updateTile(Tile tile);
}
