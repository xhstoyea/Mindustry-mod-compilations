![text](https://github.com/RouterXdd/Icicle-World/assets/91018607/002c2bd6-30ec-49c9-b322-a831f07f3821)

Java mod, who adds an ice planet with awful secret inside
# Special
Trello: https://trello.com/invite/b/Mmpg4hp6/ATTI62287b36d5a769ecdfbd3da72886abdf2705666A/icicle-world-buried-in-ice

Discord server (Eternity Universe): https://discord.gg/GVy5YbzQSH
