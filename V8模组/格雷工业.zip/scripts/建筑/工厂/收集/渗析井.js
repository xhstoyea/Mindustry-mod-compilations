const myLiquids=require("数据/vars/液体")
const aaaa=[0,0,0,1,1,0,1,1]
//~~~~~~~~~~~~~~~
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
function getbyname(name){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
const 渗析井 = extend(GenericCrafter, '渗析井', {
	    setStats() {
        this.super$setStats()
        this.stats.remove(Stat.output);
        this.stats.add(new Stat("输出", new StatCat("输出")), aaa())
      //  this.stats.add(Stat.input,aaa())
    },
    	setBars() {
		this.super$setBars();
		this.addBar("efficiency", func(e => new Bar(
			prov(() => "效率"),
			prov(() =>  Color.valueOf("ffd06d")),
			floatp(() => e.regeteff()*10)
		)));
	},
});
渗析井.configurable = false
渗析井.buildType = prov(() => {
    var other=1
    var salts=0,muds=0
    var timer=0,eff=0,attr
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
shouldConsume(){
    return false
},
check(){
    if (this.liquids.get(Liquids.water)<eff){
        return false
    }
    if (this.liquids.get(myLiquids.微生物悬浊液)>this.block.liquidCapacity-eff){
        return false
    }
    if (this.liquids.get(myLiquids.盐水)>this.block.liquidCapacity-eff){
        return false
    }
    if (attr=="mud"&&this.liquids.get(myLiquids.盐水)>0.01){
        return false
    }
    if (attr=="salt"&&this.liquids.get(myLiquids.微生物悬浊液)>0.01){
        return false
    }
    if (attr=="none"){
        return false
    }
    return true
},
regeteff(){
    return eff
},
geteff(){
    eff=0
    muds=0
    salts=0
    attr="none"
    for (var i=0;i<4;i++){
    other=Vars.world.tile(this.tileX()+aaaa[i*2], this.tileY()+aaaa[1+i*2]).floor()
    if (other.name=="泥土"){muds++}
    if (other.name=="salt"){salts++}
    }
    if (muds>=salts&&muds>0){
        attr="mud"
        eff=muds/4
    }
    if (salts>muds){
        attr="salt"
        eff=salts/4
    } 
    return eff
},
getprogressmul(){
    return this.getProgressIncrease(60)*60*eff
},
updateTile(){
    timer++
    if (timer>=4){
    eff=0.1*r(this.geteff(),3)
    timer=0
    }
    if (this.check()){
        this.liquids.remove(Liquids.water,this.getprogressmul())
        if (attr=="mud"){
            this.handleLiquid(this,myLiquids.微生物悬浊液,this.getprogressmul())
        }
        if (attr=="salt"){
            this.handleLiquid(this,myLiquids.盐水,this.getprogressmul())
        }
    }
    this.dumpLiquid(myLiquids.盐水)
    this.dumpLiquid(myLiquids.微生物悬浊液)
},
    },渗析井);
});
function aaa() {
    return function (table) {
        var m=getbyname("社会主义工业化-泥土")
        table.row()
        table.add("    ")
        table.add(new LiquidDisplay(myLiquids.盐水,6,true)).padRight(5).left()
        table.add("    ")
        table.add(Image(Blocks.salt.uiIcon).setScaling(Scaling.fit)).size(30)
        table.add("  [grey]盐碱地")
        table.row()
        table.add("    ")
       table.add(new LiquidDisplay(myLiquids.微生物悬浊液,6,true)).padRight(5).left()
        table.add("    ")
        table.add(Image(m.uiIcon).setScaling(Scaling.fit)).size(30)
        table.add("  [grey]泥土")
    };
}