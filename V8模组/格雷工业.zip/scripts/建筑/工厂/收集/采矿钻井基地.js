const myLiquids=require("数据/vars/液体")
const mathlib = require("base/MathLib")
const ores=require("特殊/深层矿脉").Oreset
const getid=require("特殊/深层矿脉").getid
//~~~~~~~~~~~~~~~
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
function getbyname(name){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
const liquidconsume=0.25
const powerconsume=5
const producetime=0.35
const 采矿钻井基地 = extend(GenericCrafter, '采矿钻井基地', {
init(){
    this.hasPower = true
    this.consumesPower=true
    this.consumeBuilder.add(extend(ConsumePower, {
        requestedPower(e) {
                var power=powerconsume
                if (!e.checkcraft()){
                        return 0
                }
                return e.getpowerconsume()
            }
        }))
    this.super$init()
},
setBars() {
	this.super$setBars();
	this.removeBar("liquid")
	this.removeBar("items")
    this.addBar("钻井液", e => new Bar(() => "钻井液", () => Color.valueOf("ffd06d"), () => e.getliqbar()))
    this.addBar("矿物效率", e => new Bar(() => e.displaybar(), () => Pal.ammo, () => e.eff()))
},
});
采矿钻井基地.drawer = new DrawMulti(
    new DrawDefault(),
    new DrawWarmupRegion(),
    (() => {
        const d = new DrawRegion("-top")
        d.rotateSpeed = 2;
        return d;
    })()
)
采矿钻井基地.configurable = true
采矿钻井基地.saveConfig=true
采矿钻井基地.buildType = prov(() => {
    var layerset=1
    var process=0
    var orearr=ores.get(getid())
    var oreset={eff:0,ore:null,drop:null}
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
buildConfiguration(table){
        table.table(Tex.button,table => {
    table.add("").update(t => {t.setText("深度:"+layerset)})
    table.row()
	table.slider(1, 32,1, layerset, g=> {
		layerset=g
		this.handleore()
		this.configure(g)
	}).width(300)
	table.row()
    table.add("").update(t => {
        if (this.getore().ore!=null){
            t.setText("矿石: "+this.getore().ore+" "+r(this.getore().eff*100,1)+"%")
        }
        else{t.setText("无矿石")}
        })
        })
},
acceptLiquid(source, liquid){
    if (liquid.name==Liquids.water.name&&this.liquids.get(liquid)<60){
        return true
    }
    return false
},
getoreresult(){
    var square=0
    var ores=null
    var drops=null
    var hardness=1
    var density=1
    for (var i=-1;i<2;i++){
        for (var j=-1;j<2;j++){
            var ore=this.checkore(this.tileX()+i,this.tileY()+j,layerset)
            if (ore!=null){
                square++
                ores=ore.type
                drops=getbyname(ore.drop)
                hardness=ore.hardness
                density=ore.density
            }
        }
    }
    return {eff:square/9,ore:ores,drop:drops,hardness:hardness,density:density}
},
checkore(x,y,layer){
    for (var i=0;i<orearr.length;i++){
        var ore=orearr[i]
        if (ore.layer==layer && mathlib.pointInQuad([x,y],ore.pos)){
            return ore
        }
    }
    return null
},
getore(){
    return oreset
},
setore(g){
    oreset=g
},
handleore(){
    var ores=this.getoreresult()
    this.setore(ores)
},
checkcraft(){
    return this.liquids.get(Liquids.water)>this.processincrease() && this.items.total()<20 && this.getore().ore!=null
},
consume(){
    this.liquids.remove(Liquids.water,this.processincrease()*liquidconsume)
},
handleoutput(){
        this.offload(this.getoutput())
},
handleprocess(){
    process+=this.processincrease()*this.eff()
},
updateTile(){
    if (this.isinit==null){
        this.isinit=true
        this.inits()
    }
    if (this.checkcraft()){

        this.handlewarmup(true)
        this.consume()
        this.handleprocess()
    }
    else{
        this.handlewarmup(false)
    }
    if (process>=60*producetime){
        this.handleoutput()
        Fx.formsmoke.at(this.x, this.y)
        for (var i=0;i<5;i++){
        Fx.plasticburn.at(this.x, this.y)
        }
        process=0
    }
    this.dump()
},
processincrease(){
    return this.getProgressIncrease(60)*60
},
handlewarmup(bool){
    if (bool){
        this.warmup=Mathf.lerpDelta(this.warmup,1,0.02)
    }
    else {
        this.warmup=Mathf.lerpDelta(this.warmup,0,0.02)
    }
},
eff(){
    var ore=this.getore()
    return ore.eff*ore.density/Math.sqrt(ore.hardness)
},
getpowerconsume(){
    return r(powerconsume*Math.sqrt(ore.layer),1)
},
getoutput(){
    return this.getore().drop
},
getliqbar(){
    return this.liquids.get(Liquids.water)/60
},
displaybar(){
    var ore=this.getore()
    if (ore.ore==null){
        return "x"
    }
    return ore.ore+" "+r(ore.eff*100,1)+"%"
},
inits(){
    this.handleore()
},
configured(player,value){
    if (value!=null){
        layerset=value
    }
},
write(write){
    this.super$write(write)
    write.f(process)
    write.f(layerset)    
},
read(read, revision){
    this.super$read(read, revision)
    process=read.f()
    layerset=read.f()
},
    },采矿钻井基地);
});