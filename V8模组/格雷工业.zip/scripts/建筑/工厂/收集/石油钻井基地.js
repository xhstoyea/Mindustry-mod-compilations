const myLiquids=require("数据/vars/液体")
const mathlib = require("base/MathLib")
const orearr = require("矿脉").ore
//~~~~~~~~~~~~~~~
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
function getbyname(name){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
const liquidconsume=0.25
const powerconsume=5
const produce=0.25
const 石油钻井基地 = extend(GenericCrafter, '石油钻井基地', {
init(){
    this.hasPower = true
    this.consumesPower=true
    this.consumeBuilder.add(extend(ConsumePower, {
        requestedPower(e) {
                var power=powerconsume
                if (!e.checkcraft()){
                        return 0
                }
                return powerconsume
            }
        }))
    this.super$init()
},
setBars() {
	this.super$setBars();
	this.removeBar("liquid")
	this.removeBar("items")
    this.addBar("钻井液", e => new Bar(() => "钻井液", () => Color.valueOf("ffd06d"), () => e.getliqbar()))
    this.addBar("矿物效率", e => new Bar(() => e.displaybar(), () => Pal.ammo, () => e.eff()))
},
});
石油钻井基地.configurable = true
石油钻井基地.saveConfig=true
石油钻井基地.buildType = prov(() => {
    var layerset=1
    var process=0
    var oreset={eff:0,ore:null,drop:null}
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
buildConfiguration(table){
    table.add("").update(t => {t.setText("深度:"+layerset)})
    table.row()
	table.slider(1, 32,1, layerset, g=> {
		layerset=g
		this.handleore()
		this.configure(g)
	}).width(300)
	table.row()
    table.add("").update(t => {t.setText(""+this.getore().ore+this.getore().eff)})
},
acceptLiquid(source, liquid){
    if (liquid.name==Liquids.water.name&&this.liquids.get(liquid)<60){
        return true
    }
    return false
},
getoreresult(){
    var square=0
    var ores=null
    var drops=null
    for (var i=-1;i<2;i++){
        for (var j=-1;j<2;j++){
            var ore=this.checkore(this.tileX()+i,this.tileY()+j,layerset)
            if (ore!=null){
                square++
                ores=ore.type
                drops=ore.drop
            }
        }
    }
    return {eff:square/9,ore:ores,drop:drops}
},
checkore(x,y,layer){
    for (var i=0;i<orearr.length;i++){
        var ore=orearr[i]
        if (ore.layer==layer && mathlib.pointInQuad([x,y],ore.pos)){
            return ore
        }
    }
    return null
},
getore(){
    return oreset
},
setore(g){
    oreset=g
},
handleore(){
    var ores=this.getoreresult()
    this.setore(ores)
},
checkcraft(){
    return this.liquids.get(Liquids.water)>this.processincrease() && this.items.total()<10 && this.getore().ore!=null
},
consume(){
    this.liquids.remove(Liquids.water,this.processincrease()*liquidconsume)
},
handleoutput(){
        this.items.add(this.getore().drop,1)
        this.dump()
},
handleprocess(){
    process+=this.processincrease()*this.eff()
},
updateTile(){
    if (this.isinit==null){
        this.isinits=true
        this.inits()
    }
    if (this.checkcraft()){
        this.consume()
        this.handleprocess()
    }
    if (process>=60*producetime){
        this.handleoutput()
        process=0
    }
},
processincrease(){
    return this.getProgressIncrease(60)*60
},
eff(){
    return this.getore().eff
},
getliqbar(){
    return this.liquids.get(Liquids.water)/60
},
displaybar(){
    if (this.getore().ore==null){
        return "x"
    }
    return this.getore().ore+" "+r(this.getore().eff*100,1)+"%"
},
inits(){
    this.handleore()
},
configured(player,value){
    if (value!=null){
        layerset=value
    }
},
write(write){
    this.super$write(write)
    write.f(process)
    write.f(layerset)    
},
read(read, revision){
    this.super$read(read, revision)
    process=read.f()
    layerset=read.f()
},
    },石油钻井基地);
});