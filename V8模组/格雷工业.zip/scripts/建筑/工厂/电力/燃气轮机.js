function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
//~~~~~~~~~~~~~~~
const myLiquids = require("数据/vars/液体")
const fuel=[Liquids.hydrogen,myLiquids.燃油,myLiquids.一氧化碳,myLiquids.乙醇,myLiquids.乙烯,myLiquids.烷烃,myLiquids.硅烷]
const burn=new Map()
burn.set(Liquids.hydrogen.name,6)
burn.set(myLiquids.燃油.name,10)
burn.set(myLiquids.一氧化碳.name,5)
burn.set(myLiquids.乙醇.name,7)
burn.set(myLiquids.乙烯.name,6)
burn.set(myLiquids.烷烃.name,6)
burn.set(myLiquids.硅烷.name,6)
const 燃气轮机 = extend(ConsumeGenerator, '燃气轮机', {
    setStats() {
        this.super$setStats()
        this.stats.remove(Stat.input);
        this.stats.add(new Stat("燃料与燃值", new StatCat("燃料")), aaa())
    },
})
燃气轮机.buildType = prov(() => {
    var burnf
    return new JavaAdapter(ConsumeGenerator.ConsumeGeneratorBuild, {
        acceptLiquid(source, liquid) {
            if (this.liquids.get(liquid)<120 && burn.has(liquid.name)){return true}
            else{return false}
		},
		getPowerProduction(){
		    if (this.liquids.get(this.liquids.current())>0){
		        this.li=5
		        burnf=burn.get(this.liquids.current().name)
		    }
		    else{burnf=0}
		    return 15*burnf/6
		}
    },燃气轮机);
});
function aaa() {
    return function (table) {
        for (var i=0;i<fuel.length;i++){
        table.add(new LiquidDisplay(fuel[i],60,false)).padRight(5).left()}
        
    };
}
