
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
function lerpDelta(a,b,delta){
    return a+(b-a)*delta
}          //线性插值
function f(x,a){
    return a*Math.pow(x,2)+((1-a)*x)
}
function po(d,range,mul,a){
    if (d<=range){
        return r(f(((range+1-d)/range),a)*mul,2)
    }
    else {return 0}
}
//~~~~~~~~~~~~~~~
const range=8
const mul=0.12
const a=0.63               //0<a<1
var weathermul=new Map()
weathermul.set("rain",1.3)
weathermul.set("snow",0.8)
weathermul.set("sandstorm",1.2)
weathermul.set("sporestorm",1.5)
const 风力发电机 = extend(ConsumeGenerator, '风力发电机', {
    setStats() {
        this.super$setStats()
        this.stats.remove(Stat.input);
        this.stats.add(new Stat("条件", new StatCat("条件")), aaa());
    },
    setBars() {
		this.super$setBars();
		this.addBar("heat", func(e => new Bar(
			prov(() => "效率"+r(e.geteff()*100,2)+"%"),
			prov(() =>  Color.valueOf("ffd06d")),
			floatp(() => e.geteff())
		)));
	},
})
风力发电机.warmupSpeed = 0
风力发电机.buildType = prov(() => {
    var count=0
    var ix=-range,iy=-range,r=0
    var target,other
    var bar=0,warmup=0
    return new JavaAdapter(ConsumeGenerator.ConsumeGeneratorBuild, {
        updateTile(){
		/*	Vars.indexer.eachBlock(this, 160,boolf(other => other!=this), cons(other => {
				amount+=other.block.size*other.block.size
			}))*/
	this.super$updateTile();
	if (this.bar==null){this.bar=0}
	target=Vars.world.tile(this.tileX()+ix, this.tileY()+iy).block()
	other=Vars.world.build(this.tileX()+ix, this.tileY()+iy)
	if (target.toString()!="air"&&other!=this){
	    count+=po(Math.abs(ix)+Math.abs(iy),range,mul,a)
	}
	ix++
	if(ix>=range+1){
	    ix=-range
	    iy++
	}
	if (iy>=range+1){
	    iy=-range
	    this.bar=count
	    count=0
	}
	if (Math.abs(this.warmup-this.geteff())<0.01){
	    this.warmup=this.geteff()
	}
	else{
	    if(this.warmup<this.geteff()){               this.warmup=lerpDelta(this.warmup,this.geteff(),0.002*this.geteff())
	    }
	    else{
	        this.warmup-=0.002
	    }
	    
	}
//	Vars.ui.showLabel(this.bar, 3, this.x, this.y)
        },
        getbars(){
            if (this.bar<1){
            return this.bar}
            else return 1
        },
		getPowerProduction(){
		    return 3*this.geteff()
		},
		geteff(){
		    return (1-this.getbars())*this.weatherboost()
		},
		weatherboost(){
		    var wea=Groups.weather
		    var boost=1
		    for (var i=0;i<wea.size();i++){
		        var weas=wea.index(i).weather.name
		        if (weathermul.has(weas)){
		            boost*=weathermul.get(weas)
		        }
		    }
		    return boost
		},
    	write(write){
    		this.super$write(write)
    		bar=this.bar
    		warmup=this.warmup
    		write.f(bar);
    		write.f(warmup)
    	},
    	read(read, revision){
    		this.super$read(read, revision);
    		bar = read.f();
    		warmup=read.f()
    		this.bar=bar
    		this.warmup=warmup
    	},
    },风力发电机);
});
function aaa() {
    return function (table) {
        table.add("需要空旷区域");
        table.row()
    };
}