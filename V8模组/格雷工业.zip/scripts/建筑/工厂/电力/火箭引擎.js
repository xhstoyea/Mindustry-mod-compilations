function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
function rand(b){
    return Math.floor(Math.random()*(b+1))
}
function fp(n,x){
    var y=n*x
    return y
}           //功率计算
function lerpDelta(a,b,delta){
    return a+(b-a)*delta
}          //线性插值
function getbyname(name){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
//~~~~~~~~~~~~~~
const list=[1,0,0,1,-1,0,0,-1]
const 火箭引擎 = extend(ConsumeGenerator, '火箭引擎', {
    drawPlace(x, y, rotation, valid) {
        Drawf.dashSquare(Color.white, x * 8+list[rotation*2]*4*8, y * 8+list[1+rotation*2]*4*8, 32)
    }, 
    setBars() {
		this.super$setBars();
		this.removeBar("liquid")		
		this.addBar("效率", func(e => new Bar(
			prov(() => "效率"),
			prov(() => Pal.ammo),
			floatp(() => e.geteff())
		)))
		this.addBar("liquid1", func(e => new Bar(
			prov(() => myliquids.肼.localizedName),
			prov(() => Color.valueOf("00ffff")),
			floatp(() => e.fuel()/120)
		)))
		this.addBar("liquid2", func(e => new Bar(
			prov(() => myliquids.氧气.localizedName),
			prov(() => Color.valueOf("ffd06d")),
			floatp(() => e.oxyg()/120)
		)))
	},
    	    setStats() {
        this.super$setStats()
        this.stats.add(Stat.input, new JavaAdapter(StatValue,{
            display(table){
                table.add(new LiquidDisplay(myliquids.肼,1,false)).padRight(5).left()
                table.add(new LiquidDisplay(myliquids.氧气,1,false)).padRight(5).left()
                table.add("[accent] ~ ") 
                table.add(new LiquidDisplay(myliquids.肼,60,false)).padRight(5).left()
                table.add(new LiquidDisplay(myliquids.氧气,60,false)).padRight(5).left()
            }}))
    },
})
const myliquids = require("数据/vars/液体")
火箭引擎.warmupSpeed = 0
火箭引擎.configurable = true;
火箭引擎.buildType = prov(() => {
    var end=0
    var fuellp=0
    var exfuelmul=0
    var exoxygmul=0
    var repow=0
    var rewarmup=0
    var cover=0
    var timer=0
    return new JavaAdapter(ConsumeGenerator.ConsumeGeneratorBuild, {
    	buildConfiguration(table){
            //table.background(Tex.button)
            table.add("        [accent]"+"流量通道：" +end).update(t => {t.setText("        [accent]"+"流量通道: "+end)}).left()
            table.row()
            table.add("        [accent]"+"燃料等效流量：" +r(this.refuel(),1)).update(t => {t.setText("        [accent]"+"燃料等效流量: "+r(this.refuel(),2))}).left()
            table.row()
            table.add("        [accent]"+"氧气等效流量：" +r(this.reoxyg(),1)).update(t => {t.setText("        [accent]"+"氧气等效流量: "+r(this.reoxyg(),2))}).left()
            table.row()
            table.add("        [accent]"+"实际效率："+r((this.geteff()*this.covmul()*100),2)+"%").update(t => {t.setText("        [accent]"+"实际效率: "+r((this.geteff()*this.covmul()*100),2)+"%")}).left()
            table.row()
            table.add("        [accent]"+"预热："+(rewarmup*100,1)+"%").update(t => {t.setText("        [accent]"+"预热: "+r(rewarmup*100,1)+"%")}).left()
            table.row()
            table.add("        [accent]"+"功率："+r(this.getPowerProduction()*60,0)).update(t => {t.setText("        [accent]"+"功率: "+r(this.getPowerProduction()*60,0))}).left()
            table.row()
            table.add("        [accent]"+"流量阀").left()
            table.row()
			table.slider(0, 60, 1, end, g=> {
			    end=g
			    fuellp=end/60
			}).width(300);
    	},
        acceptLiquid(source, liquid){
            if (liquid.name==myliquids.肼.name&&this.fuel()<120){
                return true
            }
            if (liquid.name==myliquids.氧气.name&&this.oxyg()<120){
                return true
            }
            return false
        },
        updateTile(){
            timer++
	        this.super$updateTile()
	        this.handlewarmup()
	        this.handlerepow()
	        if (timer>=6){
	            cover=this.handlecover()
	            this.handlepressure()
	            timer=0
	        }
            this.reduceexfuelmul()
            if (this.enoughfuel()){
                this.consumefuel()
            }
            if (this.enoughoxyg()){
                this.consumeoxyg()
            }
            this.warmup=repow*rewarmup/r((fp(1,60)/50),2)
        },
        fuel(){
            return this.liquids.get(myliquids.肼)
        },
        oxyg(){
            return this.liquids.get(myliquids.氧气)
        },
        consumefuel(){
                this.liquids.remove(myliquids.肼,fuellp)
                this.hasconsumedfuel()
        },
        consumeoxyg(){
                this.liquids.remove(myliquids.氧气,fuellp)
                this.hasconsumedoxyg()
        },
        hasconsumedfuel(){
            exfuelmul+=0.01
        },
        hasconsumedoxyg(){
            exoxygmul+=0.01
        },
        reduceexfuelmul(){
            exfuelmul-=exfuelmul*0.01
            exoxygmul-=exoxygmul*0.01
        },
        hasfuel(){
            return this.fuel()>0
        },
        hasoxyg(){
            return this.oxyg()>0
        },
        enoughfuel(){
            return this.hasfuel() && this.fuel()>=fuellp
        },
        enoughoxyg(){
            return this.hasoxyg() && this.oxyg()>=fuellp
        },
        refuel(){
            return r(fuellp*exfuelmul*60,1)
        },
        reoxyg(){
            return r(fuellp*exoxygmul*60,1)
        },
        ratmul(){
            if (this.refuel()==this.reoxyg()){
                return 1
            }
            if (this.refuel()>this.reoxyg()){
                return r(Math.sqrt(this.reoxyg()/this.refuel()),2)
            }
            return r(this.refuel()/this.reoxyg(),2)
        },
        lpmul(){
            if (this.refuel()==end){
                return 1
            }
            return r(Math.sqrt(this.refuel()/end),2)
        },
        covmul(){
            if (1-cover>0){
                return 1-cover
            }
            return 0
        },
        handlecover(){
            var cov=0
            Vars.indexer.eachBlock(null,this.x+list[this.rotation*2]*4*8,this.y+list[1+this.rotation*2]*4*8,16,boolf(other => other!=this), cons(other => {
                var d=Math.abs(other.tileX()-this.tileX())+Math.abs(other.tileY()-this.tileY())
                cov+=35*Math.pow(other.block.size,2)/Math.pow(d,4)
                other.health-=this.warmup*40*other.block.size/Math.pow(d,3)
                if (this.warmup>0.1){
                Fires.create(other.tile)
                }
                if (other.health<=0.1){
                    other.kill()
                }
			}))
			return cov
        },
        handlepressure(){
            var cov=0
            Vars.indexer.eachBlock(null,this.x+list[this.rotation*2]*8,this.y+list[1+this.rotation*2]*8,8,boolf(other => other!=this), cons(other => {
                cov++
            }))
            if (cov>0){
                this.health-=this.warmup*100
                if (this.health<=0.1){
                    this.kill()
                }            
            }
        },
        geteff(){
            return r(this.ratmul()*this.lpmul(),4)
        },
        getpow(){
            return r((fp(this.geteff(),this.refuel())/50),4)
        },
        getpowmul(){
            return repow/this.getpow()
        },
		getPowerProduction(){
		    return this.block.powerProduction*repow*rewarmup*this.covmul()
		},
		handlerepow(){
		    if (this.getpow()==0){
		        if (repow==0){
		            return
		        }
		        if (repow<0.02){
		            repow=0
		            return
		        }
		        repow=lerpDelta(repow,0,0.005)
		        repow-=0.0002
		        return
		    }
		    if (this.getpowmul()<0.99){
		        repow=lerpDelta(repow,this.getpow(),0.001)
		        return
		    }
		    if (this.getpowmul()>1.01){
		        repow=lerpDelta(repow,this.getpow(),0.005)
		        repow-=0.0002
		        return
		    }
		    repow=this.getpow()
		},
		handlewarmup(){
		    if (this.getpow()>0){
		        if (rewarmup>0.99){
		            rewarmup=1
		            return
		        }
		        rewarmup=lerpDelta(rewarmup,1,0.0008)
		        return
		    }
		    if (rewarmup<0.01){
		        rewarmup=0
		        return
		    }
		    rewarmup-=0.001
		    rewarmup=lerpDelta(rewarmup,0,0.0003)
		},
        ambientVolume(){
            return this.warmup*this.block.ambientSoundVolume
        },
        drawSelect(){
            Drawf.dashSquare(
		        Color.white,
	         this.x+list[this.rotation*2]*4*8,this.y+list[1+this.rotation*2]*4*8,32
		    )
        },
    	write(write){
    		this.super$write(write)
    		write.f(end)
    		write.f(fuellp)
    		write.f(exfuelmul)
    		write.f(exoxygmul)
    		write.f(repow)
    		write.f(rewarmup)
    	},
    	read(read, revision){
    		this.super$read(read, revision)
    		end=read.f()
    		fuellp=read.f()
    		exfuelmul=read.f()
    		exoxygmul=read.f()
    		repow=read.f()
    		rewarmup=read.f()
    	},
    },火箭引擎)
});