const 硅烷聚合厂 = extend(GenericCrafter, '硅烷聚合厂', {});
exports.硅烷聚合厂 = 硅烷聚合厂
