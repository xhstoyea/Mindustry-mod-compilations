const 乙烯聚合厂 = extend(GenericCrafter, '乙烯聚合厂', {});
exports.乙烯聚合厂 = 乙烯聚合厂
