const 超净间 = extend(GenericCrafter, '超净间', {});
exports.超净间 = 超净间
