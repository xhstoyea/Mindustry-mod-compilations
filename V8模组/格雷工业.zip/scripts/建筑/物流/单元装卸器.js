function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
function getbyname(name){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
const danmap = require("数据/value").danmap
//~~~~~~~~~~~~~~~
const 单元装卸器 = extend(Unloader, '单元装卸器', {});
单元装卸器.buildType = prov(() => {
    var others=Vars.content.liquids()   
    var q=[]
    for (var i=0;i<others.size;i++){
        q[i]=others.get(i)}
    var a =0
	return new JavaAdapter(Unloader.UnloaderBuild, {
    	buildConfiguration(table){
    	this.sortItem=this.getdan(q[a])
        var group = new ButtonGroup()
        group.setMinCheckCount(0)
        group.setMaxCheckCount(1)
		table.table(Tex.button, Cons(rootTable => {
	    rootTable.add(q[a].toString()).update(t => {t.setText(q[a].toString())})}))
	    table.row()
        table.table(Tex.button,rootTable => {
        for (var i=0,j=-1;i<others.size;i++){
            (function(i,self){
        if (danmap.has(q[i].name)){
        j++
        var button = rootTable.button(Tex.pane,32.5,() => {a=i;self.sortItem=self.getdan(q[a])}).tooltip(q[i].localizedName).group(group).get()
        button.getStyle().up = Styles.black3
        button.getStyle().down = Styles.flatOver;
        button.getStyle().checked = Styles.accentDrawable
        button.getStyle().over = Styles.flatOver
        button.getStyle().imageUp = new TextureRegionDrawable(q[i].uiIcon)     
        button.update(() => {button.setChecked(i==a)})
            }})(i,this)
        if(j%4==3){rootTable.row()}}})},
        getdan(liquid){
            return getbyname(danmap.get(liquid.name))
        }    
	}, 单元装卸器)
});

