function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
const list=[-1,0,0,-1,1,0,0,1]
//~~~~~~~~~~~~~~~
const 流体阀 = extend(GenericCrafter, '流体阀', {});
流体阀.configurable = true;
流体阀.buildType = prov(() => {
    var other,otheram
    var target,targetam
    var current
    var nowliquid
    var enda=0,endb=6,endc=0,l1,l2,l3
    var set,flux
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
    	buildConfiguration(table){
    	    table.add("流量限制:"+set*60).update(t => {t.setText("流量限制:"+set*60)})
    	    table.row()
    	    table.slider(0,10,1,enda,l1 => {enda=l1}).width(300);table.row()
            table.slider(0,9,1,endb,l2 => {endb=l2}).width(300);table.row()
            table.slider(0,2,1,endc,l3 => {endc=l3}).width(300)
    	},
        updateTile(){
            set=(enda+endb*10+endc*100)/60
            other = Vars.world.build(this.tileX()+list[this.rotation*2], this.tileY()+list[1+this.rotation*2])
            target = Vars.world.build(this.tileX()-list[this.rotation*2], this.tileY()-list[1+this.rotation*2])
        if (other!=null){
        if (other.block.hasLiquids){
        nowliquid=other.liquids.current()
        current=this.liquids.get(nowliquid)
        otheram=other.liquids.get(nowliquid)
        flux=Math.min(otheram,set)
        this.handleLiquid(this,nowliquid,Math.min(flux,20-current))
        other.liquids.remove(nowliquid,Math.min(flux,20-current))
        other.updateTile()
        }}
        if (target!=null){
        if (target.block.hasLiquids){
        current=this.liquids.get(nowliquid)
        targetam=target.liquids.get(nowliquid)
        target.handleLiquid(target,nowliquid,Math.min(flux,target.block.liquidCapacity-targetam))
        this.liquids.remove(nowliquid,Math.min(flux,target.block.liquidCapacity-targetam))
        target.updateTile()
        }}
        },
    	write(write){
    		this.super$write(write);
    		write.f(enda)
    		write.f(endb)
    		write.f(endc)
    	},
    	read(read, revision){
    		this.super$read(read, revision);
    		enda=read.f()
    		endb=read.f()
    		endc=read.f()
    		
    	},
    },流体阀);
});

