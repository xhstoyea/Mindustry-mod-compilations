const lib = require("base/AdvancedBuildLib")
var map={}
map.map=function(block){
    block.ignoreResultOnFull=false
    block.data=3
}
map.update=function(self){
    var tog=self.gettog()
    var rad=self.getr(tog).rad
    var enable=false
    const aaaa=[-1,0,-1,1,0,2,1,2,2,1,2,0,1,-1,0,-1]
    for (var i=0;i<8;i++){
    var other = Vars.world.build(self.tileX()+aaaa[2*i], self.tileY()+aaaa[(2*i)+1])
    if (other!=null){
    if (other.goto!=null){
        var getrad=other.goto()
        if (getrad!=null){
            var radacc=getrad(other)
        }
    }}
    if (radacc>=rad&&self.getchecks()){
        enable=true
    }
    }
    self.setchecks(enable)
}
var recipe=[]
recipe.push(
{
input:{
    liquid:[
        "water/15"
    ],
    power:1.85
},
output:{
    liquid:[
        "社会主义工业化-重水/7.5"
    ],
},
crafttime:60,
detail:"轻水在中子辐照下嬗变为重水",
color:Color.valueOf("ffffff"),
map(t){t.add("[accent]需要辐照通量: 一级中子").expandX().left().row()},
rad:1
})
recipe.push(
{
input:{
    liquid:[
        "社会主义工业化-微生物悬浊液/15"
    ],
    power:2
},
output:{
    liquid:[
        "neoplasm/7.5"
    ],
},
crafttime:60,
detail:"微生物在中子辐照下发生变异",
color:Color.valueOf("ffffff"),
map(t){t.add("[accent]需要辐照通量: 一级中子").expandX().left().row()},
rad:1
})
recipe.push(
{
input:{
    liquid:[
        "社会主义工业化-燃油/15"
    ],
    power:3
},
output:{
    liquid:[
        "社会主义工业化-烷烃/7.5",
        "社会主义工业化-乙烯/7.5"
    ],
},
crafttime:60,
detail:"燃油在中子辐照下辐解为短链烃",
color:Color.valueOf("ffffff"),
map(t){t.add("[accent]需要辐照通量: 二级中子").expandX().left().row()},
rad:2
})
const 辐照室=lib.advanced("辐照室",recipe,map)