const lib = require("base/AdvancedBuildLib")
var map={}
map.map=function(block){
    block.ignoreResultOnFull=true
    block.data=4
}
map.goto=function(self){
    var tog=self.gettog()
    var radout=self.getr(tog).radout
    if (self.warmup>0.5){
        return radout
    }
    return 0
}
var recipe=[]
recipe.push(
{
input:{
    item:[
        "thorium/1",
    ],
    liquid:[
        "cryofluid/30"
    ],
},
output:{
    productliquid:[
        "社会主义工业化-反应堆废料2/30"
    ],
    result:[
        "lead/0.33",
    ],
    power:80
},
crafttime:120,
color:Color.valueOf("ff1ecc"),
icon(){return Vars.content.getByName(ContentType.item,"thorium").uiIcon},
map(t){t.add("[accent]提供辐照通量: 一级中子").expandX().left().row()},
radout:1
})
recipe.push(
{
input:{
    item:[
        "社会主义工业化-铀/1",
    ],
    liquid:[
        "cryofluid/30"
    ],
},
output:{
    result:[
        "lead/0.5",
    ],
    productliquid:[
        "社会主义工业化-反应堆废料/30"
    ],
    power:120
},
crafttime:120,
color:Color.valueOf("4af604"),
icon(){return Vars.content.getByName(ContentType.item,"社会主义工业化-铀").uiIcon},
map(t){t.add("[accent]提供辐照通量: 二级中子").expandX().left().row()},
radout:2
})
recipe.push(
{
input:{
    item:[
        "社会主义工业化-钚/1",
    ],
    liquid:[
        "cryofluid/30"
    ],
},
output:{
    productliquid:[
        "社会主义工业化-反应堆废料3/30"
    ],
    power:160
},
crafttime:120,
color:Color.valueOf("f9bf04"),
icon(){return Vars.content.getByName(ContentType.item,"社会主义工业化-钚").uiIcon},
map(t){t.add("[accent]提供辐照通量: 二级中子").expandX().left().row()},
radout:2
})
recipe.push(
{
input:{
    item:[
        "社会主义工业化-硅岩/1",
    ],
    liquid:[
        "cryofluid/60"
    ],
},
output:{
    productliquid:[
        "社会主义工业化-反应堆废料3/30"
    ],
    power:210
},
crafttime:180,
color:Color.valueOf("ffffff"),
icon(){return Vars.content.getByName(ContentType.item,"社会主义工业化-硅岩").uiIcon},
map(t){t.add("[accent]提供辐照通量: π介子").expandX().left().row()},
radout:3
})
const RBMK=lib.advanced("RBMK",recipe,map)