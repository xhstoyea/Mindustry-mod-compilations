const lib = require("base/AdvancedBuildLib")
var map={}
map.map=function(block){
    block.ignoreResultOnFull=false
    block.data=4
}
map.update=function(self){
    var tog=self.gettog()
    var rad=self.getr(tog).rad
    var enable=false
    const aaaa=[-1,2,0,2,1,2,2,1,2,0,2,-1,-1,-2,0,-2,1,-2,-2,1,-2,0,-2,-1]
    for (var i=0;i<12;i++){
    var other = Vars.world.build(self.tileX()+aaaa[2*i], self.tileY()+aaaa[(2*i)+1])
    if (other!=null){
    if (other.goto!=null){
        var getrad=other.goto()
        if (getrad!=null){
            var radacc=getrad(other)
        }
    }}
    if (radacc>=rad&&self.getchecks()){
        enable=true
    }
    }
    self.setchecks(enable)
}
var recipe=[]
recipe.push(
{
input:{
    liquid:[
        "water/15"
    ],
    power:2
},
output:{
    liquid:[
        "社会主义工业化-重水/15"
    ],
},
crafttime:60,
detail:"轻水俘获中子嬗变为重水",
color:Color.valueOf("ffffff"),
map(t){t.add("[accent]需要辐照通量: 一级中子").expandX().left().row()},
rad:1
})
recipe.push(
{
input:{
    liquid:[
        "社会主义工业化-重水/15"
    ],
    power:3
},
output:{
    result:[
        "社会主义工业化-铍/0.25"
    ],
},
crafttime:60,
detail:"氘俘获中子嬗变为铍",
color:Color.valueOf("ffffff"),
map(t){t.add("[accent]需要辐照通量: 二级中子").expandX().left().row()},
rad:2
})
recipe.push(
{
input:{
    item:[
        "thorium/1"
    ],
    power:3
},
output:{
    result:[
        "社会主义工业化-铀/0.9"
    ],
},
crafttime:60,
detail:"钍俘获中子嬗变为铀",
color:Color.valueOf("ffffff"),
map(t){t.add("[accent]需要辐照通量: 二级中子").expandX().left().row()},
rad:2
})
recipe.push(
{
input:{
    item:[
        "社会主义工业化-铀/1"
    ],
    power:2
},
output:{
    result:[
        "社会主义工业化-钚/0.87"
    ],
},
crafttime:60,
detail:"铀俘获中子嬗变为钚",
color:Color.valueOf("ffffff"),
map(t){t.add("[accent]需要辐照通量: 二级中子").expandX().left().row()},
rad:2
})
recipe.push(
{
input:{
    item:[
        "社会主义工业化-钚/2",
    ],
    liquid:[
        "社会主义工业化-重水/30"
    ],
    power:11
},
output:{
    result:[
        "社会主义工业化-硅岩/0.2",
    ],
},
crafttime:60,
detail:"钚接受π介子轰击后嬗变为硅岩",
color:Color.valueOf("ffffff"),
map(t){t.add("[accent]需要辐照通量: π介子").expandX().left().row()},
rad:3
})
const 嬗变室=lib.advanced("嬗变室",recipe,map)