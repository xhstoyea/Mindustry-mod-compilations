const aaaa=[[-2,1,-1,1,-2,0,-1,0],[0,-1,1,-1,0,-2,1,-2],[2,1,3,1,2,0,3,0],[0,3,1,3,0,2,1,2]]//位置
const list=[[2,1,2,1],[1,1,2,2],[1,2,1,2],[2,2,1,1]]//检测
const targetlist1=[2,0,1,2,-1,1,0,-1]
const targetlist2=[2,1,0,2,-1,0,1,-1]
function bbbb(a){
    var b
    a=a.name
if (a=="社会主义工业化-铅制防辐射重装板"){b=1}
if (a=="社会主义工业化-控制主机超级电脑"){b=2}
    return b
}
const myitems = require("数据/vars/物品")
//~~~~~~~~~~~~~~
const FEL激光器 = extend(GenericCrafter, 'FEL激光器', {
    	setBars() {
		this.super$setBars();
		this.addBar("laser", func(e => new Bar(
			prov(() => "能级"),
			prov(() =>  Color.valueOf("ffd06d")),
			floatp(() => e.getlevel()/4)
		)));
	},
    	    setStats() {
        this.super$setStats()
    this.stats.remove(Stat.productionTime)
        this.stats.remove(Stat.input)
        this.stats.add(new Stat("激发体", new StatCat("激发体")), aaa())
    }
});
FEL激光器.configurable = true;
FEL激光器.buildType = prov(() => {
    var other
    var ii=0
    var d
    var bb
    var cc
    var e
    var rr
    var target1
    var target2
    var target
    var l
    var level=0
    var allow
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
    	buildConfiguration(table){
            table.button("操作", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("FEL激光器");
            dialog.cont.pane(table => {
                table.add("FEL激光器")
                table.row()
			    table.button("结构", Icon.book, run(() => {
            var dialog = new BaseDialog("结构");
            dialog.cont.pane(table => {
table.add("[yellow]暂无教程");table.row();table.add("请到作者的b站视频寻求帮助");table.row();table.add("b站:硫柳汞")
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128);
            dialog.show()})).size(140, 70);
			    table.row()
			    table.add(" ")
			    table.row()
                if (cc==0){table.add("[yellow]结构不完整!!!")}
                else{table.add("[blue]结构就绪")}
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128);
            dialog.show();
            })).size(100, 50);
    	},
    	getlevel(){
    	    if (allow){return level}
    	    else {return 0}
    	},
    	getallow(){
    	    return allow
    	},
    	gettarget(){return target},
        updateTile(){
		  //  this.super$updateTile()
		    rr=this.rotation
            other = Vars.world.build(this.tileX()+aaaa[rr][2*ii], this.tileY()+aaaa[rr][(2*ii)+1])
    if (other!=null){bb=bbbb(other.block)}
    else{bb=null}
            if (bb!=list[rr][ii]){d=0}
            if (ii<3){ii=ii+1}
            else{ii=0;
            if (d==1){cc=1}
            else{cc=0;d=1}}
            target1 = Vars.world.build(this.tileX()+targetlist1[rr*2], this.tileY()+targetlist1[1+(rr*2)])
            target2 = Vars.world.build(this.tileX()+targetlist2[rr*2], this.tileY()+targetlist2[1+(rr*2)])
    if (target1==target2){target=target1}
    else {target=null}
            l=0
if (this.items.get(myitems.钻石)==20){l=1}
if (this.items.get(myitems.钚)==20){l=2}
if (this.items.get(myitems.CMB钢)==20){l=3}
if (this.items.get(myitems.稀土)==20){l=4}            
            level=l
            if (target!=null && this.power.status>=0.5 && this.enabled){allow=true}
            else{allow=false}
        }
    },FEL激光器);
});
function aaa() {
    return function (table) {
        table.row()
        table.add(Image(myitems.钻石.uiIcon).setScaling(Scaling.fit)).size(30);
        table.add("金刚石       [grey]能级:1")
        table.row()
        table.add(Image(myitems.钚.uiIcon).setScaling(Scaling.fit)).size(30);
        table.add("反应堆级钚   [grey]能级:2")
        table.row()
        table.add(Image(myitems.CMB钢.uiIcon).setScaling(Scaling.fit)).size(30);
        table.add("CMB钢        [grey]能级:3")
        table.row()
        table.add(Image(myitems.稀土.uiIcon).setScaling(Scaling.fit)).size(30);
        table.add("稀土         [grey]能级:4")
    };
}