
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
//~~~~~~~~~~~~~~~
var r=6
var maxrange=12
const 超速频道 = extend(Router, '超速频道', {
    drawPlace(x, y, rotation, valid) {
        Drawf.dashSquare(Color.white, x * 8, y * 8, r * 16)
    }, 
});
超速频道.configurable = true;
超速频道.buildType = prov(() => {
    var xx=r,yy=r,endxx=r,endyy=r
    var range=1
    return new JavaAdapter(Router.RouterBuild, {
    	buildConfiguration(table){
			this.super$buildConfiguration(table)
    	    table.slider(0,r*2,1, endxx,xx => {
			    endxx=xx
			}).width(300)
			table.row()
			table.slider(0,r*2,1, endyy,yy=> {
			    endyy=yy
			}).width(300);
            table.row()
    	    table.slider(1,maxrange,1, range,g => {
			    range=g
			}).width(300)
    	},
        updateTile(){
            Vars.indexer.allBuildings(this.x+(endxx-r)*8, this.y+(endyy-r)*8,range*8, cons(other => {
                if (other!=this){
                    other.applyBoost(2,5)
                }
            }));
        },
        drawSelect(){
            Drawf.dashSquare(
		        Color.white,
		        this.x,this.y,r*16
		    )
		    Drawf.dashCircle(this.x+(endxx-r)*8,this.y+(endyy-r)*8,range*8,Pal.accent)
        },
    },超速频道);
});
