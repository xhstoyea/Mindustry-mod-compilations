
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                
//----------
const 力场发生器 = extend(ForceProjector, '力场发生器', {});
力场发生器.configurable = true;
力场发生器.buildType = prov(() => {
    var target
    var thisbullet
    var endr=0,lpr=0,end=0,endx=0,endy=0,lp=0,lpx=0,lpy=0
    return new JavaAdapter(ForceProjector.ForceBuild, {
    	buildConfiguration(table){
    table.add("a")
    table.row()
    table.slider(0, 3, 1, endr, lpr => {
		endr=lpr}).width(300)
		table.row()
    table.slider(0, 10, 1, end, lp => {
		end=lp}).width(300)
		table.row()
	table.slider(-40,40, 1, endx, lpx => {
	    endx=lpx}).width(300)
	    table.row()
	table.slider(0, 80, 1, endy, lpy => {
	    endy=lpy}).width(300)
    	},
        updateTile(){
		 this.super$updateTile();
    if (this.start==null){this.broke=false
    this.rlength=80;this.xx=0;this.yy=0;this.xs=0;this.ys=0;this.mul=0;this.powerneed=0;this.contain=0;this.start=0}//初始化
    if (this.contain<0.1){this.contain=0}
    if (this.contain>0){
        if (this.broke){this.contain=this.contain-0.15}
        if (!this.broke){this.contain=this.contain-0.15}}
    this.powerneed=((Math.abs(endx)+Math.abs(endy))*5)+end*90+300
    this.applyBoost(r(this.powerneed/300,4),5)
    this.mul=r(this.power.status,4)
    this.rlength=((end*16)+80)*this.mul
    this.xx=endx*2-(this.rlength/2)
    this.yy=endy*2
    this.xs=endx*2
    this.ys=endy*2
    this.ii=endr
    this.list=[this.xx,this.yy+15,-this.yy-45,this.xx,-this.xx-this.rlength,-this.yy-45,this.yy+15,-this.xx-this.rlength]
    this.slist=[this.xs,this.ys+30,-this.ys-30,this.xs,-this.xs,-this.ys-30,this.ys+30,-this.xs]
    this.rlist=[this.rlength,30,30,this.rlength,this.rlength,30,30,this.rlength]
    Vars.ui.showLabel(this.contain.toString()+this.broke, 0.015, this.x, this.y);
    if (this.mul!=0){
    thisbullet=Groups.bullet.intersect(this.list[this.ii*2]+this.x, this.list[1+this.ii*2]+this.y,this.rlist[this.ii*2],this.rlist[1+this.ii*2])
    if (thisbullet.toString().length>4){
        target=thisbullet.first()
        if (!this.broke){
        target.remove()
        this.contain=this.contain+target.damage/25}
    }}
    if (this.contain>100*this.mul){this.broke=true}
    if (this.broke){if (this.contain==0){this.broke=false}}
            },
        drawShield(){
            if(!this.broke){
            Draw.color(this.team.color, Color.white,1);
            if(true){
            Draw.z(Layer.shields + 0.001);
            Fill.rect(this.slist[this.ii*2]+this.x,this.slist[1+this.ii*2]+this.y,this.rlist[this.ii*2],this.rlist[1+this.ii*2])}
            }
            Draw.reset();
        },
    	write(write){
    		this.super$write(write);
    		write.f(end);
    		write.f(endx);
    		write.f(endy);
    	},
    	read(read, revision){
    		this.super$read(read, revision);
    		end = read.f();
    		endx=read.f();
    		endy=read.f();
    	},
    },力场发生器);
});

