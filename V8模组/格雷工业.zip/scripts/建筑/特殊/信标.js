
function r(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       //取m位小数
//~~~~~~~~~~~~~~~
const 信标 = extend(Router, '信标', {});
信标.configurable = true;
信标.buildType = prov(() => {
    return new JavaAdapter(Router.RouterBuild, {
    	buildConfiguration(table){
    	},
        updateTile(){
            Vars.indexer.eachBlock(this,range*8,boolf(other => other!=this), cons(other => {
                other.applyBoost(3,5)
			}))
        },
        drawSelect(){
            Drawf.dashSquare(
		        Pal.accent,
		        this.x,this.y,range*16
		    )
        },
    },信标);
});
