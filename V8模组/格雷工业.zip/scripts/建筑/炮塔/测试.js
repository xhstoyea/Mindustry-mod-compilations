const lib = require("数据/bullet")
let bu = Object.assign(lib.RandomLightningBulletType(10,10,10,10,10), {
	lifetime: 60,
	speed: 2,
	ammoMultiplier: 1,
})

const 萤火 = extend(PowerTurret, "萤火", {});
Object.assign(萤火, {
	health: 256000,
	armor: 24,
	size: 4,
	range: 3840,
	reload: 60,
	shake: 8,
	shootY: 12,
	shootCone: 1,
	rotateSpeed: 0.5,
	recoil: 8,
	recoilTime: 90,
	cooldownTime: 120,
	canOverdrive: false,
	shootType: bu
});
萤火.consumePower(40);
萤火.setupRequirements(
	Category.turret,
	BuildVisibility.shown,
	ItemStack.with(
		Items.copper, 48000,
		Items.lead, 48000,
		Items.graphite, 36000,
	)
)