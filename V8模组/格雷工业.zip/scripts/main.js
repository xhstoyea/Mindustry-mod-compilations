MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000
require("数据/load")
require("特殊/load")
require("建筑/load")
require("特殊/菜单")

