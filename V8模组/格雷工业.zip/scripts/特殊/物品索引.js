const lib = require("base/lib");
const recipes = require("数据/handle/recipe").recipe
const requs=require("数据/handle/recipe").requ
function getbyname(name,config,content){
        if (config==0){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
        }
        if (config==1){
            if (content=="block"){
            var k=Vars.content.getByName(ContentType.block,name)
            return k
            }
            if (content=="item"){
            var k=Vars.content.getByName(ContentType.item,name)
            return k
            }
            if (content=="liquid"){
            var k=Vars.content.getByName(ContentType.liquid,name)
            return k
            }
        }
        if (config==2){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null && content!="block"){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null && content!="item"){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k            
        }
}
function typebyname(name){
        var k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return "item"
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        if (k!=null){
        return "liquid"
        }
}

//~~~~~~~~~~~~~~

function lookforrecipe(tar){
    var aim=tar.name
    var findinput=[]
    var findoutput=[]
    var re
    var input
    var output
    for (var i=0;i<recipes.length;i++){
        re=recipes[i]
        input=re.input
        output=re.output
        if (input.includes(aim)){
            findinput.push(re)
        }
        if (output.includes(aim)){
            findoutput.push(re)
        }
    }
    return [findinput,findoutput]
}
function display(ob,table) {
    var input=ob.input
    var output=ob.output
    var area=ob.area
    var config=ob.config
    var dis
    var amo
    for (var i=0;i<(input.length)/2;i++){
        if (input[i*2]=="heat"){
            amo=input[(i*2)+1]
            table.add(Image(Icon.wavesSmall))
            table.add("[orange]"+amo+lib.b("text-热量"))
        }
        else{
        dis=getbyname(input[i*2],2,"block")
        amo=input[(i*2)+1]
        if (typebyname(dis.name)=="item"){
            table.add(new ItemDisplay(dis,amo,true)).padRight(5)}
        if (typebyname(dis.name)=="liquid"){
            table.add(new LiquidDisplay(dis,amo,true)).padRight(5)}
        }}
    table.add(" ")
    table.add(Image(Icon.right))
    table.add(" ")
    for (var i=0;i<(output.length)/2;i++){
        if (output[i*2]=="heat"||output[i*2]=="power"){
            amo=output[(i*2)+1]
            if (output[i*2]=="heat"){
            table.add(Image(Icon.wavesSmall))
            table.add("[orange]"+amo+lib.b("text-热量"))}
            else{
            amo*=60
            table.add(Image(Icon.power))
            table.add("[accent]"+amo)
            }
        }
        else{
        dis=getbyname(output[i*2],2,"block")
        amo=output[(i*2)+1]
        if (typebyname(dis.name)=="item"){
            table.add(new ItemDisplay(dis,amo,true)).padRight(5)}
        if (typebyname(dis.name)=="liquid"){
            table.add(new LiquidDisplay(dis,amo,true)).padRight(5)}
        }}
    for (var i=0;i<(config.length)/2;i++){
        if (config[i*2]=="炉温"){
            table.add(" ")
            table.add("[accent]"+lib.b("text-所需炉温")+config[(i*2)+1])}
        if (config[i*2]=="激光"){
            table.add(" ")
            table.add("[accent]"+lib.b("text-所需激光能级")+":"+config[(i*2)+1])
        }
        if (config[i*2]=="display"){
            table.add(" ")
            for (var l=0,con=config[(i*2)+1];l<con.length;l++){
                table.add(con[l])
            }
        }
        }
    table.add("  ")
    table.add(Image(getbyname(area,0,0).uiIcon).setScaling(Scaling.fit)).size(30)
    table.add(" "+getbyname(area,0).localizedName)
}
function execute(mat,table,type){
    if (type=="input"){
    for (var i=0;i<mat.length;i++){
    table.table(Core.scene.getStyle(Button.ButtonStyle).up, part => {
        part.add("[accent]"+lib.b("text-用途")).expandX().left().row()
        part.table(cons(row => {
            display(mat[i],row)
        })).left().row()        
    }).color(Color.valueOf("96c8fa")).left().growX().row()
    }}
    if (type=="output"){
    for (var i=0;i<mat.length;i++){
    table.table(Core.scene.getStyle(Button.ButtonStyle).up, part => {
        part.add("[accent]"+lib.b("text-生产")).expandX().left().row()
        part.table(cons(row => {
            display(mat[i],row)
        })).left().row()        
    }).color(Color.valueOf("ffffff")).left().growX().row()
    }}
}
function lookforrequ(tar){
    var aim=tar.name
    var findrequ=[]
    var findamo=[]
    var requ=requs[0][0]
    if (requ[0].item.name==aim){
    findrequ.push(requ[0].amount)
    findamo.push(requs[1][0])}
    return [findrequ,findamo]
}
//~~~~~~~~~~
function aaa(item) {
    return function (table) {
      /*  table.add("a"+requs[0].length)
        table.add("a"+lookforrequ(Items.copper)[0])
        table.add("a"+requs[0][0][0])*/
	    table.button("", Icon.book, run(() => {
    var dialog = new BaseDialog(lib.b("text-生产/用途"));
    dialog.cont.pane(table => {
        var getrecipe=lookforrecipe(item)
        table.add("[accent]"+lib.b("text-生产")).left()
        table.row()
        execute(getrecipe[1],table,"output")
        table.row()
        table.add(" ")
        table.row()
        table.add("[accent]"+lib.b("text-用途")).left()
        table.row()
        execute(getrecipe[0],table,"input")
    })
    dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128)
    dialog.show();
	    })).size(50, 40)
    }
}
//~~~
Events.on(EventType.ClientLoadEvent, () => {
   var allitems=Vars.content.items()
   var allitem
   for (var i=0;i<allitems.size;i++){
    allitem=allitems.get(i)
    allitem.stats.add(new Stat("索引", StatCat.function),aaa(allitem))}
})
Events.on(EventType.ClientLoadEvent, () => {
   var allliquids=Vars.content.liquids()
   var allliquid
   for (var i=0;i<allliquids.size;i++){
    allliquid=allliquids.get(i)
    allliquid.stats.add(new Stat("索引", StatCat.function),aaa(allliquid))}
})