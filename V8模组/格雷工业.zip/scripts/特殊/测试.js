const 沥青公路 = require("特殊/沥青公路")
const 测试 = extend(Block, "测试", {
});
测试.update = true;
测试.buildType = prov(() => {
    return extend(Building, {
        updateTile() {
           if (this.time==null){this.time=0}
           if (this.infor==null){this.infor=[0,0,0,0,0,0]}//旋转，预设长度，实际长度，模式，配置，配置
           this.selfblock = Vars.world.build(this.tileX(),this.tileY()) 
	       this.time=this.time+Time.delta
            if(this.selfblock.block.toString()=="社会主义工业化-测试"&&this.time>60){
            this.time=0
            Vars.world.tile(this.tileX(),this.tileY()+1).setFloor(沥青公路.沥青地板)
            Vars.world.tile(this.tileX(), this.tileY()+1).setBlock(this.selfblock.block,Team.sharded);
            
            this.kill()
            }
        },
    });
})