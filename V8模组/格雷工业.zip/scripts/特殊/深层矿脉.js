const mathlib = require("base/MathLib")
const Generator=require("base/generator").Generator
const ores=require("数据/ores").ores
var Oreset=new Map()
    for (var i=0;i<100;i++){
        var oresets=[]
        var seed=mathlib.seedRecursion(i)
        for (var o=0;o<ores.length;o++){
            var seeds=seed+Math.PI*o
            var list=Generator(ores[o],seeds,i)
            for (var j=0;j<list.length;j++){
                oresets.push(list[j])
            }
        }
        Oreset.set(i,oresets)
    }
exports.Oreset = Oreset
function transid(id){
    if (id>=0&&id<100){
        return id
    }
    if (id<0){
        return 0
    }
    if (id>=100){
        return (id-Math.floor(Math.PI*id))*100
    }
}
function getid(){
    var sector=Vars.state.rules.sector
    if (sector!=null){
        return transid(sector.id)
    }
    return 11
}
exports.getid=()=>{
    return getid()
}