
const mathlib = require("base/MathLib")
var action={}
action.explode=function(puddle){
    var xx=puddle.tile.x*8 
    var yy=puddle.tile.y*8
    Fires.create(puddle.tile)
    Damage.damage(null,xx,yy,30,300,true,true)
    Damage.damage(null,xx,yy,45,100,true,true)
    Damage.damage(null,xx,yy,60,50,true,true)
    Damage.damage(null,xx,yy,90,20,true,true)

    for (var i=0;i<20;i++){
        Fx.reactorsmoke.at(xx,yy)
        Effect.floorDust(xx,yy,10)
    }
    //Effect.shockwave(xx,yy,128,10, Color.orange);
    puddle.remove()
}
Events.run(Trigger.update, () => {
    Groups.puddle.each(puddle => {
            if (puddle.liquid.name === "社会主义工业化-肼"){
                if (mathlib.chance(0.01)){
                    action.explode(puddle)
                }
            }
    }
    )
})
const hiddenItems=[
    "社会主义工业化-铀"
    ]
/*Events.on(EventType.ClientLoadEvent, () => {
	Vars.ui.database = extend(DatabaseDialog, {
	});
	Vars.ui.database.shown=function(){}
})*/