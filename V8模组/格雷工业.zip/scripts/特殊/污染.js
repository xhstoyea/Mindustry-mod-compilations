const pollutions=new Map()
//{id,pollution}
Events.run(Trigger.update, () => {
	if(true){
    Groups.puddle.each(puddle => {
            if (puddle.liquid === Liquids.oil){
                Fires.create(puddle.tile)
            }
    }
    )
	Vars.ui.hudfrag.showToast('核心受到攻击!')
    }
	})