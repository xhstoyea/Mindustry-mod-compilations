//generator

const mathlib = require("base/MathLib")

//lib
function round(a,m){
    var y=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return y
}                       
//范围
function Rangegenerate(min,max,seed){
    var e=(max+min)/2
    var d=(max-min)/2
    var range=mathlib.seedTriangle(e,d,seed)      //服从三角分布
    return round(range,0)
}
//丰度
function Densitygenerate(e,seed){
    var d=1-e
    var density=mathlib.seedTriangle(e,d,seed)    //服从三角分布
    return round(density,2)
}
//深度
function Layergenerate(min,max,seed){
    let layer=mathlib.seedUniform(min,max,seed)    //服从均匀分布
    return round(layer,0)
}
//中心
function Pointgenerate(seed,rangex,rangey){
    let x=mathlib.seedUniform(0,1,seed)
    let y=mathlib.seedUniform(0,1,seed*7)    //服从双均匀分布
    x*=rangex
    y*=rangey
    return [x,y]
}
//四边形生成器

function Quadrilateralgenerate(seed,range,center){
    let quad=[]
    let x
    let y
    x=0+mathlib.seedUniform(0,1,seed+1)
    y=0+mathlib.seedUniform(0,1,seed-1)
    quad.push([x,y])
    x=0+mathlib.seedUniform(0,1,seed+2)
    y=0-mathlib.seedUniform(0,1,seed-2)
    quad.push([x,y])
    x=0-mathlib.seedUniform(0,1,seed+3)
    y=0-mathlib.seedUniform(0,1,seed-3)
    quad.push([x,y])
    x=0-mathlib.seedUniform(0,1,seed+4)
    y=0+mathlib.seedUniform(0,1,seed-4)
    quad.push([x,y])
    let centerx=(quad[0][0]+quad[1][0]+quad[2][0]+quad[3][0])/4
    let centery=(quad[0][1]+quad[1][1]+quad[2][1]+quad[3][1])/4
    for (var i=0;i<4;i++){
        quad[i][0]-=centerx
        quad[i][1]-=centery
    }
    //quad=mathlib.sortpointclock(quad)
    let squ=mathlib.quadSquare(quad)
    let squmul=Math.sqrt(range/squ)
    for (var i=0;i<4;i++){
        quad[i][0]*=squmul
        quad[i][1]*=squmul
    }
    centerx=(quad[0][0]+quad[1][0]+quad[2][0]+quad[3][0])/4
    centery=(quad[0][1]+quad[1][1]+quad[2][1]+quad[3][1])/4
    let addx=center[0]-centerx
    let addy=center[1]-centery
    for (var i=0;i<4;i++){
        quad[i][0]+=addx
        quad[i][1]+=addy
        quad[i][0]=round(quad[i][0],0)
        quad[i][1]=round(quad[i][1],0)
    }
    return quad
}
exports.generate=(seed,range,center)=>{
    return Quadrilateralgenerate(seed,range,center)
}
//获取器
function Singlegenerate(ore,seed,map){
    let center=Pointgenerate(seed,map.rangex,map.rangey)
    let range=Rangegenerate(ore.range[0],ore.range[1],seed)
    let density=Densitygenerate(ore.density,seed)
    let quad=Quadrilateralgenerate(seed,range,center)
    let layer=Layergenerate(ore.layer[0],ore.layer[1],seed)
    return {
        pos:quad,
        type:ore.type,
        layer:layer,
        density:density,
        drop:ore.drop,
        hardness:ore.hardness,
        name:ore.name
    }
}
//构造器
function Generator(ore,seed,sec){
    var oreset=[]
    var e=ore.f.e
    var d=ore.f.d
    var config=ore.f.config
    if (config!=null){
        for (var i=0;i<config.length;i++){
            if (config[i].sec==sec){
                e=config[i].e
                d=config[i].d
            }
        }
    }
    var amount=mathlib.seedTriangle(e,d,seed)
    amount=round(amount*800*800/160000,0)
    var range=ore.square.range
    var layer=ore.square.layer
    var density=ore.square.density
    for (var i=0;i<amount;i++){
        oreset.push(Singlegenerate({
            type:ore.type,
            name:ore.name,
            drop:ore.drop,
            hardness:ore.hardness,
            range:range,
            layer:layer,
            density:density
        },mathlib.seedIteration(seed,i),{
            rangex:800,
            rangey:800
        }))
    }
    return oreset
}
exports.Generator=(ore,seed,sec)=>{
    return Generator(ore,seed,sec)
}