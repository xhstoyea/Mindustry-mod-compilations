//MathLib

//数学处理---------------------

//判定器
//----s----
function chance(p){
    return Math.floor(Math.random()*1000)<=p*1000
}
exports.chance=(p)=>{
    return chance(p)
}

//----e----

//种子递推器
//----s----
function seedRecursion(seed){
    let x = Math.PI*seed*100
    x-=Math.floor(x)
    x*=1000000
    let numStr = x.toString()
    let decimalIndex = numStr.indexOf('.');
    let sixDigits = numStr.substring(decimalIndex + 1, decimalIndex + 7)
    return Number(sixDigits)
}
exports.seedRecursion=(seed)=>{
    return seedRecursion(seed)
}

//----e----

//种子迭代器
//----s----
function seedIteration(seed,index){
    for (var i=0;i<index;i++){
        seed=seedRecursion(seed)
    }
    return seed
}
exports.seedIteration=(seed,index)=>{
    return seedIteration(seed,index)
}

//----e----

//均匀分布器
//----s----
function Uniform(a,b){
    var p=Math.random()
    p*=b-a
    return a+p
}
exports.Uniform=(a,b)=>{
    return Uniform(a,b)
}

//----e----

//三角分布器
//----s----
function Triangle(e,d){
    var a=e-d
    var b=e+d
    var m=Math.random()
    var n=Math.random()
    return a+(b-a)*(m+n)/2
}
exports.Triangle=(e,d)=>{
    return Triangle(e,d)
}

//----e----

//正态分布器
//----s----
function Normal(e,d){
    
}
exports.Normal=(e,d)=>{
    return Normal(e,d)
}

//----e----

//种子均匀分布器
//----s----
function seedUniform(a,b,seed){
    let x = Math.PI*seed
    x-=Math.floor(x)
    return a+(b-a)*x
}
exports.seedUniform=(a,b,seed)=>{
    return seedUniform(a,b,seed)
}

//----e----

//种子三角分布器
//----s----
function seedTriangle(e,d,seed){
    var a=e-d
    var b=e+d
    var m=seedUniform(0,1,seed)
    var n=seedUniform(0,1,seedRecursion(seed))
    return a+(b-a)*(m+n)/2
}
exports.seedTriangle=(e,d,seed)=>{
    return seedTriangle(e,d,seed)
}

//----e----

//几何判断---------------------

//多边形面积
//----s----
function calculateQuadrilateralArea(points) {
    let sum = 0;
    let current
    let next
    let n = points.length;
    for (let i = 0; i < n; i++) {
        current = points[i]
        next = points[(i+1)%n]
        sum += current[1]*next[0]-current[0]*next[1]
    }
    return Math.abs(sum)/2
}
exports.quadSquare=(quad)=>{
    return calculateQuadrilateralArea(quad)
}
//----e----

//判断点是否在四边形内
//----s----
function isPointInQuadrilateral(point, vertices) {
    // vertices 是一个包含四个坐标点的数组，格式为 [[x1, y1], [x2, y2], [x3, y3], [x4, y4]]
    let x = point[0]
    let y = point[1]
    let inside = false;
    for (let i = 0, j = vertices.length - 1; i < vertices.length; j = i++) {
        let xi = vertices[i][0], yi = vertices[i][1];
        let xj = vertices[j][0], yj = vertices[j][1];
        let intersect = ((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
        if (intersect) inside = !inside;
    }
    return inside;
}
exports.pointInQuad=(point,ver)=>{
    return isPointInQuadrilateral(point,ver)
}
//----e----

//顺时针排列点
//----s----
function sortPointsClockwise(points) {
    let getSortKey = (point) => {
        let x = point[0], y = point[1];
        let quadrant;
        if (x >= 0 && y >= 0) quadrant = y === 0 ? 0 : 0;
        else if (x >= 0 && y <= 0) quadrant = 1;
        else if (x <= 0 && y <= 0) quadrant = 2;
        else quadrant = 3;
        let angle = Math.atan2(y, x);
        let clockwiseAngle = (2 * Math.PI - angle) % (2 * Math.PI);
        return { quadrant:quadrant, angle: clockwiseAngle };
    };
    return points.slice().sort((a, b) => {
        let keyA = getSortKey(a);
        let keyB = getSortKey(b);
        if (keyA.quadrant !== keyB.quadrant) {
            return keyA.quadrant - keyB.quadrant;
        }
        return keyA.angle - keyB.angle;
    });
}
exports.sortpointclock=(vertices)=>{
    return sortPointsClockwise(vertices)
}
//----e----