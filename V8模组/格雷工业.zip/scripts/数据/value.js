const myLiquids = require("数据/vars/液体")

//~~~~腐蚀~~~~
const defense=new Map()
const harm=new Map()
defense.set("conduit",1)
defense.set("pulse-conduit",2)
defense.set("liquid-router",2)
defense.set("liquid-container",1.8)
defense.set("liquid-tank",1.8)
defense.set("bridge-conduit",2)
defense.set("plated-conduit",3)
defense.set("phase-conduit",3)
defense.set("社会主义工业化-钍路由器",3)
defense.set("社会主义工业化-高压导管",3.5)
defense.set("社会主义工业化-塑料储罐",3.5)
defense.set("社会主义工业化-高压导管桥",3.5)
harm.set("社会主义工业化-毒泥浆",3.5)
harm.set("社会主义工业化-六氟化钚",3)
harm.set("社会主义工业化-反应堆废料",3)
harm.set("社会主义工业化-硝酸",1.9)
harm.set("社会主义工业化-硫酸",1.9)
harm.set(Liquids.cyanogen.name,1.9)
harm.set(Liquids.neoplasm.name,3.25)
harm.set("社会主义工业化-肼",1.85)
harm.set("社会主义工业化-芳香烃",1.2)
harm.set("社会主义工业化-杂酚",1.2)
harm.set(Liquids.ozone.name,1.85)
harm.set("社会主义工业化-盐水",1.1)
harm.set("社会主义工业化-氟气",3)
exports.corr={harm:harm,defense:defense}

//~~~~流体单元~~~~
function newItem(name) {
	let myItem = extend(Item, name, {})
	return myItem
}
var lis=Vars.content.liquids()
var q=[]
var m=[]
for (var i=0;i<lis.size;i++){
    q[i]=lis.get(i)}
for (var i=0;i<q.length;i++){
    m[i]=newItem(q[i].name+"单元")
}
for (var i=0;i<m.length;i++){
    m[i].hidden=true
}
exports.dan=m
var danmap=new Map()
for (var i=0;i<q.length;i++){
    danmap.set(q[i].name,m[i].name)
    danmap.set(m[i].name,q[i].name)
}
exports.danmap=danmap
