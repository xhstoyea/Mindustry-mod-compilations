require("数据/vars/物品")
require("数据/vars/液体")
require("数据/handle/recipe")
require("数据/value")
//require("数据/handle/var")

