const block=require("数据/vars/block").block
function turnstr(str,type){
    if (type=="item"){
    return {item:Vars.content.getByName(ContentType.item,str.split("/")[0]),amount:str.split("/")[1]}}
    if (type=="liquid"){
    return {liquid:Vars.content.getByName(ContentType.liquid,str.split("/")[0]),amount:str.split("/")[1]}}
}
for (var i=0;i<block.length;i++){
    var b=block[i]
    if (b.type==null || b.name==null){
        continue
    }
    var blo=extend(b.type,b.name,
{})
    blo.description=b.description
    blo.category=Category.crafting
    if (b.category!=null){
        blo.category=b.category
    }
    blo.buildVisibility = BuildVisibility.shown
    blo.craftTime =30
    if (b.craftTime!=null){
        blo.craftTime=b.craftTime
    }
    blo.size=1
    if (b.size!=null){
        blo.size=b.size
    }
    blo.health = blo.size*blo.size*40
    if (b.health!=null){
        blo.health=b.health
    }
    blo.hasItems=false
    if (b.hasItems!=null){
        blo.hasItems=b.hasItems
    }
    blo.hasLiquids=false
    if (b.hasLiquids!=null){
        blo.hasLiquids=b.hasLiquids
    }
    blo.hasPower=false
    if (b.hasPower!=null){
        blo.hasPower=b.hasPower
    }
    blo.itemCapacity=10
    if (b.itemCapacity!=null){
        blo.itemCapacity=b.itemCapacity
    }
    blo.liquidCapacity=30
    if (b.liquidCapacity!=null){
        blo.liquidCapacity=b.liquidCapacity
    }
    if (b.consume!=null){
        var consumes=b.consume
        if (consumes.power!=null){
            blo.consumePower(consumes.power)
            blo.hasPower=true
        }
        if (consumes.item!=null){
            var items=consumes.item
            for (var l=0;l<items.length;l++){
                if (turnstr(items[l],"item").item!=null){
                blo.consumeItem(turnstr(items[l],"item").item,(Number(turnstr(items[l],"item").amount)))
            }
            }
            blo.hasItems=true
        }        
        if (consumes.liquid!=null){
            var liquids=consumes.liquid
            for (var l=0;l<liquids.length;l++){
                if (turnstr(liquids[l],"liquid").liquid!=null){
                blo.consumeLiquid(turnstr(liquids[l],"liquid").liquid,(Number(turnstr(liquids[l],"liquid").amount)))
            }
            }
            blo.hasLiquids=true
        }
    }
    if (b.outputItem!=null){
        var output=b.outputItem
        var outputItem=[]
        for (var l=0;l<output.length;l++){
            if (turnstr(output[l],"item").item!=null){
                outputItem.push(turnstr(output[l],"item").item)
                outputItem.push(Number(turnstr(output[l],"item").amount))
            }
        }
        blo.outputItems=ItemStack.with(outputItem)
    }
    if (b.outputLiquid!=null){
        var output=b.outputLiquid
        var outputLiquid=[]
        for (var l=0;l<output.length;l++){
            if (turnstr(output[l],"liquid").liquid!=null){
                outputLiquid.push(turnstr(output[l],"liquid").liquid)
                outputLiquid.push(Number(turnstr(output[l],"liquid").amount))
            }
        }
        blo.outputLiquids=LiquidStack.with(outputLiquid)
    }
    if (b.requirements!=null){
        var req=b.requirements
        var requirement=[]
        for (var l=0;l<req.length;l++){
            if (turnstr(req[l],"item").item!=null){
                requirement.push(turnstr(req[l],"item").item)
                requirement.push(Number(turnstr(req[l],"item").amount))
            }
        }
        blo.requirements=ItemStack.with(requirement)
    }
    if (b.drawer!=null){
        blo.drawer= new DrawMulti(b.drawer)
    }
    if (b.updateEffect!=null){
        blo.updateEffect=b.updateEffect
    }
    if (b.craftEffect!=null){
        blo.craftEffect=b.craftEffect
    }
}