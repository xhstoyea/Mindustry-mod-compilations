/** 
    项目: 热能钻头 [20220802]
    作者: miner
*/

const DrillBuild = Drill.DrillBuild;

var heatRequirement = 5;
var overheatScale = 1;
var maxEfficiency = 2;

let heatDrill = Object.assign(extend(Drill, "heat-drill", {
    setBars(){
        this.super$setBars();
        
        this.addBar("heat", e => new Bar(
            () => Core.bundle.format("bar.heatpercent", parseInt(e.heat()), parseInt(e.efficiencyScale() * 100)),
            () => Pal.lightOrange,
            () => parseInt(e.heat()) / heatRequirement));
    },
}), {
    size: 2,
    drillTime: 450,
});

/** setupRequirements: 三个愿望 一次满足(误
* 参数1: 设置category
* 参数2: 设置buildVisibility
* 参数3: 设置requirements
*/
heatDrill.setupRequirements(
    Category.production,
    BuildVisibility.shown,
    ItemStack.with(Items.copper, 200, Items.lead, 150)
);

var block = heatDrill;

heatDrill.buildType = () => {
    let sideHeat = new Array(4);
    let heat = 0;

    /** JavaAdapter: 
    * 主类(DrillBuild), 
    * 接口(HeatConsumer), 
    * 实现({...}), 
    * 构造函数的参数(heatDrill)
    *
    * 注意: extend函数其实也是用JavaAdapter 其区别在于:
    * extend无法实现接口,只能继承主类(这也是anuke给extend的本意
    */
    let build = new JavaAdapter(DrillBuild, HeatConsumer, {
        /** 这里是HeatConsumer需要实现的方法
        * float[] sideHeat();
        * float heatRequirement();
        */
    
        sideHeat(){
            return sideHeat;
        },
        
        heatRequirement(){
            return heatRequirement;
        },
        
        updateTile(){
            heat = this.calculateHeat(sideHeat);

            this.super$updateTile();
        },
        
        warmupTarget(){
            return Mathf.clamp(heat / heatRequirement);
        },
        
        // 这个为什么动不了啊! 肯定是anuke的问题!
        // 新版本又能用了¿¿¿
        updateEfficiencyMultiplier(){
            this.super$updateEfficiencyMultiplier();
            
            let es = this.efficiencyScale();
        
            this.potentialEfficiency *= es;
        },

        efficiencyScale(){
            let over = Math.max(heat - heatRequirement, 0);
            return Math.min(Mathf.clamp(heat / heatRequirement) + over / heatRequirement * overheatScale, maxEfficiency);
        },
        
        // 获取热量
        heat(){
            return heat;
        },
        
    }, block);
    
    return build;
}