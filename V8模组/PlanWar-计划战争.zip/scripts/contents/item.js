const limefruit = new Item("limefruit", Color.valueOf("6e8b74"));
exports.limefruit = limefruit;
const limetreec = new Item("limetreec", Color.valueOf("C9C9C1FF"));
exports.limetreec = limetreec;
const lemon = new Item("lemon", Color.valueOf("FFF36FFF"));
exports.lemon = lemon;



function newItem(name) {
   exports[name] = new Item(name);
}
newItem("熟石灰");
newItem("生命晶体");
//newItem("qws");
//newItem("qwa");
//newItem("qwe");
//newItem("zit单元");
//newItem("建造许可");

function newLiquid(name, type) {
   exports[name] = extend(type ? CellLiquid : Liquid, name, {});
}

//newLiquid("赤焰", true);