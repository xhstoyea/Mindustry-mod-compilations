/*{
    "name": "消火栓",
    "description": "喷射液体流。可以作为灭火器或控制敌人走位并给予潮湿状态。[green]御用灭火器",
    "health": 240,
    "size": 2,
    "reload": 2,
    "range": 350,
    "recoil": 0,
    "targetGround": true,
    "targetAir": true,
    "inaccuracy": 3,
    "rotateSpeed": 8,
    "liquidCapacity": 20,
    "shootEffect":"none",
    "ammoTypes": {
        "water": {
            "type": "LiquidBulletType",
            "liquid": "water",
            "lifetime": 100,
            "knockback": 0.7,
            "statusDuration": 30,
            "status": "wet"
        }
    },
    "requirements": [
        {
            "item": "钴",
            "amount": 80
        },
        {
            "item": "氮化硅",
            "amount": 60
        },
        {
            "item": "金刚石",
            "amount": 40
        }
    ],
    "category": "turret",
    "research": "迸发"
}*/
const item = require("ap物品");
const 消火栓 = new LiquidTurret("消火栓");

//原作者Pardon，十分感谢Pardon的帮助（

const b = extend(BulletType,{
	speed: 0.01,
	damage: 0,
	collidesGround: false,
	collidesAir: false,
	collides: false,
	absorbable: false,
	hittable: false,
	lifetime: 60,
	hitEffect: Fx.none,
	despawnEffect: Fx.none,
	lightOpacity: 0,
})

exports.消火栓 = 消火栓
Object.assign(消火栓,{
	size: 2,
	recoil: 1,
	reload: 3,
	inaccuracy: 3,
	shootCone: 50,
	liquidCapacity: 20,
	shootEffect: Fx.shootLiquid,
	range: 240,
	unitSort: UnitSorts.strongest,
	health: 280,
	category: Category.turret,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		item.钴, 80,
		item.氮化硅, 60,
		item.金刚石, 30,
	),
})
消火栓.ammo(
	Liquids.water,Object.assign(new LiquidBulletType(Liquids.water),{
		knockback: 0.7,
		drag: 0.01,
		lifetime: 100,
		layer: Layer.bullet - 2,
	}),
	Liquids.cryofluid,extend(LiquidBulletType,Liquids.cryofluid,{
		damage: 1,
		drag: 0.01,
		lifetime: 100,
		layer: Layer.bullet - 2,
		update(b){
			this.super$update(b);
			
			let tile = Vars.world.tileWorld(b.x,b.y);
			if(tile != null){
				let other = Puddles.get(tile);
				if(other != null && other.liquid == Liquids.neoplasm){
					if(other.amount > 20){
						other.amount -= 20
						b.absorb()
					}else{
						other.remove()
					}
				}
			}
		}
	})
)
消火栓.buildType = prov(() => extend(LiquidTurret.LiquidTurretBuild, 消火栓, {
	findTarget() {
		this.super$findTarget()
		
		if(this.liquids.current() == Liquids.cryofluid){
			this.tile.circle((this.block.range - 1) / 8, cons(tile => {
				let other = Puddles.get(tile);
				if(other != null && other.liquid == Liquids.neoplasm && other.amount > 0.01 && this.target == null){
					this.target = b.create(this,Team.derelict,tile.worldx(),tile.worldy(),this.rotation - 180)
				}
			}))
		}
	}
}))