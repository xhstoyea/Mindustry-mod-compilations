const item = require('contents/item');
const env = require('contents/environment');

const picker = extend(Block, "picker", {
   ox: [],
   oy: [],
   drawPlace(x, y, rotation, valid) {
      this.super$drawPlace(x, y, rotation, valid);

      this.ox = [Angles.trnsx(rotation * 90, -1, -1), Angles.trnsx(rotation * 90, -1, 0), Angles.trnsx(rotation * 90, -1, 1)];
      this.oy = [Angles.trnsy(rotation * 90, -1, -1), Angles.trnsy(rotation * 90, -1, 0), Angles.trnsy(rotation * 90, -1, 1)];
      for (let i = 0; i <= 3; i++) {
         Drawf.dashSquare(
            Pal.accent,
            x * 8 + this.offset + this.ox[i] * 8,
            y * 8 + this.offset + this.oy[i] * 8,
            8
         );
      }
   },
   icons() {
      return [Core.atlas.find("计划战争-picker"), Core.atlas.find("计划战争-picker-top")]
   }
});
Object.assign(picker, {
   size: 1,
   health: 80,
   solid: true,
   update: true,
   hasShadow: true,
   destructible: true,
   rotate: true,
   rotateDraw: false,
   hasItems: true,
   buildVisibility: BuildVisibility.shown,
   category: Category.production,
});
picker.buildType = prov(() => extend(Building, {
   t: 0,
   ox: [],
   oy: [],
   updateTile() {
      this.super$updateTile();

      this.dump();

      this.t += Time.delta;

      this.ox = [Angles.trnsx(this.rotation * 90, -1, -1), Angles.trnsx(this.rotation * 90, -1, 0), Angles.trnsx(this.rotation * 90, -1, 1)];
      this.oy = [Angles.trnsy(this.rotation * 90, -1, -1), Angles.trnsy(this.rotation * 90, -1, 0), Angles.trnsy(this.rotation * 90, -1, 1)];

      if (this.t >= 300) {

         for (let i = 0; i < 3; i++) {
            if (Vars.world.tile(this.tileX() + this.ox[i], this.tileY() + this.oy[i]).block() == env.blimefruit) {
               this.items.add(item.limefruit, 2);
               Vars.world.tile(this.tileX() + this.ox[i], this.tileY() + this.oy[i]).setBlock(Blocks.air)
            }

            if (Vars.world.tile(this.tileX() + this.ox[i], this.tileY() + this.oy[i]).block() == env.climefruit) {
               this.items.add(item.limefruit, 3);
               Vars.world.tile(this.tileX() + this.ox[i], this.tileY() + this.oy[i]).setBlock(Blocks.air)
            }

            if (Vars.world.tile(this.tileX() + this.ox[i], this.tileY() + this.oy[i]).block() == env.alifecrystal) {
               this.items.add(item.生命晶体, 1);
               Vars.world.tile(this.tileX() + this.ox[i], this.tileY() + this.oy[i]).setBlock(Blocks.air)
            }

            if (Vars.world.tile(this.tileX() + this.ox[i], this.tileY() + this.oy[i]).block() == env.Blemon) {
               this.items.add(item.lemon, 1);
               Vars.world.tile(this.tileX() + this.ox[i], this.tileY() + this.oy[i]).setBlock(Blocks.air)
            }

         }

         this.t = 0;
      }
   },
   draw() {
      Draw.rect(Core.atlas.find("计划战争-picker"), this.x, this.y);
      Draw.z(30.1);

      Draw.rect(Core.atlas.find("计划战争-picker-top"), this.x, this.y, this.rotation * 90 + 90)
   },
   drawSelect() {
      this.super$drawSelect();

      for (let i = 0; i <= 3; i++) {
         Drawf.dashSquare(
            Pal.accent,
            this.x + this.offset + this.ox[i],
            this.y + this.offset + this.oy[i],
            8
         );
      }
   }
}))
exports.picker = picker;