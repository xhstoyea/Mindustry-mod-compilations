const lib = require("base/coflib");

function newUnit(name, unitType, cons) {
   const u = extend(UnitType, name, cons || {});
   u.constructor = () => new unitType.create();
   return exports[name] = u;
}
exports.newUnit = newUnit;

function specialUnit(name, unitType, cons, cons2) {
   const u = extend(UnitType, name, cons || {});
   let id;
   u.constructor = () => extend(unitType, cons2 || {
      classId() {
         return id
      }
   });
   id = EntityMapping.register(lib.modName + name, u.constructor);
   return exports[name] = u;
}
exports.specialUnit = specialUnit;

function newUnitList(name, unitType, num, cons) {
   for (let i = 1; i <= num; i++) newUnit(name + i, unitType, cons);
}

function immunities(u) {
   u.immunities.addAll(StatusEffects.burning, StatusEffects.melting, StatusEffects.blasted, StatusEffects.wet, StatusEffects.freezing, StatusEffects.sporeSlowed, StatusEffects.slow, StatusEffects.tarred, StatusEffects.muddy, StatusEffects.sapped, StatusEffects.electrified, StatusEffects.unmoving);
}
exports.immunities = immunities;
/*flying -> UnitEntity;
mech -> MechUnit;
legs -> LegsUnit;
naval -> UnitWaterMove;
payload -> PayloadUnit;
missile -> TimedKillUnit;
tank -> TankUnit;
hover -> ElevationMoveUnit;
tether -> BuildingTetherPayloadUnit;
crawl -> CrawlUnit;*/
function BottleUnitType(name, lifeTime, damage, range, status, effect, color) {
   let i = 0,
      dx = 0,
      dy = 0;
   let u = extend(MissileUnitType, name, {
      health: 10000,
      lifetime: lifeTime,
      speed: 0,
      trailLength: 0,
      flying: false,
      drawCell: false,
      hittable: false,
      targetable: false,
      loopSound: Sounds.none,
      update(unit) {
         this.super$update(unit);
         if ((i += Time.delta) >= 6) {
            Damage.damage(unit.x, unit.y, range, damage);
            Damage.status(null, unit.x, unit.y, range, status, 900, true, true);
            dx = unit.x + Mathf.range(range * 0.6);
            dy = unit.y + Mathf.range(range * 0.7);
            if (Mathf.chance(0.5)) effect.at(dx, dy, color);
            i = 0;
         }
      },
      draw(unit) {
         this.super$draw(unit);
         Draw.color(Pal.accent);
         Draw.z(Layer.effect);
         for (let i = 0; i < 4; i++) {
            let r = Time.time + i * 90;
            Lines.arc(unit.x, unit.y, range, 0.2, r);
         }
      }
   });
   u.immunities.add(status);
   return exports[name] = u;
}


newUnit("亡祭之魂", UnitEntity);