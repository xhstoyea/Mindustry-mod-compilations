//从野性之心中拿下来的
let 墙 = new Wall("特大型板制墙");
//var 墙 = extend(Wall, "wa1bbb板制墙", {});

墙.buildType = prov(() => extend(Wall.WallBuild, 墙, {
   handleDamage(amount) {
      amount = Math.min(amount * 10, amount + this.block.armor);
      if (amount > 5) return 5;
      return Damage.applyArmor(amount, this.block.armor);
   }
}));