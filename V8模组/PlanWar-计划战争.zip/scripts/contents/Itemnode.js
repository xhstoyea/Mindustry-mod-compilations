const range = 10; //范围

const 物品节点 = extend(ItemBridge, "物品节点", {
   drawPlace(x, y, rotation, valid) {
      Drawf.dashCircle(x * Vars.tilesize, y * Vars.tilesize, (range) * Vars.tilesize, Pal.accent);
   },
   //修改他的连接方式变成范围连接
   linkValid(tile, other, checkDouble) {
      if (other == null || tile == null || other == tile) return false;
      if (Math.pow(other.x - tile.x, 2) + Math.pow(other.y - tile.y, 2) > Math.pow(range + 0.5, 2)) return false;
      return ((other.block() == tile.block() && tile.block() == this) || (!(tile.block() instanceof ItemBridge) && other.block() == this)) &&
         (other.team == tile.team || tile.block() != this) &&
         (!checkDouble || other.build.link != tile.pos());
   },
});

const block = 物品节点;

物品节点.buildType = prov(() => {
   return new JavaAdapter(ItemBridge.ItemBridgeBuild, {
      /*checkIncoming(){
      
      },*/
      updateTile() {
         const other = Vars.world.build(this.link);
         if (other != null) {
            if (!block.linkValid(this.tile, other.tile)) {
               this.link = -1;
               //return;
            }
         }
         this.super$updateTile();
      },
   /*   //修改他的连接显示为线状
      draw(){
            var other = Vars.world.build(this.link);
            if(other == null) return;//如果没有连接目标，那么直接返回，不会运行下面的语句
            Draw.rect(Core.atlas.find("计划战争-物品节点-end"), this.x, this.y);
            Draw.rect(Core.atlas.find("计划战争-物品节点-end"), other.x, other.y);
    
            Lines.stroke(8);
    
            Tmp.v1.set(this.x, this.y).sub(other.x, other.y).setLength(Vars.tilesize/2).scl(-1);
    
            Lines.line(bridgeRegion,
                this.x,
                this.y,
                other.x,
                other.y, false);
            Draw.reset();
        }, *///这里的语句不启用，其实也挺好的不然你又得重写一遍


      //下面是修改他进物品和出物品为全向
      acceptItem(source, item) {
         if (this.team != source.team || !block.hasItems) return false;
         //var other = Vars.world.tile(this.link);
         return /*other != null && this.block.linkValid(this.tile, other) && */ this.items.total() < block.itemCapacity;
      }, //输入


      checkDump(to) {
         return true;
      }, //输出
   }, 物品节点);
});
exports.物品节点 = 物品节点;