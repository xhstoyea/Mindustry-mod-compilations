const item = require('contents/item')
//const liquid = require('计划战争/liquid')
//const status = require('计划战争/status')


//果实
const blimefruit = new Wall("blimefruit");
Object.assign(blimefruit, {
   targetable: false,
})
exports.blimefruit = blimefruit;


//大树
const limetre2 = extend(TreeBlock, "limetre2", {
   update: true,
   targetable: false,
});
limetre2.buildType = prov(() => extend(Building, {
   i: 0,
   drawSelect() {
      this.super$drawSelect();

      Drawf.dashSquare(Pal.accent, this.x, this.y, 25)
   },
   updateTile() {
      this.super$updateTile();

      this.i += Time.delta

      if (this.i >= 60 * 20) {
         this.tile.circle(2, cons(tile => {
            if (Mathf.chance(0.25) && tile.block() == Blocks.air) {
               tile.setBlock(blimefruit, this.team);
            }
         }))
         this.i = 0
      }
   },
   write(write) {
      this.super$write(write);
      write.f(this.i);
   },
   read(read, revision) {
      this.super$read(read, revision);
      this.i = read.f();
   }
}))

//树苗
const limetre1 = extend(TreeBlock, "limetre1", {
   drawPlace(x, y, rotation, valid) {
      this.super$drawPlace(x, y, rotation, valid);

      Drawf.dashSquare(Pal.accent, x * 8, y * 8, 25)
   },
   setBars() {
      this.super$setBars();
      this.addBar("growthProgress", func(e => new Bar(
         prov(() => Core.bundle.get("bar.growthProgress", Strings.fixed(e.getGrowthProgress() * 100, 0))),
         prov(() => Pal.powerBar),
         floatp(() => e.getGrowthProgress())
      )));
   }
});
limetre1.buildType = prov(() => extend(Building, {
   i: 0,
   drawSelect() {
      this.super$drawSelect();

      Drawf.dashSquare(Pal.accent, this.x, this.y, 25)
   },
   updateTile() {
      this.super$updateTile();

      this.i += Time.delta

      if (this.i >= 60 * 60) {
         this.tile.setBlock(limetre2, this.team);
      }
   },
   getGrowthProgress() {
      return this.i / 3600
   },
   write(write) {
      this.super$write(write);
      write.f(this.i);
   },
   read(read, revision) {
      this.super$read(read, revision);
      this.i = read.f();
   }
}))
exports.limetre1 = limetre1;
Object.assign(limetre1, {
   buildVisibility: BuildVisibility.shown,
   category: Category.effect,
   requirements: ItemStack.with(
      item.limefruit, 1,
   ),
   update: true,
   researchCostMultiplier: 0.05,
   buildCostMultiplier: 50,
   targetable: false,
})




//高产石灰树

const climefruit = new Wall("climefruit");
Object.assign(blimefruit, {
   targetable: false,
})
exports.climefruit = climefruit;



const climetre2 = extend(TreeBlock, "climetre2", {
   update: true,
   targetable: false,
});
climetre2.buildType = prov(() => extend(Building, {
   i: 0,
   drawSelect() {
      this.super$drawSelect();

      Drawf.dashSquare(Pal.accent, this.x, this.y, 25)
   },
   updateTile() {
      this.super$updateTile();
      this.i += Time.delta

      if (this.i >= 60 * 10) {
         this.tile.circle(2, cons(tile => {
            if (Mathf.chance(0.25) && tile.block() == Blocks.air) {
               tile.setBlock(climefruit, this.team);
            }
         }))
         this.i = 0
      }
   },
   write(write) {
      this.super$write(write);
      write.f(this.i);
   },
   read(read, revision) {
      this.super$read(read, revision);
      this.i = read.f();
   }
}))


const climetre1 = extend(TreeBlock, "climetre1", {
   drawPlace(x, y, rotation, valid) {
      this.super$drawPlace(x, y, rotation, valid);

      Drawf.dashSquare(Pal.accent, x * 8, y * 8, 25)
   },
   setBars() {
      this.super$setBars();
      this.addBar("growthProgress", func(e => new Bar(
         prov(() => Core.bundle.get("bar.growthProgress", Strings.fixed(e.getGrowthProgress() * 100, 0))),
         prov(() => Pal.powerBar),
         floatp(() => e.getGrowthProgress())
      )));
   }
});
climetre1.buildType = prov(() => extend(Building, {
   i: 0,
   drawSelect() {
      this.super$drawSelect();

      Drawf.dashSquare(Pal.accent, this.x, this.y, 25)
   },
   updateTile() {
      this.super$updateTile();

      this.i += Time.delta

      if (this.i >= 60 * 30) {
         this.tile.setBlock(climetre2, this.team);
      }
   },
   getGrowthProgress() {
      return this.i / 1800
   },
   write(write) {
      this.super$write(write);
      write.f(this.i);
   },
   read(read, revision) {
      this.super$read(read, revision);
      this.i = read.f();
   }
}))
exports.climetre1 = climetre1;
Object.assign(climetre1, {
   buildVisibility: BuildVisibility.shown,
   category: Category.effect,
   requirements: ItemStack.with(
      item.limetreec, 1,
   ),
   update: true,
   researchCostMultiplier: 0.05,
   buildCostMultiplier: 50,
   targetable: false,
})



//生命水晶簇

const alifecrystal = new Wall("alifecrystal");
Object.assign(alifecrystal, {
   targetable: false,
})
exports.alifecrystal = alifecrystal;

const alifecrystal2 = extend(TreeBlock, "alifecrystal2", {
   update: true,
   targetable: false,
});
alifecrystal2.buildType = prov(() => extend(Building, {
   i: 0,
   drawSelect() {
      this.super$drawSelect();

      Drawf.dashSquare(Pal.accent, this.x, this.y, 25)
   },
   updateTile() {
      this.super$updateTile();

      this.i += Time.delta

      if (this.i >= 60 * 20) {
         this.tile.circle(2, cons(tile => {
            if (Mathf.chance(0.25) && tile.block() == Blocks.air) {
               tile.setBlock(alifecrystal, this.team);
            }
         }))
         this.i = 0
      }
   },
   write(write) {
      this.super$write(write);
      write.f(this.i);
   },
   read(read, revision) {
      this.super$read(read, revision);
      this.i = read.f();
   }
}))




//果实
const Blemon = new Wall("Blemon");
Object.assign(Blemon, {
   targetable: false,
})
exports.Blemon = Blemon;


//大树
const LemonTree = extend(TreeBlock, "LemonTree", {
   update: true,
   targetable: false,
});
LemonTree.buildType = prov(() => extend(Building, {
   i: 0,
   drawSelect() {
      this.super$drawSelect();

      Drawf.dashSquare(Pal.accent, this.x, this.y, 41)//50
   },
   updateTile() {
      this.super$updateTile();

      this.i += Time.delta

      if (this.i >= 60 * 5) {
         this.tile.circle(3, cons(tile => {
            if (Mathf.chance(0.25) && tile.block() == Blocks.air) {
               tile.setBlock(Blemon, this.team);
            }
         }))
         this.i = 0
      }
   },
   write(write) {
      this.super$write(write);
      write.f(this.i);
   },
   read(read, revision) {
      this.super$read(read, revision);
      this.i = read.f();
   }
}))



//树苗
const SLemonTree = extend(TreeBlock, "SLemonTree", {
   drawPlace(x, y, rotation, valid) {
      this.super$drawPlace(x, y, rotation, valid);

      Drawf.dashSquare(Pal.accent, x * 8, y * 8, 41)
   },
   setBars() {
      this.super$setBars();
      this.addBar("growthProgress", func(e => new Bar(
         prov(() => Core.bundle.get("bar.growthProgress", Strings.fixed(e.getGrowthProgress() * 100, 0))),
         prov(() => Pal.powerBar),
         floatp(() => e.getGrowthProgress())
      )));
   }
});
SLemonTree.buildType = prov(() => extend(Building, {
   i: 0,
   drawSelect() {
      this.super$drawSelect();

      Drawf.dashSquare(Pal.accent, this.x, this.y, 41)
   },
   updateTile() {
      this.super$updateTile();

      this.i += Time.delta

      if (this.i >= 60 * 50) {
         this.tile.setBlock(LemonTree, this.team);
      }
   },
   getGrowthProgress() {
      return this.i / 3000
   },
   write(write) {
      this.super$write(write);
      write.f(this.i);
   },
   read(read, revision) {
      this.super$read(read, revision);
      this.i = read.f();
   }
}))
exports.SLemonTree = SLemonTree;
Object.assign(SLemonTree, {
   buildVisibility: BuildVisibility.shown,
   category: Category.effect,
   requirements: ItemStack.with(
      item.lemon, 1,
   ),
   update: true,
   researchCostMultiplier: 0.05,
   buildCostMultiplier: 50,
   targetable: false,
})