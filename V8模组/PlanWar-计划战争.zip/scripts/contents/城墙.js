const 辐射 = new StatusEffect("辐射损伤")

const 大型铀墙 = new Wall("大型铀墙")
Object.assign(大型铀墙, {
    health: 3200,
	size: 2,
	category: Category.defense,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		item.铀, 24,
	),
	});
大型铀墙.buildType = prov(() => extend(Building,{
              draw(){
              this.super$draw();
        Units.nearby(null,this.x,this.y,128,other => {
               if(other.team != this.team)
               {
                  other.apply(辐射损伤,200);
               }
         })
        Draw.color(Color.valueOf('008000'));
        Draw.alpha(0.8);
        Draw.z(Layer.shields);
        Fill.poly(this.x, this.y, 12, 128);
  },
}));
exports.大型铀墙 = 大型铀墙;

