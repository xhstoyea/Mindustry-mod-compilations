const WallBuild = Wall.WallBuild;

var wall = extend(Wall, "赤焰墙", {
    update: true,
    size: 2,
    health: 3200,
})

wall.setupRequirements(
    Category.defense,
    BuildVisibility.shown,
    ItemStack.with(Items.copper, 200, Items.lead, 150)
);

var dumpTime = 20; // 输出间隔时间(帧)
var dumpScaling = 0.5;
var maxDumpHealth = 200; // 最大输出血量
wall.buildType = () => {
    let dumpTimer = Mathf.random(dumpTime);
    return extend(WallBuild, wall, {
        updateTile(){
            dumpTimer -= this.delta();
            
            if(dumpTimer <= 0){
                this.dumpHealth();
                
                dumpTimer = dumpTime;
            }
        },
        
        dumpHealth(){
            let {block, maxHealth, proximity, cdump} = this;
            
            let size = proximity.size;
            
            if(size == 0){
                return;
            }
            
            this.incrementDump(size);
            
            for(let i = 0; i < size; i++){
                let other = proximity.get((cdump + i) % size);
                
                if(other.block != block){
                    continue;
                }
                
                let ofract = other.healthf();
                let fract = this.healthf();
                
                if(ofract < fract){
                    let amount = Math.min(maxDumpHealth, (fract - ofract) * maxHealth) * dumpScaling;
                    this.damage(amount);
                    other.heal(amount);
                }
            }
        },
        
        draw(){
            this.super$draw();
            
            let {block, x, y} = this;
            let size = block.size * Vars.tilesize;
            
            Draw.color(Pal.health, this.healthf());
            Fill.rect(x, y, size, size);
            
            Draw.reset();
        },
        
    });
}