/** 
    项目: 方向入料 [20220806]
    作者: miner
*/
const qws = new Item("qws", Color.valueOf("C2FFFBFF"));
exports.qws = qws;
const qwa = new Item("qwa", Color.valueOf("C2FFFBFF"));
exports.qwa = qwa;
const qwe = new Item("qwe", Color.valueOf("C2FFFBFF"));
exports.qwe = qwe;
const zit单元 = new Item("zit单元", Color.valueOf("7AFFF8FF"));
exports.zit单元 = zit单元;
const 建造许可 = new Item("建造许可", Color.valueOf("B0BAC0FF"));
exports.建造许可 = 建造许可;
const GenericCrafterBuild = GenericCrafter.GenericCrafterBuild;

var block;

var itemRotaions = Seq.with(
    /*  */qwe, null, qwe, null, qwe,/*   */
    Items.silicon,/*                                            */Items.copper,
    null,/*                                                     */null,
    qws,/*                                            */zit单元,
    null,/*                                                     */null,
    Items.silicon,/*                                            */Items.copper,
    /*  */qwa, null, qws, null, qwa,/*   */
);

var rotationMap = new ObjectMap();
let crafter = Object.assign(extend(GenericCrafter, "建造申请所", {
    init(){
        block = this;
                
        initRotations();
        
        this.super$init();
    },

    drawOverlay(x, y, rotation){
        let tilesize = Vars.tilesize;
        let offset = -this.offset;
        
        x += offset;
        y += offset;
                
        Draw.mixcol(Pal.accent, 0.24 + Mathf.absin(Time.globalTime, 12, 0.4));
        Draw.alpha(0.9);
        
        let v1 = Tmp.v1.set(offset, offset);
        rotationMap.each((item, seq) => {
            seq.each(point => {
                let v2 = Tmp.v2.set(point.x, point.y);
            
                let v = v2.rotateAround(v1, rotation * 90);
            
                let dx = x + tilesize * v.x;
                let dy = y + tilesize * v.y;
                                
                Draw.rect(item.uiIcon, dx, dy, 5.5, 5.5);
            });
        });
        
        Draw.reset();
    },
}), {
    size: 5,
    rotate: true,
    outputItem: new ItemStack(建造许可, 1),
    craftTime: 555,
    hasPower: true,
});

crafter.consumeItems(ItemStack.with(Items.copper, 3, qwe, 4, qwa, 2, Items.silicon, 3, qws, 1, zit单元, 1));

crafter.setupRequirements(
    Category.production,
    BuildVisibility.shown,
    ItemStack.with(Items.copper, 200, Items.silicon, 150 , qwe, 100)
);

function initRotations(){
    let blockSize = block.size;
    
    if(itemRotaions.size != blockSize * 4){
        throw new Error("物品方向不合标 请检查你的物品是否与方块各方向一一对应");
    }
    
    let edges = Edges.getInsideEdges(blockSize);
    
    let w = parseInt(blockSize / 2);
    for(let i = 0, length = edges.length; i < length; i++){
        let n = (i + w) % blockSize;
        let rotation = parseInt((i + w) / blockSize) % 4;
        
        let mapIndex = -1;
        switch(rotation){
            case 0: 
                mapIndex = blockSize * 3 - 2 * n - 1;
                break;
            case 1:
                mapIndex = blockSize - n - 1;
                break;
            case 2:
                mapIndex = blockSize + 2 * n;
                break;
            case 3:
                mapIndex = blockSize * 3 + n;
                break;
        }
        
        // print("i: " + i + " / " + "index: " + mapIndex);
        
        let item = itemRotaions.get(mapIndex);
        let point = edges[i].cpy();
        
        if(item == null) continue;
        
        let ar = (rotation) % 4;
        let addPoint = Geometry.d4[ar];
        
        point.add(addPoint);
        
        rotationMap.get(item, prov(() => new Seq())).add(point);
    }
    
    // print("rotationMap: " + rotationMap);
}
crafter.buildType = () => {
    let tilesize = Vars.tilesize;
    let world = Vars.world;
    
    let offset = -block.offset;
        
    return extend(GenericCrafterBuild, block, {
    
        acceptItem(source, item){
            let x = this.x + offset, y = this.y + offset;
            let rotation = this.rotation;
            
            let seq = rotationMap.get(item);
            
            if(seq == null) return this.super$acceptItem(source, item);
            
            let v1 = Tmp.v1.set(offset, offset);
            let valid = seq.contains(boolf(point => {
                let v2 = Tmp.v2.set(point.x, point.y);
            
                let v = v2.rotateAround(v1, rotation * 90);
            
                let bx = x + tilesize * v.x;
                let by = y + tilesize * v.y;
                
                let build = world.buildWorld(bx, by);
                
                return build == source;
            }));
            
            return this.super$acceptItem(source, item) && valid;
        },
        
    });
}