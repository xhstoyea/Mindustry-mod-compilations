//作者VSHES/荔枝 qq2595168568 未经允许禁止私自使用
const items = require("base/items");

const lq = new Block('力墙限制器');
lq.configurable = true;
lq.solid = true;
lq.destructible = true;
lq.update = true;
lq.requirements = ItemStack.with(
	Items.silicon, 125,
	items.钢铁, 200,
	items.金, 60
);

lq.buildType = prov(() => extend(Building, {
	angle: 360,
	range: 50,
	a: 0,
	shield: 0,
	canOpen: true,
	canAL: false,
	i: 0,
	rangee: 50,
	isBroken: false,
	canTime: false,
	d: 0,
	update() {
		this.super$update();
		if (this.canAL) {
			this.i += Time.delta;
			if (this.i >= 0 && this.i <= 5) {
				this.range = 0;
			}
			if (this.range <= this.rangee) {
				this.range += 2;
			}
			if (this.range == this.rangee) {
				this.i = 0;
				this.canAL = false;
			}
		}

		if (this.shield <= 0 && this.isBroken) {
			this.canTime = true;
		}

		if (this.canTime) {
			this.d += Time.delta;
			if (this.d >= 1800) {
				this.isBroken = false;
				this.canOpen = true;
				this.d = 0;
				this.canTime = false;
			}
		}

		Groups.bullet.intersect(this.x - this.range, this.y - this.range, this.range * 2, this.range * 2, cons(b => {
			if (this.shield > 0 && b.team != this.team) {
				b.absorb();
				Fx.absorb.at(b);
				this.shield -= b.damage;
			}
		}))
		Vars.ui.showLabel("盾容" + Math.floor(this.shield), 0.01, this.x, this.y + 4);
		Vars.ui.showLabel("范围" + this.rangee, 0.01, this.x, this.y - 4);
	},
	draw() {
		this.super$draw();

		Draw.z(Layer.shields);
		if (this.shield > 0) {
			this.a = 0.8;
			Draw.color(Pal.accent);
			Lines.stroke(2.5);
			Draw.alpha(this.a);
			Lines.arc(this.x, this.y, this.range, this.angle);
		} else {
			this.a = 0
		}
	},
	buildConfiguration(table) {
		table.button(Icon.add, Styles.cleari, run(() => {
			if (this.rangee < 150 && this.shield <= 0) {
				this.rangee += 50;
			}
		})).size(45);

		table.button(Icon.download, Styles.cleari, run(() => {
			if (this.rangee > 50 && this.shield <= 0) {
				this.rangee -= 50;
			}
		})).size(45);

		table.button(Icon.book, Styles.cleari, run(() => {
			if (this.canOpen) {
				this.canAL = true;
				this.shield = 75000 / this.rangee;
				this.isBroken = true;
				this.canOpen = false;
			}
		})).size(45);
	}
}));
exports.lq = lq;