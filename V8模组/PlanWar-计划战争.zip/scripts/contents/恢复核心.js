//作者VSHES/荔枝 qq2595168568 未经允许禁止私自使用别删此行如果在其他mod见到此文件切未经过授权后果自负
let HealCore = new Effect(100, e =>{
	 Draw.color(Color.valueOf("8BE8AA"));
	 Fill.square(e.x,e.y,e.fslope() * 1.5 + 0.14, 45);
});

const item = require("ap物品");

const 恢复 = new UnitType("恢复");
Object.assign(恢复, {
	coreUnitDock : true,
	aiController: UnitTypes.evoke.aiController,
	controller: u => new BuilderAI(true, 512),
	isEnemy: false,
	fogRadius: 0,
	lowAltitude: true,
	flying: true,
	mineSpeed: 5,
	mineHardnessScaling: false,
	mineTier: 1,
	buildSpeed: 1,
	drag: 0.05,
	speed: 3,
	rotateSpeed: 15,
	accel: 0.1,
	itemCapacity: 40,
	payloadCapacity: 256,
	health: 150,
	engineOffset: 7,
	hitSize: 8,
	alwaysUnlocked: true,
	targetable : false,
	hittable : false,
	constructor: () => new UnitEntity.create(),
})
恢复.weapons.add(
Object.assign(new RepairBeamWeapon(), {
	top: true,
	mirror: false,
	rotate: false,
	widthSinMag: 0.11,
	beamWidth: 0.7,
	repairSpeed: 3.1,
	fractionRepairSpeed: 0.06,
	x: 0,
	y: 3,
	reload: 20,
	targetUnits: false,
	targetBuildings: true,
	autoTarget: false,
	controllable: true,
	bullet: Object.assign(new BulletType(), {
		maxRange: 60,
	})
})
)

const 恢复核心 = new CoreBlock('core-恢复核心');
恢复核心.size = 3;
恢复核心.health = 1500;
恢复核心.configurable = true;
恢复核心.buildVisibility = BuildVisibility.shown;
恢复核心.category = Category.effect;
恢复核心.solid = true;
恢复核心.update = true;
恢复核心.unitType = 恢复;
恢复核心.itemCapacity = 3000;
恢复核心.unitCapModifier = 12;
恢复核心.destructible = true;
恢复核心.requirements = ItemStack.with(
	Items.graphite, 1500,
	item.钴, 1200,
);
恢复核心.buildType = prov(() => extend(CoreBlock.CoreBuild, 恢复核心, {
	updateTile() {
		this.super$updateTile();
		if (this.healthf() < 1) {
			this.heal(1500 / 18000);
			if (this.timer.get(12))
			HealCore.at(this.x + Mathf.range(3 * Vars.tilesize / 2 - 1), this.y + Mathf.range(3 * Vars.tilesize / 2 - 1));
		}
	}
}));
exports.恢复核心 = 恢复核心;