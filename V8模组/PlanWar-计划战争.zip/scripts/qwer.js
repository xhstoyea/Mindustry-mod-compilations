Events.on(EventType.ClientLoadEvent, cons(e => {
   var dialog = new BaseDialog("[cyan]plan war");
   dialog.cont.image(Core.atlas.find("计划战争-black hole"))
      .row();;
   dialog.buttons.defaults()
      .size(210, 64);
   dialog.buttons.button("@close", run(() => {
         dialog.hide();
      }))
      .size(210, 64);
   dialog.cont.pane((() => {
         var table = new Table();
         table.add("[#FCF387FF]版本更新:\n1.\n2.\n3.\n4.\n5.\n6.\n\n[gold]—————联系方式—————\n[red] 模组群: 294835498 (QQ)\n\n\nmod使用(或存在)语言/配置文件:\njava\njavascripts\n(h)json\ntoml\n\n[#FFE266FF]请确保你的手机支持js等语言(废话)")
            .left()
            .growX()
            .wrap()
            .width(600)
            .maxWidth(1000)
            .pad(4)
            .labelAlign(Align.left);
         table.row();
         table.button("[green]图片", run(() => {
               var dialog2 = new BaseDialog("[green]Picture");
               var table = new Table();
               dialog2.cont.image(Core.atlas.find("计划战争-plan war"))
                  .row();;
               dialog2.buttons.defaults()
                  .size(210, 64);
               dialog2.buttons.button("@close", run(() => {
                     dialog2.hide();
                  }))
                  .size(210, 64);
               dialog2.show();
            }))
            .size(210, 64)
            .row();

         table.button("[red]致谢/制作名单", run(() => {
               var dialog2 = new BaseDialog("[red]致谢/制作名单");
               var table = new Table();

               var t = new Table();
               t.add("__模组本体制作名单(排名不分先后)__\n代码:\n—(h)json/toml:为反复试听—\n—java:Alon—\n—js:各模组()—\n贴图:\n—ShallowSmiles—\n—为反复试听—\n—TimotheaHalley—\n—隐隐约约的齿轮组—\n蓝图制作:\n—为反复试听—\n地图制作(包括地图内的波次/规则/世界处理器/任务编辑器):\n—为反复试听—\n星球战役制作:\n—为反复试听—\n剧情制作:\n—为反复试听—\n音效制作:\n—为反复试听—\n—其他游戏(铁锈战争/无限塔防2/极度真空/Heros_Hour)或模组—\n音乐制作:\n—为反复试听—\n\n\n\n[#99F8FFFF]致谢名单[white]:\n非常重要的:TimotheaHalley；[gold]隐隐约约的齿轮组；[gold]火石，我只喜欢火石\n[white]对我有特殊意义的[gold]2356；[gold]MST₇₁[white]\n...\n...\n[gold]ShallowSmiles[white]--[red]这个模组的原作者[whitr]--愿你安息\n\n\n[cyan]还有\n\n[pink]致每一个玩我模组的人\n--------[#FFE266FF]你们--------");
               dialog2.cont.add(new ScrollPane(t))
                  .size(1500, 600)
                  .row();
               dialog2.buttons.defaults()
                  .size(620, 64);
               dialog2.buttons.button("@close", run(() => {
                     dialog2.hide();
                  }))
                  .size(500, 64);
               dialog2.show();
            }))
            .size(210, 64);;
         return table;
      })())
      .grow()
      .center()
      .maxWidth(600);
   dialog.show();
}));