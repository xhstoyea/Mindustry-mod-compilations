let ability = require("contents/ability");

function newUnit(name, unitType) {
	const u = extend(UnitType, name, {});
	u.constructor = () => extend(unitType, {});
	return exports[name] = u;
}
exports.newUnit = newUnit;
/*"flying" -> UnitEntity;
"mech" -> MechUnit;
"legs" -> LegsUnit;
"naval" -> UnitWaterMove;
"payload" -> PayloadUnit;
"missile" -> TimedKillUnit;
"tank" -> TankUnit;
"hover" -> ElevationMoveUnit;
"tether" -> BuildingTetherPayloadUnit;
"crawl" -> CrawlUnit;*/

function parasite(name) {
	let p = extend(UnitType, name, {
		display(unit, table) {
			this.super$display(unit, table);
if (unit.fin() != null)  table.getChildren().get(1).add(new Bar("存活时间", Pal.accent,() => 1 - unit.fin())).row();
		}
	})
	p.constructor = () => extend(TimedKillUnit, {});
	return exports[name] = p;
}
let 驱逐 = newUnit("驱逐",UnitEntity);

驱逐.abilities.add(ability.RotatorAbility("qw", 0, 0, 6, 26));

//let 驱离 = newUnit("驱离",UnitEntity);

//驱离.abilities.add(ability.RotatorAbility("qw", 0, 0, 5, 25));
