
//require('bmain');
//require('cymain');
require('cmain');
require('qwer');
//require('content/LimitharmWall');
//require('content/Itemnode');

//require('factory');
require('特殊/namecolor');
require('特殊/Backgroundplate');
require('特殊/SchematicSize');
require('特殊/资源显示');
require('特殊/区块编号');
require('特殊/作弊菜单');
require('特殊/超级源');
//require('特殊/时间加速');
//require('特殊/蓝图');
//require("content/MPlanets");
var startColor = Color.valueOf("00FFE1FF"); //初始颜色

var shiftValue = 20; //颜色跨度，360度为一次轮回

var mod = Vars.mods.locateMod("计划战争"); //这里的extra-utilities换成你的mod.(h)json里面写的name

var st = mod.meta.displayName;

var fin = new java.lang.StringBuilder();



for (var i = 0; i < st.length; i++) {

   var s = java.lang.String.valueOf(st.charAt(i));

   var c = startColor.shiftHue(i * (shiftValue / st.length));

   var ci = c.rgb888();

   var ct = java.lang.Integer.toHexString(ci);

   var fct = "[" + "#" + ct + "]";

   fin.append(fct)
      .append(s);

}


mod.meta.displayName = fin.toString();
Events.on(EventType.ClientLoadEvent, () => {
   if (Vars.mods.getMod("无限宇宙") != null) Vars.mods.removeMod(Vars.mods.getMod("无限宇宙"));
})