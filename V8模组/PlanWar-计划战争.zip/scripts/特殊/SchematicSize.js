Vars.maxSchematicSize = 128;
if (!Vars.headless) {
   Vars.renderer.minZoom = 0.1;
   Vars.renderer.maxZoom = 50;
}