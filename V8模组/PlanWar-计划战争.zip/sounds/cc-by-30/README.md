Content of this folder indicates assets made by various authors, under the default [CC-BY 3.0](https://creativecommons.org/licenses/by/3.0/) license.

* [raygun_newlocknew.ogg](https://freesound.org/people/newlocknew/sounds/514022/) by newlocknew
* [ccbysmgfire01.ogg](http://soundbible.com/2091-MP5-SMG-9mm.html) by GunGuru
* [ccbygrenadelaunch01.ogg](http://soundbible.com/2140-Grenade-Launcher-2.html) by Daniel Simon
* [ccbysmgfire02.ogg](http://soundbible.com/1575-High-Definition-Machine-Gun.html) by WEL
* [twisterman_silenced-gun-1.ogg](https://freesound.org/people/twisterman/sounds/163583/) by twisterman
* [submarine_in_szegvari.ogg](https://freesound.org/people/szegvari/sounds/572537/) by szegvari
* [submarine_out_szegvari.ogg](https://freesound.org/people/szegvari/sounds/572537/) by szegvari
* [worm_death_inspectorj.ogg](https://freesound.org/people/InspectorJ/sounds/401943/) by InspectorJ
* [ricochet1-10_rakurka.ogg](https://freesound.org/people/rakurka/sounds/109957/) by rakurka
* [missile_julien-nicolas.ogg](https://freesound.org/people/rakurka/sounds/109957/) by julien nicolas
* [torpedo_murraysortz.ogg](https://freesound.org/people/murraysortz/sounds/192501/) by murraysortz. Mixed with Dzierzan's voice.
* [boatgun_johandeecke.ogg](https://freesound.org/people/JohanDeecke/sounds/369528/) by JohanDeecke.
* [blaster_flyingsaucerinvasion.ogg](https://freesound.org/people/flyingsaucerinvasion/sounds/615812/) by flyingsaucerinvasion
* [explosion1_smcameron.ogg](https://freesound.org/people/smcameron/sounds/51467/) by smcameron. Mixed with explosion04.ogg
* [explosion2_smcameron.ogg](https://freesound.org/people/smcameron/sounds/51467/) by smcameron. Mixed with explosion05.ogg
* [cannon_sarge4267.ogg](https://freesound.org/people/sarge4267/sounds/102720/) by sarge4267
* [big_explosion_jobro.ogg](https://freesound.org/people/jobro/sounds/35463/) by jobro
