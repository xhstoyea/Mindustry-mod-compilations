Events.run(EventType.ClientLoadEvent, () => {
var worldprocessor = Blocks.worldProcessor;
var settings = Vars.ui.settings;
settings.game.checkPref("世处是否拥有特权", true);
settings.game.sliderPref("世处运行指令上限", 1000, 1, 1000, 5, i => i + "每Tick");
Timer.schedule(() => {
worldprocessor.privileged = Core.settings.getBool("世处是否拥有特权", true);
worldprocessor.maxInstructionsPerTick = Core.settings.getInt("世处运行指令上限");
}, 0, 0.2, -1);
});
