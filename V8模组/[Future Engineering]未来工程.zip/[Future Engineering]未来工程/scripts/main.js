require("content/blocks");
require("开屏页面")
