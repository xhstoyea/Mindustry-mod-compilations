/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Import
    const PARENT = require("reind/blk/blk_genericFactory");

    const mdl_attr = require("reind/mdl/mdl_attr");
    const mdl_content = require("reind/mdl/mdl_content");
    const mdl_data = require("reind/mdl/mdl_data");
    const mdl_draw = require("reind/mdl/mdl_draw");
    const mdl_effect = require("reind/mdl/mdl_effect");
    const mdl_game = require("reind/mdl/mdl_game");
    const mdl_table = require("reind/mdl/mdl_table");

    const db_block = require("reind/db/db_block");
    const db_stat = require("reind/db/db_stat");
  // End


  // Part: Auxilliary
    function ax_buildStats_rsMtp(blk) {
      return function(tb) {
        mdl_table.setResourceMultiplierDisplay(tb, blk);
      };
    };


    function ax_buildStats_attrBlk(blk) {
      return function(tb) {
        mdl_table.setAttributeBlockDisplay(tb, mdl_attr._blkEffcMap_attrMap(mdl_attr._map(blk)));
      };
    };


    function ax_buildStats_attrMap(blk) {
      return function(tb) {
        mdl_table.setAttributeMapDisplay(tb, mdl_attr._map(blk));
      };
    };
  // End


  // Part: Component
    function setStatsComp(blk) {
      if(db_block.db["map"]["rsMtp"].includes(blk.name)) blk.stats.add(db_stat.resourceMultiplier, ax_buildStats_rsMtp(blk));

      blk.stats.remove(Stat.tiles);
      blk.stats.remove(Stat.affinities);
      blk.stats.add((blk.baseEfficiency > 0.0) ? Stat.affinities : Stat.tiles, ax_buildStats_attrBlk(blk));

      blk.stats.remove(Stat.output);
      blk.stats.add(Stat.output, ax_buildStats_attrMap(blk));
    };


    function updateTileComp(b) {
      if(b.needCheck) {
        b.attrPair = b.block.ex_getAttrPair(b.tile);
        b.rsTg = mdl_content._ct_gn((b.attrPair == null) ? null : b.attrPair[0]);
        b.rsEffc = (b.attrPair == null) ? 1.0 : b.attrPair[1];
        b.prodRate = b.block.ex_getProdRate(b.rsTg);
        b.craftSound = mdl_data.read_1n1v(db_block.db["param"]["sound"]["craft"], b.block.name, null);

        b.needCheck = false;
      };

      if(b.rsTg == null) return;

      if(b.efficiency < 0.0001 || !b.shouldConsume()) {
        b.warmup = Mathf.approachDelta(b.warmup, 0.0, b.block.warmupSpeed);
      } else {
        b.warmup = Mathf.approachDelta(b.warmup, b.warmupTarget(), b.block.warmupSpeed);

        b.progress += b.getProgressIncrease(b.block.craftTime);
        if(b.progress > 1.0) {
          b.progress %= 1.0;

          if(b.rsTg instanceof Item) {
            var amt = Math.round(b.prodRate * b.block.craftTime / 60.0);
            for(let i = 0; i < amt; i++) {b.offload(b.rsTg)};
          };
          b.consume();

          mdl_effect.showAt(b, b.block.craftEffect, 0.0);
          mdl_effect.playAt(b, b.craftSound, Math.min(b.block.ambientSoundVolume * 2.0, 1.0), 1.0, 0.1);
        };

        if(b.rsTg instanceof Liquid) {
          b.handleLiquid(b, b.rsTg, Math.min(b.prodRate * b.getProgressIncrease(1.0), b.block.liquidCapacity - b.liquids.get(b.rsTg)));
        };

        mdl_effect.showAroundP(b.block.updateEffectChance, b, b.block.updateEffect, b.block.size * Vars.tilesize * 0.5, 0.0);
      };

      b.totalProgress += b.warmup * b.edelta();

      if(b.rsTg instanceof Liquid) {
        b.dumpLiquid(b.rsTg, 2.0, -1);
      } else {
        b.dump(b.rsTg);
      };
    };


    function sumAttributeComp(blk, attribute, tx, ty) {
      var pair = blk.ex_getAttrPair(Vars.world.tile(tx, ty));
      return (pair == null) ? 0.0 : pair[1];
    };


    function shouldConsumeComp(b) {
      if(b.rsTg == null) return false;

      if(b.rsTg instanceof Item) {
        return b.prodRate * b.block.craftTime + b.items.get(b.rsTg) < b.block.itemCapacity;
      } else {
        return b.block.ignoreLiquidFullness ? true : (b.liquids.get(b.rsTg) < b.block.liquidCapacity);
      };
    };


    function drawSelectComp(b) {
      mdl_draw.drawContentIcon(b, b.rsTg, b.block.size);
    };


    function ex_getAttrPairComp(blk, t) {
      return mdl_attr._attrPair(mdl_attr._map(blk), mdl_game._tsRect(t, 0, blk.size));
    };


    function ex_getProdRateComp(blk, rsTg) {
      if(rsTg == null) return 0.1;

      var prodRate;
      if(rsTg instanceof Item) prodRate = mdl_data.read_1n1v(db_block.db["param"]["speed"]["base"], blk.name, 2) / blk.craftTime * 60.0;
      if(rsTg instanceof Liquid) prodRate = mdl_data.read_1n1v(db_block.db["param"]["speed"]["base"], blk.name, 15.0) / 60.0;

      prodRate *= mdl_data.read_2n1v(db_block.db["map"]["rsMtp"], blk.name, rsTg.name, 1.0);

      return prodRate;
    };
  // End


/*
  ========================================
  Section: Application
  ========================================
*/


  // Part: Integration
    const setStats = function(blk) {
      PARENT.setStats(blk);

      setStatsComp(blk);
    };
    exports.setStats = setStats;


    const updateTile = function(b) {
      PARENT.updateTile(b);

      updateTileComp(b);
    };
    exports.updateTile = updateTile;


    const sumAttribute = function(blk, attribute, tx, ty) {
      return sumAttributeComp(blk, attribute, tx, ty);
    };
    exports.sumAttribute = sumAttribute;


    const canPlaceOn = function(t, team, rot) {
      return true;
    };
    exports.canPlaceOn = canPlaceOn;


    const shouldConsume = function(b) {
      return shouldConsumeComp(b);
    };
    exports.shouldConsume = shouldConsume;


    const drawSelect = function(b) {
      drawSelectComp(b);
    };
    exports.drawSelect = drawSelect;


    const ex_getAttrPair = function(blk, t) {
      return ex_getAttrPairComp(blk, t);
    };
    exports.ex_getAttrPair = ex_getAttrPair;


    const ex_getProdRate = function(blk, rsTg) {
      return ex_getProdRateComp(blk, rsTg);
    };
    exports.ex_getProdRate = ex_getProdRate;
  // End


Events.run(ClientLoadEvent, () => {
  Log.info("REIND: blk_dynamicAttributeFactory.js loaded.");
});
