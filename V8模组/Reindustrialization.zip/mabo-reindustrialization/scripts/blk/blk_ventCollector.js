/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Import
    const PARENT = require("reind/blk/blk_genericLiquidBlock");
    const PARENT_A = require("reind/blk/blk_dynamicAttributeFactory");
    const PARENT_B = require("reind/blk/blk_gasCylinder");

    const frag_attack = require("reind/frag/frag_attack");

    const mdl_data = require("reind/mdl/mdl_data");

    const db_block = require("reind/db/db_block");
    const db_stat = require("reind/db/db_stat");
  // End


  // Part: Component
    function setStatsComp(blk) {
      var pumpSpeed = mdl_data.read_1n1v(db_block.db["param"]["speed"]["base"], blk.name, 0.0);
      blk.stats.add(db_stat.standardPumpSpeed, pumpSpeed, StatUnit.liquidSecond);

      blk.stats.add(db_stat.canExplode, true);
      blk.stats.add(db_stat.explosionRadius, frag_attack._gasExploRad(blk.size) / Vars.tilesize, StatUnit.blocks);
    };


    function initComp(blk) {
      blk.outputsLiquid = true;
    };


    function canPlaceOnComp(blk, t, team, rot) {
      var pair = blk.ex_getAttrPair(t);
      return (pair == null) ? false : (pair[1] > blk.minEfficiency);
    };
  // End


/*
  ========================================
  Section: Application
  ========================================
*/


  // Part: Integration
    const setStats = function(blk) {
      PARENT.setStats(blk);
      PARENT_A.setStats(blk);

      setStatsComp(blk);
    };
    exports.setStats = setStats;


    const updateTile = function(b) {
      PARENT.updateTile(b);
      PARENT_A.updateTile(b);
    };
    exports.updateTile = updateTile;


    const init = function(blk) {
      initComp(blk);
    };
    exports.init = init;


    const sumAttribute = function(blk, attribute, tx, ty) {
      return PARENT_A.sumAttribute(blk, attribute, tx, ty);
    };
    exports.sumAttribute = sumAttribute;


    const canPlaceOn = function(blk, t, team, rot) {
      return canPlaceOnComp(blk, t, team, rot);
    };
    exports.canPlaceOn = canPlaceOn;


    const shouldConsume = function(b) {
      return PARENT_A.shouldConsume(b);
    };
    exports.shouldConsume = shouldConsume;


    const drawPlace = function(blk, tx, ty, rot, valid) {
      PARENT_B.drawPlace(blk, tx, ty, rot, valid);
    };
    exports.drawPlace = drawPlace;


    const draw = function(b) {
      PARENT.draw(b);
    };
    exports.draw = draw;


    const drawSelect = function(b) {
      PARENT.drawSelect(b);
      PARENT_A.drawSelect(b);
      PARENT_B.drawSelect(b);
    };
    exports.drawSelect = drawSelect;


    const onDestroyed = function(b) {
      PARENT_B.onDestroyed(b);
    };
    exports.onDestroyed = onDestroyed;


    const ex_getAttrPair = function(blk, t) {
      return PARENT_A.ex_getAttrPair(blk, t);
    };
    exports.ex_getAttrPair = ex_getAttrPair;


    const ex_getProdRate = function(blk, rsTg) {
      return PARENT_A.ex_getProdRate(blk, rsTg);
    };
    exports.ex_getProdRate = ex_getProdRate;
  // End


Events.run(ClientLoadEvent, () => {
  Log.info("REIND: blk_ventCollector.js loaded.");
});
