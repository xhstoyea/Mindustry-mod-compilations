/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Import
    const PARENT = require("reind/blk/blk_drill");

    const frag_faci = require("reind/frag/frag_faci");

    const mdl_content = require("reind/mdl/mdl_content");
    const mdl_table = require("reind/mdl/mdl_table");
    const mdl_text = require("reind/mdl/mdl_text");
  // End


  // Part: Auxilliary
    function ax_buildStats() {
      return function(tb) {
        var matArr = [[Core.bundle.get("stat.reind-stat-required-terrain.name"), mdl_text._term("icon"), mdl_text._term("output")]];
        var arr = [
          "river", "reind-item-ore-sand-river",
          "beach", "reind-item-ore-sand-sea",
        ];

        var cap = arr.length;
        for(let i = 0; i < cap; i += 2) {
          var rs = mdl_content._ct_gn(arr[i + 1]);
          if(rs == null) continue;

          matArr.push([frag_faci._terrainVal(arr[i]), rs, rs.localizedName]);
        };

        tb.row();
        tb.table(Styles.none, tb1 => {
          mdl_table.setTableDisplay(tb1, matArr, [240.0, 60.0, 360.0], null, Color.darkGray, 2.0, Color.darkGray, 32.0);
        }).row();
      };
    };
  // End


  // Part: Component
    function setStatsComp(blk) {
      blk.stats.add(Stat.output, ax_buildStats());
    };


    function canMineComp(blk, t) {
      if(t == null) return false;

      var itm = blk.getDrop(t);
      if(itm == null) return false;

      return itm.name.includes("reind-item-ore-sand") && (blk.tier > itm.hardness - 0.0001);
    };


    function getDropComp(blk, t) {
      var itm = t.drop();
      if((itm != null && itm.name == "reind-item-ore-sand") || (itm == null && t.floor().liquidDrop != null && t.floor().liquidDrop.name.includes("water"))) {
        var ter = frag_faci._terrain(t, blk.size);
        if(ter == "river") return Vars.content.item("reind-item-ore-sand-river");
        if(ter == "beach") return Vars.content.item("reind-item-ore-sand-sea");
      };

      return itm;
    };


    function drawPlaceComp(blk, tx, ty, rot, valid) {
      frag_faci.drawPlace_terrain(blk, tx, ty, rot, valid, 1);
    };
  // End


/*
  ========================================
  Section: Application
  ========================================
*/


  // Part: Integration
    const setStats = function(blk) {
      PARENT.setStats(blk);

      setStatsComp(blk);
    };
    exports.setStats = setStats;


    const updateTile = function(b) {
      PARENT.updateTile(b);
    };
    exports.updateTile = updateTile;


    const canMine = function(blk, t) {
      if(!PARENT.canMine(blk, t)) return false;
      if(!canMineComp(blk, t)) return false;

      return true;
    };
    exports.canMine = canMine;


    const getDrop = function(blk, t) {
      return getDropComp(blk, t);
    };
    exports.getDrop = getDrop;


    const drawPlace = function(blk, tx, ty, rot, valid) {
      drawPlaceComp(blk, tx, ty, rot, valid);
    };
    exports.drawPlace = drawPlace;
  // End


Events.run(ClientLoadEvent, () => {
  Log.info("REIND: blk_drill.js loaded.");
});
