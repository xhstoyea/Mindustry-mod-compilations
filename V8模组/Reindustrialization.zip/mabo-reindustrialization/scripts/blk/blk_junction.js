/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Import
    const PARENT = require("reind/blk/blk_genericDistributionGate");
    const VAR = require("reind/glb/glb_vars");

    const frag_item = require("reind/frag/frag_item");

    const mdl_data = require("reind/mdl/mdl_data");
    const mdl_draw = require("reind/mdl/mdl_draw");

    const db_block = require("reind/db/db_block");
  // End


  // Part: Component
    function setStatsComp(blk) {
      blk.stats.remove(Stat.maxConsecutive);
      blk.stats.add(Stat.maxConsecutive, VAR.transfer_junctionMaxConsecutive);

      var speed = mdl_data.read_1n1v(db_block.db["param"]["speed"]["base"], blk.name, 6.0);
      blk.stats.add(Stat.speed, speed, StatUnit.itemsSecond);
    };


    function updateTileComp(b) {
      if(b.needCheck) {
        b.thr = mdl_data.read_1n1v(db_block.db["param"]["time"]["base"], b.block.name, 60.0);

        b.needCheck = false;
      };

      if(b.timerCall.get(0, b.thr)) b.isReady1 = true;
      if(b.timerCall.get(1, b.thr)) b.isReady2 = true;
    };


    function acceptItemComp(b, ob, itm) {
      var transEnd = b.getTileTarget(itm, ob, true);
      if(transEnd != null) {
        var b_f = transEnd.nearby(transEnd.relativeTo(b));
        if(b_f != null && transEnd.acceptItem(b_f, itm)) return true;
      };

      return false;
    };


    function handleItemComp(b, ob, itm) {
      var transEnd = b.getTileTarget(itm, ob, true);
      if(transEnd != null) {
        var rot_f = transEnd.relativeTo(b);
        transEnd.handleItem(transEnd.nearby(rot_f), itm);
        if(rot_f % 2 == 0) {
          b.isReady1 = false;
        } else {
          b.isReady2 = false;
        };
      };
    };


    function getTileTargetComp(b, itm, ob, isFlip) {
      var rot_f = ob.relativeTo(b);
      if(rot_f % 2 == 0) {
        if(!b.isReady1) return;
      } else {
        if(!b.isReady2) return;
      };
      return frag_item._transEnd(b, b.nearby(rot_f));
    };
  // End


/*
  ========================================
  Section: Application
  ========================================
*/


  // Part: Integration
    const setStats = function(blk) {
      PARENT.setStats(blk);

      setStatsComp(blk);
    };
    exports.setStats = setStats;


    const updateTile = function(b) {
      PARENT.updateTile(b);

      updateTileComp(b);
    };
    exports.updateTile = updateTile;


    const acceptItem = function(b, ob, itm) {
      return acceptItemComp(b, ob, itm);
    };
    exports.acceptItem = acceptItem;


    const handleItem = function(b, ob, itm) {
      handleItemComp(b, ob, itm);
    };
    exports.handleItem = handleItem;


    const getTileTarget = function(b, itm, ob, isFlip) {
      return getTileTargetComp(b, itm, ob, isFlip);
    };
    exports.getTileTarget = getTileTarget;
  // End


Events.run(ClientLoadEvent, () => {
  Log.info("REIND: blk_junction.js loaded.");
});
