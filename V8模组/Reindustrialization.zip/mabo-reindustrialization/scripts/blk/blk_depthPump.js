/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Import
    const PARENT = require("reind/blk/blk_genericLiquidBlock");
    const PARENT_A = require("reind/blk/blk_dynamicAttributeFactory");

    const mdl_attr = require("reind/mdl/mdl_attr");
    const mdl_content = require("reind/mdl/mdl_content");
    const mdl_data = require("reind/mdl/mdl_data");
    const mdl_draw = require("reind/mdl/mdl_draw");
    const mdl_game = require("reind/mdl/mdl_game");
    const mdl_text = require("reind/mdl/mdl_text");

    const db_block = require("reind/db/db_block");
    const db_stat = require("reind/db/db_stat");
  // End


  // Part: Setting
    var efficiencyInterval = 90.0;
    const set_efficiencyInterval = function(val) {
      efficiencyInterval = val;
    };
    exports.set_efficiencyInterval = set_efficiencyInterval;
  // End


  // Part: Component
    function setStatsComp(blk) {
      var pumpSpeed = mdl_data.read_1n1v(db_block.db["param"]["speed"]["base"], blk.name, 0.0);
      blk.stats.add(db_stat.standardPumpSpeed, pumpSpeed, StatUnit.liquidSecond);
    };


    function updateTileComp(b) {
      if(b.timerEffc1.get(efficiencyInterval)) {
        var down = false;
        var b_sc_fi = null;

        var b_sc = mdl_game._oreScanner(b, 9999.0, b.team);

        if(b_sc == null) {
          down = true;
        } else {
          down = false;
          b_sc_fi = b_sc;
        };

        b.down = down;
        b.b_sc = b_sc_fi;
      };
    };


    function initComp(blk) {
      blk.outputsLiquid = true;
    };


    function canPlaceOnComp(blk, t, team, rot) {
      var pair = blk.ex_getAttrPair(t);
      return (pair == null) ? false : (pair[1] > blk.minEfficiency);
    };


    function shouldConsumeComp(b) {
      return !b.down;
    };


    function drawSelectComp(b) {
      if(b.b_sc == null) {
        mdl_draw.drawSelectText(b, false, mdl_text._info("no-ore-scanner"));
      } else {
        mdl_draw.drawBuildAreaConnector(b, b.b_sc);
      };
    };


    function ex_getAttrPairComp(blk, t) {
      return mdl_attr._attrPair(mdl_attr._map(blk), mdl_game._tsRect(t, 0, blk.size), "overlay");
    };
  // End


/*
  ========================================
  Section: Application
  ========================================
*/


  // Part: Integration
    const setStats = function(blk) {
      PARENT.setStats(blk);
      PARENT_A.setStats(blk);

      setStatsComp(blk);
    };
    exports.setStats = setStats;


    const updateTile = function(b) {
      PARENT.updateTile(b);
      PARENT_A.updateTile(b);

      updateTileComp(b);
    };
    exports.updateTile = updateTile;


    const init = function(blk) {
      initComp(blk);
    };
    exports.init = init;


    const sumAttribute = function(blk, attribute, tx, ty) {
      return PARENT_A.sumAttribute(blk, attribute, tx, ty);
    };
    exports.sumAttribute = sumAttribute;


    const canPlaceOn = function(blk, t, team, rot) {
      return canPlaceOnComp(blk, t, team, rot);
    };
    exports.canPlaceOn = canPlaceOn;


    const shouldConsume = function(b) {
      if(!PARENT_A.shouldConsume(b)) return false;
      if(!shouldConsumeComp(b)) return false;

      return true;
    };
    exports.shouldConsume = shouldConsume;


    const draw = function(b) {
      PARENT.draw(b);
    };
    exports.draw = draw;


    const drawSelect = function(b) {
      PARENT.drawSelect(b);
      PARENT_A.drawSelect(b);

      drawSelectComp(b);
    };
    exports.drawSelect = drawSelect;


    const ex_getAttrPair = function(blk, t) {
      return ex_getAttrPairComp(blk, t);
    };
    exports.ex_getAttrPair = ex_getAttrPair;


    const ex_getProdRate = function(blk, rsTg) {
      return PARENT_A.ex_getProdRate(blk, rsTg);
    };
    exports.ex_getProdRate = ex_getProdRate;
  // End


Events.run(ClientLoadEvent, () => {
  Log.info("REIND: blk_ventCollector.js loaded.");
});
