const db = {




  "type": {


    "quicksand": [
      "reind-env-liq-quicksand",
      "reind-env-liq-quicksand-dark",
    ],


    "parasiteFluid": [
      "reind-env-liq-carnage-plasma",
      "reind-env-liq-carnage-plasma-shallow",
    ],


  },




  "planet": {


    "type": {


      "carnage": [

        "reind-pla-ter-aerth",
        "reind-pla-ter-kanbos",

      ],


      "tide": [

        "reind-pla-ter-aerth",

      ],


    },


  },




};
exports.db = db;
