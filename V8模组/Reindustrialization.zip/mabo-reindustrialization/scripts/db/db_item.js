const db = {




  "map": {


    "hardness": [

      /* <---------------- item-ore ----------------> */

      "reind-item-ore-asbestos", 3,
      "reind-item-ore-clay", 0,
      "reind-item-ore-crude-borax", 2,
      "reind-item-ore-dolomite", 4,
      "reind-item-ore-gypsum", 2,
      "reind-item-ore-limestone", 2,
      "reind-item-ore-olivine", 7,
      "reind-item-ore-pumice", 2,
      "reind-item-ore-salt", 1,
      "reind-item-ore-sand", 0,
      "reind-item-ore-sand-river", 0,
      "reind-item-ore-sand-sea", 0,
      "reind-item-ore-sand-basaltic", 2,
      "reind-item-ore-sandstone", 4,
      "reind-item-ore-talcum", 1,
      "reind-item-ore-trona", 3,

      /* rock */

      "reind-item-ore-rock-shard-clastic", 2,
      "reind-item-ore-rock-shard-evaporite", 2,
      "reind-item-ore-rock-shard-hypabyssal", 6,
      "reind-item-ore-rock-shard-lava", 6,
      "reind-item-ore-rock-shard-metamorphic", 4,
      "reind-item-ore-rock-shard-plutonic", 6,
      "reind-item-ore-rock-shard-biological-sedimentary", 4,
      "reind-item-ore-rock-shard-clastic-sedimentary", 1,

      /* aluminum */

      "reind-item-ore-bauxite", 3,

      /* barium */

      "reind-item-ore-barite", 3,

      /* carbon */

      "reind-item-ore-lignite", 1,
      "reind-item-ore-peat", 1,
      "reind-item-ore-raw-coal", 2,
      "reind-item-ore-crude-graphite", 2,

      /* chromium */

      "reind-item-ore-chromite", 6,

      /* cobalt */

      "reind-item-ore-linnaeite", 5,

      /* copper */

      "reind-item-ore-azurite", 4,
      "reind-item-ore-chalcopyrite", 4,
      "reind-item-ore-cuprite", 4,
      "reind-item-ore-malachite", 4,
      "reind-item-ore-native-copper", 3,

      /* fluorine */

      "reind-item-ore-fluorite", 4,

      /* iron */

      "reind-item-ore-hematite", 6,
      "reind-item-ore-limonite", 4,
      "reind-item-ore-magnetite", 6,
      "reind-item-ore-pyrite", 6,

      /* lead */

      "reind-item-ore-anglesite", 3,
      "reind-item-ore-galena", 3,

      /* manganese */

      "reind-item-ore-psilomelane", 5,
      "reind-item-ore-pyrolusite", 1,

      /* mercury */

      "reind-item-ore-cinnabar", 2,

      /* phosphorus */

      "reind-item-ore-fluorapatite", 5,

      /* silicon */

      "reind-item-ore-silica-stone", 4,

      /* sulfur */

      "reind-item-ore-crude-sulfur", 2,

      /* tin */

      "reind-item-ore-cassiterite", 6,
      "reind-item-ore-stannite", 4,

      /* titanium */

      "reind-item-ore-ilmenite", 6,
      "reind-item-ore-rutile", 6,

      /* zinc */

      "reind-item-ore-smithsonite", 4,
      "reind-item-ore-sphalerite", 4,

      /* zirconium */

      "reind-item-ore-zircon", 8,

    ],


    "sinteringTemp": [

      /* aluminum */

      "reind-item-ore-bauxite", 1850.0,

      /* chromium */

      "reind-item-ore-chromite", 2350.0,

      /* cobalt */

      "reind-item-ore-linnaeite", 1100.0,

      /* copper */

      "reind-item-ore-azurite", 160.0,
      "reind-item-ore-chalcopyrite", 750.0,
      "reind-item-ore-cuprite", 1150.0,
      "reind-item-ore-malachite", 160.0,
      "reind-item-ore-native-copper", 950.0,

      /* fluorine */

      "reind-item-ore-fluorite", 1300.0,

      /* iron */

      "reind-item-ore-hematite", 1450.0,
      "reind-item-ore-limonite", 1100.0,
      "reind-item-ore-magnetite", 1520.0,
      "reind-item-ore-pyrite", 1050.0,

      /* lead */

      "reind-item-ore-anglesite", 900.0,
      "reind-item-ore-galena", 1050.0,

      /* manganese */

      "reind-item-ore-psilomelane", 1600.0,
      "reind-item-ore-pyrolusite", 500.0,

      /* mercury */

      "reind-item-ore-cinnabar", 520.0,

      /* tin */

      "reind-item-ore-cassiterite", 1550.0,
      "reind-item-ore-stannite", 540.0,

      /* titanium */

      "reind-item-ore-ilmenite", 1400.0,
      "reind-item-ore-rutile", 1750.0,

      /* zinc */

      "reind-item-ore-smithsonite", 600.0,
      "reind-item-ore-sphalerite", 370.0,

    ],


    "consumable": [

      /* <---------------- ball mill ----------------> */

      "reind-item-cons-ball-steel", "ball-mill",

      /* <---------------- electrolyzer ----------------> */

      "reind-item-cons-electrode-copper", "electrolyzer",
      "reind-item-cons-electrode-lead", "electrolyzer",

      /* <---------------- electric arc furnace ----------------> */

      "reind-item-cons-electrode-graphite", "electric-arc-furnace",

      /* <---------------- packed tower ----------------> */

      "reind-item-cons-pall-ring-steel", "packed-tower",
      "reind-item-cons-pall-ring-stainless-steel", "packed-tower",

    ],


    "rock": [
      "reind-attr-rock-clastic", "reind-item-ore-rock-shard-clastic",
      "reind-attr-rock-evaporite", "reind-item-ore-rock-shard-evaporite",
      "reind-attr-rock-hypabyssal", "reind-item-ore-rock-shard-hypabyssal",
      "reind-attr-rock-lava", "reind-item-ore-rock-shard-lava",
      "reind-attr-rock-metamorphic", "reind-item-ore-rock-shard-metamorphic",

      "reind-attr-rock-plutonic", "reind-item-ore-rock-shard-plutonic",
      "reind-attr-rock-biological-sedimentary", "reind-item-ore-rock-shard-biological-sedimentary",
      "reind-attr-rock-clastic-sedimentary", "reind-item-ore-rock-shard-clastic-sedimentary",
    ],


    "bush": [],


    "formula": [

      /* <---------------- item-ore ----------------> */

      "reind-item-ore-gypsum", "CaSO4·2H2O",
      "reind-item-ore-trona", "Na2CO3",

      /* barium */

      "reind-item-ore-barite", "BaSO4",

      /* chromium */

      "reind-item-ore-chromite", "FeCr2O4",

      /* copper */

      "reind-item-ore-azurite", "Cu3(OH)2(CO3)2",
      "reind-item-ore-chalcopyrite", "CuFeS2",
      "reind-item-ore-cuprite", "Cu2O",
      "reind-item-ore-malachite", "Cu2(OH)2CO3",
      "reind-item-ore-native-copper", "Cu",

      /* fluorine */

      "reind-item-ore-fluorite", "CaF2",

      /* iron */

      "reind-item-ore-hematite", "Fe2O3",
      "reind-item-ore-magnetite", "Fe3O4",
      "reind-item-ore-pyrite", "FeS2",

      /* lead */

      "reind-item-ore-anglesite", "PbSO4",
      "reind-item-ore-galena", "PbS",

      /* manganese */

      "reind-item-ore-pyrolusite", "MnO2",

      /* mercury */

      "reind-item-ore-cinnabar", "HgS",

      /* phosphorus */

      "reind-item-ore-fluorapatite", "Ca5F(PO4)3",
      "reind-item-ore-hydroxyapatite", "Ca5OH(PO4)3",

      /* tin */

      "reind-item-ore-cassiterite", "SnO2",
      "reind-item-ore-stannite", "Cu2FeSnS4",

      /* titanium */

      "reind-item-ore-anatase", "TiO2",
      "reind-item-ore-ilmenite", "FeTiO3",
      "reind-item-ore-rutile", "TiO2",

      /* zinc */

      "reind-item-ore-smithsonite", "ZnCO3",
      "reind-item-ore-sphalerite", "ZnS",

      /* zirconium */

      "reind-item-ore-zircon", "ZrSiO4",

      /* <---------------- item-chem[elementary] ----------------> */

      "reind-item-chem-copper", "Cu",
      "reind-item-chem-lead", "Pb",
      "reind-item-chem-sodium", "Na",
      "reind-item-chem-sulfur", "S",
      "reind-item-chem-tin", "Sn",
      "reind-item-chem-zinc", "Zn",

      /* <---------------- item-chem[inorganic] ----------------> */

      /* boron */

      "reind-item-chem-borax", "Na2[B4O5(OH)4]·8H2O",

      /* calcium */

      "reind-item-chem-lime", "CaO",

      /* potassium */

      "reind-item-chem-potassium-carbonate", "K2CO3",
      "reind-item-chem-potassium-bicarbonate", "KHCO3",
      "reind-item-chem-potassium-chloride", "KCl",
      "reind-item-chem-potassium-hydroxide", "KOH",

      /* silicon */

      "reind-item-chem-silica-sand", "SiO2",
      "reind-item-chem-quartz-sand", "SiO2",
      "reind-item-chem-silica-gel", "H2SiO4",
      "reind-item-chem-sodium-silicate", "Na2SiO3",

      /* sodium */

      "reind-item-chem-sodium-carbonate", "Na2CO3",
      "reind-item-chem-sodium-bicarbonate", "NaHCO3",
      "reind-item-chem-sodium-chloride", "NaCl",
      "reind-item-chem-sodium-hydroxide", "NaOH",

    ],


  },




  "iTag": {


    "acidic": [],


    "basic": [

      /* <---------------- item-chem[inorganic] ----------------> */

      /* potassium */

      "reind-item-chem-potassium-carbonate",
      "reind-item-chem-potassium-bicarbonate",
      "reind-item-chem-potassium-hydroxide",

      /* sodium */

      "reind-item-chem-sodium-carbonate",
      "reind-item-chem-sodium-bicarbonate",
      "reind-item-chem-sodium-hydroxide",

    ],


    "oxidative": [],


    "reductive": [

      /* <---------------- item-chem[elementary] ----------------> */

      "reind-item-chem-sodium",

    ],


    // TODO: Explode when in impact range.
    "unstable": [],


  },




  "virtual": {


    "whitelist": [

      /* <---------------- eff-stor ----------------> */

      "reind-eff-stor-bit-container",

    ],


  },




  "reaction": {


    "map": [

      /* <---------------- item-chem[elementary] ----------------> */

      "reind-item-chem-sodium", "ANY: water", "explosionII",
      "reind-item-chem-sodium", "reind-gas-misc-air", "explosionI",

      /* <---------------- item-chem[inorganic] ----------------> */

      /* calcium */

      "reind-item-chem-lime", "ANY: water", "heating",

      /* potassium */

      "reind-item-chem-potassium-hydroxide", "reind-gas-misc-air", "denaturing",

      /* sodium */

      "reind-item-chem-sodium-hydroxide", "reind-gas-misc-air", "denaturing",

    ],


    "denaturing": [

      /* <---------------- item-chem[inorganic] ----------------> */

      "reind-item-chem-potassium-hydroxide", "reind-item-chem-potassium-carbonate",

      "reind-item-chem-sodium-hydroxide", "reind-item-chem-sodium-carbonate",

    ],


  },




};
exports.db = db;
