/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Import
    const mdl_content = require("reind/mdl/mdl_content");
    const mdl_data = require("reind/mdl/mdl_data");
    const mdl_text = require("reind/mdl/mdl_text");

    const db_item = require("reind/db/db_item");
  // End


  // Part: Parser
    const _blk = function(rcFi) {
      if(rcFi == null) return;

      return mdl_content._ct_gn(rcFi.rc["parent"]);
    };
    exports._blk = _blk;


    const _rc = function(rcFi, id_rc) {
      if(rcFi == null || id_rc == null) return;

      var rcLi = rcFi.rc["recipes"];
      if(id_rc >= rcLi.length) return;

      return rcLi[id_rc];
    };
    exports._rc = _rc;


    const _rcSize = function(rcFi) {
      if(rcFi == null) return;

      return rcFi.rc["recipes"].length;
    };
    exports._rcSize = _rcSize;


    const _rcVal = function(rcFi, id_rc, str_val) {
      var rc = _rc(rcFi, id_rc);
      return rc[str_val];
    };
    exports._rcVal = _rcVal;


    const _iconNm = function(rcFi, id_rc) {
      return _rcVal(rcFi, id_rc, "icon");
    };
    exports._iconNm = _iconNm;


    const _icon = function(rcFi, id_rc) {
      var ct = mdl_content._ct_nm(_iconNm(rcFi, id_rc));
      return (ct == null) ? null : new TextureRegionDrawable(ct.uiIcon);
    };
    exports._icon = _icon;


    const _cat = function(rcFi, id_rc) {
      return _rcVal(rcFi, id_rc, "category");
    };
    exports._cat = _cat;


    const _catVal = function(rcFi, id_rc) {
      var cat = _cat(rcFi, id_rc);
      return (Vars.headless || cat == null) ? "UNDEFINED" : mdl_text._term(cat);
    };
    exports._catVal = _catVal;


    const _isGen = function(rcFi, id_rc) {
      var bool = _rcVal(rcFi, id_rc, "generated");
      return (bool == null) ? false : bool;
    };
    exports._isGen = _isGen;


    const _inputs = function(rcFi, id_rc) {
      var inputs = _rcVal(rcFi, id_rc, "inputs");
      return (inputs == null) ? [] : inputs;
    };
    exports._inputs = _inputs;


    const _outputs = function(rcFi, id_rc) {
      var outputs = _rcVal(rcFi, id_rc, "outputs");
      return (outputs == null) ? [] : outputs;
    };
    exports._outputs = _outputs;


    const _randInputs = function(rcFi, id_rc) {
      var inputs = _rcVal(rcFi, id_rc, "randInputs");
      return (inputs == null) ? [] : inputs;
    };
    exports._randInputs = _randInputs;


    const _randOutputs = function(rcFi, id_rc) {
      var outputs = _rcVal(rcFi, id_rc, "randOutputs");
      return (outputs == null) ? [] : outputs;
    };
    exports._randOutputs = _randOutputs;


    const _bfInputs = function(rcFi, id_rc) {
      var bfInputs = _rcVal(rcFi, id_rc, "bfInputs");
      return (bfInputs == null) ? [] : bfInputs;
    };
    exports._bfInputs = _bfInputs;


    const _bfOutputs = function(rcFi, id_rc) {
      var bfOutputs = _rcVal(rcFi, id_rc, "bfOutputs");
      return (bfOutputs == null) ? [] : bfOutputs;
    };
    exports._bfOutputs = _bfOutputs;


    const _reqOpt = function(rcFi, id_rc) {
      var reqOpt = _rcVal(rcFi, id_rc, "requireOptional");
      return (reqOpt == null) ? false : reqOpt;
    };
    exports._reqOpt = _reqOpt;


    const _optInputs = function(rcFi, id_rc) {
      var optInputs = _rcVal(rcFi, id_rc, "optInputs");
      return (optInputs == null) ? [] : optInputs;
    };
    exports._optInputs = _optInputs;


    const _failP = function(rcFi, id_rc) {
      var p = _rcVal(rcFi, id_rc, "failProbability");
      return (p == null) ? 0.0 : p;
    };
    exports._failP = _failP;


    const _failOutputs = function(rcFi, id_rc) {
      var outputs = _rcVal(rcFi, id_rc, "failOutputs");
      return (outputs == null) ? [] : outputs;
    };
    exports._failOutputs = _failOutputs;


    const _rawTooltip = function(rcFi, id_rc) {
      return _rcVal(rcFi, id_rc, "tooltip");
    };
    exports._rawTooltip = _rawTooltip;


    const _tooltip = function(rcFi, id_rc) {
      if(Vars.headless) return "";

      var str_cat = _catVal(rcFi, id_rc);

      var ct = mdl_content._ct_nm(_iconNm(rcFi, id_rc));
      var str_ct = (ct == null) ? "-" : ct.localizedName;

      var failP = _failP(rcFi, id_rc);
      var str_fail = (failP > 0.0001) ? mdl_text._statText(mdl_text._term("chance-to-fail"), Strings.fixed(failP * 100.0, 1) + "%") : null;

      var isGen = _isGen(rcFi, id_rc);
      var str_isGen = isGen ? mdl_text._info("generated-recipe") : null;

      var tt = _rawTooltip(rcFi, id_rc);
      var str_tt = (tt == null) ? null : mdl_text._info("tt-" + tt);

      var str_fi =  "[accent]<" + str_cat + " [" + Strings.fixed(id_rc + 1.0, 0) + "]" + ">[]\n" + str_ct +
      ((str_isGen == null) ? "" : ("\n\n" + str_isGen)) +
      ((str_fail == null) ? "" : ("\n\n" + str_fail)) +
      ((str_tt == null) ? "" : ("\n\n[gray]" + str_tt + "[]"));
      return str_fi;
    };
    exports._tooltip = _tooltip;


    const _timeScale = function(rcFi, id_rc) {
      var scl = _rcVal(rcFi, id_rc, "timeScale");
      return (scl == null) ? 1.0 : scl;
    };
    exports._timeScale = _timeScale;


    const _script = function(rcFi, id_rc) {
      var scr = _rcVal(rcFi, id_rc, "script");
      return (scr == null) ? function() {} : scr;
    };
    exports._script = _script;


    const _updateScript = function(rcFi, id_rc) {
      var scr = _rcVal(rcFi, id_rc, "updateScript");
      return (scr == null) ? function() {} : scr;
    };
    exports._updateScript = _updateScript;


    const _craftScript = function(rcFi, id_rc) {
      var scr = _rcVal(rcFi, id_rc, "craftScript");
      return (scr == null) ? function() {} : scr;
    };
    exports._craftScript = _craftScript;
  // End


  // Part: Generated Recipe
    const arr_rock = [
      "reind-item-ore-rock-shard-clastic",
      "reind-item-ore-rock-shard-evaporite",
      "reind-item-ore-rock-shard-hypabyssal",
      "reind-item-ore-rock-shard-lava",
      "reind-item-ore-rock-shard-metamorphic",
      "reind-item-ore-rock-shard-plutonic",
      "reind-item-ore-rock-shard-biological-sedimentary",
      "reind-item-ore-rock-shard-clastic-sedimentary",
    ];


    const arr_oreChunks = [

      "reind-item-ore-dolomite",
      "reind-item-ore-gypsum",
      "reind-item-ore-limestone",

      /* barium */

      "reind-item-ore-barite",

      /* phosphorus */

      "reind-item-ore-fluorapatite",

      /* silicon */

      "reind-item-ore-silica-stone",

      /* sulfur */

      "reind-item-ore-crude-sulfur",

      /* zirconium */

      "reind-item-ore-zircon",

    ];


    const arr_oreDust = [

      /* aluminum */

      "reind-item-ore-bauxite",

      /* chromium */

      "reind-item-ore-chromite",

      /* cobalt */

      "reind-item-ore-linnaeite",

      /* copper */

      "reind-item-ore-azurite",
      "reind-item-ore-chalcopyrite",
      "reind-item-ore-cuprite",
      "reind-item-ore-malachite",
      "reind-item-ore-native-copper",

      /* fluorine */

      "reind-item-ore-fluorite",

      /* iron */

      "reind-item-ore-hematite",
      "reind-item-ore-limonite",
      "reind-item-ore-magnetite",
      "reind-item-ore-pyrite",

      /* lead */

      "reind-item-ore-anglesite",
      "reind-item-ore-galena",

      /* manganese */

      "reind-item-ore-psilomelane",
      "reind-item-ore-pyrolusite",

      /* mercury */

      "reind-item-ore-cinnabar",

      /* tin */

      "reind-item-ore-cassiterite",
      "reind-item-ore-stannite",

      /* titanium */

      "reind-item-ore-ilmenite",
      "reind-item-ore-rutile",

      /* zinc */

      "reind-item-ore-smithsonite",
      "reind-item-ore-sphalerite",

    ];


    const __rockCrusher_oreChunks = function(rc, amtI, amtO, gi, go, maxHardness, timeScale) {
      if(gi == null) gi = [];
      if(go == null) go = [];
      if(timeScale == null) timeScale = 1.0;

      var rcLi = rc["recipes"];
      var cap = arr_oreChunks.length;
      for(let i = 0; i < cap; i++) {
        var itmOre = mdl_content._ct_gn(arr_oreChunks[i], true);
        var itmChunks = mdl_content._ct_gn(mdl_text.convert_oreItm(arr_oreChunks[i], "chunks"), true);
        if(itmOre == null || itmChunks == null) continue;
        if(maxHardness != null) {
          var hardness = mdl_data.read_1n1v(db_item.db["map"]["hardness"], itmOre.name, 0);
          if(hardness > maxHardness) continue;
        };

        var rcObj = {
          "icon": itmOre.name,
          "category": "crushing",
          "generated": true,
          "inputs": [
            itmOre.name, amtI,
          ].concat(gi),
          "outputs": [
            itmChunks.name, amtO,
          ].concat(go),
          "timeScale": timeScale,
        };

        rcLi.push(rcObj);
      };
    };
    exports.__rockCrusher_oreChunks = __rockCrusher_oreChunks;


    const __pulverizer_rock = function(rc, amtI, amtO, gi, go, maxHardness, timeScale) {
      if(gi == null) gi = [];
      if(go == null) go = [];
      if(timeScale == null) timeScale = 1.0;

      var rcLi = rc["recipes"];
      var cap = arr_rock.length;
      for(let i = 0; i < cap; i++) {
        var itmOre = mdl_content._ct_gn(arr_rock[i], true);
        var itmDust = mdl_content._ct_gn(mdl_text.convert_oreItm(arr_rock[i], "dust", true), true);
        if(itmOre == null || itmDust == null) continue;
        if(maxHardness != null) {
          var hardness = mdl_data.read_1n1v(db_item.db["map"]["hardness"], itmOre.name, 0);
          if(hardness > maxHardness) continue;
        };

        var rcObj = {
          "icon": itmOre.name,
          "category": "pulverization",
          "generated": true,
          "inputs": [
            itmOre.name, amtI,
          ].concat(gi),
          "outputs": [
            itmDust.name, amtO,
          ].concat(go),
          "timeScale": timeScale,
        };

        rcLi.push(rcObj);
      };
    };
    exports.__pulverizer_rock = __pulverizer_rock;


    const __pulverizer_oreDust = function(rc, amtI, amtO, gi, go, maxHardness, timeScale) {
      if(gi == null) gi = [];
      if(go == null) go = [];
      if(timeScale == null) timeScale = 1.0;

      var rcLi = rc["recipes"];
      var cap = arr_oreDust.length;
      for(let i = 0; i < cap; i++) {
        var itmOre = mdl_content._ct_gn(arr_oreDust[i], true);
        var itmDust = mdl_content._ct_gn(mdl_text.convert_oreItm(arr_oreDust[i], "dust"), true);
        if(itmOre == null || itmDust == null) continue;
        if(maxHardness != null) {
          var hardness = mdl_data.read_1n1v(db_item.db["map"]["hardness"], itmOre.name, 0);
          if(hardness > maxHardness) continue;
        };

        var rcObj = {
          "icon": itmOre.name,
          "category": "pulverization",
          "generated": true,
          "inputs": [
            itmOre.name, amtI,
          ].concat(gi),
          "outputs": [
            itmDust.name, amtO,
          ].concat(go),
          "timeScale": timeScale,
        };

        rcLi.push(rcObj);
      };
    };
    exports.__pulverizer_oreDust = __pulverizer_oreDust;


    const __sinteringFurnace_oreDust = function(rc, amtI, amtO, gi, go, maxSinteringTemp, timeScale) {
      if(gi == null) gi = [];
      if(go == null) go = [];
      if(timeScale == null) timeScale = 1.0;

      var rcLi = rc["recipes"];
      var cap = arr_oreDust.length;
      for(let i = 0; i < cap; i++) {
        var itmOre = mdl_content._ct_gn(arr_oreDust[i], true);
        var itmDust = mdl_content._ct_gn(mdl_text.convert_oreItm(arr_oreDust[i], "dust"), true);
        if(itmOre == null || itmDust == null) continue;
        if(maxSinteringTemp != null) {
          var sinteringTemp = mdl_data.read_1n1v(db_item.db["map"]["sinteringTemp"], itmOre.name, 300.0);
          if(sinteringTemp > maxSinteringTemp) continue;
        };

        var rcObj = {
          "icon": itmDust.name,
          "category": "sintering",
          "generated": true,
          "inputs": [
            itmDust.name, amtI,
          ].concat(gi),
          "outputs": [
            itmOre.name, amtO,
          ].concat(go),
          "timeScale": timeScale,
        };

        rcLi.push(rcObj);
      };
    };
    exports.__sinteringFurnace_oreDust = __sinteringFurnace_oreDust;


    const __sinteringFurnace_oreDustP1 = function(rc, amtI, amtO, gi, go, maxSinteringTemp, timeScale) {
      if(gi == null) gi = [];
      if(go == null) go = [];
      if(timeScale == null) timeScale = 1.0;

      var rcLi = rc["recipes"];
      var cap = arr_oreDust.length;
      for(let i = 0; i < cap; i++) {
        var itmOre = mdl_content._ct_gn(arr_oreDust[i], true);
        var itmDustP1 = mdl_content._ct_gn(mdl_text.convert_oreItm(arr_oreDust[i], "p1-dust"), true);
        var itmConcentrate = mdl_content._ct_gn(mdl_text.convert_oreItm(arr_oreDust[i], "concentrate"), true);
        if(itmOre == null || itmDustP1 == null || itmConcentrate == null) continue;
        if(maxSinteringTemp != null) {
          var sinteringTemp = mdl_data.read_1n1v(db_item.db["map"]["sinteringTemp"], itmOre.name, 300.0);
          if(sinteringTemp > maxSinteringTemp) continue;
        };

        var rcObj = {
          "icon": itmDustP1.name,
          "category": "concentrate-sintering",
          "generated": true,
          "inputs": [
            itmDustP1.name, amtI,
          ].concat(gi),
          "outputs": [
            itmConcentrate.name, amtO,
          ].concat(go),
          "timeScale": timeScale,
        };

        rcLi.push(rcObj);
      };
    };
    exports.__sinteringFurnace_oreDustP1 = __sinteringFurnace_oreDustP1;
  // End


Events.run(ClientLoadEvent, () => {
  Log.info("REIND: mdl_pollution.js loaded.");
});
