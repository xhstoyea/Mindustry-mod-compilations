/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Param
    const _polLocal = function(t, r) {
      // TODO: Add calculation
    };
    exports._polLocal = _polLocal;
  // End


Events.run(ClientLoadEvent, () => {
  Log.info("REIND: mdl_pollution.js loaded.");
});
