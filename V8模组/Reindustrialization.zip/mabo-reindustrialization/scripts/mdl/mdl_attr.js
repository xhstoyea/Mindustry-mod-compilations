/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Import
    const mdl_data = require("reind/mdl/mdl_data");
    const mdl_game = require("reind/mdl/mdl_game");

    const db_block = require("reind/db/db_block");
    const db_fluid = require("reind/db/db_fluid");
    const db_item = require("reind/db/db_item");
  // End


  // Part: Base
    const _attr = function(attr_gn) {
      var val = null;

      if(typeof attr_gn == "string") val = attr_gn;
      if(attr_gn instanceof Attribute) val = attr_gn.toString();

      return val;
    };
    exports._attr = _attr;
  // End


  // Part: Stat
    /*
     * NOTE:
     *
     * Returns the localized name for attribute, used mainly for stats.
     * Attributes have no translation in vanilla game, since there's no need.
     */
    const _attrVal = function(attr_gn) {
      var nmAttr = _attr(attr_gn);

      return Core.bundle.get("attr." + nmAttr + ".name");
    };
    exports._attrVal = _attrVal;
  // End


  // Part: Block
    const _blkEffcMap = function(attrs_gn) {
      var arr = (attrs_gn instanceof Array) ? attrs_gn : [attrs_gn];
      var map = [];

      arr.forEach(i => {
        var nmAttr = _attr(i);
        Vars.content.blocks().each(blk => {
          var tmpAttr = blk.attributes.get(Attribute.get(nmAttr));
          if(Math.abs(tmpAttr) > 0.0) {
            map.push(blk);
            map.push(tmpAttr);
            map.push(nmAttr);
          };
        });
      });

      return map;
    };
    exports._blkEffcMap = _blkEffcMap;


    const _blkEffcMap_attrMap = function(map) {
      var attrs = [];
      var cap = map.length;
      if(cap == 0) return attrs;
      for(let i = 0; i < cap; i += 2) {
        attrs.push(map[i]);
      };

      return _blkEffcMap(attrs);
    };
    exports._blkEffcMap_attrMap = _blkEffcMap_attrMap;
  // End


  // Part: Sum
    const _sumAttr = function(blk, t, attr_gn) {
      var nmAttr = _attr(attr_gn);

      return blk.sumAttribute(Attribute.get(nmAttr), t.x, t.y);
    };
    exports._sumAttr = _sumAttr;


    const _sumAttr_ts = function(ts, attr_gn, mode) {
      if(mode == null) mode = "floor";
      if(mode != "floor" && mode != "block" && mode != "overlay" && mode != "all") return 0.0;

      var attr = 0.0;
      var nmAttr = _attr(attr_gn);

      ts.forEach(ot => {
        switch(mode) {
          case "floor" :
            attr += ot.floor().attributes.get(Attribute.get(nmAttr));
            break;
          case "block" :
            attr += ot.block().attributes.get(Attribute.get(nmAttr));
            break;
          case "overlay" :
            attr += ot.overlay().attributes.get(Attribute.get(nmAttr));
            break;
          case "all" :
            attr += ot.floor().attributes.get(Attribute.get(nmAttr));
            attr += ot.block().attributes.get(Attribute.get(nmAttr));
            attr += ot.overlay().attributes.get(Attribute.get(nmAttr));
            break;
        };
      });

      return attr;
    };
    exports._sumAttr_ts = _sumAttr_ts;


    const _sumAttr_rect = function(blk, t, attr_gn, r, mode) {
      if(r == null) r = 0;

      var nmAttr = _attr(attr_gn);

      return _sumAttr_ts(mdl_game._tsRect(t, r, blk.size), nmAttr, mode);
    };
    exports._sumAttr_rect = _sumAttr_rect;
  // End


  // Part: Condition
    const _limit = function(blk, avLimit) {
      if(avLimit == null) avLimit = 1.0;

      return Math.pow(blk.size, 2) * avLimit;
    };
    exports._limit = _limit;
  // End


  // Part: Dynamic Attr
    const arr_map = [
      "rock", db_item.db["map"]["rock"],
      "bush", db_item.db["map"]["bush"],
      "vent", db_fluid.db["map"]["vent"],
      "dliq", db_fluid.db["map"]["dliq"],
    ];
    const _map = function(blk) {
      if(blk == null) return;

      var nmMap = mdl_data.read_1n1v(db_block.db["map"]["attributeMap"], blk.name);
      if(nmMap == null) return;

      var cap = arr_map.length;
      for(let i = 0; i < cap; i += 2) {
        if(arr_map[i] == nmMap) return arr_map[i + 1];
      };
    };
    exports._map = _map;


    /*
     * NOTE:
     *
     * Gets the highest attribute sum in a mapper list, from a list of tiles.
     * Returns an attribute pair as {[attrTg, attr]}.
     */
    const _attrPair = function(map, ts, mode) {
      if(map == null || ts == null) return;

      var attr = 0.0;
      var attrTg = null;
      var cap = map.length;
      if(cap > 0) {
        for(let i = 0; i < cap; i += 2) {
          var tmpNmAttr = map[i];
          var tmpAttr = _sumAttr_ts(ts, tmpNmAttr, mode);
          if(tmpAttr > attr) {
            attrTg = map[i + 1];
            attr = tmpAttr;
          };
        };
      };

      return (attrTg == null) ? null : [attrTg, attr];
    };
    exports._attrPair = _attrPair;


    /*
     * NOTE:
     *
     * Gets attribute sum for each attribute in a mapper list.
     * Returns a list of {attrTg} and {attr}.
     */
    const _attrMap = function(map, ts, mode) {
      var arr = [];

      if(map == null || ts == null) return arr;

      var cap = map.length;
      if(cap > 0) {
        for(let i = 0; i < cap; i += 2) {
          var nmAttr = map[i];
          var attr = sumAttr_ts(ts, nmAttr, mode);
          var attrTg = map[i + 1];

          arr.push(attrTg);
          arr.push(attr);
        };
      };

      return arr;
    };
    exports._attrMap = _attrMap;
  // End


  // Part: Special
    const _wind = function(t, scl) {
      if(scl == null) scl = 1.0;

      var attr = (1.0 - Math.pow(Math.sin(Time.time / 6400.0 / scl), 2) * 0.7) * Attribute.get("reind-attr-env-wind").env();
      if(t != null && attr > 0.0) attr += Mathf.randomSeed(t.pos(), -2, 2) * 0.1;

      if(attr < 0.0) attr = 0.0;
      return attr;
    };
    exports._wind = _wind;
  // End


Events.run(ClientLoadEvent, () => {
  Log.info("REIND: mdl_attr.js loaded.");
});
