/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Import
    const mdl_attr = require("reind/mdl/mdl_attr");
    const mdl_content = require("reind/mdl/mdl_content");
    const mdl_recipe = require("reind/mdl/mdl_recipe");
    const mdl_text = require("reind/mdl/mdl_text");
    const mdl_ui = require("reind/mdl/mdl_ui");

    const db_block = require("reind/db/db_block");
    const db_dialog = require("reind/db/db_dialog");
  // End


  // Part: Element


    /* <---------------- spacing ----------------> */


    const __margin = function(tb, scl) {
      if(scl == null) scl = 1.0;

      tb.marginLeft(12.0 * scl).marginRight(12.0 * scl).marginTop(15.0 * scl).marginBottom(15.0 * scl);
    };
    exports.__margin = __margin;


    /* <---------------- new line ----------------> */


    const __break = function(tb) {
      tb.add("").row();
      tb.add("").row();
    };
    exports.__break = __break;


    const __breakHalf = function(tb) {
      tb.add("").row();
    };
    exports.__breakHalf = __breakHalf;


    const __breakQuad = function(tb) {
      tb.add("").row();
      tb.add("").row();
      tb.add("").row();
      tb.add("").row();
    };
    exports.__breakQuad = __breakQuad;


    const __bar = function(tb, color, w, stroke) {
      if(color == null) color = Color.darkGray;
      if(stroke == null) stroke = 4.0;

      if(w == null) {
        tb.image().color(color).height(stroke).pad(0.0).growX().fillX().row();
      } else {
        tb.image().color(color).width(w).height(stroke).pad(0.0).fillX().row();
      };
    };
    exports.__bar = __bar;


    const __barV = function(tb, color, h, stroke) {
      if(color == null) color = Color.darkGray;
      if(stroke == null) stroke = 4.0;

      if(h == null) {
        return tb.image().color(color).width(stroke).pad(0.0).growY().fillY();
      } else {
        return tb.image().color(color).width(stroke).height(h).pad(0.0).fillY();
      };
    };
    exports.__barV = __barV;


    /* <---------------- text ----------------> */


    const __wrapLine = function(tb, str, align, order, padLeft) {
      if(align == null) align = Align.left;
      if(order == null) order = 0;
      if(padLeft == null) padLeft = 0.0;

      tb.add(str).center().labelAlign(align).wrap().width(mdl_ui._sizePair(null, null, order * 120.0)[0]).padLeft(padLeft).row();
    };
    exports.__wrapLine = __wrapLine;


    /* <---------------- input ----------------> */


    const __slider = function(tb, scr, min, max, step, ini) {
      if(min == null) min = 0;
      if(max == null) max = 2;
      if(step == null) step = 1;
      if(ini == null) ini = min;
      if(scr == null) return;

      tb.slider(min, max, step, ini, val => scr.call(val)).row();
    };
    exports.__slider = __slider;


    /* <---------------- content ----------------> */


    const __blockEfficiency = function(tb, blk, effc, nmAttr) {
      var str = (Math.abs(effc) < 0.0001) ? "" : (Strings.autoFixed(effc * 100.0, 2) + "%");

      return tb.table(Styles.none, tb1 => {
        tb1.left();

        tb1.table(Styles.none, tb2 => {
          tb2.left();

          var btn = tb2.button(new TextureRegionDrawable(blk.uiIcon), 64.0, db_dialog._content(blk)).tooltip(blk.localizedName + ((nmAttr == null) ? "" : ("\n\n[green]" + mdl_attr._attrVal(nmAttr) +"[]"))).padRight(-18.0).get();
          tb2.table(Styles.none, tb3 => {
            tb3.left();

            __break(tb3);
            tb3.add(str).fontScale(0.85).left().style(Styles.outlineLabel).color(effc < 0.0 ? Pal.remove : Pal.accent);
          });

          btn.margin(0.0);
          var btnStyle = btn.getStyle();
          btnStyle.up = Styles.none;
          btnStyle.down = Styles.none;
          btnStyle.over = Styles.flatOver;
        }).padRight(4.0);
      }).left().padRight(8.0).padTop(4.0).padBottom(4.0);
    };
    exports.__blockEfficiency = __blockEfficiency;


    const __recipeItem = function(tb, ct, amt, p, cancelLiq) {
      if(p == null) p = 1.0;
      if(cancelLiq == null) cancelLiq = false;

      // Use {-1} as amount to hide the label
      var str = (amt < 0) ? " " : ((ct instanceof Liquid && !cancelLiq) ? Strings.autoFixed(amt * 60.0, 2) + "/s" : Strings.autoFixed(amt, 0));

      return tb.table(Styles.none, tb1 => {
        tb1.left();

        tb1.table(Styles.none, tb2 => {
          tb2.left();

          var btn = tb2.button(new TextureRegionDrawable(ct.uiIcon), 32.0, db_dialog._content(ct)).tooltip(ct.localizedName).padRight(-4.0).get();
          tb2.table(Styles.none, tb3 => {
            tb3.left();

            tb3.add((Math.abs(p - 1.0) > 0.0001) ? (Strings.autoFixed(p * 100.0, 2) + "%") : "").left().fontScale(0.85).style(Styles.outlineLabel).color(Color.gray);
            tb3.row();
            tb3.add(str).fontScale(0.85).left().style(Styles.outlineLabel);
          });

          btn.margin(0.0);
          var btnStyle = btn.getStyle();
          btnStyle.up = Styles.none;
          btnStyle.down = Styles.none;
          btnStyle.over = Styles.flatOver;
        }).padRight(6.0);
      }).left().padRight(12.0).padTop(4.0).padBottom(4.0);
    };
    exports.__recipeItem = __recipeItem;


  // End


  // Part: Text
    const setHeadline = function(tb, str) {
      if(tb == null || str == null) return;

      tb.table(Tex.button, tb1 => {
        tb1.left();

        tb1.add(str);
      }).left().row();
    };
    exports.setHeadline = setHeadline;


    const setNoteStat = function(tb, str, order, padLeft) {
      if(order == null) order = 1;
      if(padLeft == null) padLeft = 0.0;
      if(tb == null || str == null) return;

      tb.row();

      tb.table(Tex.whiteui, tb1 => {
        tb1.center().setColor(Pal.darkestGray);
        __margin(tb1);

        __wrapLine(tb1, str, Align.center, order, padLeft);
      }).padTop(8.0).padBottom(8.0).growX().row();
    };
    exports.setNoteStat = setNoteStat;
  // End


  // Part: Table
    const setTableDisplay = function(tb, matArr, ws, hs, color, stroke, color_title, imgW) {
      if(ws == null) ws = [];
      if(hs == null) hs = [];
      if(imgW == null) imgW = 32.0;

      var rowAmt = matArr.length;
      var colAmt = matArr[0].length;

      tb.table(Styles.none, tb1 => {
        __bar(tb1, color, null, stroke);

        for(let i = 0; i < rowAmt; i++) {
          var h = hs[i];
          if(h == null) h = 40.0;

          tb1.table((color_title != null && i == 0) ? Tex.whiteui : Styles.none, tb2 => {
            if(color_title != null) tb2.setColor(color_title);

            __barV(tb2, color, null, stroke);

            for(let j = 0; j < colAmt; j++) {
              var w = ws[j];
              if(w == null) w = 80.0;

              tb2.table(Styles.none, tb3 => {
                if(i == 0) {tb3.center()} else {tb3.left()};
                __margin(tb3);

                var tmp = matArr[i][j];
                if(tmp != null) {
                  if(tmp instanceof TextureRegion) {
                    tb3.image(tmp).width(imgW).height(imgW);
                  } else if (tmp instanceof UnlockableContent) {
                    var btn = tb3.button(new TextureRegionDrawable(tmp.uiIcon), imgW, db_dialog._content(tmp)).tooltip(tmp.localizedName).get();
                    btn.margin(0.0);
                    var btnStyle = btn.getStyle();
                    btnStyle.up = Styles.none;
                    btnStyle.down = Styles.none;
                    btnStyle.over = Styles.flatOver;
                  } else {
                    if(typeof tmp == "string") {tb3.add(tmp)} else {tb3.add(Strings.autoFixed(tmp, 2))};
                  };
                };
              }).width(w);

              __barV(tb2, color, null, stroke);
            };
          }).height(h).row();

          __bar(tb1, color, null, stroke);
        };
      }).row();
    };
    exports.setTableDisplay = setTableDisplay;
  // End


  // Part: Content
    const setContentRowDisplay = function(tb, cts_gn, showOrder) {
      var arr;
      if(showOrder == null) showOrder = false;
      if(cts_gn instanceof Array) {
        arr = cts_gn;
      } else {
        arr = [cts_gn];
        showOrder = false;
      };

      var ord = 0;

      tb.row();
      __breakHalf(tb);
      arr.forEach(ct => {
        if(typeof ct == "string") ct = mdl_content._ct_nm(ct);
        if(ct != null) {
          tb.table(Tex.whiteui, tb1 => {
            tb1.left().setColor(Pal.darkestGray);
            __margin(tb1);

            if(showOrder) tb1.table(Styles.none, tb2 => {
              tb2.left();

              tb2.table(Styles.none, tb3 => {
                tb3.center();

                tb3.add("[" + Strings.fixed(ord + 1.0, 0) + "]").color(Pal.accent);
              }).width(48.0);
            }).marginRight(18.0).growY();

            tb1.table(Styles.none, tb_l => {
              tb_l.left();

              tb_l.image(ct.uiIcon).size(Vars.iconLarge).padRight(18.0);
              __barV(tb_l).padRight(18.0);
              tb_l.add(ct.localizedName);
            });

            tb1.table(Styles.none, tb_m => {}).width(80.0).growX().growY();

            tb1.table(Styles.none, tb_r => {
              tb_r.left();

              tb_r.button("?", db_dialog._content(ct)).size(42.0);
            });
          }).growX().row();
          __breakHalf(tb);

          ord++;
        };
      });
    };
    exports.setContentRowDisplay = setContentRowDisplay;


    const setContentListDisplay = function(tb, cts_gn, sizeScl, col) {
      if(sizeScl == null) sizeScl = 1.0;
      if(col == null) col = mdl_ui._col(sizeScl);

      var arr;
      if(cts_gn instanceof Array) {
        arr = cts_gn;
      } else {
        arr = [cts_gn];
      };

      tb.row();
      tb.table(Tex.whiteui, tb1 => {
        tb1.left().setColor(Pal.darkestGray);
        __margin(tb1, 0.5);

        var cap = arr.length;
        for(let i = 0, j = 0; i < cap; i++) {
          (function(i) {
            var ct = arr[i];
            var btn = tb1.button(new TextureRegionDrawable(ct.uiIcon), 32.0 * sizeScl, db_dialog._content(ct)).pad(4.0).tooltip(ct.localizedName).get();

            btn.margin(0.0);
            var btnStyle = btn.getStyle();
            btnStyle.up = Styles.none;
            btnStyle.down = Styles.none;
            btnStyle.over = Styles.flatOver;
          })(i);

          if(j % col == col - 1) tb1.row();
          j++;
        };
      }).row();
    };
    exports.setContentListDisplay = setContentListDisplay;


    const setBatchDisplay = function(tb, batch, col) {
      var cap = batch.length;
      if(cap == 0) return;

      if(col == null) col = 1;

      tb.row();
      tb.table(Styles.none, tb1 => {
        tb1.left();
        __margin(tb1, 0.5);

        for(let i = 0, j = 0; i < cap; i += 3) {
          (function(i) {
            var itm = mdl_content._ct_gn(batch[i]);
            var amt = batch[i + 1];
            var p = batch[i + 2];

            __recipeItem(tb1, itm, amt, p).padLeft(20.0);
          }) (i);

          if(j % col == col - 1) tb1.row();
          j++;
        };
      }).row();
    };
    exports.setBatchDisplay = setBatchDisplay;


    const setContentSelector = function(tb, cts, id_sel, scr, col) {
      if(col == null) col = 4;
      if(tb == null || cts == null || id_sel == null || scr == null || cts.length == 0) return;

      var btnGrp = new ButtonGroup();
      btnGrp.setMinCheckCount(0);
      btnGrp.setMaxCheckCount(1);

      tb.table(Tex.button, tb1 => {
        tb1.left();
        __margin(tb1);

        var cap = cts.length;
        if(cap > 0) {
          for(let i = 0, j = 0; i < cap; i++) {
            (function(i) {
              var ct = cts[i];
              var id = ct.id;

              var btn = tb1.button(Styles.none, 32.0, () => {
                (id == id_sel) ? scr.call(-1) : scr.call(id);
              }).pad(4.0).tooltip(ct.localizedName).group(btnGrp).get();

              var btnStyle = btn.getStyle();
              btnStyle.up = Styles.none;
              btnStyle.down = Styles.none;
              btnStyle.over = Styles.flatOver;
              btnStyle.checked = Styles.accentDrawable;
              btnStyle.imageUp = new TextureRegionDrawable(ct.uiIcon);
              btn.update(() => btn.setChecked(id == id_sel));
            })(i);

            if(j % col == col - 1) tb1.row();
            j++;
          };
        };
      }).row();
    };
    exports.setContentSelector = setContentSelector;
  // End


  // Part: Event
    const setTrigger = function(tb, scr, icon_gn, str_tt, size, overScr, notOverScr) {
      if(icon_gn == null) icon_gn = Icon.cross;
      if(size == null) size = 32.0;
      if(tb == null || scr == null) return;

      var cell_btn = tb.button(icon_gn, size, () => scr.call()).center();
      if(str_tt != null) cell_btn.tooltip(str_tt);
      tb.row();

      if(overScr != null) {
        cell_btn.update(btn => {
          if(btn.isOver()) {
            overScr.call();
          } else {
            if(notOverScr != null) notOverScr.call();
          };
        });
      };
    };
    exports.setTrigger = setTrigger;
  // End


  // Part: Efficiency
    const setResourceMultiplierDisplay = function(tb, blk) {
      var matArr = [[mdl_text._term("icon"), mdl_text._term("resource"), mdl_text._term("multiplier")]];
      var arr = db_block.db["map"]["rsMtp"];
      var cap = arr.length;
      for(let i = 0; i < cap; i += 3) {
        if(blk.name != arr[i]) continue;

        var rs = mdl_content._ct_gn(arr[i + 1]);
        if(rs == null) continue;
        var mtp = arr[i + 2];

        matArr.push([rs, rs.localizedName, ((mtp < 0.9999) ? "[red]" : "[green]") + Strings.autoFixed(mtp * 100.0, 2) + "%[]"]);
      };

      tb.row();
      tb.table(Styles.none, tb1 => {
        setTableDisplay(tb1, matArr, [60.0, 360.0, 120.0], null, Color.darkGray, 2.0, Color.darkGray, 32.0);
      }).row();
    };
    exports.setResourceMultiplierDisplay = setResourceMultiplierDisplay;


    const setAttributeBlockDisplay = function(tb, blkEffcMap, col) {
      var cap = blkEffcMap.length;
      if(cap == 0) return;

      if(col == null) col = Math.ceil(mdl_ui._col(2.0) * 0.5);

      tb.row();
      tb.table(Styles.none, tb1 => {
        tb1.left();

        for(let i = 0, j = 0; i < cap; i += 3) {
          (function(i) {
            var blk = blkEffcMap[i];
            var effc = blkEffcMap[i + 1];
            var nmAttr = blkEffcMap[i + 2];

            __blockEfficiency(tb1, blk, effc, nmAttr);
          }) (i);

          if(j % col == col - 1) tb1.row();
          j++;
        };
      }).row();
    };
    exports.setAttributeBlockDisplay = setAttributeBlockDisplay;


    const setAttributeMapDisplay = function(tb, map) {
      var cap = map.length;
      if(cap == 0) return;

      var matArr = [[Core.bundle.get("stat.reind-stat-attribute-required.name"), mdl_text._term("icon"), mdl_text._term("output")]];
      for(let i = 0; i < cap; i += 2) {
        var nmAttr = map[i];
        var ct = mdl_content._ct_gn(map[i + 1]);
        if(ct == null) continue;

        matArr.push([mdl_attr._attrVal(nmAttr), ct, ct.localizedName]);
      };

      tb.row();
      tb.table(Styles.none, tb1 => {
        setTableDisplay(tb1, matArr, [300.0, 60.0, 360.0], null, Color.darkGray, 2.0, Color.darkGray, 32.0);
      }).row();
    };
    exports.setAttributeMapDisplay = setAttributeMapDisplay;
  // End


  // Part: Recipe
    const setRecipeDisplay = function(tb, rcFi) {
      var cap = mdl_recipe._rcSize(rcFi);
      if(cap == 0) {
        tb.add(mdl_text._info("no-recipe-found"));
      } else {
        tb.row();

        var blk = mdl_recipe._blk(rcFi);
        if(blk == null) return;

        for(let i = 0; i < cap; i++) {
          var cat = mdl_recipe._cat(rcFi, i);
          var cat_pre = (i == 0) ? null : mdl_recipe._cat(rcFi, i - 1);
          var inputs = mdl_recipe._inputs(rcFi, i);
          var outputs = mdl_recipe._outputs(rcFi, i);
          var randInputs = mdl_recipe._randInputs(rcFi, i);
          var randOutputs = mdl_recipe._randOutputs(rcFi, i);
          var bfInputs = mdl_recipe._bfInputs(rcFi, i);
          var bfOutputs = mdl_recipe._bfOutputs(rcFi, i);
          var optInputs = mdl_recipe._optInputs(rcFi, i);
          var failOutputs = mdl_recipe._failOutputs(rcFi, i);

          // Category
          if(cat != cat_pre) {
            var catVal = mdl_recipe._catVal(rcFi, i);
            tb.table(Tex.whiteui, tb1 => {
              tb1.center().setColor(Color.darkGray);
              __margin(tb1, 0.5);

              tb1.add(catVal).pad(3.0);
            }).growX().row();
          } else {
            __bar(tb, Color.valueOf("303030"), null, 1.0);
          };

          // Recipe base
          tb.table(Tex.whiteui, tb1 => {
            tb1.left().setColor(Pal.darkestGray);

            // Order
            tb1.table(Styles.none, tb2 => {
              tb2.left();

              tb2.table(Styles.none, tb3 => {
                tb3.center();

                tb3.add("[" + Strings.fixed(i + 1.0, 0) + "]").color(Pal.accent);
              }).width(72.0);

              __barV(tb2, Pal.accent);
            }).left().growY();

            // Spacing
            tb1.table(Styles.none, tb2 => {}).left().width(36.0).growY();

            // Input Base
            tb1.table(Styles.none, tb2 => {
              tb1.left();

              // Input
              var arr = inputs;
              var cap1 = arr.length;
              if(cap1 > 0) {
                tb2.table(Styles.none, tb3 => {
                  tb3.left();
                  __margin(tb3);

                  tb3.add("I:").left().tooltip(mdl_text._term("input")).row();
                  tb3.table(Styles.none, tb4 => {
                    for(let j = 0; j < cap1; j++) {
                      if(j % 2 != 0) continue;

                      var ct = mdl_content._ct_nm(arr[j]);
                      if(ct == null) continue;
                      var amt = arr[j + 1];

                      __recipeItem(tb4, ct, amt);
                    };
                  });
                }).left().marginRight(72.0);
              };

              // Random Input
              var arr = randInputs;
              var cap1 = arr.length;
              if(cap1 > 0) {
                tb2.table(Styles.none, tb3 => {
                  tb3.left();
                  __margin(tb3);

                  tb3.add("RI:").left().tooltip(mdl_text._term("random-input")).row();
                  tb3.table(Styles.none, tb4 => {
                    for(let j = 0; j < cap1; j++) {
                      if(j % 3 != 0) continue;

                      var ct = mdl_content._ct_nm(arr[j]);
                      if(ct == null) continue;
                      var amt = arr[j + 1];
                      var p = arr[j + 2];

                      __recipeItem(tb4, ct, amt, p);
                    };
                  });
                }).left().marginRight(72.0);
              };

              // Batch Fluid Input
              var arr = bfInputs;
              var cap1 = arr.length;
              if(cap1 > 0){
                tb2.table(Styles.none, tb3 => {
                  tb3.left();
                  __margin(tb2);

                  tb3.add("BFI:").left().tooltip(mdl_text._term("batch-fluid-input")).row();
                  tb3.table(Styles.none, tb4 => {
                    for(let j = 0; j < cap1; j++) {
                      if(j % 2 != 0) continue;

                      var ct = mdl_content._ct_nm(arr[j]);
                      var amt = arr[j + 1];

                      __recipeItem(tb4, ct, amt, 1.0, true);
                    };
                  });
                }).left().marginRight(72.0);
              };

              // Optional Input
              var arr = optInputs;
              var cap1 = arr.length;
              if(cap1 > 0) {
                tb2.table(Styles.none, tb3 => {
                  tb3.left();
                  __margin(tb3);

                  tb3.add("OI:").left().tooltip(mdl_text._term("optional-input")).row();
                  tb3.button("?", db_dialog._optInput(arr)).size(42.0).pad(6.0);
                }).left().marginRight(72.0);
              };

              // Spacing
              tb2.table(Styles.none, tb3 => {}).left().width(36.0).growX().growY();
            }).left().growX().growY();

            // Spacing
            tb1.table(Styles.none, tb2 => {}).width(120.0).growX().growY();

            // Output Base
            tb1.table(Styles.none, tb2 => {
              tb2.left();

              // Output
              var arr = outputs;
              var cap1 = arr.length;
              if(cap1 > 0) {
                tb2.table(Styles.none, tb3 => {
                  tb3.left()
                  __margin(tb3);

                  tb3.add("O:").left().tooltip(mdl_text._term("output")).row();
                  tb3.table(Styles.none, tb4 => {
                    for(let j = 0; j < cap1; j++) {
                      if(j % 2 != 0) continue;

                      var ct = mdl_content._ct_nm(arr[j]);
                      if(ct == null) continue;
                      var amt = arr[j + 1];

                      __recipeItem(tb4, ct, amt);
                    };
                  });
                }).left().marginRight(72.0);
              };

              // Random Output
              var arr = randOutputs;
              var cap1 = arr.length;
              if(cap1 > 0) {
                tb2.table(Styles.none, tb3 => {
                  tb3.left();
                  __margin(tb3);

                  tb3.add("RO:").left().tooltip(mdl_text._term("random-output")).row();
                  tb3.table(Styles.none, tb4 => {
                    for(let j = 0; j < cap1; j++) {
                      if(j % 3 != 0) continue;

                      var ct = mdl_content._ct_nm(arr[j]);
                      if(ct == null) continue;
                      var amt = arr[j + 1];
                      var p = arr[j + 2];

                      __recipeItem(tb4, ct, amt, p);
                    };
                  });
                }).left().marginRight(72.0);
              };

              // Batch Fluid Output
              var arr = bfOutputs;
              var cap1 = arr.length;
              if(cap1 > 0){
                tb2.table(Styles.none, tb3 => {
                  tb3.left();
                  __margin(tb3);

                  tb3.add("BFO:").left().tooltip(mdl_text._term("batch-fluid-output")).row();
                  tb3.table(Styles.none, tb4 => {
                    for(let j = 0; j < cap1; j++) {
                      if(j % 2 != 0) continue;

                      var ct = mdl_content._ct_nm(arr[j]);
                      if(ct == null) continue;
                      var amt = arr[j + 1];
                      __recipeItem(tb4, ct, amt, 1.0, true);
                    };
                  });
                }).left().marginRight(72.0);
              };

              // Fail Output
              var arr = failOutputs;
              var cap1 = arr.length;
              if(cap1 > 0) {
                tb2.table(Styles.none, tb3 => {
                  tb3.left();
                  __margin(tb3);

                  tb3.add("FO:").left().tooltip(mdl_text._term("failed-output")).row();
                  tb3.table(Styles.none, tb4 => {
                    for(let j = 0; j < cap1; j++) {
                      if(j % 2 != 0) continue;

                      var ct = mdl_content._ct_nm(arr[j]);
                      if(ct == null) continue;
                      var amt = arr[j + 1];
                      __recipeItem(tb4, ct, amt);
                    };
                  });
                }).left().marginRight(72.0);
              };
            }).left().growY();

            // Recipe stats
            tb1.table(Styles.none, tb2 => {
              __barV(tb2, Pal.accent);

              tb2.table(Styles.none, tb3 => {}).width(24.0);

              tb2.table(Styles.none, tb3 => {
                var tt = mdl_recipe._rawTooltip(rcFi, i);

                tb3.left();
                __margin(tb3);

                // Generated
                var isGen = mdl_recipe._isGen(rcFi, i);
                if(isGen) tb3.add(mdl_text._info("generated-recipe")).left().row();

                // Time Scale
                var scl = mdl_recipe._timeScale(rcFi, i);
                if(Math.abs(scl - 1.0) > 0.01) tb3.add(mdl_text._statText(mdl_text._term("time-required"), Strings.fixed(scl, 1) + "x") + " [gray](" + Strings.autoFixed(blk.craftTime * scl / 60.0, 2) + "s)[]").left().row();

                // Require Optional
                var reqOpt = mdl_recipe._reqOpt(rcFi, i);
                if(reqOpt) tb3.add(mdl_text._statText(mdl_text._term("require-optional"), Core.bundle.get("yes"))).left().row();

                // Fail Probability
                var failP = mdl_recipe._failP(rcFi, i);
                if(failP > 0.0) tb3.add(mdl_text._statText(mdl_text._term("chance-to-fail"), Strings.fixed(failP * 100.0, 1) + "%")).left().row();

                // Tooltip: Overdriven Mode
                if(tt == "overdriven") tb3.add(mdl_text._info("tt-overdriven")).left().row();
              }).left().width(320.0).growX();
            }).growY();
          }).growX().row();
        };
      };
    };
    exports.setRecipeDisplay = setRecipeDisplay;


    const setRecipeSelector = function(tb, rcFi, id_rc, b, scr, col) {
      if(col == null) col = 4;
      if(tb == null || rcFi == null || id_rc == null || scr == null) return;

      var btnGrp = new ButtonGroup();
      btnGrp.setMinCheckCount(0);
      btnGrp.setMaxCheckCount(1);

      var cap = mdl_recipe._rcSize(rcFi);
      if(cap == 0) return;

      tb.button("?", db_dialog._content(b.block)).left().size(42.0).row();

      tb.table(Tex.button, tb1 => {
        tb1.left();

        for(let i = 0, j = 0; i < cap; i++) {
          (function(i) {
            var cat = mdl_recipe._cat(rcFi, i);
            var cat_pre = (i == 0) ? null : mdl_recipe._cat(rcFi, i - 1);
            if(cat != cat_pre) {
              j = 0;
              if(i != 0) {
                __break(tb1);
              };
            };

            var tt = mdl_recipe._rawTooltip(rcFi, i);
            var tooltip = mdl_recipe._tooltip(rcFi, i);
            var btn = tb1.button(Tex.pane, 32.0, () => {
              (i == id_rc) ? scr.call(0) : scr.call(i);
            }).pad(4.0).tooltip(tooltip).group(btnGrp).get();

            var btnStyle = btn.getStyle();
            btnStyle.up = Styles.none;
            btnStyle.down = Styles.none;
            btnStyle.over = Styles.flatOver;
            btnStyle.checked = Styles.accentDrawable;
            btnStyle.imageUp = (tt == "overdriven") ? mdl_recipe._icon(rcFi, i).tint(Color.red) : mdl_recipe._icon(rcFi, i);
            btn.update(() => btn.setChecked(i == id_rc));
          })(i);

          if(j % col == col - 1) tb1.row();
          j++;
        };
      }).row();
    };
    exports.setRecipeSelector = setRecipeSelector;
  // End


Events.run(ClientLoadEvent, () => {
  Log.info("REIND: mdl_table.js loaded.");
});
