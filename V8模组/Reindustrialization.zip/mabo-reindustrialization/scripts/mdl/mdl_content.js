/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Import
    const frag_heat = require("reind/frag/frag_heat");

    const mdl_data = require("reind/mdl/mdl_data");
    const mdl_file = require("reind/mdl/mdl_file");
    const mdl_test = require("reind/mdl/mdl_test");
    const mdl_text = require("reind/mdl/mdl_text");

    const db_block = require("reind/db/db_block");
    const db_fluid = require("reind/db/db_fluid");
    const db_item = require("reind/db/db_item");
    const db_unit = require("reind/db/db_unit");
  // End


  // Part: Call
    const caller = function(ct, scr) {
      scr.call(ct);
    };
    exports.caller = caller;


    const callInit = function(ct, scr) {
      ct.init(() => scr.call(ct));
    };
    exports.callInit = callInit;
  // End


  // Part: Meta
    const _tp_nm = function(nm) {
      if(nm == null || typeof nm != "string") return;

      if(mdl_text.includes_ex(
        nm,
        "reind-item-",
        "reind-ilitem-",
      )) return "item";

      if(mdl_text.includes_ex(
        nm,
        "reind-liq-",
        "reind-gas-",
        "reind-effc-",
        "reind-illiq-",
        "reind-ilgas-",
        "reind-ileffc-",
      )) return "fluid";

      if(mdl_text.includes_ex(
        nm,
        "reind-env-",
      )) return "env";

      if(mdl_text.includes_ex(
        nm,
        "reind-def-",
        "reind-dis-",
        "reind-eff-",
        "reind-fac-",
        "reind-bliq-",
        "reind-log-",
        "reind-min-",
        "reind-pow-",
        "reind-pay-",
        "reind-ildef-",
        "reind-ildis-",
        "reind-ileff-",
        "reind-ilfac-",
        "reind-ilbliq-",
        "reind-illog-",
        "reind-ilmin-",
        "reind-ilpow-",
        "reind-ilpay-",
        "reind-map-",
      )) return "build";

      if(mdl_text.includes_ex(
        nm,
        "reind-unit-",
      )) return "unit";

      if(mdl_text.includes_ex(
        nm,
        "reind-sta-",
      )) return "status";

      if(mdl_text.includes_ex(
        nm,
        "reind-wea-",
      )) return "weather";

      if(mdl_text.includes_ex(
        nm,
        "reind-camp-",
      )) return "sector";

      if(mdl_text.includes_ex(
        nm,
        "reind-pla-",
      )) return "planet";
    };
    exports._tp_nm = _tp_nm;


    const _ct_id = function(tp_ct, id) {
      if(id < 0) return;

      var ct = null;
      switch(tp_ct) {
        case "item" :
          ct = Vars.content.items().get(id);
          break;
        case "fluid" :
          ct = Vars.content.liquids().get(id);
          break;
        case "env" :
          ct = Vars.content.blocks().get(id);
          break;
        case "build" :
          ct = Vars.content.blocks().get(id);
          break;
        case "unit" :
          ct = Vars.content.units().get(id);
          break;
        case "status" :
          ct = Vars.content.statusEffects().get(id);
          break;
        case "weather" :
          ct = Vars.content.weathers().get(id);
          break;
        case "sector" :
          ct = Vars.content.sectors().get(id);
          break;
        case "planet" :
          ct = Vars.content.planets().get(id);
          break;
      };

      return ct;
    };
    exports._ct_id = _ct_id;


    const _ct_nm = function(nm, suppressWarning) {
      if(nm == null || typeof nm != "string") return;

      if(suppressWarning == null) suppressWarning = false;

      var tp_ct = _tp_nm(nm);
      var ct = null;
      switch(tp_ct) {
        case "item" :
          ct = Vars.content.item(nm);
          break;
        case "fluid" :
          ct = Vars.content.liquid(nm);
          break;
        case "env" :
          ct = Vars.content.block(nm);
          break;
        case "build" :
          ct = Vars.content.block(nm);
          break;
        case "unit" :
          ct = Vars.content.unit(nm);
          break;
        case "status" :
          ct = Vars.content.statusEffect(nm);
          break;
        case "weather" :
          ct = Vars.content.weather(nm);
          break;
        case "sector" :
          ct = Vars.content.sector(nm);
          break;
        case "planet" :
          ct = Vars.content.planet(nm);
          break;
      };

      // NOTE: Use these at last to avoid some bugs. This is required for cross-mod reference.
      if(ct == null) ct = Vars.content.item(nm);
      if(ct == null) ct = Vars.content.liquid(nm);
      if(ct == null) ct = Vars.content.block(nm);
      if(ct == null) ct = Vars.content.unit(nm);
      if(ct == null) ct = Vars.content.statusEffect(nm);
      if(ct == null) ct = Vars.content.weather(nm);
      if(ct == null) ct = Vars.content.sector(nm);
      if(ct == null) ct = Vars.content.planet(nm);

      if(ct == null && !suppressWarning) mdl_test._w_contentNotFound(nm);

      return ct;
    };
    exports._ct_nm = _ct_nm;


    const _ct_gn = function(ct_gn, suppressWarning) {
      if(ct_gn == null) return;

      var val = null;

      if(ct_gn instanceof UnlockableContent) val = ct_gn;
      if(typeof ct_gn == "string") val = _ct_nm(ct_gn, suppressWarning);

      return val;
    };
    exports._ct_gn = _ct_gn;


    const _nmCt_gn = function(ct_gn) {
      if(ct_gn == null) return;

      var val = null;

      if(typeof ct_gn == "string") val = ct_gn;
      if(ct_gn instanceof UnlockableContent) val = ct_gn.name;

      return val;
    };
    exports._nmCt_gn = _nmCt_gn;
  // End


  // Part: Field
    const _reg = function(ct, suffix) {
      if(suffix == null) suffix = "";
      if(Vars.headless) return;

      return Core.atlas.find(ct.name + suffix);
    };
    exports._reg = _reg;


    const _buildReg = function(blk) {
      if(Vars.headless) return;

      return Core.atlas.find(blk.name + "-icon", Core.atlas.find(blk.name));
    };
    exports._buildReg = _buildReg;
  // End


  // Part: Setting
    const rsTagExc = {
      "p1": [],
      "p2": [],

      "accumulated": [],
      "dried": [],
      "roasted": [],
      "unannealed": [],
      "unbaked": [],

      "blend": [],
      "chunks": [],
      "concentrate": [],
      "dust": [
        "reind-item-was-dust",

        "reind-effc-effc-dust-recycling"
      ],
      "crude-gas": [],

      "acidic": [],
      "basic": [],

      "clean": [],
      "conc": [],
      "fuming": [],
      "purified": [],
      "thickened": [],

      "slurry": [
        "reind-liq-was-waste-slurry",
      ],
      "solution": [],
      "suspension": [],
    };


    const rsTagInc = {

    };


    const _rsTag = function(ct) {
      if(ct == null || !_isReind(ct)) return;

      var nm = ct.name;
      var arr = [];

      // Automatically add tags by name
      var keys = Object.keys(rsTagExc);
      var cap = keys.length;
      for(let i = 0; i < cap; i++) {
        var tag = keys[i];

        if(!rsTagExc[tag].includes(nm) && !arr.includes(tag)) {
          var cond = false;

          // This is horrible
          if(nm.includes(tag)) {
            if(new RegExp("-" + tag + "[^0-z]", "i").test(nm)) {cond = true} else {
              if(!(new RegExp("-" + tag + "\\w", "i").test(nm)) && new RegExp("-" + tag, "i").test(nm)) cond = true;
            };
          };

          if(cond) arr.push(tag);
        };
      };

      // Manually add tags
      var tags = rsTagInc[nm];
      if(tags != null) {
        var cap = tags.length;
        if(cap > 0) {
          for(let i = 0; i < cap; i++) {
            var tag = tags[i];

            if(!arr.includes(tag)) arr.push(tag);
          };
        };
      };

      return arr;
    };
    exports._rsTag = _rsTag;


    const _rsTagVal = function(ct, noColor) {
      if(noColor == null) noColor = false;
      if(ct == null || !_isReind(ct)) return;

      var tags = _rsTag(ct);
      var val = "";

      tags.forEach(tag => val += "<" + tag + ">");

      return (val == "") ? null : (noColor ? val : ("[gray]" + val + "[]"));
    };
    exports._rsTagVal = _rsTagVal;


    const _faction = function(ct) {
      if(ct == null || !_isReind(ct)) return;

      var nm = ct.name;
      var tp_ct = _tp_nm(nm);
      var faction = null;
      switch(tp_ct) {
        case "build" :
          faction = mdl_data.read_1n1v(db_block.db["map"]["faction"], nm);
          break;
        case "unit" :
          faction = mdl_data.read_1n1v(db_unit.db["map"]["faction"], nm);
          break;
      };

      if(faction == null) faction = "no-faction";

      return faction;
    };
    exports._faction = _faction;


    const _factionVal = function(ct) {
      if(ct == null) return;

      var faction = _faction(ct);
      return (Vars.headless || faction == null) ? null : mdl_text._term(faction);
    };
    exports._factionVal = _factionVal;


    const _factionMembers = function(faction, includeNoFaction) {
      var arr = [];

      if(faction instanceof Block || faction instanceof UnitType) faction = _faction(faction);
      if(includeNoFaction == null) includeNoFaction = false;
      if(faction == "no-faction" && !includeNoFaction) return arr;

      Vars.content.blocks().each(blk => {if(!_isEnvBlock(blk) && _faction(blk) == faction && !arr.includes(blk)) arr.push(blk)});
      Vars.content.units().each(utp => {if(_faction(utp) == faction && !arr.includes(utp)) arr.push(utp)});

      return arr;
    };
    exports._factionMembers = _factionMembers;


    const _fami = function(ct) {
      if(ct == null) return [];

      return _isFactory(ct) ? mdl_data.readLi_1n1v(db_block.db["map"]["family"], ct.name) : [];
    };
    exports._fami = _fami;


    const _famiVal = function(ct) {
      if(Vars.headless || ct == null) return;

      return mdl_text._tagText(_fami(ct).map(i => mdl_text._term(i)));
    };
    exports._famiVal = _famiVal;


    const _famiMembers = function(fami) {
      var arr = (fami instanceof Block) ? _fami(fami) : [fami];
      var arr1 = [];

      Vars.content.blocks().each(blk => {
        if(_isFactory(blk)) {
          var cond = false;
          var tmpFami = _fami(blk);
          arr.forEach(i => {if(tmpFami.includes(i) && !arr1.includes(i)) cond = true});

          if(cond) arr1.push(blk);
        };
      });

      return arr1;
    };
    exports._famiMembers = _famiMembers;


    const _consTg = function(ct) {
      if(ct == null) return [];

      return mdl_data.readLi_1n1v(db_item.db["map"]["consumable"], ct.name);
    };
    exports._consTg = _consTg;


    const _consTgVal = function(ct) {
      if(Vars.headless || ct == null) return;

      return mdl_text._tagText(_consTg(ct).map(i => mdl_text._term("fac-" + i)));
    };
    exports._consTgVal = _consTgVal;


    const _oreBlks = function(rs) {
      const li_blk = Vars.content.blocks();
      const blks = [];

      if(rs == null) return blks;
      if(rs instanceof Item) {
        li_blk.each(blk => {if(blk.itemDrop == rs) blks.push(blk)});
      } else if(rs instanceof Liquid) {
        li_blk.each(blk => {if(blk.liquidDrop == rs) blks.push(blk)});
      };

      return blks;
    };
    exports._oreBlks = _oreBlks;
  // End


  // Part: Cond
    const _isReind = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_file._isReindName(nmCt);
    };
    exports._isReind = _isReind;


    /* resource */


    const _isEffc = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-effc-",
        "reind-ileffc-",
      );
    };
    exports._isEffc = _isEffc;


    const _isNoCapEffc = function(ct_gn) {
      return db_fluid.db["efficiency"]["noCap"].includes(_nmCt_gn(ct_gn));
    };
    exports._isNoCapEffc = _isNoCapEffc;


    const _isVirt = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-item-virt-",
        "reind-ilitem-virt-",
      );
    };
    exports._isVirt = _isVirt;


    const arr_bit = [
      "reind-item-virt-bit",
      "reind-item-virt-kilobit",
      "reind-item-virt-megabit",
      "reind-item-virt-gigabit",
    ];
    const _isBit = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return arr_bit.includes(nmCt);
    };
    exports._isBit = _isBit;


    const _isLiq = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-liq-",
        "reind-illiq-",
      );
    };
    exports._isLiq = _isLiq;


    const _isGas = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-gas-",
        "reind-ilgas-",
      );
    };
    exports._isGas = _isGas;


    const _isIntermediate = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-item-int-",
        "reind-liq-int-",
        "reind-gas-int-",
        "reind-ilitem-int-",
        "reind-illiq-int-",
        "reind-ilgas-int-",
      );
    };
    exports._isIntermediate = _isIntermediate;


    const _isWaste = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-item-was-",
        "reind-liq-was-",
        "reind-ilitem-was-",
        "reind-illiq-was-",
      );
    };
    exports._isWaste = _isWaste;


    const _isOre = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-item-ore-",
        "reind-liq-ore-",
        "reind-gas-ore-",
        "reind-ilitem-ore-",
        "reind-illiq-ore-",
        "reind-ilgas-ore-",
      );
    };
    exports._isOre = _isOre;


    const _isAqueous = function(ct_gn) {
      return db_fluid.db["group"]["aqueous"].includes(_nmCt_gn(ct_gn));
    };
    exports._isAqueous = _isAqueous;


    const _isConductiveLiquid = function(ct_gn) {
      return db_fluid.db["group"]["conductive"].includes(_nmCt_gn(ct_gn));
    };
    exports._isConductiveLiquid = _isConductiveLiquid;


    const _isAcidic = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);
      if(db_item.db["iTag"]["acidic"].includes(nmCt)) return true;
      if(db_fluid.db["group"]["acidic"].includes(nmCt)) return true;

      return false;
    };
    exports._isAcidic = _isAcidic;


    const _isBasic = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);
      if(db_item.db["iTag"]["basic"].includes(nmCt)) return true;
      if(db_fluid.db["group"]["basic"].includes(nmCt)) return true;

      return false;
    };
    exports._isBasic = _isBasic;


    const _isOxidative = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);
      if(db_item.db["iTag"]["oxidative"].includes(nmCt)) return true;
      if(db_fluid.db["fTag"]["oxidative"].includes(nmCt)) return true;

      return false;
    };
    exports._isOxidative = _isOxidative;


    const _isReductive = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);
      if(db_item.db["iTag"]["reductive"].includes(nmCt)) return true;
      if(db_fluid.db["fTag"]["reductive"].includes(nmCt)) return true;

      return false;
    };
    exports._isReductive = _isReductive;


    const _isUnstable = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);
      if(db_item.db["iTag"]["unstable"].includes(nmCt)) return true;

      return false;
    };
    exports._isUnstable = _isUnstable;


    /* build */


    const _isOreScanner = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-min-scan-",
        "reind-ilmin-scan-",
      );
    };
    exports._isOreScanner = _isOreScanner;


    const _isCrop = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-min-crop-",
        "reind-ilmin-crop-",
      );
    };
    exports._isCrop = _isCrop;


    const _isExposedBlock = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return db_block.db["param"]["exposed"].includes(nmCt);
    };
    exports._isExposedBlock = _isExposedBlock;


    const _isItemJunction = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return db_block.db["group"]["itemJunction"].includes(nmCt);
    };
    exports._isItemJunction = _isItemJunction;


    const _isCoreBlock = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-eff-core-",
        "reind-ileff-core",
      );
    };
    exports._isCoreBlock = _isCoreBlock;


    const _isCond = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-bliq-aux-",
        "reind-bliq-brd-",
        "reind-bliq-cond-",
        "reind-ilbliq-aux-",
        "reind-ilbliq-brd-",
        "reind-ilbliq-cond-",
      );
    };
    exports._isCond = _isCond;


    const _isFluidContainer = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-bliq-stor-",
        "reind-ilbliq-stor-",
      );
    };
    exports._isFluidContainer = _isFluidContainer;


    const _isFluidJunction = function(ct_gn) {
      var ct = _ct_gn(ct_gn);

      if(ct == null) return false;
      if(ct instanceof LiquidJunction) return true;
      if(ct.name.includes("reind-dis-aux") && ct.name.includes("-junction")) return true;

      return false;
    };
    exports._isFluidJunction = _isFluidJunction;


    const _isCloggable = function(ct_gn) {
      return db_block.db["durability"]["cloggable"].includes(_nmCt_gn(ct_gn));
    };
    exports._isCloggable = _isCloggable;


    const _isHcond = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-pow-hcond-",
        "reind-ilpow-hcond-",
      );
    };
    exports._isHcond = _isHcond;


    const _isEcond = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-pow-econd-",
        "reind-ilpow-econd-",
      );
    };
    exports._isEcond = _isEcond;


    const _canShortCircuit = function(ct_gn) {
      return db_block.db["power"]["shortCircuit"].includes(_nmCt_gn(ct_gn));
    };
    exports._canShortCircuit = _canShortCircuit;


    const _isPowerTransmitter = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "-wire-node",
        "-wire-relay",
      );
    };
    exports._isPowerTransmitter = _isPowerTransmitter;


    const _isPowerNode = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return nmCt != null && nmCt.includes("-wire-node") && !nmCt.includes("-remote-wire-node");
    };
    exports._isPowerNode = _isPowerNode;


    const _isRemotePowerNode = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return nmCt != null && nmCt.includes("-remote-wire-node");
    };
    exports._isRemotePowerNode = _isRemotePowerNode;


    const _isMagnetic = function(ct_gn) {
      return db_block.db["group"]["magnetic"].includes(_nmCt_gn(ct_gn));
    };
    exports._isMagnetic = _isMagnetic;


    const _isFactory = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-fac-",
        "reind-ilfac-",
        "reind-map-fac-",
      );
    };
    exports._isFactory = _isFactory;


    const _isWall = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-def-wall",
        "reind-ildef-wall",
        "reind-map-wall",
      );
    };
    exports._isWall = _isWall;


    /* env */


    const _isEnvBlock = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-env-",
      );
    };
    exports._isEnvBlock = _isEnvBlock;


    const _isMapBlock = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-map-",
      );
    };
    exports._isMapBlock = _isMapBlock;


    const _isTree = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-env-tree-",
      );
    };
    exports._isTree = _isTree;


    const _isDepthOre = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-env-ore-depth-",
      );
    };
    exports._isDepthOre = _isDepthOre;


    const _isDepthLiquid = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-env-ore-dliq-",
      );
    };
    exports._isDepthLiquid = _isDepthLiquid;


    const _isScannerTarget = function(ct_gn) {
      if(_isDepthOre(ct_gn) || _isDepthLiquid(ct_gn)) return true;

      return false;
    };
    exports._isScannerTarget = _isScannerTarget;


    /* unit */


    const _isNonRobot = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return db_unit.db["type"]["nonRobot"].includes(nmCt);
    };
    exports._isNonRobot = _isNonRobot;


    const _isCoreUnit = function(ct_gn) {
      var nmCt = _nmCt_gn(ct_gn);

      return mdl_text.includes_ex(
        nmCt,
        "reind-unit-core-",
      );
    };
    exports._isCoreUnit = _isCoreUnit;


    /* bullet */


    const _isRemoteBullet = function(btp) {
      if(btp == null) return true;
      if(btp instanceof ContinuousBulletType) return true;
      if(btp instanceof LaserBulletType || btp instanceof ShrapnelBulletType) return true;
      if(btp instanceof PointBulletType || btp instanceof RailBulletType || btp instanceof PointLaserBulletType || btp instanceof SapBulletType) return true;
      if(btp instanceof InterceptorBulletType) return true;

      return false;
    };
    exports._isRemoteBullet = _isRemoteBullet;


    /* entity */


    const _canUpdate = function(e) {
      if(e == null) return false;
      if(Vars.state.isEditor()) return false;
      if(e.team == Team.derelict) return false;
      if(e instanceof Building && !e.enabled) return false;

      return true;
    };
    exports._canUpdate = _canUpdate;


    const _isEnemy = function(e, team) {
      if(e == null || team == null) return false;
      if(e.team == Team.derelict || e.team == team) return false;

      return true;
    };
    exports._isEnemy = _isEnemy;


    const _isAiReady = function(unit) {
      if(unit == null) return false;
      if(unit.dead || unit.isPlayer()) return false;

      return true;
    };
    exports._isAiReady = _isAiReady;


    const _isOnFloor = function(unit) {
      if(unit == null) return false;
      if(unit.flying) return false;
      if(unit.hovering && (unit instanceof Legsc)) return false;

      return true;
    };
    exports._isOnFloor = _isOnFloor;


    const _isHeatDamageable = function(unit) {
      if(unit == null) return false;
      if(!_isOnFloor(unit)) return false;
      if(unit.type.naval) return false;

      return true;
    };
    exports._isHeatDamageable = _isHeatDamageable;


    const _isLowGround = function(unit) {
      if(unit == null) return false;
      if(unit.flying) return false;
      if(unit instanceof Legsc) return false;

      return true;
    };
    exports._isLowGround = _isLowGround;


    const _isHighAir = function(unit) {
      if(unit == null) return false;
      if(!unit.flying) return false;
      if(unit.type.lowAltitude) return false;

      return true;
    };
    exports._isHighAir = _isHighAir;


    const _isCoverable = function(unit, includeSize) {
      if(includeSize == null) includeSize = false;

      if(unit == null) return false;
      if(unit.flying || unit.type.groundLayer > 75.9999) return false;
      if(includeSize && unit.type.hitSize > 27.9999) return false;

      return true;
    };
    exports._isCoverable = _isCoverable;


    const _isMoving = function(unit) {
      if(unit == null) return false;

      return unit.vel.len() > (unit.flying ? 0.1 : 0.01);
    };
    exports._isMoving = _isMoving;


    const _isCovered = function(unit) {
      if(unit == null) return false;
      if(unit.hasEffect(Vars.content.statusEffect("reind-sta-spec-hidden-well"))) return true;

      return false;
    };
    exports._isCovered = _isCovered;


    const _isHot = function(unit) {
      if(unit == null) return false;
      if(unit.hasEffect(StatusEffects.burning) || unit.hasEffect(StatusEffects.melting)) return true;
      if(frag_heat._meltTime(unit) > 0.0) return true;

      return false;
    };
    exports._isHot = _isHot;


    const _isDamaged = function(unit) {
      if(unit == null) return false;
      if(unit.hasEffect(Vars.content.effect("reind-sta-spec-damaged")) || unit.hasEffect(Vars.content.effect("reind-sta-spec-severely-damaged"))) return true;

      return false;
    };
    exports._isDamaged = _isDamaged;


    const _isAttacking = function(unit) {
      if(unit == null) return false;

      var mts = unit.mounts;
      var cap = mts.length;
      if(cap == 0) return false;
      for(let i = 0; i < cap; i++) {
        if(mts[i].reload > 0.0) return true;
      };

      return false;
    };
    exports._isAttacking = _isAttacking;


    const _isActing = function(unit) {
      if(unit == null) return false;
      if(_isMoving(unit)) return true;
      if(unit.mining() || unit.isBuilding()) return true;
      if(_isAttacking(unit)) return true;

      return false;
    };
    exports._isActing = _isActing;
  // End


Events.run(ClientLoadEvent, () => {
  Log.info("REIND: mdl_content.js loaded.");
});
