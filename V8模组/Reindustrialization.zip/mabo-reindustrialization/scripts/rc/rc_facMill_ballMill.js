const mdl_recipe = require("reind/mdl/mdl_recipe");


const gi = [
  "reind-effc-effc-ball-impact", 0.01666667,
];


const rc = {
  "parent": "reind-fac-mill-ball-mill",

  "recipes": [


    /* ========================================
      Section: Special
    ======================================== */


    // Fine Aggregate : Chunks (Aggregate)
    {
      "icon": "reind-item-int-chunks-aggregate",
      "category": "special",
      "inputs": [
        "reind-item-int-chunks-aggregate", 20,
      ].concat(gi),
      "outputs": [
        "reind-item-buil-fine-aggregate", 20,
      ],
    },


    // Sandstone
    {
      "icon": "reind-item-ore-sandstone",
      "category": "special",
      "inputs": [
        "reind-item-ore-sandstone", 20,
      ].concat(gi),
      "randOutputs": [
        "reind-item-ore-sand", 60, 0.5,
      ],
    },


    /* ========================================
      Section: Mixing
    ======================================== */


    // Blend (High-Alumina Brick)
    {
      "icon": "reind-item-int-blend-brick-high-alumina",
      "category": "mixing",
      "inputs": [
        "reind-item-int-dust-p1-bauxite", 20,
        "reind-item-ore-clay", 20,
      ].concat(gi),
      "outputs": [
        "reind-item-int-blend-brick-high-alumina", 20,
      ],
    },


    // Blend (Magnesia Brick)
    {
      "icon": "reind-item-int-blend-brick-magnesia",
      "category": "mixing",
      "inputs": [
        "reind-item-chem-magnesia-sand", 20,
        "reind-item-ore-clay", 20,
      ].concat(gi),
      "outputs": [
        "reind-item-int-blend-brick-magnesia", 20,
      ],
    },


    // Blend (Mullite Brick)
    {
      "icon": "reind-item-int-blend-brick-mullite",
      "category": "mixing",
      "inputs": [
        "reind-item-int-dust-p1-bauxite", 10,
        "reind-item-ore-clay", 20,
        "reind-item-bio-sawdust", 10,
      ].concat(gi),
      "outputs": [
        "reind-item-int-blend-brick-mullite", 20,
      ],
    },


    // Blend (Silica Brick)
    {
      "icon": "reind-item-int-blend-brick-silica",
      "category": "mixing",
      "inputs": [
        "reind-item-int-chunks-silica-stone", 20,
        "reind-item-int-chunks-limestone", 10,
        "reind-item-int-chunks-gypsum", 10,
      ].concat(gi),
      "optInputs": [
        "reind-item-chem-coal", 20, 0.65, 1.0,
        "reind-item-chem-semicoke", 20, 0.5, 1.0,
        "reind-item-chem-coke", 20, 0.35, 1.0,
      ],
      "requireOptional": true,
      "outputs": [
        "reind-item-int-blend-brick-silica", 20,
      ],
    },


    /* ========================================
      Section: Pulverization
    ======================================== */


    // Asbestos
    {
      "icon": "reind-item-ore-asbestos",
      "category": "pulverization",
      "inputs": [
        "reind-item-ore-asbestos", 20,
      ].concat(gi),
      "outputs": [
        "reind-item-int-dust-asbestos", 20,
      ],
    },


    // Raw Coal
    {
      "icon": "reind-item-ore-raw-coal",
      "category": "pulverization",
      "inputs": [
        "reind-item-ore-raw-coal", 20,
      ].concat(gi),
      "outputs": [
        "reind-item-int-dust-raw-coal", 20,
      ],
    },


    // Sand
    {
      "icon": "reind-item-ore-sand",
      "category": "pulverization",
      "inputs": [].concat(gi),
      "optInputs": [
        "reind-item-ore-sand", 20, 1.0, 1.0,
        "reind-item-ore-sand-river", 20, 1.0, 1.0,
        "reind-item-ore-sand-sea", 20, 1.0, 1.0,
        "reind-item-ore-sand-basaltic", 20, 1.0, 1.0,
      ],
      "requireOptional": true,
      "outputs": [
        "reind-item-int-dust-sand", 20,
      ],
    },


    // Chunks (Zircon)
    {
      "icon": "reind-item-int-chunks-zircon",
      "category": "pulverization",
      "inputs": [
        "reind-item-int-chunks-zircon", 20,
      ].concat(gi),
      "outputs": [
        "reind-item-int-dust-zircon", 20,
      ],
    },


    // GENERATED


  ],
};


mdl_recipe.__pulverizer_rock(rc, 20, 20, gi, null);
mdl_recipe.__pulverizer_oreDust(rc, 20, 20, gi, null);


exports.rc = rc;
