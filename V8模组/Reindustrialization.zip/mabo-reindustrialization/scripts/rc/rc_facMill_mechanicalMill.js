const mdl_recipe = require("reind/mdl/mdl_recipe");


const gi = [
  "reind-effc-cond-torque", 0.025,
  "reind-liq-ore-water", 0.1,
];
const go = [
  "reind-liq-was-waste-slurry", 0.1,
];


const rc = {
  "parent": "reind-fac-mill-mechanical-mill",

  "recipes": [


    /* ========================================
      Section: Special
    ======================================== */


    // Fine Aggregate : Chunks (Aggregate)
    {
      "icon": "reind-item-int-chunks-aggregate",
      "category": "special",
      "inputs": [
        "reind-item-int-chunks-aggregate", 2,
      ].concat(gi),
      "outputs": [
        "reind-item-buil-fine-aggregate", 2,
      ].concat(go),
    },


    /* ========================================
      Section: Pulverization
    ======================================== */


    // Asbestos
    {
      "icon": "reind-item-ore-asbestos",
      "category": "pulverization",
      "inputs": [
        "reind-item-ore-asbestos", 2,
      ].concat(gi),
      "outputs": [
        "reind-item-int-dust-asbestos", 2,
      ].concat(go),
    },


    // Raw Coal
    {
      "icon": "reind-item-ore-raw-coal",
      "category": "pulverization",
      "inputs": [
        "reind-item-ore-raw-coal", 2,
      ].concat(gi),
      "outputs": [
        "reind-item-int-dust-raw-coal", 2,
      ].concat(go),
    },


    // Sand
    {
      "icon": "reind-item-ore-sand",
      "category": "pulverization",
      "inputs": [].concat(gi),
      "optInputs": [
        "reind-item-ore-sand", 2, 1.0, 1.0,
        "reind-item-ore-sand-river", 2, 1.0, 1.0,
        "reind-item-ore-sand-sea", 2, 1.0, 1.0,
        "reind-item-ore-sand-basaltic", 2, 1.0, 1.0,
      ],
      "requireOptional": true,
      "outputs": [
        "reind-item-int-dust-sand", 2,
      ].concat(go),
    },


    // GENERATED


  ],
};


mdl_recipe.__pulverizer_rock(rc, 2, 2, gi, go, 4);
mdl_recipe.__pulverizer_oreDust(rc, 2, 2, gi, go, 4);


exports.rc = rc;
