const mdl_recipe = require("reind/mdl/mdl_recipe");


const gi = [
  "reind-effc-effc-vibration-screen", 0.01666667,
  "reind-liq-ore-water", 0.15,
];
const go = [
  "reind-liq-was-waste-slurry", 0.15,
];


const rc = {
  "parent": "reind-fac-mill-hammer-crusher",

  "recipes": [


    /* ========================================
      Section: Special
    ======================================== */


    // Coarse Aggregate : Chunks (Aggregate)
    {
      "icon": "reind-item-int-chunks-aggregate",
      "category": "special",
      "inputs": [
        "reind-item-int-chunks-aggregate", 10,
      ].concat(gi),
      "outputs": [
        "reind-item-buil-coarse-aggregate", 10,
      ].concat(go),
    },


    // Fine Aggregate : Coarse Aggregate
    {
      "icon": "reind-item-buil-fine-aggregate",
      "category": "special",
      "inputs": [
        "reind-item-buil-coarse-aggregate", 10,
      ].concat(gi),
      "outputs": [
        "reind-item-buil-fine-aggregate", 10,
      ].concat(go),
    },


    // Coarse Aggregate : Pumice
    {
      "icon": "reind-item-ore-pumice",
      "category": "special",
      "inputs": [
        "reind-item-ore-pumice", 10,
      ].concat(gi),
      "outputs": [
        "reind-item-buil-coarse-aggregate", 10,
      ].concat(go),
    },


    /* ========================================
      Section: Crushing
    ======================================== */


    /* <---------------- aggregate ----------------> */


    // Clastic
    {
      "icon": "reind-item-ore-rock-shard-clastic",
      "category": "crushing",
      "inputs": [
        "reind-item-ore-rock-shard-clastic", 10,
      ].concat(gi),
      "outputs": [
        "reind-item-int-chunks-aggregate", 10,
      ].concat(go),
    },


    // Clastic Sedimentary
    {
      "icon": "reind-item-ore-rock-shard-clastic-sedimentary",
      "category": "crushing",
      "inputs": [
        "reind-item-ore-rock-shard-clastic-sedimentary", 10,
      ].concat(gi),
      "outputs": [
        "reind-item-int-chunks-aggregate", 10,
      ].concat(go),
    },


    // Gangue
    {
      "icon": "reind-item-was-gangue",
      "category": "crushing",
      "inputs": [
        "reind-item-was-gangue", 10,
      ].concat(gi),
      "outputs": [
        "reind-item-was-gangue", 10,
      ].concat(go),
    },


    // GENERATED


  ],
};


mdl_recipe.__rockCrusher_oreChunks(rc, 10, 10, gi, go, 4);


exports.rc = rc;
