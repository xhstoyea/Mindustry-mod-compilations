const mdl_recipe = require("reind/mdl/mdl_recipe");


const gi = [
  "reind-effc-effc-temperature-control", 0.01666667,
  "reind-effc-effc-smoke-exhaust", 0.03333333,
];


const rc = {
  "parent": "reind-fac-furn-primitive-sintering-furnace",

  "recipes": [


    /* ========================================
      Section: Concentrate Sintering
    ======================================== */


    // GENERATED


  ],
};


mdl_recipe.__sinteringFurnace_oreDustP1(rc, 40, 40, gi, null, 950.0, 2.0);


rc["recipes"].pushAll([


  /* ========================================
    Section: Sintering
  ======================================== */


  // Sand
  {
    "icon": "reind-item-int-dust-sand",
    "category": "sintering",
    "inputs": [
      "reind-item-int-dust-sand", 20,
    ].concat(gi),
    "outputs": [
      "reind-item-ore-sand", 20,
    ],
  },


  // GENERATED


]);


mdl_recipe.__sinteringFurnace_oreDust(rc, 20, 20, gi, null, 950.0);


exports.rc = rc;
