/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Import
    const TEMPLATE = require("reind/blk/blk_ventCollector");
  // End


/*
  ========================================
  Section: Region
  ========================================
*/


  // Part: bliq-pump
    const bliqPump_ventCollector = extend(AttributeCrafter, "bliq-pump-vent-collector", {
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      sumAttribute(attr, x, y) {
        return TEMPLATE.sumAttribute(this, attr, x, y);
      },
      canPlaceOn(tile, team, rotation) {
        if(!TEMPLATE.canPlaceOn(this, tile, team, rotation)) return false;
        return true;
      },
      drawPlace(x, y, rotation, valid) {
        this.super$drawPlace(x, y, rotation, valid);
        TEMPLATE.drawPlace(this, x, y, rotation, valid);
      },
      ex_getAttrPair(tile) {
        return TEMPLATE.ex_getAttrPair(this, tile);
      },
      ex_getProdRate(rsTg) {
        return TEMPLATE.ex_getProdRate(this, rsTg);
      },
    });
    bliqPump_ventCollector.buildType = () => extend(AttributeCrafter.AttributeCrafterBuild, bliqPump_ventCollector, {
      timerEffc: new Interval(1), tmpRate: 0.0, transEnd: null,
      needCheck: true, attrPair: null, rsTg: null, rsEffc: null, prodRate: 0.1, craftSound: null,
      updateTile() {
        this.super$updateTile();
        TEMPLATE.updateTile(this);
      },
      shouldConsume() {
        if(!TEMPLATE.shouldConsume(this)) return false;
        return true;
      },
      draw() {
        this.super$draw();
        TEMPLATE.draw(this);
      },
      drawSelect() {
        this.super$drawSelect();
        TEMPLATE.drawSelect(this);
      },
      onDestroyed() {
        this.super$onDestroyed();
        TEMPLATE.onDestroyed(this);
      },
    });
    exports.bliqPump_ventCollector = bliqPump_ventCollector;
  // End




Events.run(ClientLoadEvent, () => {
  Log.info("REIND: ct_blk_ventCollector.js loaded.");
});
