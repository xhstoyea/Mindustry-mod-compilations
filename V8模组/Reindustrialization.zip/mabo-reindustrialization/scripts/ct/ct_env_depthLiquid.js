/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Import
    const TEMPLATE = require("reind/env/env_depthLiquid");
  // End


/*
  ========================================
  Section: Region
  ========================================
*/


  // Part: liq-ore
    const envOre_dliq_water = extend(OverlayFloor, "env-ore-dliq-water", {
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(tile) {
        TEMPLATE.drawBase(this, tile);
      },
    });
    exports.envOre_dliq_water = envOre_dliq_water;


    const envOre_dliq_brine = extend(OverlayFloor, "env-ore-dliq-brine", {
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(tile) {
        TEMPLATE.drawBase(this, tile);
      },
    });
    exports.envOre_dliq_brine = envOre_dliq_brine;


    const envOre_dliq_oil = extend(OverlayFloor, "env-ore-dliq-oil", {
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawBase(tile) {
        TEMPLATE.drawBase(this, tile);
      },
    });
    exports.envOre_dliq_oil = envOre_dliq_oil;
  // End



Events.run(ClientLoadEvent, () => {
  Log.info("REIND: ct_env_depthLiquid.js loaded.");
});
