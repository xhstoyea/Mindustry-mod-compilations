/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Import
    const TEMPLATE = require("reind/blk/blk_depthPump");
  // End


/*
  ========================================
  Section: Region
  ========================================
*/


  // Part: bliq-pump
    const bliqPump_basicDepthPump = extend(AttributeCrafter, "bliq-pump-basic-depth-pump", {
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      sumAttribute(attr, x, y) {
        return TEMPLATE.sumAttribute(this, attr, x, y);
      },
      canPlaceOn(tile, team, rotation) {
        if(!TEMPLATE.canPlaceOn(this, tile, team, rotation)) return false;
        return true;
      },
      ex_getAttrPair(tile) {
        return TEMPLATE.ex_getAttrPair(this, tile);
      },
      ex_getProdRate(rsTg) {
        return TEMPLATE.ex_getProdRate(this, rsTg);
      },
    });
    bliqPump_basicDepthPump.buildType = () => extend(AttributeCrafter.AttributeCrafterBuild, bliqPump_basicDepthPump, {
      timerEffc: new Interval(1), tmpRate: 0.0, transEnd: null,
      needCheck: true, attrPair: null, rsTg: null, rsEffc: null, prodRate: 0.1, craftSound: null,
      timerEffc1: new Interval(1), down: true, b_sc: null,
      updateTile() {
        this.super$updateTile();
        TEMPLATE.updateTile(this);
      },
      shouldConsume() {
        if(!TEMPLATE.shouldConsume(this)) return false;
        return true;
      },
      draw() {
        this.super$draw();
        TEMPLATE.draw(this);
      },
      drawSelect() {
        this.super$drawSelect();
        TEMPLATE.drawSelect(this);
      },
    });
    exports.bliqPump_basicDepthPump = bliqPump_basicDepthPump;
  // End




Events.run(ClientLoadEvent, () => {
  Log.info("REIND: ct_blk_depthPump.js loaded.");
});
