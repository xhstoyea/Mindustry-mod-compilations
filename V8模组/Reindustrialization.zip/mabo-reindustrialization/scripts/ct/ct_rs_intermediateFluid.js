/*
  ========================================
  Section: Definition
  ========================================
*/


  // Part: Import
    const TEMPLATE = require("reind/rs/rs_intermediateFluid");
  // End


/*
  ========================================
  Section: Region
  ========================================
*/


  // Part: liq-int


    /* <---------------- melt ----------------> */


    const liqInt_melt_glass = extend(Liquid, "liq-int-melt-glass", {
      alters: 0,
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(puddle) {
        this.super$update(puddle);
        TEMPLATE.update(this, puddle);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
    });
    exports.liqInt_melt_glass = liqInt_melt_glass;


    /* <---------------- misc ----------------> */


    const liqInt_brinePurified = extend(Liquid, "liq-int-brine-purified", {
      alters: 0,
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(puddle) {
        this.super$update(puddle);
        TEMPLATE.update(this, puddle);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
    });
    exports.liqInt_brinePurified = liqInt_brinePurified;


  // End


  // Part: gas-int


    /* <---------------- crude gas ----------------> */


    /* carbon */


    const gasInt_crudeGas_carbonDioxide = extend(Liquid, "gas-int-crude-gas-carbon-dioxide", {
      alters: 0,
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(puddle) {
        this.super$update(puddle);
        TEMPLATE.update(this, puddle);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
    });
    exports.gasInt_crudeGas_carbonDioxide = gasInt_crudeGas_carbonDioxide;


    /* nitrogen */


    const gasInt_crudeGas_ammonia = extend(Liquid, "gas-int-crude-gas-ammonia", {
      alters: 0,
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(puddle) {
        this.super$update(puddle);
        TEMPLATE.update(this, puddle);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
    });
    exports.gasInt_crudeGas_ammonia = gasInt_crudeGas_ammonia;


    /* sulfur */


    const gasInt_crudeGas_hydrogenSulfide = extend(Liquid, "gas-int-crude-gas-hydrogen-sulfide", {
      alters: 0,
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(puddle) {
        this.super$update(puddle);
        TEMPLATE.update(this, puddle);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
    });
    exports.gasInt_crudeGas_hydrogenSulfide = gasInt_crudeGas_hydrogenSulfide;


    const gasInt_crudeGas_sulfurDioxide = extend(Liquid, "gas-int-crude-gas-sulfur-dioxide", {
      alters: 0,
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(puddle) {
        this.super$update(puddle);
        TEMPLATE.update(this, puddle);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
    });
    exports.gasInt_crudeGas_sulfurDioxide = gasInt_crudeGas_sulfurDioxide;


    /* <---------------- misc ----------------> */


    const gasInt_airClean = extend(Liquid, "gas-int-air-clean", {
      alters: 0,
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(puddle) {
        this.super$update(puddle);
        TEMPLATE.update(this, puddle);
      },
      loadIcon() {
        this.super$loadIcon();
        TEMPLATE.loadIcon(this);
      },
      createIcons(packer) {
        this.super$createIcons(packer);
        TEMPLATE.createIcons(this, packer);
      },
    });
    exports.gasInt_airClean = gasInt_airClean;


  // End


Events.run(ClientLoadEvent, () => {
  Log.info("REIND: ct_rs_intermediateFluid.js loaded.");
});
