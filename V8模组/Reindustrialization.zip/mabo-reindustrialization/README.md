<h1> Reindustrialization </h1>
<p> Welcome to the recipe hell. </p>
<p> This mod is heavily inspired by Greg's Tech from Minecraft, thus being hardcore for a beginner! <p>
<p> Mod contents: </p>
<ul>
  <li> A whole new planet and its tech tree with distinct gameplay. </li>
  <li> Trees that hide your units (and yield logs). </li>
  <li> Production equipments and routes based on processes in real life. </li>
  <li> Multi-crafters with random I/O and more scripts. </li>
  <li> TMI compatibility (you will need it). </li>
  <li> Underground ores and scanners. </li>
  <li> Pipe corrosion based on properties of the fluid and block material. </li>
  <li> Crops that can be harvested. </li>
</ul>
<p> See the credits in game! </p>
