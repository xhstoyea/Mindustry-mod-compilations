const 边陲哨站 = extend(CoreBlock, "边陲哨站", {
	canBreak(tile) {
		return Vars.state.teams.cores(tile.team()).size > 1;
	},
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.cores(team).size < 3;
	}
});