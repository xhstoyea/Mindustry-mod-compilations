const lib = require("planets/library");
const 普罗特 = new Planet("普罗特", Planets.sun, 1, 3.3);
普罗特.meshLoader = prov(() => new MultiMesh(
	new HexMesh(普罗特, 8)
));
普罗特.generator = extend(SerpuloPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nA3JMQ6AIBAAwQXFRr9i4XuMBR5XkCAYkP9LphwcbmLO/lHMwRq0SY3vF0sGluRvTQ17XoZNStU9d0na20gDduAHAc0Org==")
	}
});
普罗特.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(普罗特, 2, 0.15, 0.14, 5, Color.valueOf("D1D1D180"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(普罗特, 3, 0.6, 0.15, 5, Color.valueOf("D1D1D1"), 2, 0.42, 1.2, 0.45)
));
// const 本初核心 = extend(CoreBlock, "本初核心", {});
// exports.本初核心 = 本初核心;
const 边陲哨站 = extend(CoreBlock, "边陲哨站", {})
普罗特.defaultCore = 边陲哨站;
普罗特.generator = new SerpuloPlanetGenerator();
普罗特.visible = 普罗特.accessible = 普罗特.alwaysUnlocked = true;
普罗特.clearSectorOnLose = false;
普罗特.tidalLock = false;
普罗特.localizedName = "普罗特";
普罗特.prebuildBase = false;
普罗特.bloom = false;
普罗特.startSector = 63;
普罗特.orbitRadius = 85;
普罗特.orbitTime = 180 * 60;
普罗特.rotateTime = 90 * 60;
普罗特.atmosphereRadIn = 0.02;
普罗特.atmosphereRadOut = 0.3;
普罗特.atmosphereColor = 普罗特.lightColor = Color.valueOf("D1D1D180");
普罗特.iconColor = Color.valueOf("D1D1D180")
//普罗特.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);
exports.普罗特 = 普罗特;
工业核心.buildVisibility = BuildVisibility.shown
exports.边陲哨站 = 边陲哨站;

