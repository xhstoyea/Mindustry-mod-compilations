this.window = this;

for (let i = 0; i < 8; i++) {
	window["先驱者核心" + i] = new Block("先驱者核心" + i);
};
MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 40000
require('开屏菜单');
require('tank');
//来自爬爬的模组