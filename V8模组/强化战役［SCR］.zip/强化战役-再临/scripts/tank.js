const LightTank = new TankUnitType("回响");
LightTank.constructor = () => new TankUnit.create()
const LightTank = new TankUnitType("幻奏");
LightTank.constructor = () => new TankUnit.create()