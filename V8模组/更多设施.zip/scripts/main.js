MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000
require("物品");
require("blocks/前哨基地");
require("blocks/迭代核心");
require("blocks/最高指挥中心");
require("blocks/护盾");
//require("工厂/灌注站");
//require("工厂/倾倒站");
require("工厂/螺旋压缩机");
require("base/MFlib");
require("base/library");
require("sectorSize");
require("星球/ET");