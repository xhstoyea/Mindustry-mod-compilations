/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const PARAM = require("lovec/glb/GLB_param");
  const VAR = require("lovec/glb/GLB_var");


  const MATH_geometry = require("lovec/math/MATH_geometry");


  const FRAG_unit = require("lovec/frag/FRAG_unit");


  const MDL_cond = require("lovec/mdl/MDL_cond");
  const MDL_draw = require("lovec/mdl/MDL_draw");
  const MDL_effect = require("lovec/mdl/MDL_effect");
  const MDL_entity = require("lovec/mdl/MDL_entity");
  const MDL_pos = require("lovec/mdl/MDL_pos");
  const MDL_ui = require("lovec/mdl/MDL_ui");
  const MDL_util = require("lovec/mdl/MDL_util");


  const DB_block = require("lovec/db/DB_block");
  const DB_unit = require("lovec/db/DB_unit");


  /* <---------- update ----------> */


  function evComp_test() {

  };


  function evComp_unit() {
    Groups.unit.each(unit => {


      FRAG_unit.comp_update_surrounding(unit.type, unit);
      FRAG_unit.comp_update_heat(unit.type, unit);


    });
  };


  /* <---------- draw ----------> */


  function evComp_testDraw() {
    if(!PARAM.testDraw) return;

    var unit_pl = Vars.player.unit();
    if(unit_pl != null) {


      // Param
      // NOTE: Use tmp!
      let t = unit_pl.tileOn();
      let ts = MDL_pos._tsDstManh(t, VAR.r_unitSurRange, true);


      // Draw unit surrounding range
      ts.forEach(ot => MDL_draw.drawArea_tShrink(ot, 1, Pal.accent, 0.5, VAR.lay_debugFlr));


    };

    Groups.unit.forEach(unit => {
      if(MDL_cond._isVisible(unit)) {


        MDL_draw.drawDebug_hitSize(unit);
        MDL_draw.drawDebug_target(unit);


      };
    });

    Groups.bullet.forEach(bul => {
      if(MDL_cond._isVisible(bul)) {


        MDL_draw.drawDebug_hitSize(bul);
        MDL_draw.drawDebug_aim(bul);


      };
    });

  };


  function evComp_unitStat() {
    if(!PARAM.drawUnitStat) return;

    Groups.unit.each(unit => {
      var cond = true;
      if(!MDL_cond._isVisible(unit)) cond = false;
      if((!unit.isPlayer() || !PARAM.drawPlayerStat) && !(unit.type instanceof MissileUnitType) && PARAM.drawUnitNearMouse && MATH_geometry._dst(Core.input.mouseWorldX(), Core.input.mouseWorldY(), unit.x, unit.y) > VAR.rad_mouseRad + unit.type.hitSize * 0.5) cond = false;
      if(unit.type instanceof MissileUnitType && !PARAM.drawMissileStat) cond = false;

      if(cond) {
        MDL_draw.drawUnit_healthBar(
          unit,
          MDL_entity._healthFrac(unit),
          unit.type.hitSize / Vars.tilesize,
          unit.team.color,
          1.0,
          0.0,
          0,
          1.0,
          MDL_entity._armor(unit),
          unit.shield,
          unit.speedMultiplier,
          unit.damageMultiplier * unit.reloadMultiplier,
        );

        if(PARAM.drawUnitReload) {
          for(let i = 0; i < 3; i++) {
            let ids = DB_unit.db["param"]["reloadBarIds"]["off" + i].read(unit.type.name);
            if(ids != null) MDL_draw.drawUnit_reload(
              unit,
              ids,
              Pal.techBlue,
              1.0,
              0.0,
              i,
              null,
            );
          };
        };
      };
    });
  };


  function evComp_buildStat() {
    if(!PARAM.drawBuildStat) return;

    var t = MDL_pos._tMouse();
    var b = t == null ? null : t.build;
    var unit_pl = Vars.player.unit();
    var b_pl = (unit_pl == null || !(unit_pl instanceof BlockUnitc)) ? null : unit_pl.tile();

    // Draw player building
    if(b_pl != null && PARAM.drawPlayerStat) {
      MDL_draw.drawUnit_healthBar(
        b_pl,
        b_pl.health / b_pl.maxHealth,
        b_pl.block.size,
        b_pl.team.color,
        1.0,
        0.0,
        -1.0 + VAR.r_offBuildStat,
        1.0,
        b_pl.block.armor,
        MDL_entity._bShield(b_pl),
        MDL_entity._bSpd(b_pl),
        null,
      );

      if(PARAM.drawUnitReload) {
        let hasReload = DB_block.db["group"]["showReload"].includes(b_pl.block.name);

        if(hasReload) MDL_draw.drawUnit_reload(
          b_pl,
          null,
          Pal.techBlue,
          1.0,
          -16.0,
          -1.25 + VAR.r_offBuildStat,
          MDL_entity._reloadFrac(b_pl),
        );

        MDL_draw.drawUnit_reload(
          b_pl,
          null,
          Pal.accent,
          1.0,
          -16.0,
          (hasReload ? -0.25 : -1.25) + VAR.r_offBuildStat,
          MDL_entity._warmupFrac(b_pl, true),
        );
      };

      MDL_draw.drawRect_normal(b_pl.x, b_pl.y, VAR.r_offBuildStat, b_pl.block.size, Pal.accent, 0.5, false, true);
    };

    // Draw mouse building if not player
    if(b != null && (!PARAM.drawPlayerStat || b !== b_pl)) {
      MDL_draw.drawUnit_healthBar(
        b,
        b.health / b.maxHealth,
        b.block.size,
        b.team.color,
        1.0,
        0.0,
        -1 + VAR.r_offBuildStat,
        1.0,
        b.block.armor,
        MDL_entity._bShield(b),
        MDL_entity._bSpd(b),
        null,
      );

      if(PARAM.drawUnitReload) {
        let hasReload = DB_block.db["group"]["showReload"].includes(b.block.name);

        if(hasReload) MDL_draw.drawUnit_reload(
          b,
          null,
          Pal.techBlue,
          1.0,
          -16.0,
          -1.25 + VAR.r_offBuildStat,
          MDL_entity._reloadFrac(b),
        );

        MDL_draw.drawUnit_reload(
          b,
          null,
          Pal.accent,
          1.0,
          -16.0,
          (hasReload ? -0.25 : -1.25) + VAR.r_offBuildStat,
          MDL_entity._warmupFrac(b, true),
        );
      };

      MDL_draw.drawRect_normal(b.x, b.y, VAR.r_offBuildStat, b.block.size, Pal.accent, 0.5, false, true);
    };
  };


  /* <---------- build destroy ----------> */


  function evComp_damageDisplay1(ev) {
    if(!PARAM.displayDamage) return;

    var bul = ev.source;
    var b = ev.build;
    if(bul == null || b == null) return;

    var dmg = MDL_entity._bulDmg(
      bul,
      bul.type.buildingDamageMultiplier,
      MATH_geometry._dst(bul.x, bul.y, b.x, b.y),
      b.block.armor,
      b.block.size * Vars.tilesize,
    );

    var mode = "health";
    if(MDL_entity._bShield(b, true) > dmg) mode = "shield";

    MDL_effect.showAt_dmg(b.x, b.y, dmg, bul.team, mode);
  };


  /* <---------- unit damage ----------> */


  function evComp_damageDisplay2(ev) {
    if(!PARAM.displayDamage) return;

    var bul = ev.bullet;
    var unit = ev.unit;
    if(bul == null || unit == null) return;
    if(unit.type instanceof MissileUnitType && !PARAM.drawMissileStat) return;

    var dmg = MDL_entity._bulDmg(
      bul,
      1.0 / unit.healthMultiplier,
      MATH_geometry._dst(bul.x, bul.y, unit.x, unit.y),
      MDL_entity._armor(unit),
      unit.type.hitSize,
    );

    var mode = "health";
    if(unit.shield > dmg) mode = "shield";

    MDL_effect.showAt_dmg(unit.x, unit.y, dmg, bul.team, mode);
  };


  /* <---------- unit destroy ----------> */


  function evComp_remains(ev) {
    MDL_effect.showAt_remains(ev.unit.x, ev.unit.y, ev.unit, ev.unit.team);
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  Events.run(Trigger.update, () => {
    evComp_test();
    evComp_unit();
  });


  Events.run(Trigger.draw, () => {
    evComp_testDraw();
    evComp_unitStat();
    evComp_buildStat();
  });


  Events.on(EventType.BuildDamageEvent, ev => {
    evComp_damageDisplay1(ev);
  });


  Events.on(EventType.UnitDamageEvent, ev => {
    evComp_damageDisplay2(ev);
  });


  Events.on(EventType.UnitDestroyEvent, ev => {
    evComp_remains(ev);
  });
