/*
  ========================================
  Section: Introduction
  ========================================
*/


  /* ----------------------------------------
   * NOTE:
   *
   * Method extension to native javascript classes.
   * I don't think a conflict will happen since most guys won't dig deeper in js.
   * ---------------------------------------- */


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- number ----------> */


  var ptp = Number.prototype;


  /* calculation */


  /* ----------------------------------------
   * NOTE:
   *
   * Converts javascript number to java integer.
   * ---------------------------------------- */
  ptp.toInt = function() {
    return new Point2(this, 0).x;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Converts javascript number to java float.
   * ---------------------------------------- */
  ptp.toF = function() {
    return new Vec2(this, 0).x
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Gets a random integer with the number (floored) as maximum.
   * ---------------------------------------- */
  ptp.randInt = function(base) {
    var cap = Math.floor(this);
    if(base == null) base = 0.0;

    return Math.floor(Math.random() * (cap + 1.0 - base) + base);
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Gets how many times something occurs at {p} with the number (floored) as attempts.
   * ---------------------------------------- */
  ptp.randFreq = function(p) {
    var freq = 0;

    let iCap = Math.floor(this);
    for(let i = 0; i < iCap; i++) {
      if(Mathf.chance(p)) freq++;
    };

    return freq;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * To percentage string.
   * ---------------------------------------- */
  ptp.perc = function(deciDigit) {
    return Strings.fixed(this * 100.0, deciDigit == null ? 2 : deciDigit) + "%";
  };


  /* ----------------------------------------
   * NOTE:
   *
   * To scientific notation string.
   * ---------------------------------------- */
  ptp.sci = function(pow, deciDigit) {
    return Strings.fixed(this * Math.pow(10, -pow), deciDigit == null ? 2 : deciDigit) + " × 10^" + pow;
  };


  /* <---------- boolean ----------> */


  var ptp = Boolean.prototype;


  /* calculation */


  /* ----------------------------------------
   * NOTE:
   *
   * Gets the flipped boolean value. Does NOT change the original one.
   * Don't use "===" here or you will get screwed by boolean objects.
   * ---------------------------------------- */
  ptp.conj = function() {
    return this != true;
  };


  /* <---------- string ----------> */


  var ptp = String.prototype;


  /* condition */


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the string contains any piece from {strs}.
   * ---------------------------------------- */
  ptp.includesAny = function(strs) {
    let iCap = strs.iCap();
    if(iCap === 0) return true;
    for(let i = 0; i < iCap; i++) {
      if(this.includes(strs[i])) return true;
    };

    return false;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the string contains all the pieces from {strs}.
   * ---------------------------------------- */
  ptp.includesAll = function(strs) {
    let iCap = strs.iCap();
    if(iCap === 0) return true;
    for(let i = 0; i < iCap; i++) {
      if(!this.includes(strs[i])) return false;
    };

    return true;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the string equals any string from {strs}.
   * ---------------------------------------- */
  ptp.equalsAny = function(strs) {
    let iCap = strs.iCap();
    if(iCap === 0) return true;
    for(let i = 0; i < iCap; i++) {
      if(this == strs[i]) return true;
    };

    return false;
  };


  /* calculation */


  ptp.iCap = function() {
    return Number(this.length);
  };


  /* string calculation */


  /* ----------------------------------------
   * NOTE:
   *
   * Adds color mark.
   * ---------------------------------------- */
  ptp.color = function(color) {
    return "[#" + color.toString() + "]" + this + "[]";
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Example:
   * "Convert this to camelCase".toCamelCase()    // Returns "convertThisToCamelCase"
   * ---------------------------------------- */
  ptp.toCamelCase = function() {
    return this.replace(/(?:^\w|[A-Z]|\b\w)/g, (l, ind) => ind === 0 ? l.toLowerCase() : l.toUpperCase()).replace(/\s+/g, "").replace(/-/g, "");
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Example:
   * "Convert this to kebab-case".toKebabCase()    // Returns "convert-this-to-kebab-case"
   * ---------------------------------------- */
  ptp.toKebabCase = function() {
    return this.replace(/([a-z])([A-Z])/g, "$1-$2").replace(/[\s+_]/g, "-").toLowerCase();
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Example:
   * "convertThisToSnakeCase".toSnakeCase()    // Returns "convert_this_to_snake_case"
   * ---------------------------------------- */
  ptp.toSnakeCase = function() {
    return this.replace(/([a-zA-Z])(?=[A-Z])/g, "$1_").replace(/-/g, "_").toLowerCase();
  };


  /* <---------- array ----------> */


  var ptp = Array.prototype;


  /* test */


  /* ----------------------------------------
   * NOTE:
   *
   * Simply {print}.
   * ---------------------------------------- */
  ptp.print = function() {
    print(this);
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Simply {print} for each element.
   * ---------------------------------------- */
  ptp.printEach = function() {
    this.forEach(i => print(i));
  };


  /* modification */


  /* ----------------------------------------
   * NOTE:
   *
   * Pushes the element only when it is not in the array.
   * ---------------------------------------- */
  ptp.pushUnique = function(ele) {
    if(!this.includes(ele)) this.push(ele);

    return this;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Pushes every element from {arr_p} to the array.
   * {arr_p} can be a single element btw.
   * ---------------------------------------- */
  ptp.pushAll = function(eles_p) {
    !(eles_p instanceof Array) ? this.push(eles_p) : eles_p.forEach(ele => this.push(ele));

    return this;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Removes the first matching element in the array.
   * ---------------------------------------- */
  ptp.remove = function(ele) {
    var ind = this.indexOf(ele);
    if(ind > -1) this.splice(ind, 1);

    return this;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Batch variant of {remove}.
   * ---------------------------------------- */
  ptp.removeAll = function(eles_p) {
    !(eles_p instanceof Array) ? this.remove(eles_p) : eles_p.forEach(ele => this.remove(ele));

    return this;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Removes all matching element in the array.
   * ---------------------------------------- */
  ptp.pull = function(ele) {
    while(this.includes(ele)) {
      this.remove(ele);
    };

    return this;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Batch variant of {pull}.
   * ---------------------------------------- */
  ptp.pullAll = function(eles_p) {
    !(eles_p instanceof Array) ? this.pull(eles_p) : eles_p.forEach(ele => this.pull(ele));

    return this;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Empties the array.
   * ---------------------------------------- */
  ptp.clear = function() {
    this.length = 0;

    return this;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Sets array length and fills it with {val}.
   * ---------------------------------------- */
  ptp.setVal = function(val, len) {
    if(len == null) len = this.length;

    this.length = len;
    for(let ele of this) {
      ele = val;
    };

    return this;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Randomizes the orders of elements in the array.
   * ---------------------------------------- */
  ptp.randomize = function(ord) {
    if(ord == null) ord = 1;

    let iCap = this.iCap();
    if(iCap === 0) return this;
    for(let i = iCap - ord; i > -1; i -= ord) {
      let j = Math.round(Mathf.random(i / ord)) * ord;
      for(let k = 0; k < ord; k++) {
        let tmp = this[i + k];
        this[i + k] = this[j + k];
        this[j + k] = tmp;
      };
    };

    return this;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Replaces elements in the array, using {mapF} as the mapper function.
   * I won't call this REPLACE cauz it returns a new object for string.
   * ---------------------------------------- */
  ptp.substitute = function(mapF, ord, off) {
    if(ord == null) ord = 1;
    if(off == null) off = 0;

    let iCap = this.iCap();
    if(iCap === 0) return this;
    for(let i = 0; i < iCap; i += ord) {
      this[i + off] = mapF(this[i + off]);
    };

    return this;
  };


  /* condition */


  /* ----------------------------------------
   * NOTE:
   *
   * Wether {obj} is an instance of at least one class from this array.
   * ---------------------------------------- */
  ptp.hasIns = function(obj) {
    return this.some(cls => obj instanceof cls);
  };


  /* array condition */


  /* ----------------------------------------
   * NOTE:
   *
   * Wether this array is a subset of another array.
   * ---------------------------------------- */
  ptp.subsetOf = function(arr_tg) {
    const countArr = this.toCountArr();

    let iCap = countArr.iCap();
    if(iCap === 0) return true;
    for(let i = 0; i < iCap; i += 2) {
      let ele = countArr[i];
      let count = countArr[i + 1];

      if(arr_tg.count(ele) < count) return false;
    };

    countArr.clear();
    return true;
  };


  /* calculation */


  ptp.iCap = function() {
    return Number(this.length);
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Sums up numbers in the array.
   * ---------------------------------------- */
  ptp.sum = function(ord, off) {
    var val = 0.0;
    if(ord == null) ord = 1;
    if(off == null) off = 0;

    let iCap = this.iCap();
    if(iCap === 0) return val;
    for(let i = 0; i < iCap; i += ord) {
      let tmpVal = Number(this[i + off]);
      if(!isNaN(tmpVal)) val += tmpVal;
    };

    return val;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * A variant of {sum} that uses values from {mapF}.
   * ---------------------------------------- */
  ptp.sumBy = function(mapF, ord, off) {
    var val = 0.0;
    if(ord == null) ord = 1;
    if(off == null) off = 0;

    let iCap = this.iCap();
    if(iCap === 0) return val;
    for(let i = 0; i < iCap; i+= ord) {
      let tmpVal = Number(this[i + off]);
      if(!isNaN(tmpVal)) val += mapF(tmpVal);
    };

    return val;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Returns average value.
   * ---------------------------------------- */
  ptp.mean = function(ord, off) {
    var val = 0.0;
    if(ord == null) ord = 1;
    if(off == null) off = 0;

    let iCap = this.iCap();
    if(iCap === 0) return val;
    var count = 0;
    for(let i = 0; i < iCap; i += ord) {
      let tmpVal = Number(this[i + off]);
      if(!isNaN(tmpVal)) {
        val += tmpVal;
        count++;
      };
    };

    return count === 0 ? 0.0 : val / count;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * A variant of {mean} that uses values from {mapF}.
   * ---------------------------------------- */
  ptp.meanBy = function(mapF, ord, off) {
    var val = 0.0;
    if(ord == null) ord = 1;
    if(off == null) off = 0;

    let iCap = this.iCap();
    if(iCap === 0) return val;
    var count = 0;
    for(let i = 0; i < iCap; i += ord) {
      let tmpVal = Number(this[i + off]);
      if(!isNaN(tmpVal)) {
        val += mapF(tmpVal);
        count++;
      };
    };

    return count === 0 ? 0.0 : val / count;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Returns power mean.
   * ---------------------------------------- */
  ptp.meanPow = function(pow, ord, off) {
    var val = 0.0;
    if(ord == null) ord = 1;
    if(off == null) off = 0;

    let iCap = this.iCap();
    if(iCap === 0) return val;
    var count = 0;
    for(let i = 0; i < iCap; i += ord) {
      let tmpVal = Number(this[i + off]);
      if(!isNaN(tmpVal)) {
        val += Math.pow(tmpVal, pow);
        count++;
      };
    };

    return count === 0 ? 0.0 : Math.pow(val / count, 1.0 / pow);
  };


  /* ----------------------------------------
   * NOTE:
   *
   * A variant of {meanPow} that uses values from {mapF}.
   * ---------------------------------------- */
  ptp.meanPowBy = function(mapF, pow, ord, off) {
    var val = 0.0;
    if(ord == null) ord = 1;
    if(off == null) off = 0;

    let iCap = this.iCap();
    if(iCap === 0) return val;
    var count = 0;
    for(let i = 0; i < iCap; i += ord) {
      let tmpVal = Number(this[i + off]);
      if(!isNaN(tmpVal)) {
        val += Math.pow(mapF(tmpVal), pow);
        count++;
      };
    };

    return count === 0 ? 0.0 : Math.pow(val / count, 1.0 / pow);
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Counts how many times an element occurs in the array.
   * ---------------------------------------- */
  ptp.count = function(ele, ord, off) {
    var count = 0;
    if(ord == null) ord = 1;
    if(off == null) off = 0;

    let iCap = this.iCap();
    if(iCap === 0) return count;
    for(let i = 0; i < iCap; i += ord) {
      if(this[i + off] === ele) count++;
    };

    return count;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * A variant of {count} that counts only when {boolF} returns {true}.
   * ---------------------------------------- */
  ptp.countBy = function(boolF, ord, off) {
    var count = 0;
    if(ord == null) ord = 1;
    if(off == null) off = 0;

    let iCap = this.iCap();
    if(iCap === 0) return count;
    for(let i = 0; i < iCap; i += ord) {
      if(boolF(this[i + off])) count++;
    };

    return count;
  };


  /* array calculation */


  /* ----------------------------------------
   * NOTE:
   *
   * Example:
   * [0, 1, 2, 1, 2, 3, 0, 4, 5].unique();    // Returns [0, 1, 2, 3, 4, 5]
   * ---------------------------------------- */
  ptp.unique = function() {
    const arr = [];

    let iCap = this.iCap();
    if(iCap === 0) return arr;
    for(let i = 0; i < iCap; i++) {
      let ele = this[i];
      if(!arr.includes(ele)) arr.push(ele);
    };

    return arr;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * A variant of {unique} that uses values from {mapF}.
   * ---------------------------------------- */
  const tmpArr_arrUniqueBy = [];
  ptp.uniqueBy = function(mapF) {
    const arr = [];

    let iCap = this.iCap();
    if(iCap === 0) return arr;
    for(let i = 0; i < iCap; i++) {
      let ele = this[i];
      let tmpEle = mapF(ele);
      if(!tmpArr_arrUniqueBy.includes(tmpEle)) {
        arr.push(ele);
        tmpArr_arrUniqueBy.push(tmpEle);
      };
    };

    tmpArr_arrUniqueBy.clear();
    return arr;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Example:
   * [0, 1, 2, 3, 4].intersect([2, 3, 4, 5, 6]);    // Returns [2, 3, 4]
   * ---------------------------------------- */
  ptp.intersect = function(eles_p) {
    const arr = [];

    let iCap = this.iCap();
    if(iCap === 0) return arr;
    for(let i = 0; i < iCap; i++) {
      let ele = this[i];
      if(!(eles_p instanceof Array) ? ele === eles_p : eles_p.includes(ele)) arr.push(ele);
    };

    return arr;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * A variant of {intersect} that uses values from {mapF}.
   * ---------------------------------------- */
  const tmpArr_arrIntersectBy = [];
  ptp.intersectBy = function(eles_p, mapF) {
    if(eles_p instanceof Array) eles_p.forEach(ele => tmpArr_arrIntersectBy.push(mapF(ele)));
    const arr = [];

    let iCap = this.iCap();
    if(iCap === 0) return arr;
    for(let i = 0; i < iCap; i++) {
      let ele = this[i];
      let tmpEle = mapF(ele);
      if(!(eles_p instanceof Array) ? tmpEle === mapF(eles_p) : tmpArr_arrIntersectBy.includes(tmpEle)) arr.push(ele);
    };

    tmpArr_arrIntersectBy.clear();
    return arr;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Example:
   * [0,1,2,3,4,5,6].chunk(3);    // Returns [[0, 1, 2], [3, 4, 5], [6]]
   * ---------------------------------------- */
  ptp.chunk = function(ord) {
    const arr = [];
    if(ord == null) ord = 1;

    let iCap = this.iCap();
    if(iCap === 0) return arr;
    for(let i = 0, j = 0; i < iCap; i += ord) {
      let tmpArr = [];
      while(j < ord) {
        let ele = this[i + j];
        if(ele !== undefined) tmpArr.push(ele);
        j++;
      };
      j = 0;
      arr.push(tmpArr);
    };

    return arr;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Returns a index array.
   *
   * Example:
   * [5, 6, 9, 0, 1].toIndArr()    // Returns [0, 1, 2, 3, 4]
   * [5, 6, 9, 0, 1].toIndArr(true)    // Returns [1, 2, 3, 4, 5]
   * ---------------------------------------- */
  ptp.toIndArr = function(isStatistical) {
    const arr = [];

    let iCap = this.iCap();
    if(iCap === 0) return arr;
    for(let i = 0; i < iCap; i++) {
      arr.push(isStatistical ? i + 1 : i);
    };

    return arr;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Returns a 2-ordered count array.
   *
   * Example:
   * [0, 0, 1, 2, 3, 3, 3, 4].toCountArr()    // Returns [0, 2, 1, 1, 2, 1, 3, 3, 4, 1]
   * ---------------------------------------- */
  ptp.toCountArr = function(ord, off) {
    const arr = [];
    if(ord == null) ord = 1;
    if(off == null) off = 0;

    let iCap = this.iCap();
    if(iCap === 0) return arr;
    for(let i = 0; i < iCap; i += ord) {
      let ele = this[i + off];
      if(arr.read(ele, 0) === 0) {
        arr.push(ele);
        arr.push(this.count(ele));
      };
    };

    return arr;
  };


  /* data */


  /* ----------------------------------------
   * NOTE:
   *
   * How many rows (or lines) this array has at given order.
   *
   * Example:
   * [0, 1, 2, 0, 2, 3, 0, 3, 4, 0].rowAmt(3);    // Returns 4
   * ---------------------------------------- */
  ptp.rowAmt = function(ord) {
    if(this.length === 0) return 0;
    if(ord == null) ord = 1;

    return (this.length - this.length % ord) / ord + Number(this.length % ord !== 0);
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Reads data from a formatted array.
   * Use {def} for default value.
   * If there are multiple matching results, this only returns the first one.
   * ---------------------------------------- */
  ptp.read = function(nms_p, def) {
    let iCap = this.iCap();
    if(iCap === 0) return def;
    const nms = (nms_p instanceof Array) ? nms_p : [nms_p];
    let iCap1 = nms.iCap();
    for(let i = 0; i < iCap; i += iCap1 + 1) {
      if((function(arr) {
        for(let j = 0; j < iCap1; j++) {if(arr[i + j] != nms[j]) return false};
        return true;
      }) (this)) return this[i + iCap1];
    };

    nms.clear();
    return def;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Returns an array of elements with the same offset (in the same column) in a formatted array.
   * ---------------------------------------- */
  ptp.readCol = function(ord, off) {
    const arr = [];
    if(ord == null) ord = 1;
    if(off == null) off = 0;

    let iCap = this.iCap();
    if(iCap === 0) return arr;
    for(let i = 0; i < iCap; i += ord) {
      arr.push(this[i + off]);
    };

    return arr;
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Returns a random element.
   * ---------------------------------------- */
  ptp.readRand = function(ord, off) {
    if(this.length === 0) return null;

    if(ord == null) ord = 1;
    if(off == null) off = 0;

    return this[Math.round(Number(this.rowAmt(ord) - 1).randInt() * ord + off)];
  };


  /* ----------------------------------------
   * NOTE:
   *
   * Reads data from a formatted array, and returns the results as an array.
   * Mostly useful when there are multiple matching results.
   * ---------------------------------------- */
  ptp.readList = function(nms_p) {
    const arr = [];

    let iCap = this.iCap();
    if(iCap === 0) return arr;
    const nms = (nms_p instanceof Array) ? nms_p : [nms_p];
    let iCap1 = nms.iCap();
    for(let i = 0; i < iCap; i += iCap1 + 1) {
      if((function(arr) {
        for(let j = 0; j < iCap1; j++) {if(arr[i + j] !== nms[j]) return false};
        return true;
      }) (this)) arr.push(this[i + iCap1]);
    };

    nms.clear();
    return arr;
  };
