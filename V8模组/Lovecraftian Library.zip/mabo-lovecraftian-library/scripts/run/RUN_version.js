/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  // NOTE: Nope, this should be completely independent.


  /* <---------- base ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Checks if dependencies are all valid.
   * Returns {true} if mod not found or minimum version unmet, and shows error message.
   * Expected to be called on top of everything in main.js.
   * You should code what will happen next.
   *
   * {minVerMap} is a 2-ordered array of {nmDepend} and {minVer}.
   * {nmDepend} is the name of dependency.
   * {minVer} is the version of dependency, it should be a number. And the mod version should be a number in format.
   * Example line:
   * "lovec", 100,
   * ---------------------------------------- */
  const checkVersion = function(nmMod, minVerMap) {
    var str = "[gray]Unmet dependency for " + nmMod + "!\n";
    str += "\n--------------------------------";
    var cond = false;

    var iCap = minVerMap.length;
    if(iCap === 0) return;
    for(let i = 0; i < iCap; i += 2) {

      let nmDepend = minVerMap[i];
      let minVer = minVerMap[i + 1];
      let ver = -1.0;

      let mod = Vars.mods.locateMod(nmDepend);
      if(mod != null) {
        ver = Number(mod.meta.version);
        if(isNaN(ver)) ver = 0.0;
      };
      if(ver >= minVer) continue;

      cond = true;
      str += "\n" + nmDepend + "        " + minVer + "        " + (ver < 0.0 ? "!NOTFOUND" : "!OUTDATED");

    };
    str += "\n--------------------------------";
    str += "\n[]";

    if(cond) {
      Events.run(ClientLoadEvent, () => Vars.ui.showErrorMessage(str));
    };

    return cond;
  };
  exports.checkVersion = checkVersion;
