/*
  ========================================
  Section: Introduction
  ========================================
*/


  /* ----------------------------------------
   * NOTE:
   *
   * Adds some methods to {global} so you can use them in game, if you know how to use console.
   * ---------------------------------------- */


/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const EFF = require("lovec/glb/GLB_eff");


  const MATH_base = require("lovec/math/MATH_base");
  const MATH_geometry = require("lovec/math/MATH_geometry");
  const MATH_statistics = require("lovec/math/MATH_statistics");


  const FRAG_faci = require("lovec/frag/FRAG_faci");


  const MDL_effect = require("lovec/mdl/MDL_effect");
  const MDL_event = require("lovec/mdl/MDL_event");
  const MDL_file = require("lovec/mdl/MDL_file");
  const MDL_json = require("lovec/mdl/MDL_json");
  const MDL_test = require("lovec/mdl/MDL_test");
  const MDL_util = require("lovec/mdl/MDL_util");


  const TP_dial = require("lovec/tp/TP_dial");
  const TP_effect = require("lovec/tp/TP_effect");
  const TP_table = require("lovec/tp/TP_table");


  /* <---------- tool ----------> */


  var propListenerState = false;
  const propListenerTimer = new Interval(1);
  var propListenerIntv = 120.0;
  var propListenerGetter = null;
  var propListenerInd = 1;


/*
  ========================================
  Section: Application
  ========================================
*/


  MDL_event._c_onLoad(() => {
    global.lovec = {


      glb_eff: EFF,


      math_base: MATH_base,
      math_geometry: MATH_geometry,
      math_statistics: MATH_statistics,


      mdl_file: MDL_file,
      mdl_json: MDL_json,
      mdl_effect: MDL_effect,


      tp_dial: TP_dial,
      tp_effect: TP_effect,
      tp_table: TP_table,


      print: {


        printLiq(tx, ty) {
          MDL_test._i_liq(tx, ty);
        },


        printCep(team) {
          if(!Vars.state.isGame()) {
            MDL_test._i_notInGame();
            return;
          };

          if(team == null) team = Vars.player.team();
          Log.info(
            "[LOVEC] CEP stats for " + team.toString().color(team.color)
            + "\n- CEP provided: " + Strings.fixed(FRAG_faci._cepCapCur(team), 2)
            + "\n- CEP used: " + Strings.fixed(FRAG_faci._cepUseCur(team), 2)
            + "\n- CEP fraction: " + Number(FRAG_faci._cepFracCur(team)).perc()
            + "\n- CEP efficiency: " + Number(FRAG_faci._cepEffcCur(team)).perc()
          );
        },


      },


      tool: {


        propListener: {


          setState(bool) {
            propListenerState = Boolean(bool);

            propListenerInd = 1;
          },


          setProp(propGetter) {
            propListenerGetter = null;
            if(propGetter != null && propGetter instanceof Function) propListenerGetter = propGetter;

            propListenerInd = 1;
          },


          setInterval(time) {
            propListenerIntv = Mathf.clamp(time, 6.0, 600.0);
            if(isNaN(propListenerIntv)) propListenerIntv = 120.0;

            propListenerInd = 1;
          },


        },


        timeControl(param) {
          var timeScl = Number(param);
          // NOTE: Too large {timeScl} will BREAK your save forever.
          if(isNaN(timeScl) || timeScl < 0.0 || timeScl > 50.0) {
            MDL_test._i_invalidArgs();
            return;
          };

          Time.setDeltaProvider(() => Core.graphics.getDeltaTime() * 60.0 * timeScl);
          MDL_test._i_timeControl(timeScl);
        },


        cheat() {
          Core.scene.add(TP_table._winDial("NOPE", tb => {
            tb.add("[red]Just no way.[]");
          }));

          Log.info("[LOVEC] Nice try :)");
        },


      },


    };
  }, 75112593);


  MDL_event._c_onUpdate(() => {


    // Property listener
    if(propListenerState && propListenerGetter != null && propListenerTimer.get(propListenerIntv)) {
      let prop = propListenerGetter();
      if(prop instanceof Array) {

        let str = "[LOVEC] Property listener (" + propListenerInd + "): [accent](";
        for(let ele of prop) {
          str += String(ele) + ", ";
        };
        str += ")[]";

        Log.info(str);

      } else {
        Log.info("[LOVEC] Property listener (" + propListenerInd + "): " + String(prop).color(Pal.accent));
      };

      propListenerInd++;
    };


  }, 62543995);
