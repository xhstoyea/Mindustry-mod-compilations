/*
  ========================================
  Section: Introduction
  ========================================
*/


  /* ----------------------------------------
   * NOTE:
   *
   * Another part of extension called later than {RUN_methodExt}.
   * ---------------------------------------- */


/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


/*
  ========================================
  Section: Application
  ========================================
*/


  require("lovec/run/jsExt/RUN_jsPostExt_function");
  require("lovec/run/jsExt/RUN_jsPostExt_class");
