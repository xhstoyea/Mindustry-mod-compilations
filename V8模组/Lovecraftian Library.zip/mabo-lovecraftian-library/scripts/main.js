/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  // NOTE: Keep these at top!
  const RUN_methodExt = require("lovec/run/RUN_methodExt");
  const VARGEN = require("lovec/glb/GLB_varGen");


  const PARAM = require("lovec/glb/GLB_param");


  const RUN_event = require("lovec/run/RUN_event");
  const RUN_memMonitor = require("lovec/run/RUN_memMonitor");


  const FRAG_faci = require("lovec/frag/FRAG_faci");


  const MDL_bundle = require("lovec/mdl/MDL_bundle");
  const MDL_event = require("lovec/mdl/MDL_event");
  const MDL_util = require("lovec/mdl/MDL_util");
  const MDL_content = require("lovec/mdl/MDL_content");


  const DB_env = require("lovec/db/DB_env");
  const DB_status = require("lovec/db/DB_status");


  const TP_dial = require("lovec/tp/TP_dial");
  const TP_stat = require("lovec/tp/TP_stat");
  const TP_table = require("lovec/tp/TP_table");


  // NOTE: Keep this at bottom!
  const RUN_global = require("lovec/run/RUN_global");


  /* <---------- load ----------> */


  const CT_STA_baseStatus = require("lovec/ct/CT_STA_baseStatus");
  const CT_STA_liquidStatus = require("lovec/ct/CT_STA_liquidStatus");
  const CT_STA_burstStatus = require("lovec/ct/CT_STA_burstStatus");


/*
  ========================================
  Section: Application
  ========================================
*/


  MDL_util.setMod_localization("lovec");


  MDL_event._c_onLoad(() => {


    // Set node root names
    if(!Vars.headless) {
      TechTree.roots.each(rt => {
        let nmCt = DB_env.db["nodeRootNameMap"].read(rt.name);
        if(nmCt != null) {
          let ct = MDL_content._ct(nmCt);
          if(ct != null) rt.name = ct.localizedName;
        };
      });
    };


    // Set robot only status
    DB_status.db["group"]["robotOnly"].map(nmSta => MDL_content._ct(nmSta, "sta")).forEach(sta => {
      if(sta != null) {
        sta.stats.add(TP_stat.sta_robotOnly, true);
        VARGEN.bioticUtps.forEach(utp => utp.immunities.add(sta));
      };
    });


    // Set oceanic status
    DB_status.db["group"]["oceanic"].map(nmSta => MDL_content._ct(nmSta, "sta")).forEach(sta => {
      if(sta != null) {
        VARGEN.navalUtps.forEach(utp => utp.immunities.add(sta));
      };
    });


    // Set settings
    // NOTE: I don't think there's need to create a module for this. Just check {MDL_util._cfg()}.
    Vars.ui.settings.addCategory(MDL_bundle._term("lovec", "settings"), tb => {

      tb.checkPref("lovec-test-draw", false);
      tb.checkPref("lovec-test-memory", false);

      tb.sliderPref("lovec-interval-efficiency", 5, 1, 15, val => Strings.fixed(val * 0.1, 2) + "s");

      tb.checkPref("lovec-draw-wobble", false);
      tb.checkPref("lovec-draw0shadow-blurred", true);
      tb.sliderPref("lovec-draw0tree-alpha", 10, 0, 10, val => Strings.fixed(val * 10.0, 0) + "%");
      tb.checkPref("lovec-draw0tree-shadow", true);
      tb.checkPref("lovec-draw0tree-player", true);
      tb.checkPref("lovec-draw0aux-bridge", true);
      tb.checkPref("lovec-draw0aux-router", true);

      tb.checkPref("lovec-icontag-show", true);
      tb.sliderPref("lovec-icontag-interval", 6, 1, 12, val => Strings.fixed(val * 0.33333333, 2) + "s");

      tb.checkPref("lovec-damagedisplay-show", true);
      tb.checkPref("lovec-unit0stat-show", true);
      tb.checkPref("lovec-unit0stat-player", true);
      tb.checkPref("lovec-unit0stat-reload", true);
      tb.checkPref("lovec-unit0stat-missile", false);
      tb.checkPref("lovec-unit0stat-build", true);
      tb.checkPref("lovec-unit0stat-mouse", true);
      tb.sliderPref("lovec-unit0remains-lifetime", 12, 0, 60, val => Strings.fixed(val * 5.0, 0) + "s");

    });


  }, 12563333);
