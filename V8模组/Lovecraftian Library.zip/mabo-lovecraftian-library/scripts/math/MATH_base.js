/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  /* <---------- util ----------> */


  const maxDst = 99999999.0;
  exports.maxDst = maxDst;


  const maxTime = 99999999.0;
  exports.maxTime = maxTime;


  const fEqual = function(num, param, tol) {
    if(tol == null) tol = 0.0001;

    return Math.abs(num - param) < tol;
  };
  exports.fEqual = fEqual;


  const _interp = function(val_f, val_t, param, interp, param_f, param_t) {
    if(interp == null) interp = Interp.linear;
    if(param_f == null) param_f = 0.0;
    if(param_t == null) param_t = 1.0;
    if(fEqual(param_f, param_t)) return val_f;

    return val_f + interp.apply((param - param_f) / (param_t - param_f)) * (val_f - val_t);
  };
  exports._interp = _interp;
