/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const MDL_content = require("lovec/mdl/MDL_content");


  /* <---------- const ----------> */


  const tmpBatches = [
    [],
    [],
    [],
    [],
    [],
  ];
  exports.tmpBatches = tmpBatches;


  /* <---------- item module ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Adds item to {b}, with {b_f} as the source. Returns {true} if succeeded.
   * {amt} is quite straightforward, amount.
   * {p} is the chance at which each item is added, used for random input.
   * ---------------------------------------- */
  const addItem = function(b, b_f, itm, amt, p) {
    if(b == null || itm == null) return false;
    if(b.items == null || !b.acceptItem(b_f, itm)) return false;

    if(amt == null) amt = 1;
    if(amt < 0.0001) return false;
    if(p == null) p = 1.0;

    for(let i = 0; i < amt; i++) {
      if(!b.acceptItem(b_f, itm)) break;

      if(Mathf.chance(p)) b.offload(itm);
    };

    return true;
  };
  exports.addItem = addItem;


  const consumeItem = function(b, itm, amt, p) {
    if(b == null || itm == null) return false;
    if(b.items == null) return false;

    if(amt == null) amt = 1;
    if(amt < 0.0001) return false;
    if(p == null) p = 1.0;

    if(p > 0.9999) {b.items.remove(itm, amt)} else {
      for(let i = 0; i < amt; i++) {
        if(Mathf.chance(p)) b.items.remove(itm, 1);
      };
    };

    return true;
  };
  exports.consumeItem = consumeItem;


  /* ----------------------------------------
   * NOTE:
   *
   * Adds items in a batch to {b}.
   *
   * A batch is a 3-ord array with {ct_gn}, {amt} and {p}.
   * Sometimes liquid is also a valid input, not for now.
   *
   * Exmaple:
   * batch = [
   *   Items.copper, 5, 0.5,
   *   "lead", 10, 0.5,
   * ];
   * ---------------------------------------- */
  const addItemBatch = function(b, b_f, batch) {
    if(b == null || batch == null) return false;
    if(b.items == null) return false;

    var iCap = batch.iCap();
    if(iCap === 0) return false;
    var bool = false;
    for(let i = 0; i < iCap; i += 3) {
      var itm = MDL_content._ct(batch[i]);
      var amt = batch[i + 1];
      var p = batch[i + 2];

      if(itm != null && itm instanceof Item) {
        if(addItem(b, b_f, itm, amt, p)) bool = true;
      };
    };

    return bool;
  };
  exports.addItemBatch = addItemBatch;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether {b} can accept the item batch.
   * Use {mode} carefully, if set to {"any"}, some items may go to the void.
   * ---------------------------------------- */
  const modes_acceptItemBatch = ["any, all"];
  const acceptItemBatch = function(b, b_f, batch, mode) {
    if(b == null || batch == null) return false;
    if(b.items == null) return false;

    if(mode == null) mode = "all";
    if(!mode.equalsAny(modes_acceptItemBatch)) return false;

    var iCap = batch.iCap();
    if(iCap === 0) return false;
    if(mode === "any") {

      for(let i = 0; i < iCap; i += 3) {
        var itm = MDL_content._ct(batch[i]);

        if(itm != null && itm instanceof Item) {
          if(b.acceptItem(b_f, itm)) return true;
        };
      };

      return false;

    } else {

      for(let i = 0; i < iCap; i += 3) {
        var itm = MDL_content._ct(batch[i]);

        if(itm != null && itm instanceof Item) {
          if(!b.acceptItem(b_f, itm)) return false;
        };
      };

      return true;

    };
  };
  exports.acceptItemBatch = acceptItemBatch;


  /* <---------- component ----------> */


  /* exposed */


  const comp_updateTile_exposed = function(b) {
    // TODO
  };
  exports.comp_updateTile_exposed = comp_updateTile_exposed;


  const comp_onDestroyed_exposed = function(b) {
    // TODO
  };
  exports.comp_onDestroyed_exposed = comp_onDestroyed_exposed;


  /* virtual */


  const comp_updateTile_virtual = function(b) {
    // TODO
  };
  exports.comp_updateTile_virtual = comp_updateTile_virtual;
