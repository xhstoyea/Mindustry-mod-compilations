/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const VAR = require("lovec/glb/GLB_var");


  const MDL_cond = require("lovec/mdl/MDL_cond");
  const MDL_effect = require("lovec/mdl/MDL_effect");
  const MDL_ui = require("lovec/mdl/MDL_ui");


  const DB_fluid = require("lovec/db/DB_fluid");


  /* <---------- liquid module ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Adds liquid to {b}, with {b_f} as the source.
   * Returns the amount of liquid transfered.
   * ---------------------------------------- */
  const addLiquid = function(b, b_f, liq, rate) {
    var amt_trans = 0.0;
    if(b == null || liq == null) return amt_trans;
    if(b.liquids == null || !b.acceptLiquid(b_f, liq)) return amt_trans;

    if(rate == null) rate = 0.0;
    if(Math.abs(rate) < 0.0001) return amt_trans;

    amt_trans = rate > 0.0 ? Math.min(rate * b.edelta(), b.block.liquidCapacity - b.liquids.get(liq)) : -Math.min(-rate * b.edelta(), b.liquids.get(liq));
    b.liquids.add(liq, amt_trans);

    return amt_trans;
  };
  exports.addLiquid = addLiquid;


  /* ----------------------------------------
   * NOTE:
   *
   * Like {addLiquid()} but {b_f} is required, since it's transportation.
   * From {b_f} to {b}, uses efficiency of {b_f} by default.
   * Set {isActiveTrans} to {true} to use the efficiency of {b} instead, e.g. in liquid unloaders.
   * ---------------------------------------- */
  const transferLiquid = function(b, b_f, liq, rate, isActiveTrans) {
    var amt_trans = 0.0;
    if(b == null || b_f == null || liq == null) return amt_trans;
    if(b.liquids == null || b_f.liquids == null || !b.acceptLiquid(b_f, liq)) return amt_trans;

    if(rate == null) rate = 0.0;
    if(Math.abs(rate) < 0.0001) return amt_trans;

    var amt_f = b_f.liquids.get(liq);
    if(amt_f < 0.0001) return amt_trans;
    var amt = b.liquids.get(liq);
    var cap = b.block.liquidCapacity;
    amt_trans = Math.min(Mathf.clamp((isActiveTrans ? b.edelta() : b_f.edelta()) * rate, 0.0, cap - amt), amt_f);

    b.handleLiquid(b_f, liq, amt_trans);
    b_f.liquids.remove(liq, amt_trans);

    return amt_trans;
  };
  exports.transferLiquid = transferLiquid;


  /* ----------------------------------------
   * NOTE:
   *
   * Gets the transportation destination.
   * Any building with the tag {"fjunc"} will be considered a junction.
   * ---------------------------------------- */
  const _liqEnd = function(b, b_t) {
    if(b == null || b_t == null) return;
    if(b.liquids == null) return;
    if(!MDL_cond._isFJunc(b_t.block)) return b_t;

    var rot_t = b.relativeTo(b_t);
    var end = "tmp";
    var t = b_t.tile;
    while(end === "tmp") {
      end = (t == null) ? null : t.build;
      if(end != null && MDL_cond._isFJunc(end.block) && end.team == b.team) {
        t = end.tile.nearby(rot_t);
        end = "tmp";
      };
    };

    return end;
  };
  exports._liqEnd = _liqEnd;


  /* <---------- component ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Puddles will exist even when {NaN} occurs, they are invisible and break the save permanently somehow.
   * ---------------------------------------- */
  const comp_update_fix = function(liq, puddle) {
    if(isNaN(puddle.amount)) puddle.remove();
  };
  exports.comp_update_fix = comp_update_fix;


  /* ----------------------------------------
   * NOTE:
   *
   * The puddle fumes, that's it.
   * ---------------------------------------- */
  const comp_update_fuming = function(liq, puddle) {
    if(liq.gas) return;
    if(!Mathf.chanceDelta(MDL_effect._p_frac(0.03, puddle.amount * 0.04))) return;
    if(!DB_fluid.db["group"]["fuming"].includes(liq.name)) return;

    //MDL_effect.showAt(puddle.x, puddle.y, VAR.eff_heatSmog);
  };
  exports.comp_update_fuming = comp_update_fuming;


  /* ----------------------------------------
   * NOTE:
   *
   * If a block can short-circuit and it's soaked in a condutive puddle...
   * Check {DB_block.db["group"]["shortCircuit"]}.
   * ---------------------------------------- */
  const comp_update_shortCircuit = function(liq, puddle) {

  };
  exports.comp_update_shortCircuit = comp_update_shortCircuit;


  /* ----------------------------------------
   * NOTE:
   *
   * How puddles call {MDL_reaction}.
   * ---------------------------------------- */
  const comp_update_puddleReaction = function(liq, puddle) {
    // TODO
  };
  exports.comp_update_puddleReaction = comp_update_puddleReaction;


  /* ----------------------------------------
   * NOTE:
   *
   * The building will be destroyed if it contains abstract fluid.
   * Well, it only happens if you cheat or have found yet another bug.
   * ---------------------------------------- */
  const comp_updateTile_effc = function(b) {
    if(b == null) return;
    if(b.liquids == null || !Mathf.chanceDelta(0.04)) return;
    if(MDL_cond._isEffcBlk(b.block)) return;

    if(MDL_cond._isEffc(b.liquids.current())) {
      b.kill();
      MDL_effect.showAt_regFade(b.x, b.y, Icon.cancel, Color.scarlet);
      MDL_ui.showInfoFade("lovec", "trans-abstract-fluid");
    };
  };
  exports.comp_updateTile_effc = comp_updateTile_effc;


  /* ----------------------------------------
   * NOTE:
   *
   * Prevents the building from storing a large amount of abstract fluid.
   * If the abstract fluid is an exception (e.g. heat), it should have the tag {"rs-nocap0effc"}.
   * ---------------------------------------- */
  const comp_updateTile_capEffc = function(b) {
    if(b == null) return;
    if(b.liquids == null || !Mathf.chanceDelta(0.02)) return;

    var limit = VAR.rs_effcCap;
    b.liquids.each(liq => {
      if(MDL_cond._isEffc(liq) && !MDL_cond._isNoCapEffc(liq) && b.liquids.get(liq) > limit) b.liquids.set(liq, limit);
    });
  };
  exports.comp_updateTile_capEffc = comp_updateTile_capEffc;
