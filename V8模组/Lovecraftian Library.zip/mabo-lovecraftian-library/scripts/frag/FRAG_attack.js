/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const MDL_effect = require("lovec/mdl/MDL_effect");
  const MDL_entity = require("lovec/mdl/MDL_entity");


  /* <---------- base ----------> */


  const damage = function(e, dmg, pierceArmor, flashBuilding) {
    if(e == null) return;
    if(dmg < 0.0001) return;

    var dmg_fi = MDL_entity._dmgTake(e, dmg, pierceArmor);
    if(e instanceof Building) {
      MDL_effect.showAt_dmg(e.x, e.y, dmg, null, MDL_entity._bShield(e, true) > dmg_fi ? "shield" : "health");
      if(flashBuilding) MDL_effect.showAt_flash(e);
    } else {
      MDL_effect.showAt_dmg(e.x, e.y, dmg, null, e.shield > dmg_fi ? "shield" : "health");
    };

    pierceArmor ? e.damagePierce(dmg, true) : e.damage(dmg, true);
  };
  exports.damage = damage;


  /* <---------- ranged ----------> */
