/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TIMER = require("lovec/glb/GLB_timer");
  const VARGEN = require("lovec/glb/GLB_varGen");


  const MDL_bundle = require("lovec/mdl/MDL_bundle");
  const MDL_cond = require("lovec/mdl/MDL_cond");
  const MDL_content = require("lovec/mdl/MDL_content");
  const MDL_draw = require("lovec/mdl/MDL_draw");
  const MDL_event = require("lovec/mdl/MDL_event");


  const TP_attr = require("lovec/tp/TP_attr");
  const TP_stat = require("lovec/tp/TP_stat");


  const DB_block = require("lovec/db/DB_block");


  /* <---------- core ----------> */


  const cepCapMap = new ObjectMap();
  const cepUseMap = new ObjectMap();
  const cepFracMap = new ObjectMap();
  const cepEffcMap = new ObjectMap();


  const _cepProv = function(blk_gn, b) {
    var blk = MDL_content._ct(blk_gn, "blk");
    var tmp = blk == null ? 0.0 : DB_block.db["param"]["cep"]["prov"].read(blk.name, MDL_cond._isCoreBlock(blk) ? 5.0 : 0.0);

    if(typeof tmp === "function") {
      return b == null ? 0.0 : tmp(b);
    } else return tmp;
  };
  exports._cepProv = _cepProv;


  const _cepUse = function(blk_gn, b) {
    var blk = MDL_content._ct(blk_gn, "blk");
    var tmp = blk == null ? 0.0 : DB_block.db["param"]["cep"]["use"].read(blk.name, 0.0);

    if(typeof tmp === "function") {
      return b == null ? 0.0 : tmp(b);
    } else return tmp;
  };
  exports._cepUse = _cepUse;


  const _cepCapCur = function(team) {
    return cepCapMap.get(team, 0.0);
  };
  exports._cepCapCur = _cepCapCur;


  const _cepUseCur = function(team) {
    return cepUseMap.get(team, 0.0);
  };
  exports._cepUseCur = _cepUseCur;


  const _cepFracCur = function(team) {
    return cepFracMap.get(team, 0.0);
  };
  exports._cepFracCur = _cepFracCur;


  const _cepEffcCur = function(team) {
    return cepEffcMap.get(team, 1.0);
  };
  exports._cepEffcCur = _cepEffcCur;


  const comp_setStats_cep = function(blk) {
    var cepProv = _cepProv(blk);
    if(cepProv > 0.0) blk.stats.add(TP_stat.blk0misc_cepProv, cepProv);

    var cepUse = _cepUse(blk);
    if(cepUse > 0.0) blk.stats.add(TP_stat.blk0misc_cepUse, cepUse);
  };
  exports.comp_setStats_cep = comp_setStats_cep;


  const comp_drawSelect_cep = function(b, offTy) {
    MDL_draw.drawText_select(b, MDL_bundle._info("lovec", "text-cep") + " " + _cepUseCur(b.team) + " / " + _cepCapCur(b.team), _cepFracCur(b.team) < 1.0001, offTy);
  };
  exports.comp_drawSelect_cep = comp_drawSelect_cep;


  /* <---------- drill ----------> */


  const _drillSpd = function(blk, boosted) {
    var spd = 0.0;
    if(blk instanceof Drill) {
      spd = Math.pow(blk.size, 2) / blk.drillTime * 60.0 * (boosted ? Math.pow(blk.liquidBoostIntensity, 2) : 1.0);
    } else if(blk instanceof BeamDrill) {
      spd = blk.size / blk.drillTime * 60.0 * (boosted ? blk.optionalBoostIntensity : 1.0);
    };

    return spd;
  };
  exports._drillSpd = _drillSpd;


  /* <---------- tree ----------> */


  const _treeRsLevel = function(blk) {
    if(!MDL_cond._isTreeBlock(blk)) return 0.0;

    var treeGrp = blk.ex_getTreeGrp();
    var rsLevel = 0.0;
    switch(treeGrp) {

      case "tree" :
        rsLevel = Math.max(blk.attributes.get(TP_attr.attr0blk_tree), blk.attributes.get(TP_attr.attr0blk_hardTree));
        break;

      case "fungi" :
        rsLevel = Math.max(blk.attributes.get(TP_attr.attr0blk_fungi), blk.attributes.get(TP_attr.attr0blk_hardFungi));
        break;

      case "bush" :
        // TODO: Bush map things
        break;

    };

    return rsLevel;
  };
  exports._treeRsLevel = _treeRsLevel;


/*
  ========================================
  Section: Application
  ========================================
*/


  // Param update
  MDL_event._c_onUpdate(() => {


    if(Vars.state.isGame() && TIMER.timerState_param) {


        VARGEN.mainTeams.forEach(team => {


        // Team cores
        let cepCap = 0.0;
        team.cores().each(b => {
          cepCap += _cepProv(b.block, b);
        });
        cepCapMap.put(team, cepCap);


        // Team buildings
        let cepUse = 0.0;
        team.data().buildings.each(b => {
          if(MDL_cond._isBuildingActive(b)) cepUse += _cepUse(b.block, b);
        });
        cepUseMap.put(team, cepUse);


        // Team units
        team.data().units.each(unit => {

        });


        let cepFrac = cepCap < 0.0001 ? 1.0 : cepUse / cepCap;
        cepFracMap.put(team, cepFrac);
        let cepEffc = cepFrac < 1.0001 ? 1.0 : Math.max((2.0 * cepCap - cepUse) / cepCap, 0.0);
        cepEffcMap.put(team, cepEffc);


      });


    };


  }, 22468922);
