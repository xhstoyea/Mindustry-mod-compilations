/*
  ========================================
  Section: Introduction
  ========================================
*/


  /* ----------------------------------------
   * NOTE:
   *
   * Items and liquids are generalized as resource.
   * ---------------------------------------- */


  /* ----------------------------------------
   * BASE:
   *
   * !NOTHING
   * ---------------------------------------- */


  /* ----------------------------------------
   * KEY:
   *
   * rs.alts: 0
   * ---------------------------------------- */


  /* ----------------------------------------
   * PARAM:
   *
   * !NOTHING
   * ---------------------------------------- */


/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const PARAM = require("lovec/glb/GLB_param");


  const MDL_content = require("lovec/mdl/MDL_content");
  const MDL_draw = require("lovec/mdl/MDL_draw");
  const MDL_event = require("lovec/mdl/MDL_event");


  /* <---------- component ----------> */


  function comp_init(rs) {

  };


  function comp_setStats(rs) {

  };


  function comp_loadIcon(rs) {
    let iCap = rs.alts;
    if(iCap === 0) return;

    const regs = [Core.atlas.find(rs.name + "-t0")];
    for(let i = 0; i < iCap; i++) {
      regs.push(Core.atlas.find(rs.name + "-t" + (i + 1)));
    };

    MDL_event._c_onUpdate(() => {
      let ind = !PARAM.showIconTag ? 0 : (Math.floor((Time.globalTime / PARAM.iconTagIntv) % regs.length));
      rs.fullIcon.set(regs[ind]);
      rs.uiIcon.set(regs[ind]);
    });
  };


  function comp_createIcons(rs, packer) {
    // NOTE: I have to put it here.
    if(MDL_draw._isSameColor(rs.color, Color.black)) rs.color = MDL_draw._iconColor(rs);

    const tags = MDL_content._rsTags(rs, true);
    let iCap = tags.iCap();
    if(iCap !== 0) {

      let pix_base = Core.atlas.getPixmap(rs.name);
      let pix0 = MDL_draw._pix_stack(pix_base);
      packer.add(MultiPacker.PageType.main, rs.name + "-t0", pix0);
      pix0.dispose();

      let alts = 0;
      for(let i = 0; i < iCap; i++) {
        if(Core.atlas.has("lovec-rs0tag-") + tags[i]) {
          let pix_tag = Core.atlas.getPixmap("lovec-rs0tag-" + tags[i]);
          let pix = MDL_draw._pix_stack(pix_base, pix_tag);
          packer.add(MultiPacker.PageType.main, rs.name + "-t" + (alts + 1), pix);
          alts++;
        };
      };

      rs.alts = alts;

    };

    tags.clear();
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  module.exports = {


    /* <---------- resource ----------> */


    init: function(rs) {
      comp_init(rs);
    },


    setStats: function(rs) {
      comp_setStats(rs);
    },


    loadIcon: function(rs) {
      comp_loadIcon(rs);
    },


    createIcons: function(rs, packer) {
      comp_createIcons(rs, packer);
    },


    /* <---------- resource (specific) ----------> */


    /* <---------- resource (extended) ----------> */


    // @NOSUPER
    ex_getTags: function(rs) {
      return [];
    },


  };
