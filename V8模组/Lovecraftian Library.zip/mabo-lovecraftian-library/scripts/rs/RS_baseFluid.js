/*
  ========================================
  Section: Introduction
  ========================================
*/


  /* ----------------------------------------
   * NOTE:
   *
   * Fluids without features.
   * There is nothing named {RS_oreFluid}, since every liquid can be ore in some way.
   * ---------------------------------------- */


  /* ----------------------------------------
   * BASE:
   *
   * Liquid
   * ---------------------------------------- */


  /* ----------------------------------------
   * KEY:
   *
   * liq.alts: 0
   * ---------------------------------------- */


  /* ----------------------------------------
   * PARAM:
   *
   * !NOTHING
   * ---------------------------------------- */


/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const PARENT = require("lovec/rs/RS_baseResource");


  const MATH_base = require("lovec/math/MATH_base");


  const FRAG_fluid = require("lovec/frag/FRAG_fluid");


  const MDL_cond = require("lovec/mdl/MDL_cond");
  const MDL_content = require("lovec/mdl/MDL_content");
  const MDL_flow = require("lovec/mdl/MDL_flow");
  const MDL_table = require("lovec/mdl/MDL_table");


  const DB_fluid = require("lovec/db/DB_fluid");


  const TP_stat = require("lovec/tp/TP_stat");


  /* <---------- component ----------> */


  function comp_init(liq) {
    liq.incinerable = false;
    liq.coolant = false;
    liq.capPuddles = true;

    if(liq.gas) {
      liq.gasColor = Color.valueOf("bfbfbf")
    } else {
      liq.boilPoint = MDL_flow._boilPon(liq) / 50.0;
    };

    if(MATH_base.fEqual(liq.temperature, 0.5)) liq.temperature = MDL_flow._tempWrap(liq);
    if(MATH_base.fEqual(liq.viscosity, 0.5)) liq.viscosity = MDL_flow._viscWrap(liq);
  };


  function comp_setStats(liq) {
    liq.stats.remove(Stat.explosiveness);
    liq.stats.remove(Stat.flammability);
    liq.stats.remove(Stat.temperature);
    liq.stats.remove(Stat.heatCapacity);
    liq.stats.remove(Stat.viscosity);

    if(liq.explosiveness > 0.0) liq.stats.addPercent(Stat.explosiveness, liq.explosiveness);
    if(liq.flammability > 0.0) liq.stats.addPercent(Stat.flammability, liq.flammability);
    if(!MATH_base.fEqual(liq.temperature, 0.5)) liq.stats.add(Stat.temperature, Number(liq.temperature).perc());
    if(!MATH_base.fEqual(liq.heatCapacity, 0.5)) liq.stats.addPercent(Stat.heatCapacity, liq.heatCapacity);
    if(!liq.gas && !MATH_base.fEqual(liq.viscosity, 0.5)) liq.stats.add(Stat.viscosity, Number(liq.viscosity).perc());

    if(liq.effect !== StatusEffects.none) liq.stats.add(TP_stat.rs_fluidStatus, StatValues.content(new Seq([liq.effect])));

    if(!liq.gas && MDL_cond._isConductiveLiq(liq)) liq.stats.add(TP_stat.rs_conductiveLiq, true);

    var dens = MDL_flow._dens(liq);
    liq.stats.add(TP_stat.rs_dens, liq.gas ? Number(dens).sci(-3) : Strings.fixed(dens, 2));

    var fHeat = MDL_flow._fHeat(liq);
    if(!MATH_base.fEqual(fHeat, 26.0)) liq.stats.add(TP_stat.rs_fHeat, fHeat, TP_stat.rs_heatUnits);

    var eleGrpB = MDL_flow._eleGrpB(liq);
    if(eleGrpB !== "!ERR") liq.stats.add(TP_stat.rs_eleGrp, eleGrpB);
    var fTagsB = MDL_flow._fTagsB(liq);
    if(fTagsB !== "!NOTAG") liq.stats.add(TP_stat.rs_fTags, fTagsB);
    var corPow = MDL_flow._corPow(liq);
    if(corPow > 0.0) liq.stats.add(TP_stat.rs_corPow, Number(corPow).perc());

    const oreblks = MDL_content._oreBlks(liq);
    if(oreblks.length > 0) {
      liq.stats.add(TP_stat.rs_isOre, true);
      liq.stats.add(
        TP_stat.rs_blockRelated,
        extend(StatValue, {display(tb) {tb.row(); MDL_table.setDisplay_ctRow(tb, oreblks)}}),
      );
    };
  };


  function comp_update(liq, puddle) {
    FRAG_fluid.comp_update_fix(liq, puddle);
    FRAG_fluid.comp_update_shortCircuit(liq, puddle);
    FRAG_fluid.comp_update_puddleReaction(liq, puddle);
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  module.exports = {


    /* <---------- resource ----------> */


    init: function(liq) {
      PARENT.init(liq);
      comp_init(liq);
    },


    setStats: function(liq) {
      PARENT.setStats(liq);
      comp_setStats(liq);
    },


    update: function(liq, puddle) {
      comp_update(liq, puddle)
    },


    loadIcon: function(liq) {
      PARENT.loadIcon(liq);
    },


    createIcons: function(liq, packer) {
      PARENT.createIcons(liq, packer);
    },


    /* <---------- resource (specific) ----------> */


    /* <---------- resource (extended) ----------> */


    // @NOSUPER
    ex_getTags: function(liq) {
      return [];
    },


  };
