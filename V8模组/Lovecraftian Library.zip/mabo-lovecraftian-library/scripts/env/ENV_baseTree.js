/*
  ========================================
  Section: Introduction
  ========================================
*/


  /* ----------------------------------------
   * NOTE:
   *
   * Base for most vegetation.
   * I'm calling mushroom a tree and you can't stop me.
   * Shadow is generated so you don't need a sprite for that.
   * This is not the template for creating trees! Check something like {ENV_tree} instead.
   * ---------------------------------------- */


  /* ----------------------------------------
   * BASE:
   *
   * !NOTHING
   * ---------------------------------------- */


  /* ----------------------------------------
   * KEY:
   *
   * blk.armor: f    // @PARAM: Layer of the tree, should fall in (76.0, 80.0)
   * blk.hidable: bool    // @PARAM: Wether the tree can hide units
   * blk.drawUnd: bool    // @PARAM: Wether to draw darkened under region
   * ---------------------------------------- */


  /* ----------------------------------------
   * PARAM:
   *
   * !NOTHING
   * ---------------------------------------- */


/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const PARENT = require("lovec/env/ENV_baseProp");
  const PARAM = require("lovec/glb/GLB_param");
  const VAR = require("lovec/glb/GLB_var");


  const MATH_geometry = require("lovec/math/MATH_geometry");


  const FRAG_faci = require("lovec/frag/FRAG_faci");


  const MDL_bundle = require("lovec/mdl/MDL_bundle");
  const MDL_content = require("lovec/mdl/MDL_content");
  const MDL_draw = require("lovec/mdl/MDL_draw");
  const MDL_pos = require("lovec/mdl/MDL_pos");


  const TP_stat = require("lovec/tp/TP_stat");


  /* <---------- component ----------> */


  function comp_setStats(blk) {
    var treeGrp = blk.ex_getTreeGrp();
    if(treeGrp !== "") {
      blk.stats.add(TP_stat.blk0env_treeType, MDL_bundle._term("lovec", treeGrp));
    };

    var rsLevel = FRAG_faci._treeRsLevel(blk);
    if(rsLevel > 0.0) blk.stats.add(TP_stat.blk0env_rsLevel, Number(rsLevel).perc());
  };


  function comp_drawBase(blk, t) {
    var a = PARAM.treeAlpha;
    if(a < 0.0001) return;

    var reg = MDL_content._regVari(blk, t);
    var ang = Mathf.randomSeed(t.pos(), 0.0, 360.0);
    var offAng = Mathf.randomSeed(t.pos(), 45.0, 75.0);
    var regScl = Mathf.randomSeed(t.pos(), 0.75, 1.5);
    var scl = 1.0;
    var mag = 1.0;
    var wob = 1.0;
    switch(blk.ex_getTreeGrp()) {

      case "bush" :
        scl = 0.5;
        mag = 1.5;
        wob = 0.7;
        break;

      case "fungi" :
        scl = 3.0;
        mag = 0.4;
        wob = 0.3;
        break;

    };
    var z = Mathf.clamp(blk.armor, 76.0, 80.0);

    // Transparentization
    if(PARAM.checkTreeDst) {
      let dst = MATH_geometry._dst(t.worldx(), t.worldy(), MDL_pos._playerX(), MDL_pos._playerY());
      if(dst < reg.width * VAR.rad_treeScl) a *= 0.37;
    };

    if(blk.drawUnd) {
      if(PARAM.drawTreeShadow) {
        MDL_draw.drawRegion_blurredShadow(t.worldx() + blk.shadowOffset, t.worldy() + blk.shadowOffset, reg, ang + offAng, regScl * 1.1, a * 0.75, z - 0.0005);
        MDL_draw.drawRegion_blurredShadow(t.worldx() + blk.shadowOffset, t.worldy() + blk.shadowOffset, reg, ang, regScl * 1.1, a * 0.75, z - 0.0002);
      };
      MDL_draw.drawRegion_wobble(t.worldx(), t.worldy(), reg, ang + offAng, regScl * 0.9, scl, mag * 1.25, wob * 1.25, wob * 1.25, Color.black, a, z - 0.0003, true, 0.37);
      MDL_draw.drawRegion_wobble(t.worldx(), t.worldy(), reg, ang, regScl, scl, mag, wob, wob, Color.white, a, z);
    } else {
      if(PARAM.drawTreeShadow) {
        MDL_draw.drawRegion_blurredShadow(t.worldx() + blk.shadowOffset, t.worldy() + blk.shadowOffset, reg, ang, regScl * 1.1, a, z - 0.0005);
      };
      MDL_draw.drawRegion_wobble(t.worldx(), t.worldy(), reg, ang, regScl, scl, mag, wob, wob, Color.white, a, z);
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  module.exports = {


    /* <---------- block ----------> */


    init: function(blk) {
      PARENT.init(blk);
    },


    setStats: function(blk) {
      PARENT.setStats(blk);
      comp_setStats(blk);
    },


    // @NOSUPER
    drawBase: function(blk, t) {
      comp_drawBase(blk, t);
    },


    /* <---------- block (specific) ----------> */


    /* <---------- block (extended) ----------> */


    // @NOSUPER
    ex_getTags: function(blk) {
      return ["blk-env", "blk-tree"];
    },


    // @NOSUPER
    ex_getTreeGrp: function(blk) {
      return "";
    },


    // @NOSUPER
    ex_getHidable: function(blk) {
      return blk.hidable;
    },


  };
