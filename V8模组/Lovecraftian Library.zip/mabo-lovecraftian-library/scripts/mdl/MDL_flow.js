/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const MDL_bundle = require("lovec/mdl/MDL_bundle");
  const MDL_content = require("lovec/mdl/MDL_content");
  const MDL_text = require("lovec/mdl/MDL_text");


  const DB_block = require("lovec/db/DB_block");
  const DB_fluid = require("lovec/db/DB_fluid");


  /* <---------- auxilliary ----------> */


  function halfLogWrap(val, val_hf, val_max, base) {
    return base == null ? (
      1.0 - 0.5 * (Math.log(val_max + 1.0) - Math.log(val + 1.0)) / (Math.log(val_max + 1.0) - Math.log(val_hf + 1.0))
    ) : (
      1.0 - 0.5 * (Mathf.log(base, val_max + 1.0) - Mathf.log(base, val + 1.0)) / (Mathf.log(base, val_max + 1.0) - Mathf.log(base, val_hf + 1.0))
    );
  };


  /* <---------- base (group) ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Gets the elementary group of a fluid.
   * An elementary group is a collection of fluids similiar in properties.
   * ---------------------------------------- */
  const _eleGrp = function(liq_gn) {
    var liq = MDL_content._ct(liq_gn, "rs");
    if(liq == null) return;

    var obj = DB_fluid.db["group"]["elementary"];
    var grp;
    for(let key in obj) {
      if(obj[key].includes(liq.name)) return key;
    };
  };
  exports._eleGrp = _eleGrp;


  /* ----------------------------------------
   * NOTE:
   *
   * Gets the name of elementary group from the bundle.
   * For {"acidAq"}, this will read {"term.common-term-grp-acidaq.name"}.
   * The same for other groups.
   * ---------------------------------------- */
  const _eleGrpB = function(liq_gn) {
    var eleGrp = _eleGrp(liq_gn);
    if(eleGrp == null) return "!ERR";

    return MDL_bundle._term("common", "grp-" + eleGrp);
  };
  exports._eleGrpB = _eleGrpB;


  /* ----------------------------------------
   * NOTE:
   *
   * Gets the material group of a block, mostly for corrosion calculation.
   * This is not floor material, which is related to terrain instead.
   * ---------------------------------------- */
  const _matGrp = function(blk_gn) {
    var blk = MDL_content._ct(blk_gn, "blk");
    if(blk == null) return;

    var obj = DB_block.db["group"]["material"];
    var grp;
    for(let key in obj) {
      if(obj[key].includes(blk.name)) return key;
    };
  };
  exports._matGrp = _matGrp;


  const _matGrpB = function(blk_gn) {
    var matGrp = _matGrp(blk_gn);
    if(matGrp == null) return "!ERR";

    return MDL_bundle._term("common", "grp-" + matGrp);
  };
  exports._matGrpB = _matGrpB;


  /* ----------------------------------------
   * NOTE:
   *
   * Gets a list of fluid tags of the fluid.
   * Fluid tags provide extra multipliers to corrosion damage.
   * ---------------------------------------- */
  const _fTags = function(liq_gn) {
    var arr = [];
    var liq = MDL_content._ct(liq_gn, "rs");
    if(liq == null) return arr;

    var obj = DB_fluid.db["group"]["fTag"];
    var grp;
    for(let key in obj) {
      if(obj[key].includes(liq.name)) arr.push(key);
    };

    return arr;
  };
  exports._fTags = _fTags;


  const _fTagsB = function(liq_gn) {
    var arr = _fTags(liq_gn).substitute(tag => MDL_bundle._term("common", "grp-" + tag));

    return MDL_text._tagText(arr);
  };
  exports._fTagsB = _fTagsB;


  /* <---------- base (param) ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Gets density of a fluid.
   * ---------------------------------------- */
  const _dens = function(liq_gn) {
    var dens = 1.0;
    var liq = MDL_content._ct(liq_gn, "rs");
    if(liq == null) return dens;

    var dens_def = liq.gas ? 0.00121 : 1.0;
    dens = DB_fluid.db["param"]["dens"].read(liq.name);
    if(dens == null) {
      let eleGrp = _eleGrp(liq);
      if(eleGrp == null) {dens = dens_def} else {
        dens = DB_fluid.db["grpParam"]["dens"].read(eleGrp, dens_def);
      };
    };

    return dens;
  };
  exports._dens = _dens;


  /* ----------------------------------------
   * NOTE:
   *
   * Gets boiling point of a fluid.
   * ---------------------------------------- */
  const _boilPon = function(liq_gn) {
    var boilPon = 100.0;
    var liq = MDL_content._ct(liq_gn, "rs");
    if(liq == null) return boilPon;

    boilPon = DB_fluid.db["param"]["boil"].read(liq.name);
    if(boilPon == null) {
      let eleGrp = _eleGrp(liq);
      if(eleGrp == null) {boilPon = 100.0} else {
        boilPon = DB_fluid.db["grpParam"]["boil"].read(eleGrp, 100.0);
      };
    };

    return boilPon;
  };
  exports._boilPon = _boilPon;


  /* ----------------------------------------
   * NOTE:
   *
   * Gets fluid heat of a fluid.
   * This will affect temperature.
   * ---------------------------------------- */
  const _fHeat = function(liq_gn) {
    var fHeat = 26.0;
    var liq = MDL_content._ct(liq_gn, "rs");
    if(liq == null) return fHeat;

    fHeat = DB_fluid.db["param"]["fHeat"].read(liq.name, 26.0);

    return fHeat;
  };
  exports._fHeat = _fHeat;


  /* ----------------------------------------
   * NOTE:
   *
   * Gets wrapped temperature.
   * ---------------------------------------- */
  const _tempWrap = function(liq_gn) {
    return halfLogWrap(_fHeat(liq_gn), 26.0, 1500.0);
  };
  exports._tempWrap  = _tempWrap;


  /* ----------------------------------------
   * NOTE:
   *
   * Gets wrapped viscosity.
   * ---------------------------------------- */
  const _viscWrap = function(liq_gn) {
    var viscWrap = 0.5;
    var liq = MDL_content._ct(liq_gn, "rs");
    if(liq == null) return viscWrap;

    var arr = DB_fluid.db["param"]["visc"];
    var visc = arr.read(liq.name);
    if(visc != null) {

      viscWrap = halfLogWrap(visc, 0.98, 2800.0);

    } else {

      if(liq.gas) {viscWrap = 0.15} else {
        let eleGrp = _eleGrp(liq);
        if(eleGrp == null) {viscWrap = 0.5} else {
          viscWrap = DB_fluid.db["grpParam"]["viscWrap"].read(eleGrp, 0.5);
        };
      };

    };

    return viscWrap;
  };
  exports._viscWrap = _viscWrap;


  /* <---------- corrosion ----------> */


  const _corPow = function(liq_gn) {
    var corPow = 0.0;
    var liq = MDL_content._ct(liq_gn, "rs");
    if(liq == null) return corPow;

    corPow = DB_fluid.db["param"]["corrosion"].read(liq.name);
    if(corPow == null) {
      let eleGrp = _eleGrp(liq);
      if(eleGrp == null) {corPow = 0.0} else {
        corPow = DB_fluid.db["grpParam"]["corrosion"].read(eleGrp, 0.0);
      };
    };

    return corPow;
  };
  exports._corPow = _corPow;


  const _corMtp = function(blk_gn, liq_gn) {
    var corMtp = 1.0;
    var blk = MDL_content._ct(blk_gn, "blk");
    var liq = MDL_content._ct(liq_gn, "rs");
    if(blk == null || liq == null) return corMtp;

    var eleGrp = _eleGrp(liq);
    var matGrp = _matGrp(blk);
    if(eleGrp == null || matGrp == null) return corMtp;

    try{corMtp = DB_fluid.db["grpParam"]["matEleScl"][matGrp].read(eleGrp, 1.0)} catch(err) {corMtp = 1.0};

    var tagMtp;
    _fTags(liq).forEach(tag => {
      try{tagMtp = DB_fluid.db["grpParam"]["matFTagScl"]["matGrp"].read(tag, 1.0)} catch(err) {tagMtp = 1.0};
      corMtp *= tagMtp;
    });

    return corMtp;
  };
  exports._corMtp = _corMtp;


  const _corRes = function(blk_gn) {
    var corRes = 1.0;
    var blk = MDL_content._ct(blk_gn, "blk");
    if(blk == null) return corRes;

    corRes = DB_block.db["param"]["corRes"].read(blk.name);
    if(corRes == null) {
      let matGrp = _matGrp(blk);
      if(matGrp == null) {corRes = 1.0} else {
        corRes = DB_block.db["grpParam"]["corRes"].read(matGrp, 1.0);
      };
    };

    return corRes;
  };
  exports._corRes = _corRes;
