/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const VAR = require("lovec/glb/GLB_var");


  const MDL_bundle = require("lovec/mdl/MDL_bundle");
  const MDL_event = require("lovec/mdl/MDL_event");


  /* <---------- base ----------> */


  var shouldMuteMusic = false;
  const setMute = function(bool) {
    shouldMuteMusic = bool;
  };
  exports.setMute = setMute;


  const _cameraX = function() {
    return Core.camera.position.x;
  };
  exports._cameraX = _cameraX;


  const _cameraY = function() {
    return Core.camera.position.y;
  };
  exports._cameraY = _cameraY;


  const _screenW = function() {
    return Core.graphics.getWidth();
  };
  exports._screenW = _screenW;


  const _screenH = function() {
    return Core.graphics.getHeight();
  };
  exports._screenH = _screenH;


  const _centerX = function() {
    return Core.graphics.getWidth() * 0.5;
  };
  exports._centerX = _centerX;


  const _centerY = function() {
    return Core.graphics.getHeight() * 0.5;
  };
  exports._centerY = _centerY;


  const _zoom = function() {
    // TODO: Remember wtf is this.
    return 1.0;
  };
  exports._zoom = _zoom;


  const _uiW = function(pad, cap, offW, offH) {
    if(pad == null) pad = 20.0;
    if(cap == null) cap = 760.0;
    if(offW == null) offW = 0.0;
    if(offH == null) offH = 0.0;

    return Math.max(Math.min(_screenW() - pad * 2.0, cap), 64.0) - offW;
  };
  exports._uiW = _uiW;


  const _uiH = function(pad, cap, offW, offH) {
    if(pad == null) pad = 20.0;
    if(cap == null) cap = 760.0;
    if(offW == null) offW = 0.0;
    if(offH == null) offH = 0.0;

    return h_fi = Math.max(Math.min(_screenH() - pad * 2.0, cap), 64.0) - offH;
  };
  exports._uiH = _uiH;


  /* ----------------------------------------
   * NOTE:
   *
   * How many columns is suitable for current window size.
   * ---------------------------------------- */
  const _colAmt = function(w, pad, ord) {
    if(w == null) w = 32.0;
    if(pad == null) pad = 4.0;
    if(ord == null) ord = 1;

    return Math.max(Math.floor(_uiW(null, null, ord * VAR.rad_ordRad, 0.0) / (w + pad)), 7);
  };
  exports._colAmt = _colAmt;


  /* <---------- info ----------> */


  const announce = function(nmMod, bp, timeS) {
    if(Vars.headless || nmMod == null || bp == null) return;

    if(timeS == null) timeS = 3.0;

    Vars.ui.announce(MDL_bundle._info(nmMod, bp), timeS);
  };
  exports.announce = announce;


  const showInfoFade = function(nmMod, bp, timeS) {
    if(Vars.headless || nmMod == null || bp == null) return;

    if(timeS == null) timeS = 3.0;

    Vars.ui.showInfoFade(MDL_bundle._info(nmMod, bp), timeS);
  };
  exports.showInfoFade = showInfoFade;


  const showLabel = function(x, y, nmMod, bp, timeS) {
    if(Vars.headless || nmMod == null || bp == null) return;

    if(timeS == null) timeS = 3.0;

    Vars.ui.showLabel(MDL_bundle._info(nmMod, bp), timeS, x, y);
  };
  exports.showLabel = showLabel;


  const showError = function(nmMod, bp) {
    if(Vars.headless || nmMod == null || bp == null) return;

    Vars.ui.showErrorMessage(MDL_bundle._info(nmMod, bp));
  };
  exports.showError = showError;


/*
  ========================================
  Section: Application
  ========================================
*/


  MDL_event._c_onUpdate(() => {


    if(shouldMuteMusic) Vars.control.sound.stop();


  }, 77586623);
