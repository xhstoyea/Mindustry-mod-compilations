/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const EFF = require("lovec/glb/GLB_eff");
  const PARAM = require("lovec/glb/GLB_param");
  const VAR = require("lovec/glb/GLB_var");


  const MATH_base = require("lovec/math/MATH_base");


  const MDL_cond = require("lovec/mdl/MDL_cond");
  const MDL_draw = require("lovec/mdl/MDL_draw");
  const MDL_util = require("lovec/mdl/MDL_util");


  const TP_effect = require("lovec/tp/TP_effect");


  /* <---------- base ----------> */


  const _p_frac = function(p, frac) {
    return Math.min(p * frac, VAR.p_effPCap);
  };
  exports._p_frac = _p_frac;


  const _se = function(se_gn) {
    if(se_gn instanceof Sound) return se_gn;

    return Vars.tree.loadSound(se_gn);
  };
  exports._se = _se;


  /* <---------- sound ----------> */


  const play = function(se_gn) {
    if(Vars.headless || se_gn == null) return;

    var se = _se(se_gn);
    if(se != null) se.play();
  };
  exports.play = play;


  const playAt = function(x, y, se_gn, vol, pitch, offPitch) {
    if(Vars.headless || se_gn == null) return;

    var se = _se(se_gn);
    if(se == null) return;

    if(vol == null) vol = 1.0;
    if(pitch == null) pitch = 1.0;

    var pitch_fi = (offPitch == null) ? pitch : (pitch + Mathf.range(offPitch));
    se.at(x, y, pitch_fi, vol);
  };
  exports.playAt = playAt;


  /* <---------- effect ----------> */


  const showAt = function(x, y, eff, rot, color, data) {
    if(Vars.headless || Vars.state.isPaused() || eff == null) return;

    if(rot == null) rot = Mathf.random(360.0);
    if(color == null) color = Color.white;

    if(data == null) {
      eff.at(x, y, rot, color);
    } else {
      eff.at(x, y, rot, color, data);
    };
  };
  exports.showAt = showAt;


  const showAtP = function(p, x, y, eff, rot, color, data) {
    if(!Mathf.chance(p)) return;

    showAt(x, y, eff, rot, color, data);
  };
  exports.showAtP = showAtP;


  const showAround = function(x, y, eff, rad, rot, color, data) {
    if(Vars.headless || Vars.state.isPaused() || eff == null) return;

    return showAt(x + Mathf.range(rad), y + Mathf.range(rad), eff, rot, color, data);
  };
  exports.showAround = showAround;


  const showAroundP = function(p, x, y, eff, rad, rot, color, data) {
    if(!Mathf.chance(p)) return;

    showAround(x, y, eff, rad, rot, color, data);
  };
  exports.showAroundP = showAroundP;


  /* <---------- special effects ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Creates a regular shake effect.
   * ---------------------------------------- */
  const showAt_shake = function(x, y, pow, dur) {
    if(Vars.headless || Vars.state.isPaused()) return;

    if(pow == null) pow = 4.0;
    if(dur == null) dur = 60.0;
    if(pow < 0.0001 || dur < 0.0001) return;

    Effect.shake(pow, dur, x, y);
  };
  exports.showAt_shake = showAt_shake;


  /* ----------------------------------------
   * NOTE:
   *
   * Creates floor dust effects in a range.
   * ---------------------------------------- */
  const showAt_dust = function(x, y, rad, repeat) {
    if(Vars.headless || Vars.state.isPaused()) return;

    if(rad == null) rad = 8.0;
    if(repeat == null) repeat = 1;

    var x_i;
    var y_i;
    for(let i = 0; i < repeat; i++) {
      x_i = x + Mathf.range(rad);
      y_i = y + Mathf.range(rad);
      Effect.floorDust(x_i, y_i, 8.0);
    };
  };
  exports.showAt_dust = showAt_dust;


  /* ----------------------------------------
   * NOTE:
   *
   * Creates a ripple effect on liquid floors.
   * Ignore {liqColor} for dynamic color selection.
   * ---------------------------------------- */
  const eff_ripple = new Effect(30.0, eff => {
    eff.lifetime = 30.0 * eff.rotation * 0.25;

    Draw.color(Tmp.c1.set(eff.color).mul(1.5));
    Lines.stroke(eff.fout() * 1.4);
    Lines.circle(eff.x, eff.y, eff.fin() * eff.rotation);
  });
  eff_ripple.layer = Layer.debris;
  const showAt_ripple = function(x, y, rad, liqColor) {
    if(Vars.headless || Vars.state.isPaused()) return;

    if(rad == null) rad = 18.0;

    if(liqColor == null) {
      let t = Vars.world.tileWorld(x, y);
      if(t != null) {
        let liq = t.floor().liquidDrop;
        if(liq != null) liqColor = liq.color;
      };
    };
    if(liqColor == null) return;

    showAt(x, y, eff_ripple, rad, liqColor);
  };
  exports.showAt_ripple = showAt_ripple;


  /* ----------------------------------------
   * NOTE:
   *
   * Creates impact wave effect.
   * ---------------------------------------- */
  const eff_impactWave1 = TP_effect._impactWave(6.0, 0.0, null, 1.0);
  const eff_impactWave2 = TP_effect._impactWave(6.0, 0.0, null, 1.2);
  const eff_impactWave3 = TP_effect._impactWave(6.0, 0.0, null, 1.5);
  const eff_impactWave4 = TP_effect._impactWave(6.0, 0.0, null, 1.9);
  const showAt_impactWave = function(x, y, rad) {
    if(Vars.headless) return;

    showAt(x, y, eff_impactWave1, rad);
    showAt(x, y, eff_impactWave2, rad);
    showAt(x, y, eff_impactWave3, rad);
    showAt(x, y, eff_impactWave4, rad);
  };
  exports.showAt_impactWave = showAt_impactWave;


  /* ----------------------------------------
   * NOTE:
   *
   * Creates rotor wave effect.
   * Used by rotor units.
   * ---------------------------------------- */
  const eff_rotorWave = new Effect(20.0, eff => {
    eff.lifetime = 20.0 * Math.pow(eff.rotation * 0.025, 0.5);

    Draw.color(Color.valueOf("ffffff30"), Color.valueOf("ffffff00"), eff.fin());
    Lines.stroke(2.0);
    Lines.circle(eff.x, eff.y, eff.rotation * eff.fin());
    Draw.reset();
  });
  eff_rotorWave.layer = VAR.lay_effFlr;
  const showAt_rotorWave = function(x, y, rad) {
    if(Vars.headless) return;

    showAt(x, y, eff_rotorWave, rad);
  };
  exports.showAt_rotorWave = showAt_rotorWave;


  /* ----------------------------------------
   * NOTE:
   *
   * Creates liquid corrosion effect.
   * ---------------------------------------- */
  const eff_corrosion = new Effect(120.0, eff => {
    Draw.z(VAR.lay_effBase);
    Draw.color(eff.color);
    Fill.circle(eff.x, eff.y, 0.8 * Interp.pow5Out.apply(1.0 - eff.fin()))
  });
  const showAt_corrosion = function(x, y, size, liqColor) {
    if(Vars.headless || Vars.state.isPaused()) return;

    if(size == null) size = 1;
    if(liqColor == null) liqColor = Color.white;

    var rad = size * Vars.tilesize * 0.5;
    showAround(x, y, eff_corrosion, rad, 0.0, liqColor);
  };
  exports.showAt_corrosion = showAt_corrosion;


  /* ----------------------------------------
   * NOTE:
   *
   * Creates remains of a unit.
   * ---------------------------------------- */
  const showAt_remains = function(x, y, utp0unit, team, isPermanent, forceHot) {
    if(Vars.headless || utp0unit == null || team == null) return;

    var unit = (utp0unit instanceof Unit) ? utp0unit : null;
    var utp = (utp0unit instanceof Unit) ? utp0unit.type : utp0unit;
    if(MDL_cond._hasNoRemains(utp)) return;

    var t = Vars.world.tileWorld(x, y);
    if(t == null || !t.floor().canShadow) return;

    var tint = null;
    var a = 1.0;
    var z = VAR.lay_unitRemains;
    var inLiq = false;
    var shouldFloat = false;
    if(t.floor().isLiquid && t.build == null && (!t.solid() || t.block() instanceof TreeBlock)) {
      inLiq = true;
      if(utp.hitSize < 17.5001) {shouldFloat = true} else {
        let liq = t.floor().liquidDrop;
        if(liq != null) {
          tint = liq.color;
          a = 0.5;
          z = 22.0;
        };
      };
    };

    const remains = extend(Decal, {


      lifetime: isPermanent ? MATH_base.maxTime : PARAM.unitRemainsLifetime, offTime: Mathf.random(1200.0),
      x: x, y: y, rotation: Mathf.random(360.0), team: team,
      color: Color.valueOf("606060"), tint: tint, a: a, z: z,
      region: Core.atlas.find(utp.name + "-icon", utp.region),
      cellRegion: Core.atlas.find(utp.name + "-cell-icon", utp.cellRegion),
      shouldFloat: shouldFloat,
      isHot: forceHot ? true : MDL_cond._isHot(unit), shouldFadeHeat: forceHot ? false : (!MDL_cond._isHotSta(t.floor().status) || !inLiq),


      draw() {
        var x = this.x + (!this.shouldFloat ? 0.0 : Math.sin((Time.time + this.offTime) * 0.01) * 0.35 * Vars.tilesize);
        var y = this.y + (!this.shouldFloat ? 0.0 : Math.cos((Time.time + this.offTime) * 0.05 + 32.0) * 0.15 * Vars.tilesize);
        if(this.shouldFloat && Mathf.chanceDelta(0.01)) showAt_ripple(x, y, utp.hitSize * 1.2);

        Draw.z(this.z);
        if(this.tint != null) {Draw.tint(this.color, this.tint, 0.5)} else {
          if(!this.isHot) {Draw.color(this.color)} else {
            Draw.color(Tmp.c1.set(Color.valueOf("ea8878")).lerp(this.color, Interp.pow2Out.apply(this.fin())));
          };
        };
        Draw.alpha(this.a - Mathf.curve(this.fin(), 0.98) * this.a);
        Draw.rect(this.region, x, y, this.rotation);
        Draw.color(Tmp.c2.set(this.color).mul(this.team.color));
        Draw.alpha(this.a - Mathf.curve(this.fin(), 0.98) * this.a);
        Draw.rect(this.cellRegion, x, y, this.rotation);
        Draw.color();
        if(this.isHot) {
          Draw.blend(Blending.additive);
          Draw.mixcol(Color.valueOf("ff3838"), 1.0);
          Draw.alpha((0.5 + Mathf.absin(10.0, 0.5)) * (!this.shouldFadeHeat ? (0.5 - Mathf.curve(this.fin(), 0.98) * 0.5) : (0.5 - Interp.pow2Out.apply(this.fin()) * 0.5)));
          Draw.rect(this.region, x, y, this.rotation);
          Draw.blend();
        };
        Draw.reset();
      },


    });
    remains.add();
  };
  exports.showAt_remains = showAt_remains;


  /* ----------------------------------------
   * NOTE:
   *
   * Creates a flash effect over an entity.
   * Color is only used for buildings, due to hard-coded {applyColor()}.
   * The only exception for unit is {Pal.heal}.
   * ---------------------------------------- */
  const eff_flash = new Effect(20.0, eff => {
    var e = eff.data;
    var color = eff.color;
    var a = eff.fout() * color.a;

    if(e instanceof Building) {

      var reg = Core.atlas.find(e.block.name + "-icon", e.block.region);
      var ang = 0.0;
      MDL_draw.drawRegion_normal(e.x, e.y, reg, ang, 1.0, color, a, Layer.effect + VAR.lay_offDrawOver, true);

    } else if(e instanceof Unit) {

      if(MDL_draw._isSameColor(color, Pal.heal)) {unit.healTime = 1.0}
      else {unit.hitTime = 1.0};

    } else return;
  });
  const showAt_flash = function(e, color_gn) {
    if(Vars.headless || Vars.state.isPaused() || e == null) return;
    var unit_pl = Vars.player.unit();
    if(unit_pl == null) return;

    if(color_gn == null) color_gn = Color.white;

    showAt(unit_pl.x, unit_pl.y, eff_flash, 0.0, MDL_draw._color(color_gn), e);
  };
  exports.showAt_flash = showAt_flash;


  /* ----------------------------------------
   * NOTE:
   *
   * Creates a texture region or icon that fades out.
   * ---------------------------------------- */
  const eff_regFade = new Effect(40.0, eff => {
    eff.lifetime = 40.0 * eff.rotation;

    var reg0icon = eff.data;
    var color = eff.color;
    var a = eff.fout() * color.a;

    if(reg0icon instanceof TextureRegion) {MDL_draw.drawRegion_normal(eff.x, eff.y, reg0icon, 0.0, 1.0, color, a, Layer.effect + VAR.lay_offDrawOver)}
    else {MDL_draw.drawRegion_icon(eff.x, eff.y, reg0icon, 0.0, 1.0, color, a)};
  });
  const showAt_regFade = function(x, y, reg0icon, color_gn, scl) {
    if(Vars.headless || Vars.state.isPaused() || reg0icon == null) return;

    if(color_gn == null) color_gn = Color.white;
    if(scl == null) scl = 1.0;

    showAt(x, y, eff_regFade, scl, MDL_draw._color(color_gn), reg0icon);
  };
  exports.showAt_regFade = showAt_regFade;


  /* ----------------------------------------
   * NOTE:
   *
   * Creates a damage number effect.
   * Only works when damage display is enabled.
   * ---------------------------------------- */
  const modes_dmg = ["health", "shield", "heal"];
  const eff_dmg = new Effect(40.0, eff => {
    var dmg = eff.rotation;
    var mode = eff.data;
    var sizeScl = Math.max(Math.log((dmg + 10.0) / 10.0), 0.7);

    var str_dmg = dmg > 9.9999 ? Strings.fixed(dmg, 0) : (dmg > 0.9999 ? Strings.fixed(dmg, 1) : Strings.fixed(dmg, 2));
    var str_fi = null;
    switch(mode) {
      case "health" :
        str_fi = str_dmg;
        break;
      case "shield" :
        str_fi = "<" + str_dmg + ">";
        break;
      case "heal" :
        str_fi = "+" + str_dmg;
        break;
    };

    MDL_draw.drawText(
      eff.x,
      eff.y,
      str_fi,
      sizeScl - Interp.pow3In.apply(eff.fin()) * sizeScl,
      eff.color,
      Align.center,
      0.0,
      8.0 * eff.fin(),
      Math.min(dmg / 10000.0, 10.0),
    );
  });
  const showAt_dmg = function(x, y, dmg, team, mode) {
    if(Vars.headless || !PARAM.displayDamage || dmg == null || dmg < 0.0001) return;
    if(mode == null) mode = "health";
    if(!mode.equalsAny(modes_dmg)) return;

    if(team == null) team = Team.derelict;

    var color = null;
    switch(mode) {
      case "health" :
        color = team === Team.derelict ? Color.white : team.color;
        break;
      case "shield" :
        color = Pal.techBlue;
        break;
      case "heal" :
        color = Pal.heal;
        break;
    };
    if(color == null) return;

    showAround(x, y, eff_dmg, 14.0, dmg, color, mode);
  };
  exports.showAt_dmg = showAt_dmg;
