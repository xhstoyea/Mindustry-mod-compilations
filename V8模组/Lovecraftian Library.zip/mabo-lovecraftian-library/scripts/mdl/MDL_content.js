/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const MDL_event = require("lovec/mdl/MDL_event");
  const MDL_test = require("lovec/mdl/MDL_test");


  const DB_item = require("lovec/db/DB_item");


  /* <---------- base ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Gets a content from generalized content (mostly names).
   * Use {mode} to specify the category, for better performance.
   * This will print a warning to console if content not found, use {suppressWarning} to disable it.
   *
   * Example:
   * _ct("copper");    // Returns vanilla copper item
   * _ct("water");    // Returns vanilla water liquid
   * _ct("shallow-water");    // Returns shallow water floor
   * _ct(Blocks.router);    // Returns router block
   * _ct("router", "rs", true);    // Returns null since there's no item or liquid named router, but warning is suppressed
   *
   * Don't do stupid things like naming something "null".
   * ---------------------------------------- */
  const _ct = function(ct_gn, mode, suppressWarning) {
    if(ct_gn == null || ct_gn === "null") return null;

    var ct = null;
    if(ct_gn instanceof UnlockableContent) ct = ct_gn;
    if(typeof ct_gn === "string") {
      if(mode != null) {
        switch(mode) {
          case "rs" :
            ct = Vars.content.item(ct_gn);
            if(ct == null) ct = Vars.content.liquid(ct_gn);
            break;
          case "blk" :
            ct = Vars.content.block(ct_gn);
            break;
          case "utp" :
            ct = Vars.content.unit(ct_gn);
            break;
          case "sta" :
            ct = Vars.content.statusEffect(ct_gn);
            break;
          case "wea" :
            ct = Vars.content.weather(ct_gn);
            break;
          case "sec" :
            ct = Vars.content.sector(ct_gn);
            break;
          case "pla" :
            ct = Vars.content.planet(ct_gn);
            break;
        };
      } else {
        ct = Vars.content.item(ct_gn);
        if(ct == null) ct = Vars.content.liquid(ct_gn);
        if(ct == null) ct = Vars.content.weather(ct_gn);
        if(ct == null) ct = Vars.content.sector(ct_gn);
        if(ct == null) ct = Vars.content.planet(ct_gn);
        if(ct == null) ct = Vars.content.statusEffect(ct_gn);
        if(ct == null) ct = Vars.content.unit(ct_gn);
        if(ct == null) ct = Vars.content.block(ct_gn);
      };

      if(suppressWarning == null) suppressWarning = false;
      if(ct == null && !suppressWarning) MDL_test._w_ctNotFound(ct_gn);
    };

    return ct;
  };
  exports._ct = _ct;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether this content has name in bundle.
   * ---------------------------------------- */
  const _hasBundle = function(ct_gn) {
    var ct = _ct(ct_gn);
    if(ct == null) return false;

    return Core.bundle.has(ct.contentType.toString() + "." + ct.name + ".name");
  };
  exports._hasBundle = _hasBundle;


  /* ----------------------------------------
   * NOTE:
   *
   * Renames a content on client load.
   * Only called if bundle is not provided.
   * ---------------------------------------- */
  const rename = function(ct_gn, nm) {
    if(Vars.headless) return;

    var ct = _ct(ct_gn);
    if(ct == null || _hasBundle(ct)) return;

    MDL_event._c_onLoad(() => {
      ct.localizedName = nm;
    });
  };
  exports.rename = rename;


  /* ----------------------------------------
   * NOTE:
   *
   * Gets the mod that adds the content.
   * Returns name by default.
   * Will return {"vanilla"} or {null} if it's vanilla content.
   * ---------------------------------------- */
  const _mod = function(ct_gn, returnMod) {
    var ct = _ct(ct_gn);
    if(ct == null) return;

    var mod = ct.minfo.mod;
    return mod == null ? (returnMod ? null : "vanilla") : (returnMod ? mod : mod.name);
  };
  exports._mod = _mod;


  const _hasTag = function(ct, tag) {
    if(ct == null) return false;

    var bool = false;
    try {bool = ct.ex_getTags().includes(tag)} catch(err) {bool = false};

    return bool;
  };
  exports._hasTag = _hasTag;


  /* <---------- region ----------> */


  const _reg = function(ct_gn, suffix) {
    if(Vars.headless) return;
    var ct = _ct(ct_gn);
    if(ct == null) return;
    if(suffix == null) suffix = "";

    return Core.atlas.find(ct.name + suffix);
  };
  exports._reg = _reg;


  /* ----------------------------------------
   * NOTE:
   *
   * Gets the default complete region for a block.
   * -icon sprite should always be created.
   * ---------------------------------------- */
  const _regBlk = function(blk_gn) {
    if(Vars.headless) return;
    var blk = _ct(blk_gn);
    if(blk == null) return;

    return Core.atlas.find(blk.name + "-icon", Core.atlas.find(blk.name));
  };
  exports._regBlk = _regBlk;


  /* ----------------------------------------
   * NOTE:
   *
   * Gets the block heat region for the inputted size.
   * ---------------------------------------- */
  var maxBlockHeatInd = 0;
  while(Core.atlas.has("lovec-ast-block-heat" + (maxBlockHeatInd + 1))) {maxBlockHeatInd++};
  const _regHeat = function(size) {
    if(Var.headless) return;

    var ind = Math.round(size);
    if(ind < 1 || ind > maxBlockHeatInd) return;

    return Core.atlas.find("lovec-ast-block-heat" + ind);
  };
  exports._regHeat = _regHeat;


  /* ----------------------------------------
   * NOTE:
   *
   * Gets a random region from variant regions, based on tile position.
   * ---------------------------------------- */
  const _regVari = function(blk_gn, t, off) {
    if(Vars.headless) return;
    var blk = _ct(blk_gn);
    if(blk == null) return;

    if(blk.variants === 0) return blk.region;

    if(off == null) off = 0;
    return blk.variantRegions[Mathf.randomSeed(t.pos() + off, 0, Math.max(0, blk.variantRegions.length - 1))];
  };
  exports._regVari = _regVari;


  /* random overlay */


  /* ----------------------------------------
   * NOTE:
   *
   * Gets an array of random overlay regions.
   * Mostly used as the base for other functions, since {DB_env.db["map"]["randRegTag"]} requires a mapper function not array.
   * Why? I have to ensure everything is loaded.
   * ---------------------------------------- */
  const _randRegs = function(nm) {
    const arr = [];
    if(Vars.headless) return arr;

    let i = 0;
    while(Core.atlas.has(nm + (i + 1))) {
      arr.push(Core.atlas.find(nm + (i + 1)));
      i++;
    };

    return arr;
  };
  exports._randRegs = _randRegs;


  const _randRegs_rock = function() {
    return _randRegs("lovec-ov0rand-rock");
  };
  exports._randRegs_rock = _randRegs_rock;


  const _randRegs_rockSand = function() {
    return _randRegs("lovec-ov0rand-rock-sand");
  };
  exports._randRegs_rockSand = _randRegs_rockSand;


  /* <---------- resource ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Returns an array of tags that belong to the resource.
   * Set {iconTagOnly} to get tags that can be shown over icon only.
   * ---------------------------------------- */
  const _rsTags = function(rs, iconTagOnly) {
    var tags = null;
    try {tags = rs.ex_getTags()} catch(err) {tags = null};
    return tags == null ? [] : (iconTagOnly ? tags.filter(i => DB_item.db["iconTag"].includes(i)) : tags);
  };
  exports._rsTags = _rsTags;


  /* ----------------------------------------
   * NOTE:
   *
   * Returns an array of blocks that drop the resource.
   * ---------------------------------------- */
  const _oreBlks = function(rs) {
    const arr = [];
    if(rs == null) return arr;

    const li = Vars.content.blocks();
    if(rs instanceof Item) li.each(blk => {if(blk.itemDrop === rs) arr.push(blk)});
    if(rs instanceof Liquid) li.each(blk => {if(blk.liquidDrop === rs) arr.push(blk)});

    return arr;
  };
  exports._oreBlks = _oreBlks;
