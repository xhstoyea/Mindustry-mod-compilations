/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const MATH_geometry = require("lovec/math/MATH_geometry");


  const MDL_cond = require("lovec/mdl/MDL_cond");
  const MDL_effect = require("lovec/mdl/MDL_effect");


  /* <---------- unit ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Spawns a unit at (x, y).
   * Use {repeat} to spawn multiple times in radius of {rad}.
   * Set {ang} to apply a specific rotation.
   * Use {scr} to furthur modify those spawned units.
   * ---------------------------------------- */
  const spawnUnit = function(x, y, utp, team, rad, ang, repeat, scr) {
    if(Vars.net.client() || utp == null) return;

    if(team == null) team = Team.sharded;
    if(rad == null) rad = 0.0;
    if(ang == null) ang = "rand";
    if(repeat == null) repeat = 1;

    var x_i;
    var y_i;
    var ang_i;
    for(let i = 0; i < repeat; i++) {
      x_i = x + Mathf.range(rad);
      y_i = y + Mathf.range(rad);
      ang_i = ang === "rand" ? Mathf.random(360.0) : ang;

      if(scr == null) {
        utp.spawn(team, x_i, y_i, ang_i);
      } else {
        utp.spawn(team, x_i, y_i, ang_i, scr);
      };
    };
  };
  exports.spawnUnit = spawnUnit;


  /* ----------------------------------------
   * NOTE:
   *
   * Apply knockback for {unit} from a center of (x, y), with {pow} as the power.
   * {pow} can be negative to pull the target.
   * Set {rad} to apply range knockback, e.g. for splash damage.
   * Set {ang} to push/pull the target in a specific angle.
   * ---------------------------------------- */
  const knockback = function(x, y, unit, pow, rad, ang) {
    if(unit == null || MDL_cond._isHighAir(unit)) return;

    if(pow == null) pow = 0.0;
    if(Math.abs(pow) < 0.0001) return;

    var pow_fi = rad == null ? pow : (pow * (1.0 - Mathf.clamp(MATH_geometry._dst(x, y, unit.x, unit.y) / rad)) * 4.0);
    if(unit.flying) pow_fi *= 2.5;

    var vec2 = Tmp.v1.set(unit).sub(x, y).nor().scl(pow_fi * 80.0);
    if(ang != null) vec.setAngle(ang + (pow_fi < 0.0 ? 180.0 : 0.0));

    unit.impulse(vec2);
  };
  exports.knockback = knockback;


  /* <---------- bullet ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Like {spawnUnit} but for bullets.
   * Set {se_gn} if a sound should be played.
   * {scl} is lifetime scale, {velScl} is velocity scale.
   * {eOwn} is the owner, {eShoot} is the shooter, {eTg} is the target.
   * ---------------------------------------- */
  const spawnBul = function(x, y, btp, se_gn, team, rad, ang, repeat,
    scl, velScl, dmg_ow, aimX_ow, aimY_ow, data,
    eOwn, eShoot, eTg, mover
  ) {
    if(btp == null) return;

    if(team == null) team = Team.derelict;
    if(rad == null) rad = 0.0;
    if(ang == null) ang = "rand";
    if(repeat == null) repeat = 1;
    if(scl == null) scl = 1.0;
    if(velScl == null) velScl = 1.0;
    if(dmg_ow == null) dmg_ow = -1;
    if(aimX_ow == null) aimX_ow = -1;
    if(aimY_ow == null) aimY_ow = -1;
    if(data == null) data = null;
    if(eOwn == null) eOwn = null;
    if(eShoot == null) eShoot = eOwn;
    if(eTg == null) eTg = null;
    if(mover == null) mover = null;

    var x_i;
    var y_i;
    var ang_i;
    for(let i = 0; i < repeat; i++) {
      x_i = x + Mathf.range(rad);
      y_i = y + Mathf.range(rad);
      ang_i = ang === "rand" ? Mathf.random(360.0) : ang;

      btp.create(eOwn, eShoot, team, x_i, y_i, ang_i, dmg_ow, velScl, scl, data, mover, aimX_ow, aimY_ow, eTg);
    };

    MDL_effect.playAt(x, y, se_gn);
  };
  exports.spawnBul = spawnBul;


  /* ----------------------------------------
   * NOTE:
   *
   * Applys damage to a bullet.
   * Destroys the bullet if bullet damage is reduced to below zero.
   * ---------------------------------------- */
  const damageBul = function(bul, dmg) {
    if(bul == null) return;

    if(dmg == null) dmg = 0.0;
    if(dmg < 0.0001) return;

    bul.damage > dmg ? (bul.damage -= dmg) : bul.remove();
  };
  exports.damageBul = damageBul;
