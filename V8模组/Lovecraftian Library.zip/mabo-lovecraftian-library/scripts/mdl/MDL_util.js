/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const MDL_bundle = require("lovec/mdl/MDL_bundle");


  /* <---------- setting ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Reads the setting. Also see {GLB_param}.
   * ---------------------------------------- */
  const _cfg = function(nmCfg, useScl) {
    var val = null;
    switch(nmCfg) {

      case "test-draw" :
        val = Core.settings.getBool("lovec-test-draw", false);
        break;

      case "test-memory" :
        val = Core.settings.getBool("lovec-test-memory", false);
        break;

      // @SCALED: x6.0
      case "interval-efficiency" :
        val = Core.settings.getInt("lovec-interval-efficiency", 5);
        if(useScl) val *= 6.0;
        break;

      case "draw-wobble" :
        val = Core.settings.getBool("lovec-draw-wobble", false);
        break;

      case "draw0shadow-blurred" :
        val = Core.settings.getBool("lovec-draw0shadow-blurred", true);
        break;

      // @SCALED: x0.1
      case "draw0tree-alpha" :
        val = Core.settings.getInt("lovec-draw0tree-alpha", 10);
        if(useScl) val *= 0.1;
        break;

      case "draw0tree-shadow" :
        val = Core.settings.getBool("lovec-draw0tree-shadow", true);
        break;

      case "draw0tree-player" :
        val = Core.settings.getBool("lovec-draw0tree-player", true);
        break;

      case "draw0aux-bridge" :
        val = Core.settings.getBool("lovec-draw0aux-bridge", true);
        break;

      case "draw0aux-router" :
        val = Core.settings.getBool("lovec-draw0aux-router", true);
        break;

      case "icontag-show" :
        val = Core.settings.getBool("lovec-icontag-show", true);
        break;

      // @SCALED: x20.0
      case "icontag-interval" :
        val = Core.settings.getInt("lovec-icontag-interval", 6);
        if(useScl) val *= 20.0;
        break;

      case "damagedisplay-show" :
        val = Core.settings.getBool("lovec-damagedisplay-show", true);
        break;

      case "unit0stat-show" :
        val = Core.settings.getBool("lovec-unit0stat-show", true);
        break;

      case "unit0stat-player" :
        val = Core.settings.getBool("lovec-unit0stat-player", true);
        break;

      case "unit0stat-reload" :
        val = Core.settings.getBool("lovec-unit0stat-reload", true);
        break;

      case "unit0stat-missile" :
        val = Core.settings.getBool("lovec-unit0stat-missile", false);
        break;

      case "unit0stat-build" :
        val = Core.settings.getBool("lovec-unit0stat-build", true);
        break;

      case "unit0stat-mouse" :
        val = Core.settings.getBool("lovec-unit0stat-mouse", true);
        break;

      // @SCALED: x300.0
      case "unit0remains-lifetime" :
        val = Core.settings.getInt("lovec-unit0remains-lifetime", 12);
        if(useScl) val *= 300.0;
        break;

    };

    return val;
  };
  exports._cfg = _cfg;


  /* <---------- mod ----------> */


  const _loadedMod = function(nmMod) {
    if(nmMod === "vanilla") return;

    return Vars.mods.locateMod(nmMod);
  };
  exports._loadedMod = _loadedMod;


  /* ----------------------------------------
   * NOTE:
   *
   * Localize the mod stats.
   * Put {info.modname-info-mod} in your bundle.
   * ---------------------------------------- */
  const setMod_localization = function(nmMod) {
    if(Vars.headless) return;

    var mod = _loadedMod(nmMod);
    if(mod == null) return;

    mod.meta.displayName = MDL_bundle._info(nmMod, "mod");
    mod.meta.description = MDL_bundle._info(nmMod, "mod", true);
  };
  exports.setMod_localization = setMod_localization;


  /* ----------------------------------------
   * NOTE:
   *
   * Merges two JS objects.
   * Only objects and arrays should be present in the object.
   * ---------------------------------------- */
  const mergeObj = function(obj0, obj) {
    var tmp = null;

    for(let key1 in obj0) {

      if(obj0[key1] instanceof Array) {

        try {tmp = obj[key1]} catch(err) {tmp = null};
        if(tmp != null) obj0[key1].pushAll(tmp);

      } else {

        for(let key2 in obj0[key1]) {

          if(obj0[key1][key2] instanceof Array) {

            try {tmp = obj[key1][key2]} catch(err) {tmp = null};
            if(tmp != null) obj0[key1][key2].pushAll(tmp);

          } else {

            for(let key3 in obj0[key1][key2]) {

              if(obj0[key1][key2][key3] instanceof Array) {

                try {tmp = obj[key1][key2][key3]} catch(err) {tmp = null};
                if(tmp != null) obj0[key1][key2][key3].pushAll(tmp);

              } else {

                // NOTE: Too deep.

              };

            };

          };

        };

      };

    };
  };
  exports.mergeObj = mergeObj;


  /* ----------------------------------------
   * NOTE:
   *
   * Called in a DB file before it's exported.
   * This will merge all DBs from other mods with the same structure.
   * You don't need this for your own mod, unless you know what you're doing.
   * ---------------------------------------- */
  const mergeDB = function(dbObj, nmFi) {
    Vars.mods.eachEnabled(mod => {
      if(mod.name !== "lovec") {
        var dbFi = null;
        var path = mod.name + "/db/" + nmFi;
        try {dbFi = require(path)} catch(err) {dbFi = null};
        if(dbFi != null) {
          mergeObj(dbObj, dbFi.db);
        };
      };
    });
  };
  exports.mergeDB = mergeDB;
