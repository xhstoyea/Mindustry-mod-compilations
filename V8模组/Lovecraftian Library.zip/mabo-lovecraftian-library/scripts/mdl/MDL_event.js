/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  /* <---------- base ----------> */


  const ids_onLoad = [];
  const _c_onLoad = function(scr, id) {
    if(id != null && ids_onLoad.includes(id)) return;

    if(id != null) ids_onLoad.push(id);
    Events.run(ClientLoadEvent, () => {
      scr();
    });
  };
  exports._c_onLoad = _c_onLoad;


  const ids_onWorldLoad = [];
  const _c_onWorldLoad = function(scr, id) {
    if(id != null && ids_onWorldLoad.includes(id)) return;

    if(id != null) ids_onWorldLoad.push(id);
    Events.run(WorldLoadEvent, () => {
      scr();
    });
  };
  exports._c_onWorldLoad = _c_onWorldLoad;


  const ids_onUpdate = [];
  const _c_onUpdate = function(scr, id) {
    if(id != null && ids_onUpdate.includes(id)) return;

    if(id != null) ids_onUpdate.push(id);
    Events.run(Trigger.update, () => {
      scr();
    });
  };
  exports._c_onUpdate = _c_onUpdate;


  const ids_onDraw = [];
  const _c_onDraw = function(scr, id) {
    if(id != null && ids_onDraw.includes(id)) return;

    if(id != null) ids_onDraw.push(id);
    Events.run(Trigger.draw, () => {
      scr();
    });
  };
  exports._c_onDraw = _c_onDraw;
