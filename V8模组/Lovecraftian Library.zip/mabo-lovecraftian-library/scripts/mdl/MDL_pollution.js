/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const MDL_content = require("lovec/mdl/MDL_content");


  const DB_block = require("lovec/db/DB_block");
  const DB_unit = require("lovec/db/DB_unit");


  /* <---------- base ----------> */


  const _pol = function(blk_gn) {
    var pol = 0.0;
    var blk = MDL_content._ct(blk_gn, "blk");
    if(blk == null) return pol;

    pol = DB_block.db["param"]["pol"].read(blk.name, 0.0);

    return pol;
  };
  exports._pol = _pol;


  const _polTol = function(blk0utp_gn) {
    var polTol = 0.0;
    var blk0utp = MDL_content._ct(blk0utp_gn, "utp");
    if(blk0utp == null) blk0utp = MDL_content._ct(blk0utp_gn, "blk");
    if(blk0utp == null) return polTol;

    polTol = ((blk0utp instanceof UnitType) ? DB_unit.db["param"]["polTol"] : DB_block.db["param"]["polTol"]).read(blk0utp.name, 500.0);

    return polTol;
  };
  exports._polTol = _polTol;
