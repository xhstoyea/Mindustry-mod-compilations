/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  /* <---------- base ----------> */


  const _i_invalidArgs = function() {
    Log.info("[LOVEC] " + "Invalid arguments!".color(Pal.remove));
  };
  exports._i_invalidArgs = _i_invalidArgs;


  const _i_notInGame = function() {
    Log.info("[LOVEC] " + "Method unavailable outside of game.".color(Pal.remove));
  };
  exports._i_notInGame = _i_notInGame;


  const _i_noBuild = function(tx, ty) {
    Log.info("[LOVEC] " + ("There's no building at (" + tx + ", " + ty + ").").color(Pal.remove));
  };
  exports._i_noBuild = _i_noBuild;


  /* <---------- content ----------> */


  const _w_ctNotFound = function(nmCt) {
    if(typeof nmCt !== "string") {
      Log.warn("[LOVEC] Content name not string!");
    } else {
      Log.warn("[LOVEC] Content mot found for " + nmCt);
    };
  };
  exports._w_ctNotFound = _w_ctNotFound;


  /* <---------- faci ----------> */


  const _i_liq = function(tx, ty) {
    if(!Vars.state.isGame()) {
      _i_notInGame();
      return;
    };

    var b = Vars.world.build(tx, ty);
    if(b == null) {
      _i_noBuild(tx, ty);
      return;
    };

    if(b.liquids == null) {
      Log.info("[LOVEC] " + b.block.localizedName.color(b.team.color) + " at (" + tx + ", " + ty + ") does not have liquid module.");
    } else {
      let cap = b.block.liquidCapacity;
      let str = "[LOVEC] liquid info for " + b.block.localizedName.color(b.team.color) + " at (" + tx + ", " + ty + ")"
      + "\n- Liquid capacity: " + Strings.fixed(cap, 2);
      if(b.liquids.currentAmount() > 0.0001) {
        str += "\n- Current liquid: " + b.liquids.current().localizedName
        + "\n- Liquids: ";
        b.liquids.each(liq => {
          let amt = b.liquids.get(liq);
          str += "\n  > " + liq.localizedName + ": " + Strings.fixed(amt, 4) + " (" + Number(amt / cap).perc() + ")";
        });
      };

      Log.info(str);
    };
  };
  exports._i_liq = _i_liq;


  /* <---------- tool ----------> */


  const _i_timeControl = function(timeScl) {
    Log.info("[LOVEC] Current time scale: " + Strings.autoFixed(timeScl, 3) + "x");
  };
  exports._i_timeControl = _i_timeControl;
