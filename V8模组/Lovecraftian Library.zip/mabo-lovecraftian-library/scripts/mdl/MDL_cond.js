/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const VAR = require("lovec/glb/GLB_var");


  const MDL_content = require("lovec/mdl/MDL_content");
  const MDL_entity = require("lovec/mdl/MDL_entity");


  const DB_block = require("lovec/db/DB_block");
  const DB_fluid = require("lovec/db/DB_fluid");
  const DB_status = require("lovec/db/DB_status");
  const DB_unit = require("lovec/db/DB_unit");


  /* <---------- pos ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the floor at given position supports shadow casting.
   * ---------------------------------------- */
  const _posCanShadow = function(x, y) {
    var flr = Vars.world.floorWorld(x, y);
    if(flr == null || flr instanceof EmptyFloor || !flr.canShadow) return false;

    return true;
  };
  exports._posCanShadow = _posCanShadow;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether something at given position is visible (in the screen).
   * ---------------------------------------- */
  const _posVisible = function(x, y, clipSize) {
    if(clipSize == null) clipSize = 0.0;

    return Core.camera.bounds(Tmp.r1).overlaps(Tmp.r2.setCentered(x, y, clipSize));
  };
  exports._posVisible = _posVisible;


  /* <---------- resource ----------> */


  const _isRsAvailable = function(rs_gn) {
    var rs = MDL_content._ct(rs_gn, "rs");
    if(rs == null) return false;

    return rs.unlockedNow() && rs.isOnPlanet(Vars.state.getPlanet()) && !rs.isHidden();
  };
  exports._isRsAvailable = _isRsAvailable;


  const _isVirt = function(rs_gn) {
    return MDL_content._hasTag(MDL_content._ct(rs_gn, "rs"), "rs-virt");
  };
  exports._isVirt = _isVirt;


  const _isEffc = function(rs_gn) {
    return MDL_content._hasTag(MDL_content._ct(rs_gn, "rs"), "rs-effc");
  };
  exports._isEffc = _isEffc;


  const _isNoCapEffc = function(rs_gn) {
    return MDL_content._hasTag(MDL_content._ct(rs_gn, "rs"), "rs-nocap0effc");
  };
  exports._isNoCapEffc = _isNoCapEffc;


  const _isConductiveLiq = function(rs_gn) {
    var rs = MDL_content._ct(rs_gn, "rs");

    return rs == null ? false : DB_fluid.db["group"]["conductive"].includes(rs.name);
  };
  exports._isConductiveLiq = _isConductiveLiq;


  /* <---------- block ----------> */


  const _isMapBlock = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-map");
  };
  exports._isMapBlock = _isMapBlock;


  const _isMiner = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-min");
  };
  exports._isMiner = _isMiner;


  const _isDrill = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-drl");
  };
  exports._isDrill = _isDrill;


  const _isOreScanner = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-scan");
  };
  exports._isOreScanner = _isOreScanner;


  const _isCrop = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-crop");
  };
  exports._isCrop = _isCrop;


  const _isItemDistributor = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-dis");
  };
  exports._isItemDistributor = _isItemDistributor;


  const _isConv = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-conv");
  };
  exports._isConv = _isConv;


  const _isBrd = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-brd");
  };
  exports._isBrd = _isBrd;


  const _isGate = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-gate");
  };
  exports._isGate = _isGate;


  const _isRouter = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-router");
  };
  exports._isRouter = _isRouter;


  const _isExposedBlock = function(blk_gn) {
    var blk = MDL_content._ct(blk_gn, "blk");

    return blk == null ? false : DB_block.db["group"]["exposed"].includes(blk.name);
  };
  exports._isExposedBlock = _isExposedBlock;


  const _isCont = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-cont");
  };
  exports._isCont = _isCont;


  const _isVirtBlk = function(blk_gn) {
    return _isCoreBlock(blk_gn) || _isVCont(blk_gn);
  };
  exports._isVirtBlk = _isVirtBlk;


  const _isVCont = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-vcont") || _isCoreBlock(blk_gn);
  };
  exports._isVCont = _isVCont;


  const _isCoreBlock = function(blk_gn) {
    var blk = MDL_content._ct(blk_gn, "blk")

    return blk == null ? false : (blk instanceof CoreBlock || MDL_content._hasTag(blk, "blk-core"));
  };
  exports._isCoreBlock = _isCoreBlock;


  const _isFCond = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-fcond");
  };
  exports._isFCond = _isFCond;


  const _isFCont = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-fcont");
  };
  exports._isFCont = _isFCont;


  const _isFJunc = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-fjunc");
  };
  exports._isFJunc = _isFJunc;


  const _isCloggable = function(blk_gn) {
    var blk = MDL_content._ct(blk_gn, "blk");

    return blk == null ? false : DB_block.db["group"]["cloggable"].includes(blk.name);
  };
  exports._isCloggable = _isCloggable;


  const _isEffcBlk = function(blk_gn) {
    return _isHCond(blk_gn) || _isECond(blk_gn) || _isECont(blk_gn);
  };
  exports._isEffcBlk = _isEffcBlk;


  const _isHCond = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-hcond");
  };
  exports._isHCond = _isHCond;


  const _isECond = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-econd");
  };
  exports._isECond = _isECond;


  const _isECont = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-econt");
  };
  exports._isECont = _isECont;


  const _canShortCircuit = function(blk_gn) {
    var blk = MDL_content._ct(blk_gn, "blk");

    return blk == null ? false : DB_block.db["group"]["shortCircuit"].includes(blk.name);
  };
  exports._canShortCircuit = _canShortCircuit;


  const _isPowTrans = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk0pow-trans");
  };
  exports._isPowTrans = _isPowTrans;


  const _isPowNode = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk0pow-node");
  };
  exports._isPowNode = _isPowNode;


  const _isRemotePowNode = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk0pow-rnode");
  };
  exports._isRemotePowNode = _isRemotePowNode;


  const _isMagnetic = function(blk_gn) {
    var blk = MDL_content._ct(blk_gn, "blk");

    return blk == null ? false : DB_block.db["group"]["magnetic"].includes(blk.name);
  };
  exports._isMagnetic = _isMagnetic;


  const _isFactory = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-fac");
  };
  exports._isFactory = _isFactory;


  const _isWall = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-wall");
  };
  exports._isWall = _isWall;


  /* <---------- env ----------> */


  const _isEnvBlock = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-env");
  };
  exports._isEnvBlock = _isEnvBlock;


  const _isVentBlock = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-vent");
  };
  exports._isVentBlock = _isVentBlock;


  const _isTreeBlock = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-tree");
  };
  exports._isTreeBlock = _isTreeBlock;


  const _isDepthOre = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-dpore");
  };
  exports._isDepthOre = _isDepthOre;


  const _isDepthLiquid = function(blk_gn) {
    return MDL_content._hasTag(MDL_content._ct(blk_gn, "blk"), "blk-dpliq");
  };
  exports._isDepthLiquid = _isDepthLiquid;


  const _isScannerTarget = function(blk_gn) {
    if(_isDepthOre(blk_gn) || _isDepthLiquid(blk_gn)) return true;

    return false;
  };
  exports._isScannerTarget = _isScannerTarget;


  /* <---------- unit type ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Wether this unit is related to core.
   * ---------------------------------------- */
  const _isCoreUnit = function(utp_gn) {
    var utp = MDL_content._ct(utp_gn, "utp");

    return utp == null ? false : DB_unit.db["group"]["coreUnit"].includes(utp.name);
  };
  exports._isCoreUnit = _isCoreUnit;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether this unit is a robot.
   * ---------------------------------------- */
  const _isNonRobot = function(utp_gn) {
    var utp = MDL_content._ct(utp_gn, "utp");

    return utp == null ? false : DB_unit.db["group"]["nonRobot"].includes(utp.name);
  };
  exports._isNonRobot = _isNonRobot;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether this unit can creates remains upon death.
   * ---------------------------------------- */
  const _hasNoRemains = function(utp_gn) {
    var utp = MDL_content._ct(utp_gn, "utp");

    return utp == null ? false : (
      DB_unit.db["group"]["noRemainsMod"].includes(MDL_content._mod(utp))
      || DB_unit.db["group"]["noRemains"].includes(utp.name)
      || _isNonRobot(utp)
      || utp instanceof MissileUnitType
    );
  };
  exports._hasNoRemains = _hasNoRemains;


  /* <---------- entity ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Wether this entity is supposed to update.
   * ---------------------------------------- */
  const _canUpdate = function(e) {
    if(e == null) return false;
    if(Vars.state.isEditor()) return false;
    if(e instanceof Building && !e.allowUpdate()) return false;

    return true;
  };
  exports._canUpdate = _canUpdate;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether this entity is in the screen and not covered by fog.
   * ---------------------------------------- */
  const _isVisible = function(e) {
    if(e == null) return false;

    return !e.inFogTo(Vars.player.team()) && _posVisible(e.x, e.y, MDL_entity._clipSize(e));
  };
  exports._isVisible = _isVisible;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether this entity is seen as enemy to {team}.
   * ---------------------------------------- */
  const _isEnemy = function(e, team) {
    if(e == null || team == null) return false;
    if(e.team === Team.derelict || e.team === team) return false;

    return true;
  };
  exports._isEnemy = _isEnemy;


  const _isBuildingActive = function(b) {
    if(b == null) return false;
    if(b.team === Team.derelict) return false;
    if(b.edelta() < 0.0001) return false;

    return true;
  };
  exports._isBuildingActive = _isBuildingActive;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether this unit can be controlled by AI.
   * ---------------------------------------- */
  const _isAiReady = function(unit) {
    if(unit == null) return false;
    if(unit.dead || unit.isPlayer()) return false;

    return true;
  };
  exports._isAiReady = _isAiReady;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the unit can be covered by trees.
   * ---------------------------------------- */
  const _isCoverable = function(unit, includeSize) {
    if(unit == null) return false;
    if(unit.flying || unit.type.groundLayer > 75.9999) return false;
    if(includeSize && unit.type.hitSize > VAR.rad_treeHideMaxRad - 0.0001) return false;

    return true;
  };
  exports._isCoverable = _isCoverable;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the unit is covered by trees.
   * ---------------------------------------- */
  const _isCovered = function(unit) {
    if(unit == null) return false;
    if(unit.hasEffect(Vars.content.statusEffect("lovec-sta-hidden-well"))) return true;

    return false;
  };
  exports._isCovered = _isCovered;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the unit can be damaged by heat.
   * ---------------------------------------- */
  const _isHeatDamageable = function(unit) {
    if(unit == null) return false;
    if(!_isOnFloor(unit)) return false;
    if(unit.type.naval) return false;

    return true;
  };
  exports._isHeatDamageable = _isHeatDamageable;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the unit can be affected by liquid floor.
   * ---------------------------------------- */
  const _isOnFloor = function(unit) {
    if(unit == null) return false;
    if(unit.flying) return false;
    if(unit.hovering && (unit instanceof Legsc)) return false;

    return true;
  };
  exports._isOnFloor = _isOnFloor;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the unit suffers from wall penalty.
   * ---------------------------------------- */
  const _isLowGround = function(unit) {
    if(unit == null) return false;
    if(unit.flying) return false;
    if(unit instanceof Legsc) return false;

    return true;
  };
  exports._isLowGround = _isLowGround;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the unit can be knockbacked by explosions.
   * ---------------------------------------- */
  const _isHighAir = function(unit) {
    if(unit == null) return false;
    if(!unit.flying) return false;
    if(unit.type.lowAltitude) return false;

    return true;
  };
  exports._isHighAir = _isHighAir;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the unit is moving (not done by collision).
   * ---------------------------------------- */
  const _isMoving = function(unit) {
    if(unit == null) return false;

    return unit.vel.len() > (unit.flying ? 0.1 : 0.01);
  };
  exports._isMoving = _isMoving;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the unit has injured status.
   * ---------------------------------------- */
  const _isInjured = function(unit) {
    if(unit == null) return false;
    if(unit.hasEffect(Vars.content.effect("lovec-sta-slightly-injured")) || unit.hasEffect(Vars.content.effect("lovec-sta-injured")) || unit.hasEffect(Vars.content.effect("lovec-sta-heavily-injured"))) return true;

    return false;
  };
  exports._isInjured = _isInjured;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the unit has damaged status.
   * ---------------------------------------- */
  const _isDamaged = function(unit) {
    if(unit == null) return false;
    if(unit.hasEffect(Vars.content.effect("lovec-sta-damaged")) || unit.hasEffect(Vars.content.effect("lovec-sta-severely-damaged"))) return true;

    return false;
  };
  exports._isDamaged = _isDamaged;


  const _hasEffectAny = function(unit, stas_gn) {
    if(unit == null) return false;
    var cond = false;
    var tmpSta;
    for(let sta_gn of stas_gn) {
      tmpSta = MDL_content._ct(sta_gn, "sta");
      if(tmpSta == null) continue;
      if(unit.hasEffect(tmpSta)) {
        cond = true;
        break;
      };
    };

    return cond;
  };
  exports._hasEffectAny = _hasEffectAny;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the unit is HOT.
   * Used for remains.
   * ---------------------------------------- */
  const _isHot = function(unit) {
    if(unit == null) return false;
    if(_hasEffectAny(unit, DB_status.db["group"]["hot"])) return true;
    //if(FRAG_heat._meltTime(unit) > 0.0) return true;

    let t = unit.tileOn();
    if(t != null && _isHotSta(t.floor().status)) return true;

    return false;
  };
  exports._isHot = _isHot;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the unit has been soaked in aqueous liquids recently.
   * This may influence something like short circuit.
   * ---------------------------------------- */
  const _isWet = function(unit) {
    if(unit == null) return false;
    if(_hasEffectAny(unit, DB_status.db["group"]["wet"])) return true;

    return false;
  };
  exports._isWet = _isWet;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the unit has at least one weapon active.
   * ---------------------------------------- */
  const _isAttacking = function(unit) {
    if(unit == null) return false;

    unit.mounts.forEach(mt => {if(mt.reload > 0.0) return true});

    return false;
  };
  exports._isAttacking = _isAttacking;


  /* ----------------------------------------
   * NOTE:
   *
   * Wether the unit is performing any actions.
   * ---------------------------------------- */
  const _isActing = function(unit) {
    if(unit == null) return false;
    if(_isMoving(unit) || _isAttacking(unit) || unit.mining() || unit.isBuilding()) return true;

    return false;
  };
  exports._isActing = _isActing;


  /* <---------- status effect ----------> */


  const _isHotSta = function(sta_gn) {
    var sta = MDL_content._ct(sta_gn, "sta");

    return sta == null ? false : DB_status.db["group"]["hot"].includes(sta.name);
  };
  exports._isHotSta = _isHotSta;


  const _isWetSta = function(sta_gn) {
    var sta = MDL_content._ct(sta_gn, "sta");

    return sta == null ? false : DB_status.db["group"]["wet"].includes(sta.name);
  };
  exports._isWetSta = _isWetSta;


  const _isBlkSta = function(sta_gn) {
    return MDL_content._hasTag(MDL_content._ct(sta_gn, "sta"), "blk-sta");
  };
  exports._isBlkSta = _isBlkSta;


  const _isStackSta = function(sta_gn) {
    var sta = MDL_content._ct(sta_gn, "sta");
    if(sta == null) return false;

    var cond;
    try {cond = sta.ex_isStackSta()} catch(err) {cond = false};

    return cond;
  };
  exports._isStackSta = _isStackSta;
