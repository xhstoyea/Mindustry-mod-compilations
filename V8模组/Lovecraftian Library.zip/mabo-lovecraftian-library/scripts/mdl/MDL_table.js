/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const VAR = require("lovec/glb/GLB_var");


  const MDL_bundle = require("lovec/mdl/MDL_bundle");
  const MDL_cond = require("lovec/mdl/MDL_cond");
  const MDL_content = require("lovec/mdl/MDL_content");
  const MDL_ui = require("lovec/mdl/MDL_ui");


  const TP_dial = require("lovec/tp/TP_dial");


  /* <---------- base ----------> */


  /* spacing */


  /* ----------------------------------------
   * NOTE:
   *
   * Sets margin for the cell quickly.
   * ---------------------------------------- */
  const __margin = function(tb, scl) {
    if(scl == null) scl = 1.0;

    return tb.marginLeft(12.0 * scl).marginRight(12.0 * scl).marginTop(15.0 * scl).marginBottom(15.0 * scl);
  };
  exports.__margin = __margin;


  /* new line */


  /* ----------------------------------------
   * NOTE:
   *
   * Adds empty lines.
   * ---------------------------------------- */
  const __break = function(tb, repeat) {
    if(repeat == null) repeat = 2;

    for(let i = 0; i < repeat; i++) {tb.add("").row()};
  };
  exports.__break = __break;


  /* ----------------------------------------
   * NOTE:
   *
   * A horizonal bar.
   * ---------------------------------------- */
  const __bar = function(tb, color, w, stroke) {
    if(color == null) color = Color.darkGray;
    if(stroke == null) stroke = 4.0;

    if(w == null) {
      tb.image().color(color).height(stroke).pad(0.0).growX().fillX().row();
    } else {
      tb.image().color(color).width(w).height(stroke).pad(0.0).fillX().row();
    };
  };
  exports.__bar = __bar;


  /* ----------------------------------------
   * NOTE:
   *
   * A vertical bar.
   * ---------------------------------------- */
  const __barV = function(tb, color, h, stroke) {
    if(color == null) color = Color.darkGray;
    if(stroke == null) stroke = 4.0;

    if(h == null) {
      return tb.image().color(color).width(stroke).pad(0.0).growY().fillY();
    } else {
      return tb.image().color(color).width(stroke).height(h).pad(0.0).fillY();
    };
  };
  exports.__barV = __barV;


  /* text */


  /* ----------------------------------------
   * NOTE:
   *
   * A text line that is wrapped.
   * ---------------------------------------- */
  const __wrapLine = function(tb, str, align, ord, padLeft) {
    if(align == null) align = Align.left;
    if(ord == null) ord = 0;
    if(padLeft == null) padLeft = 0.0;

    tb.add(str).center().labelAlign(align).wrap().width(MDL_ui._uiW(null, null, ord * VAR.rad_ordRad)).padLeft(padLeft).row();
  };
  exports.__wrapLine = __wrapLine;


  /* ----------------------------------------
   * NOTE:
   *
   * Used when a dialog has no contents.
   * ---------------------------------------- */
  const __textNothing = function(tb) {
    tb.add(MDL_bundle._info("lovec", "nothing")).center().row();
  };
  exports.__textNothing = __textNothing;


  /* input */


  /* ----------------------------------------
   * NOTE:
   *
   * The basic button template.
   * ---------------------------------------- */
  const __btnBase = function(tb, nm, scr, w, h) {
    if(w == null) w = 200.0;
    if(h == null) h = 50.0;

    return tb.button(nm, scr).size(w, h).center().pad(12.0);
  };
  exports.__btnBase = __btnBase;


  /* ----------------------------------------
   * NOTE:
   *
   * A button to close the dialog.
   * ---------------------------------------- */
  const __btnClose = function(tb, dial, w, h) {
    return __btnBase(tb, "@close", () => {
      dial.hide();
    }, w, h);
  };
  exports.__btnClose = __btnClose;


  /* ----------------------------------------
   * NOTE:
   *
   * A button to visit a website.
   * ---------------------------------------- */
  const __btnLink = function(tb, nm, url, w, h) {
    return __btnBase(tb, nm, () => {
      Core.app.openURI(url);
    }, w, h);
  };
  exports.__btnLink = __btnLink;


  /* ----------------------------------------
   * NOTE:
   *
   * A config button to switch {bool} property in a building.
   * ---------------------------------------- */
  const __btnCfg_toggle = function(tb, b, icon1, icon2, bool, w) {
    if(w == null) w = 24.0;

    tb.button(bool ? icon1 : icon2, w, () => {

      Call.tileConfig(Vars.player, b, bool.conj());
      b.deselect();

    }).center().row();
  };
  exports.__btnCfg_toggle = __btnCfg_toggle;


  /* ----------------------------------------
   * NOTE:
   *
   * Simply a slider.
   * Use arrow function for {scr} like:
   * val => print(val);
   * ---------------------------------------- */
  const __slider = function(tb, scr_val, min, max, step, def) {
    if(scr_val == null) scr_val = val => {};
    if(min == null) min = 0;
    if(max == null) max = 2;
    if(step == null) step = 1;
    if(def == null) def = min;

    tb.slider(min, max, step, ini, scr_val).row();
  };
  exports.__slider = __slider;


  /* content */


  /* ----------------------------------------
   * NOTE:
   *
   * Like what's done in {Stat.tiles}, but displays the attribute in tooltip.
   * ---------------------------------------- */
  const __blkEffc = function(tb, blk, mtp, nmAttr, w) {
    if(blk == null) return;

    if(w == null) w = 64.0;

    var str = (Math.abs(mtp) < 0.0001) ? "" : (Strings.autoFixed(mtp * 100.0, 2) + "%");
    return tb.table(Styles.none, tb1 => {

      tb.left();

      tb1.table(Styles.none, tb2 => {

        tb2.left();

        var btn = tb2.button(new TextureRegionDrawable(blk.uiIcon), w, TP_dial._ct(blk))
        .tooltip(blk.localizedName + ((nmAttr == null) ? "" : ("\n\n[green]" + MDL_attr._attrB(nmAttr) + "[]")))
        .padRight(-18.0)
        .get();
        tb2.table(Styles.none, tb3 => {

          tb3.left();

          __break(tb3);

          tb3.add(str)
          .fontScale(0.85)
          .left()
          .style(Styles.outlineLabel)
          .color(mtp < 0.0 ? Pal.remove : Pal.accent);

        });

        btn.margin(0.0);
        var btnStyle = btn.getStyle();
        btnStyle.up = Styles.none;
        btnStyle.down = Styles.none;
        btnStyle.over = Styles.flatOver;

      }).padRight(4.0);

    }).left().padRight(8.0).padTop(4.0).padBottom(4.0);
  };
  exports.__blkEffc = __blkEffc;


  const __ct = function(tb, ct, w, pad) {
    if(ct == null) return;

    if(w == null) w = 32.0;
    if(pad == null) pad = 4.0;

    var btnCell = tb.button(new TextureRegionDrawable(ct.uiIcon), w, () => Vars.ui.content.show(ct))
    .pad(pad)
    .tooltip(ct.localizedName, true);
    var btn = btnCell.get();

    btn.margin(0.0);
    var btnStyle = btn.getStyle();
    btnStyle.up = Styles.none;
    btnStyle.down = Styles.none;
    btnStyle.over = Styles.flatOver;

    return btnCell;
  };
  exports.__ct = __ct;


  /* ----------------------------------------
   * NOTE:
   *
   * A group of elements mainly used by recipe tables.
   * ---------------------------------------- */
  const __rcCt = function(tb, ct, amt, p, cancelLiq, w) {
    if(ct == null) return;

    if(amt == null) amt = -1;
    if(p == null) p = 1.0;
    if(cancelLiq == null) cancelLiq = false;
    if(w == null) w = 32.0;

    var str = (amt < 0) ? " ": ((ct instanceof Liquid && !cancelLiq) ? Strings.autoFixed(amt * 60.0, 2) + "/s" : Strings.autoFixed(amt, 0));

    return tb.table(Styles.none, tb1 => {

      tb1.left();

      tb1.table(Styles.none, tb2 => {

        tb2.left();

        var btn = tb2.button(new TextureRegionDrawable(ct.uiIcon), w, TP_dial._ct(ct))
        .tooltip(ct.localizedName)
        .padRight(-4.0)
        .get();
        tb2.table(Styles.none, tb3 => {

          tb3.left();

          tb3.add((Math.abs(p - 1.0) > 0.0001) ? (Strings.autoFixed(p * 100.0, 2) + "%") : "")
          .left()
          .fontScale(0.85)
          .style(Styles.outlineLabel)
          .color(Color.gray)
          .row();

          tb3.add(str)
          .left()
          .fontScale(0.85)
          .style(Styles.outlineLabel);

        });

        btn.margin(0.0);
        var btnStyle = btn.getStyle();
        btnStyle.up = Styles.none;
        btnStyle.down = Styles.none;
        btnStyle.over = Styles.flatOver;

      }).padRight(6.0);

    }).left().padRight(12.0).padTop(4.0).padBottom(4.0);
  };
  exports.__rcCt = __rcCt;


  /* <---------- text ----------> */


  const setText_headline = function(tb, str) {
    if(str == null) return;

    tb.table(Tex.button, tb1 => {

      tb1.left();

      tb1.add(str);

    }).left().row();
  };
  exports.setText_headline = setText_headline;


  const setStatText_note = function(tb, str, ord, padLeft) {
    if(str == null) return;

    if(ord == null) ord = 1;
    if(padLeft == null) padLeft = 0.0;

    tb.table(Tex.whiteui, tb1 => {

      tb1.center().setColor(Pal.darkestGray);
      __margin(tb1);

      __wrapLine(tb1, str, Align.center, ord, padLeft);

    }).padTop(8.0).padBottom(8.0).growX().row();
  };
  exports.setStatText_note = setStatText_note;


  /* <---------- table ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Sets up an outlined table for data display.
   * ---------------------------------------- */
  const setDisplay_table = function(tb, matArr, ws, hs, color, stroke, color_title, imgW) {
    if(ws == null) ws = [];
    if(hs == null) hs = [];
    if(imgW == null) imgW = 32.0;

    var rowAmt = matArr.iCap();
    var colAmt = matArr[0].iCap();
    var tmp = null;

    tb.table(Styles.none, tb1 => {

      __bar(tb1, color, null, stroke);

      for(let i = 0; i < rowAmt; i++) {
        var h = hs[i];
        if(h == null) h = 40.0;

        tb1.table((color_title != null && i === 0) ? Tex.whiteui : Styles.none, tb2 => {

          if(color_title != null) tb2.setColor(color_title);

          __barV(tb2, color, null, stroke);

          for(let j = 0; j < colAmt; j++) {
            var w = ws[j];
            if(w == null) w = 80.0;

            tb2.table(Styles.none, tb3 => {

              if(i === 0) {tb3.center()} else {tb3.left()};
              __margin(tb3);

              tmp = matArr[i][j];
              if(tmp != null) {

                if(tmp instanceof TextureRegion) {tb3.image(tmp).width(imgW).height(imgW)}
                else if(tmp instanceof UnlockableContent) {
                  var btn = tb3.button(new TextureRegionDrawable(tmp.uiIcon), imgW, TP_dial._ct(tmp))
                  .tooltip(tmp.localizedName)
                  .get();

                  btn.margin(0.0);
                  var btnStyle = btn.getStyle();
                  btnStyle.up = Styles.none;
                  btnStyle.down = Styles.none;
                  btnStyle.over = Styles.flatOver;
                }
                else if(typeof tmp === "string") {tb3.add(tmp)}
                else if(typeof tmp === "number") {tb3.add(Strings.autoFixed(tmp, 2))}
                else {tb3.add("!ERR")};

              };

            }).width(w);

            __barV(tb2, color, null, stroke);
          };

        }).height(h).row();

        __bar(tb1, color, null, stroke);
      };

    }).row();
  };
  exports.setDisplay_table = setDisplay_table;


  /* <---------- content ----------> */


  const setDisplay_ctRow = function(tb, cts_gn_p, showOrd) {
    let cts_gn;
    if(showOrd == null) showOrd = false;
    if(cts_gn_p instanceof Array) {cts_gn = cts_gn_p} else {
      cts_gn = [cts_gn_p];
      showOrd = false;
    };

    var ordCur = 0;

    __break(tb, 1);

    cts_gn.forEach(ct_gn => {
      let ct = MDL_content._ct(ct_gn);
      if(ct != null) {

        tb.table(Tex.whiteui, tb1 => {

          tb1.left().setColor(Pal.darkestGray);
          __margin(tb1);

          // @TABLE: order
          if(showOrd) tb1.table(Styles.none, tb2 => {

            tb2.left();

            tb2.table(Styles.none, tb3 => {

              tb3.center();

              tb3.add("[" + Strings.fixed(ordCur + 1.0, 0) + "]").color(Pal.accent);

            }).width(48.0);

          }).marginRight(18.0).growY();

          // @TABLE: content icon
          tb1.table(Styles.none, tb2 => {

            tb2.left();

            tb2.image(ct.uiIcon).size(Vars.iconLarge).padRight(18.0);
            __barV(tb2).padRight(18.0);
            tb2.add(ct.localizedName);

          });

          // @TABLE: spacing
          tb1.table(Styles.none, tb2 => {}).width(80.0).growX().growY();

          // @TABLE: "?" button
          tb1.table(Styles.none, tb2 => {

            tb2.left();

            tb2.button("?", () => Vars.ui.content.show(ct)).size(VAR.rad_charBtnRad);

          });

        }).growX().row();

        __break(tb, 1);

        ordCur++;

      };
    });
  };
  exports.setDisplay_ctRow = setDisplay_ctRow;


  const setDisplay_ctLi = function(tb, cts_gn_p, iconW, colAmt) {
    if(iconW == null) iconW = 32.0;
    if(colAmt == null) colAmt = MDL_ui._colAmt(iconW, 0.0, 2);

    let cts_gn;
    if(cts_gn_p instanceof Array) {cts_gn = cts_gn_p} else {
      cts_gn = [cts_gn_p];
    };

    tb.table(Tex.whiteui, tb1 => {

      tb1.left().setColor(Pal.darkestGray);
      __margin(tb1, 0.5);

      let iCap = cts_gn.length;
      if(iCap === 0) return;
      for(let i = 0, j = 0; i < iCap; i++) {
        (function(i) {
          let ct = MDL_content._ct(cts_gn[i]);
          if(ct == null) return;
          __ct(tb1, ct, iconW);
        })(i);

        if(j % colAmt === colAmt - 1) tb1.row();
        j++;
      };

    }).left().row();
  };
  exports.setDisplay_ctLi = setDisplay_ctLi;


  const setSelector_ctMulti = function(tb, blk, cts, ctsGetter, cfgCaller, closeSelect, rowAmt, colAmt, max) {
    if(closeSelect == null) closeSelect = false;
    if(rowAmt == null) rowAmt = 4;
    if(colAmt == null) colAmt = 4;
    if(max == null) max = 999999;

    var search = null;
    var countRow = 0;
    const btnGrp = new ButtonGroup();
    btnGrp.setMinCheckCount(0);
    btnGrp.setMaxCheckCount(max);
    const cont = new Table().top();
    cont.defaults().size(40.0);

    const rebuild = () => {
      btnGrp.clear();
      cont.clearChildren();

      let text = search == null ? "" : search.getText();
      countRow = 0;

      let arr = cts.filter(ct => (text === "" || text.localizedName.toLowerCase().contains(text.toLowerCase)));
      let iCap = arr.iCap();
      if(iCap > 0) {
        for(let i = 0, j = 0; i < iCap; i++) {

          j += (function(i) {
            var ct = arr[i];
            if(!MDL_cond._isRsAvailable(ct)) return 0;

            var btn = cont.button(Tex.whiteui, Styles.clearNoneTogglei, Mathf.clamp(ct.selectionSize, 0.0, 40.0), () => {
              if(closeSelect) Vars.control.input.config.hideConfig();
            }).tooltip(ct.localizedName, true).group(btnGrp).get();
            btn.changed(() => cfgCaller(btn.isChecked() ? new Seq(["selector", ct, true]) : new Seq(["selector", ct, false])));
            btn.getStyle().imageUp = new TextureRegionDrawable(ct.uiIcon);
            btn.update(() => btn.setChecked(ctsGetter().includes(ct)));

            return 1
          })(i);

          if((j - 1) % colAmt == colAmt - 1) {
            cont.row();
            j = 0;
            countRow++;
          };

        };
      };

    };
    rebuild();

    const root = new Table().background(Styles.black6);
    if(countRow > rowAmt * 1.5) root.table(Styles.none, tb1 => {

      tb1.image(Icon.zoom).padLeft(4.0);
      search = tb1.field(null, text => rebuild()).padBottom(4.0).left().growX().get();
      search.setMessageText("@players.search");

    }).fillX().row();

    const pn = new ScrollPane(cont, Styles.smallPane);
    pn.setScrollingDisabled(true, false);
    pn.exited(() => {
      if(pn.hasScroll()) Core.scene.setScrollFocus(null);
    });
    if(blk != null) {
      pn.setScrollYForce(blk.selectScroll);
      pn.update(() => blk.selectScroll = pn.getScrollY());
    };
    pn.setOverscroll(false, false);

    root.add(pn).maxHeight(rowAmt * 40.0);
    tb.top().add(root);
  };
  exports.setSelector_ctMulti = setSelector_ctMulti;
