/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  // NOTE: Nope, everything here should be independent and static.


  /* <---------- base ----------> */


  exports.jsonReader = new JsonReader();


  /* <---------- layer ----------> */


  exports.lay_offDraw = 6.11;
  exports.lay_offDrawOver = 26.11;


  exports.lay_effFlr = 14.11;
  exports.lay_effBase = 69.11;
  exports.lay_effSmog = 86.11;
  exports.lay_effSmogHigh = 116.01;
  exports.lay_effHigh = 116.41;
  exports.lay_overText = 212.11;


  exports.lay_vent = 0.61;
  exports.lay_randOv = 1.07;
  exports.lay_debugFlr = 2.21;
  exports.lay_unitRemains = 58.11;
  exports.lay_debugTop = 118.91;


  /* <---------- time ----------> */


  exports.time_paramIntv = 90.0;
  exports.time_paramGlobalIntv = 110.0;
  exports.time_lightningIntv = 40.0;
  exports.time_unitIntv = 20.0;


  exports.time_drownDef = 200.0;
  exports.time_flrStaDef = 40.0;
  exports.time_liqStaDef = 150.0;
  exports.time_unitStaDef = 100.0;
  exports.time_stackStaExtDef = 120.0;


  /* <---------- chance ----------> */


  exports.p_effPCap = 0.08;


  exports.p_unitUpdateP = 0.25;


  /* <---------- radius ----------> */


  exports.rad_ordRad = 120.0;
  exports.rad_mouseRad = 28.0;
  exports.rad_charBtnRad = 42.0;
  exports.rad_treeHideMaxRad = 28.0;


  exports.r_unitSurRange = 4;


  exports.r_offBuildStat = 2.25;


  exports.rad_treeScl = 0.15;


  /* <---------- resource ----------> */


  exports.rs_effcCap = 5.0;
