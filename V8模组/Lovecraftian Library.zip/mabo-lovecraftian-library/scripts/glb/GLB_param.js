/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TIMER = require("lovec/glb/GLB_timer");


  const MDL_cond = require("lovec/mdl/MDL_cond");
  const MDL_event = require("lovec/mdl/MDL_event");
  const MDL_util = require("lovec/mdl/MDL_util");


/*
  ========================================
  Section: Application
  ========================================
*/


  MDL_event._c_onUpdate(() => {
    if(TIMER.timerState_paramGlobal) {


      // Param
      let unit_pl = Vars.player.unit();


      /* <---------- param ----------> */


      exports.plaCur = Vars.state.rules.planet;
      exports.mapCur = Vars.state.map;


      /* <---------- setting ----------> */


      exports.testDraw = MDL_util._cfg("test-draw");
      exports.enableMemoryMonitor = MDL_util._cfg("test-memory");


      exports.drawWobble = MDL_util._cfg("draw-wobble");
      exports.drawBlurredShadow = MDL_util._cfg("draw0shadow-blurred");
      exports.treeAlpha = (Groups.player.size() > 1) ? 1.0 : MDL_util._cfg("draw0tree-alpha", true);
      exports.checkTreeDst = MDL_util._cfg("draw0tree-player") && MDL_cond._isCoverable(unit_pl);
      exports.drawTreeShadow = MDL_util._cfg("draw0tree-shadow");
      exports.drawBridgeTransportLine = MDL_util._cfg("draw0aux-bridge");
      exports.drawRouterHeresy = MDL_util._cfg("draw0aux-router");


      exports.showIconTag = MDL_util._cfg("icontag-show");
      exports.iconTagIntv = MDL_util._cfg("icontag-interval", true);


      exports.drawUnitStat = MDL_util._cfg("unit0stat-show");
      exports.drawPlayerStat = MDL_util._cfg("unit0stat-player");
      exports.drawUnitReload = MDL_util._cfg("unit0stat-reload");
      exports.drawMissileStat = MDL_util._cfg("unit0stat-missile");
      exports.drawBuildStat = MDL_util._cfg("unit0stat-build");
      exports.drawUnitNearMouse = MDL_util._cfg("unit0stat-mouse");


      exports.displayDamage = MDL_util._cfg("damagedisplay-show");
      exports.unitRemainsLifetime = MDL_util._cfg("unit0remains-lifetime", true);


    };
  }, 12976533);
