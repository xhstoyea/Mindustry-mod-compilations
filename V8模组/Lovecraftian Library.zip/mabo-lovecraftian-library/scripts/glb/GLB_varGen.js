/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const MDL_cond = require("lovec/mdl/MDL_cond");
  const MDL_event = require("lovec/mdl/MDL_event");


  const DB_item = require("lovec/db/DB_item");


  /* <---------- sprite ----------> */


  MDL_event._c_onLoad(() => {


    exports.icons = {
      check: new TextureRegionDrawable(Core.atlas.find("lovec-icon-check")),
      cross: new TextureRegionDrawable(Core.atlas.find("lovec-icon-cross")),
      harvest: new TextureRegionDrawable(Core.atlas.find("lovec-icon-harvest")),
      play: new TextureRegionDrawable(Core.atlas.find("lovec-icon-play")),
      swap: new TextureRegionDrawable(Core.atlas.find("lovec-icon-swap")),
    };


  }, 25777741);


  /* <---------- list ----------> */


  MDL_event._c_onLoad(() => {


    exports.mainTeams = [
      Team.sharded,
      Team.crux,
      Team.malis,
      Team.green,
      Team.blue,
      Team.neoplastic,
    ];


    exports.sandItms = Vars.content.items().select(itm => DB_item.db["group"]["sand"].includes(itm.name)).toArray();


    exports.bioticUtps = Vars.content.units().select(utp => MDL_cond._isNonRobot(utp)).toArray();
    exports.navalUtps = Vars.content.units().select(utp => utp.naval).toArray();


    exports.blkStas = Vars.content.statusEffects().select(sta => MDL_cond._isBlkSta(sta)).toArray();
    exports.stackStas = Vars.content.statusEffects().select(sta => MDL_cond._isStackSta(sta)).toArray();


  }, 79532268);
