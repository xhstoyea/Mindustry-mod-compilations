/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  /* <---------- base ----------> */


  const INTEGER = java.lang.Integer;
  exports.INTEGER = INTEGER;


  const BYTE = java.lang.Byte;
  exports.BYTE = BYTE;


  const SHORT = java.lang.Short;
  exports.SHORT = SHORT;


  const LONG = java.lang.Long;
  exports.LONG = LONG;


  const FLOAT = java.lang.Float;
  exports.FLOAT = FLOAT;


  const DOUBLE = java.lang.Double;
  exports.DOUBLE = DOUBLE;


  const BOOLEAN = java.lang.Boolean;
  exports.BOOLEAN = BOOLEAN;


  const STRING = java.lang.String;
  exports.STRING = STRING;


  const OBJECT = java.lang.Object;
  exports.OBJECT = OBJECT;
