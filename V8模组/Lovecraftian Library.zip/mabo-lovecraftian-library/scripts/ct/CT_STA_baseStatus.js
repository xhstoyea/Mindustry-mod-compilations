/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/sta/STA_baseStatus");
  const EFF = require("lovec/glb/GLB_eff");


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- sta ----------> */


  const sta_damaged = extend(StatusEffect, "sta-damaged", {
    init() {
      this.super$init();
      TEMPLATE.init(this);
    },
    setStats() {
      this.super$setStats();
      TEMPLATE.setStats(this);
    },
    update(unit, time) {
      this.super$update(unit, time);
      TEMPLATE.update(this, unit, time);
    },
    ex_getTags() {
      return TEMPLATE.ex_getTags(this);
    },
    // @SPEC
    effect: EFF.unitDamagedSmog, effectChance: 0.08,
  });
  exports.sta_damaged = sta_damaged;


  const sta_severelyDamaged = extend(StatusEffect, "sta-severely-damaged", {
    init() {
      this.super$init();
      TEMPLATE.init(this);
    },
    setStats() {
      this.super$setStats();
      TEMPLATE.setStats(this);
    },
    update(unit, time) {
      this.super$update(unit, time);
      TEMPLATE.update(this, unit, time);
    },
    ex_getTags() {
      return TEMPLATE.ex_getTags(this);
    },
    // @SPEC
    effect: EFF.unitDamagedSmog, effectChance: 0.3,
  });
  exports.sta_severelyDamaged = sta_severelyDamaged;


  const sta_hiddenWell = extend(StatusEffect, "sta-hidden-well", {
    init() {
      this.super$init();
      TEMPLATE.init(this);
    },
    setStats() {
      this.super$setStats();
      TEMPLATE.setStats(this);
    },
    update(unit, time) {
      this.super$update(unit, time);
      TEMPLATE.update(this, unit, time);
    },
    ex_getTags() {
      return TEMPLATE.ex_getTags(this);
    },
  });
  exports.sta_hiddenWell = sta_hiddenWell;
