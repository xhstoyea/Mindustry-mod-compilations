/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/sta/STA_liquidStatus");
  const EFF = require("lovec/glb/GLB_eff");


  const TP_effect = require("lovec/tp/TP_effect");


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- sta0liq ----------> */


  const sta0liq_seaWaterCorrosion = extend(StatusEffect, "sta0liq-sea-water-corrosion", {
    burstTime: 1800.0,
    burstDamage: 75.0, burstDamagePerc: 0.0075,
    burstScr: unit => {},
    burstEff: EFF.circlePulseDynamic, burstEffColor: Color.valueOf("6fb6bf"),
    init() {
      this.super$init();
      TEMPLATE.init(this);
    },
    setStats() {
      this.super$setStats();
      TEMPLATE.setStats(this);
    },
    update(unit, time) {
      this.super$update(unit, time);
      TEMPLATE.update(this, unit, time);
    },
    ex_getTags() {
      return TEMPLATE.ex_getTags(this);
    },
    ex_isStackSta() {
      return TEMPLATE.ex_isStackSta(this);
    },
    ex_getBurstTime() {
      return TEMPLATE.ex_getBurstTime(this);
    },
    // @SPEC
    effect: TP_effect._wetParticle("6fb6bf"), effectChance: 0.08,
  });
  exports.sta0liq_seaWaterCorrosion = sta0liq_seaWaterCorrosion;


  const sta0liq_brineCorrosion = extend(StatusEffect, "sta0liq-brine-corrosion", {
    burstTime: 1800.0,
    burstDamage: 150.0, burstDamagePerc: 0.015,
    burstScr: unit => {},
    burstEff: EFF.circlePulseDynamic, burstEffColor: Color.valueOf("d8c0d4"),
    init() {
      this.super$init();
      TEMPLATE.init(this);
    },
    setStats() {
      this.super$setStats();
      TEMPLATE.setStats(this);
    },
    update(unit, time) {
      this.super$update(unit, time);
      TEMPLATE.update(this, unit, time);
    },
    ex_getTags() {
      return TEMPLATE.ex_getTags(this);
    },
    ex_isStackSta() {
      return TEMPLATE.ex_isStackSta(this);
    },
    ex_getBurstTime() {
      return TEMPLATE.ex_getBurstTime(this);
    },
    // @SPEC
    effect: TP_effect._wetParticle("d8c0d4"), effectChance: 0.08,
  });
  exports.sta0liq_brineCorrosion = sta0liq_brineCorrosion;
