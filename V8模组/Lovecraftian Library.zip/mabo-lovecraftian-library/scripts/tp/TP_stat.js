/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  /* <---------- base ----------> */


  const newIns_stat = function(bp, statCat) {
    if(statCat == null) statCat = StatCat.function;

    return new Stat("lovec-stat-" + bp, statCat);
  };


  const newIns_statUnit = function(bp, param) {
    return param == null ? new StatUnit("lovec-stat0unit-" + bp) : new StatUnit("lovec-stat0unit-" + bp, param);
  };


  /* <---------- stat ----------> */


  /* block */


  exports.blk_polTol = newIns_stat("blk-poltol");


  /* block (env) */


  exports.blk0env_ventSize = newIns_stat("blk0env-ventsize", StatCat.general);
  exports.blk0env_treeType = newIns_stat("blk0env-treetype", StatCat.general);
  exports.blk0env_rsLevel = newIns_stat("blk0env-rslevel", StatCat.general);


  /* block (miner) */


  exports.blk0min_baseDrillSpd = newIns_stat("blk0min-basedrillspd", StatCat.crafting);
  exports.blk0min_boostedDrillSpd = newIns_stat("blk0min-boosteddrillspd", StatCat.crafting);
  exports.blk0min_drillTier = newIns_stat("blk0min-drilltier", StatCat.crafting);
  exports.blk0min_blockedItms = newIns_stat("blk0min-blockeditms", StatCat.crafting);


  /* block (item) */


  exports.blk0itm_unloadable = newIns_stat("blk0itm-unloadable");
  exports.blk0itm_exposed = newIns_stat("blk0itm-exposed");


  /* block (misc) */


  exports.blk0misc_cepProv = newIns_stat("blk0misc-cepprov");
  exports.blk0misc_cepUse = newIns_stat("blk0misc-cepuse");


  /* resource */


  exports.rs_isOre = newIns_stat("rs-isore");
  exports.rs_sintTemp = newIns_stat("rs-sinttemp");


  exports.rs_isConsumable = newIns_stat("rs-isconsumable");
  exports.rs_isIntermediate = newIns_stat("rs-isintermediate");
  exports.rs_isWaste = newIns_stat("rs-iswaste");


  exports.rs_buildable = newIns_stat("rs-buildable");
  exports.rs_hardness = newIns_stat("rs-hardness");


  exports.rs_fluidStatus = newIns_stat("rs-fluidstatus");
  exports.rs_conductiveLiq = newIns_stat("rs-conductiveliq");


  exports.rs_dens = newIns_stat("rs-dens");
  exports.rs_fHeat = newIns_stat("rs-fheat");


  exports.rs_eleGrp = newIns_stat("rs-elegrp");
  exports.rs_fTags = newIns_stat("rs-ftags");
  exports.rs_corPow = newIns_stat("rs-corpow");


  exports.rs_blockRelated = newIns_stat("rs-blockrelated");


  /* unit type */


  exports.utp_notRobot = newIns_stat("utp-notrobot");


  /* status */


  exports.sta_robotOnly = newIns_stat("sta-robotonly");
  exports.sta_burstTime = newIns_stat("sta-bursttime");
  exports.sta_burstDmg = newIns_stat("sta-burstdmg");


  /* <---------- stat unit ----------> */


  /* block */


  exports.blk_perBlock = newIns_statUnit("blk-perblock", true);


  exports.blk_polUnits = newIns_statUnit("rs-polunits");


  /* resource */


  exports.rs_heatUnits = newIns_statUnit("rs-heatunits");
