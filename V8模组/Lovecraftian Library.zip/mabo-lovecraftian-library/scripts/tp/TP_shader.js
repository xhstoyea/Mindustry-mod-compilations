/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  /* <---------- auxilliary ----------> */


  const newIns_surf = function(nmFrag) {
    return new Shaders.SurfaceShader(nmFrag);
  };
  exports.newIns_surf = newIns_surf;


  /* <---------- base ----------> */


  exports.shad0surf_liq = newIns_surf("shad0surf-liq");
  exports.shad0surf_liq1 = newIns_surf("shad0surf-liq1");
