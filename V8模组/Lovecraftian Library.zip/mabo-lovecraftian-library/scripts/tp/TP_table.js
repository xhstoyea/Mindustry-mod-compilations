/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const MDL_table = require("lovec/mdl/MDL_table");
  const MDL_ui = require("lovec/mdl/MDL_ui");


  /* <---------- actor ----------> */


  const _winDial = function(title, tableF) {
    if(title == null) title = "";

    const winDial = new Table();
    winDial.dragged((dx, dy) => {
      winDial.translation.x += dx;
      winDial.translation.y += dy;
    });
    winDial.setPosition(MDL_ui._centerX(), MDL_ui._centerY(), Align.center);

    winDial.table(Tex.whiteui, tb => {

      tb.left().setColor(Color.darkGray);

      tb.table(Styles.none, tb1 => {

        tb1.left();
        MDL_table.__margin(tb1, 0.25);

        tb1.table(Styles.none, tb2 => tb2.add(title));
        tb1.table(Styles.none, tb2 => {}).width(80.0).growX();
        tb1.table(Styles.none, tb2 => tb2.add("x")).get().clicked(() => {
          winDial.actions(Actions.remove());
          winDial.act(0.1);
        });

      });

    }).row();

    winDial.table(Tex.whiteui, tb => {

      tb.left().setColor(Pal.darkestGray);

      tb.table(Styles.none, tb1 => {

        tb1.left();
        MDL_table.__margin(tb1);

        tableF(tb1);

      });

    }).fillX().row();

    return winDial;
  };
  exports._winDial = _winDial;
