/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TP_shader = require("lovec/tp/TP_shader");


  /* <---------- auxilliary ----------> */


  const newIns_shad = function(shader) {
    var cacheLay = new CacheLayer.ShaderLayer(shader);
    CacheLayer.add(cacheLay);

    return cacheLay;
  };
  exports.newIns_shad = newIns_shad


  /* <---------- base ----------> */


  exports.shad0surf_liq = newIns_shad(TP_shader.shad0surf_liq);
  exports.shad0surf_liq1 = newIns_shad(TP_shader.shad0surf_liq1);
