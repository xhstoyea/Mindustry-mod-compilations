/*
  ========================================
  Section: Introduction
  ========================================
*/


  /* ----------------------------------------
   * NOTE:
   *
   * This file defines dialogs, which are closely related to tables.
   * Dialogs are only created after load event, to ensure {Core.scene} is not {null}.
   * Do NOT call a dialog before that!
   * ---------------------------------------- */


/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const MDL_content = require("lovec/mdl/MDL_content");
  const MDL_event = require("lovec/mdl/MDL_event");
  const MDL_table = require("lovec/mdl/MDL_table");
  const MDL_ui = require("lovec/mdl/MDL_ui");


  /* <---------- content ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Calls a dialog that shows a list of contents.
   * Title color can be customized using color marks.
   * ---------------------------------------- */
  let cts;
  MDL_event._c_onLoad(() => {
    cts = extend(BaseDialog, "", {


      ex_show(title, cts_gn) {
        this.cont.clear();
        this.buttons.clear();

        // @TABLE: title
        this.title.setText("[accent]" + title + "[]");
        this.title.getStyle().fontColor = Color.white;

        // @TABLE: content
        MDL_table.__break(this.cont);
        this.cont.pane(pn => {

          MDL_table.__margin(pn);

          let iCap = cts_gn.iCap();
          let colAmt = MDL_ui._colAmt(32.0, 4.0, 2);
          if(iCap > 0) {

            for(let i = 0, j = 0; i < iCap; i++) {
              (function(i) {
                MDL_table.__ct(pn, MDL_content._ct(cts_gn[i]));
              })(i);

              if(j % colAmt === colAmt - 1) pn.row();
              j++;
            };

          } else {

            MDL_table.__textNothing(pn);

          };

        }).width(MDL_ui._uiW()).row();

        // @TABLE: buttons
        MDL_table.__break(this.cont);
        MDL_table.__btnClose(this.buttons, this);

        this.show();
      },


    });
    exports.cts = cts;
  }, 524126);


  /* ----------------------------------------
   * NOTE:
   *
   * Calls a dialog for content display in rows.
   * ---------------------------------------- */
  let ctsRow;
  MDL_event._c_onLoad(() => {
    ctsRow = extend(BaseDialog, "", {


      ex_show(title, cts_gn) {
        this.cont.clear();
        this.buttons.clear();

        // @TABLE: title
        this.title.setText("[accent]" + title + "[]");
        this.title.getStyle().fontColor = Color.white;

        // @TABLE: content
        MDL_table.__break(this.cont);
        this.cont.pane(pn => {

          MDL_table.setDisplay_ctRow(pn, cts_gn, true);

        }).width(MDL_ui._uiW()).row();

        // @TABLE: buttons
        MDL_table.__break(this.cont);
        MDL_table.__btnClose(this.buttons, this);

        this.show();
      },


    });
    exports.ctsRow = ctsRow;
  }, 124877);


  /* <---------- info ----------> */


  /* ----------------------------------------
   * NOTE:
   *
   * Calls a dialog for basic information display.
   * {infoStr} is the text shown above content. {null} to disable it.
   * {cont} is a table.
   * ---------------------------------------- */
  let baseInfo;
  MDL_event._c_onLoad(() => {
    baseInfo = extend(BaseDialog, "", {


      ex_show(title, infoStr, tableF) {
        this.cont.clear();
        this.buttons.clear();

        this.title.setText("[accent]" + title + "[]");
        this.title.getStyle().fontColor = Color.white;

        // @TABLE: info
        if(infoStr != null) {
          MDL_table.__break(this.cont);
          this.cont.table(Tex.whiteui, tb => {

            tb.setColor(Pal.darkestGray);
            MDL_table.__margin(tb);

            MDL_table.__wrapLine(tb, "[gray]" + infoStr + "[]");

          }).row();
        };

        // @TABLE: bar
        if(infoStr != null && tableF != null) {
          MDL_table.__break(this.cont);
          MDL_table.__bar(this.cont, null, MDL_ui._uiW());
        };

        // @TABLE: content
        if(tableF != null) {
          MDL_table.__break(this.cont);
          this.cont.pane(pn => {

            MDL_table.__margin(pn);

            tableF(pn);

          });
        };

        // @TABLE: buttons
        MDL_table.__break(this.cont);
        MDL_table.__btnClose(this.buttons, this);

        this.show();
      },


    });
    exports.baseInfo = baseInfo;
  }, 426331);
