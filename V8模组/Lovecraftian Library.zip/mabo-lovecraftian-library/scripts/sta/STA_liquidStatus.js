/*
  ========================================
  Section: Introduction
  ========================================
*/


  /* ----------------------------------------
   * NOTE:
   *
   * Status effects that is mainly applied by liquids.
   * ---------------------------------------- */


  /* ----------------------------------------
   * BASE:
   *
   * StatusEffect
   * ---------------------------------------- */


  /* ----------------------------------------
   * PARAM:
   *
   * !NOTHING
   * ---------------------------------------- */


/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const PARENT = require("lovec/sta/STA_baseStatus");
  const TIMER = require("lovec/glb/GLB_timer");
  const VAR = require("lovec/glb/GLB_var");


  const FRAG_attack = require("lovec/frag/FRAG_attack");


  const MDL_cond = require("lovec/mdl/MDL_cond");
  const MDL_content = require("lovec/mdl/MDL_content");
  const MDL_text = require("lovec/mdl/MDL_text");


  const TP_stat = require("lovec/tp/TP_stat");


  /* <---------- component ----------> */


  function comp_setStats(sta) {
    if(sta.burstTime > 0.0) sta.stats.add(TP_stat.sta_burstTime, sta.burstTime / 60.0, StatUnit.seconds);
    if(sta.burstDamage > 0.0) sta.stats.add(TP_stat.sta_burstDmg, MDL_text._dmgText(sta.burstDamage, sta.burstDamagePerc));
  };


  function comp_update(sta, unit, staEn) {
    if(sta.burstTime < 0.0001) return;

    if(TIMER.timerState_stackSta) {
      let t = unit.tileOn();
      if(t != null && MDL_cond._isOnFloor(unit)) {
        let flr = t.floor();
        let puddle = Puddles.get(t);

        if(puddle != null && puddle.liquid.effect === sta) {
          unit.apply(sta, staEn.time + VAR.time_stackStaExtDef);
        } else if(flr.status === sta && flr.statusDuration > 0.0) {
          unit.apply(sta, staEn.time + VAR.time_stackStaExtDef) * (flr.shallow ? 1.0 : 2.0);
        };
      };
    };

    if(staEn.time > sta.burstTime) {
      let dmg = sta.burstDamage + unit.maxHealth * sta.burstDamagePerc;
      FRAG_attack.damage(unit, dmg, true);
      sta.burstScr(unit);
      sta.burstEff.at(unit.x, unit.y, unit.type.hitSize * 1.1, sta.burstEffColor);
      unit.unapply(sta);
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  const TEMPLATE = {


    /* <---------- status ----------> */


    init: function(sta) {
      PARENT.init(sta);
    },


    setStats: function(sta) {
      PARENT.setStats(sta);
      comp_setStats(sta);
    },


    update: function(sta, unit, staEn) {
      PARENT.update(sta, unit, staEn);
      comp_update(sta, unit, staEn);
    },


    /* <---------- status (specific) ----------> */


    /* <---------- status (extra) ----------> */


    // @NOSUPER
    ex_getTags: function(sta) {
      return TEMPLATE.ex_getTags.funArr;
    }.setProp({
      "funArr": [],
    }),


    // @NOSUPER
    ex_isStackSta: function(sta) {
      return sta.burstTime > 0.0;
    },


    // @NOSUPER
    ex_getBurstTime: function(sta) {
      return sta.burstTime;
    },


  };


  TEMPLATE._std = function(eff, effP, burstTime, burstDmg, burstDmgPerc, burstScr, burstEff, burstEffColor) {
    return {
      burstTime: Object.val(burstTime, 0.0),
      burstDamage: Object.val(burstDmg, 0.0), burstDamagePerc: Object.val(burstDmgPerc, 0.0),
      burstScr: Object.val(burstScr, function(unit) {}),
      burstEff: Object.val(burstEff, Fx.none), burstEffColor: Object.val(burstEffColor, Color.white),
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      update(unit, staEn) {
        this.super$update(unit, staEn);
        TEMPLATE.update(this, unit, staEn);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      ex_isStackSta() {
        return TEMPLATE.ex_isStackSta(this);
      },
      ex_getBurstTime() {
        return TEMPLATE.ex_getBurstTime(this);
      },
      // @SPEC
      effect: Object.val(eff, Fx.none), effectChance: Object.val(effP, 0.02),
    };
  };


  module.exports = TEMPLATE;
