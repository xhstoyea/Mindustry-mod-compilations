const MDL_util = require("lovec/mdl/MDL_util");


const db = {


  "group": {


    /* ----------------------------------------
     * NOTE:
     *
     * These status effects can't be applied to biotic units.
     * ---------------------------------------- */
    "robotOnly": [

      "lovec-sta0liq-sea-water-corrosion",
      "lovec-sta0liq-brine-corrosion",

    ],


    /* ----------------------------------------
     * NOTE:
     *
     * These status effects are related to sea, naval units will gain immunity to these.
     * ---------------------------------------- */
    "oceanic": [

      "wet",

      "lovec-sta0liq-sea-water-corrosion",

    ],


    /* ----------------------------------------
     * NOTE:
     *
     * These status effects are related to high temperature.
     * ---------------------------------------- */
    "hot": [

      "burning",
      "melting",

      "lovec-sta0bur-overheated",

    ],


    /* ----------------------------------------
     * NOTE:
     *
     * These status effects are related to being soaked in aqueous liquids.
     * ---------------------------------------- */
    "wet": [

      "wet",

      "lovec-sta0liq-sea-water-corrosion",
      "lovec-sta0liq-brine-corrosion",

    ],


  },


};


MDL_util.mergeDB(db, "DB_status");


exports.db = db;
