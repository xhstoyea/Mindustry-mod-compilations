const MDL_content = require("lovec/mdl/MDL_content");
const MDL_util = require("lovec/mdl/MDL_util");


const db = {


  "param": {


    "pla": {


      "wind": [],


    },


    "map": {


      "weArr": [],


      "wind": [],


    },


  },


  "map": {


    "randRegTag": [

      "rock", MDL_content._randRegs_rock,
      "rock-sand", MDL_content._randRegs_rockSand,

    ],


  },


  /* ----------------------------------------
   * NOTE:
   *
   * Maps name of a node root to the localized name of a content.
   *
   * Example:
   * "core-shard", "serpulo",    // Sets the name of root with {Blocks.coreShard} to localized name of {Planets.serpulo}
   * ---------------------------------------- */
  "nodeRootNameMap": [],


};


MDL_util.mergeDB(db, "DB_env");


exports.db = db;
