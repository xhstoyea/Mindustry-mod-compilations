const MDL_util = require("lovec/mdl/MDL_util");


const db = {


  "param": {


    /* ----------------------------------------
     * NOTE:
     *
     * Hardness of the item, mostly used for ore items.
     * Will overwrite the value defined anywhere else.
     * Required for proper recipe generation.
     * ---------------------------------------- */
    "hardness": [],


    /* ----------------------------------------
     * NOTE:
     *
     * The temperature for sintering process, used for recipe generation.
     * Can be applied to ore items only.
     * ---------------------------------------- */
    "sintTemp": [],


  },


  "group": {


    /* ----------------------------------------
     * NOTE:
     *
     * Items here are not mineable by regular drills by default.
     * A sand miner is required.
     * ---------------------------------------- */
    "sand": [

      "loveclab-item0ore-sand",
      "loveclab-item0ore-sand-river",
      "loveclab-item0ore-sand-sea",

    ],


  },


  /* ----------------------------------------
   * NOTE:
   *
   * Those resource tags have icon tag sprites, which will be shown over the resource icon.
   * ---------------------------------------- */
  "iconTag": [

    "rs-p1",
    "rs-p2",

    "rs-chunks",
    "rs-clean",
    "rs-conc",
    "rs-crude0gas",
    "rs-dust",

  ],


};


MDL_util.mergeDB(db, "DB_item");


exports.db = db;
