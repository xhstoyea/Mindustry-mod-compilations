const MDL_util = require("lovec/mdl/MDL_util");


const db = {


  "param": {


    "range": {


      "base": [],


      "impact": [],


      "ep": [],


    },


    "speed": {


      "base": [],


    },


    "corRes": [],


    /* ----------------------------------------
     * NOTE:
     *
     * How many pollution points the block generates per block.
     * ---------------------------------------- */
    "pol": [],


    /* ----------------------------------------
     * NOTE:
     *
     * Pollution tolerance.
     * Some buildings may halt.
     * ---------------------------------------- */
    "polTol": [],


    /* ----------------------------------------
     * NOTE:
     *
     * @DYNAMIC: (b) => {...}
     * Core energy points provided/used by a block.
     * Core block provides 5 points by default.
     * ---------------------------------------- */
    "cep": {


      "prov": [],


      "use": [],


    },


  },


  "group": {


    /* ----------------------------------------
     * NOTE:
     *
     * Material groups, used mainly for corrosion.
     * ---------------------------------------- */
    "material": {


      "wood": [],


      "copper": [],


      "lead": [],


      "iron": [],


      "steel": [],


      "galvanized": [],


      "stainless": [],


      "glass": [],


      "cement": [],


      "rubber": [],


    },


    /* ----------------------------------------
     * NOTE:
     *
     * These blocks will trigger item reaction.
     * Only works for item blocks.
     * ---------------------------------------- */
    "exposed": [],


    /* ----------------------------------------
     * NOTE:
     *
     * Theses blocks will get damaged if containing viscous fluids.
     * ---------------------------------------- */
    "cloggable": [],


    /* ----------------------------------------
     * NOTE:
     *
     * Theses blocks can short-circuit if soaked in water.
     * ---------------------------------------- */
    "shortCircuit": [],


    /* ----------------------------------------
     * NOTE:
     *
     * These blocks provide magnetic disturbance.
     * ---------------------------------------- */
    "magnetic": [],


    /* ----------------------------------------
     * NOTE:
     *
     * These blocks have reload bars.
     * ---------------------------------------- */
    "showReload": [

      "mass-driver",
      "payload-mass-driver",
      "large-payload-mass-driver",
      "shockwave-tower",

      "lancer",
      "ripple",
      "foreshadow",
      "meltdown",
      "titan",
      "afflict",
      "scathe",

    ],


  },


  "grpParam": {


    "corRes": [

      "wood", 1.0,
      "copper", 1.5,
      "lead", 1.5,
      "iron", 1.5,
      "steel", 2.0,
      "galvanized", 4.0,
      "stainless", 6.5,
      "glass", 12.5,
      "cement", 3.0,
      "rubber", 8.5,

    ],


  },


};


MDL_util.mergeDB(db, "DB_block");


exports.db = db;
