# Lovecraftian Library

Lovec is a javascript library mod that I made mostly for my other mods, it alone does not add any new contents, and can be used as a QOL mod for recipe searching, health bar display, etc.

The mod is based on my previous mod [Reindustrialization](https://github.com/HuanXefh/Reindustrialization), which has been separated into several mods now. See LovecLab and ProjReind.

If you have any ideas for new mechanics or want to report bugs, you can DM me on Discord (maboroshix).

Note on Jul 28, 2025: LovecLab and ProjReind are **UNFINISHED** and the repos are **NOT** created yet.
