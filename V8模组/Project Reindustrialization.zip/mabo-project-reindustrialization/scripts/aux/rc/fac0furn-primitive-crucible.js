const MDL_content = require("lovec/mdl/MDL_content");


const rc = {


  // craftTime: 60s


  "base": [


  ],


  "recipe": [


    /* <---------- alloying ----------> */


    /* copper */


    "ALLOYING: brass", {

      "icon": "loveclab-item0chem-brass",
      "category": "alloying",
      "tempReq": MDL_content._exSintTemp(["loveclab-item0chem-copper", "loveclab-item0chem-zinc"], "max"),

      "bi": [
        [
          "loveclab-item0chem-copper", 30, 1.0,
          "loveclab-item0ore-native-copper", 45, 1.0,
        ], -1.0, -1.0,
        "loveclab-item0chem-zinc", 15, 1.0,
      ],

      "bo": [
        "loveclab-item0chem-brass", 60, 0.5,
      ],

    },


    "ALLOYING: tin bronze", {

      "icon": "loveclab-item0chem-tin-bronze",
      "category": "alloying",
      "tempReq": MDL_content._exSintTemp(["loveclab-item0chem-copper", "loveclab-item0chem-tin"], "max"),

      "bi": [
        [
          "loveclab-item0chem-copper", 30, 1.0,
          "loveclab-item0ore-native-copper", 45, 1.0,
        ], -1.0, -1.0,
        "loveclab-item0chem-tin", 15, 1.0,
      ],

      "bo": [
        "loveclab-item0chem-tin-bronze", 60, 0.5,
      ],

    },


    /* lead */


    "ALLOYING: solder", {

      "icon": "loveclab-item0chem-solder",
      "category": "alloying",
      "tempReq": MDL_content._exSintTemp(["loveclab-item0chem-lead", "loveclab-item0chem-tin"], "max"),

      "bi": [
        "loveclab-item0chem-lead", 30, 1.0,
        "loveclab-item0chem-tin", 15, 1.0,
      ],

      "bo": [
        "loveclab-item0chem-solder", 60, 0.5,
      ],

    },


  ],


};


Events.run(ClientLoadEvent, () => {
  exports.rc = rc;
});
