const rc = {


  // craftTime: 20s


  "base": [


  ],


  "recipe": [


    /* <---------- brick baking ----------> */


    "BRICK BAKING: clay brick", {

      "icon": "loveclab-item0buil-brick-clay",
      "category": "brick-baking",
      "tempReq": 400.0,

      "bi": [
        "loveclab-item0ore-clay", 10, 1.0,
      ],

      "bo": [
        "loveclab-item0buil-brick-clay", 5, 1.0,
      ],

      "failP": 0.2,
      "fo": [],

    },


    /* <---------- misc ----------> */


    "MISC: charcoal", {

      "icon": "loveclab-item0bio-charcoal",
      "category": "misc",
      "tempReq": 300.0,
      "tempAllowed": 750.0,

      "bi": [
        "loveclab-item0bio-log", 10, 1.0,
      ],

      "bo": [
        "loveclab-item0bio-charcoal", 10, 0.5,
      ],

      "failP": 0.2,
      "fo": [],

    },


  ],


};


Events.run(ClientLoadEvent, () => {
  exports.rc = rc;
});
