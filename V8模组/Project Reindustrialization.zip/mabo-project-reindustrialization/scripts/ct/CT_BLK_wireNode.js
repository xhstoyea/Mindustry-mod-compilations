/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/blk/BLK_wireNode");


  /* <---------- auxilliary ----------> */


  function _std(wireMat, linkMode, minRadFrac) {
    return {
      wireMat: Object.val(wireMat, "copper"), linkMode: Object.val(linkMode, "any"), minRadFrac: Object.val(minRadFrac, 0.0),
      linkFilterTup: null,
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawPlace(tx, ty, rot, valid) {
        this.super$drawPlace(tx, ty, rot, valid);
        TEMPLATE.drawPlace(this, tx, ty, rot, valid);
      },
      canPlaceOn(t, team, rot) {
        if(!this.super$canPlaceOn(t, team, rot)) return false;
        if(!TEMPLATE.canPlaceOn(this, t, team, rot)) return false;
        return true;
      },
      linkValid(b, b_t) {
        if(!this.super$linkValid(b, b_t, true)) return false;
        if(!TEMPLATE.linkValid(this, b, b_t)) return false;
        return true;
      },
      drawLaser(x1, y1, x2, y2, size1, size2) {
        TEMPLATE.drawLaser(this, x1, y1, x2, y2, size1, size2);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      ex_getMinRadFrac() {
        return TEMPLATE.ex_getMinRadFrac(this);
      },
    };
  };


  function _std_b(touchDmg, arcColor) {
    return {
      touchDmg: Object.val(touchDmg, 0.0), arcColor: Object.val(arcColor, Pal.accent),
      created() {
        this.super$created();
        TEMPLATE.created(this);
      },
      onDestroyed() {
        this.super$onDestroyed();
        TEMPLATE.onDestroyed(this);
      },
      updateTile() {
        this.super$updateTile();
        TEMPLATE.updateTile(this);
      },
      onProximityUpdate() {
        this.super$onProximityUpdate();
        TEMPLATE.onProximityUpdate(this);
      },
      draw() {
        this.super$draw();
        TEMPLATE.draw(this);
      },
      drawSelect() {
        this.super$drawSelect();
        TEMPLATE.drawSelect(this);
      },
      drawConfigure() {
        this.super$drawConfigure();
        TEMPLATE.drawConfigure(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- pow0trans ----------> */


  const pow0trans_copperWireNode = extend(PowerNode, "pow0trans-copper-wire-node", _std("copper", "cons", 0.35));
  pow0trans_copperWireNode.buildType = () => extend(PowerNode.PowerNodeBuild, pow0trans_copperWireNode, _std_b(20.0));
  exports.pow0trans_copperWireNode = pow0trans_copperWireNode;


  const pow0trans_copperWireRemoteNode = extend(PowerNode, "pow0trans-copper-wire-remote-node", _std("copper", "remote-node", 0.7));
  pow0trans_copperWireRemoteNode.buildType = () => extend(PowerNode.PowerNodeBuild, pow0trans_copperWireRemoteNode, _std_b(30.0));
  exports.pow0trans_copperWireRemoteNode = pow0trans_copperWireRemoteNode;
