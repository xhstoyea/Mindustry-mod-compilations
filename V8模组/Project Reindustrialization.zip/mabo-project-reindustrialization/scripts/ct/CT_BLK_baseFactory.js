/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/blk/BLK_baseFactory");
  const EFF = require("lovec/glb/GLB_eff");


  const FRAG_faci = require("lovec/frag/FRAG_faci");


  /* <---------- auxilliary ----------> */


  function _std(craftEff, updateEff, updateEffP) {
    return {
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawPlace(tx, ty, rot, valid) {
        this.super$drawPlace(tx, ty, rot, valid);
        TEMPLATE.drawPlace(this, tx, ty, rot, valid);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      // @SPEC
      craftEffect: Object.val(craftEff, Fx.none), updateEffect: Object.val(updateEff, Fx.none), updateEffectChance: Object.val(updateEffP, 0.02),
    };
  };


  function _std_b(craftSe) {
    return {
      craftSound: Object.val(craftSe, Sounds.none),
      created() {
        this.super$created();
        TEMPLATE.created(this);
      },
      onDestroyed() {
        this.super$onDestroyed();
        TEMPLATE.onDestroyed(this);
      },
      updateTile() {
        this.super$updateTile();
        TEMPLATE.updateTile(this);
      },
      onProximityUpdate() {
        this.super$onProximityUpdate();
        TEMPLATE.onProximityUpdate(this);
      },
      draw() {
        this.super$draw();
        TEMPLATE.draw(this);
      },
      drawSelect() {
        this.super$drawSelect();
        TEMPLATE.drawSelect(this);
      },
      craft() {
        this.super$craft();
        TEMPLATE.craft(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- fac0air ----------> */


  const fac0air_airCollector = extend(GenericCrafter, "fac0air-air-collector", {
    init() {
      this.super$init();
      TEMPLATE.init(this);
    },
    setStats() {
      this.super$setStats();
      TEMPLATE.setStats(this);
      // @SPEC
      FRAG_faci.comp_setStats_ter(this, ["sand"], "disable");
    },
    drawPlace(tx, ty, rot, valid) {
      this.super$drawPlace(tx, ty, rot, valid);
      TEMPLATE.drawPlace(this, tx, ty, rot, valid);
    },
    ex_getTags() {
      return TEMPLATE.ex_getTags(this);
    },
    // @SPEC
    craftEffect: Fx.none, updateEffect: Fx.none, updateEffectChance: 0.02,
    canPlaceOn: function(t, team, rot) {
      if(!this.super$canPlaceOn(t, team, rot)) return false;
      if(!FRAG_faci.comp_canPlaceOn_ter(this, t, team, rot, ["sand"], "disable")) return false;
      return true;
    },
  });
  fac0air_airCollector.buildType = () => extend(GenericCrafter.GenericCrafterBuild, fac0air_airCollector, {
    craftSound: Sounds.none,
    created() {
      this.super$created();
      TEMPLATE.created(this);
    },
    onDestroyed() {
      this.super$onDestroyed();
      TEMPLATE.onDestroyed(this);
    },
    updateTile() {
      this.super$updateTile();
      TEMPLATE.updateTile(this);
    },
    onProximityUpdate() {
      this.super$onProximityUpdate();
      TEMPLATE.onProximityUpdate(this);
    },
    draw() {
      this.super$draw();
      TEMPLATE.draw(this);
    },
    drawSelect() {
      this.super$drawSelect();
      TEMPLATE.drawSelect(this);
    },
    craft() {
      this.super$craft();
      TEMPLATE.craft(this);
    },
  });
  exports.fac0air_airCollector = fac0air_airCollector;


  /* <---------- fac0proc ----------> */


  const fac0proc_sawmill = extend(GenericCrafter, "fac0proc-sawmill", _std(null, EFF.sawmillCrack, 0.02));
  fac0proc_sawmill.buildType = () => extend(GenericCrafter.GenericCrafterBuild, fac0proc_sawmill, _std_b());
  exports.fac0proc_sawmill = fac0proc_sawmill;
