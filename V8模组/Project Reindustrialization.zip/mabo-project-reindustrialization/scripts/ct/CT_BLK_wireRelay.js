/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/blk/BLK_wireRelay");


  /* <---------- auxilliary ----------> */


  function _std(wireMat) {
    return {
      wireMat: Object.val(wireMat, "copper"),
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawPlace(tx, ty, rot, valid) {
        this.super$drawPlace(tx, ty, rot, valid);
        TEMPLATE.drawPlace(this, tx, ty, rot, valid);
      },
      canPlaceOn(t, team, rot) {
        if(!this.super$canPlaceOn(t, team, rot)) return false;
        if(!TEMPLATE.canPlaceOn(this, t, team, rot)) return false;
        return true;
      },
      drawLaser(x1, y1, x2, y2, size1, size2) {
        TEMPLATE.drawLaser(this, x1, y1, x2, y2, size1, size2);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
    };
  };


  function _std_b(touchDmg, arcColor) {
    return {
      touchDmg: Object.val(touchDmg, 0.0), arcColor: Object.val(arcColor, Pal.accent),
      created() {
        this.super$created();
        TEMPLATE.created(this);
      },
      onDestroyed() {
        this.super$onDestroyed();
        TEMPLATE.onDestroyed(this);
      },
      updateTile() {
        this.super$updateTile();
        TEMPLATE.updateTile(this);
      },
      onProximityUpdate() {
        this.super$onProximityUpdate();
        TEMPLATE.onProximityUpdate(this);
      },
      draw() {
        TEMPLATE.draw(this);
      },
      drawSelect() {
        this.super$drawSelect();
        TEMPLATE.drawSelect(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- pow0trans ----------> */


  const pow0trans_copperWireRelay = extend(BeamNode, "pow0trans-copper-wire-relay", _std("copper"));
  pow0trans_copperWireRelay.buildType = () => extend(BeamNode.BeamNodeBuild, pow0trans_copperWireRelay, _std_b(20.0));
  exports.pow0trans_copperWireRelay = pow0trans_copperWireRelay;
