/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/blk/BLK_groundDrill");
  const EFF = require("lovec/glb/GLB_eff");


  /* <---------- auxilliary ----------> */


  function _std(drillEff, drillEffP, drillEffRnd, updateEff, updateEffP) {
    return {
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawPlace(tx, ty, rot, valid) {
        this.super$drawPlace(tx, ty, rot, valid);
        TEMPLATE.drawPlace(this, tx, ty, rot, valid);
      },
      canMine(t) {
        if(!this.super$canMine(t)) return false;
        if(!TEMPLATE.canMine(this, t)) return false;
        return true;
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      // @SPEC
      drillEffect: Object.val(drillEff, Fx.none), drillEffectChance: Object.val(drillEffP, 1.0), drillEffectRnd: Object.val(drillEffRnd, 0.0),
      updateEffect: Object.val(updateEff, Fx.none), updateEffectChance: Object.val(updateEffP, 0.02),
    };
  };


  function _std_b(useCep, useAccel) {
    return {
      useCep: Object.val(useCep, false),
      useAccel: Object.val(useAccel, false), timeDrilledInc: 0.0,
      created() {
        this.super$created();
        TEMPLATE.created(this);
      },
      onDestroyed() {
        this.super$onDestroyed();
        TEMPLATE.onDestroyed(this);
      },
      updateTile() {
        this.super$updateTile();
        TEMPLATE.updateTile(this);
      },
      onProximityUpdate() {
        this.super$onProximityUpdate();
        TEMPLATE.onProximityUpdate(this);
      },
      draw() {
        this.super$draw();
        TEMPLATE.draw(this);
      },
      drawSelect() {
        this.super$drawSelect();
        TEMPLATE.drawSelect(this);
      },
      updateEfficiencyMultiplier() {
        this.super$updateEfficiencyMultiplier();
        TEMPLATE.updateEfficiencyMultiplier(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- min0drl ----------> */


  const min0drl_survivorDrill = extend(Drill, "min0drl-survivor-drill", _std(EFF.drillPulsePack[3], 1.0, 0.0, EFF.drillCrack, 0.01));
  min0drl_survivorDrill.buildType = () => extend(Drill.DrillBuild, min0drl_survivorDrill, _std_b(true, true));
  exports.min0drl_survivorDrill = min0drl_survivorDrill;


  const min0drl_progressClassDrill = extend(Drill, "min0drl-progress-class-drill", _std(EFF.heatSmog, 1.0, 0.0, EFF.drillCrack, 0.01));
  min0drl_progressClassDrill.buildType = () => extend(Drill.DrillBuild, min0drl_progressClassDrill, _std_b(false, true));
  exports.min0drl_progressClassDrill = min0drl_progressClassDrill;
