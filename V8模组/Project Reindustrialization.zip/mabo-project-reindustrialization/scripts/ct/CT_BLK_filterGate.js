/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/blk/BLK_filterGate");


  const MDL_content = require("lovec/mdl/MDL_content");


  /* <---------- auxilliary ----------> */


  function _std() {
    return {
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawPlace(tx, ty, rot, valid) {
        this.super$drawPlace(tx, ty, rot, valid);
        TEMPLATE.drawPlace(this, tx, ty, rot, valid);
      },
      icons() {
        return TEMPLATE.icons(this);
      },
      setBars() {
        this.super$setBars();
        TEMPLATE.setBars(this);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
    };
  };


  function _std_b(filterScr, noSelect) {
    return {
      filterScr: Object.val(filterScr, function(b, b_f, itm) {return true}),
      noSelect: Object.val(noSelect, false),
      invReg: null, isInv: false,
      created() {
        this.super$created();
        TEMPLATE.created(this);
      },
      onDestroyed() {
        this.super$onDestroyed();
        TEMPLATE.onDestroyed(this);
      },
      updateTile() {
        this.super$updateTile();
        TEMPLATE.updateTile(this);
      },
      onProximityUpdate() {
        this.super$onProximityUpdate();
        TEMPLATE.onProximityUpdate(this);
      },
      draw() {
        this.super$draw();
        TEMPLATE.draw(this);
      },
      drawSelect() {
        this.super$drawSelect();
        TEMPLATE.drawSelect(this);
      },
      acceptItem(b_f, itm) {
        if(!this.super$acceptItem(b_f, itm)) return false;
        if(!TEMPLATE.acceptItem(this, b_f, itm)) return false;
        return true;
      },
      getTileTarget(itm, b_f, isFlip) {
        return TEMPLATE.getTileTarget(this, itm, b_f, isFlip);
      },
      buildConfiguration(tb) {
        TEMPLATE.buildConfiguration(this, tb);
      },
      config() {
        return TEMPLATE.config(this);
      },
      write(wr) {
        this.super$write(wr);
        TEMPLATE.write(this, wr);
      },
      read(rd, revi) {
        this.super$read(rd, revi);
        TEMPLATE.read(this, rd, revi);
      },
      ex_accIsInv(param) {
        return TEMPLATE.ex_accIsInv(this, param);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- dis0aux ----------> */


  const dis0aux_filterGate = extend(Sorter, "dis0aux-filter-gate", _std());
  dis0aux_filterGate.buildType = () => extend(Sorter.SorterBuild, dis0aux_filterGate, _std_b(function(b, b_f, itm) {
    
    return itm === b.sortItem;

  }));
  exports.dis0aux_filterGate = dis0aux_filterGate;
