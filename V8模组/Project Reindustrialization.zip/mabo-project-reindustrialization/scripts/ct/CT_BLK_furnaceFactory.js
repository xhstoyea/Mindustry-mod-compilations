/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/blk/BLK_furnaceFactory");
  const EFF = require("lovec/glb/GLB_eff");


  const MDL_recipe = require("lovec/mdl/MDL_recipe");


  /* <---------- auxiliary ----------> */


  function _std(nmBlk, fuelType, blockedFuels, craftEff, updateEff, updateEffP) {
    return {
      rcMdl: MDL_recipe._rcMdl("projreind", nmBlk),
      fuelType: Object.val(fuelType, "item"), blockedFuels: Object.val(blockedFuels, []),
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawPlace(tx, ty, rot, valid) {
        this.super$drawPlace(tx, ty, rot, valid);
        TEMPLATE.drawPlace(this, tx, ty, rot, valid);
      },
      setBars() {
        this.super$setBars();
        TEMPLATE.setBars(this);
      },
      consumesItem(itm) {
        return TEMPLATE.consumesItem(this, itm);
      },
      consumesLiquid(liq) {
        return TEMPLATE.consumesLiquid(this, liq);
      },
      outputsItems() {
        return TEMPLATE.outputsItems(this);
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      ex_getRcMdl() {
        return TEMPLATE.ex_getRcMdl(this);
      },
      ex_getFuelType() {
        return TEMPLATE.ex_getFuelType(this);
      },
      ex_getBlockedFuels() {
        return TEMPLATE.ex_getBlockedFuels(this);
      },
      // @SPEC
      craftEffect: Object.val(craftEff, Fx.none), updateEffect: Object.val(updateEff, Fx.none), updateEffectChance: Object.val(updateEffP, 0.02),
    };
  };


  function _std_b(craftSe, useCep, noDump, heatIncRate) {
    return {
      craftSound: Object.val(craftSe, Sounds.none),
      useCep: Object.val(useCep, false), noDump: Object.val(noDump, false), isTall: false, heatIncRate: Object.val(heatIncRate, 0.0001),
      rcHeader: "", validTup: null, timeScl: 1.0, ignoreItemFullness: false,
      ci: [], bi: [], aux: [], reqOpt: false, opt: [],
      co: [], bo: [], failP: 0.0, fo: [],
      scrTup: null, tmpEffc: 0.0, progInc: 0.0, progIncLiq: 0.0, canAdd: false,
      hasRun: false, isStopped: false, dumpTup: null,
      heatReg: null, tempReq: 0.0, tempAllowed: Infinity, tempCur: -1.0, fuelPonCur: 0.0, fuelConsMtp: 1.0, fuelLvlMtp: 1.0, fuelTup: null,
      created() {
        this.super$created();
        TEMPLATE.created(this);
      },
      onDestroyed() {
        this.super$onDestroyed();
        TEMPLATE.onDestroyed(this);
      },
      updateTile() {
        TEMPLATE.updateTile(this);
      },
      onProximityUpdate() {
        this.super$onProximityUpdate();
        TEMPLATE.onProximityUpdate(this);
      },
      draw() {
        this.super$draw();
        TEMPLATE.draw(this);
      },
      drawSelect() {
        this.super$drawSelect();
        TEMPLATE.drawSelect(this);
      },
      displayConsumption(tb) {
        TEMPLATE.displayConsumption(this, tb);
      },
      displayBars(tb) {
        this.super$displayBars(tb);
        TEMPLATE.displayBars(this, tb);
      },
      acceptItem(b_f, itm) {
        return TEMPLATE.acceptItem(this, b_f, itm);
      },
      acceptLiquid(b_f, liq) {
        return TEMPLATE.acceptLiquid(this, b_f, liq);
      },
      shouldConsume() {
        return TEMPLATE.shouldConsume(this);
      },
      warmupTarget() {
        return TEMPLATE.warmupTarget(this);
      },
      craft() {
        this.super$craft();
        TEMPLATE.craft(this);
      },
      buildConfiguration(tb) {
        TEMPLATE.buildConfiguration(this, tb);
      },
      config() {
        return TEMPLATE.config(this);
      },
      drawStatus() {
        TEMPLATE.drawStatus(this);
      },
      write(wr) {
        this.super$write(wr);
        TEMPLATE.write(this, wr);
      },
      read(rd, revi) {
        this.super$read(rd, revi);
        TEMPLATE.read(this, rd, revi);
      },
      ex_accRcHeader(param) {
        return TEMPLATE.ex_accRcHeader(this, param);
      },
      ex_updateParams(rcMdl, rcHeader, forceLoad) {
        TEMPLATE.ex_updateParams(this, rcMdl, rcHeader, forceLoad);
      },
      ex_initParams() {
        TEMPLATE.ex_initParams(this);
      },
      ex_getEffc() {
        return TEMPLATE.ex_getEffc(this);
      },
      ex_getTimerEffc() {
        return TEMPLATE.ex_getTimerEffc(this);
      },
      ex_getFailP() {
        return TEMPLATE.ex_getFailP(this);
      },
      ex_getHeat() {
        return TEMPLATE.ex_getHeat(this);
      },
      ex_getHeatFrac() {
        return TEMPLATE.ex_getHeatFrac(this);
      },
    };
  };


  const bioFuelItms = [
    "loveclab-item0bio-log",
    "loveclab-item0bio-timber",
    "loveclab-item0bio-sawdust",
  ];


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- fac0furn ----------> */


  const fac0furn_kiln = extend(GenericCrafter, "fac0furn-kiln", _std("fac0furn-kiln", "item", [], EFF.furnaceSmog, EFF.furnaceCrack, 0.01));
  fac0furn_kiln.buildType = () => extend(GenericCrafter.GenericCrafterBuild, fac0furn_kiln, _std_b());
  exports.fac0furn_kiln = fac0furn_kiln;


  const fac0furn_primitiveSmelter = extend(GenericCrafter, "fac0furn-primitive-smelter", _std("fac0furn-primitive-smelter", "item", [], EFF.furnaceSmog, EFF.furnaceCrack, 0.01));
  fac0furn_primitiveSmelter.buildType = () => extend(GenericCrafter.GenericCrafterBuild, fac0furn_primitiveSmelter, _std_b(null, false, true));
  exports.fac0furn_primitiveSmelter = fac0furn_primitiveSmelter;


  const fac0furn_bloomery = extend(GenericCrafter, "fac0furn-bloomery", _std("fac0furn-bloomery", "item", bioFuelItms, EFF.furnaceSmog, EFF.furnaceCrack, 0.01));
  fac0furn_bloomery.buildType = () => extend(GenericCrafter.GenericCrafterBuild, fac0furn_bloomery, _std_b());
  exports.fac0furn_bloomery = fac0furn_bloomery;


  const fac0furn_primitiveCrucible = extend(GenericCrafter, "fac0furn-primitive-crucible", _std("fac0furn-primitive-crucible", "item", bioFuelItms, EFF.furnaceSmog, EFF.furnaceCrack, 0.01));
  fac0furn_primitiveCrucible.buildType = () => extend(GenericCrafter.GenericCrafterBuild, fac0furn_primitiveCrucible, _std_b(null, false, false, 0.0002));
  exports.fac0furn_primitiveCrucible = fac0furn_primitiveCrucible;
