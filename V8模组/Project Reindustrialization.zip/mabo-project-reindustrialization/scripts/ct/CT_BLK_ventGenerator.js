/*
  ========================================
  Section: Definition
  ========================================
*/


  /* <---------- import ----------> */


  const TEMPLATE = require("lovec/blk/BLK_ventGenerator");
  const EFF = require("lovec/glb/GLB_eff");


  /* <---------- auxilliary ----------> */


  function _std(shouldGenParam, genEff, genEffP, exploEff) {
    return {
      shouldGenParam: Object.val(shouldGenParam, false),
      init() {
        this.super$init();
        TEMPLATE.init(this);
      },
      setStats() {
        this.super$setStats();
        TEMPLATE.setStats(this);
      },
      drawPlace(tx, ty, rot, valid) {
        this.super$drawPlace(tx, ty, rot, valid);
        TEMPLATE.drawPlace(this, tx, ty, rot, valid);
      },
      canPlaceOn(t, team, rot) {
        if(!this.super$canPlaceOn(t, team, rot)) return false;
        if(!TEMPLATE.canPlaceOn(this, t, team, rot)) return false;
        return true;
      },
      ex_getTags() {
        return TEMPLATE.ex_getTags(this);
      },
      // @SPEC
      generateEffect: Object.val(genEff, Fx.none), effectChance: Object.val(genEffP, 0.02),
      explodeEffect: Object.val(exploEff, Fx.none),
    };
  };


  function _std_b() {
    return {
      created() {
        this.super$created();
        TEMPLATE.created(this);
      },
      onDestroyed() {
        this.super$onDestroyed();
        TEMPLATE.onDestroyed(this);
      },
      updateTile() {
        this.super$updateTile();
        TEMPLATE.updateTile(this);
      },
      onProximityUpdate() {
        this.super$onProximityUpdate();
        TEMPLATE.onProximityUpdate(this);
      },
      draw() {
        this.super$draw();
        TEMPLATE.draw(this);
      },
      drawSelect() {
        this.super$drawSelect();
        TEMPLATE.drawSelect(this);
      },
      warmup() {
        return TEMPLATE.warmup(this);
      },
      totalProgress() {
        return TEMPLATE.totalProgress(this);
      },
      createExplosion() {
        this.super$createExplosion();
        TEMPLATE.createExplosion(this);
      },
    };
  };


/*
  ========================================
  Section: Application
  ========================================
*/


  /* <---------- pow0gen ----------> */


  const pow0gen_ventGenerator = extend(ThermalGenerator, "pow0gen-vent-generator", _std(true, EFF.powerParticle, 0.02, EFF.explosion));
  pow0gen_ventGenerator.buildType = () => extend(ThermalGenerator.ThermalGeneratorBuild, pow0gen_ventGenerator, _std_b());
  exports.pow0gen_ventGenerator = pow0gen_ventGenerator;
