const db = {


  "param": {


    "amount": {


      "base": [

        "projreind-dis0loot-item-hopper", 15,

      ],


    },


    "range": {


      "base": [],


      "impact": [],


      "ep": [],


    },


    "speed": {


      "base": [],


    },


    "multiplier": {


      "fuelCons": [

        "projreind-fac0furn-primitive-smelter", 0.1,
        "projreind-fac0furn-bloomery", 0.75,

      ],


      "fuelLvl": [

        "projreind-fac0furn-bloomery", 1.35,
        "projreind-fac0furn-primitive-crucible", 1.35,

      ],


    },


    "time": {


      "base": [

        "projreind-dis0loot-item-hopper", 5.0 * 60.0,

        "projreind-fac0mill-jaw-crusher", 5.0 * 60.0 * 60.0,

      ],


    },


    "heal": {


      "amount": [

        "projreind-eff0proj-bay-class-repairer", 20.0,

      ],


      "percent": [],


    },


    "pipeDiam": [

      "projreind-bliq0cond-wooden-liquid-pipe", 60.0,
      "projreind-bliq0cond-bronze-liquid-pipe", 90.0,
      "projreind-bliq0cond-steel-liquid-pipe", 100.0,

      "projreind-bliq0cond-wooden-gas-pipe", 15.0,
      "projreind-bliq0cond-bronze-gas-pipe", 20.0,
      "projreind-bliq0cond-steel-gas-pipe", 30.0,

    ],


    "presRes": [

      "projreind-bliq0cond-wooden-liquid-pipe", 1.0,
      "projreind-bliq0cond-bronze-liquid-pipe", 7.0,
      "projreind-bliq0cond-steel-liquid-pipe", 12.0,

      "projreind-bliq0cond-wooden-gas-pipe", 1.0,
      "projreind-bliq0cond-bronze-gas-pipe", 7.0,
      "projreind-bliq0cond-steel-gas-pipe", 12.0,

      "projreind-bliq0brd-bronze-fluid-pipe-bridge", 7.0,

    ],


    "vacRes": [

      "projreind-bliq0cond-wooden-liquid-pipe", 0.0,
      "projreind-bliq0cond-bronze-liquid-pipe", -3.0,
      "projreind-bliq0cond-steel-liquid-pipe", -7.0,

      "projreind-bliq0cond-wooden-gas-pipe", 0.0,
      "projreind-bliq0cond-bronze-gas-pipe", -3.0,
      "projreind-bliq0cond-steel-gas-pipe", -7.0,

      "projreind-bliq0brd-bronze-fluid-pipe-bridge", -3.0,

    ],


    "corRes": [],


    "pol": [

      "projreind-min0drl-survivor-drill", 6.0,
      "projreind-min0drl-progress-class-drill", 2.0,

      "projreind-fac0air-air-collector", -4.0,
      "projreind-fac0air-air-filter", -30.0,

      "projreind-fac0furn-kiln", 6.0,
      "projreind-fac0furn-primitive-smelter", 10.0,
      "projreind-fac0furn-bloomery", 10.0,
      "projreind-fac0furn-primitive-crucible", 4.0,

      "projreind-fac0mill-jaw-crusher", 3.0,

    ],


    "polTol": [],


    "cep": {


      "prov": [],


      "use": [

        "projreind-min0drl-survivor-drill", 1.0,

        "projreind-fac0proc-core-crafter", 2.5,

      ],


    },


  },


  "map": {


    "faction": [

      "projreind-min0drl-survivor-drill", "emerald-tide",
      "projreind-min0drl-progress-class-drill", "emerald-tide",

      "projreind-eff0proj-local-repairer", "outpost-military",
      "projreind-eff0proj-bay-class-repairer", "outpost-military",

    ],


    "facFami": [

      "projreind-fac0furn-primitive-crucible", "alloy-furnace",

      "projreind-fac0furn-kiln", "brick-kiln",

      "projreind-fac0furn-kiln", "carbonization-furnace",

      "projreind-fac0mill-jaw-crusher", "rock-crusher",

      "projreind-fac0furn-primitive-smelter", "smelter",
      "projreind-fac0furn-bloomery", "smelter",

    ],


  },


  "group": {


    "material": {


      "wood": [

        "projreind-bliq0cond-wooden-liquid-pipe",

        "projreind-bliq0cond-wooden-gas-pipe",

      ],


      "copper": [

        "projreind-bliq0brd-bronze-fluid-pipe-bridge",

      ],


      "lead": [],


      "iron": [],


      "steel": [

        "projreind-bliq0pump-piston-liquid-pump",

      ],


      "galvanized": [],


      "stainless": [],


      "glass": [],


      "cement": [],


      "rubber": [],


    },


    "exposed": [

      "projreind-dis0conv-primitive-conveyor",

      "projreind-eff0stor-crate",

    ],


    "cloggable": [

      "projreind-bliq0cond-wooden-liquid-pipe",

    ],


    "shortCircuit": [

      "projreind-pow0trans-copper-cable",
      "projreind-pow0trans-copper-wire-relay",
      "projreind-pow0trans-copper-wire-node",

    ],


    "magnetic": [],


    "showReload": [],


  },


};
exports.db = db;
