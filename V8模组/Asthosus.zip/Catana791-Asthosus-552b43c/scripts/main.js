const asthosus = Vars.mods.locateMod("asthosus").meta;

asthosus.displayName = Core.bundle.get("mod.asthosus.name");
asthosus.author = Core.bundle.get("mod.asthosus.author");
asthosus.description = Core.bundle.get("mod.asthosus.description");
asthosus.subtitle = Core.bundle.get("mod.asthosus.subtitle");
