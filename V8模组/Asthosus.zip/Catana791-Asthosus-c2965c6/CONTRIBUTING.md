# Contributing

<div align = center>
  
## In General
<br>
<br>

### If you wish to contribute to this mod, you can do one of the following:
<br><br>

- Create a pull request with your content already finished. <br> If it matches Asthosus' theme and is correct code-wise, I may merge it.
<br> <br>
- Create an issue telling me what you want changed or added.
<br> <br>
## The Preferred Way
- Join the Asthosus Discord server. <br> We have a forum present that can be used for suggestions and creations
