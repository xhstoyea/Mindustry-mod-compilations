package mindustry.mods;

import arc.Events;
import arc.Log;
import arc.math.Mathf;
import mindustry.Vars;
import mindustry.game.Difficulty;
import mindustry.mod.Mod;
import mindustry.type.UnitType;
import mindustry.ai.AiController;
import mindustry.entities.units.Unit;
import mindustry.game.EventType;
import mindustry.world.Block;
import mindustry.world.blocks.storage.CoreBlock;

public class HellModeAI extends Mod {
    
    private static final String PRESET_UNIT_NAME = "gamma";
    private static final String PRESET_BLOCK_NAME = "core-shard";
    private static final int SPAWN_UNIT_COUNT = 3;
    private static final float BASE_SPAWN_X = 0.2f;
    private static final float BASE_SPAWN_Y = 0.2f;
    private static final float SPAWN_RANGE = 0.6f;

    @Override
    public void init() {
        Log.info("【HellMode-AI】模组初始化开始...");
        
        // 初始化顺序优化：先设置难度再增强属性
        setHighestDifficulty();
        enhanceAIBasicStats();
        
        // 注册事件监听（增加空指针防御）
        if (Vars.state != null && Vars.state.rules != null) {
            Events.on(EventType.GameStartEvent.class, this::onGameStart);
        } else {
            Log.err("【错误】游戏规则未初始化，模组功能受限！");
        }
        
        Log.info("【HellMode-AI】模组初始化完成！");
    }

    private void setHighestDifficulty() {
        if (Vars.state != null && Vars.state.rules != null) {
            Vars.state.rules.difficulty = Difficulty.insane;
            Log.info("【HellMode-AI】游戏难度: 灾难级");
        } else {
            Log.err("【错误】无法设置难度：游戏规则未加载！");
        }
    }

    private void enhanceAIBasicStats() {
        if (Vars.state != null && Vars.state.rules != null) {
            Vars.state.rules.enemyHealthMultiplier = 2.5f;
            Vars.state.rules.enemyDamageMultiplier = 2.0f;
            Vars.state.rules.enemyBuildSpeedMultiplier = 1.5f;
            Vars.state.rules.enemyMineSpeedMultiplier = 1.3f;
            
            Log.info("【HellMode-AI】AI属性增强完成:");
            Log.info("【HellMode-AI】- 血量×2.5 | 伤害×2.0 | 建造×1.5 | 采矿×1.3");
        } else {
            Log.err("【错误】无法增强属性：游戏规则未加载！");
        }
    }

    private void onGameStart(EventType.GameStartEvent event) {
        // 增加游戏状态检查
        if (Vars.state.isGamePaused() || Vars.state.isMenu()) {
            Log.warn("【跳过】游戏未运行，取消AI生成任务");
            return;
        }
        
        spawnGammaUnits();
        assignBuildTasksToAI();
    }

    private void spawnGammaUnits() {
        // 增强型单位生成逻辑
        if (!ensureUnitTypeExists(PRESET_UNIT_NAME, "gamma")) return;
        
        int aiTeam = Vars.state.rules.waveTeam;
        float worldWidth = Vars.world.width();
        float worldHeight = Vars.world.height();

        // 优化生成区域计算（防止负数）
        float safeMinX = Math.max(0, worldWidth * BASE_SPAWN_X);
        float safeMaxX = Math.min(worldWidth, worldWidth * (BASE_SPAWN_X + SPAWN_RANGE));
        float safeMinY = Math.max(0, worldHeight * BASE_SPAWN_Y);
        float safeMaxY = Math.min(worldHeight, worldHeight * (BASE_SPAWN_Y + SPAWN_RANGE));

        for (int i = 0; i < SPAWN_UNIT_COUNT; i++) {
            // 边界保护：防止生成在地图外
            float spawnX = Mathf.clamp(Mathf.random(safeMinX, safeMaxX), 0, worldWidth);
            float spawnY = Mathf.clamp(Mathf.random(safeMinY, safeMaxY), 0, worldHeight);

            Unit gammaUnit = safeSpawn(gammaUnitType, aiTeam, spawnX, spawnY);
            if (gammaUnit != null) {
                Log.info("【成功】生成伽马单位: " + gammaUnit + " 位置: (" + (int)spawnX + "," + (int)spawnY + ")");
            }
        }
    }

    private void assignBuildTasksToAI() {
        // 增强型建造任务分配
        if (!ensureBlockExists(PRESET_BLOCK_NAME, "core-shard")) return;
        
        Seq<Unit> validUnits = Vars.unitGroup.select(u -> 
            u.team == Vars.state.rules.waveTeam && 
            u.isAIControlled() && 
            u.canBuild()
        );

        if (validUnits.isEmpty()) {
            Log.warn("【跳过】未找到可建造的AI单位");
            return;
        }

        for (Unit unit : validUnits) {
            // 智能选址：优先选择空闲区域
            int x = Mathf.random(100, Vars.world.width() - 100);
            int y = Mathf.random(100, Vars.world.height() - 100);
            
            if (isSafeBuildLocation(x, y, coreShardBlock)) {
                unit.build(coreShardBlock, x, y);
                Log.info("【任务】AI单位 " + unit + " 开始建造核心碎片 @ (" + x + "," + y + ")");
            } else {
                Log.warn("【跳过】位置 (" + x + "," + y + ") 不安全");
            }
        }
    }

    // 辅助方法：安全生成单位
    private Unit safeSpawn(UnitType type, int team, float x, float y) {
        try {
            return type.spawn(team, x, y);
        } catch (Exception e) {
            Log.err("【生成失败】" + type + " @ (" + x + "," + y + ")", e);
            return null;
        }
    }

    // 辅助方法：检查建筑合法性
    private boolean isSafeBuildLocation(int x, int y, Block block) {
        return block != null && block.canPlace(x, y) && Vars.world.getBlock(x, y).isAir();
    }

    // 辅助方法：检查单位类型存在性
    private boolean ensureUnitTypeExists(String name, String friendlyName) {
        UnitType type = Vars.content.unit(name);
        if (type == null) {
            Log.err("【错误】缺失关键单位：" + friendlyName + " (" + name + ")");
            return false;
        }
        return true;
    }

    // 辅助方法：检查建筑类型存在性
    private boolean ensureBlockExists(String name, String friendlyName) {
        Block block = Vars.content.block(name);
        if (block == null) {
            Log.err("【错误】缺失关键建筑：" + friendlyName + " (" + name + ")");
            return false;
        }
        return true;
    }
}