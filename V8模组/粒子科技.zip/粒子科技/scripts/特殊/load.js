require("特殊/菜单")

require("特殊/缩放强化")

//require("特殊/高温影响")

require("特殊/极危脉冲")