
//格雷工业的，只取了要用的一部分

//判定器
//----s----
function chance(p){
    return Math.floor(Math.random()*1000)<=p*1000
}
exports.chance=(p)=>{
    return chance(p)
}

var action={}
action.explode=function(puddle){
    var xx=puddle.tile.x*6 //坐标赋值，这里是说范围
    var yy=puddle.tile.y*6 
    //Fires.create(puddle.tile)
    Damage.damage(null,xx,yy,10,235,true,true) //不知道, x, y, r, damage, 不知道, 不知道

    for (var i=0;i<8;i++){
        Fx.reactorsmoke.at(xx,yy) //反应堆烟雾粒子显示
        Effect.floorDust(xx,yy,3) //地板灰效果
    }
    puddle.remove()
}
Events.run(Trigger.update, () => {
    Groups.puddle.each(puddle => {
            if (puddle.liquid.name === "粒子科技-核爆"){
                if (chance(0.95)){
                    action.explode(puddle)
                }
            }
        }
    ), 
    Groups.puddle.each(puddle => {
            if (puddle.liquid.name === "粒子科技-反聚能"){
                if (chance(0.7)){
                    action.explode(puddle)
                }
            }
        }
    )
})