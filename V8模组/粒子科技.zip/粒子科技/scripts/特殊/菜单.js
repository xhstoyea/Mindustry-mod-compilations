var checkread=false
Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("粒子科技");
    dialog.buttons.defaults().size(400, 64);
       /* dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128)*/
    dialog.buttons.button("@close", run(() => {dialog.hide()})).size(400, 128)/*.disabled(b=>!checkread).update(b => {
        if (!checkread){
            b.setText("请仔细阅读本次更新公告并确认")
        }
        if (checkread){
            b.setText("关闭")
        }
            })*/

    dialog.cont.pane((() => {

        var table = new Table();
        table.add("粒子科技");
        table.row();
        table.add("v1.6.6");
        table.row();
        table.add('模组Q群:850080316');
        table.row()
        table.add("B站:一根来自MC的灰柴")
        table.row();
        table.add(" ");
        table.row();
    table.button('更新', Icon.infoCircle, run(() => {
    var dialog = new BaseDialog("更新");
    dialog.cont.pane(t => {
        t.add("更新");
        t.row();
        t.button("本次更新", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("本次更新");
            dialog.cont.pane(t => {
                t.add("v1.6.6更新:\n\n更新、优化了部分贴图，\n将极危脉冲产生条件中的 高热熔融物 去除。\n增加能崩手机端游戏的 清空 ，\n增加地图 28号沉降区，\n增加凝固的熔融、灼热岩石，\n黑曜石…[思考]")
            })
            dialog.buttons.button("@close", ()=>{
        dialog.hide()
            }).size(400, 128)
            dialog.show();
        })).size(400, 128);
        t.row()
        t.button("历次更新", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("历次更新");
            dialog.cont.pane(t => {
                t.add("").left()
                t.row()
    			t.check("确认收到",checkread, m => {
			    checkread=m
			}).left()
			    t.row()
                t.add("v1.6.5更新:\n\n将 爆炸物发电机 与 激活态暗核聚变反应堆核心 设置为仅沙盒可用\n修复了菜单\n添加多方块结构 暗核聚变反应堆 ，\n但是还没有做具体功能，\n在蓝图库中有相应建造蓝图。\n正在检修程序路径为`粒子科技v1.6.5/scripts/数据`中的错误。\n删除了风力发电机，因为用石头做成一个坚硬的风力发电机并不合理，\n因为我想搞一个的以石头材质的发电机:手摇发电机\n(其实我本来是想说的是'让两块石头互相碰撞产生电火花，以此来收集电。'，\n但是发现那样做的话电的产生过少了，\n更不想再做一个额外的脚本令它连发电都依赖于概率！)")
			    t.row()
                t.add(" ")
			    t.row()
                t.add("v1.6更新:\n\n修改了星球区块大小，区块网格回归\n新增初级风力发电站\n额外搞一个爆炸物发电站\n修改了天气 辐射尘 的粒子显示大小\n给核心机 烬尘 配备了武器\n新单位 微风 \n(但是因为模板是核心机的，\n所以该单位被制造出后将会向某角落走\n贴图还未画出)\n正在试图使粒子在普通容器中消失，在特定的容器中不消失\n替换了三个多合成工厂的依赖库\n修改了研究需求物品量(改少了)")
                t.row()
                t.add(" ")
                t.row()
                t.add("v1.5更新:\n\n新增 轧线机 ，以及更多的线材\n新增 放射性废品 与 废品 。\n新增 玻璃处理厂 ，但是还没有配方\n优化了部分流程\n修改了部分物品的cost(利用这个物品建造块的时间)值\n缩放强化因未知原因无法运行")
                t.row()
                t.add(" ")
                t.row()
                t.add("v1.4更新:\n\n'小男孩'，高温与耐温性，新-核爆声音\n修复多配方方块\n更新粒子发生器，引爆器远程控制电路\n更新石英岩，石英砂，石英\n为电弧高炉(原高级熔炉)添加硅的产出")
                t.row()
                t.add(" ")
                t.row()
                t.add("v1.3更新:\n\n将回旋加速器成功转为能炸还能生产的块(借鉴格雷工业)\n液体:反聚能(回旋输出)\n物品:砖头，铁，锡等物品\n生产:低级熔炉多配方(正在修)\n运输:石传送带，石装卸器，石路由器(管式)\n钻头:铁制钻机\n脚本更多了\n星球网格不知道为什么没了")
                t.row()
                t.add(" ")
                t.row()
                t.add("v1.2更新:\n\n物品:芯片，显示单元\n钻机:石凿，离心机\n更新了星球'帕蒂克'，\n内含战役地图'辐寂站'！\n关注B站'一根来自MC的灰柴哦！\n(虽然现在不发关于这个的视频，等V2.0吧!)")
                t.row()
                t.add(" ")
                t.row()
                t.add("v1.1更新:\n\n物品:玻璃，石头，黏土，芯片，显示单元。\n生产:低级熔炉，高级熔炉，回旋加速器(半)\n钻头:光能采矿机。\n具体增加更多前期用的产线。\n增加scripts文件夹。\n增加了一个钻头彩蛋:光能采矿机。\n虽然说20多秒才有一个矿，但是它毕竟什么都能挖awa~")
                t.row()
                t.add(" ")
                t.row()
                t.add("v1.0更新:\n\n模组基础架构，封面图\n物品:能量团，反物质，暗物质(贴图)")
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128);;
            dialog.show();
        })).size(400, 128);
    });
    dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128);;
    dialog.show();
})).size(400, 64);

    table.row();
    
    table.button('简介', Icon.infoCircle, run(() => {
    var dialog = new BaseDialog("简介");
    dialog.cont.pane(t => {
        t.add("粒子的运动，辐射的倍增，危险的边际。")
    });
    dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128)
    dialog.show();
})).size(400, 64);
        table.row();
        
        dialog.button("加入粒子科技群", run(() => {
        Core.app.openURI("https://qun.qq.com/universal-share/share?ac=1&authKey=KaUNZ4upaX8VZIL664vg5O23EeajpIJ7J8QUsNbZbIyFl9YjvGgey6ZLn9iJ7P3D&busi_data=eyJncm91cENvZGUiOiI4NTAwODAzMTYiLCJ0b2tlbiI6IjBkWWhGdUFuak02Q04wUWJrNWFSS2FJblpZQm03ZDBSTW5meTlYaHJZZjZTYVNGN2p0Y2ZpSmFLYUJNOXdOYnIiLCJ1aW4iOiIxNjkyNzU2NjcyIn0%3D&data=Ssn0ioS__fUKR-7LWfg-hy7w7UXi4ZPe5MS3a1CdllKOFvFYGqBLpS96jzlIfIE-rX5LqNJ4WrPNkxrlbPh5IA&svctype=4&tempid=h5_group_info");
        })).size(100, 100);
        
        table.row();
        return table;
    })()).grow().center().maxWidth(620);
    dialog.show();
    
}));
//代码来源于铧金工业！