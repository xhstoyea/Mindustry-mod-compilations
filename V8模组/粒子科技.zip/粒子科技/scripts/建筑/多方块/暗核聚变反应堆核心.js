//引用于格雷工业，给原作者写的做了一些整理
//至于为什么不改变量名…来，你行你改
const locations=[-3,3,-2,3,-1,3,0,3,1,3,2,3,3,3,-3,2,3,2,-3,1,3,1,-3,0,3,0,-3,-1,3,-1,-3,-2,3,-2,-3,-3,-2,-3,-1,-3,0,-3,1,-3,2,-3,3,-3]//位置(以核心为原点展开平面直角坐标系)(x,y)
const list=[6,1,1,3,1,1,6,1,1,1,1,5,4,1,1,1,1,6,1,1,2,1,1,6]//检测(写b值，代表下面定义的方块，对应上列方位)(x,y)-单块数据赋值
function bbbb(a){
    var b
    a=a.name
if (a=="粒子科技-铁墙"){b=1}//单块数据赋值，需要在前面写模组内部名称 + “ - ”
if (a=="粒子科技-DFC稳定器"){b=2}
if (a=="粒子科技-DFC燃料喷射器"){b=3}
if (a=="粒子科技-DFC能量接收器"){b=4}
if (a=="粒子科技-DFC能量发射器"){b=5}
if (a=="粒子科技-超导电塔"){b=6} //大概不能用原版块
    return b
}
function getbyname(name){
        var k=Vars.content.getByName(ContentType.block,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.item,name)
        if (k!=null){
            return k
        }
        k=Vars.content.getByName(ContentType.liquid,name)
        return k
}
//~~~~~~~~~~~~~~
var auto = false
const 暗核聚变反应堆核心 = extend(GenericCrafter, '暗核聚变反应堆核心', {}); //定义type(不要给它的json文件加上type，会显示冲突，我试过，真的，改了挺久的)
暗核聚变反应堆核心.configurable = true; //设置为可配置
暗核聚变反应堆核心.buildType = prov(() => { //设置建筑类型(内部写脚本)
    var other
    var ii=0
    var d=1//这次加上了"=1"
    var bb
    var cc=0//给cc与e赋了初始值
    var e=0
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
    	buildConfiguration(table){
            table.button("操作", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("暗核聚变反应堆核心");
            dialog.cont.pane(table => {
                table.add("多方块结构:暗核聚变反应堆")
                table.row()
                table.add("来源于Minecraft的一个模组:HBM核科技(又称NTM)")
                table.row()
                table.add("通过燃料喷射器为核心注入燃料，致使其激活，为稳定器添加稳定透镜以提供核心能量平衡的条件。")
                table.row()
                table.add("将能量发射器与能量接收器相对而放，接上冷凝胶，给能量发射器接电便可开机。")
                table.row()
                table.add("在mdt中，这种多方块设计并不能完全应用，就像是贴核心放置钨箱快速冶炼的操作。")
                table.row()
                table.add("很喜闻乐见的是它的发电量几乎是无与伦比的，当然，这排除我们以后的科技。")
                table.row()
                //table.add("cc="+cc)
                table.row()
                //其实我可以加"\n"，但是加不加都一样，而且这是我闲得
			    table.button("教程", Icon.book, run(() => {
            var dialog = new BaseDialog("教程");
            dialog.cont.pane(table => {
                table.add("搭建如图所示");
				table.row()
				table.image(Core.atlas.find("粒子科技-DFC搭建")).left().size(256, 256).pad(3).row();
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128);
            dialog.show()})).size(140, 70);
			    table.row()
			    table.add(" ")
			    table.row()
                if (cc==0){table.add("[yellow]结构不完整!!!")}
                else{table.add("[blue]结构就绪");
                table.row();
                table.add(" ");
                table.row();
                table.button("建造", Icon.infoCircle, run(() => {dialog.hide();e=1})).size(140, 70);
                }
                table.row()
                table.add(" ")
                table.row()
                if (auto){table.button("切换至手动建造", Icon.infoCircle, run(() => {auto=false;e=0})).size(140, 70)}
                else{table.button("请在我下次结构就绪时自动完成建造", Icon.infoCircle, run(() => {auto=true})).size(300, 70)}
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 128);
            dialog.show();
            })).size(100, 50);
    	},
        updateTile(){
            
            // 在检查逻辑后添加打印：(AⅠ的)
            /*if (bb != list[ii]) {
            d = 0;
            table.add("[错误] 位置索引 ii=" + ii + " 不匹配！预期方块类型: " + list[ii] + "，实际方块类型: " + bb);
            }*/
            
            if (auto){e=1}
		    this.super$updateTile()
            other = Vars.world.build(this.tileX()+locations[2*ii], this.tileY()+locations[(2*ii)+1])
            if (cc==1 && e==1){
                Vars.world.tile(this.tileX(), this.tileY()).setBlock(getbyname("粒子科技-暗核聚变反应堆"),this.team); //设置块名称
                Sounds.corexplode.play();
                //Fx.chainLightning.at(xx,yy)，用了会闪退
                log("成功地建造了一个多方块结构'DFC'！")
                //Vars.world.tile(this.tileX(), this.tileY()).setBlock(DFC.暗核聚变反应堆,this.team);
                }
            if (other!=null){bb=bbbb(other.block)}
            else{bb=null}
            if (bb!=list[ii]){d=0}
            if (ii<23){ii=ii+1}
            else{ii=0;
                if (d==1){cc=1}
                else{cc=0;d=1}
            }//这里cc=0如果改成1会导致一个核心就能自成一个完整结构
        }
    },暗核聚变反应堆核心);
});

