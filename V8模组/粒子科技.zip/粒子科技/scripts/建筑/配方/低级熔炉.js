const library = require("base/MultiCrafter-library");
//const myliquids = require("数据/vars/液体");
//const myitems = require("数据/vars/物品");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"低级熔炉", [
    {
		input: {
			items: ["sand/4","coal/1"],
		},
		output: {
			items: ["粒子科技-玻璃/2"],
		},
        craftTime: 180,
        //
        title: "烧制玻璃",
        group: "普通烧制",
	},
	{
		input: {
			items: ["粒子科技-黏土/2","coal/1"],
		},
		output: {
			items: ["粒子科技-砖头/2"],
		},
        craftTime: 180,
        //
        title: "烧制砖头",
        group: "普通烧制",
	},
	{
		input: {
			items: ["粒子科技-粗铁/2","coal/1"],
		},
		output: {
			items: ["粒子科技-铁/2"],
		},
        craftTime: 250,
        //
        title: "烧铁",
        group: "普通烧制",
	},
	{
		input: {
			items: ["粒子科技-粗铜/2","coal/1"],
		},
		output: {
			items: ["粒子科技-工业铜锭/2"],
		},
        craftTime: 180,
        //
        title: "烧铜",
        group: "普通烧制",
	},
  ],
);