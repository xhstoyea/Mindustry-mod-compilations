const library = require("base/MultiCrafter-library");
//const myliquids = require("数据/vars/液体");
//const myliquids = require("数据/vars/物品");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"浇筑台", [
    {
		input: {
		    
			liquids: ["粒子科技-锡熔融物/3"],
		},
		output: {
			items: ["粒子科技-锡/1"],
		},
        craftTime: 600,
        
        title: "冷却为锡，是用来焊接的材料之一",
        group: "浇筑并冷却",
	},
	{
		input: {
		    
			liquids: ["粒子科技-铁熔融物/3"],
		},
		output: {
			items: ["粒子科技-铁/1"],
		},
        craftTime: 600,
        
        
        title: "冷却为铁，一种便宜且坚固的材料",
        group: "浇筑并冷却",
	},
	{
		input: {
		    
			liquids: ["粒子科技-铅熔融物/2"],
		},
		output: {
			items: ["lead/4"],
		},
        craftTime: 350,
        
        
        title: "冷却为铅，因为没有任何变化所以冷却后还是铅",
        group: "浇筑并冷却",
	},
	{
		input: {
		    
			liquids: ["粒子科技-铀熔融物/3"],
		},
		output: {
			items: ["粒子科技-放射性废品/2"], //原定:二氧化铀 UO2
		},
        craftTime: 600,
        
        
        title: "冷却为UO2，但是这个模组里没有啊",
        group: "浇筑并冷却",
	},
	{
		input: {
		    
			liquids: ["粒子科技-核爆/800"],
		},
		output: {
			items: ["粒子科技-虚无之物/1"],
		},
        craftTime: 9568,
        title: "//// ///程/序/错/误/!/// ////",
        group: "浇筑并冷却",
	},
	{
		input: {
		    
			liquids: ["粒子科技-高热熔融物/2"],
		},
		output: {
			items: ["粒子科技-放射性废品/3"],
		},
        craftTime: 600,
        
        
        title: "冷却高温且具有放射物的液体，但这似乎没有什么用。",
        group: "浇筑并冷却",
	}
  ],
);