// 定义一个四舍五入函数，保留m位小数
function roundToDecimal(a,m){
    var x=Math.round(a*Math.pow(10,m))/Math.pow(10,m)
    return x
}                       // 取m位小数

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// 定义暗核聚变反应堆方块

var basePower = 1200

// 创建新的普通发电机类型"暗核聚变反应堆"
const 暗核聚变反应堆 = extend(ConsumeGenerator, '暗核聚变反应堆', {});

// 使反应堆可配置
暗核聚变反应堆.configurable = true

// 定义反应堆的建筑类型
暗核聚变反应堆.buildType = prov(() => {

    // 初始化二变量
    var currentPower=basePower; //电流功率
    var targetPower=basePower; //目标功率
    
    return new JavaAdapter(ConsumeGenerator.ConsumeGeneratorBuild, {
        // 构建配置界面
    	buildConfiguration(table){
			this.super$buildConfiguration(table)
			// 添加开关控件
			table.check("switch", this.enabled, t => {
			    this.enabled=t
			})
			table.row()
            // 显示功率
            table.add("稳定器功率:"+(targetPower-basePower)).update(t => {
                t.setText("稳定器功率:"+(targetPower-basePower))
            })
            table.row()
            // 添加功率设置滑块
    	    table.slider(0, basePower*2, 1, targetPower, value => {
			    targetPower=value //currentPower
			}).width(300)
    	},
        
        // 每帧更新逻辑
        updateTile(){
            
            // 平滑调整功率(ai的，存疑)
            if(Math.abs(currentPower - targetPower) > 0.1) {
                currentPower = roundToDecimal(currentPower + (targetPower - currentPower) * 0.1, 2);
            } else {
                currentPower = targetPower;
            }
            // 设置实际效率
            this.productionEfficiency = currentPower / basePower;
            
            // 获取当前液体和数量
            this.liquid=this.liquids.current()
            this.liquidAmout=this.liquids.get(this.liquid)
            }
            
        },
        
        // 保存数据
    	write(write){
    		this.super$write(write);
    		write.f(targetPower)
    	},
        
        // 读取数据
    	read(read, revision){
    		this.super$read(read, revision);
    		targetPower=read.f()
    		//currentPower=targetPower
    	},
    }, 暗核聚变反应堆);
);