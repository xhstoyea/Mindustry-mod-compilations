const library = require("base/MultiCrafter-library");
//const myliquids = require("数据/vars/液体");
//const myitems = require("数据/vars/物品");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"轧线机", [
    {
		input: {
		    power: 5, 
			items: ["粒子科技-锡/1"],
		},
		output: {
			items: ["粒子科技-锡线/8"],
		},
        craftTime: 350,
          
        title: "将锡加工为锡线，导电性较差，但是满足焊接等需求",
        group: "轧线工程",
	},
	{
		input: {
		    power: 5, 
			items: ["粒子科技-铁/1"],
		},
		output: {
			items: ["粒子科技-铁线/8"],
		},
        craftTime: 350,
          
        title: "将铁加工为铁线，导电性较差，但是较为坚硬",
        group: "轧线工程",
	},
	{
		input: {
		    power: 5, 
			items: ["lead/1"],
		},
		output: {
			items: ["粒子科技-铅线/8"],
		},
        craftTime: 350,
          
        title: "将铅加工为铅线，导电性较差，但是可以防电离辐射？",
        group: "轧线工程",
	},
	{
		input: {
		    power: 5, 
			items: ["粒子科技-工业铜锭/1"],
		},
		output: {
			items: ["粒子科技-铜线/8"],
		},
        craftTime: 350,
          
        title: "将铜加工为铜线，导电性较好，较为广泛使用",
        group: "轧线工程",
	},
	{
		input: {
		    power: 5, 
			items: ["粒子科技-铀-238/1"],
		},
		output: {
			items: ["粒子科技-铀线/8"],
		},
        craftTime: 350,
          
        title: "将铀-238加工为铀线，导电性差，还有辐射",
        group: "轧线工程",
	},
	{
		input: {
		    power: 5, 
			items: ["粒子科技-铀-235/1"],
		},
		output: {
			items: ["粒子科技-高导铀线/8"],
		},
        craftTime: 350,
         
        title: "将铀-235加工为高导铀线，导电性较好，但是有辐射",
        group: "轧线工程",
	},
	{
		input: {
		    power: 5, 
			items: ["粒子科技-石英/1"],
		},
		output: {
			items: ["粒子科技-石英线/8"],
		},
        craftTime: 350,
         
        title: "将石英加工为石英线，顶多用来装饰？导电性极差",
        group: "轧线工程",
	},
	{
		input: {
		    power: 5, 
			items: ["粒子科技-铀燃料/1"],
		},
		output: {
			items: ["粒子科技-放射性废品/8"],
		},
        craftTime: 360,
         
        title: "将铀燃料棒加工为…不是，你在干什么？",
        group: "轧线工程",
	}
  ],
);