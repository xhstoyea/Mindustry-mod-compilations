const library = require("base/ParameterCrafter-library");
const myliquids = require("数据/vars/液体");
const myitems = require("数据/vars/物品");
const furnace = library.ParameterCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"粒子发生器", [
    {
		input: {
			power: 3500
		},
		output: {
			items: ["粒子科技-分子/50","粒子科技-原子/25","粒子科技-中子/15","粒子科技-质子/14","粒子科技-夸克/5","粒子科技-胶子/8","粒子科技-上帝粒子/1"],
		},
        craftTime: 6000,
        craftbyWeight: true,
        craftTimes: 5,
        title: "高能光子粒子对撞",
        group: "粒子实验",
	},
	],
);