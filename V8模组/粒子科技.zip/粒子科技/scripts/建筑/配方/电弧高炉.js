const library = require("base/MultiCrafter-library");
//const myliquids = require("数据/vars/液体");
//const myitems = require("数据/vars/物品");
const furnace = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild,"电弧高炉", [
    {
		input: {
		    power: 5, 
			items: ["粒子科技-粗锡/4"],
		},
		output: {
			liquids: ["粒子科技-锡熔融物/2"],
		},
        craftTime: 300,
        
        title: "高温熔化粗锡",
        group: "高温融熔",
	},
	{
		input: {
		    power: 6, 
			items: ["粒子科技-粗铁/2"],
		},
		output: {
			liquids: ["粒子科技-铁熔融物/2"],
		},
        craftTime: 300,
        
        
        title: "高温熔化粗铁",
        group: "高温融熔",
	},
	{
		input: {
		    power: 4, 
			items: ["lead/4"],
		},
		output: {
			liquids: ["粒子科技-铅熔融物/2"],
		},
        craftTime: 300,
        
        
        title: "高温熔化铅",
        group: "高温融熔",
	},
	{
		input: {
		    power: 6, 
			items: ["粒子科技-天然铀/2"],
		},
		output: {
			liquids: ["粒子科技-铀熔融物/2"],
		},
        craftTime: 300,
        
        
        title: "高温熔化天然铀",
        group: "高温融熔",
	},
	{
		input: {
		    power: 10, 
			items: ["粒子科技-石英砂/12","coal/5"],
		},
		output: {
			items: ["silicon/1","粒子科技-石英/6"],
		},
        craftTime: 300,
        
        //craftTimes: 3,
        title: "高温熔化石英砂以获得硅",
        group: "高温冶炼",
	},
	{
		input: {
		    power: 9, 
			items: ["粒子科技-铀燃料/2"],
		},
		output: {
			liquids: ["粒子科技-高热熔融物/2"],
		},
        craftTime: 300,
        
        
        title: "高温熔炼铀-238燃料棒，致使产出堆芯融化以后的废料",
        group: "高温融熔",
	}
  ],
);