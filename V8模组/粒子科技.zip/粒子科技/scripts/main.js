MapResizeDialog.minSize = 1
MapResizeDialog.maxSize = 6500
Vars.maxSchematicSize = 99;
//require("穹垒核心")
//try {
    require("特殊/菜单")
/*    log("已执行路径为'scripts/特殊/菜单'的文件");
} catch (error) {
    log("文件错误格式或执行失败,原因:", error);
    log("已跳过该错误模块，继续加载下一个文件");
}*/
try {
    require("建筑/load")
    log("已执行路径为'scripts/建筑/load'的文件");
} catch (error) {
    log("文件错误格式或执行失败,原因:", error);
    log("已跳过该错误模块，继续加载下一个文件");
}
//try {
    require("特殊/load")
    /*log("已执行路径为'scripts/特殊/load'的文件");
} catch (error) {
    log("文件错误格式或执行失败,原因:", error);
    log("已跳过该错误模块，继续加载下一个文件");
}
try {*/
    require("数据/load");
/*    log("已执行路径为'scripts/数据/load'的文件");
} catch (error) {
    log("文件错误格式或执行失败,原因:", error);
    log("已跳过该错误模块，继续加载下一个文件");
}*/
    require("聚变能源核心");
    /*    log("已执行路径为'scripts/聚变能源核心'的文件");
} catch (error) {
    log("文件错误格式或执行失败,原因:", error);
    log("已跳过该错误模块，继续加载下一个文件");
}*/
log("文件加载完成，详见日志");