require("数据/vars/物品")
require("数据/vars/液体")
//require("数据/高温")
