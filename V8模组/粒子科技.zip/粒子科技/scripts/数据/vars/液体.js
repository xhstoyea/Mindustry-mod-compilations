function newLiquid(name) {
	exports[name] = (() => {
		let myLiquid = extend(Liquid, name, {});
		return myLiquid;
	})();
}
newLiquid("铀熔融物")
newLiquid("铅熔融物")
newLiquid("锡熔融物")
newLiquid("铁熔融物")
newLiquid("高热熔融物")
newLiquid("硫酸")
newLiquid("反聚能")
newLiquid("钛混合物")
newLiquid("核爆")