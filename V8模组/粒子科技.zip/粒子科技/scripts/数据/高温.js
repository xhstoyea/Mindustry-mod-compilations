const myLiquids = require("数据/vars/液体")

//~~~~高温~~~~
const defense=new Map() //名+抗性等级
const harm=new Map() //名+高温等级
defense.set("conduit",1) //水管
defense.set("liquid-source",20) //液体源
defense.set("pulse-conduit",2)//脉冲导管
defense.set("liquid-router",1)//液体路由器
defense.set("liquid-container",2)//液体容器
defense.set("liquid-tank",3)//液体罐
defense.set("bridge-conduit",1)//桥导管
defense.set("plated-conduit",5)//电镀导管
defense.set("粒子科技-小男孩",1)//核弹1
harm.set("粒子科技-高热熔融物",8)//高温等级
harm.set("slag",2)
harm.set("粒子科技-核爆",30)
harm.set("粒子科技-锡熔融物",2)
harm.set("粒子科技-铅熔融物",3)
harm.set("粒子科技-铁熔融物",5)
harm.set("粒子科技-铀熔融物",6)
harm.set("粒子科技-反聚能",30)

exports.corr={harm:harm,defense:defense}
