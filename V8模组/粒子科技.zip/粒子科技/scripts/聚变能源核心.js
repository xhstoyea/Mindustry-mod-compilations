const 聚变能源核心 = extend(CoreBlock, "聚变能源核心", {
    canBreak() {
        return Vars.state.teams.cores(Vars.player.team()).size > 4;
    },
    canReplace(other) {
        return other.alwaysReplace;
    },
    canPlaceOn(tile, team) {
        return true;
    }
});

聚变能源核心.buildType = prov(() => {
    return new JavaAdapter(CoreBlock.CoreBuild, {
        killed: false,
        
        updateTile() {
            this.super$updateTile();
            
            // 检查生命值是否低于30且尚未触发自毁
            if (this.healthf() <= 30 && !this.killed) {
                this.killed = true;
                this.startSelfDestruct();
            }
        },
        
        startSelfDestruct() {
            // 显示警告标签
            Vars.ui.showLabel("[red]自毁程序已启动", 3, this.x, this.y);
            
            // 创建视觉和声音效果
            Effects.shake(4, 8, this.x, this.y);
            Effects.effect(Fx.explosion, this.x, this.y);
            Sounds.explosion.at(this.x, this.y);
            
            // 延迟执行主要爆炸效果
            Time.run(60, () => {
                if (!this.isValid()) return;
                
                // 主要爆炸效果
                Effects.shake(8, 16, this.x, this.y);
                Effects.effect(Fx.massiveExplosion, this.x, this.y);
                Sounds.explosionbig.at(this.x, this.y);
                
                // 造成范围伤害
                Damage.damage(this.team, this.x, this.y, 8 * 8, 600);
                
                // 对周围实体造成伤害
                Units.nearby(this.team, this.x, this.y, 10 * 8, cons(unit => {
                    if (unit.team !== this.team) {
                        unit.damage(500);
                    }
                }));
                
                // 破坏周围区块
                Geometry.circle(this.tileX(), this.tileY(), 5, (x, y) => {
                    const tile = Vars.world.tile(x, y);
                    if (tile && tile.block() !== Blocks.air && tile.block() !== this.block) {
                        tile.setBlock(Blocks.air);
                    }
                });
                
                // 最后销毁自身
                this.kill();
            });
        }
    }, 聚变能源核心);
});

exports.聚变能源核心 = 聚变能源核心;