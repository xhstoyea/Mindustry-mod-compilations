    "drawer": {                                 注释
        "type": "DrawMulti",
        "drawers": [
            "DrawWeave",                    绘制编织(军工厂的制作线绘制)
            "DrawDefault",                    绘图默认值
            {
                "type": "DrawRegion"         显示部分
            },
            {
                "type": "DrawLiquidRegion",  显示内部液体
                "drawLiquid": "液体",
                "suffix": "-流体1"
            },
            {
                "type": "DrawBubbles",       绘制气泡
                "color": "十六进制颜色",
                "sides": 10,                  边数
                "recurrence": 3,              重现
                "spread": 6,                  速度
                "radius": 1.5,                 半径
                "amount": 20                数量
            },
            {
                "type": "DrawRegion",        显示组成部分
                "suffix": "-部分1"
            },
            {
		        "type":"DrawFlame",          火焰效果调节
		        "flameRadius": 0,            火焰半径
		        "flameRadiusIn": 0,          火焰内半径
		        "flameRadiusMag": 0,       火焰半径幅度
		        "flameRadiusInMag": 0      火焰内半径幅度
		    }
            {
                "type": "DrawRegion",        转动组成部分
                "suffix": "-转动",             组成部分后缀
                "spinSprite": true,            旋转贴图
                "x": 2.75,                    横坐标(以块中心为原点)
				"y": 2.75,                    纵坐标
				"rotation": 22.5              方向
                "rotateSpeed": 速度值       旋转速度
            },
            {
	            "type":"DrawArcSmelt"       绘制激光冶炼效果
	        },
	        {
                "type": "DrawParticles",      绘制粒子
                "color": "16进制颜色",        颜色
                "alpha": 0.6,                 透明度
                "particleSize": 2,             粒子尺寸
                "particles": 10,               粒子数量
                "particleRad": 6,             粒子弧度
                "particleLife":80              存在时间
            }, 
            {
			    "type": "DrawFade",          绘制渐变
			    "scale": 1.13,                整体规模
			    "alpha": 0.99                 透明度
	        },
	        {
			    "type":"DrawCrucibleFlame",  绘制坩埚火焰
		    },
		    {
		        "type":"DrawCultivator",
		        "plantColor": "16进制颜色",                  植物颜色
                "plantColorLight": "16进制颜色",             植物亮色
                "bottomColor": "16进制颜色",                底部颜色
                "bubbles": 数字,                             气泡数量
                "sides": 数字,                                边数
                "strokeMin": 数字,                           最小描边
                "spread": 数字,                              扩散范围
                "timeScl": 数字,                             时间缩放
                "recurrence": 数字,                          重复率
                "radius": 数字                               半径
		    }, 
        ]
    }


    绘制种类:

        "DrawPart"                          绘制零件
        "PartFunc"                          零件功能
        "PartMove"                         零件移动
        "PartParams"                       零件参数
        "PartProgress"                      零件进度
        
        "DrawArcSmelt"                     绘制激光冶炼效果
        "DrawBlock"                         绘制块
        "DrawBlurSpin"                      模糊旋转
        "DrawBubbles"                      绘制气泡
        "DrawCells"                         绘制单元
        "DrawCircles"                       绘制圆
        "DrawCrucibleFlame"                绘制坩埚火焰
        "DrawCultivator"                     绘制种植物
        "DrawDefault"                       常规绘制
        "DrawFade"                         绘制渐变
        "DrawFlame"                        火焰效果
        "DrawFrames"                       绘制帧
        "DrawGlowRegion"                   绘制发光部分
        "DrawHeatInput"                     绘制热量输入
        "DrawHeatOutput"                   绘制热量输出
        "DrawHeatRegion"                   绘制(输入热量)变色组成部分
        "DrawLiquidOutputs"                 绘制流体输出
        "DrawLiquidRegion"                  绘制(输入流体)变色组成部分
        "DrawLiquidTile"                      绘制流体识别
        "DrawMulti"                          绘制多部分组成
        "DrawMultiWeave"                    拉伸编织(军工厂的制作线绘制)
        "DrawParticles"                       绘制粒子
        "DrawPistons"                        绘制活塞(？)
        "DrawPlasma"                        绘制等离子火焰
        "DrawPower"                         绘制电力
        "DrawPulseShape"                    绘制脉冲形状
        "DrawPumpLiquid"                    绘制泵内流体
        "DrawRegion"                         绘制组成部分
        "DrawShape"                         绘制形状
        "DrawSideRegion"                     绘制 边、面 组成部分
        "DrawSoftParticles"                   绘制软粒子
        "DrawSpikes"                         绘制钉子
        "DrawTurret"                          绘制炮台底座
        "DrawWarmupRegion"                 预热零件
        "DrawWeave"                         绘制编织(军工厂的制作线绘制)