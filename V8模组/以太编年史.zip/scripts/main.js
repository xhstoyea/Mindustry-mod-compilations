require("lib");
require("物品");
require("卸载器");
