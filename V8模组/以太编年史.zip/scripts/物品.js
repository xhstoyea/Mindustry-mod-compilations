function newItem(name) {
	Object.assign(exports[name] = new Item(name));
}

newItem("高爆炸药")
newItem("绛基合金")
newItem("聚变能")
newItem("锎")
newItem("铼")
newItem("铼铱合金")
newItem("拟钢")
newItem("相位能")
newItem("铱")
newItem("渊宇发收器")
newItem("战争协定权限")
newItem("自愈合金")
