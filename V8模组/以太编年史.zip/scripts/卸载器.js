const lib = require("lib");
const ECUnloader = lib.getClass("ec.world.blocks.storage.ECUnloader");
const i = require("物品");

const 装卸器 = new ECUnloader("强化装卸器");
装卸器.size = 1;
装卸器.armor=9;
装卸器.health=560;
装卸器.speed=1.5;
装卸器.group=BlockGroup.transportation;
装卸器.placeableLiquid=true;
装卸器.absorbLasers=true;
装卸器.hasPower=true;
装卸器.underBullets=true;
装卸器.conductivePower=true;
装卸器.outputsPower= true;
装卸器.consumePowerBuffered(1000);
装卸器.requirements = ItemStack.with(
    Items.plastanium, 20, Items.silicon, 15, i.拟钢, 35
);
装卸器.buildVisibility = BuildVisibility.shown;
装卸器.category = Category.effect;

exports.装卸器 = 装卸器;
