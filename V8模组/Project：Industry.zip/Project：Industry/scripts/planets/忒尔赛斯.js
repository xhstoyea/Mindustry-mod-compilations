const lib = require("planets/library");
const 忒尔赛斯 = new Planet("忒尔赛斯", Planets.sun, 1, 3.3);
忒尔赛斯.meshLoader = prov(() => new MultiMesh(
	new HexMesh(忒尔赛斯, 8)
));
忒尔赛斯.generator = extend(SerpuloPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nA3JMQ6AIBAAwQXFRr9i4XuMBR5XkCAYkP9LphwcbmLO/lHMwRq0SY3vF0sGluRvTQ17XoZNStU9d0na20gDduAHAc0Org==")
	}
});
忒尔赛斯.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(忒尔赛斯, 2, 0.15, 0.14, 5, Color.valueOf("D1D1D180"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(忒尔赛斯, 3, 0.6, 0.15, 5, Color.valueOf("D1D1D1"), 2, 0.42, 1.2, 0.45)
));
// const 本初核心 = extend(CoreBlock, "本初核心", {});
// exports.本初核心 = 本初核心;
const 工业核心 = extend(CoreBlock, "工业核心", {})
忒尔赛斯.defaultCore = 工业核心;
忒尔赛斯.generator = new SerpuloPlanetGenerator();
忒尔赛斯.visible = 忒尔赛斯.accessible = 忒尔赛斯.alwaysUnlocked = true;
忒尔赛斯.clearSectorOnLose = false;
忒尔赛斯.tidalLock = false;
忒尔赛斯.localizedName = "忒尔赛斯";
忒尔赛斯.prebuildBase = false;
忒尔赛斯.bloom = false;
忒尔赛斯.startSector = 1;
忒尔赛斯.orbitRadius = 85;
忒尔赛斯.orbitTime = 180 * 60;
忒尔赛斯.rotateTime = 90 * 60;
忒尔赛斯.atmosphereRadIn = 0.02;
忒尔赛斯.atmosphereRadOut = 0.3;
忒尔赛斯.atmosphereColor = 忒尔赛斯.lightColor = Color.valueOf("D1D1D180");
忒尔赛斯.iconColor = Color.valueOf("D1D1D180")
//忒尔赛斯.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);
exports.忒尔赛斯 = 忒尔赛斯;
工业核心.buildVisibility = BuildVisibility.shown
exports.工业核心 = 工业核心;

const 遗迹工厂 = new SectorPreset("遗迹工厂", 忒尔赛斯, 12)
遗迹工厂.difficulty = 1
遗迹工厂.captureWave = 10
遗迹工厂.localizedName = "遗迹工厂"
遗迹工厂.alwaysUnlocked = true
exports.遗迹工厂 = 遗迹工厂
lib.addToResearch(遗迹工厂, {
	parent: "工业核心"
});