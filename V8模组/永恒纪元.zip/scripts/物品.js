function newItem(name, color, obj) {
	Object.assign(exports[name] = new Item(name,
		Color.valueOf(color)), obj);
}
function newLiquid(name, color, obj) {
	Object.assign(exports[name] = new Liquid(name,
		Color.valueOf(color)), obj);
}

newItem("铼铱合金")
newItem("相位能")
newItem("聚变能")
newItem("绛基合金")
newItem("高爆炸药")
newItem("锎")
newItem("拟钢")
newItem("zyhj")
newItem("低温聚合物")
newItem("战争协定权限")
newItem("Ir")
newItem("Re")