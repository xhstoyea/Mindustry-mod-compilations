const dsdplanets = DSDPlanets;
const HIAROS = new Planet("希亚罗斯", dsdplanets.dsdsun, 1, 4.2);
HIAROS.meshLoader = prov(() => new HexMesh(HIAROS, 7));

function color(c) {
	return Color.valueOf(c);
}
/*const sS = require("sectorSize");
sS.planetGrid(HIAROS, 3);*/
HIAROS.generator = new SerpuloPlanetGenerator();
HIAROS.generator = extend(SerpuloPlanetGenerator, {
	arr: [color("99E0FF"), color("C0ECFF"),color("727272FF"), color("99E0FF"),color("4DA6FFFF"),color("7457CEFF"),color("4DA6FFFF"),color("93C1F5FF"),color("CFE3FCFF"),color("ADD5FEFF"),color("ADD5FEFF"),color("99ACFFFF"),color("C0ECFFFF"),color("99ECFFFF"),color("CFE3FCFF")],
	getColor(position) {
		const noise = (amount, a, b, c) => {
			var n = Simplex.noise3d(this.seed + amount, a, b, c, position.x, position.y, position.z);
			return n
		};
		this.vec = new Vec3(noise(1, 16, 0.2, 8 / 3), noise(6, 73, 0.7, 9 / 2.5), noise(3, 2, 0.43, 3 / 2));
		var amo = Mathf.round(Mathf.clamp(this.vec.x * this.arr.length, 0, this.arr.length - 1));
		return Tmp.c1.set(this.arr[amo]);
	},
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgYmBiZmDJS8xNZWB7tmDH0/3NDNwpqcXJRZkFJEZn5eQwMDGw5iUmpOcUMTNGxjAwyz2bMfz6151nfoudbFulCqBcNrU/n73q+eiZQMSMDBAAAdBEhZg==")
	},
	allowLanding(sector){
        return false
        //是否启用数字区块
    }
});
HIAROS.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(HIAROS, 2, 0.3, 0.13, 5, Color.valueOf("99EEFFE2"), 1.2, 0.42, 1, 0.43),
	new HexSkyMesh(HIAROS, 2.5, 0.15, 0.14, 5, Color.valueOf("93C1FFE3"), 1.8, 0.42, 1, 0.4),
	new HexSkyMesh(HIAROS, 3, 0.6, 0.15, 5, Color.valueOf("C0ECFFE4"), 2, 0.42, 1.2, 0.45)
));;
HIAROS.bloom = false;
//不清楚
HIAROS.accessible = true;
//是否在行星菜单内显示
HIAROS.defaultAttributes.set(Attribute.heat, 0);
HIAROS.rotateTime = 1200
//一昼夜的时间(s)
HIAROS.localizedName= "希亚罗斯";
//如果有翻译文件就不需要写这个
HIAROS.visible = true;
//可见
HIAROS.atmosphereRadIn = 0.02; //进入大气层距离
HIAROS.atmosphereRadOut = 0.3; //离开大气层距离
HIAROS.alwaysUnlocked = true;
HIAROS.prebuildBase= false;
HIAROS.orbitRadius = 128;
//星球公转半径
HIAROS.atmosphereColor = HIAROS.lightColor = Color.valueOf("99ecff");
//大气层/发光颜色
HIAROS.atmosphereRadIn = 0.004;
//大气素
HIAROS.atmosphereRadOut = 0.15;
//大气输出
HIAROS.defaultEnv = Env.spores | Env.terrestrial;
//环境
HIAROS.startSector = 0;
//默认解锁的区块编号
HIAROS.clearSectorOnLose = true;
//失败是否重置区域存档
exports.HIAROS = HIAROS;
const lib = require("lib");

const 初指 = extend(CoreBlock, "初指", {});
exports.初指 = 初指;
初指.category = Category.logic;
HIAROS.defaultCore = 初指;

const map1 = new SectorPreset("起源地区", HIAROS, 0);
map1.description = "趁着敌方还未发现来自我们的威胁,占领这里";
//引号内填msav的名字
map1.difficulty = 2;
//难度
map1.alwaysUnlocked = true;
//无需解锁
map1.addStartingItems = true;
//允许添加初始资源
map1.captureWave = 80;
//多少波可占领
map1.localizedName = "起源地区";
exports.map1 = map1;