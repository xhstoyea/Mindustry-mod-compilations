const library = require("建造/library");
const myitems = require("物品");
const 多重合金冶炼炉 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "多重合金冶炼炉", [{
    input: {
        items: ["这是一个模组-铼铱合金/2","这是一个模组-zyhj/2","这是一个模组-相位能/3"],
        power: 25,//需求电力
    },
    output: {
        items: ["这是一个模组-绛基合金/3"],
    },
    craftTime: 80,//生产时间
},
{//同上
    input: {
        items: ["titanium/4","silicon/3"],
        liquids: ["slag/15"],
        power: 15,
    },
    output: {
        items: ["surge-alloy/4"],
    },
    craftTime: 35,
},
{//同上
    input: {
        items: ["plastanium/3","这是一个模组-拟钢/3"],
        liquids: ["slag/32"],
        power: 21,
    },
    output: {
        items: ["这是一个模组-zyhj/4"],
    },
    craftTime: 50,
},
{//同上
    input: {
        items: ["这是一个模组-拟钢/4","这是一个模组-Re/3","这是一个模组-Ir/3"],
        liquids: ["slag/20"],
        power: 20,
    },
    output: {
        items: ["这是一个模组-铼铱合金/4"],
    },
    craftTime: 45,
}]);