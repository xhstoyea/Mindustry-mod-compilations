
const Basecore = extend(CoreBlock, "前线指挥中心", {
	canBreak(tile) {
		return Vars.state.teams.cores(tile.team()).size > 1;
	},
	canReplace(other) {
		return other.alwaysReplace;
	},
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.cores(team);
	}
});

Basecore.buildType = prov(() => {
	let kill = false, num = 1, time = 60 * num;
	return extend(CoreBlock.CoreBuild, Basecore, {
		updateTile() {
			this.super$updateTile();
			if (Vars.state.teams.cores(this.team).size > 20) kill = true;
			if (kill) {
				time--
				if (time == 0) {
					this.kill();
				}
			}
		},
	})
})
const 渊宇接收终端 = extend(CoreBlock,"渊宇接收终端",{setStats() {
        this.super$setStats();
        this.stats.add(Stat.basePowerGeneration, 2800, StatUnit.powerSecond);
    },
    setBars() {
        this.super$setBars();
        this.addBar("power", func((entity) => new Bar(
            prov(() => Core.bundle.format("bar.poweroutput", Strings.fixed(entity.getPowerProduction() * 60, 1))),
            prov(() => Pal.powerBar),
            floatp(() => 1)
        )));
    },
});//得塔一级
渊宇接收终端.buildType = prov(() => {
    return new JavaAdapter(CoreBlock.CoreBuild, {

        getPowerProduction() {
            return 2800 / 60;
        },
    }, 渊宇接收终端);
});
渊宇接收终端.hasPower = true;
渊宇接收终端.consumesPower = false;
渊宇接收终端.outputsPower = true;