const lib = require("lib");
//const ab = lib.getClass("dsd.entities.abilities.NoDamaged");

const 塔纳托斯 = new UnitType('塔纳托斯');
塔纳托斯.constructor = prov(() => extend(UnitTypes.toxopid.constructor.get().class, {}));

exports.塔纳托斯 = 塔纳托斯//前3行是我引用json单位创建js实例的，直接写js单位的话还有别的属性
/*塔纳托斯.abilities.add(
 ab(60)//数值是间隔多久受到伤害，每次受到伤害的时间固定为六分之一秒，接近于受伤一次
//——R
);
*/