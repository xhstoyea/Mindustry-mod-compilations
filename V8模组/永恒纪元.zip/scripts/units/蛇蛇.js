const {UnitEngine} = UnitType;

const librarySnake = require("units/library-蛇");


const 尾 = librarySnake.segment("尾", {
    offsetSegment: 20,
}, {});

const 身 = librarySnake.segment("身", {
    offsetSegment: 20,
}, {});

const 头 = librarySnake.head("头", {
    body: 身,
    end: 尾,
    lengthSnake:11,
}, {});
/*
hand头
body身
tail尾
*/