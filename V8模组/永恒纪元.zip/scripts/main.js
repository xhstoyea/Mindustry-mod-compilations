
function CreatorsPackage(name) {
 	var p = Packages.rhino.NativeJavaPackage(name, Vars.mods.mainLoader());
 	Packages.rhino.ScriptRuntime.setObjectProtoAndParent(p, Vars.mods.scripts.scope)
 	return p
 }
 
 var DSD = CreatorsPackage('dsd')
 importPackage(DSD)
 importPackage(DSD.content)
 //importPackage(TDCreatorsJavaPack.vv)



 ModJS.RunName.add("这是一个模组")
 ModJS.DawnRun.add(run(() => {
require("物品");
require("lib");
require("辅助");
require("希亚罗斯");
require("建造/核心");
require("建造/library");
require("建造/多配方");
require("units/library-蛇蛇");
require("units/蛇蛇");
require("开屏菜单");
require("units/限伤");
}));