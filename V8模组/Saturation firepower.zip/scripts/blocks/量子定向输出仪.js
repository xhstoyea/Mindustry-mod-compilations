const staticUnloader = extend(DirectionalUnloader, "量子定向输出仪", {});
staticUnloader.buildType = prov(() => {
    const speed = staticUnloader.speed;
    const limit = speed;
    let counter = 0;
    return new JavaAdapter(DirectionalUnloader.DirectionalUnloaderBuild, {
        updateTile() {
            counter += this.edelta();
            while (counter >= limit) {
                this.unloadTimer = speed;
                this.super$updateTile();
                counter -= limit;
            }
        },
    }, staticUnloader);
});
staticUnloader.speed = 0.2;
staticUnloader.buildVisibility = BuildVisibility.shown;
staticUnloader.category = Category.distribution;
exports.staticUnloader = staticUnloader;