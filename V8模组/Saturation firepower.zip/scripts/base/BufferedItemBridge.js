const block = Blocks.itemBridge
block.buildType = prov(() => {

    const buffer = new ItemBuffer(block.bufferCapacity);

    return extend(BufferedItemBridge.BufferedItemBridgeBuild, block, {

        updateTransport(other) {
            if (buffer.accepts() && this.items.total() > 0) {
                buffer.accept(this.items.take());
            }
            const item = buffer.poll(block.speed / this.timeScale);
            if (item != null && other.acceptItem(this, item)) {
                this.moved = true;
                other.handleItem(this, item);
                buffer.remove();
            }
        },
        version() {
            return 2
        },
        write(write) {
            this.super$write(write);
            buffer.write(write);
        },

        read(read, revision) {
            this.super$read(read, revision);
            if (revision!=1)buffer.read(read);
        }

    })
})
