const 阳电 = extend(StatusEffect, "阳电", {
    init() {
        this.affinity(阴电, (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Object.assign(new WrapEffect(Fx.titanExplosionFrag,Color.valueOf("EFDDFF"),60),{}).at(unit.x,unit.y)
            result.set(阴电, Math.min(time + result.time, 60));
        });
    }
});
const 阴电 = extend(StatusEffect, "阴电", {
    init() {
        this.affinity(阳电,  (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Object.assign(new WrapEffect(Fx.titanExplosionFrag,Color.valueOf("FFEFB2"),60),{}).at(unit.x,unit.y)
            result.set(阳电, Math.min(time + result.time, 60));
        });
    }
});
const 油蚀 = extend(StatusEffect,"油蚀",{
	init(){
	    this.affinity(StatusEffects.burning, (unit, result, time) => {
            result.set(StatusEffects.burning, time + result.time);
        });
        this.affinity(StatusEffects.melting, (unit, result, time) => {
            result.set(StatusEffects.melting, time + result.time);
        });
	    this.opposite(StatusEffects.wet, StatusEffects.freezing)
	},
});

const 崩溃 = extend(StatusEffect, "崩溃", {
    init(){
	    this.affinity(余热, (unit, result, time) => {
            result.set(余热, time);
        });
	},
});
const 余热 = extend(StatusEffect, "余热", {
	init(){
	    this.affinity(崩溃, (unit, result, time) => {
            //unit.damagePierce(Math.max(this.transitionDamage,(unit.maxHealth+unit.shield)*0.006));
            unit.damagePierce(this.transitionDamage);
            Object.assign(new WrapEffect(Fx.dynamicSpikes,Color.valueOf("F2FF9C"),60),{}).at(unit.x,unit.y)
            result.set(余热, result.time);
        });
	},
});

exports.油蚀 = 油蚀;
exports.阳电 = 阳电;
exports.阴电 = 阴电;
exports.崩溃 = 崩溃;
exports.余热 = 余热;