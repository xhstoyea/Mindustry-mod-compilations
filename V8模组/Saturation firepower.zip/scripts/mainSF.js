MapResizeDialog.minSize = 50
MapResizeDialog.maxSize = 50000
require("SFitems");
require("SFliquids");
const SFStatusEffects = require("base/status");
require("blocks/前哨基地");
require("base/BufferedItemBridge");
require("blocks/最高指挥中心");
require("blocks/铁幕");
require("blocks/铁穹");
require("blocks/量子定向输出仪");
require("planets/泰伯利亚");

//不要更改
function getClass(name){
    return Packages.rhino.NativeJavaClass(Vars.mods.scripts.scope, Packages.java.net.URLClassLoader([
        Vars.mods.getMod("饱和火力").file.file().toURI().toURL()
    ], Vars.mods.mainLoader()).loadClass(name));
};


StatusEffects.burning.init(()=>{
    let class1 = getClass("sf.lib.StatusLib");
    class1.affinity(StatusEffects.burning,StatusEffects.tarred,(unit, result, time)=>{
        unit.damagePierce(8);
        Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
        result.set(StatusEffects.burning, Math.min(time + result.time, 300));
    });
    class1.affinity(StatusEffects.burning,SFStatusEffects.油蚀,(unit, result, time)=>{
        unit.damagePierce(12);
        unit.damage(12);
        Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 1.5), unit.y + Mathf.range(unit.bounds() / 1.5));
        result.set(StatusEffects.burning, Math.min(time + result.time, 300));
    });
    class1.opposite(StatusEffects.burning,StatusEffects.wet,);
    class1.opposite(StatusEffects.burning,StatusEffects.freezing);
});
StatusEffects.melting.init(()=>{
    let class1 = getClass("sf.lib.StatusLib");
    class1.affinity(StatusEffects.melting,StatusEffects.tarred,(unit, result, time)=>{
        unit.damagePierce(8);
        Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
        result.set(StatusEffects.melting, Math.min(time + result.time, 300));
    });
    class1.affinity(StatusEffects.melting,SFStatusEffects.油蚀,(unit, result, time)=>{
        unit.damagePierce(12);
        unit.damage(12);
        Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 1.5), unit.y + Mathf.range(unit.bounds() / 1.5));
        result.set(StatusEffects.melting, Math.min(time + result.time, 300));
    });
    class1.opposite(StatusEffects.melting,StatusEffects.wet);
    class1.opposite(StatusEffects.melting,StatusEffects.freezing)
});

