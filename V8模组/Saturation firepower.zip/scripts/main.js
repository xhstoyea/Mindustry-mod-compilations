MapResizeDialog.minSize = 50
MapResizeDialog.maxSize = 50000
require("SFitems");
require("SFliquids");
require("base/status");
require("blocks/前哨基地");
require("base/BufferedItemBridge");
require("blocks/最高指挥中心");
require("blocks/铁幕");
require("blocks/铁穹");
require("blocks/量子定向输出仪");
require("planets/泰伯利亚");