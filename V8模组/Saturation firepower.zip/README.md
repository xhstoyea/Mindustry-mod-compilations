# 饱和火力/Saturation Firepower
![SF](https://github.com/RA2EXE/Saturation-Firepower/assets/119042209/3a60e114-5c42-493c-af44-8f5bceb499aa)

# WARNING
>Unstable beta! 
Unfortunately, this mod doesn't work on English devices, I'll translate to the English version after completing the whole mod.

# 内容概述/Content overview
>200+ New blocks, covering all aspects! More factories, drills, transmission components, defenses and unit factories!

>50+ Turrets with different shapes and functions, full firepower!

>40+ New units, and comprehensive upgrades to the original units! Download a new gaming experience!

>A large number of new maps (some are under construction, there will eventually be about 30), and more spectacular battle scenes! More difficult battles! Stronger enemies!

>The most realistic battlefield environment and various tactical options. Start with the tutorial and progress to the difficult main campaign, as well as difficult side campaigns for challengers.

# Community
·QQ Group：181108928（respawn in 13/07/2024）
·Discord：https://discord.gg/Y7NhHfku
Suggestions and feedback are welcome here.
