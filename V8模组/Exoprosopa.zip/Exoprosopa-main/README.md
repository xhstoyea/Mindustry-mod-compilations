# Exoprosopa V0.71: Biome Update

<p align="center"><img src="banner.png" alt="banner" width="800"></p>

<p align="center">
  <a href="https://discord.gg/E3N63nvCSc"><img src="https://img.shields.io/badge/Discord_Community-Join-2ea44f?logo=discord&color=5865F2&style=for-the-badge"></a>
</p>

  Exoprosopa adds frostnova planet into the game alongside with its own unique techtree and environment.<br><br>
  Conquer this planet with over 20 campaign maps available on this mod.<br>
  Including challenge maps!<br><br>
  With over 13 items to be discovered, 124 blocks to be researched. and 17 different units to build!<br>

  Thankyou for playing this mod!<br>
  You can contributes maps or give suggestions on Exoprosopa Server!<br><br>

  V0.71, TnmSpiroct
  
  - Codex Resprite
  - More Biomes
  - 2 New Items (Experimental)
  - Removed Some Biomes
  - New Turret, Anvil
  - Fixes some blocks can be placed on deep water
  - Nucrid Crusher
