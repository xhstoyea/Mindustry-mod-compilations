require("多配方/多配方工厂运行");

const 热熔机 = extend(GenericCrafter, "热熔机", {});
exports.热熔机 = 热熔机;

const 制冰机 = extend(GenericCrafter, "制冰机", {});
exports.制冰机 = 制冰机;

const 猩红藻培养仪 = extend(GenericCrafter, "猩红藻培养仪", {});
exports.猩红藻培养仪 = 猩红藻培养仪;

const 玻璃熔炼厂 = extend(GenericCrafter, "玻璃熔炼厂", {});
exports.玻璃熔炼厂 = 玻璃熔炼厂;

const 粉碎机 = extend(GenericCrafter, "粉碎机", {});
exports.粉碎机 = 粉碎机;

const 压缩机 = extend(GenericCrafter, "压缩机", {});
exports.压缩机 = 压缩机;

const 锻钢厂 = extend(GenericCrafter, "锻钢厂", {});
exports.锻钢厂 = 锻钢厂;

const 机床 = extend(GenericCrafter, "机床", {});
exports.机床 = 机床;

const 电弧炉 = extend(GenericCrafter, "电弧炉", {});
exports.电弧炉 = 电弧炉;

const 储能厂 = extend(HeatCrafter, "储能厂", {});
exports.储能厂 = 储能厂;

const 热量传输器 = extend(HeatConductor, "热量传输器", {});
exports.热量传输器 = 热量传输器;

const 制热机 = extend(HeatProducer, "制热机", {});
exports.制热机 = 制热机;

const 熔液制热机 = extend(HeatProducer, "熔液制热机", {});
exports.熔液制热机 = 熔液制热机;

require("多配方/虫蚀工厂配方");