const ITEM = require('分类/物品');

function NLB(name, type) {
	const u = extend(type, name, {});
	return exports[name] = u;
}

//黄铜
NLB("黄铜导管", Conduit);
NLB("黄铜流体路由器", LiquidRouter);
NLB("黄铜流体交叉器", LiquidJunction);
//安山合金
NLB("安山合金导管", Conduit);
NLB("安山合金导管桥", LiquidBridge);
NLB("安山合金流体路由器", LiquidRouter);
NLB("安山合金流体交叉器", LiquidJunction);
NLB("流体装罐", LiquidRouter);
NLB("流体储罐", LiquidRouter);
NLB("大型流体储罐", LiquidRouter);