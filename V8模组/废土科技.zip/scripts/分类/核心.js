const 一阶废料核心 = extend(CoreBlock, "一阶废料核心", {});
exports.一阶废料核心 = 一阶废料核心;

const 终阶废料核心 = extend(CoreBlock, "终阶废料核心", {});
exports.终阶废料核心 = 终阶废料核心;

const 废料前哨 = extend(CoreBlock, "废料前哨", 
 {
       canBreak(tile) { return Vars.state.teams.cores(tile.team()).size > 1; },
       canReplace(other) { return other.alwaysReplace; },
       canPlaceOn(tile, team) { return Vars.state.teams.cores(team).size < 15; },
 });
exports.废料前哨 = 废料前哨;

const 虫视之核 = extend(CoreBlock, "虫视之核", {});
exports.虫视之核 = 虫视之核;

const 安山合金容器 = extend(StorageBlock, "安山合金容器", {});
exports.安山合金容器 = 安山合金容器;

const 安山合金储存舱 = extend(StorageBlock, "安山合金储存舱", {});
exports.安山合金储存舱 = 安山合金储存舱;

const 安山合金卸载器 = extend(Unloader, "安山合金卸载器", {});
exports.安山合金卸载器 = 安山合金卸载器;

const 资源发射台 = extend(LaunchPad, "资源发射台", {});
exports.资源发射台 = 资源发射台;

const 物质补正仪 = extend(MendProjector, "物质补正仪", {});
exports.物质补正仪 = 物质补正仪;

const 物质补正场 = extend(MendProjector, "物质补正场", {});
exports.物质补正场 = 物质补正场;