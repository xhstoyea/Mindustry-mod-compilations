const 陆军工厂 = extend(UnitFactory, "陆军工厂", {});
exports.陆军工厂 = 陆军工厂;

const 空军工厂 = extend(UnitFactory, "空军工厂", {});
exports.空军工厂 = 空军工厂;

const 负减级重构工厂 = extend(Reconstructor, "负减级重构工厂", {});
exports.负减级重构工厂 = 负减级重构工厂;

const 小型构筑器 = extend(Constructor, "小型构筑器", {});
exports.小型构筑器 = 小型构筑器;

const 小型解构器 = extend(PayloadDeconstructor, "小型解构器", {});
exports.小型解构器 = 小型解构器;

const 载荷驱动器 = extend(PayloadMassDriver, "载荷驱动器", {});
exports.载荷驱动器 = 载荷驱动器;

const 资源装载器 = extend(PayloadLoader, "资源装载器", {});
exports.资源装载器 = 资源装载器;

const 资源卸载器 = extend(PayloadUnloader, "资源卸载器", {});
exports.资源卸载器 = 资源卸载器;

const 初代载荷传送带 = extend(PayloadConveyor, "初代载荷传送带", {});
exports.初代载荷传送带 = 初代载荷传送带;

const 初代载荷路由器 = extend(PayloadRouter, "初代载荷路由器", {});
exports.初代载荷路由器 = 初代载荷路由器;
