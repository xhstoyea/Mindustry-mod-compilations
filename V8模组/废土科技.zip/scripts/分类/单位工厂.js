const 陆军工厂 = extend(UnitFactory, "陆军工厂", {});
exports.陆军工厂 = 陆军工厂;

const 空军工厂 = extend(UnitFactory, "空军工厂", {});
exports.空军工厂 = 空军工厂;

const 负减级重构工厂 = extend(Reconstructor, "负减级重构工厂", {});
exports.负减级重构工厂 = 负减级重构工厂;

const 陆军组装厂 = extend(UnitAssembler, "陆军组装厂", {});
exports.陆军组装厂 = 陆军组装厂;

const 初等构建器 = extend(Constructor, "初等构建器", {});
exports.初等构建器 = 初等构建器;

const 小型解构器 = extend(PayloadDeconstructor, "小型解构器", {});
exports.小型解构器 = 小型解构器;

const 载荷驱动器 = extend(PayloadMassDriver, "载荷驱动器", {});
exports.载荷驱动器 = 载荷驱动器;

const 资源装载器 = extend(PayloadLoader, "资源装载器", {});
exports.资源装载器 = 资源装载器;

const 资源卸载器 = extend(PayloadUnloader, "资源卸载器", {});
exports.资源卸载器 = 资源卸载器;

const 初代载荷传送带 = extend(PayloadConveyor, "初代载荷传送带", {});
exports.初代载荷传送带 = 初代载荷传送带;

const 初代载荷路由器 = extend(PayloadRouter, "初代载荷路由器", {});
exports.初代载荷路由器 = 初代载荷路由器;

const 初等单位框架 = extend(Wall, "初等单位框架", {});
exports.初等单位框架 = 初等单位框架;

const 初等海军模块 = extend(Wall, "初等海军模块", {});
exports.初等海军模块 = 初等海军模块;

const 初等陆军模块 = extend(Wall, "初等陆军模块", {});
exports.初等陆军模块 = 初等陆军模块;

const 初等空军模块 = extend(Wall, "初等空军模块", {});
exports.初等空军模块 = 初等空军模块;

const 蜂群工厂 = extend(UnitFactory, "蜂群工厂", {});
exports.蜂群工厂 = 蜂群工厂;

const 蚁群工厂 = extend(UnitFactory, "蚁群工厂", {});
exports.蚁群工厂 = 蚁群工厂;