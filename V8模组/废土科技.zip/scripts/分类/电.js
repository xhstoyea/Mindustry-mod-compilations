const 初级电力传导节点 = extend(PowerNode, "初级电力传导节点", {});
exports.初级电力传导节点 = 初级电力传导节点;

const 二级电力传导节点 = extend(PowerNode, "二级电力传导节点", {});
exports.二级电力传导节点 = 二级电力传导节点;

const 电缆 = extend(Battery, "电缆", {});
exports.电缆 = 电缆;

const 装甲电缆 = extend(Battery, "装甲电缆", {});
exports.装甲电缆 = 装甲电缆;

const 电力墙 = extend(Battery, "电力墙", {});
exports.电力墙 = 电力墙;

const 电表 = extend(PowerNode, "电表", {});
exports.电表 = 电表;

const 太阳能板 = extend(ConsumeGenerator, "太阳能板", {});
exports.太阳能板 = 太阳能板;

const 大型太阳能板 = extend(ConsumeGenerator, "大型太阳能板", {});
exports.大型太阳能板 = 大型太阳能板;

const 小型火力发电机 = extend(ConsumeGenerator, "小型火力发电机", {});
exports.小型火力发电机 = 小型火力发电机;

const 大型火力发电机 = extend(ConsumeGenerator, "大型火力发电机", {});
exports.大型火力发电机 = 大型火力发电机;

const 水车 = extend(ConsumeGenerator, "水车", {});
exports.水车 = 水车;

const 燃油发电机 = extend(ConsumeGenerator, "燃油发电机", {});
exports.燃油发电机 = 燃油发电机;

const 小型电池 = extend(Battery, "小型电池", {});
exports.小型电池 = 小型电池;

const 中型电池 = extend(Battery, "中型电池", {});
exports.中型电池 = 中型电池;

const 大型电池 = extend(Battery, "大型电池", {});
exports.大型电池 = 大型电池;

const 虫蚀光能板 = extend(ConsumeGenerator, "虫蚀光能板", {});
exports.虫蚀光能板 = 虫蚀光能板;

const 大型虫蚀光能板 = extend(ConsumeGenerator, "大型虫蚀光能板", {});
exports.大型虫蚀光能板 = 大型虫蚀光能板;

const 虫蚀燃烧器 = extend(ConsumeGenerator, "虫蚀燃烧器", {});
exports.虫蚀燃烧器 = 虫蚀燃烧器;