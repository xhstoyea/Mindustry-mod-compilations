//矿
const 废料堆积地板 = new OreBlock('废料堆积地板');
exports.废料堆积地板 = 废料堆积地板;

const 粗铜矿 = new OreBlock('粗铜矿');
exports.粗铜矿 = 粗铜矿;

const 铁矿 = new OreBlock('铁矿');
exports.铁矿 = 铁矿;

const 墙粗铜矿 = new OreBlock('墙粗铜矿');
exports.墙粗铜矿 = 墙粗铜矿;

const 墙粗铁矿 = new OreBlock('墙粗铁矿');
exports.墙粗铁矿 = 墙粗铁矿;

const 墙焦炭矿 = new OreBlock('墙焦炭矿');
exports.墙焦炭矿 = 墙焦炭矿;

const 安山岩石 = new OreBlock('安山岩石');
exports.安山岩石 = 安山岩石;

const 金 = new OreBlock('金');
exports.金 = 金;

const 废料挖掘点 = new Floor('废料挖掘点');
exports.废料挖掘点 = 废料挖掘点;

const 粗铜挖掘点 = new Floor('粗铜挖掘点');
exports.粗铜挖掘点 = 粗铜挖掘点;

const 安山岩挖掘点 = new Floor('安山岩挖掘点');
exports.安山岩挖掘点 = 安山岩挖掘点;

const 铁挖掘点 = new Floor('铁挖掘点');
exports.铁挖掘点 = 铁挖掘点;

const 粗金挖掘点 = new Floor('粗金挖掘点');
exports.粗金挖掘点 = 粗金挖掘点;

const 人造水源 = new Floor('人造水源');
exports.人造水源 = 人造水源;
//墙
const 废料墙 = new StaticWall('废料墙');
exports.废料墙 = 废料墙;

const 荒地墙 = new StaticWall('荒地墙');
exports.荒地墙 = 荒地墙;

const 恶地墙 = new StaticWall('恶地墙');
exports.恶地墙 = 恶地墙;

const 虫蚀恶地墙 = new StaticWall('虫蚀恶地墙');
exports.虫蚀恶地墙 = 虫蚀恶地墙;

const 神圣墙 = new StaticWall('神圣墙');
exports.神圣墙 = 神圣墙;

const 银灰墙 = new StaticWall('银灰墙');
exports.银灰墙 = 银灰墙;

const 猩红墙 = new StaticWall('猩红墙');
exports.猩红墙 = 猩红墙;

const 腐化墙 = new StaticWall('腐化墙');
exports.腐化墙 = 腐化墙;

const 死命墙 = new StaticWall('死命墙');
exports.死命墙 = 死命墙;

const 冰墙 = new StaticWall('冰墙');
exports.冰墙 = 冰墙;

const 遗迹墙 = new StaticWall('遗迹墙');
exports.遗迹墙 = 遗迹墙;

const 基地工作围墙 = new StaticWall('基地工作围墙');
exports.基地工作围墙 = 基地工作围墙;
//地板
const 熔液池 = new Floor('熔液池');
exports.熔液池 = 熔液池;

const 深层污水 = new Floor('深层污水');
exports.深层污水 = 深层污水;

const 荒地污水 = new Floor('荒地污水');
exports.荒地污水 = 荒地污水;

const 恶地污水 = new Floor('恶地污水');
exports.恶地污水 = 恶地污水;

const 死命土壤 = new Floor('死命土壤');
exports.死命土壤 = 死命土壤;

const 废土地板 = new Floor('废土地板');
exports.废土地板 = 废土地板;

const 荒地 = new Floor('荒地');
exports.荒地 = 荒地;

const 恶地 = new Floor('恶地');
exports.恶地 = 恶地;

const 虫蚀恶地 = new Floor('虫蚀恶地');
exports.虫蚀恶地 = 虫蚀恶地;

const 神圣地板 = new Floor('神圣地板');
exports.神圣地板 = 神圣地板;

const 银灰地板 = new Floor('银灰地板');
exports.银灰地板 = 银灰地板;

const 猩红地板 = new Floor('猩红地板');
exports.猩红地板 = 猩红地板;

const 腐化地板 = new Floor('腐化地板');
exports.腐化地板 = 腐化地板;

const 冰面 = new Floor('冰面');
exports.冰面 = 冰面;

const 冻土 = new Floor('冻土');
exports.冻土 = 冻土;

const 黄白遗迹地板 = new Floor('黄白遗迹地板');
exports.黄白遗迹地板 = 黄白遗迹地板;

const 棕黑遗迹地板 = new Floor('棕黑遗迹地板');
exports.棕黑遗迹地板 = 棕黑遗迹地板;

const 棕黄遗迹地板 = new Floor('棕黄遗迹地板');
exports.棕黄遗迹地板 = 棕黄遗迹地板;

const 角围格 = new Floor('角围格');
exports.角围格 = 角围格;

const 角围格二 = new Floor('角围格二');
exports.角围格二 = 角围格二;

const 角围格三 = new Floor('角围格三');
exports.角围格三 = 角围格三;

const 角围格四 = new Floor('角围格四');
exports.角围格四 = 角围格四;

const 边围格 = new Floor('边围格');
exports.边围格 = 边围格;

const 基地工作地板 = new Floor('基地工作地板');
exports.基地工作地板 = 基地工作地板;

const 高摩擦地板 = new Floor('高摩擦地板');
exports.高摩擦地板 = 高摩擦地板;

//装饰
const 废土石块 = new Prop('废土石块');
exports.废土石块 = 废土石块;

const 焦树 = new TreeBlock('焦树');
exports.焦树 = 焦树;

const 猩红树 = new TreeBlock('猩红树');
exports.猩红树 = 猩红树;