function newUnit(name, unitType) {
	const u = extend(UnitType, name, {});
	u.constructor = () => extend(unitType, {});
	return exports[name] = u;
}

/*"flying" -> UnitEntity;
"mech" -> MechUnit;
"legs" -> LegsUnit;
"naval" -> UnitWaterMove;
"payload" -> PayloadUnit;
"missile" -> TimedKillUnit;
"tank" -> TankUnit;
"hover" -> ElevationMoveUnit;
"tether" -> BuildingTetherPayloadUnit;
"crawl" -> CrawlUnit;*/
newUnit("废甲",MechUnit);
newUnit("守卫",MechUnit);
newUnit("铁棘",UnitEntity);
newUnit("负殇",UnitEntity);
newUnit("zero-I型",LegsUnit);