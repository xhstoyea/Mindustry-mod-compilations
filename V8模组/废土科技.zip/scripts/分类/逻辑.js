const 微型处理器 = extend(LogicBlock, "微型处理器", {});
exports.微型处理器 = 微型处理器;

const 小型处理器 = extend(LogicBlock, "小型处理器", {});
exports.小型处理器 = 小型处理器;

const 大型处理器 = extend(LogicBlock, "大型处理器", {});
exports.大型处理器 = 大型处理器;

const 小型内存元 = extend(MemoryBlock, "小型内存元", {});
exports.小型内存元 = 小型内存元;

const 信息板 = extend(MessageBlock, "信息板", {});
exports.信息板 = 信息板;

const 逻辑显示器 = extend(LogicDisplay, "逻辑显示器", {});
exports.逻辑显示器 = 逻辑显示器;

const 开关 = extend(SwitchBlock, "开关", {});
exports.开关 = 开关;