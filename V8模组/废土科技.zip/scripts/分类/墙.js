const 小型废料墙 = extend(Wall, "小型废料墙", {});
exports.小型废料墙 = 小型废料墙;

const 中型废料墙 = extend(Wall, "中型废料墙", {});
exports.中型废料墙 = 中型废料墙;

const 大型废料墙 = extend(Wall, "大型废料墙", {});
exports.大型废料墙 = 大型废料墙;

const 巨型废料墙 = extend(Wall, "巨型废料墙", {});
exports.巨型废料墙 = 巨型废料墙;

const 小型黄铜墙 = extend(Wall, "小型黄铜墙", {});
exports.小型黄铜墙 = 小型黄铜墙;

const 中型黄铜墙 = extend(Wall, "中型黄铜墙", {});
exports.中型黄铜墙 = 中型黄铜墙;

const 大型黄铜墙 = extend(Wall, "大型黄铜墙", {});
exports.大型黄铜墙 = 大型黄铜墙;

const 巨型黄铜墙 = extend(Wall, "巨型黄铜墙", {});
exports.巨型黄铜墙 = 巨型黄铜墙;

const 小型虫蚀墙 = extend(Wall, "小型虫蚀墙", {});
exports.小型虫蚀墙 = 小型虫蚀墙;

const 中型虫蚀墙 = extend(Wall, "中型虫蚀墙", {});
exports.中型虫蚀墙 = 中型虫蚀墙;

const 大型虫蚀墙 = extend(Wall, "大型虫蚀墙", {});
exports.大型虫蚀墙 = 大型虫蚀墙;

const 巨型虫蚀墙 = extend(Wall, "巨型虫蚀墙", {});
exports.巨型虫蚀墙 = 巨型虫蚀墙;

const 小型锶晶墙 = extend(Wall, "小型锶晶墙", {});
exports.小型锶晶墙 = 小型锶晶墙;

const 中型锶晶墙 = extend(Wall, "中型锶晶墙", {});
exports.中型锶晶墙 = 中型锶晶墙;

const 大型锶晶墙 = extend(Wall, "大型锶晶墙", {});
exports.大型锶晶墙 = 大型锶晶墙;

const 巨型锶晶墙 = extend(Wall, "巨型锶晶墙", {});
exports.巨型锶晶墙 = 巨型锶晶墙;

const 小型防爆玻璃墙 = extend(Wall, "小型防爆玻璃墙", {});
exports.小型防爆玻璃墙 = 小型防爆玻璃墙;

const 中型防爆玻璃墙 = extend(Wall, "中型防爆玻璃墙", {});
exports.中型防爆玻璃墙 = 中型防爆玻璃墙;

const 大型防爆玻璃墙 = extend(Wall, "大型防爆玻璃墙", {});
exports.大型防爆玻璃墙 = 大型防爆玻璃墙;

const 巨型防爆玻璃墙 = extend(Wall, "巨型防爆玻璃墙", {});
exports.巨型防爆玻璃墙 = 巨型防爆玻璃墙;

const 小型黄铜门 = extend(Door, "小型黄铜门", {});
exports.小型黄铜门 = 小型黄铜门;

const 小型黄铜闸门 = extend(AutoDoor, "小型黄铜闸门", {});
exports.小型黄铜闸门 = 小型黄铜闸门;

const 小型铁块 = extend(Wall, "小型铁块", {});
exports.小型铁块 = 小型铁块;

const 大型铁块 = extend(Wall, "大型铁块", {});
exports.大型铁块 = 大型铁块;

const 小型金块 = extend(Wall, "小型金块", {});
exports.小型金块 = 小型金块;

const 大型金块 = extend(Wall, "大型金块", {});
exports.大型金块 = 大型金块;

const 大型黄铜门 = extend(Door, "大型黄铜门", {});
exports.大型黄铜门 = 大型黄铜门;

const 大型黄铜闸门 = extend(AutoDoor, "大型黄铜闸门", {});
exports.大型黄铜闸门 = 大型黄铜闸门;
//多方块结构方块
const 安山合金隔热层 = extend(Wall, "安山合金隔热层", {});
exports.安山合金隔热层 = 安山合金隔热层;

const 钢制架构 = extend(Wall, "钢制架构", {});
exports.钢制架构 = 钢制架构;

const 储能块 = extend(Battery, "储能块", {});
exports.储能块 = 储能块;

const 电路板 = extend(Wall, "电路板", {});
exports.电路板 = 电路板;

const 金制隔热墙 = extend(Wall, "金制隔热墙", {});
exports.金制隔热墙 = 金制隔热墙;

const 加热器 = extend(Wall, "加热器", {});
exports.加热器 = 加热器;

const 钢制重装板 = extend(Wall, "钢制重装板", {});
exports.钢制重装板 = 钢制重装板;

const 基地货物1x = extend(Wall, "基地货物1x", {});
exports.基地货物1x = 基地货物1x;

const 基地货物2x = extend(Wall, "基地货物2x", {});
exports.基地货物2x = 基地货物2x;

const 基地货物3x = extend(Wall, "基地货物3x", {});
exports.基地货物3x = 基地货物3x;

const 通讯塔 = extend(Wall, "通讯塔", {});
exports.通讯塔 = 通讯塔;
