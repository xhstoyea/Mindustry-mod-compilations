var a = "已加载: "
function newItem(name) {
	exports[name] = extend(Item, name, {});
	a = a + name + ", "
}
function newCellLiquid(name) {
	exports[name] = extend(CellLiquid, name, {});
	a = a + name + ", "
}
function newLiquid(name) {
	exports[name] = extend(Liquid, name, {});
	a = a + name + ", "
}
function newBlock(name) {
	exports[name] = extend(Block, name, {});
	a = a + name + ", "
}
//Item——————————————————
newItem("废料")
newItem("粗铜")
newItem("黄铜")
newItem("粗金")
newItem("精密构件")
newItem("安山岩")
newItem("安山合金")
newItem("铁")
newItem("钢")
newItem("碳")
newItem("猩红藻")
newItem("钢化玻璃")
newItem("绿藻")
newItem("铜板")
newItem("铁板")
newItem("金板")
newItem("帝科斯基白模研究卡")
newItem("帝科斯基基础研究卡")
newItem("帝科斯基物流研究卡")
newLiquid("水")
newLiquid("熔融铜")
newLiquid("熔融铁")
newLiquid("熔融金")
newLiquid("有机溶液")
newLiquid("熔液")
newLiquid("石油")
newLiquid("二氧化碳")
newBlock("最高访问协议")
newBlock("科技_原始")
newBlock("科技_工业")
newBlock("成就_地图_1")

log(a)

//废料,粗铜,黄铜,安山岩,安山合金,铁,钢,碳,猩红藻,钢化玻璃,绿藻,有机物,水,熔融铜,熔融金,