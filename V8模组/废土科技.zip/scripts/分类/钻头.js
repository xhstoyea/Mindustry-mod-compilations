const 废料钻头 = extend(Drill, "废料钻头", {});
exports.废料钻头 = 废料钻头;

const 黄铜钻头 = extend(Drill, "黄铜钻头", {});
exports.黄铜钻头 = 黄铜钻头;

const 充能钻头 = extend(Drill, "充能钻头", {});
exports.充能钻头 = 充能钻头;

const 水钻机 = extend(SolidPump, "水钻机", {});
exports.水钻机 = 水钻机;

const 中型抽水机 = extend(SolidPump, "中型抽水机", {});
exports.中型抽水机 = 中型抽水机;

const 气压泵 = extend(SolidPump, "气压泵", {});
exports.气压泵 = 气压泵;

const 石油钻井 = extend(GenericCrafter, "石油钻井", {});
exports.石油钻井 = 石油钻井;

const 废料钻井 = extend(GenericCrafter, "废料钻井", {});
exports.废料钻井 = 废料钻井;