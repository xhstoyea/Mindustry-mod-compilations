const 空 =Attribute.add("空")
exports.空 =空
const 水 =Attribute.add("水")
exports.水 =水
const 石油 =Attribute.add("石油")
exports.石油 =石油