const lib = require('lib')
const 物品 = require('分类/物品')

const 开端 = new ItemTurret('开端');
exports.开端 = 开端;

const 防空机枪 = new ItemTurret('防空机枪');
exports.防空机枪 = 防空机枪;

const 黄铜双管炮 = new ItemTurret('黄铜双管炮');
exports.黄铜双管炮 = 黄铜双管炮;

const 安山合金双管炮 = new ItemTurret('安山合金双管炮');
exports.安山合金双管炮 = 安山合金双管炮;

const 剑光 = new ItemTurret('剑光');
exports.剑光 = 剑光;

const 伏特 = new PowerTurret('伏特');
exports.伏特 = 伏特;

const 光束 = new PowerTurret('光束');
exports.光束 = 光束;

const 高压 = new PowerTurret('高压');
exports.高压 = 高压;

const 护卫 = new PowerTurret('护卫');
exports.护卫 = 护卫;

const 驱逐 = new LiquidTurret('驱逐');
exports.驱逐 = 驱逐;

const 劫火 = new ItemTurret('劫火');
exports.劫火 = 劫火;

const 破败 = new ItemTurret('破败');
exports.破败 = 破败;

const 粉碎 = new PowerTurret('粉碎');
exports.粉碎 = 粉碎;

const 虫啮 = new ItemTurret('虫啮');
exports.虫啮 = 虫啮;