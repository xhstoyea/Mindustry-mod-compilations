function newStatusEffect(name) {
	exports[name] = extend(StatusEffect, name, {});
}
newStatusEffect('电离')
newStatusEffect('火蚀')