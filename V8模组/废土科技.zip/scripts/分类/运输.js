//废料物流
const 废料管道 = extend(Duct, "废料管道", {});
exports.废料管道 = 废料管道;

const 废料交叉器 = extend(DuctJunction, "废料交叉器", {});
exports.废料交叉器 = 废料交叉器;

const 废料运输桥 = extend(ItemBridge, "废料运输桥", {});
exports.废料运输桥 = 废料运输桥;

const 废料路由器 = extend(Router, "废料路由器", {});
exports.废料路由器 = 废料路由器;

const 废料分类器 = extend(Sorter, "废料分类器", {});
exports.废料分类器 = 废料分类器;

const 废料反向分类器 = extend(Sorter, "废料反向分类器", {});
exports.废料反向分类器 = 废料反向分类器;

const 废料溢流门 = extend(OverflowGate, "废料溢流门", {});
exports.废料溢流门 = 废料溢流门;

const 废料反向溢流门 = extend(OverflowGate, "废料反向溢流门", {});
exports.废料反向溢流门 = 废料反向溢流门; 



   //黄铜物流
const 黄铜管道 = extend(Duct, "黄铜管道", {});
exports.黄铜管道 = 黄铜管道;

const 黄铜交叉器 = extend(DuctJunction, "黄铜交叉器", {});
exports.黄铜交叉器 = 黄铜交叉器;

const 黄铜运输桥 = extend(ItemBridge, "黄铜运输桥", {});
exports.黄铜运输桥 = 黄铜运输桥;



//合金物流
const 合金管道 = extend(Duct, "合金管道", {});
exports.合金管道 = 合金管道;

const 合金交叉器 = extend(DuctJunction, "合金交叉器", {});
exports.合金交叉器 = 合金交叉器;

const 合金运输桥 = extend(ItemBridge, "合金运输桥", {});
exports.合金运输桥 = 合金运输桥;
//???敌人物流
const 虫蚀管道 = extend(Duct, "虫蚀管道", {});
exports.虫蚀管道 = 虫蚀管道;

const 虫蚀交叉器 = extend(DuctJunction, "虫蚀交叉器", {});
exports.虫蚀交叉器 = 虫蚀交叉器;

const 虫蚀运输桥 = extend(ItemBridge, "虫蚀运输桥", {});
exports.虫蚀运输桥 = 虫蚀运输桥;

const 虫蚀路由器 = extend(Router, "虫蚀路由器", {});
exports.虫蚀路由器 = 虫蚀路由器;

const 虫蚀分类器 = extend(Sorter, "虫蚀分类器", {});
exports.虫蚀分类器 = 虫蚀分类器;

const 虫蚀反向分类器 = extend(Sorter, "虫蚀反向分类器", {});
exports.虫蚀反向分类器 = 虫蚀反向分类器;

const 虫蚀溢流门 = extend(OverflowGate, "虫蚀溢流门", {});
exports.虫蚀溢流门 = 虫蚀溢流门;

const 虫蚀反向溢流门 = extend(OverflowGate, "虫蚀反向溢流门", {});
exports.虫蚀反向溢流门 = 虫蚀反向溢流门; 