//废料物流
const 废料传送带 = extend(Conveyor, "废料传送带", {});
exports.废料传送带 = 废料传送带;

const 废料交叉器 = extend(Junction, "废料交叉器", {});
exports.废料交叉器 = 废料交叉器;

const 废料运输桥 = extend(ItemBridge, "废料运输桥", {});
exports.废料运输桥 = 废料运输桥;

const 废料路由器 = extend(Router, "废料路由器", {});
exports.废料路由器 = 废料路由器;

const 废料分类器 = extend(Sorter, "废料分类器", {});
exports.废料分类器 = 废料分类器;

const 废料反向分类器 = extend(Sorter, "废料反向分类器", {});
exports.废料反向分类器 = 废料反向分类器;

const 废料溢流门 = extend(OverflowGate, "废料溢流门", {});
exports.废料溢流门 = 废料溢流门;

const 废料反向溢流门 = extend(OverflowGate, "废料反向溢流门", {});
exports.废料反向溢流门 = 废料反向溢流门; 



   //黄铜物流
const 黄铜传送带 = extend(Conveyor, "黄铜传送带", {});
exports.黄铜传送带 = 黄铜传送带;

const 黄铜交叉器 = extend(Junction, "黄铜交叉器", {});
exports.黄铜交叉器 = 黄铜交叉器;

const 黄铜运输桥 = extend(ItemBridge, "黄铜运输桥", {});
exports.黄铜运输桥 = 黄铜运输桥;



//合金物流
const 合金传送带 = extend(Conveyor, "合金传送带", {});
exports.合金传送带 = 合金传送带;

const 合金交叉器 = extend(Junction, "合金交叉器", {});
exports.合金交叉器 = 合金交叉器;

const 合金运输桥 = extend(ItemBridge, "合金运输桥", {});
exports.合金运输桥 = 合金运输桥;