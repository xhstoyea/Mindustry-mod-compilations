const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");

const 冶炼厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "冶炼厂", [//冶炼厂，工厂名
    {
        input: {
            items: ["废土科技-粗铜/7"],
            power: 1
        },
        output: {
            liquids: ["废土科技-熔融铜/6"]
        },
        craftTime: 30
    },
    {
        input: {
            items: ["废土科技-粗金/4"],
            power: 1
        },
        output: {
            liquids: ["废土科技-熔融金/3"]
        },
        craftTime: 45
    }
])