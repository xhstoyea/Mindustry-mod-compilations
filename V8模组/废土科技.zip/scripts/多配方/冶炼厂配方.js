const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");

const 冶炼厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "冶炼厂", [//冶炼厂，工厂名
	{
		input: {
			items: ["废土科技-粗铜/7"],
			power: 1
		},
		output: {
			liquids: ["废土科技-熔融铜/6"]
		},
		stages: [
			{
				title: "熔炼粗铜@minor 高温熔化粗铜",
				bartitle: "熔炼中",
				input: ["7 粗铜"],
				output: ["6 熔融铜"]
			},
		],
		craftTime: 30
	},
	{
		input: {
			items: ["废土科技-粗铁/7"],
			power: 1
		},
		output: {
			liquids: ["废土科技-熔融铁/6"]
		},
		stages: [
			{
				title: "熔炼粗铁@minor 高温熔化粗铁",
				bartitle: "熔炼中",
				input: ["7 粗铁"],
				output: ["6 熔融铁"]
			},
		],
		craftTime: 30
	},
	{
		input: {
			items: ["废土科技-粗金/4"],
			power: 1
		},
		output: {
			liquids: ["废土科技-熔融金/3"]
		},
		stages: [
			{
				title: "熔炼粗金@minor 高温熔化粗金",
				bartitle: "熔炼中",
				input: ["4 粗金"],
				output: ["3 熔融金"]
			},
		],
		craftTime: 45
	}
])