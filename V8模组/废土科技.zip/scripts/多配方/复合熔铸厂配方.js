const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");

const 复合熔铸厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "复合熔铸厂", [
    {
        input: {
            items: ["废土科技-铁/6", "废土科技-碳/6"],
            power: 3
        },
        output: {
            items: ["废土科技-钢/6", ]
        },
        craftTime: 15
    },
    {
        input: {
            items: ["废土科技-废沙/6","废土科技-碳/6"],
            power: 4
        },
        output: {
            items: ["废土科技-钢化玻璃/6", ]
        },
        craftTime: 15
    }
])