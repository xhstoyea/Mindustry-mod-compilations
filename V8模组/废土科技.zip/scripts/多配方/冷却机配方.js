const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");
const 冷却机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "冷却机", [
    {
        input: {
            liquids: [
            "废土科技-熔融铜/6", 
            "废土科技-水/6"
            ],
            power: 1
        },
        output: {
            items: [
            "废土科技-黄铜/5"
            ]
        },
        craftTime: 30
    },
    {
        input: {
            liquids: [
            "废土科技-熔融铁/6",
            "废土科技-水/1"
            ],
            power: 1
        },
        output: {
            items: ["废土科技-铁/5"]
        },
        craftTime: 30
    },
    {
        input: {
            liquids: [
            "废土科技-熔融金/6"
            ],
            items: [
            "废土科技-冰/1"
            ],
            power: 1
        },
        output: {
            items: ["废土科技-金/5"]
        },
        craftTime: 30
    }
]);