const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");
const 冷却机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "冷却机", [
	{
		input: {
			liquids: [
			"废土科技-熔融铜/6", 
			"废土科技-水/6"
			],
			power: 1
		},
		output: {
			items: [
			"废土科技-黄铜/5"
			]
		},
		stages: [
			{
				title: "冷却金属液@minor 使用特殊科技冷却金属",
				bartitle: "冷却中",
				input: ["6 熔融铜+ 6 水"],
				output: ["5 黄铜"]
			},
		],
		craftTime: 30
	},
	{
		input: {
			liquids: [
			"废土科技-熔融铁/6",
			"废土科技-水/6"
			],
			power: 1
		},
		output: {
			items: ["废土科技-铁/5"]
		},
		stages: [
			{
				title: "冷却金属液@minor 使用特殊科技冷却金属",
				bartitle: "冷却中",
				input: ["6 熔融铁+ 6 水"],
				output: ["5 铁"]
			},
		],
		craftTime: 30
	},
	{
		input: {
			liquids: [
			"废土科技-熔融金/6"
			],
			items: [
			"废土科技-冰/1"
			],
			power: 1
		},
		output: {
			items: ["废土科技-金/5"]
		},
		stages: [
			{
				title: "冷却金属液@minor 使用特殊科技冷却金属",
				bartitle: "冷却中",
				input: ["6 熔融金+ 1 冰"],
				output: ["5 金"]
			},
		],
		craftTime: 30
	}
]);