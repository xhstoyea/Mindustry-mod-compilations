const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");

const 初代实验室 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "初代实验室", [
    {
        input: {
            power: 5
        },
        output: {
            items: ["废土科技-帝科斯基白模研究卡/1"]
        },
        craftTime: 60
    },
    {
        input: {
            power: 1000 / 60
        },
        output: {
            items: ["废土科技-帝科斯基基础研究卡/1"]
        },
        craftTime: 1800
    },
    {
        input: {
            power: 2000 / 60
        },
        output: {
            items: ["废土科技-帝科斯基物流研究卡/1"]
        },
        craftTime: 3600
    }
])