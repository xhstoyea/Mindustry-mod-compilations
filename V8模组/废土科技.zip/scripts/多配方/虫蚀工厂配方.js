const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");

const 虫蚀工厂1x = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "虫蚀工厂1x", [
	{
		input: {
			items: ["废土科技-废料/1"],
			power: 0.1
		},
		output: {
			items: ["废土科技-废沙/1"]
		},
		group:"粉碎机",
		craftTime: 30
	},
]);

const 虫蚀工厂2x = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "虫蚀工厂2x", [
	{
		input: {
			items: ["废土科技-粗铜/7"],
			power: 1
		},
		output: {
			liquids: ["废土科技-熔融铜/6"]
		},
		group:"冶炼厂",
		craftTime: 30
	},
	{
		input: {
			items: ["废土科技-粗铁/7"],
			power: 1
		},
		output: {
			liquids: ["废土科技-熔融铁/6"]
		},
		group:"冶炼厂",
		craftTime: 30
	},
	{
		input: {
			items: ["废土科技-粗金/4"],
			power: 1
		},
		output: {
			liquids: ["废土科技-熔融金/3"]
		},
		group:"冶炼厂",
		craftTime: 45
	},
	
	{
		input: {
			liquids: [
			"废土科技-熔融铜/6", 
			"废土科技-水/6"
			],
			power: 1
		},
		output: {
			items: [
			"废土科技-黄铜/5"
			]
		},
		group:"冷却机",
		craftTime: 30
	},
	{
		input: {
			liquids: [
			"废土科技-熔融铁/6",
			"废土科技-水/6"
			],
			power: 1
		},
		output: {
			items: ["废土科技-铁/5"]
		},
		group:"冷却机",
		craftTime: 30
	},
	{
		input: {
			liquids: [
			"废土科技-熔融金/6"
			],
			items: [
			"废土科技-冰/1"
			],
			power: 1
		},
		output: {
			items: ["废土科技-金/5"]
		},
		group:"冷却机",
		craftTime: 30
	},
	{
		input: {
			items: [
			"废土科技-安山岩/2",
			"废土科技-铁/2"
			],
		},
		output: {
			items: ["废土科技-安山合金/2"]
		},
		group:"热熔机",
		craftTime: 45
	},
]);

const 虫蚀工厂3x = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "虫蚀工厂3x", [
	{
		input: {
			liquids: ["废土科技-水/0.03"],
			power: 1
		},
		output: {
			items: ["废土科技-冰/20"]
		},
		group:"制冰机",
		craftTime: 600
	},
])

const 虫蚀钻井 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "虫蚀钻井", [
	{
		input: {
			power: 0.3
		},
		output: {
			liquids: ["废土科技-水/18"]
		},
		group:"气压泵",
		craftTime: 60
	},
	{
		input: {
			power: 1,
			liquids: ["废土科技-水/24"]
		},
		output: {
			items: ["废土科技-碳/3"]
		},
		group:"钻头(碳)",
		craftTime: 60
	},
])