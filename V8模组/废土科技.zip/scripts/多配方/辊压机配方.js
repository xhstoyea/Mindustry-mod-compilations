const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");
const 辊压机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "辊压机", [
    {
        input: {
            items: [
            "废土科技-黄铜/1"
            ]
            power: 1
        },
        output: {
            items: [
            "废土科技-铜板/1"
            ]
        },
        craftTime: 30
    },
    {
        input: {
            items: [
            "废土科技-铁/1"
            ]
            power: 1
        },
        output: {
            items: [
            "废土科技-铁板/1"
            ]
        },
        craftTime: 30
    },
    {
        input: {
            items: [
            "废土科技-金/1"
            ]
            power: 1
        },
        output: {
            items: [
            "废土科技-金板/1"
            ]
        },
        craftTime: 30
    },
]);