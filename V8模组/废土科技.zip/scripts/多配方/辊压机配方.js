const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");
const 辊压机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "辊压机", [
	{
		input: {
			items: ["废土科技-黄铜/3"],
			power: 1
		},
		output: {
			items: ["废土科技-铜板/3"]
		},
		stages: [
			{
				title: "加热@minor 将电能转化为热能快速加热黄铜",
				bartitle: "加热中",
				input: ["黄铜"],
				output: ["半熔融黄铜"]
			},
			{
				title: "压板@minor 通过液压杠杆等装置压制黄铜",
				bartitle: "压制中",
				input: ["半熔融黄铜"],
				output: ["半熔融铜板"]
			},
			{
				title: "冷却@minor 通过特殊制冷设备冷却",
				bartitle: "冷却中",
				input: ["半熔融铜板"],
				output: ["铜板"]
			},
		],
		craftTime: 90
	},
	{
		input: {
			items: ["废土科技-铁/3"],
			power: 1.5
		},
		output: {
			items: ["废土科技-铁板/3"]
		},
		stages: [
			{
				title: "加热@minor 将电能转化为热能快速加热铁",
				bartitle: "加热中",
				input: ["铁"],
				output: ["半熔融铁"]
			},
			{
				title: "压板@minor 通过液压杠杆等装置压制铁",
				bartitle: "压制中",
				input: ["半熔融铁"],
				output: ["半熔融铁板"]
			},
			{
				title: "冷却@minor 通过特殊制冷设备冷却",
				bartitle: "冷却中",
				input: ["半熔融铁板"],
				output: ["铁板"]
			},
		],
		craftTime: 90
	},
	{
		input: {
			items: ["废土科技-金/1"],
			power: 2.5
		},
		output: {
			items: ["废土科技-金板/1"]
		},
		stages: [
			{
				title: "加热@minor 将电能转化为热能快速加热金",
				bartitle: "加热中",
				input: ["金"],
				output: ["半熔融金"]
			},
			{
				title: "压板@minor 通过液压杠杆等装置压制金",
				bartitle: "压制中",
				input: ["半熔融金"],
				output: ["半熔融金板"]
			},
			{
				title: "冷却@minor 通过特殊制冷设备冷却",
				bartitle: "冷却中",
				input: ["半熔融金板"],
				output: ["金板"]
			},
		],
		craftTime: 90
	},
]);