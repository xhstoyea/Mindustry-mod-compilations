require("多配方/冷却机配方")
require("多配方/冶炼厂配方")
require("多配方/初代实验室配方")
require("多配方/复合熔铸厂配方")