Vars.renderer.minZoom = 0.1;//最小缩放尺寸
Vars.renderer.maxZoom = 50;//最大缩放尺寸
Vars.maxSchematicSize = 99;//蓝图最大尺寸
MapResizeDialog.minSize = 1//地图最小尺寸
MapResizeDialog.maxSize = 5000//地图最大尺寸
//我希望5000*5000不会把你我的手机干爆
require("library")
require("科技树")
try {
    require("菜单");
} catch (error) {
    log("菜单加载或执行失败,原因: ", error);
    log("已跳过菜单模块，继续执行下一个js");
}
log("菜单已加载")
require("多配方/多配方工厂运行")
require("分类/分类运行")
require("多方块/多方块工厂运行")
require("行卫星/行卫星运行");
log("废土科技的js已全部加载")