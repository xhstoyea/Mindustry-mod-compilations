const lib = require("lib");
const {一阶废料核心} = require('分类/核心');
const {帝科斯基} = require('行卫星/帝科斯基');
const 死命 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new MultiMesh(
            new NoiseMesh(this, 69, 5, 0.3, 8, 1, 0.05, 3, Color.valueOf("#4e546f"), Color.valueOf("#6e7a8d"), 1, 0.125, 2, 0.5)
    )); 
        this.super$load();
    }//行星构建
}, "死命",帝科斯基 , 0.4);//类型:行星

const c1 = Color.valueOf("#4e546f"), c2 = Color.valueOf("#6e7a8d"), c3 = Color.valueOf("#91a0b0");//行星总体颜色
const sS = require("sectorSize");
sS.planetGrid(死命, 1);//行星网格数量10*3的n次幂+2

死命.cloudMeshLoader = prov(() => new MultiMesh(
    new HexSkyMesh(死命, 2, 0.15, 0.14, 5, Color.valueOf("91A0B080"), 2, 0.42, 0.5, 0.43),//种子，旋转速度，半径，精细度，颜色，噪声层数，噪声衰减，缩放比例，筛选
	new HexSkyMesh(死命, 3, 0.6, 0.16, 5, Color.valueOf("6E7A8DFF"), 2, 0.42, 1.2, 0.45)
));
死命.generator = extend(SerpuloPlanetGenerator,{
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgYmBiYWDJS8xNZWB7tmDH0/3NDOzFJamJuZkpDFzFyRmpuYklmcnFDNwpqcXJRZkFJZn5eQwMDGw5iUmpOcUMTNGxjAzyT3fNfzpn/vPlE591Neg+2dHwcsY2oNCzaTOhJjIwMDJAAADBmCrd");
	},
	allowLanding (sector) {
		return false
	},
});
死命.minZoom = 0.6;
死命.allowCampaignRules = true;//见帝科斯基
死命.atmosphereColor = 死命.lightColor = Color.valueOf("4e546f90");
死命.landCloudColor = Color.valueOf("4e546f");//云层颜色
死命.atmosphereRadIn = 0;
死命.atmosphereRadOut = 0.5;//星球大气层厚度
死命.hasAtmosphere = true;//自身可看见大气层
死命.lightSrcTo = 0.5;//区块光照变化
死命.lightDstFrom  = 0.5;//大气层
死命.localizedName = "死命";//行星名
死命.visible = true;//星球是否可见
死命.bloom = false;//光源（？）
死命.atmosphereColor = 死命.lightColor = Color.valueOf("4e546f90");//大气颜色光效
死命.updateLighting = true;//区块的昼夜交替
死命.accessible = true;//星球是否可以到达
死命.launchCapacityMultiplier = 0.5;//发射核心时最大可携带的资源量,“1”为发射的核心的100%容量,0.5为50%
死命.allowLaunchSchematics = true;//开启发射核心蓝图
死命.description = "易守难攻的卫星，几乎没有工业区";//星球介绍
死命.allowSectorInvasion = false;//模拟攻击图入侵
死命.allowWaveSimulation = true;//模拟后台波次
死命.alwaysUnlocked = true;//默认解锁
死命.clearSectorOnLose = false;//不知道什么玩意,关了吧
死命.allowLaunchLoadout = true;//允许带资源发射核心
死命.startSector = 273;//星球起始公转方向(相对于太阳,1~360随便填)
死命.orbitRadius = 10;//星球轨道半径
死命.tidalLock = true//星球潮汐锁定
死命.iconColor = Color.valueOf("#6e7a8d");//图标颜色
死命.rotateTime = 300;//星球自转一周的时间
死命.defaultCore = 一阶废料核心;//默认发射核心

exports.死命 = 死命