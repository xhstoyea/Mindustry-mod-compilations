/*树结构
1{1{1{1{1{1}, 2}}}, 2}
*/
//嘿，我知道你们会抄，但能不能把区块编号换几下，Tecoskia是帝科斯基英文名！
//引用
const {负减级重构工厂,空军工厂} = require('分类/单位工厂');
const {一阶废料核心} = require('分类/核心');
const {帝科斯基} = require('行卫星/帝科斯基');
const {死命} = require('行卫星/死命');
const lib = require('lib');
//=======================帝科斯基树
帝科斯基.startSector = 0;
const Tecoskia1 = new SectorPreset("废墟古城", 帝科斯基, 0);
//地图编号（Tecoskia1），文件名称，星球，区块编号
Tecoskia1.alwaysUnlocked = true;
Tecoskia1.difficulty = 0;
Tecoskia1.captureWave = 10;
Tecoskia1.description = "被一个文明遗弃了的区块,似乎这个文明已经消亡,可以利用这里的资源发展";
Tecoskia1.localizedName = "废墟古城";
Events.on(ContentInitEvent, (e) => {
    lib.addToResearch(Tecoskia1, {
        parent: '一阶废料核心'
    });
});
exports.Tecoskia1 = Tecoskia1;

// map3相关代码整合
const Tecoskia11 = new SectorPreset("猩红起始地段", 帝科斯基, 92);
Tecoskia11.alwaysUnlocked = false;
Tecoskia11.difficulty = 1;
Tecoskia11.captureWave = 20;
Tecoskia11.description = "这里原本是猩红藻培养基站,与往日一样,实验员德尔塔正在培养具有放射性的猩红藻,试图加入反应堆中运作,直到助手泽塔不慎将一滴液体滴入培养仓——那滴液体是生长液,而那群藻正在自主合成生长液并不可控的大量繁殖……";
Tecoskia11.localizedName = "猩红起始地段";
Events.on(ContentInitEvent, (e) => {
    lib.addToResearch(Tecoskia11, {
        parent: '废墟古城',
        objectives: Seq.with(
            new Objectives.SectorComplete(Tecoskia1)
        )
    });
});
exports.Tecoskia11 = Tecoskia11;

const Tecoskia12 = new SectorPreset("陡峭岩山", 帝科斯基, 95);
Tecoskia12.alwaysUnlocked = false;
Tecoskia12.difficulty = 1;
Tecoskia12.captureWave = 20;
Tecoskia12.description = "这里拥有比较丰富的安山岩资源，可以制作我们的第一种混合物-安山合金";
Tecoskia12.localizedName = "陡峭岩山";
Events.on(ContentInitEvent, (e) => {
    lib.addToResearch(Tecoskia12, {
        parent: '废墟古城',
        objectives: Seq.with(
            new Objectives.SectorComplete(Tecoskia1),
            new Objectives.SectorComplete(Tecoskia11)
        )
    });
});
exports.Tecoskia12 = Tecoskia12;

// map4相关代码整合
const Tecoskia111 = new SectorPreset("对峙狭廊", 帝科斯基, 32);
Tecoskia111.alwaysUnlocked = false;
Tecoskia111.difficulty = 1;
Tecoskia111.description = "敌人在猩红藻爆发后蜗居于此,为了防御猩红,他们制造了腐化孢子,效果较好,可他们忘记了,腐化是一种孢子,在那时,满地的蘑菇开始散放孢子,人口再次锐减";
Tecoskia111.localizedName = "对峙狭廊";
Events.on(ContentInitEvent, (e) => {
    lib.addToResearch(Tecoskia111, {
        parent: '猩红起始地段',
        objectives: Seq.with(
            new Objectives.SectorComplete(Tecoskia11),
            new Objectives.Research(空军工厂)
        )
    });
});
exports.Tecoskia111 = Tecoskia111;

const Tecoskia1111 = new SectorPreset("金石幽谷", 帝科斯基, 154);
Tecoskia1111.alwaysUnlocked = false;
Tecoskia1111.difficulty = 1;
Tecoskia1111.captureWave = 20;
Tecoskia1111.description = "这里存在着不明来源且大量的高纯度金矿，根据仪器检测，这里原本是一片郊区";
Tecoskia1111.localizedName = "金石幽谷";
Events.on(ContentInitEvent, (e) => {
    lib.addToResearch(Tecoskia1111, {
        parent: '对峙狭廊',
        objectives: Seq.with(
            new Objectives.SectorComplete(Tecoskia111),
        )
    });
});
exports.Tecoskia1111 = Tecoskia1111;

const Tecoskia11111 = new SectorPreset("落日要塞", 帝科斯基, 153);
Tecoskia11111.alwaysUnlocked = false;
Tecoskia11111.difficulty = 1;
Tecoskia11111.description = "这里的敌人利用能源制热，并排入这个要塞的基部，形成了人造岩浆湖，但这些热液并没有降温迹象，并且一般情况下，过多能量注入会使水沸腾，令人疑惑";
Tecoskia11111.localizedName = "落日要塞";
Events.on(ContentInitEvent, (e) => {
    lib.addToResearch(Tecoskia11111, {
        parent: '金石幽谷',
        objectives: Seq.with(
            new Objectives.SectorComplete(Tecoskia1111),
        )
    });
});
exports.Tecoskia11111 = Tecoskia11111;

const Tecoskia111111 = new SectorPreset("熔岩岸堤", 帝科斯基, 152);
Tecoskia111111.alwaysUnlocked = false;
Tecoskia111111.difficulty = 2;
Tecoskia111111.description = "防御极弱，不要在这里过多停留";
Tecoskia111111.localizedName = "熔岩岸堤";
Events.on(ContentInitEvent, (e) => {
    lib.addToResearch(Tecoskia111111, {
        parent: '落日要塞',
        objectives: Seq.with(
            new Objectives.SectorComplete(Tecoskia11111),
        )
    });
});
exports.Tecoskia111111 = Tecoskia111111;
//=======================死命树

const Tecoskia11112 = new SectorPreset("卫星前哨", 死命, 1);
Tecoskia11112.alwaysUnlocked = false;
Tecoskia11112.difficulty = 2;
Tecoskia11112.description = "这里是敌方的一个控制中心，这里他们还有一个较为原始的计算机，不过小心，他们有点难对付";
Tecoskia11112.localizedName = "卫星前哨";
Events.on(ContentInitEvent, (e) => {
    lib.addToResearch(Tecoskia11112, {
        parent: '金石幽谷',
        objectives: Seq.with(
            new Objectives.SectorComplete(Tecoskia1111),
        )
    });
});
exports.Tecoskia11112 = Tecoskia11112;