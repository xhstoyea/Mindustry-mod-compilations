//此代码来自无限宇宙
/*
待研究
        gier = makeAsteroid("gier", erekir, Blocks.ferricStoneWall, Blocks.carbonWall, -5, 0.4f, 7, 1f, gen -> {
            gen.min = 25;
            gen.max = 35;
            gen.carbonChance = 0.6f;
            gen.iceChance = 0f;
            gen.berylChance = 0.1f;
        });
*/
const lib = require("lib");
const {一阶废料核心} = require('分类/核心');
const {德克科} = require('行卫星/德克科');
const 帝科斯基 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new MultiMesh(
            new NoiseMesh(帝科斯基, 5, 6, Color.valueOf("#363636"),1.8, 6, 1, 0.1, 4),
            new NoiseMesh(帝科斯基, 1, 7, Color.valueOf("#e05438"),2.2, 6, 1, 0.2, 1)
    )); //网格密度？
/*
NoiseMesh(Planet planet, int seed, int divisions, Color color, float radius, int octaves, float persistence, float scale, float mag)
行星，种子，精细度(网格细分次数)，颜色，半径，噪声层数，噪声衰减系数，缩放(噪声缩放)，幅值(强度、幅度)
*/
        this.super$load();
    }//行星构建
}, "帝科斯基", 德克科, 2.5);//名字: ,母星: ,大小: (单位塞普罗)

帝科斯基.cloudMeshLoader = prov(() => new MultiMesh(
    new HexSkyMesh(帝科斯基, 2, 0.15, 0.14, 5, Color.valueOf("7E493380"), 2, 1, 1, 0.43),//种子，旋转速度，半径，精细度，颜色，噪声层数，噪声衰减，缩放比例，筛选
	new HexSkyMesh(帝科斯基, 3, 0.6, 0.15, 5, Color.valueOf("E3A876FF"), 2, 1, 1.2, 0.45)
));

const sS = require("sectorSize");
sS.planetGrid(帝科斯基, 3);//行星网格数量10*3^n+2

帝科斯基.generator = extend(SerpuloPlanetGenerator,{
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgYmBiYWDJS8xNZWB7tmDH0/3NDOzFJamJuZkpDFzFyRmpuYklmcnFDNwpqcXJRZkFJZn5eQwMDGw5iUmpOcUMTNGxjAzyT3fNfzpn/vPlE591Neg+2dHwcsY2oNCzaTOhJjIwMDJAAADBmCrd");
	},
	allowLanding (sector) {
		return false
	},
});

帝科斯基.allowCampaignRules = true;//可使用规则
帝科斯基.atmosphereColor = 帝科斯基.lightColor = Color.valueOf("363636b0");
帝科斯基.landCloudColor = Color.valueOf("fbd891");//云层颜色
帝科斯基.atmosphereRadIn = 0;//大气层内半径
帝科斯基.atmosphereRadOut = 0.4;//星球大气层外半径
帝科斯基.hasAtmosphere = true;//自身可看见大气层
帝科斯基.lightSrcTo = 0.5;//区块光照变化
帝科斯基.lightDstFrom = 0.75;//大气层
帝科斯基.localizedName = "帝科斯基";//行星名
帝科斯基.visible = true;//星球是否可见
帝科斯基.bloom = false;//光源（？）
帝科斯基.updateLighting = true;//区块的昼夜交替
帝科斯基.accessible = true;//星球是否可以到达
帝科斯基.launchCapacityMultiplier = 0.5;//发射核心时最大可携带的资源量,“1”为发射的核心的100%容量,0.5为50%
帝科斯基.allowLaunchSchematics = true;//开启发射核心蓝图
帝科斯基.description = "一个陨落的前文明星球,但尚存敌军,似乎可以在这里发展文明";//星球介绍
帝科斯基.allowSectorInvasion = false;//模拟攻击图入侵
帝科斯基.allowWaveSimulation = true;//模拟后台波次
帝科斯基.alwaysUnlocked = true;//默认解锁
帝科斯基.clearSectorOnLose = false;//不知道什么玩意,关了吧
帝科斯基.allowLaunchLoadout = true;//允许带资源发射核心
帝科斯基.startSector = 273;//星球起始公转方向(相对于太阳,1~360随便填)
帝科斯基.orbitRadius = 110;//星球轨道半径
帝科斯基.tidalLock = false//星球潮汐锁定
帝科斯基.iconColor = Color.valueOf("#363636");//图标颜色
帝科斯基.rotateTime = 476;//星球自转一周的时间
帝科斯基.defaultCore = 一阶废料核心;//默认发射核心

exports.帝科斯基 = 帝科斯基

// map1相关代码整合
