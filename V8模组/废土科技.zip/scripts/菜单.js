//参考:合晶工业
Events.on(EventType.ClientLoadEvent, cons(e => {
	var dialog = new BaseDialog("[#E3A876FF]废土科技");//新建一个显示窗口
			var dialog = new BaseDialog("废土科技");
			dialog.cont.pane(table => {
			table.add("关于本mod\n\nmod暂不公开请勿传播,本mod拥有部分故事背景,以出现\n灾难的星球帝科斯基为背景,数个围绕灾难的主线地图将由你探\n索\n\n[red]本mod可能会出现大量重复色系的高饱和度颜色,易引起审\n美疲劳\n[#ffffffff]可以向QQ号[#0000ffff]3958138991[#ffffffff]提出建议,申请好友请备注“建\n议”")
			table.row();
		})
	dialog.buttons.button("关闭", run(() => {
	dialog.hide()//退出此界面
	})).size(110, 64);//按钮用原版@close
	//贴图size（长,宽）
	dialog.buttons.button("[red]注意事项", run(() => {
		var dialog2 = new BaseDialog('注意事项');
		dialog2.cont.pane(table => {
			table.add("1.由于版本更新因素可能导致多配方工厂致使您的游戏卡一下，但不要担心，至少可以用（作者不会写java，见谅\n\n2.由于未知原因带资源默认会带铅和铜,发射核心时需要点击核心图标以恢复正常\n\n3.目前因为技术原因无法制作本星球的数字区块生成\n\n[red]4.极少数人可能会在游玩本mod时，因mod中的闪光或图形出\n现癫痫症状，即便没有癫痫病史也可能出现类似状况。这些症状\n包含眼睛疼痛、视觉异常、偏头痛、痉挛、意识障碍（如昏迷）\n等。若游玩过程中出现上述症状，请立即停止游戏并就医。若您\n或亲属有癫痫病史，游玩前建议咨询医生。同时，可通过坐远屏\n幕、使用小屏幕设备、保持环境明亮、避免疲劳时游戏等方式降\n低风险"/*区块旁的数字区块十分庞大,发射核心至数字区块时,需在进入区块加载页面时大退,重新打开游戏并重新进入区块并等待\n[red]请勿在获得建筑“资源转化器”与“资源发射器”前进入数字区块,并且进入数字区块前必须带超过1k的黄铜、铁、废料,否则无法正常游玩本mod星球的数字区块*/)
		})
		dialog2.buttons.defaults().size(210, 64);
		dialog2.addCloseButton();
		dialog2.show();
	})).size(110, 64);
		dialog.buttons.button("制作人员", run(() => {
		var dialog3 = new BaseDialog('制作人员');
		dialog3.cont.pane(table => {
		table.add("贴图：UPTEN-C814&AL-1S天童爱丽丝\n地图：UPTEN-C814&AL-1S天童爱丽丝\n音乐：来自Re-Logic/Jeff的lunch\n来自bilibili的\"11与27\"menu\n目前原作者不明确的game1~3\n对于音乐我不用做商用，希望原作者见谅\n如有冒犯，会立即删除")
		})
		dialog3.buttons.defaults().size(210, 64);
		dialog3.addCloseButton();
		dialog3.show();
	})).size(110, 64);
        dialog.show();
}))
/*结构
1（2，3（4））
*/