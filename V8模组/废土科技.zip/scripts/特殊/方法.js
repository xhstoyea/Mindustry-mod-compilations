function Team(int id, String name, Color color, Color pal1, Color pal2, Color pal3){
        this(id, name, color);

        setPalette(pal1, pal2, pal3);
        this.color.set(color);
    }