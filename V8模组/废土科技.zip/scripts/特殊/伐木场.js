function LcCrafterBuild() {
	
}