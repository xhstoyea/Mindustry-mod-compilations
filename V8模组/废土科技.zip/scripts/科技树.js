const {一阶废料核心} = require('分类/核心');
const lib = require("lib");
const {帝科斯基} = require('行卫星/帝科斯基');
const {死命} = require('行卫星/死命');
帝科斯基.techTree = TechTree.nodeRoot( "废土科技", 一阶废料核心, true, run(() => {}));
死命.techTree = 帝科斯基.techTree
帝科斯基.techTree.addPlanet(帝科斯基);
死命.techTree.addPlanet(死命);

			