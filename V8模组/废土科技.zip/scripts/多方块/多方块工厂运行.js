require("多方块/机床FTKJ")
require("多方块/电弧炉FTKJ")