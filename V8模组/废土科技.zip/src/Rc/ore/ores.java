package Rc.ore;

import mindustry.*;
import mindustry.world.*;
import mindustry.world.blocks.*;
import mindustry.world.blocks.environment.*;

oreLead = new OreBlock