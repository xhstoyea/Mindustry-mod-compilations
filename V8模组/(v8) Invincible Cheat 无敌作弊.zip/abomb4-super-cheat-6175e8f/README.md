# 无敌作弊 Invincible Cheat Mod
不做人的 Mindustry 作弊 Mod，滥用会影响游戏体验。

Inhumane Mindustry cheating mod, abuse will affect the game experience.

<hr />

This is a cheat mod, abuse will reduce your game experience, be careful for using this.

GitHub: https://github.com/abomb4/super-cheat

email:  abomb4@163.com

Wellcome to feedback!

Features:
- Adjustable Overdrive Projector (speedup, or slow down)
- Invincible Core and Invincible build plane
- Cheat Items (power source, liquid source, item source with 36x faster)
- Invincible Wall, Invincible Force Projector
- Several strange force projectors
- Chronosphere Unloader and Pusher
- Unit Factory
- DPS Tester Unit
- Team Changer

这是个作弊 mod，会降低游戏体验，请谨慎使用。
主要特性：
- 可调整的超速投影（更快，也可以更慢）
- 无敌核心，无敌建造机
- 作弊物品（电源、水源、物品源超快版）
- 无敌围墙，无敌力场
- 一大堆神奇力场
- 时空提取器、时空推送器
- 单位工厂
- DPS 测试单位
- 队伍更换器

Это читерный мод, злоупотребление испортит интерес к игре, острожней с этим.
Возможности:
- Настраиваемый сверхприводный проектор (ускорение или замедление)
- Блоки, меняющие команду, за которую играют те или иные единицы (или вы сами)
- Измеритель урона в секунду
- Непобедимое ядро и его строительная боевая единица
- Cheat Items (power source, liquid source, item source with 36x faster)
- Неразрушаемые стены, силовой проектор с бесконечной прочностью
- Несколько полезных проекторов
- Дистанционный загрузчик и разгрузчик
- Универсальный завод боевых единиц, также может производить их для врагов