//---------------------@滞人编写
const lib = require('lib');
//电镀微晶导管防自然
const GC = require('Blocks/Blocks-ChuanShu');
GC.jizhuangxieqi3.buildType = prov(() => {
    var ts = 1;
    var td = 0;
    return new JavaAdapter(Unloader.UnloaderBuild, {
        delta(){
            return Time.delta * ts;
        },
        applyBoost(intensity, duration){
            if(intensity >= ts){
                td = Math.max(td, duration);
            }
            ts = Math.max(ts, intensity);
        },
        updateTile(){
            if(td > 0){
                td -= Time.delta;
                if(td <= 0){
                    ts = 1;
                }
            }
            this.timeScale = Math.max(ts * this.power.status, 0.001);
            this.timeScaleDuration = td / Math.max(this.power.status, 0.001);
            if(this.power.status >= 0.001){
                this.super$updateTile();
            }
        },
    }, GC.jizhuangxieqi3);
});