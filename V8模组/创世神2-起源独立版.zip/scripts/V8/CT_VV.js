require('V8/fanjiasu');
require('V8/fanjiasu2');
const lib = require('V8/lib')
require('V8/zhiliaoyi');
require('V8/jianshangyi');
require('V8/geshangyi');
require('V8/fanghuyi');
xinxiban =
    (() => {
        //信息版
        var a = new MessageBlock, 'xinxiban', {
            isPlaceable() { return lib.techDsAvailable() && this.super$isPlaceable(); },//非沙盒禁止建造
            canBreak(tile) { return false; },
        });
        maxNewlines = 24
        maxTextLength = 114514
        targetable = false;
        update = false;
        solid = false;
        requirements = ItemStack.with(        );
        alwaysUnlocked = true;
        health = 1;
        size = 2;
        buildVisibility = BuildVisibility.sandboxOnly;//仅沙盒
        category = Category.logic;
        buildType = prov(() => new JavaAdapter(MessageBlock.MessageBuild, {
            collide(other) { return false },
            damage(damage) { },
            handleDamage(tile, amount) { return 0; },
        }, a))