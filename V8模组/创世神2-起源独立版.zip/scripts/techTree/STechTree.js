var node = TechTree.node;
var nodeProduce = TechTree.nodeProduce;
const {
    //crafting
    siliconSmelter, siliconCrucible, kiln, graphitePress, plastaniumCompressor, multiPress, phaseWeaver, surgeSmelter, pyratiteMixer, blastMixer, cryofluidMixer,
    melter, separator, disassembler, sporePress, pulverizer, incinerator, coalCentrifuge,


 illuminator, 

    //defense
    copperWall, copperWallLarge, titaniumWall, titaniumWallLarge, plastaniumWall, plastaniumWallLarge, thoriumWall, thoriumWallLarge, door, doorLarge,
    phaseWall, phaseWallLarge, surgeWall, surgeWallLarge,

  

    mender, mendProjector, overdriveProjector, overdriveDome, forceProjector, shockMine,
    scrapWall, scrapWallLarge, scrapWallHuge, scrapWallGigantic, 


    //transport
    conveyor, titaniumConveyor, plastaniumConveyor, armoredConveyor, distributor, junction, itemBridge, phaseConveyor, sorter, invertedSorter, router,
    overflowGate, underflowGate, massDriver,


    //liquid
    mechanicalPump, rotaryPump, impulsePump, conduit, pulseConduit, platedConduit, liquidRouter, liquidContainer, liquidTank, liquidJunction, bridgeConduit, phaseConduit,


    //power
    combustionGenerator, thermalGenerator, steamGenerator, differentialGenerator, rtgGenerator, solarPanel, largeSolarPanel, thoriumReactor,
    impactReactor, battery, batteryLarge, powerNode, powerNodeLarge, surgeTower, diode,



    //production
    mechanicalDrill, pneumaticDrill, laserDrill, blastDrill, waterExtractor, oilExtractor, cultivator,
  

    //storage
    coreShard, coreFoundation, coreNucleus, vault, container, unloader,


    //turrets
    duo, scatter, scorch, hail, arc, wave, lancer, swarmer, salvo, fuse, ripple, cyclone, foreshadow, spectre, meltdown, segment, parallax, tsunami,

 

    //units
    groundFactory, airFactory, navalFactory,
    additiveReconstructor, multiplicativeReconstructor, exponentialReconstructor, tetrativeReconstructor,
    repairPoint, repairTurret,



    //payloads
    payloadConveyor, payloadRouter,

    //logic
    message, switchBlock, microProcessor, logicProcessor, hyperProcessor, largeLogicDisplay, logicDisplay, memoryCell, memoryBank,
    //campaign
    launchPad 
} = Blocks



const {
    mace, dagger, crawler, fortress, scepter, reign, vela,
    nova, pulsar, quasar, corvus, atrax,
    spiroct, arkyid, toxopid,

    flare, eclipse, horizon, zenith, antumbra, //空军
    mono, poly, mega, quad, oct, //空辅
    risso, minke, bryde, sei, omura, //海军
    retusa, oxynoe, cyerce, aegires, navanax//海辅
} = UnitTypes

const{    groundZero
    , saltFlats
    , frozenForest
    , biomassFacility
    , craters
    , ruinousShores
    , windsweptIslands
    , stainedMountains
    , extractionOutpost
    , coastline
    , navalFortress
    , fungalPass
    , overgrowth
    , tarFields
    , impact0078
    , desolateRift
    , nuclearComplex
    , planetaryTerminal,}= require('techTree/maps');

    node(coreShard, () => {

        node(conveyor, () => {
    
            node(junction, () => {
                node(router, () => {
                      node(distributor);
                    node(sorter, () => {
                        node(invertedSorter);
                        node(overflowGate, () => {
                            node(underflowGate);
                        });
                    });
                    node(container, Seq.with(new Objectives.SectorComplete(biomassFacility)), () => {
                        node(unloader);
                        node(vault, Seq.with(new Objectives.SectorComplete(stainedMountains)), () => {
    
                        });
                    });
    
                    node(itemBridge, () => {
                        node(titaniumConveyor, Seq.with(new Objectives.SectorComplete(craters)), () => {
                            node(phaseConveyor, () => {
                                node(massDriver, () => {
    
                                });
                            });
    
                            node(payloadConveyor, () => {
                                node(payloadRouter, () => {
    
                                });
                            });
    
                            node(armoredConveyor, () => {
                                node(plastaniumConveyor, () => {
    
                                });
                            });
                        });
                    });
                });
            });
        });
    
        node(coreFoundation, () => {
            node(coreNucleus, () => {
    
            });
        });
    
        node(mechanicalDrill, () => {
    
            node(mechanicalPump, () => {
                node(conduit, () => {
                    node(liquidJunction, () => {
                        node(liquidRouter, () => {
                            node(liquidContainer, () => {
                                node(liquidTank);
                            });
    
                            node(bridgeConduit);
    
                            node(pulseConduit, Seq.with(new Objectives.SectorComplete(windsweptIslands)), () => {
                                node(phaseConduit, () => {
    
                                });
    
                                node(platedConduit, () => {
    
                                });
    
                                node(rotaryPump, () => {
                                    node(impulsePump, () => {
    
                                    });
                                });
                            });
                        });
                    });
                });
            });
    
            node(graphitePress, () => {
                node(pneumaticDrill, Seq.with(new Objectives.SectorComplete(frozenForest)), () => {
                    node(cultivator, Seq.with(new Objectives.SectorComplete(biomassFacility)), () => {
    
                    });
    
                    node(laserDrill, () => {
                        node(blastDrill, Seq.with(new Objectives.SectorComplete(nuclearComplex)), () => {
    
                        });
    
                        node(waterExtractor, Seq.with(new Objectives.SectorComplete(saltFlats)), () => {
                            node(oilExtractor, () => {
    
                            });
                        });
                    });
                });
    
                node(pyratiteMixer, () => {
                    node(blastMixer,  () => {
    
                    });
                });
    
                node(siliconSmelter, () => {
    
                    node(sporePress, () => {
                        node(coalCentrifuge, () => {
                            node(multiPress, () => {
                                node(siliconCrucible, () => {
    
                                });
                            });
                        });
    
                        node(plastaniumCompressor, Seq.with(new Objectives.SectorComplete(windsweptIslands)), () => {
                            node(phaseWeaver, Seq.with(new Objectives.SectorComplete(tarFields)), () => {
    
                            });
                        });
                    });
    
                    node(kiln, Seq.with(new Objectives.SectorComplete(craters)), () => {
                        node(pulverizer, () => {
                            node(incinerator, () => {
                                node(melter, () => {
                                    node(surgeSmelter, () => {
    
                                    });
    
                                    node(separator, () => {
                                        node(disassembler, () => {
    
                                        });
                                    });
    
                                    node(cryofluidMixer, () => {
    
                                    });
                                });
                            });
                        });
                    });
    
                    //logic disabled until further notice
                    node(microProcessor, () => {
                        node(switchBlock, () => {
                            node(message, () => {
                                node(logicDisplay, () => {
                                    node(largeLogicDisplay, () => {
    
                                    });
                                });
    
                                node(memoryCell, () => {
                                    node(memoryBank, () => {
    
                                    });
                                });
                            });
    
                            node(logicProcessor, () => {
                                node(hyperProcessor, () => {
    
                                });
                            });
                        });
                    });
    
                    node(illuminator, () => {
    
                    });
                });
            });
    
    
            node(combustionGenerator, Seq.with(new Objectives.Research(Items.coal)), () => {
                node(powerNode, () => {
                    node(powerNodeLarge, () => {
                        node(diode, () => {
                            node(surgeTower, () => {
    
                            });
                        });
                    });
    
                    node(battery, () => {
                        node(batteryLarge, () => {
    
                        });
                    });
    
                    node(mender, () => {
                        node(mendProjector, () => {
                            node(forceProjector, Seq.with(new Objectives.SectorComplete(impact0078)), () => {
                                node(overdriveProjector, Seq.with(new Objectives.SectorComplete(impact0078)), () => {
                                    node(overdriveDome, Seq.with(new Objectives.SectorComplete(impact0078)), () => {
    
                                    });
                                });
                            });
    
                            node(repairPoint, () => {
                                node(repairTurret, () => {
    
                                });
                            });
                        });
                    });
    
                    node(steamGenerator, Seq.with(new Objectives.SectorComplete(craters)), () => {
                        node(thermalGenerator, () => {
                            node(differentialGenerator, () => {
                                node(thoriumReactor, Seq.with(new Objectives.Research(Liquids.cryofluid)), () => {
                                    node(impactReactor, () => {
    
                                    });
    
                                    node(rtgGenerator, () => {
    
                                    });
                                });
                            });
                        });
                    });
    
                    node(solarPanel, () => {
                        node(largeSolarPanel, () => {
    
                        });
                    });
                });
            });
        });
    
        node(duo, () => {
            node(copperWall, () => {
                node(copperWallLarge, () => {
                    node(scrapWall, () => {
                        node(scrapWallLarge, () => {
                            node(scrapWallHuge, () => {
                                node(scrapWallGigantic);
                            });
                        });
                    });
    
                    node(titaniumWall, () => {
                        node(titaniumWallLarge);
    
                        node(door, () => {
                            node(doorLarge);
                        });
    
                        node(plastaniumWall, () => {
                            node(plastaniumWallLarge, () => {
    
                            });
                        });
                        node(thoriumWall, () => {
                            node(thoriumWallLarge);
                            node(surgeWall, () => {
                                node(surgeWallLarge);
                                node(phaseWall, () => {
                                    node(phaseWallLarge);
                                });
                            });
                        });
                    });
                });
            });
    
            node(scatter, () => {
                node(hail, Seq.with(new Objectives.SectorComplete(craters)), () => {
                    node(salvo, () => {
                        node(swarmer, () => {
                            node(cyclone, () => {
                                node(spectre, Seq.with(new Objectives.SectorComplete(nuclearComplex)), () => {
    
                                });
                            });
                        });
    
                        node(ripple, () => {
                            node(fuse, () => {
    
                            });
                        });
                    });
                });
            });
    
            node(scorch, () => {
                node(arc, () => {
                    node(wave, () => {
                        node(parallax, () => {
                            node(segment, () => {
    
                            });
                        });
    
                        node(tsunami, () => {
    
                        });
                    });
    
                    node(lancer, () => {
                        node(meltdown, () => {
                            node(foreshadow, () => {
    
                            });
                        });
    
                        node(shockMine, () => {
    
                        });
                    });
                });
            });
        });
    
        node(groundFactory, () => {
    
            node(dagger, () => {
                node(mace, () => {
                    node(fortress, () => {
                        node(scepter, () => {
                            node(reign, () => {
    
                            });
                        });
                    });
                });
    
                node(nova, () => {
                    node(pulsar, () => {
                        node(quasar, () => {
                            node(vela, () => {
                                node(corvus, () => {
    
                                });
                            });
                        });
                    });
                });
    
                //override research requirements to have graphite, not coal
                node(crawler, ItemStack.with(Items.silicon, 400, Items.graphite, 400), () => {
                    node(atrax, () => {
                        node(spiroct, () => {
                            node(arkyid, () => {
                                node(toxopid,() => {
    
                                });
                            });
                        });
                    });
                });
            });
    
            node(airFactory, () => {
                node(flare, () => {
                    node(horizon, () => {
                        node(zenith, () => {
                            node(antumbra, () => {
                                node(eclipse, () => {
    
                                });
                            });
                        });
                    });
    
                    node(mono, () => {
                        node(poly, () => {
                            node(mega, () => {
                                node(quad, () => {
                                    node(oct, () => {
    
                                    });
                                });
                            });
                        });
                    });
                });
    
                node(navalFactory,  () => {
                    node(risso, () => {
                        node(minke, () => {
                            node(bryde, () => {
                                node(sei, () => {
                                    node(omura, () => {
    
                                    });
                                });
                            });
                        });
    
                        node(retusa, Seq.with(new Objectives.SectorComplete(windsweptIslands)), () => {
                            node(oxynoe, Seq.with(new Objectives.SectorComplete(coastline)), () => {
                                node(cyerce, () => {
                                    node(aegires, () => {
                                        node(navanax, Seq.with(new Objectives.SectorComplete(navalFortress)), () => {
    
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
    
            node(additiveReconstructor, Seq.with(new Objectives.SectorComplete(biomassFacility)), () => {
                node(multiplicativeReconstructor, Seq.with(new Objectives.SectorComplete(overgrowth)), () => {
                    node(exponentialReconstructor, () => {
                        node(tetrativeReconstructor, () => {
    
                        });
                    });
                });
            });
        });   
        nodeProduce(Items.copper, () => {
            nodeProduce(Liquids.water, () => {
    
            });
    
            nodeProduce(Items.lead, () => {
                nodeProduce(Items.titanium, () => {
                    nodeProduce(Liquids.cryofluid, () => {
    
                    });
    
                    nodeProduce(Items.thorium, () => {
                        nodeProduce(Items.surgeAlloy, () => {
    
                        });
    
                        nodeProduce(Items.phaseFabric, () => {
    
                        });
                    });
                });
    
                nodeProduce(Items.metaglass, () => {
    
                });
            });
    
            nodeProduce(Items.sand, () => {
                nodeProduce(Items.scrap, () => {
                    nodeProduce(Liquids.slag, () => {
    
                    });
                });
    
                nodeProduce(Items.coal, () => {
                    nodeProduce(Items.graphite, () => {
                        nodeProduce(Items.silicon, () => {
    
                        });
                    });
    
                    nodeProduce(Items.pyratite, () => {
                        nodeProduce(Items.blastCompound, () => {
    
                        });
                    });
    
                    nodeProduce(Items.sporePod, () => {
    
                    });
    
                    nodeProduce(Liquids.oil, () => {
                        nodeProduce(Items.plastanium, () => {
    
                        });
                    });
                });
            });
        });
    });  