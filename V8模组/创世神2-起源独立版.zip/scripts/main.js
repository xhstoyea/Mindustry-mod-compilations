if(Vars.mods.locateMod("coreunloader-mod") ==null){
if(Vars.mods.locateMod("ctcoresystem")!=null){
//Java核心系统  //
function CreatorsPackage(name) {
	var p = Packages.rhino.NativeJavaPackage(name, Vars.mods.mainLoader());
	Packages.rhino.ScriptRuntime.setObjectProtoAndParent(p, Vars.mods.scripts.scope)
	return p
}
var CreatorsJavaPack = CreatorsPackage('creators')
importPackage(CreatorsJavaPack)
importPackage(CreatorsJavaPack.draw)
importPackage(CreatorsJavaPack.type)
importPackage(CreatorsJavaPack.world.block)

//require('BlocksLibes/wanxiangqiao');
CT2ModJS.RunName.add("creators")
CT2ModJS.DawnRun.add(run(() => {
//***********************************/1
require('V8/DC');//炮台
//require('BlocksLibes/Build');//微晶导管桥防自然
require('V8/units');//单位
//const BS = require('invincible');//沙盒测试相关方块
require('invincible')
require('next-wave');//跳波器
require('BlocksLibes/xuwu');//服务器禁虚无
require('xingqiu')
require('techTree');//科技树
require('V8/FenNei');//分类


//require('techTree/maps2');//挑战科技树  
//const {} = require('units/medal');//金牌银牌
//require('ui');//更新，首页按钮等


}));

}
}
Events.on(EventType.ClientLoadEvent, cons(e => {
    Vars.content.block("creators-large-payload-mass-driver").capOutlineRegion = Vars.content.block("large-payload-mass-driver").capOutlineRegion;
    Vars.content.block("creators-large-payload-mass-driver").leftOutlineRegion = Vars.content.block("large-payload-mass-driver").leftOutlineRegion;
    Vars.content.block("creators-large-payload-mass-driver").rightOutlineRegion = Vars.content.block("large-payload-mass-driver").rightOutlineRegion;
}));


