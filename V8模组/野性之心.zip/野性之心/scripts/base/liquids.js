exports.孢子毒素 = new CellLiquid('孢子毒素');
exports.精油 = new Liquid('精油');
//exports.json液体名字 = new Item('json液体名字');