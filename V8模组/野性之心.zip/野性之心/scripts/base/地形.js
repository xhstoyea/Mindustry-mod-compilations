exports.丛林草 = extend(Floor, "1-丛林草", {
    mapColor: Color.valueOf("679C39FF")});
exports.丛林浅水 = extend(Floor, "丛林浅水", {
    mapColor: Color.valueOf("6BAAB7FF")});
exports.丛林深水 = extend(Floor, "丛林深水", {
    mapColor: Color.valueOf("4D95A3FF")});
exports.泥沙 = extend(Floor, "泥沙", {
    mapColor: Color.valueOf("585050FF")});