let 寄生 = extend(StatusEffect, "寄生", {
	death(u) {
		单位.spawn(u.team == Team.crux ? Team.sharded : Team.crux, unitX, unitY);
	}
});
let trigger = Seq.with(寄生);

Events.on(UnitDestroyEvent, e => {
	let u = e.unit, bits = u.statusBits();
	if (bits.isEmpty()) return;
	trigger.each(s => bits.get(s.id), s => s.death(u));
});