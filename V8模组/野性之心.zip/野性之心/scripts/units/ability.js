const lib = require("base/lib");

exports.RotatorAbility = (name, x, y, speed, size, mirror) => { //螺旋桨
	return extend(Ability, {
		display: false,
		draw(unit) {
			let rot = unit.rotation - 90;
			let xy = lib.AngleTrns(rot, x, y);
			let xy2 = lib.AngleTrns(rot, -x, y);
			let Speed = Time.time * speed * 6;
			let ux = unit.x + xy.x, uy = unit.y + xy.y;
			let nx = unit.x + xy2.x, ny = unit.y + xy2.y;
			Draw.rect(unit.type.name + "-" + name, ux, uy, size, size, Speed);
			if (mirror) Draw.rect(unit.type.name + "-" + name, nx, ny, size, size, -Speed);
		}
	})
};