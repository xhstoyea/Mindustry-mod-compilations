let 平台 = new UnitCargoLoader("辅助无人机平台");
平台.MAXBlock = 1;