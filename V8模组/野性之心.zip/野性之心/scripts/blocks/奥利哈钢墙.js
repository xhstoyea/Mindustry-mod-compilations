let 墙 = new Wall("f奥利哈钢墙");
墙.buildType = prov(() => extend(Wall.WallBuild, 墙, {
	handleDamage(amount) {
		amount = Math.min(amount * 10, amount + this.block.armor);
		if (amount > 50) return 50;
		return Damage.applyArmor(amount, this.block.armor);
	}
})
);