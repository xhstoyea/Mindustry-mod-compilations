Attribute.add("grass");
require("base/地形");
require("blocks/attribute");
require("planets/Plantera");
require("planets/tree");
require("units/units");
require("units/渐变霓虹");
require("base/items");
require("base/liquids");
require("blocks/力墙限制器");
require("blocks/先遣核心");
require("开屏菜单");
//require("缩放强化");
require("blocks/武装铁墙");
require("blocks/奥利哈钢墙");
/*const xxx = extendContent(Item,"铁矿石",{})//在其他js里创建的物品,调用方法见栗子*/
/*const xxx = extendContent(Item,"炮弹",{})*/
//require("blocks/万能弹头工厂");