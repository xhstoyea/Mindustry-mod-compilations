const lib = require("lib");
const Aplanets = new Planet("深渊", Planets.sun, 1, 3.3);
Aplanets.meshLoader = prov(() => new MultiMesh(new HexMesh(Aplanets, 8)));
Aplanets.generator = extend(SerpuloPlanetGenerator, {
    getDefaultLoadout() {
        return Schematics.readBase64("bXNjaAF4nA3JMQ6AIBAAwQXFRr9i4XuMBR5XkCAYkP9LphwcbmLO/lHMwRq0SY3vF0sGluRvTQ17XoZNStU9d0na20gDduAHAc0Org==")
    }
});
Aplanets.cloudMeshLoader = prov(() => new MultiMesh(new HexSkyMesh(Aplanets, 2, 0.15, 0.14, 5, Color.valueOf("0A095B00"), 2, 0.42, 1, 0.43), new HexSkyMesh(Aplanets, 3, 0.6, 0.15, 5, Color.valueOf("0A095B00"), 2, 0.42, 1.2, 0.45)));
Aplanets.generator = new SerpuloPlanetGenerator();
Aplanets.localizedName = "深渊";
Aplanets.visible = Aplanets.accessible = Aplanets.alwaysUnlocked = true;
Aplanets.clearSectorOnLose = false;
Aplanets.tidalLock = false;
Aplanets.prebuildBase = false;
Aplanets.bloom = false;
Aplanets.startSector = 1;
Aplanets.orbitRadius = 85;
Aplanets.orbitTime = 180 * 60;
Aplanets.rotateTime = 90 * 60;
Aplanets.atmosphereRadIn = 0.02;
Aplanets.atmosphereRadOut = 0.3;
Aplanets.atmosphereColor = Aplanets.lightColor = Color.valueOf("0A095B00");
Aplanets.iconColor = Color.valueOf("FFFFFF00");

const AAA = new SectorPreset("赤焰山脉", Aplanets, 1);
AAA.description = "北半球R12边界，这里防御稀少，是进攻的绝佳地点";
AAA.localizedName = "赤焰山脉";
AAA.difficulty = 2;
AAA.alwaysUnlocked = false;
AAA.addStartingItems = true;
AAA.captureWave = 0;
exports.AAA = AAA;
lib.addToResearch(AAA, {
    parent: "Planetary-Launch-Terminal", 
    objectives: Seq.with(new Objectives.SectorComplete(SectorPresets.planetaryTerminal)),
});
