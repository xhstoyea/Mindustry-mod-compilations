let amount = 0, ergodic = false;

const 单位站 = extend(Block,"单位站",{
    canPlaceOn(tile,team,rotation){
	    if(amount < 4)return true
	},
	beforePlaceBegan(tile,previous){
	    this.super$beforePlaceBegan(tile,previous);
	    ergodic = true
	},
	update: true,
});
单位站.buildType = prov(() => extend(Building,{
    updateTile(){
        this.super$updateTile();
        if(ergodic){
            amount = 0
            this.tile.circle(200, cons(tile => {
                if(tile.block() === 单位站) amount ++
            }))
            ergodic = false
        }
    }
}))