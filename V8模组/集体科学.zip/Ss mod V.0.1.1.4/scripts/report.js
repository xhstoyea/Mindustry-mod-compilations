Events.on(EventType.ClientLoadEvent, cons(e => {
	const dialog = new BaseDialog(Core.bundle.get("report"));

	dialog.buttons.button(Core.bundle.get("union"), run(() => {
		dialog.hide();
	})).size(210, 64);
	
	dialog.cont.pane(table => {
		table.image(Core.atlas.find("cccp-镰刀锤子")).size(128,128).pad(3).row();
		
		table.add(Core.bundle.get("report.sub")).left().growX().wrap().width(420).maxWidth(420).pad(4).labelAlign(Align.left).row();
	})
	dialog.show()
}))