const nodeRoot = TechTree.nodeRoot;
const nodeProduce = TechTree.nodeProduce
const node = TechTree.node;
const SectorComplete = Objectives.SectorComplete;
const Research = Objectives.Research;

const coloz = new Planet("coloz", Planets.sun, 1, 3);
exports.coloz = coloz
Object.assign(coloz,{
    generator: extend(SerpuloPlanetGenerator,{
		getColor(position){
			return Color.valueOf("39c5bb")
		}
	}),
	meshLoader: prov(() => new HexMesh(coloz, 4)),
	cloudMeshLoader: () => new MultiMesh(
		new HexSkyMesh(coloz, 2, 0.15, 0.14, 5, Color.valueOf("66ccffbf"), 2, 0.42, 1, 0.43)
	),
    atmosphereColor: Color.valueOf("66ccff"),
	landCloudColor: Color.valueOf("66ccff"),
	atmosphereRadIn: 0,
	atmosphereRadOut: 0.2,
	camRadius: -0.25,
	visible: true,
	bloom: false,
	accessible: true,
	alwaysUnlocked: true,
	allowLaunchLoadout: true,
	allowLaunchSchematics: true,
	launchCapacityMultiplier: 0.75,
	clearSectorOnLose: true,
	startSector: 21,
	orbitRadius: 42,
	//rotateTime: 17 * 60,
	iconColor: Color.valueOf("39c5bb"),
})

const 喀纳斯林地 = new SectorPreset("喀纳斯林地",coloz,21);
Object.assign(喀纳斯林地,{
    captureWave: 6,
	difficulty: 3,
	addStartingItems: true,
	alwaysUnlocked: true,
	startWaveTimeMultiplier: 4,
})

const 塔兹穆穹顶 = new SectorPreset("塔兹穆穹顶",coloz,2);
Object.assign(塔兹穆穹顶,{
    captureWave: 15,
	difficulty: 4,
})

coloz.techTree = nodeRoot("coloz", coloz, () => {
    node(喀纳斯林地,() => {
        node(塔兹穆穹顶,Seq.with(
        SectorComplete(喀纳斯林地)
        ),() => {})
    })
})