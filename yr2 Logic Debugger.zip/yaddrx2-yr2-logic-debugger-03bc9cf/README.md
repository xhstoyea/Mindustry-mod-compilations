# yr2-logic-debugger

一个逻辑辅助工具

原作[DeltaNedas/ldb](https://github.com/deltanedas/ldb)

本项目地址https://github.com/yaddrx2/yr2-logic-debugger

yaddrx2将其升级到了137，仅供学习交流使用

联系作者yaddrx2@foxmail.com

qq2568094643

## 特性列表
此版本在[DeltaNedas](https://github.com/deltanedas)原作1.3.3版本基础上进行修改

### 逻辑码编辑板
- 代码语句的文本形式编辑
- 在指定位置从剪切板导入代码块

### 变量显示面板
- 变量更新闪烁
- 逻辑块所连方块的显示
- 建筑|单位的位置显示

### 单步调试面板
- 代码单步运行调试
- 暂停逻辑块运行
- 指定运行行数
- 设置断点

### 内存块编辑板
- 内存值更新闪烁
- 十进制编辑
- 整数二进制显示
- 整数十六进制写入

# License
All of yr2-logic-debugger is licensed under the GNU GPLv3, available in [LICENSE](/LICENSE).
