const 大型爆破油田 = extend(Wall,"大型爆破油田", {});
大型爆破油田.update = true;
大型爆破油田.buildType = prov(() => {
	const th = extend(Wall.WallBuild, 大型爆破油田, {
	updateTile(){
	var bx = this.tileX();
	var by = this.tileY();
	for(var i=-2;i<3;i++){
	    for(var I=-2;I<3;I++){
	    Vars.world.tile(bx+i, by+I).setFloor(Blocks.tar);
	    Vars.world.tile(bx+i, by+I).setAir();
	    }
        }
        Effect.shake(5, 240, this);
        this.kill;
	},
	})
	return th
});