Events.on(EventType.ClientLoadEvent, cons(e => {
	var dialog = new BaseDialog("[#9CB664FF]拂尘");
	dialog.buttons.defaults().size(210, 64);
	dialog.buttons.button("@close", run(() => {
		dialog.hide();
	})).size(210, 64);
	dialog.cont.pane((() => {
		var table = new Table();
		table.add("[#9CB664FF]欢迎来到DUST模组的妙妙屋!核邪友碍地玩耍去吧![doge] 进QQ群820233685来van").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
		table.row();
		table.button("[green]你戳一下逝逝", run(() => {
			var dialog2 = new BaseDialog("[green]其他玩意");
			var table = new Table();
			dialog2.cont.add("当前版本0.31 \n感谢绿影翼龙为mod补全Wiki百科(以及他的嘲讽) \n感谢嗷嗷怪对部分贴图的修改").row();;
			dialog2.buttons.defaults().size(210, 64);
			dialog2.buttons.button("@close", run(() => {
				dialog2.hide();
			})).size(210, 64);
			dialog2.show();
		})).size(210, 64);
		return table;
	})()).grow().center().maxWidth(620);
	dialog.show();
}));