const yszy = extend(Wall,"爆裂炸药库", {});
yszy.update = yszy.configurable = true;
yszy.buildType = prov(() => {
    const r = 40;
	const b = extend(Wall.WallBuild, yszy, {
	updateTile(){
	this.super$updateTile();
	Units.nearbyEnemies(this.team, this.x, this.y, r*2, r*2, cons(evu => {
    if(evu != null && evu.within(this.x, this.y, r)){
        this.kill();
        }
    }));
	},
	buildConfiguration(table){
		table.button(Icon.upOpen, Styles.defaulti, run(() => {
		this.kill();
		})).size(45);
	},
	})
	return b
});
yszy.envEnabled = Env.any;