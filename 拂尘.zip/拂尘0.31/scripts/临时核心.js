const 临时核心 = extend(CoreBlock, "临时核心", {
	canBreak() {
		return true;
	},
	canReplace(other) {
		return true;
	},
	canPlaceOn(tile, team) {
		return Vars.state.teams.cores(team).size < 128;
	},
	drawPlace(x, y, rotation, valid) {
		if (Vars.world.tile(x, y) == null) return;
		if (!this.canPlaceOn(Vars.world.tile(x, y), Vars.player.team(), rotation)) {
			this.drawPlaceText(Core.bundle.get("核心数量超限"), x, y, valid);
		}
	}
});
exports.临时核心 = 临时核心;