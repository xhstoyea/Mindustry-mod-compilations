const newBlock = (name, cons) => {
var b = extend(Block, name, cons);
b.solid = b.destructible = b.update = true;
b.drawDisabled = false;
b.envEnabled = Env.any;
b.group = BlockGroup.none;
b.priority = TargetPriority.base;
b.size = 2;
b.setupRequirements(
    Category.distribution,
    BuildVisibility.shown,
    ItemStack.with(Items.copper, 1)
)
b.setBuilding = cons => {
    b.BuildType = prov(() => { 
        return extend(Building,cons)
    })
};
return b;
};
var sh = newBlock(”setHealth”, {});
sh.configurable = true;
sh.setBuilding( {
    buildConfiguration(table) {
        table.button(”setHealth”, Icon.add,Styles.defaultt,
run(() =>{
this.health += 80;
})).size(120, 60);
}
})