const 爆破油田 = extend(Wall,"爆破油田", {});
爆破油田.update = true;
爆破油田.buildType = prov(() => {
	const th = extend(Wall.WallBuild, 爆破油田, {
	updateTile(){
	    Vars.world.tile(this.tileX(), this.tileY()).setFloor(Blocks.tar);
	    Vars.world.tile(this.tileX(), this.tileY()).setAir();
	    Effect.shake(5, 240, this);
        this.kill();
	},
	})
	return th
});