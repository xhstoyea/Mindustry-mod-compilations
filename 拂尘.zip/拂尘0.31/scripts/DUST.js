const lib = require("拂尘lib");
const DUST = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(DUST, 4));
        this.super$load();
    }
}, "DUST", Planets.sun, 1);
const sS = require("sectorSize");
sS.planetGrid(DUST, 2.5);
//上面的是区块大小 ▲ 正常是3.3不建议乱改
DUST.generator = new SerpuloPlanetGenerator();
//可以将[Erekir]改成任何游戏中有的星球
DUST.atmosphereColor = Color.valueOf("55ffb2");//大气颜色
DUST.atmosphereRadIn = 0.05;//？？？
DUST.atmosphereRadOut = 0.5;//密度？
DUST.clearSectorOnLose = true;
DUST.addStartingItems = true;
DUST.localizedName = "DUST";
DUST.visible = true;//能否看得见
DUST.bloom = false;//这个不确定
DUST.accessible = true;//可达到？
DUST.alwaysUnlocked = true;//始终未锁定
DUST.startSector = 0;//开始的地方数量
DUST.orbitRadius = 35;//距离太阳
DUST.rotateTime = 1200;//一昼夜的时间(s)
DUST.allowLaunchLoadout = true;
DUST.allowLaunchSchematics = true;
//----分界线----从这往下可以复制增加区块
const 错位零号 = new SectorPreset("错位零号", DUST, 0);//引号内填msav的名字
错位零号.description = "新的开始";
错位零号.difficulty = 1;//难度 1-10
错位零号.alwaysUnlocked = true;//总是解锁
错位零号.addStartingItems = true;//允许添加初始资源
错位零号.captureWave = 35;//多少波可占领
错位零号.localizedName = "错位零号";
exports.错位零号 = 错位零号;
lib.addToResearch(错位零号, {
    parent: "groundZero",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});
const 撕裂地带 = new SectorPreset("撕裂地带", DUST, 1);//引号内填msav的名字
撕裂地带.description = "行星中部一个异常的撕裂带，到底是自然造成的，还是……#SE#V##M#U###E#1#F#";
撕裂地带.difficulty = 1;//难度 1-10
撕裂地带.alwaysUnlocked = false;//总是解锁
撕裂地带.addStartingItems = true;
撕裂地带.localizedName = "撕裂地带";
exports.撕裂地带 = 撕裂地带;
lib.addToResearch(撕裂地带, {
	parent: "错位零号",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});
const 垃圾填埋厂 = new SectorPreset("垃圾填埋厂", DUST, 2);//引号内填msav的名字
垃圾填埋厂.description = "只是处理一些垃圾的地点，没什么特别的";
垃圾填埋厂.difficulty = 1;//难度 1-10
垃圾填埋厂.alwaysUnlocked = false;//总是解锁
垃圾填埋厂.addStartingItems = true;
垃圾填埋厂.captureWave = 40;//多少波可占领
垃圾填埋厂.localizedName = "垃圾填埋厂";
exports.垃圾填埋厂 = 垃圾填埋厂;
lib.addToResearch(垃圾填埋厂, {
	parent: "撕裂地带",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});
const 冰封地带 = new SectorPreset("冰封地带", DUST, 3);//引号内填msav的名字
冰封地带.description = "被常年冰封，可是地理位置却十分离奇";
冰封地带.difficulty = 1;//难度 1-10
冰封地带.alwaysUnlocked = false;//总是解锁
冰封地带.addStartingItems = true;//允许添加初始资源
冰封地带.captureWave = 50;//多少波可占领
冰封地带.localizedName = "冰封地带";
exports.冰封地带 = 冰封地带;
lib.addToResearch(冰封地带, {
	parent: "垃圾填埋厂",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});
const 深邃洞窟 = new SectorPreset("深邃洞窟", DUST, 4);//引号内填msav的名字
深邃洞窟.description = "我们的旅途也许完成五分之一了";
深邃洞窟.difficulty = 2;//难度 1-10
深邃洞窟.alwaysUnlocked = false;//总是解锁
深邃洞窟.addStartingItems = true;//允许添加初始资源
深邃洞窟.localizedName = "深邃洞窟";
exports.深邃洞窟 = 深邃洞窟;
lib.addToResearch(深邃洞窟, {
	parent: "冰封地带",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});
const 错乱街道 = new SectorPreset("错乱街道", DUST, 5);//引号内填msav的名字
错乱街道.description = "[red]欢迎来到毁灭之城";
错乱街道.difficulty = 3;//难度 1-10
错乱街道.alwaysUnlocked = false;//总是解锁
错乱街道.addStartingItems = true;//允许添加初始资源
错乱街道.captureWave = 15;
错乱街道.localizedName = "错乱街道";
exports.错乱街道 = 错乱街道;
lib.addToResearch(错乱街道, {
	parent: "深邃洞窟",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});
const 核裂阵地 = new SectorPreset("核裂阵地", DUST, 6);//引号内填msav的名字
核裂阵地.description = "核裂阵的前身？";
核裂阵地.difficulty = 3;//难度 1-10
核裂阵地.alwaysUnlocked = false;//总是解锁
核裂阵地.addStartingItems = true;//允许添加初始资源
核裂阵地.captureWave = 30;
核裂阵地.localizedName = "核裂阵地";
exports.核裂阵地 = 核裂阵地;
lib.addToResearch(核裂阵地, {
	parent: "错乱街道",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});
const 废弃实验地 = new SectorPreset("废弃实验地", DUST, 7);//引号内填msav的名字
废弃实验地.description = "DUST...废弃...";
废弃实验地.difficulty = 3;//难度 1-10
废弃实验地.alwaysUnlocked = false;//总是解锁
废弃实验地.addStartingItems = true;//允许添加初始资源
废弃实验地.captureWave = 20;
废弃实验地.localizedName = "废弃实验地";
exports.废弃实验地 = 废弃实验地;
lib.addToResearch(废弃实验地, {
	parent: "核裂阵地",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});
const 二十四区 = new SectorPreset("二十四区", DUST, 8);//引号内填msav的名字
二十四区.description = "只是一个编号为24的区块";
二十四区.difficulty = 4;//难度 1-10
二十四区.alwaysUnlocked = false;//总是解锁
二十四区.addStartingItems = true;//允许添加初始资源
二十四区.captureWave = 25;
二十四区.localizedName = "废弃实验地";
exports.二十四区 = 二十四区;
lib.addToResearch(二十四区, {
	parent: "废弃实验地",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});
const 死亡公路 = new SectorPreset("死亡公路", DUST, 9);//引号内填msav的名字
死亡公路.description = "象征你战役的死亡";
死亡公路.difficulty = 4;//难度 1-10
死亡公路.alwaysUnlocked = false;//总是解锁
死亡公路.addStartingItems = true;//允许添加初始资源
死亡公路.captureWave = 50;
死亡公路.localizedName = "死亡公路";
exports.死亡公路 = 死亡公路;
lib.addToResearch(死亡公路, {
	parent: "二十四区",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});


