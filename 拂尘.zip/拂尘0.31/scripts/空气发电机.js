const 空气发电机 = extend(SolarGenerator, '空气发电机', {});
空气发电机.localizedName = '空气发电机';
空气发电机.buildVisibility = BuildVisibility.shown;
空气发电机.category = Category.power;
空气发电机.update = 空气发电机.configurable = 空气发电机.hasPower = true;
空气发电机.powerProduction = 2;
空气发电机.buildType = prov(() => {
    var productionEfficiency = 2;
    return new JavaAdapter(SolarGenerator.SolarGeneratorBuild, {
	write(write){
		this.super$write(write);
		write.f(this.productionEfficiency);
	},
	read(read, revision){
		this.super$read(read, revision);
		this.productionEfficiency = read.f();
	}
},空气发电机);
});

