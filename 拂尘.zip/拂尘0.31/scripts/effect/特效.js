var bomb1 = Bomb("bomb1");
bomb1.explodeEffect(new Effect(2,cons(e =>{
Fx.titanSmoke.at(e.x,e.y,new Color(0.3,0.6,0.9,0.9));
Fx.titanExplosion.at(e.x,e.y,new Color(0.3,0.6,0.9,0.9));
})));

const light1 = new Effect(10,cons(e =>{
Fx.instBomb.at(e.x,e.y,new Color(0.3,0.6,0.9,0.9));
Fx.lighting.at(e.x,e.y,new Color(0.3,0.6,0.9,0.9));
}));
