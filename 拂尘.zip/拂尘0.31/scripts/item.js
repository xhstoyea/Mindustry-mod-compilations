exports.碳 = (() => {
let myItem = extend(Item, "碳", {});
return myItem;
})();
exports.蓝钻 = (() => {
let myItem = extend(Item, "蓝钻", {});
return myItem;
})();
exports.钻石晶体 = (() => {
let myItem = extend(Item, "钻石晶体", {});
return myItem;
})();
exports.石英 = (() => {
let myItem = extend(Item, "石英", {});
return myItem;
})();
exports.铀 = (() => {
let myItem = extend(Item, "铀", {});
return myItem;
})();
exports.锇 = (() => {
let myItem = extend(Item, "锇", {});
return myItem;
})();
exports.钾盐 = (() => {
let myItem = extend(Item, "钾盐", {});
return myItem;
})();
exports.赤盐 = (() => {
let myItem = extend(Item, "赤盐", {});
return myItem;
})();
exports.火盐 = (() => {
let myItem = extend(Item, "火盐", {});
return myItem;
})();
exports.蔚盐 = (() => {
let myItem = extend(Item, "蔚盐", {});
return myItem;
})();
exports.重工业塑钢 = (() => {
let myItem = extend(Item, "重工业塑钢", {});
return myItem;
})();
exports.碳钢 = (() => {
let myItem = extend(Item, "碳钢", {});
return myItem;
})();
exports.锇合金 = (() => {
let myItem = extend(Item, "锇合金", {});
return myItem;
})();
exports.共价体 = (() => {
let myItem = extend(Item, "共价体", {});
return myItem;
})();