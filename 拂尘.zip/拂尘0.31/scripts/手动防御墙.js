
const 手动防御墙 = extend(Wall, '手动防御墙', {});
手动防御墙.localizedName = '手动防御墙';
手动防御墙.buildVisibility = BuildVisibility.shown;
手动防御墙.category = Category.power;
手动防御墙.update = 手动防御墙.configurable = true;
手动防御墙.buildType = prov(() => {
    return new JavaAdapter(Wall.WallBuild, {
	buildConfiguration(table){
		table.button(Icon.upOpen, Styles.defaulti, run(() => {
		    if(this.health < 540) this.health +=60;
		})).size(45);
	},
},手动防御墙);
});

