Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("粒子科技");
    dialog.buttons.defaults().size(400, 64);
    // 修正点：在 dialog.hide(); 后补上右括号
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(400, 128);  // 此处添加缺失的右括号
    
    dialog.cont.pane(() => {
        var table = new Table();
        table.add("粒子科技");
        table.row();
        table.add("v1.2");
        table.row();
        table.add(" ");
        table.row();
        table.add("QQ模组群:850080316");
        table.row();
        table.add("B站:一根来自MC的灰柴");
        table.row();
        table.add(" ");
        table.row();
        table.button("更新", Icon.infoCircle, run(() => {
            var updateDialog = new BaseDialog("更新");
            updateDialog.cont.pane(t => {
                t.add("更新");
                t.row();
                t.button("本次更新", Icon.infoCircle, run(() => {
                    var currentUpdateDialog = new BaseDialog("本次更新");
                    currentUpdateDialog.cont.pane(t => {
                        t.add("v1.2更新:\n\n新增更多物品与流程，增加'[grey]石凿[white]'\n更新了星球'[lime]帕蒂克[white]'，内含战役地图'[green]辐寂站[white]'\n关注B站'一根来自MC的灰柴哦！\n\n\n(虽然现在不发关于这个的视频，等V2.0吧!)");
                    });
                    currentUpdateDialog.buttons.button("@close", () => { currentUpdateDialog.hide(); }).size(400, 128);
                })).size(400, 128);
                t.row();
                t.button("历次更新", Icon.infoCircle, run(() => {
                    var historyDialog = new BaseDialog("历次更新");
                    historyDialog.cont.pane(t => {
                        t.add("v1.1更新\n\n物品:玻璃，石头，黏土，芯片，显示单元。\n\n生产:低级熔炉，高级熔炉。\n\n钻头:光能采矿机。\n\n\n\n具体增加更多前期用的产线，增加scripts，增加了一个钻头彩蛋:光能采矿机，虽然说20多秒才有一个矿，但是它毕竟什么都能挖awa~");
                    });
                    historyDialog.buttons.button("@close", () => { historyDialog.hide(); }).size(400, 128);
                })).size(400, 128);
            });
            updateDialog.buttons.button("@close", () => { updateDialog.hide(); }).size(400, 128);
        })).size(400, 128);
        table.button("简介", Icon.infoCircle, run(() => {
            var descDialog = new BaseDialog("简介");
            descDialog.cont.pane(t => {
                t.add("粒子的运动，辐射的倍增，危险的边际。");
            });
            descDialog.buttons.button("@close", () => { descDialog.hide(); }).size(400, 128);
        })).size(400, 64);
        table.row();
        return table;
    }).grow().center().maxWidth(620);
    dialog.show();
}));