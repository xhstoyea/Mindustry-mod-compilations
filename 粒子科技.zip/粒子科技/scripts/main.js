MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000
require("物品")
require("液体")
require("菜单")
require("base/lib")
require("base/library")