function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("铀-238")
newItem("铀-235")
newItem("玻璃")
newItem("钚-239")
newItem("芯片")
newItem("显示单元")
newItem("石头")
newItem("黏土")
newItem("能量团")
newItem("反物质")
newItem("铀燃料")
newItem("枯竭铀燃料")
newItem("天然铀")
