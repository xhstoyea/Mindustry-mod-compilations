![moardustry](https://user-images.githubusercontent.com/76548026/114630681-bfa5e780-9c80-11eb-970c-f8aebd8be2a0.png)
# MOARdustry
A mod for Mindustry that adds MOAR to your game.

**Moardustry v0.10 Adds:**
<br>`Items:` 4
<br>`Liquids:` 3
<br>`Blocks:` 30
<br>`Turrets:` 16
<br>`Units:` 13
