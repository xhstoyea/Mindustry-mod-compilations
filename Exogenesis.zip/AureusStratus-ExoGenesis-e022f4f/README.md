# Exogenesis

My discord AureusAltirius#6109

Official exogenesis youtube channel link https://youtube.com/channel/UCkIHhwPP42TkNtdx56vbHGA

A mod that adds a lot more content to the game.
<br>I just hope you guys enjoy my mod.

## The mod adds:

alot of stuff

## Mod races/factions

Exogenesis contains five different races each with there own lore, weapons, defense, and units.

`Credits to Đuvent for making both the lore of the factions and the two attack maps`

`Genesux`: In the "Siravax System" they lay in the sub-zero temperature planet called "Siratla", other planets in the
system that are comrpised of Siratla Stone and Crystals is Ruxt, While Vantax is a Gas Planet, these three specific
planets also have multiple satelites(moons) surrounding them, the star is Siravax and the Genesux are comprised of cold
energy and Siratla stone, They are a type of lithiods, these beings and are strong, their weapons and creations are made
out of metal material formed from various metals and cold energy. Little is understood of there goal, but it seems like
nothing is gonna stop them from achieving it.

`Solran`: These lithiod lifeforms are almost an Opposition of the Genesux since they are extremely hot/molten and have
capabilities out of this galaxy, they are found in the "Alphandax System", which is an astronomical question, since this
is a Binary System with Alphandax and Betanax, but there are planets orbiting, anyways moving on we have these
creatures, they are comprised of molten rock and material they get from under the volcanos and lava oceans of there
planet Volceru, they get titanium and multiple igna-rocks and they fuse them together to get a strong material that they
use to form their absolute monsters, other satelites/planets in this Binary System include, Furnius and Siten.

`Elecian`: They are found in the "Vanstarius System", they live on a gassy planet with 3/4 satelites, other planets in
this system also have satelites, the other planets are, Ravu, Duris. Mineus, although Duris and Mineus dont have
satelites we will still include them, the Eleciams are monsters at destruction and show no mercy, their technology are
very advanced and are un-matched in there will to fight, they are very strong and can pack quite a punch, wether you
have walls or not, the material that they use are unknown and are probably an alloy made out of titanium and some other
material.

`Terretux`: deep Bootes Void, in galaxy long dead there lies a fallen empire, destroyed by a cataclysmic event.
Astronomeers from Serpulo call it the "Forgotten empire", this species originated from the "Erten system", with planets
surrounding it such as Xeantra and Celtus, They are powered by Pure Dark Energy and an unknown form of energy, they use
their strong and strange materials to create weapons and technology yet understood. What had happen to this great
empire?.

`Quantra`: These peaceful, Aquatic Plant Creatures are found in the "Lumian System", they arent observed as much as the
others but have developed underwater and on islands and shores, they live in an radioactive biome of an ocean, they
somehow get their materials to make several naval weapons, they will also invent other weapons that devastate
everything.

## Screenshots

![unknown-14](https://user-images.githubusercontent.com/68311340/118233805-7227c080-b460-11eb-99cd-5ab35cecb273.png)
![unknown-15](https://user-images.githubusercontent.com/68311340/118233809-7358ed80-b460-11eb-8077-b3304aab2e0d.png)
