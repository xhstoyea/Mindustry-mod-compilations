MapResizeDialog.minSize = 50
MapResizeDialog.maxSize = 50000
require("planets/朗伊尔");//星球
