const LYRlib = require("base/LYRlib");
const LYR = new Planet("朗伊尔", Planets.sun, 1, 3.3);
LYR.meshLoader = prov(() => new MultiMesh(
	new HexMesh(LYR, 8)
));
LYR.generator = extend(SerpuloPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nA3JMQ6AIBAAwQXFRr9i4XuMBR5XkCAYkP9LphwcbmLO/lHMwRq0SY3vF0sGluRvTQ17XoZNStU9d0na20gDduAHAc0Org==")
	}
});
LYR.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(LYR, 2, 0.15, 0.14, 5, Color.valueOf("BBFFFF"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(LYR, 3, 0.6, 0.15, 5, Color.valueOf("AEEEEE"), 2, 0.42, 1.2, 0.45)
));
LYR.generator = new SerpuloPlanetGenerator();
LYR.visible = LYR.accessible = LYR.alwaysUnlocked = true;
LYR.clearSectorOnLose = false;
LYR.tidalLock = false;
LYR.localizedName = "朗伊尔";
LYR.prebuildBase = false;
LYR.bloom = false;
LYR.startSector = 1;
LYR.orbitRadius = 85;
LYR.orbitTime = 180 * 60;
LYR.rotateTime = 90 * 60;
LYR.atmosphereRadIn = 0.02;
LYR.atmosphereRadOut = 0.3;
LYR.atmosphereColor = LYR.lightColor = Color.valueOf("8EE5EE");
LYR.iconColor = Color.valueOf("98F5FF"),
LYR.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);
/*
map n head2
SC map n head2
SC map name
*/



const map1pj = new SectorPreset("指挥中心", LYR, 1);
map1pj.description = "新任将军您好，我们将在这里对您进行训练";
map1pj.difficulty = 2;
map1pj.alwaysUnlocked = false;
map1pj.addStartingItems = true;
map1pj.captureWave = 0;
map1pj.localizedName = "指挥中心";
exports.map1pj = map1pj;
SFlib.addToResearch(map1pj, {
	parent: "planetaryTerminal",
	objectives: Seq.with(
	new Objectives.SectorComplete(SectorPresets.planetaryTerminal))
});