function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}

newItem("玻璃合金")
newItem("基础架构蓝图")
newItem("可塑性炸药")
newItem("耐热塑料")
newItem("塑料")
newItem("铜合金")
newItem("裂位能")