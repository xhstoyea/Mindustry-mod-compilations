//捆绑包,把js文件捆绑在一起
let mod = Vars.mods.getMod(modName);
mod.meta.author = "Dimension+[red]星[orange]辰[green]102524";
mod.meta.description = "[red]蓝图工艺"

require('Planet')
require('lib')
require('物品')
require('流体')