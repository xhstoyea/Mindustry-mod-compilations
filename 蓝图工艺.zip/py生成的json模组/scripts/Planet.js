const lib = require("lib");
const free = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(free, 6));
        this.super$load();
    }
}, "free", Planets.sun, 1);
const sS = require("sectorSize");
sS.planetGrid(free, 1);
//上面的是区块大小 ▲ 正常是3.3不建议乱改
free.generator = new ErekirPlanetGenerator();
//可以将[Erekir]改成任何游戏中有的星球
free.atmosphereColor = Color.valueOf("F75000");//大气颜色
free.atmosphereRadIn = 0.05;//？？？
free.atmosphereRadOut = 0.5;//密度？
free.localizedName = "free-campaign";;
free.visible = true;//能否看得见
free.bloom = false;//这个不确定
free.accessible = true;//可达到？
free.alwaysUnlocked = true;//始终未锁定
free.startSector = 1;//开始的地方数量
free.orbitRadius = 22;//距离太阳
//----分界线----从这往下可以复制增加区块
const maps = new SectorPreset("wo-de-tu", free, 1);
maps.alwaysUnlocked = true;
maps.captureWave = 1;
maps.difficulty = 5;
maps.localizedName = "start";
exports.maps = maps;
lib.addToResearch(maps, {
    parent: 'planetaryTerminal',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.groundZero))
});
//---------分----界----线---------------


//防呆列表
//free随便写算是星球的名字
//想改turn或false的酌情使用,最好翻译一下
//想加新的区块可以复制上面的
//请不要乱改sectorSize.js
//记得自己加地图到外面的maps文件夹里
//
//
