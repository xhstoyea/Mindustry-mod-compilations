Events.on(ClientLoadEvent, cons((e) => {
    Vars.content.each(cons(mdt => {
		if(mdt instanceof UnitType){
            mdt.envDisabled = Env.none;
        }
        if(mdt instanceof Planet){
            mdt.hiddenItems.clear();
        }
    }));
}));