const lib = require("lib");
const M埃 = new Planet("MEE-埃里克尔", Planets.sun, 1, 2.3);
M埃.meshLoader = prov(() => new MultiMesh(
	new HexMesh(M埃, 5)
));
M埃.generator = extend(ErekirPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgYWBhZmDJS8xNZeB5Or/v6YKFzxbseLq/mYE7JbU4uSizoCQzP4+BgYEtJzEpNaeYgSk6lpGBJzm/KFU3KbEYKskIQkACAAynFxI=")
	}
});
M埃.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(M埃, 2, 0.15, 0.14, 5, Color.valueOf("E28654FF"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(M埃, 3, 0.6, 0.15, 5, Color.valueOf("E28654FF"), 2, 0.42, 1.2, 0.45)
));
M埃.generator = new ErekirPlanetGenerator();
M埃.visible = M埃.accessible = M埃.alwaysUnlocked = true;
M埃.clearSectorOnLose = true;
M埃.tidalLock = false;
M埃.defaultAttributes.set(Attribute.heat, 0.8);
M埃.updateLighting = false;
M埃.lightSrcTo = 0.5;
M埃.allowLaunchToNumbered = false
M埃.lightDstFrom = 0.2;
M埃.defaultEnv = Env.scorching | Env.terrestrial;
M埃.defaultCore = Blocks.coreBastion;
M埃.localizedName = "MEE-埃里克尔";
M埃.prebuildBase = false;
M埃.bloom = false;
M埃.startSector = 2;
M埃.orbitRadius = 85;
M埃.atmosphereRadIn = 0.02;
M埃.atmosphereRadOut = 0.3;
M埃.atmosphereColor = M埃.lightColor = Color.valueOf("E28654FF");
M埃.iconColor = Color.valueOf("E28654FF"),
M埃.hiddenItems.addAll(Items.serpuloItems).removeAll(Items.erekirItems);

const MEE始发地区 = new SectorPreset("MEE始发地区", M埃, 2);
MEE始发地区.alwaysUnlocked = false;
MEE始发地区.difficulty = 4;
MEE始发地区.localizedName = "MEE始发地区";
exports.MEE始发地区 = MEE始发地区;
lib.addToResearch(MEE始发地区, {
	parent: "origin",
	objectives: Seq.with(
	new Objectives.SectorComplete(SectorPresets.origin))
});
const MEE庇护前哨 = new SectorPreset("MEE庇护前哨", M埃, 4);
MEE庇护前哨.alwaysUnlocked = false;
MEE庇护前哨.difficulty = 6;
MEE庇护前哨.localizedName = "MEE庇护前哨";
exports.MEE庇护前哨 = MEE庇护前哨;
lib.addToResearch(MEE庇护前哨, {
    parent: "MEE始发地区",
    objectives: Seq.with(
        new Objectives.SectorComplete(MEE始发地区))
});
const MEE岩浆湖 = new SectorPreset("MEE岩浆湖", M埃, 6);
MEE岩浆湖.alwaysUnlocked = false;
MEE岩浆湖.difficulty = 6;
MEE岩浆湖.localizedName = "MEE岩浆湖";
exports.MEE岩浆湖 = MEE岩浆湖;
lib.addToResearch(MEE岩浆湖, {
    parent: MEE庇护前哨,
    objectives: Seq.with(
        new Objectives.SectorComplete(MEE庇护前哨))
});

const MEE交错丘陵 = new SectorPreset("MEE交错丘陵", M埃, 8);
MEE交错丘陵.captureWave = 9;
MEE交错丘陵.alwaysUnlocked = false;
MEE交错丘陵.difficulty = 6;
MEE交错丘陵.localizedName = "MEE交错丘陵";
exports.MEE交错丘陵 = MEE交错丘陵;
lib.addToResearch(MEE交错丘陵, {
    parent: MEE岩浆湖,
    objectives: Seq.with(
        new Objectives.SectorComplete(MEE岩浆湖))
});
 const MEE风化山脉 = new SectorPreset("MEE风化山脉", M埃, 10);
 MEE风化山脉.alwaysUnlocked = false;
 MEE风化山脉.difficulty = 6;
 MEE风化山脉.localizedName = "MEE风化山脉";
 exports.MEE风化山脉 = MEE风化山脉;
 lib.addToResearch(MEE风化山脉, {
     parent: MEE交错丘陵,
     objectives: Seq.with(
         new Objectives.SectorComplete(MEE交错丘陵))
 });
const MEE风蚀盆地 = new SectorPreset("MEE风蚀盆地", M埃, 12);
MEE风蚀盆地.alwaysUnlocked = false;
MEE风蚀盆地.difficulty = 12;
MEE风蚀盆地.localizedName = "MEE风蚀盆地";
exports.MEE风蚀盆地 = MEE风蚀盆地;
lib.addToResearch(MEE风蚀盆地, {
    parent: MEE风化山脉,
    objectives: Seq.with(
        new Objectives.SectorComplete(MEE风化山脉))
});
const MEE芳油湿地 = new SectorPreset("MEE芳油湿地", M埃, 14);
MEE芳油湿地.alwaysUnlocked = false;
MEE芳油湿地.difficulty = 14;
MEE芳油湿地.localizedName = "MEE芳油湿地";
exports.MEE芳油湿地 = MEE芳油湿地;
lib.addToResearch(MEE芳油湿地, {
    parent: MEE风蚀盆地,
    objectives: Seq.with(
        new Objectives.SectorComplete(MEE风蚀盆地))
});
const MEE横堑峰峦 = new SectorPreset("MEE横堑峰峦", M埃, 16);
MEE横堑峰峦.alwaysUnlocked = false;
MEE横堑峰峦.difficulty = 16;
MEE横堑峰峦.localizedName = "MEE横堑峰峦";
exports.MEE横堑峰峦 = MEE横堑峰峦;
lib.addToResearch(MEE横堑峰峦, {
    parent: MEE芳油湿地,
    objectives: Seq.with(
        new Objectives.SectorComplete(MEE芳油湿地))
});
const MEE贫瘠峡谷 = new SectorPreset("MEE贫瘠峡谷", M埃, 17);
MEE贫瘠峡谷.captureWave = 25;
MEE贫瘠峡谷.alwaysUnlocked = false;
MEE贫瘠峡谷.difficulty = 16;
MEE贫瘠峡谷.localizedName = "MEE贫瘠峡谷";
exports.MEE贫瘠峡谷 = MEE贫瘠峡谷;
lib.addToResearch(MEE贫瘠峡谷, {
    parent: MEE芳油湿地,
    objectives: Seq.with(
        new Objectives.SectorComplete(MEE芳油湿地))
});
const MEE破碎火山 = new SectorPreset("MEE破碎火山", M埃, 20);
MEE破碎火山.alwaysUnlocked = false;
MEE破碎火山.difficulty = 16;
MEE破碎火山.localizedName = "MEE破碎火山";
exports.MEE破碎火山 = MEE破碎火山;
lib.addToResearch(MEE破碎火山, {
    parent: MEE贫瘠峡谷,
    objectives: Seq.with(
        new Objectives.SectorComplete(MEE贫瘠峡谷))
});
const MEE晶石要塞 = new SectorPreset("MEE晶石要塞", M埃, 23);
MEE晶石要塞.alwaysUnlocked = false;
MEE晶石要塞.difficulty = 20;
MEE晶石要塞.localizedName = "MEE晶石要塞";
exports.MEE晶石要塞 = MEE晶石要塞;
lib.addToResearch(MEE晶石要塞, {
    parent: MEE破碎火山,
    objectives: Seq.with(
        new Objectives.SectorComplete(MEE破碎火山))
});
//const MEE。 = new SectorPreset("MEE。", M埃, 16);
//MEE。.alwaysUnlocked = false;
//MEE。.difficulty = 16;
//MEE。.localizedName = "MEE。";
//exports.MEE。 = MEE。;
//lib.addToResearch(MEE。, {
//    parent: MEE芳油湿地,
//    objectives: Seq.with(
//        new Objectives.SectorComplete(MEE芳油湿地))
//});
