const ability = require("other/拓展能力");

const 悲悯 = new ErekirUnitType("悲悯");
悲悯.constructor = prov(() => extend(UnitTypes.disrupt.constructor.get().class, {}));
悲悯.abilities.add(
    ability.CloneAbility(560,34500,Color.valueOf("ffffff"))
);
exports.悲悯 = 悲悯;