const 公理子弹 = extend(BasicBulletType, {
    damage: 300,
    lifetime: 80,
    speed: 6,
    pierce: true,
    pierceCap: 2,
    pierceArmor: true,
    homingPower: 0.009,
    homingRange: 96,
    frontColor: Color.valueOf("ffffff"),
    backColor: Color.valueOf("ffffff"),
    sprite: "埃里克尔更多设备-edge",
    trailColor: Color.valueOf("ffffff"),
    trailWidth: 1,
    trailLength: 12,
    hitEffect: extend(ParticleEffect, {
        lifetime: 20,
        cone: 360,
        particles: 8,
        line: true,
        baseLength: 0,
        length: 20,
        lenFrom: 6,
        lenTo: 2,
        strokeFrom: 3,
        strokeTo: 0,
        colorFrom: Color.valueOf("ffffff"),
        colorTo: Color.valueOf("ffffff")
    }),
    hitEntity(b, entity, health){
        this.super$hitEntity(b, entity, health);
        if(b.owner instanceof Turret.TurretBuild){
            if(b.owner.getCount() >= 0.99){
                entity.killed();
                b.owner.setCount(0.25);
            }
            b.owner.maxHealth += 125;
            b.owner.health += 125;
            if(entity instanceof Unit && entity.dead){
                b.owner.reloadCounter += 180;
            }
        }
    }
});

const 公理 = extend(PowerTurret, "公理", {
    shootType: 公理子弹,
    setBars() {
        this.super$setBars();
        this.addBar("count", e => new Bar(
            () => Core.bundle.get("bar.count"),
            () => Color.valueOf("FFFFFF"),
            () => e.getCount()
        ));
    }
});

公理.buildType = prov(() => {
    let count = 0;
    let maxMul = 1;
    return extend(PowerTurret.PowerTurretBuild, 公理, {
        getCount(){
            return count / maxMul;
        },
        setCount(value){
            count *= value;
        },
        updateTile(){
            this.super$updateTile();
            count -= maxMul * 0.001;
            count = Math.min(maxMul, Math.max(0, count));
            maxMul = this.maxHealth / 4650 + 1;
            this.health = Math.min(this.maxHealth, this.health);
            this.maxHealth = Math.min(this.block.health * 2, this.maxHealth);
        },
        shoot(type){
            this.super$shoot(type);
            count += 0.04 * maxMul;
            this.health += 50;
        },
        handleBullet(bullet, offsetX, offsetY, angleOffset){
            bullet.damage *= 1 + count;
        },
        write(write){
            this.super$write(write);
            write.f(count);
            write.i(this.maxHealth);
        },
        read(read, revision){
            this.super$read(read, revision);
            count = read.f();
            this.maxHealth = read.i();
        }
    })
});
exports.公理 = 公理;