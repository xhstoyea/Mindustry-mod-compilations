const item = require("blocks/items");

let 泯灭charge = new MultiEffect(
  Object.assign(new ParticleEffect(),{
    lifetime : 80,
    particles : 1,
    sizeFrom : 0,
    sizeTo : 4,
    baseLength : 0,
    length : -0.01,
    colorFrom : Color.valueOf("E8D174"),
    colorTo : Color.valueOf("E8D174"),
    interp : Interp.circleOut
  })
);
let 泯灭shoot = new MultiEffect(
  new Effect(40,e => {
    Draw.color(Color.valueOf("E8D174"));
    
    for(let i = 0;i < 4;i++){
      Drawf.tri(e.x,e.y,8 * e.fout(),128 * e.fout(),e.rotation + 90 * i + 45);
    }
  }),
  new Effect(40,e => {
    Draw.color(Color.valueOf("E8D174"));
    Lines.stroke(4 * e.fout(Interp.circleOut));
    
    for(let i = 0;i < 4;i++){
      let vec = new Vec2(0,0).trns(e.rotation,80 * e.fin(Interp.circleOut) * (i + 1));
      Lines.poly(e.x + vec.x,e.y + vec.y,Lines.circleVertices(12 * (4 - i) * e.fin()),12 * (4 - i) * e.fin(),e.rotation);
    }
  })
);
const 泯灭激光 = extend(LaserBulletType,{
  lightningSpace : 36,
  lightningLength : 10,
  lightningDelay : 0.8,
  lightningLengthRand : 8,
  lightningAngleRand : 90,
  lightningDamage : 280,
  lightningColor : Pal.surge,

  colors: [Color.valueOf("E8D17480"),Color.valueOf("E8D174"),Color.valueOf("ffffff")],
  length : 80000,
  width : 24,
  lifetime : 56,

  chargeEffect : 泯灭charge,
  shootEffect : 泯灭shoot,
  despawnEffect : Fx.none,

  sideAngle : 90,
  sideLength : 128,
  sideWidth : 1.2,

  damage : 450,
  splashDamage : 120,
  splashDamageRadius : 16,

  hitEntity(b,entity,health){
    if(entity instanceof Healthc){
      entity.damagePierce(entity.health * 0.1);
    }
    this.super$hitEntity(b,entity,health);
  }
});

const 泯灭 = extend(ItemTurret,"泯灭",{

});

泯灭.ammo(
item.列位石,泯灭激光
);