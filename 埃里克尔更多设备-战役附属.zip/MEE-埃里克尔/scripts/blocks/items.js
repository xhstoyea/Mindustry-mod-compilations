function newItem(name) {
	exports[name] = (() => {
		let 物品 = extend(Item, name, {});
		return 物品;
	})();
}
newItem("列位石")