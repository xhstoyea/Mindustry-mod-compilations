const 列位混合墙 = extend(Wall,"列位混合墙", {
  update : true,
    setBars() {
        this.super$setBars();
        this.addBar("count", func(e => new Bar(
            prov(() => Core.bundle.get("bar.count") + ":" + e.getCount().toFixed().toString()),
            prov(() => Color.valueOf("FFFFFF")),
            floatp(() => e.getCount())
        )));
    }
});

列位混合墙.buildType = prov(() => {
  let count = 0;
  let lastHealth = 20000;
  return extend(Wall.WallBuild,列位混合墙,{
    getCount(){
      return Math.ceil(count) / Math.ceil(this.maxHealth * 0.2);
    },
    updateTile(){
      this.super$updateTile();

      if(lastHealth > this.health){
        count += Math.ceil(lastHealth - this.health);
      }
      lastHealth = this.health;

      if(Math.ceil(count) / Math.ceil(this.maxHealth * 0.2) > 1){
        count -= this.maxHealth * 0.2;
        this.maxHealth += this.maxHealth * 0.05;
        this.health += this.maxHealth * 0.12;
      }

      if(this.health < this.maxHealth){
        this.health += this.maxHealth * 0.0008;
      }
      this.health = Math.min(this.health, this.maxHealth);
      this.armor = Math.floor(this.maxHealth / 2000);
    },
    write(w){
      this.super$write(w);
      w.f(this.maxHealth);
      w.f(this.health);
      w.f(count);
      w.f(lastHealth);
    },
    read(r,rv){
      this.super$read(r,rv);
      this.maxHealth = r.f();
      this.health = r.f();
      count = r.f();
      lastHealth = r.f();
    }
  })
});