let EXbullet = require("other/拓展子弹");

const 烁子弹 = extend(ArtilleryBulletType, {
  lifetime : 240,
  speed: 4,

  damage : 240,
  splashDamage : 240,
  splashDamageRadius : 48,

  trailColor : Pal.surge,
  trailChance : 0,
  trailLength : 12,
  trailWidth : 2,

  despawnEffect :   Object.assign(new WaveEffect(), {
    lifetime : 22,
    interp : Interp.circleOut,
    strokeFrom : 3,
    strokeTo: 0,
    sizeFrom : 3,
    sizeTo : 48,
    colorFrom : Pal.surge,
    colorTo : Pal.surge
  })
});
烁子弹.parts.add(
  Object.assign(new FlarePart(),{
    rotation: 0,
    color1 : Pal.surge,
    stroke : 3,
    radius : 3,
    radiusTo : 18,
  })
);
let 芒fragRadius = 64;
const 芒frag = extend(BasicBulletType, {
  lifetime : 360,
  speed: 0,

  sprite : "circle",
  width : 8,
  height : 8,
  shrinkY : 0,
  frontColor : Color.valueOf("000000"),
  backColor : Color.valueOf("000000"),
  layer : 300,

  damage : 480,
  buildingDamageMultiplier : 0.1,

  collides : false,
  absorbable : false,

  trailColor : Pal.surge,
  trailChance : 0,
  trailLength : 12,
  trailWidth : 2,

  despawnEffect : Object.assign(new WaveEffect(), {
    lifetime : 22,
    interp : Interp.circleOut,
    strokeFrom : 3,
    strokeTo: 0,
    sizeFrom : 3,
    sizeTo : 48,
    colorFrom : Pal.surge,
    colorTo : Pal.surge
  }),

  update(b){
    this.super$update(b);
    Units.nearbyEnemies(b.team,b.x,b.y,芒fragRadius,cons(unit => {
      const  dst = 1 - b.dst(unit) / 芒fragRadius;
      unit.impulseNet(Tmp.v3.set(b).sub(unit).nor().scl(unit.mass() * dst * 0.8));
      unit.damageContinuousPierce(this.damage / 60);
    }));
    Vars.indexer.allBuildings(b.x,b.y,芒fragRadius,cons(build => {
      if(build.team != b.team && build.health > 30){
        build.damageContinuousPierce(b.damage * b.type.buildingDamageMultiplier / 60);
      }
    }));
  },
  draw(b){
    this.super$draw(b);
  }
});
芒frag.parts.add(
  Object.assign(new ShapePart, {
    circle : true,
    radius : 8,
    radiusTo : 8,
    color : Pal.surge,
    colorTo : Pal.surge,
    layer : 110
  }),
  Object.assign(new HaloPart,{
    progress : DrawPart.PartProgress.life.sin(0.0015,1),
    shapes : 2,
    tri : true,

    rotateSpeed : 0,
    haloRotateSpeed : 2.4,
    radius : 8,
    radiusTo : 8,
    triLength : 8,
    triLengthTo : 16,
    haloRadius : 7,
    haloRadiusTo : 7,
    color : Pal.surge,
    colorTo : Pal.surge,
    layer : 110
  })
);
const 芒子弹 = extend(BasicBulletType, {
  lifetime : 240,
  speed: 4,

  damage : 480,

  reloadMultiplier : 0.5,
  
  fragBullets : 1,
  fragBullet : 芒frag,

  trailColor : Pal.surge,
  trailChance : 0,
  trailLength : 12,
  trailWidth : 2,

  despawnEffect :   Object.assign(new WaveEffect(), {
    lifetime : 22,
    interp : Interp.circleOut,
    strokeFrom : 3,
    strokeTo: 0,
    sizeFrom : 3,
    sizeTo : 48,
    colorFrom : Pal.surge,
    colorTo : Pal.surge
  })
});
芒子弹.parts.add(
  Object.assign(new FlarePart(),{
    rotation: 0,
    color1 : Pal.surge,
    stroke : 3,
    radius : 3,
    radiusTo : 18,
  })
);


const 耀frag = extend(ArtilleryBulletType, {
  lifetime : 80,
  speed: 8,
  drag : 0.048,

  damage : 120,
  
  fragBullets : 1,
  fragLifeMin : 1,
  fragLifeMax : 1,
  fragBullet : 芒frag,

  trailColor : Pal.surge,
  trailChance : 0,
  trailLength : 12,
  trailWidth : 2,

  despawnEffect :   Object.assign(new WaveEffect(), {
    lifetime : 22,
    interp : Interp.circleOut,
    strokeFrom : 3,
    strokeTo: 0,
    sizeFrom : 3,
    sizeTo : 48,
    colorFrom : Pal.surge,
    colorTo : Pal.surge
  })
});

const 耀子弹 = extend(BasicBulletType, {
  lifetime : 240,
  speed: 4,

  damage : 960,

  reloadMultiplier : 0.125,
  
  fragBullets : 8,
  fragVelocityMin : 0.5,
  fragVelocityMax : 1,
  fragLifeMin : 0.8,
  fragLifeMax : 1,
  fragBullet : 耀frag,

  trailColor : Pal.surge,
  trailChance : 0,
  trailLength : 12,
  trailWidth : 2,

  despawnEffect :   Object.assign(new WaveEffect(), {
    lifetime : 22,
    interp : Interp.circleOut,
    strokeFrom : 3,
    strokeTo: 0,
    sizeFrom : 3,
    sizeTo : 48,
    colorFrom : Pal.surge,
    colorTo : Pal.surge
  })
});

const 烁芒耀 = extend(PowerTurret, "烁芒耀", {
    shootType : 烁子弹,
    setStats(){
        this.super$setStats();
        this.stats.add(Stat.ammo, StatValues.ammo(ObjectMap.of(this, 芒子弹)));
        this.stats.add(Stat.ammo, StatValues.ammo(ObjectMap.of(this, 耀子弹)));
    },
    setBars() {
        this.super$setBars();
        this.addBar("level", e => new Bar(
            () => Core.bundle.get("bar.level") + e.getLevel().toString(),
            () => Color.valueOf("FFFFFF"),
            () => 1
        ));
        this.addBar("experience", e => new Bar(
            () => Core.bundle.get("bar.experience"),
            () => Color.valueOf("FFFFFF"),
            () => e.getEx()
        ));
    }
});
烁芒耀.buildType = prov(() => {
  let level = 1;
  let counter = 0;
  return extend(PowerTurret.PowerTurretBuild, 烁芒耀,{
    getLevel(){
      return level;
    },
    getEx(){
      return counter / level;
    },
    addCounter(){
      counter += 1;
    },
    updateTile(){
      this.super$updateTile();
      if(counter == level){
        counter -= level;
        level += 1;
      }
    },
    getDisplayName(){
      if(level < 15){
        return Core.bundle.get("FLS.fire");
      } else if(level < 30) {
        return Core.bundle.get("FLS.light");
      } else {
        return Core.bundle.get("FLS.shine");
      }
    },
    useAmmo(){
      if(level < 15){
        return 烁子弹;
      } else if(level < 30) {
        return 芒子弹;
      } else {
        return 耀子弹;
      }
    },
    peekAmmo(){
      if(level < 15){
        return 烁子弹;
      } else if(level < 30) {
        return 芒子弹;
      } else {
        return 耀子弹;
      }
    },
    shoot(type){
      this.super$shoot(type);
      counter += 1;
    },
    handleBullet(bullet, offsetX, offsetY, angleOffset){
      bullet.lifetime += bullet.lifetime * level / 20;
    },
    write(w){
      this.super$write(w);
      w.f(counter);
      w.f(level);
    },
    read(r,rv){
      this.super$read(r,rv);
      counter = r.f();
      level = r.f();
    }
  });
});