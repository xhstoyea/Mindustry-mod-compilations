importClass(java.lang.Class);
const mod = Vars.mods.locateMod("mov");
mod.meta.displayName = "调色器"
mod.meta.description = "用于修改游戏屏幕颜色的"
require("shaders_display");