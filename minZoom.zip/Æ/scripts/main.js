Vars.renderer.minZoom = 0.7
Blocks.illuminator.radius = 3000
Blocks.illuminator.brightness = 1
