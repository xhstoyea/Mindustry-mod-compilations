// by miner 2023 6.6

var alignmentElements = null;
var background = null;
var confirmTable = null;
var target = null;
var editMode = false;

// Drag
const alignmentRange = 5;
var dragMode = false;

// Resize
var resizeMode = false;
var touchLine = 0;
var touchAlign = Align.center;
var edgeScaling = 4;

// for draw
var horizontalLines = new ObjectSet();
var verticalLines = new ObjectSet();

Events.on(EventType.ClientLoadEvent, cons(e => {
    let {ui} = Vars;
    let {hudfrag, hudGroup} = ui;
    
    let {blockfrag} = hudfrag;
    let mainStack = Reflect.get(blockfrag, "mainStack"); // 放置面板
    
    let wavesTable = hudGroup.find("waves"); // 波数面板
    
    let minimap = hudGroup.find("minimap"); // 小地图
    let position = hudGroup.find("position");
    
    let coreInfo = hudGroup.find("coreinfo");
    let coreItemsTable = coreInfo.getChildren().get(1);
    let coreItems = coreItemsTable.getChildren().get(0); // 核心资源显示
    
    alignmentElements = Seq.with(
        mainStack,
        wavesTable,
        minimap, position,
        coreItems,
    );
}));

function createListener(e, needSave, alignable){
    // Read old
    if(needSave){
        readPosition(e);
        readSize(e);
    }
    
    if(alignable){
        alignmentElements.add(e);
    }
    
    return extend(InputListener, {
		lastx: 0,
		lasty: 0,
		
		touchUp(event, x, y, pointer, button){
		    if(!editMode) return;
		    
		    if(needSave){
    		    savePosition(e);
    		    saveSize(e);
		    }
        },
        
        touchDown(event, x, y, pointer, button){
		    if(!editMode) return;
		     
		    let ew = e.getWidth();
		    let eh = e.getHeight();
		    
		    let edgeWidth = ew / edgeScaling;
		    let edgeHeight = eh / edgeScaling;
		    
		    resizeMode = true;
		    dragMode = false;
		    
		    if(y >= eh - edgeHeight){
                if(x <= edgeWidth){
                    touchAlign = Align.top | Align.left;
                }else if(x >= ew - edgeWidth){
                    touchAlign = Align.top | Align.right;
                }else {
                    touchAlign = Align.top;
                }
            }else if(y <= edgeHeight){
                if(x <= edgeWidth){
                    touchAlign = Align.bottom | Align.left;
                }else if(x >= ew - edgeWidth){
                    touchAlign = Align.bottom | Align.right;
                }else {
                    touchAlign = Align.bottom;
                }
            }else if(x <= edgeWidth){
                touchAlign = Align.left;
            }else if(x >= ew - edgeWidth){ 
                touchAlign = Align.right;
            }else{
                touchAlign = Align.center;
                
                dragMode = true;
                resizeMode = false;
            }
		    
		    let v = e.localToParentCoordinates(Tmp.v1.set(x, y));
			this.lastx = v.x;
			this.lasty = v.y;
			
			return true;
		},

		touchDragged(event, x, y, pointer){
		    if(!editMode) return;
		    
		    horizontalLines.clear();
            verticalLines.clear();
		    
		    let v = e.localToParentCoordinates(Tmp.v1.set(x, y));
		    
		    let deltaX = v.x - this.lastx,
		        deltaY = v.y - this.lasty;
		    
		    this.lastx = v.x;
			this.lasty = v.y;
		    
		    if(dragMode){
		        this.updateDragMode(deltaX, deltaY);
		    }else if(resizeMode){
		        this.updateResizeMode(deltaX, deltaY);
		    }
		},
		
		enableEdit(){
		    enableEdit(e);
		},
		
		updateDragMode(deltaX, deltaY){
		    e.moveBy(deltaX, deltaY);
		    updateDragAlign();
		},
		
		updateResizeMode(deltaX, deltaY){		    
		    let newX = e.x;
		    let newY = e.y;
		    
		    let newWidth = e.getWidth();
		    let newHeight = e.getHeight();
		    let minWidth = e.getMinWidth();
		    let minHeight = e.getMinHeight();
		    
		    if(Align.isLeft(touchAlign) || Align.isRight(touchAlign)){
		        newWidth = Math.max(minWidth, newWidth);
		    
		        if(Align.isLeft(touchAlign)){
		            if(newWidth != minWidth){
    		            newX += deltaX;
    		        }
    		        newWidth -= deltaX;
    		    }else{
    		        newWidth += deltaX;
    		    }
		    }
		    
		    if(Align.isBottom(touchAlign) || Align.isTop(touchAlign)){
		        newHeight = Math.max(minHeight, newHeight);
		        
		        if(Align.isBottom(touchAlign)){
		            if(newHeight != minHeight){
    		            newY += deltaY;
    		        }
    		        newHeight -= deltaY;
    		    }else{
    		        newHeight += deltaY;
    		    }
		    }
		    
		    e.setPosition(newX, newY);
		    e.setSize(newWidth, newHeight);
		    
		    updateResizeAlign();
		},
		
	}); 
}

function isEditing(e){
    return target == e;
}

module.exports = {
    createListener: createListener,
    isEditing: isEditing,
}

function initBackground(){
    background = extend(Element, {
        draw(){
            this.super$draw();
            
            let {x, y, width, height} = this;
            
            // 背景色
            Draw.color(Color.black, 0.2);
            Fill.rect(x + width/2, y + height/2, width, height);
            Draw.reset();
            
            this.drawAlignmentLines();
            this.drawBounds();
            this.drawHint();
        },
        
        // 绘制对齐线
        drawAlignmentLines(){
            let {x, y, width, height} = this; 
            
            Draw.color(Pal.accent, 0.8);
            horizontalLines.each(ly => {
                Lines.line(0, ly, width, ly);
            })
            
            verticalLines.each(lx => {
                Lines.line(lx, 0, lx, height);
            })
            
            Draw.reset();
        },
        
        drawBounds(){
            Draw.color(Color.sky);
            
            // 绘制可对齐元素边框
            alignmentElements.each(element => {
                if(target == element){
                    return;
                }
                
                let ew = element.getWidth();
                let eh = element.getHeight();
                
                let v1 = element.localToStageCoordinates(Tmp.v1.set(0, 0));
                
                Lines.rect(v1.x, v1.y, ew, eh);
            });
            
            Draw.reset();
        },
        
        drawHint(){
            let {x, y} = target;
        
            let tw = target.getWidth();
		    let th = target.getHeight();
		    
		    let ew = tw / edgeScaling;
		    let eh = th / edgeScaling;
		    
		    // 中心矩形长宽
		    let rectWidth = tw - ew*2,
		        rectHeight = th - eh * 2;
		    
		    Draw.color(Pal.accent, 0.9);
		    
		    // 绘制元素边框
		    Lines.rect(x, y, tw, th);
		    
		    Lines.rect(x + ew, y + th - eh, rectWidth, eh); // 上
		    Lines.rect(x, y + eh, ew, rectHeight); // 左
		    Lines.rect(x + ew, y, rectWidth, eh); // 下
		    Lines.rect(x + tw - ew, y + eh, ew, rectHeight); // 右
		    
		    // 有边框 角落就不用渲染了
		    // Lines.rect(x + tw - ew, y, ew, eh); // 右下
		    // Lines.rect(x + tw - ew, y + th - eh, ew, eh); // 右上
		    // Lines.rect(x, y, ew, eh); // 左下
		    // Lines.rect(x, y + th - eh, ew, eh); // 左上
		    
		    Lines.rect(x + ew, y + eh, rectWidth, rectHeight); // 中心矩形
		    Draw.reset();
		    
		    // 绘制一些图标提示
		    let halfX = x + tw/2, halfY = y + th/2;
		    let size = 32;
		    
		    Draw.rect(Icon.up.getRegion(), halfX, y + th - eh/2, size, size);
		    Draw.rect(Icon.down.getRegion(), halfX, y + eh/2, size, size);
		    Draw.rect(Icon.left.getRegion(), x + ew/2, halfY, size, size);
		    Draw.rect(Icon.right.getRegion(), x + tw - ew/2, halfY, size, size);
		    
		    Draw.reset();
        },
        
    });
    
    background.touchable = Touchable.disabled;
    background.setFillParent(true);
}

function initConfirmTable(){
    confirmTable = new Table();
    
    let c = Tmp.c1.set(Pal.accent);
    c.a = 0.55;
    confirmTable.background(Tex.whiteui.tint(c));
    
    confirmTable.button("@confirm", Icon.ok, 64, () => {
        disableEdit();
    }).size(128, 64);
    
    confirmTable.pack();
    
    let h = confirmTable.getHeight();
    confirmTable.setPosition(Core.scene.getWidth()/2, h/2, Align.center);
    confirmTable.update(() => {
        if(!Vars.state.isGame()){
            disableEdit();
        }
    })
}

function enableEdit(e){
    if(background == null){
        initBackground();
    }
    
    if(confirmTable == null){
        initConfirmTable();
    }
    
    target = e;
    editMode = true;
    
    Core.scene.add(background);
    Core.scene.add(confirmTable);
}

function disableEdit(){
    target = null;
    editMode = false;
    
    background.remove();
    confirmTable.remove();
    
    horizontalLines.clear();
    verticalLines.clear();
}

function savePosition(e){
    let {name} = e;
        
    if(name == null){
        throw new Error("If you want to save position for element, please name your element");
    }
    
    let floatx = java.lang.Float(e.x);
    let floaty = java.lang.Float(e.y);
    Core.settings.put("ui-" + name + "-lastPosition-x", floatx);
    Core.settings.put("ui-" + name + "-lastPosition-y", floaty);
}

function readPosition(e){
    let {name} = e;
        
    if(name == null){
        throw new Error("If you want to read position for element, please name your element");
    }
    
    let x = Core.settings.getFloat("ui-" + name + "-lastPosition-x", e.x);
    let y = Core.settings.getFloat("ui-" + name + "-lastPosition-y", e.y);
    
    e.setPosition(x, y);
}

function saveSize(e){
    let {name} = e;
        
    if(name == null){
        throw new Error("If you want to save size for element, please name your element");
    }
    
    let floatw = java.lang.Float(e.getWidth());
    let floath = java.lang.Float(e.getHeight());
    Core.settings.put("ui-" + name + "-lastSize-w", floatw);
    Core.settings.put("ui-" + name + "-lastSize-h", floath);
}

function readSize(e){
    let {name} = e;
        
    if(name == null){
        throw new Error("If you want to read size for element, please name your element");
    }
    
    let w = Core.settings.getFloat("ui-" + name + "-lastSize-w", e.getWidth());
    let h = Core.settings.getFloat("ui-" + name + "-lastSize-h", e.getHeight());
    
    e.setSize(w, h);
}

function updateDragAlign(){    
    let tx = target.x, ty = target.y;
    let tw = target.getWidth(), th = target.getHeight();
    
    let tleft = tx; // 目标元素左端线的x
    let tright = tx + tw; // 目标元素右端线的x
    let tbottom = ty; // 目标元素下端线的y
    let ttop = ty + th; // 目标元素上端线的y
    
    alignmentElements.each(element => {
        if(target == element || !element.visible){
            return;
        }
    
        let {x, y} = element;
        let ew = element.getWidth();
        let eh = element.getHeight();
        
        let v1 = element.localToStageCoordinates(Tmp.v1.set(0, 0));
        
        let left = v1.x;
        let right = v1.x + ew;
        let bottom = v1.y;
        let top = v1.y + eh;
        
        if(Math.abs(tleft - left) <= alignmentRange){
            target.setPosition(left, ty);
            verticalLines.add(left);
        }else if(Math.abs(tright - left) <= alignmentRange){
            target.setPosition(left - tw, ty);
            verticalLines.add(left);
        }
                
        if(Math.abs(tleft - right) <= alignmentRange){
            target.setPosition(right, ty);
            verticalLines.add(right);
        }else if(Math.abs(tright - right) <= alignmentRange){
            target.setPosition(right - tw, ty);
            verticalLines.add(right);
        }
        
        tx = target.x;
        ty = target.y;
        
        if(Math.abs(ttop - bottom) <= alignmentRange){
            target.setPosition(tx, bottom - th);
            horizontalLines.add(bottom);
        }else if(Math.abs(tbottom - bottom) <= alignmentRange){
            target.setPosition(tx, bottom);
            horizontalLines.add(bottom);
        }
                
        if(Math.abs(ttop - top) <= alignmentRange){
            target.setPosition(tx, top - th);
            horizontalLines.add(top);
        }else if(Math.abs(tbottom - top) <= alignmentRange){
            target.setPosition(tx, top);
            horizontalLines.add(top);
        }
    });
    
    target.keepInStage();
}

function updateResizeAlign(){

}