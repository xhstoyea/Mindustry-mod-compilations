let mod = Vars.mods.getMod(modName);

mod.meta.author = "[yellow]miner";
mod.meta.description = 
"为PE制作的核心资源显示\n" +
"[sky]2.0日志: 适配136 优化了一下代码[white]\n" + 
"[sky]3.0日志: 应用全新ui对齐 会保存ui位置[white]\n" + 
"[sky]3.1日志: 修复一些bug\n" + 
"[sky]3.5日志: 应用全新ui缩放 会保存ui大小\n" + 
"miner的mod群:757679470";

const editor = require("UIEditor");
const hider = require("UIHider");

var table = new Table();

var usedItems = new ObjectSet();

var player = null;

function setup(){
    table.name = "minerCoreItemsDisplay";
    table.setPosition(0, Core.scene.getHeight()/2);
    table.left();
    
    let listener = editor.createListener(table, true, true);
    hider.addHider(table, listener);
    
    table.addListener(listener);
    table.update(() => {
        table.keepInStage();
    });
	
	let iconSize = Vars.iconSmall;
		
	table.row();
	
	table.table(Styles.black3, itemsTable => {
	    var rebuild = () => {
    		itemsTable.clear();
    		
    		let i = 0;
    		Vars.content.items().each((item) => {
    		    if(!usedItems.contains(item)) return;
    		
    			itemsTable.image(item.uiIcon).scaling(Scaling.fit).grow().minSize(iconSize);
    			
    			itemsTable.label(() => "" + UI.formatAmount(player.core() == null ? 0 : player.core().items.get(item))).growX().padRight(5).minWidth(iconSize + 5);
    			
    			if(++i % 4 == 0) itemsTable.row();
    		});
    		
    		pack(table);
    	};
    	
    	itemsTable.update(t => {
    		Vars.content.items().each(item => {
    			if(player.core() != null && player.core().items.get(item) > 0 && usedItems.add(item)){
    			    rebuild();
    			}
    		});
    	});
	}).grow();
	
	table.row();
	
    table.table(Styles.black3, info => {
        let addInfo = (icon, l) => {
    	    info.image(icon).scaling(Scaling.fit).size(iconSize);
    	    info.label(l).padRight(5).get();
    	}
    	
    	addInfo(Blocks.coreNucleus.uiIcon, () => player.team().cores().size + "");
        addInfo(UnitTypes.gamma.uiIcon, () => {
            let team = player.team();
            return"[#" + team.color + "]" + countPlayer(team) + "[]/[accent]" + Groups.player.size();
        });
    }).growX();
}

Events.on(ResetEvent, e => {
	usedItems.clear();
});

Events.on(EventType.ClientLoadEvent, cons(e => {
    player = Vars.player;
    
	setup();
	
	Vars.ui.hudGroup.addChild(table);
}));

function countUnit(unitType, team){
	return team.data().countType(unitType);
}

function countPlayer(team){
	return team.data().players.size;
}

function pack(e){
    let w = Math.max(e.getWidth(), e.getMinWidth());
    let h = Math.max(e.getHeight(), e.getMinHeight());
    e.setSize(w, h);
}