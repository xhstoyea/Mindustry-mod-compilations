const editor = require("UIEditor");
const input = require("InputListener");

var hidden = new Seq();
var editTable = new Table();

function addHider(e, editListener){
    e.touchablility = () => editor.isEditing(e) ? Touchable.enabled : Touchable.disabled;
    
    hidden.add({
        element: e,
        listener: editListener,
    });
}

function showEditButton(obj){
    let e = obj.element;
    let listener = obj.listener;

    editTable.clear();
    
    editTable.button(Icon.edit, Styles.cleari, () => {
        listener.enableEdit();
        hideTable();
    }).grow();
    
    let width = e.getWidth(),
        height = e.getHeight();
    
    let v = e.localToStageCoordinates(Tmp.v1.set(width/2, 0));
    
    let x = v.x, y = v.y;
    if(y < Core.scene.getHeight()/2){
        y += height + 32;
    }
    
    Core.scene.add(editTable);
    editTable.setSize(width, 32);
    editTable.setPosition(x, y, Align.top);
    editTable.validate();
    
    editTable.update(() => {
        if(!Vars.state.isGame()){
            hideTable();
        }
    });
    
    editTable.actions(
        Actions.fadeIn(1),
        Actions.delay(1),
        Actions.fadeOut(1),
        Actions.remove()
    );
    editTable.act(0);
}

function hideTable(){
    editTable.clearActions();
    editTable.actions(
        Actions.fadeOut(1), 
        Actions.remove()
    );
}

Events.on(ClientLoadEvent, e => {
    input.addEvent(input.EVENT_TOUCH_UP, e => {
        if(hidden.isEmpty()) return;
        
        let {x, y, point, keyCode} = e;
    
        for(let i = 0, size = hidden.size; i < size; i++){
            let obj = hidden.get(i);
            
            let e = obj.element;
            let {parent, visible} = e;
            
            if(parent == null || !visible) return;
            
            let v = e.screenToLocalCoordinates(Tmp.v1.set(x, y));
            if(hitElement(e, v.x, v.y)){
                showEditButton(obj);
                break;
            }
        }
    });
});

module.exports = {
    addHider: addHider,
}

function hitElement(e, x, y){
    let trans = e.translation;
    let width = e.getWidth(), height = e.getHeight();
    return x >= trans.x && x < width + trans.x && y >= trans.y && y < height + trans.y;
}