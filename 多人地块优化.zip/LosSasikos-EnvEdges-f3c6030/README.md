# Environment's Edges
This texture pack adds "edges" to some environment blocks. Thats all lol.
