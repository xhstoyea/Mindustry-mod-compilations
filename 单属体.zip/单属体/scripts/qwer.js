//信息栏
//进游戏显示 搬运请勿移除版权等声明信息
Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("[red]单属体信息栏");
    dialog.cont.image(Core.atlas.find("单属体-图片")).row();;
    dialog.buttons.defaults().size(210, 64);
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(210, 64);
    dialog.cont.pane((() => {
        var table = new Table();   
         table.add("[green]当前版本2.2.0").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
table.button("[blue]加QQ群", run(() => {
    var dialog2 = new BaseDialog("[blue]单属体模组[white]QQ[blue]群二维码");
    var table = new Table();
    dialog2.cont.image(Core.atlas.find("单属体-二维码")).row();;
    dialog2.buttons.defaults().size(210, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 64);
       dialog2.show();
    })).size(210, 64).row();
table.button("[red]更新日志", run(() => {
    var dialog2 = new BaseDialog("[red]更新日志");
    var table = new Table();
	
	var t = new Table();
	t.add("[red]----更新日志----\n[blue]\n6月23日,更新了核电");
    dialog2.cont.add(new ScrollPane(t)).size(500, 600).row();
    dialog2.buttons.defaults().size(620, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 64);
       dialog2.show();
    })).size(210, 64).row();//return table;
table.button("[red]mod剧情", run(() => {//0
    var dialog2 = new BaseDialog("[red]mod剧情");
    var table = new Table();
	
	var t = new Table();
	t.add("没有剧情可写，不想写剧情");
    dialog2.cont.add(new ScrollPane(t)).size(500, 810).row();
    dialog2.buttons.defaults().size(210, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 64);
       dialog2.show();
    })).size(210, 64);//1
        return table;
    })()).grow().center().maxWidth(620);
    dialog.show();
}));
//新科技作者提供
//由zxs的模组研究后,自己制作而成