const library = require("base/library");
const 沙铜工作台 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "沙铜工作台", [
  {
    input: {
      items: ["copper/5"],     
    },
    output: {
      items: ["单属体-铜钻头/1"],
    },
    craftTime: 15.5,
  }, 
]);
//copper=铜,lead=铅,metaglass=钢化玻璃,graphite=石墨,sand=沙子,coal=煤,titanium=钛,thorium=钍,scrap=废料,silicon=硅,plastanium=孢子,phase-fabric=相织位物,surge-alloy=合金,spore-pod=塑钢,blast-compound=爆炸混合物,pyratite=硫