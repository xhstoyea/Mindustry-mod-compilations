require('qwer');
require('替换背景');
require('沙铜工作台');
require('SFitems');
require('Planet');