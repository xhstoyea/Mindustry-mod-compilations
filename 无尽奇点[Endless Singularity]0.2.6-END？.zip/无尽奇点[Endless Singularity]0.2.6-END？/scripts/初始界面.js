//信息栏
//进游戏显示 搬运请勿移除版权等声明信息
Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("[purple]无尽奇点");
    dialog.cont.image(Core.atlas.find("无尽奇点-图标")).row();;
    dialog.buttons.defaults().size(210, 64);
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(210, 64);
    dialog.cont.pane((() => {
        var table = new Table();   
         table.add("我们将重做本mod\n这将会是最后一个版本\n  \n[green]这是一个富有挑战性的MOD，我们已经尽可能将难度最大化，另外，祝您玩的愉快！\n  \n[blue]下载群号:\n混沌-奇点(主群):242384028\n铜-奇点(一号分群):595152276\n \n[red]内测群号:470398205(请确定你有这个实力进，进群问题非常阴间) ").left().growX().wrap().width(600).maxWidth(1000).pad(5).labelAlign(Align.left);
        table.row();
        
table.button("[green]更新日志", run(() => {
    var dialog2 = new BaseDialog("[green]更新日志");
    var table = new Table();
	
	var t = new Table();
	t.add("\n目前内容总数:尚未统计\n[blue]0.2.5\n[green]1. ui修复\n[blue]0.2.5\n[green]1.零号地区,雪山荒原,冲击区0078地图整改\n2.新增T2系列少量单位\n[red]3.新增boss[天昭]4.新增古代炮台-火葬炮[blue]5.平衡性整改\n[blue]0.2.4\n[green]1.二阶段地图整改(污染区重做)\n2.新增T2系列少量单位及T2兵工厂\n[blue]0.2.32\n[green]1.核心建造机工厂削弱3.新增 进阶核心\n[blue]0.2.31\n[green]1.部分平衡性调整及BUG修复\n[blue]0.2.3公测板\n[green]1.部分平衡性调整及BUG修复\n2.增加 更好的物流设备,电力设备及炮台\n[red]3.新增新战役 物流旧区\n4.新增BOSS 观星台\n[blue]0.2.2\n[green]1.部分平衡性调整及BUG修复\n2.增加 大量新内容\n[red]3.新增新战役 污染区 冲击区0078\n[purple]4.新增加BOSS 奇点 原型机\n[green]4.部分贴图重作\n[blue]0.2.1\n[green]1.部分平衡性调整及BUG修复\n2.增加新的炮台 革新 ,单位 狂战士,以及新的物流系统和核心\n[red]3.区块重调,并且新增新战役 雪沙谷\n[blue]0.2.0\n[green]1.平衡性超巨幅度修改\n2.赤潮 重做\n3.新增成就系统 ");
    dialog2.cont.add(new ScrollPane(t)).size(500, 600).row();
    dialog2.buttons.defaults().size(210, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 64);
       dialog2.show();
    })).size(210, 64).row();//return table;
    
    	table.button(" MOD设定(暂无)", run(() => {
    var dialog2 = new BaseDialog(" MOD设定(暂无)");
    var table = new Table();
	
	var t = new Table();
	t.add("\n无");
    dialog2.cont.add(new ScrollPane(t)).size(500, 600).row();
    dialog2.buttons.defaults().size(210, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 64);
       dialog2.show();
    })).size(210, 64).row();//return table;
    
table.button("[yellow]关于MOD", run(() => {//0
    var dialog2 = new BaseDialog("[yellow]关于MOD");
    var table = new Table();
	var t = new Table();
	t.add(" \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n  \n \n \n \n \n \n开发人员:\n[green]没有炮台的炮台S(主作者)\n[blue]蓝细菌光合自养(地图作者/平衡性测试者)\n[red]Mr.世纪灯泡(贴图绘图师)\n \n[red]至谢名单:  \n[yellow]一只gamma(工业时代mod作者)-代码指导\n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n[red]抄袭moder刺杀名单\n1.星流之神(by魔君·亚利姆[B站账号:像素6] QQ:1776695329\n[此mod作者正在重置] \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n ");
    dialog2.cont.add(new ScrollPane(t)).size(500, 810).row();
    dialog2.buttons.defaults().size(210, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 64);
       dialog2.show();
    })).size(210, 64);//1
        return table;
        
    })()).grow().center().maxWidth(620);
    dialog.show();
}));
//新科技作者提供