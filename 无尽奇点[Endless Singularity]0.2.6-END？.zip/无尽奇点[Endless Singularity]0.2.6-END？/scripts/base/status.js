exports.amodname = "无尽奇点"
exports.getStatus = function (腐蚀){
return Vars.content.statusEffect(exports.amodname + "-" + 腐蚀);
}
exports.getStatus = function (燃烧){
return Vars.content.statusEffect(exports.amodname + "-" + 燃烧);
}
exports.getStatus = function (潮湿){
return Vars.content.statusEffect(exports.amodname + "-" + 潮湿);
}
exports.getStatus = function (融化){
return Vars.content.statusEffect(exports.amodname + "-" + 融化);
}
exports.getStatus = function (防御){
return Vars.content.statusEffect(exports.amodname + "-" + 防御);
}
exports.getStatus = function (冰冻){
return Vars.content.statusEffect(exports.amodname + "-" + 冰冻);
}
exports.getStatus = function (脆裂){
return Vars.content.statusEffect(exports.amodname + "-" + 脆裂);
}
exports.getStatus = function (胶化){
return Vars.content.statusEffect(exports.amodname + "-" + 胶化);
}
exports.getStatus = function (无){
return Vars.content.statusEffect(exports.amodname + "-" + 无);
}

const 腐蚀 = extend(StatusEffect, "腐蚀", {
    init() {
        this.opposite(冰冻, 防御, 燃烧, 融化, 胶化);//这里是写排斥，可以逗号隔开写多个

        //这里写反应，尽量和自己的效果反应，反应的效果接口reactive要为true，且其他效果不建议写
        this.affinity(脆裂, (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            //反应发生时如果要有特效，这是一个例子
            Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
            //也可以写其他的，unit就是收到反应带了结果的单位
            //举例，下面是检测生成队伍来执行爆破与冰冻的反应
            /*if(unit.team == state.rules.waveTeam){
                Events.fire(Trigger.blastFreeze);
            }*/

            //这里是设置最终反应结果
            // 如果反应元素不为result且reactive为true，它的所有作用（包括单位左上角显示）在反应时全部失去作用
            //time是反应时长
            result.set(s1, Math.min(time + result.time, 60));
        }
        this.affinity(潮湿, (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
            result.set(s1, Math.min(time + result.time, 60));
        });
    }
});
//剩下的是自定义接口，包括且不限于color，damage等，就不举例了
//还有不要和我一样在代码里写中文！因为不方便编译
const 燃烧 = extend(StatusEffect, "燃烧", {
    init() {
        this.opposite(潮湿, 冰冻, 腐蚀);
        this.affinity(胶化,  (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
 
            result.set(s1, Math.min(time + result.time, 60));
        });
    }
});
const 潮湿 = extend(StatusEffect, "潮湿", {
    init() {
        this.opposite(燃烧, 防御, 融化);
        this.affinity(腐蚀,  (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
 
            result.set(s1, Math.min(time + result.time, 60));
        });
    }
});
const 融化 = extend(StatusEffect, "融化", {
    init() {
        this.opposite(潮湿, 冰冻, 腐蚀);
        this.affinity(胶化,  (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
 
            result.set(s1, Math.min(time + result.time, 60));
        });
    }
});
const 防御 = extend(StatusEffect, "防御", {
    init() {
        this.opposite(冰冻, 腐蚀, 融化, 脆裂);
        this.affinity(无,  (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
 
            result.set(s1, Math.min(time + result.time, 0));
        });
    }
});
const 冰冻 = extend(StatusEffect, "冰冻", {
    init() {
        this.opposite(燃烧, 防御);
        this.affinity(无,  (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
 
            result.set(s1, Math.min(time + result.time, 60));
        });
    }
});
const 脆裂 = extend(StatusEffect, "脆裂", {
    init() {
        this.opposite(融化, 防御);
        this.affinity(无,  (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
 
            result.set(s1, Math.min(time + result.time, 60));
        });
    }
});
const 胶化 = extend(StatusEffect, "胶化", {
    init() {
        this.opposite(腐蚀);
        this.affinity(燃烧, (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
 
            result.set(s1, Math.min(time + result.time, 60));
        }
        this.affinity(融化, (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
 
            result.set(s1, Math.min(time + result.time, 60));
        });
    }
});
const 无 = extend(StatusEffect, "无", {
    init() {
        this.opposite(无);
        this.affinity(防御, (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
 
            result.set(s1, Math.min(time + result.time, 0));
        }
        this.affinity(脆裂, (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
 
            result.set(s1, Math.min(time + result.time, 0));
        }
        this.affinity(冰冻, (unit, result, time) => {
            unit.damagePierce(this.transitionDamage);
            Fx.burning.at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
 
            result.set(s1, Math.min(time + result.time, 0));
        });
    }
});


exports.腐蚀 = 腐蚀;
exports.燃烧 = 燃烧;
exports.潮湿 = 潮湿;
exports.融化 = 融化;
exports.防御 = 防御;
exports.冰冻 = 冰冻;
exports.脆裂 = 脆裂;
exports.胶化 = 胶化;
exports.无 = 无;