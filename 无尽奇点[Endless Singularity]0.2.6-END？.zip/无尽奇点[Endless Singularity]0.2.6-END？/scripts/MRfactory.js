//作者 blac8
//使用方法:将这个js扔进你mod的scripts文件夹
//然后看栗子
//crafted customVaild customVaildP用于自定义
const factory={
    def:{
        acceptItem(item,tile,source){
            for(var i=0;i<this.recipes.length;i++){
                for(var j=0;j<this.recipes[i].input.length;j++){
                    if(item==this.recipes[i].input[j].item&&tile.entity.items.get(this.recipes[i].input[j].item)<this.itemCapacity)
                        return true;
                }
            }return false;
        },consVaild(entity,recipes){
            const recipe=this.recipes[recipes];
            for(var i=0;i<recipe.input.length;i++){
                if(entity.items.get(recipe.input[i].item)<recipe.input[i].amount){
                    return false;
                }
            }return true;
        },canOutput(entity,recipes){
            recipe=this.recipes[recipes];
            for(var i=0;i<recipe.output.length;i++){
                if(entity.items.get(recipe.output[i].item)+recipe.output[i].amount>this.itemCapacity){
                    return false;
                }
            }return true;
        },update(tile){
            const entity=tile.ent();
            if(entity.recipe==-1){
                for(var i=0;i<this.recipes.length;i++){
                    if(this.consVaild(entity,i)&&this.canOutput(entity,i)&&this.customVaild(tile,i)){
                        entity.recipe=i;break;
                    }
                }
            }else if(entity.recipe>-1&&this.consVaild(entity,entity.recipe)&&this.canOutput(entity,entity.recipe)&&this.customVaild(tile,entity.recipe)){
                if(this.customVaildP(tile,entity.recipe))
                    entity.progress+=1/this.recipes[entity.recipe].time;
                if(entity.progress>1){
                    for(var i=0;i<this.recipes[entity.recipe].input.length;i++){
                        entity.items.remove(this.recipes[entity.recipe].input[i].item,this.recipes[entity.recipe].input[i].amount);
                    }for(var i=0;i<this.recipes[entity.recipe].output.length;i++){
                        entity.items.add(this.recipes[entity.recipe].output[i].item,this.recipes[entity.recipe].output[i].amount);
                    }this.crafted(tile,entity.recipe);
                    entity.progress=0;
                    entity.recipe=-1
                }
            }else{
                entity.progress=0;
                entity.recipe=-1;
            }
            for(var i=0;i<this.recipes.length;i++){
                for(var j=0;j<this.recipes[i].output.length;j++){
                    this.tryDump(tile,this.recipes[i].output[j].item);
                }
            }
        },crafted(tile,recipe){
            return;
        },customVaild(tile,recipe){
            return true;
        },customVaildP(tile,recipe){
            return true;
        }
    },
    entity:prov(()=>extend(TileEntity,{
        getprogress(){return this._progress},
        setprogress(value){this._progress=value},
        _progress:0,
        getrecipe(){return this._recipe},
        setrecipe(value){this._recipe=value},
        _recipe:-1,
        write(stream){
            this.super$write(stream);
            stream.writeFloat(this._progress);
            stream.writeByte(this._recipe);
        },
        read(stream,revision){
            this.super$read(stream,revision);
            this._progress=stream.readFloat();
            this._recipe=stream.readByte();
        }
    }))
}
module.exports={
	extendContent:function(name,def){
        const factorydef=Object.create(factory.def);
        const block=extendContent(Block,name,Object.assign(factorydef,def));
        Object.assign(block,{
            update:true,
            soild:true,
            hasItems:true,
            entityType:factory.entity
        });
        return block;
    }
}