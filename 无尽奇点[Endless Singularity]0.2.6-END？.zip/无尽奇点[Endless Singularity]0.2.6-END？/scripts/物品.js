function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("铜")
newItem("铅")
newItem("石墨")
newItem("废料")
newItem("铁")
newItem("钢")
newItem("煤")
newItem("硅")
newItem("钢化玻璃")
newItem("沙")
newItem("石英")
newItem("硫")
newItem("波动合金")
newItem("硅晶玻璃")
newItem("碳钢")
newItem("钛")