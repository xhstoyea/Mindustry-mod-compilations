MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 5000
require("液体")
require("物品")
require("初始界面")

require("base/status")