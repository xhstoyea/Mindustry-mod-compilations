const lib = require("base/xmblib");
//const 核心 = require("方块/核心/恢复核心");
const colorSrc = Liquids.water.color;
const colorDst = Pal.heal;

const LLSZX2 = new Planet("LLSZX2", Planets.sun, 1, 3);
Object.assign(LLSZX2, {
	generator: extend(SerpuloPlanetGenerator,  {
		allowLanding(sector){return false},
getColor(position){
            // 种子 叠加数量 坚持(每次叠加振幅乘率) 频率 坐标
            let noise = Simplex.noise3d(this.seed, 7, 0.8, 1/3, position.x, position.y, position.z);
            if(noise > 0.6){
                return colorDst;
            }
            let deep = Simplex.noise3d(this.seed, 8, 0.5, 1, position.x, position.y, position.z);
            return Tmp.c1.set(colorSrc).lerp(Color.black, deep);
        },
        generateSector(sector){
            this.super$generateSector(sector);
        },
    }),
	meshLoader: prov(() => new HexMesh(LLSZX2, 4)),
	cloudMeshLoader: () => new MultiMesh(
		new HexSkyMesh(LLSZX2, 2, 0.15, 0.14, 5, Color.valueOf("FFFFFF"), 2, 0.42, 1, 0.45)
	),
	atmosphereColor: Color.valueOf("88A4FFFF"),
	landCloudColor: Color.valueOf("FFFFFF"),
	atmosphereRadIn: 0.02,
	atmosphereRadOut: 0.3,
	visible: true,
	bloom: false,
	accessible: true,
	alwaysUnlocked: true,
	startSector: 1,
	camRadius: 0.5,
	orbitRadius: 75,
	orbitSpacing: 2,
	orbitTime: 240 * 60,
	rotateTime: 15 * 60,
	iconColor: Color.valueOf("FFFFFF"),
})
LLSZX2.ruleSetter = r => {
	r.attributes.set(Attribute.heat, -0.3);
	r.attributes.set(Attribute.light, -0.3);
}
LLSZX2.totalRadius += 2.6;
LLSZX2.hiddenItems.addAll(
	Items.scrap,
	Items.copper,
	Items.lead,
	Items.titanium,
	Items.thorium,
	Items.silicon,
	Items.plastanium,
	Items.phaseFabric,
	Items.surgeAlloy,
	Items.sporePod,
	Items.sand,
	Items.blastCompound,
	Items.pyratite,
	Items.metaglass,
	Items.beryllium,
	Items.tungsten,
	Items.oxide,
	Items.carbide,
	Items.fissileMatter,
	Items.dormantCyst
);
exports.LLSZX2 = LLSZX2;

const 起始前哨 = new SectorPreset("起始前哨", LLSZX2, 1);//名字 星球 区块
起始前哨.description = "这里位置偏远，敌人很少，且资源充足，是最佳的降落点。尊敬的指挥官，请尽快在这里建造基地以及防线，抵御敌人的进攻！";
起始前哨.difficulty = 1;//1-10
起始前哨.alwaysUnlocked = true;//总是解锁
起始前哨.addStartingItems = false;//允许添加初始资源
起始前哨.captureWave = 10;//多少波可占领
起始前哨.localizedName = "起始前哨";
exports.起始前哨 = 起始前哨;
lib.addToResearch(起始前哨, {
	parent: "groundZero",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});

const 荒芜沙谷 = new SectorPreset("荒芜沙谷", LLSZX2, 2);//名字 星球 区块
起始前哨.description = "这里十分干旱，生物难以生存，所以敌人防线并不强大。研发生物培养机，尝试进攻敌人！";
荒芜沙谷.difficulty = 2;//1-10
荒芜沙谷.alwaysUnlocked = false;//总是解锁
荒芜沙谷.addStartingItems = true;//允许添加初始资源
荒芜沙谷.localizedName = "荒芜沙谷";
exports.荒芜沙谷 = 荒芜沙谷;
lib.addToResearch(荒芜沙谷, {
	parent: "起始前哨",
	objectives: Seq.with(
		new Objectives.SectorComplete(起始前哨))
});

/*Planets.serpulo.hiddenItems.addAll(
	item.organosand,
	item.biomass,
	item.ossature,
	item.nickel,
	item.manganese,
	item.crystal,
	item.biomassSteel,
	item.organosilicon,
	item.neoplasmSteel,
	item.methylSulfone
);
Planets.erekir.hiddenItems.addAll(
	item.organosand,
	item.biomass,
	item.ossature,
	item.nickel,
	item.manganese,
	item.crystal,
	item.biomassSteel,
	item.organosilicon,
	item.neoplasmSteel,
	item.methylSulfone
);
*/
