const 超核处理器核心 = extend(CoreBlock, "超核处理器核心", {
    
    canBreak() {return true;},
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) { return true; },
});
exports.超核处理器核心 = 超核处理器核心;