const 阿牛 = extend(CoreBlock, "阿牛", {
    
    canBreak() {return false;},
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) { return true; },
});
exports.阿牛 = 阿牛;