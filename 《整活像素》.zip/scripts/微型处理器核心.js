const 微型处理器核心 = extend(CoreBlock, "微型处理器核心", {
    
    canBreak() {return true;},
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) { return true; },
});
exports.微型处理器核心 = 微型处理器核心;