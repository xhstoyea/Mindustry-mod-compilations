const 逻辑处理器核心 = extend(CoreBlock, "逻辑处理器核心", {
    
    canBreak() {return true;},
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) { return true; },
});
exports.逻辑处理器核心 = 逻辑处理器核心;