const library = require("library");
const 小卖部 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "小卖部", [
  {
    input: {
      items: ["aughhhh-零钱/1"],     
      power: 0,
    },
    output: {
      items: ["aughhhh-豆皮/2"],
    },
    craftTime: 60,
  }, 
  {
    input: {
      items: ["aughhhh-零钱/5"],     
      power: 0,
    },
    output: {
      items: ["aughhhh-三鲜伊面/1"],
    },
    craftTime: 60,
  },
  {
    input: {
      items: ["aughhhh-零钱/8"],     
      power: 0,
    },
    output: {
      items: ["aughhhh-小蛋糕/1"],
    },
    crafttime: 60,
    },
  {
    input: {
      items: ["aughhhh-零钱/1"],     
      power: 0,
    },
    output: {
      items: ["aughhhh-霸王丝/1"],
    },
    craftTime: 60,
    },
  {
    input: {
      items: ["aughhhh-零钱/1"],     
      power: 0,
    },
    output: {
      items: ["aughhhh-海螺因/1"],
    },
    craftTime: 60,
    },
  {
    input: {
      items: ["aughhhh-零钱/3"],     
      power: 0,
    },
    output: {
      items: ["aughhhh-健力宝/1"],
    },
    craftTime: 60,
    },
  {
    input: {
      items: ["aughhhh-零钱/1"],     
      power: 0,
    },
    output: {
      items: ["aughhhh-石油辣条/1"],
    },
    craftTime: 60,
    },
  {
    input: {
      items: ["aughhhh-零钱/5"],     
      power: 0,
    },
    output: {
      items: ["aughhhh-旭日升/1"],
    },
    craftTime: 60,
    },      
]);  