const lib = require("base/lib");
const LLSZX = new Planet("愣溜双子星", Planets.sun, 1, 3);
const colorSrc = Items.sand.color;
const colorDst = Pal.heal;

LLSZX.meshLoader = prov(() => new MultiMesh(
	new HexMesh(LLSZX, 8)
));
Object.assign(LLSZX, {
	generator: extend(SerpuloPlanetGenerator,  {
		allowLanding(sector){return false},
getColor(position){
            // 种子 叠加数量 坚持(每次叠加振幅乘率) 频率 坐标
            let noise = Simplex.noise3d(this.seed, 7, 0.8, 1/3, position.x, position.y, position.z);
            if(noise > 0.6){
                return colorDst;
            }
            let deep = Simplex.noise3d(this.seed, 8, 0.5, 1, position.x, position.y, position.z);
            return Tmp.c1.set(colorSrc).lerp(Color.black, deep);
        },
        generateSector(sector){
            this.super$generateSector(sector);
        },
    }),
	meshLoader: prov(() => new HexMesh(LLSZX, 4)),
	cloudMeshLoader: () => new MultiMesh(
		new HexSkyMesh(LLSZX, 2, 0.15, 0.14, 5, Color.valueOf("FFFFFF"), 2, 0.42, 1, 0.45)
	),
	atmosphereColor: Color.valueOf("88A4FFFF"),
	landCloudColor: Color.valueOf("FFFFFF"),
	atmosphereRadIn: 0.02,
	atmosphereRadOut: 0.3,
	visible: true,
	bloom: false,
	accessible: true,
	alwaysUnlocked: true,
	startSector: 1,
	camRadius: 0.5,
	orbitRadius: 75,
	orbitSpacing: 2,
	orbitTime: 240 * 60,
	rotateTime: 15 * 60,
	iconColor: Color.valueOf("FFFFFF"),
})
LLSZX.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(LLSZX, 2, 0.15, 0.14, 5, Color.valueOf("D3AE8DFF"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(LLSZX, 3, 0.6, 0.15, 5, Color.valueOf("F7CBA4FF"), 2, 0.42, 1.2, 0.45)
));
LLSZX.visible = LLSZX.accessible = LLSZX.alwaysUnlocked = LLSZX.clearSectorOnLose = true;
LLSZX.tidalLock = false;
LLSZX.localizedName = "愣溜双子星";
LLSZX.atmosphereColor = LLSZX.lightColor = Color.valueOf("25C9AB90");
LLSZX.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);
//愣溜双子星.generator = new CPG;

const 起始前哨 = new SectorPreset("起始前哨", LLSZX, 1);
起始前哨.description = "NaN数据丢失";
起始前哨.difficulty = 2;
起始前哨.alwaysUnlocked = true;
起始前哨.addStartingItems = true;
起始前哨.captureWave = 0;
起始前哨.localizedName = "起始前哨";
exports.起始前哨 = 起始前哨;
lib.addToResearch(起始前哨, {
	parent: "groundZero",
});

const 荒芜沙谷 = new SectorPreset("荒芜沙谷", LLSZX, 25);
荒芜沙谷.description = "荒芜沙谷";
荒芜沙谷.difficulty = 2;
荒芜沙谷.alwaysUnlocked = false;
荒芜沙谷.addStartingItems = true;
荒芜沙谷.captureWave = 21;
荒芜沙谷.localizedName = "荒芜沙谷";
exports.荒芜沙谷 = 荒芜沙谷;
lib.addToResearch(荒芜沙谷, {
	parent: "起始前哨",
	objectives: Seq.with(
		new Objectives.SectorComplete(起始前哨))
});

const 狭长绿洲 = new SectorPreset("狭长绿洲", LLSZX, 50);
狭长绿洲.description = "我们勘察到了一片绿洲，不过这片绿洲在被沙漠倾食着...\n敌人也很奇怪...";
狭长绿洲.difficulty = 2;
狭长绿洲.alwaysUnlocked = false;
狭长绿洲.addStartingItems = true;
狭长绿洲.captureWave = 21;
狭长绿洲.localizedName = "狭长绿洲";
exports.狭长绿洲 = 狭长绿洲;
lib.addToResearch(狭长绿洲, {
	parent: "荒芜沙谷",
	objectives: Seq.with(
		new Objectives.SectorComplete(起始前哨))
});