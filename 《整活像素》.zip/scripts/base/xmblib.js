exports.modName = "aughhhh";
exports.mod = Vars.mods.locateMod(exports.modName);

exports.regenAmount = Stat("regenAmount");
exports.damageReduction = Stat("damageReduction");

exports.addResearch = (content, research) => {
	if (!content) {
		throw new Error('content is null!');
	}
	if (!research.parent) {
		throw new Error('research.parent is empty!');
	}
	let researchName = research.parent;
	let customRequirements = research.requirements;
	let objectives = research.objectives;
	let lastNode = TechTree.all.find(boolf(t => t.content == content));
	if (lastNode != null) {
		lastNode.remove();
	}
	let node = new TechTree.TechNode(null, content, customRequirements !== undefined ? customRequirements : content.researchRequirements());
	if (objectives) {
		node.objectives.addAll(objectives);
	}
	if (node.parent != null) {
		node.parent.children.remove(node);
	}
	// find parent node.
	let parent = TechTree.all.find(boolf(t => t.content.name.equals(researchName) || t.content.name.equals(exports.modName + "-" + researchName)));
	if (parent == null) {
		throw new Error("Content '" + researchName + "' isn't in the tech tree, but '" + content.name + "' requires it to be researched.");
	}
	// add this node to the parent
	if (!parent.children.contains(node)) {
		parent.children.add(node);
	}
	// reparent the node
	node.parent = parent;
}

exports.newBlock = (name, con) => {
	const b = extend(Block, name, con);
	b.solid = b.update = b.destructible = b.configurable = true;
	b.drawDisabled = false;
	b.envEnabled = Env.any;
	b.group = BlockGroup.none;
	b.priority = TargetPriority.base;
	b.category = Category.effect;
	b.buildVisibility = BuildVisibility.shown;
	return b
}

exports.setBuilding = (building, block, con) => {
	block.buildType = prov(() => {
		if (building == Building) {
			return extend(building, con);
		} else {
			return extend(building, block, con);
		}
	})
}

exports.region = (name) => {
	return Core.atlas.find(exports.modName + "-" + name)
}

exports.bundle = (text, num) => {
	if (num) {
		return Core.bundle.format(text, num);
	} else {
		return Core.bundle.get(text);
	}
}

exports.float = (speed, length) => {
	return Mathf.sin(Time.time * speed) * length;
}

function Colour(R, G, B, A) {
	if (G) {
		return new Color(R, G, B, A || 1);
	} else {
		return Color.valueOf(R);
	}
}
exports.Color = Colour;

exports.FF5845 = Colour("FF5845");
exports.FF6666 = Colour("FF6666");

exports.AngleTrns = (ang, rad, rad2) => {
	if (rad2) {
		return {
			x: Angles.trnsx(ang, rad, rad2),
			y: Angles.trnsy(ang, rad, rad2)
		}
	} else {
		return {
			x: Angles.trnsx(ang, rad),
			y: Angles.trnsy(ang, rad)
		}
	}
}

exports.DoubleTri = (x, y, width, length, angle) => {
	Draw.z(Layer.effect);
	Drawf.tri(x, y, width, length, angle + 180);
	Drawf.tri(x, y, width, length / 4, angle);
}

function Halo(obj) {
	let def = {
		fuc: {},
		mirror: false,
		shapeR: 0,
		shapes: 2,
		radius: 4,
		triL: 20,
		haloRad: 50,
		haloRot: 0,
		haloRS: 0,
		color: Colour("FF5845"),
		colorTo: Colour("FF6666")
	}
	for (let k in def) {
		if (obj[k] == undefined) continue
		def[k] = obj[k]
	}
	return Object.assign(extend(HaloPart, def.fuc), {
		mirror: def.mirror,
		tri: true,
		shapeRotation: def.shapeR,
		shapes: def.shapes,
		radius: def.radius,
		triLength: def.triL,
		haloRadius: def.haloRad,
		haloRotation: def.haloRot,
		haloRotateSpeed: def.haloRS,
		color: def.color,
		colorTo: def.colorTo,
		layer: 110
	})
}
exports.Halo = Halo;

exports.DoubleHalo = (unit, obj) => {
	unit.parts.add(
		Halo({
			mirror: obj.mirror,
			shapes: obj.shapes,
			radius: obj.radius,
			triL: obj.triL,
			haloRad: obj.haloRad,
			haloRot: obj.haloRot,
			haloRS: obj.haloRS,
			color: obj.color,
			colorTo: obj.colorTo
		}),
		Halo({
			mirror: obj.mirror,
			shapeR: 180,
			shapes: obj.shapes,
			radius: obj.radius,
			triL: obj.triL / 4,
			haloRad: obj.haloRad,
			haloRot: obj.haloRot,
			haloRS: obj.haloRS,
			color: obj.color,
			colorTo: obj.colorTo
		})
	)
}