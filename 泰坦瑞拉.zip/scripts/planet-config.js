Events.on(ClientLoadEvent, e => {
Planets.tantros.accessible = Planets.tantros.alwaysUnlocked = Planets.tantros.visible = true
Planets.tantros.allowLaunchToNumbered = false
Planets.tantros.allowLaunchLoadout = true
Planets.tantros.defaultCore = Vars.content.block("tantaria-core-pike")
Planets.tantros.generator.defaultLoadout = Schematics.read(Vars.tree.get("schematics/core-pike.msch"));
});


