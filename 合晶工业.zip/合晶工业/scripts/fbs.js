//此代码来自创世神
const 工厂 = require('工厂');
//const {暴风雪} = require('单位');
工厂.次代合晶工厂.buildType = prov(() => {
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
        draw() {
            this.super$draw();
            Draw.blend();
            Draw.color();
            Draw.rect(Core.atlas.find("合晶工业-合晶2-1"), this.x, this.y, 90 - Time.time * 2);
            Draw.rect(Core.atlas.find("合晶工业-合晶2-2"), this.x, this.y, 90 - Time.time * 2);
            Draw.rect(Core.atlas.find("合晶工业-合晶2-3"), this.x, this.y, 90 + Time.time * 2);
            Draw.rect(Core.atlas.find("合晶工业-合晶2-4"), this.x, this.y, 90 + Time.time * 2);            
        },
    }, 工厂.次代合晶工厂);
});
//——————————————————————————————————————
工厂.终代合晶工厂.buildType = prov(() => {
    return new JavaAdapter(GenericCrafter.GenericCrafterBuild, {
        draw() {
            this.super$draw();
            Draw.blend();
            Draw.color();
            Draw.rect(Core.atlas.find("合晶工业-合晶4-1"), this.x, this.y, 45 + Time.time * 3);            
            Draw.rect(Core.atlas.find("合晶工业-合晶4-1"), this.x, this.y, 45 - Time.time * 3);              
        },
    }, 工厂.终代合晶工厂);
});

//---------------------------------------------------------------------------------
const 暴雪机器人 = extend(UnitType, "暴雪机器人", {

   /* draw(unit) {
        this.super$draw(unit);
        Draw.rect(
            "合晶工业-雪花环",
            unit.x + Angles.trnsx(unit.rotation - 90, 0, 0),
            unit.y + Angles.trnsy(unit.rotation - 90, 0, 0),
            Time.time * -1);
    }*/

})
暴雪机器人.constructor = prov(() => extend(UnitTypes.reign.constructor.get().class, {}));
