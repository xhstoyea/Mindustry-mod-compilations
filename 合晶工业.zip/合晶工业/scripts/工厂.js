


const 硅粗制机 = extend(GenericCrafter, "硅粗制机", {});
exports.硅粗制机 = 硅粗制机;

const 硅提纯机 = extend(GenericCrafter, "硅提纯机", {});
exports.硅提纯机 = 硅提纯机;

const 次代合晶工厂 = extend(GenericCrafter, "次代合晶工厂", {});
exports.次代合晶工厂 = 次代合晶工厂;

const 超代合晶工厂 = extend(GenericCrafter, "超代合晶工厂", {});
exports.超代合晶工厂 = 超代合晶工厂;

const 终代合晶工厂 = extend(GenericCrafter, "终代合晶工厂", {});
exports.终代合晶工厂 = 终代合晶工厂;

const 铝墙 = extend(Wall, "铝墙", {});
exports.铝墙 = 铝墙;




const 大型铝墙 = extend(Wall, "大型铝墙", {});
exports.大型铝墙 = 大型铝墙;


const 巨型铝墙 = extend(Wall, "巨型铝墙", {});
exports.巨型铝墙 = 巨型铝墙;


const 锡墙 = extend(Wall, "锡墙", {});
exports.锡墙 = 锡墙;

const 大型锡墙 = extend(Wall, "大型锡墙", {});
exports.大型锡墙 = 大型锡墙;

const 巨型锡墙 = extend(Wall, "巨型锡墙", {});
exports.巨型锡墙 = 巨型锡墙;

const 铝钢墙 = extend(Wall, "铝钢墙", {});
exports.铝钢墙 = 铝钢墙;


const 大型铝钢墙 = extend(Wall, "大型铝钢墙", {});
exports.大型铝钢墙 = 大型铝钢墙;


const 巨型铝钢墙 = extend(Wall, "巨型铝钢墙", {});
exports.巨型铝钢墙 = 巨型铝钢墙;


const 金墙 = extend(Wall, "金墙", {});
exports.金墙 = 金墙;


const 大型金墙 = extend(Wall, "大型金墙", {});
exports.大型金墙 = 大型金墙;


const 巨型金墙 = extend(Wall, "巨型金墙", {});
exports.巨型金墙 = 巨型金墙;

const 赤金墙 = extend(Wall, "赤金墙", {});
exports.赤金墙 = 赤金墙;
/*
const 2级合晶墙 = extend(Wall, "2级合晶墙", {});
exports.2级合晶墙 = 2级合晶墙;

const 1级合晶墙 = extend(Wall, "1级合晶墙", {});
exports.1级合晶墙 = 1级合晶墙;
*/
const 铝质机械泵 = extend(Pump, "铝质机械泵", {});
exports.铝质机械泵 = 铝质机械泵;


const 涡轮泵 = extend(Pump, "涡轮泵", {});
exports.涡轮泵 = 涡轮泵;

const 增压泵 = extend(Pump, "增压泵", {});
exports.增压泵 = 增压泵;

const 超压泵 = extend(Pump, "超压泵", {});
exports.超压泵 = 超压泵;



const 水力发电机 = extend(ImpactReactor, "水力发电机", {});
exports.水力发电机 = 水力发电机;


