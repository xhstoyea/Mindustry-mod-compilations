const 物品 = require("物品");
function newDun(name, ItemStack) {
	let nD = new ForceProjector(name);
	nD.itemConsumer = nD.consumeItems(ItemStack).boost();
	exports[name] = nD;
	return nD;
}

newDun("力墙发生场", ItemStack.with(物品.固态能, 1))
newDun("小型力墙", ItemStack.with(物品.纯硅晶, 1))
newDun("大型力墙", ItemStack.with(物品.金辉合金, 2))