const {基础核心} = require('核心');
const lib = require("lib");
const {凌星} = require('星球');

const {粗硅晶,纯硅晶,废晶,二级废晶,弹性塑钢板,钍晶,铝,锂


} = require('物品');
const {map1,map2,map3,map4


} = require('星球');
const {硅提纯机,硅粗制机} = require('工厂');

凌星.techTree = TechTree.nodeRoot( "凌星", 基础核心, true, run(() => {
/*
lib.addToResearch(硅提纯机, {//3级微晶超速
        parent: "硅粗制机",
        requirements: ItemStack.with(
            铝, 850 / 4 * 200,
            锂, 340 / 4 * 200,
            粗硅晶, 20 / 4 * 200,

        ),
        objectives: Seq.with(
            new Objectives.SectorComplete(map4),//占领-三花聚顶
        ),

    });

*/




}));

			