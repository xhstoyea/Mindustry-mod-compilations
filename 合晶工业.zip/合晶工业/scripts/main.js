Vars.renderer.minZoom = 0.1;
Vars.renderer.maxZoom = 50;
Vars.maxSchematicSize = 256;
require('核心');
require("星球");
require('第三科技'),
require('炮/炮'),
require('工厂'),
require('单位');
require('单位工厂');
require('物品');
require('晶体工厂');
// require('质量流动器');
require('uu');
require('Attribute');
require('ui');
require('drills');
require('发电机');
require('辅助建筑');
require('mapTechTree');//科技树 
require('核心1');
require('fbs');
require("排序/运输")





 