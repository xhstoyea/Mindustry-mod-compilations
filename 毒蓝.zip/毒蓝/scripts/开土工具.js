const 开土工具 = extendContent(CoreBlock, "开土工具", {
    
    canBreak(){return true;},
    canReplace(other){return true;},
    canPlaceOn(tile, team){return true;},
});
exports.开土工具 = 开土工具;