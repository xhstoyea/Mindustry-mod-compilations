const library = require("base/abaaba");
const 矿机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "矿机", [
  {
    input: {
      items: ["coal/5"],     
      power: 2,
    },
    output: {
      items: ["copper/10"],
    },
    craftTime: 6,
  }, 
  {
    input: {
      items: ["coal/5"],     
      power: 2,
    },
    output: {
      items: ["lead/10"],
    },
    craftTime: 6,
  }, 
  {
    input: {
      items: ["coal/5"],     
      power: 2,
    },
    output: {
      items: ["scrap/10"],
    },
    craftTime: 6,
  }, 
  {
    input: {
      items: ["coal/5"],     
      power: 2,
    },
    output: {
      items: ["sand/10"],
    },
    craftTime: 6,
  }, 
  {
    input: {
      items: ["coal/5"],     
      power: 2,
    },
    output: {
      items: ["titanium/10"],
    },
    craftTime: 6,
  }, 
  {
    input: {
      items: ["coal/5"],     
      power: 2,
    },
    output: {
      items: ["spore-pod/10"],
    },
    craftTime: 6,
  }, 
  {
    input: {
      items: ["coal/5"],     
      power: 2,
    },
    output: {
      items: ["thorium/10"],
    },
    craftTime: 6,
  }, 
  
  ]);