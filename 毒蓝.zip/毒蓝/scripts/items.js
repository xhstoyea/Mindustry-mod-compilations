exports.0 = (() => {
var myliquid = extendContent(Liquid, '0', {});
return myliquid;
})();

