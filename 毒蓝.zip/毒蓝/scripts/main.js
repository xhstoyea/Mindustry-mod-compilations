require("创世压缩机");
require("开土工具");
require("矿机");

