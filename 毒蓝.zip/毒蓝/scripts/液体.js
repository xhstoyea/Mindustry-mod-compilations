exports.白 = (() => {
var myliquid = extendContent(Liquid, '白', {});
return myliquid;
})();
