/*感谢神魂大佬*/
const library = require("base/abaaba");
const 创世压缩机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "创世压缩机", [
  {
    input: {
      items: ["coal/100000"],     
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-煤奇原/1"],
    },
    craftTime: 300,
  }, 
  {
    input: {
      items: ["sand/100000"],     
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-沙奇原/1"],
    },
    craftTime: 300,
  }, 
  {
    input: {
      items: ["copper/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-铜奇原/1"],
    },
    craftTime: 300,
  }, 
  {
    input: {
      items: ["lead/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-铅奇原/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      items: ["titanium/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-钛奇原/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      items: ["thorium/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-钍奇原/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      items: ["silicon/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-硅奇原/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      items: ["plastanium/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-塑奇原/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      items: ["surge-alloy/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-巨奇原/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      items: ["phase-fabric/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-相奇原/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      items: ["graphite/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-石奇原/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      items: ["scrap/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-废奇原/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      items: ["metaglass/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-玻奇原/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      items: ["blast-compound/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-爆奇原/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      items: ["pyratite/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-硫奇原/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      items: ["spore-pod/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-孢奇原/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      liquids: ["water/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-水奇以/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      liquids: ["slag/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-矿奇以/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      liquids: ["cryofluid/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-冷奇以/1"],
    },
    craftTime: 300,
  },
  {
    input: {
      liquids: ["oil/100000"], 
      power: 90000,
    },
    output: {
      items: ["[yellow]毒[blue]蓝-石奇以/1"],
    },
    craftTime: 300,
  },
  
  ]);