
const meta = Vars.mods.locateMod("fhsn").meta;
meta.displayName = "[#FFCCFF]梦境";


