    require("fhsnlib");
    require("display");
	require("手摇发电机");
	require("rankT");