const a1 = extend(BasicBulletType,{});
a1.lifetime = 33;
a1.speed = 5;
a1.damage = 60;
a1.width = 12;//子弹宽度
a1.height = 20;//高度？长度？
a1.shrinkY = 0;//缩小？
a1.drag = -0.01;//拖尾？
//a1.homingPower = 0.08;
a1.reloadMultiplier = 2;//开火速率

const 初源 = extend(ItemTurret, "初源", {});
初源.reload = 40;//装填时间？or数量？
初源.shoot.shots = 1;//一次性射击的炮弹？
//初源.burstSpacing = 4;
初源.inaccuracy = 10;//射击误差
初源.range = 200;//8:1
//初源.xRand = 4;
初源.size = 2;
初源.shootSound = Sounds.shootBig;//子弹音效
//初源.health = 200 * 2 * 2;
初源.ammoPerShot = 1;//弹药？
//lib.Coolant(初源, 0.2);
// 初源.limitRange();
初源.ammo(
   // Items.copper, mc,
    //Items.graphite, mg,
   // Items.silicon, a1,
   // Items.pyratite, mp,
    Items.beryllium, a1
);
初源.requirements = ItemStack.with(
    Items.beryllium, 120,
    Items.silicon, 80,
    Items.graphite, 100
);
初源.buildVisibility = BuildVisibility.shown;
初源.category = Category.turret;//显示界面

exports.初源 = 初源;
//以下原数据
/*const a1 = extend(BasicBulletType,{});
a1.lifetime = 33;
a1.speed = 5;
a1.damage = 60;
a1.width = 12;//子弹宽度
a1.height = 20;//高度？长度？
a1.shrinkY = 0;//缩小？
a1.drag = -0.01;//拖尾？
//a1.homingPower = 0.08;
a1.reloadMultiplier = 1.2;//开火速率

const 初源 = extend(ItemTurret, "初源", {});
初源.reload = 40;//装填时间？or数量？
初源.shoot.shots = 8;//一次性射击的炮弹？
//初源.burstSpacing = 4;
初源.inaccuracy = 10;//射击误差
初源.range = 200;//8:1
//初源.xRand = 4;
初源.size = 3;
初源.shootSound = Sounds.shootBig;//子弹音效
//初源.health = 200 * 2 * 2;
初源.ammoPerShot = 1;//弹药？
//lib.Coolant(初源, 0.2);
// 初源.limitRange();
初源.ammo(
   // Items.copper, mc,
    //Items.graphite, mg,
   // Items.silicon, a1,
   // Items.pyratite, mp,
    Items.beryllium, a1
);
初源.requirements = ItemStack.with(
    Items.beryllium, 120,
    Items.silicon, 80,
    Items.graphite, 100
);
初源.buildVisibility = BuildVisibility.shown;
初源.category = Category.turret;//显示界面

exports.初源 = 初源;*/