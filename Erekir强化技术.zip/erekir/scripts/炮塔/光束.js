const myitems = require("物品");

const 光束 = extend(PowerTurret, "光束", {});
光束.reload = 60;//装填时间？or数量？
光束.range = 165;//8:1
光束.size = 2;
光束.shootSound = Sounds.laser;//子弹音效
光束.consumePower(5);

光束.shoot.firstShotDelay = 40;

光束.recoil = 2;
光束.shake = 2;
光束.shootEffect = Fx.lancerLaserShoot;
光束.smokeEffect = Fx.none;
光束.heatColor = Color.red;
光束.targetAir = false;
光束.moveWhileCharging = false;
光束.accurateDelay = false;

光束.buildingDamageMultiplier = 0.25;

光束.hitEffect = Fx.hitLancer;
光束.hitSize = 4;
光束.lifetime = 16;
光束.drawSize = 400;
光束.collidesAir = false;
光束.length = 173;
光束.ammoMultiplier = 1;
光束.pierceCap = 4;

光束.buildVisibility = BuildVisibility.shown;
光束.category = Category.turret;//显示界面

exports.光束 = 光束;