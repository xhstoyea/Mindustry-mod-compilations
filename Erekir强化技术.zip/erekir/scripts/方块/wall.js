const graphiteWall = extend(Wall,"graphiteWall",{});
      graphiteWall.size = 1;
graphiteWall.health = 500;
graphiteWall.absorbLasers = false;//能否吸收激光
graphiteWall.hasPower = true;//允许能源
graphiteWall.consumesPower = false;//消耗能源
graphiteWall.outputsPower = true;//输出能源
graphiteWall.requirements = ItemStack.with(
    Items.graphite, 5
);
graphiteWall.buildVisibility = BuildVisibility.shown;
graphiteWall.category = Category.defense;
exports.graphiteWall = graphiteWall;
//graphiteraphitewall 1 : 100