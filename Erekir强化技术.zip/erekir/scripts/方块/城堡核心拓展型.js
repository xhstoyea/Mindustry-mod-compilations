const 城堡核心拓展型 = extend(CoreBlock, "城堡核心拓展型", {
	setStats() {
		this.super$setStats();
		this.stats.add(Stat.buildTime, this.buildCost / 60, StatUnit.seconds);
	},
	canBreak(tile) {
		return Vars.state.teams.cores(tile.team()).size > 1;
	},
	canReplace(other) {
		return other.alwaysReplace;
	},
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.cores(team).size < 5;
	}
});

城堡核心拓展型.buildType = prov(() => {
	let kill = false, num = 1, time = 60 * num;
	return extend(CoreBlock.CoreBuild, 城堡核心拓展型, {
		updateTile() {
			this.super$updateTile();
			if (Vars.state.teams.cores(this.team).size > 4) kill = true;
			if (kill) {
				Vars.ui.showLabel("[red]警告！警告！警告！空间开始崩溃⚠️", 0.01, this.x, this.y);
				time--
				if (time == 0) {
					this.kill();
				}
			}
		},
		draw() {
			this.super$draw();
			Draw.z(Layer.effect);
			Lines.stroke(2, Pal.accent);
			Draw.alpha(Vars.state.teams.cores(this.team).size > 4 ? 1 : 0);
			Lines.arc(this.x, this.y, 16, time * (6 / num) / 360, 90);
		}
	})
});
    exports.城堡核心拓展型 = 城堡核心拓展型