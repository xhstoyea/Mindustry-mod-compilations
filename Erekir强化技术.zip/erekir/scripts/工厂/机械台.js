const library = require("base/library");
const myitems = require("物品")
const 机械台 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "机械台", [
  {
    input: {
      items: ["tungsten/1"],     
      power: 0.5,
    },
    output: {
      items: ["技术-齿轮/4"],
    },
    craftTime: 60,
  }, 
     {
    input: {
      items: [
      "tungsten/2",
      "surge-alloy/1",
      ],    
      power: 1,
    },
    output: {
      items: ["技术-合金齿轮/2"],
    },
    craftTime: 120,
  },
 ]);
机械台.craftEffect = Fx.pulverizeMedium;
机械台.itemCapacity = 20;
//机械台.liquidCapacity = 60;
机械台.health = 1000;
机械台.size = 4;
机械台.hasItems = true;
机械台.hasLiquids = false;
机械台.hasPower = true;
机械台.requirements = ItemStack.with(
    Items.tungsten, 120,
    Items.silicon, 80,
    Items.graphite, 100
);
机械台.researchCost = ItemStack.with(
Items.tungsten, 1200,
Items.silicon, 800,
Items.graphite, 1000,
);
机械台.buildVisibility = BuildVisibility.shown;
机械台.category = Category.crafting;//显示界面

exports.机械台 = 机械台;
