const library = require("base/library");
const myitems = require("物品")
const 晶化机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "晶化机", [
  {
    input: {
      items: ["silicon/1"],     
      liquids: ["hydrogen/6"],
      power: 6,
    },
    output: {
      items: ["技术-硅晶/1"],
    },
    craftTime: 30,
  }, 
  ]);
晶化机.craftEffect = Fx.pulverizeMedium;
晶化机.itemCapacity = 20;
晶化机.liquidCapacity = 60;
晶化机.health = 520;
晶化机.size = 3;
晶化机.hasItems = true;
晶化机.hasLiquids = true;
晶化机.hasPower = true;
晶化机.requirements = ItemStack.with(
    Items.beryllium, 120,
    Items.silicon, 80,
    Items.graphite, 100
);
晶化机.researchCost = ItemStack.with(
Items.beryllium, 20,
Items.silicon, 10,
Items.graphite, 15,
);
晶化机.buildVisibility = BuildVisibility.shown;
晶化机.category = Category.crafting;//显示界面

exports.晶化机 = 晶化机;
