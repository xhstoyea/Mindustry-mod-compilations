const mod = Vars.mods.locateMod("bsm");
require('stronghold-core');//执行这个文件
require('core-unit');

mod.meta.displayName = "更好的战役";
mod.meta.description = "[red]“原作者已弃坑，现在由我来继续开发”\n如果你们当中有人的话，请给我写封信……[]\n\n[accent]= = = = = 关于模式 = = = = =[]\n\n这是一个极其危险的扩展内容，它会破坏游戏的平衡性和机制。\n\n\n在安装之前最好先保存一份游戏存档（以便可以回滚），以防万一您不喜欢这个扩展内容所带来的影响。而且，最好还是不要冒不必要的风险，相信我的话就好： [red]修改多个原版文件[]\n\n[accent]重要事项:[] 某些单位的描述并不准确，甚至存在错误。\n\n[accent]特别感谢:[]\n[#8100cd]- inflarespirit (eve_light)\n[#fc8e6c]- ARmOrDer\n[#8F00B8]- 6matie9 (.miaofficial.)";
mod.meta.author = "D&X / 时倾";

Blocks.foreshadow.removeConsumer(Blocks.foreshadow.coolant);
Blocks.foreshadow.coolant = null;
Blocks.foreshadow.buildType = () => extend(ItemTurret.ItemTurretBuild, Blocks.foreshadow, {
acceptItem(source, item) {
return (item == Items.blastCompound && this.items.get(item) <= 50) || this.super$acceptItem(source, item);
},
handleItem(source, item) {
if (item == Items.blastCompound) {
this.items.add(item, 1);
} else {
this.super$handleItem(source, item);
}
},
useAmmo() {
this.items.remove(Items.blastCompound, 15);
this.super$useAmmo();
}
});
