const saltPress = extendContent(GenericCrafter, "salt-press", {

	draw(tile) {
		var frameRegions = new Array();
		for (var i = 0; i < 3; i++) {
            frameRegions[i] = "chemindustry-salt-press-frame" + i;
		}
		Draw.rect(this.region, tile.drawx(), tile.drawy())
		Draw.rect(Core.atlas.find(frameRegions[Math.floor(Mathf.absin(tile.ent().totalProgress, 7, 2.999))]), tile.drawx(), tile.drawy());
	},
	generateIcons() {
		return [
			Core.atlas.find(this.name),
			Core.atlas.find(this.name + "-frame0"),
		];
	}
})