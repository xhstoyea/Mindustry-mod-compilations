const fabricSpinner = extendContent(GenericCrafter, "fabric-spinner", {
	draw(tile) {
		Draw.rect(Core.atlas.find(this.name + "-bottom"), tile.drawx(), tile.drawy());
		Draw.color();
		Draw.rect(Core.atlas.find(this.name + "-weave"), tile.drawx(), tile.drawy(), tile.ent().totalProgress * 2) 
		Draw.rect(this.region, tile.drawx(), tile.drawy())
	},
	generateIcons() {
		return [
		Core.atlas.find(this.name + "-bottom"),
		Core.atlas.find(this.name),
		Core.atlas.find(this.name + "-weave"),
		];
	}
})