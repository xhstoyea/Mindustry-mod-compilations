if(typeof(require) !== "undefined"){ 
	require("blocks/production/acid-electrolysis-cell");
	require("blocks/production/alkali-electrolysis-cell");
	require("blocks/production/fabric-spinner");
	require("blocks/production/salt-press");
}