# Intro

![BetterDuStryMod](https://github.com/Dong-Wo-Long/Images-and-gifs/blob/main/techsupport_sysodmin.gif)

# BetterDuStryMod
![BetterDuStryMod](https://github.com/Dong-Wo-Long/BetterDuStryMod/blob/main/icon.png)
### Introduction
This mod is an amalgamation of EU and ET. However, in addition it adds new blocks and rebalances existing blocks.

![BetterDuStryMod](https://github.com/Dong-Wo-Long/BSM-other/blob/main/database-units.png)

> [!IMPORTANT]
> ### The mod does not shamelessly steal other people's sprites without their author's permission to use them.
### Sapphirium
(https://github.com/3Snake3/Sapphirium?ysclid=lyzqzrbhic385832513)

Special thanks to Snake#2132 for the ability to use weapon sprites for units:
- ship-large-cannon - is based on the "tornado-cyclone"
- ship-cannon - is based on the "parity-unit-launcher"
- aa-ship-weapon - original sprite "point-laser-mount"
- ship-rail-rig - redesigned from “whirlpool-launcher”

### Asthosus
(https://github.com/Catana791/asthosus?ysclid=lyzrir3syb127993937)

Thanks also to Catana#8735 for the opportunity to use this sprite:
- missiles-mount - recolor sprite "everse-launcher"

> [!CAUTION]
> ### What follows are just spoilers of future content (WIP):
New bullets for Titan:

![BetterDuStryMod](https://github.com/Dong-Wo-Long/BSM-other/blob/main/Mindustry_LmnQzuS9mx.gif)

Updated Breaches:

![BetterDuStryMod](https://github.com/Dong-Wo-Long/BSM-other/blob/main/Mindustry_oqqv2mMNvN.gif)
