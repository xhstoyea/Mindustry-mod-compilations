Blocks.sand.playerUnmineable = false
Blocks.darksand.playerUnmineable = false