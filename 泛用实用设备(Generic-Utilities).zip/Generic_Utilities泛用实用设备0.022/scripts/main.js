MapResizeDialog.minSize = 1
MapResizeDialog.maxSize = 9999
Vars.maxSchematicSize = 99;
//为了不BUG,数值改小了点

//以上为原版限制解除

print("Hello World");