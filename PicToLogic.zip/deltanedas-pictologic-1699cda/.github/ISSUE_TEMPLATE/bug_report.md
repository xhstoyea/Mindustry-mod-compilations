---
name: Bug report
about: Report a bug
title: ''
labels: bug
assignees: ''

---

**Platform**
Debian sid

**Mindustry Version**
105

**Pictologic Version** *the number please*
"latest"

**Steps to reproduce**

----

Place an X in the box below (no spaces) to show that you have read the following:
- [ ] I have installed the 6.0 version of ui-lib.
