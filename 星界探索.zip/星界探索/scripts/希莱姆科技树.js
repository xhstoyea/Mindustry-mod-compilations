var lib = require("techTreeLib")
const Research = Objectives.Research;
const 物品 = require("物品");
const planet = require("希莱姆");

lib.rootPlanet(planet.希莱姆,"希莱姆",planet.探索者基站)
    .child(Items.graphite)
        .child(物品.锺)
            .child(Items.thorium)
                .warpChild(Items.phaseFabric)
                .warp()
            .warp()
        .child(Items.sand)
            .warpChild(Items.silicon)
            .warp()
        .child(物品.污水)
            .warpChild(Liquids.water)
            .warp()
        .warp()
    .warpChild(planet.map1)
    .warp()