const 希莱姆 = new Planet("希莱姆", Planets.sun, 1, 4);
希莱姆.meshLoader = prov(() => new HexMesh(希莱姆, 7));

function color(c) {
	return Color.valueOf(c);
}

希莱姆.generator = extend(SerpuloPlanetGenerator, {
	arr: [color("4D505A"), color("3D414C"), color("2F333C"), color("272930"), color("1B1C1F"),color("9E78DCFF"),color("7457CEFF"),color("5541B1FF"),color("5E4892FF"),color("43336AFF"),color("483D5DFF"),color("727272FF"),color("5E4892FF"),color("67539BFF"),color("43336AFF")],
	getColor(position) {
		const noise = (amount, a, b, c) => {
			var n = Simplex.noise3d(this.seed + amount, a, b, c, position.x, position.y, position.z);
			return n
		};
		this.vec = new Vec3(noise(1, 16, 0.2, 8 / 3), noise(6, 72, 0.8, 9 / 2), noise(3, 2, 0.4, 3 / 2));
		var amo = Mathf.round(Mathf.clamp(this.vec.x * this.arr.length, 0, this.arr.length - 1));
		return Tmp.c1.set(this.arr[amo]);
	},
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgYmBiZmDJS8xNZWB7tmDH0/3NDNwpqcXJRZkFJZn5eQwMDGw5iUmpOcUMTNGxjAwyz2bMfz6151nfoudbFulCqBcNrU/n73q+eiZQMSMDBAAAdBEhZg==")
	},
	allowLanding(sector){
        return false
        //是否启用数字区块
    }
});
希莱姆.bloom = false;
//不清楚
希莱姆.accessible = true;
//是否在行星菜单内显示
希莱姆.rotateTime = 1440
//一昼夜的时间(s)
希莱姆.localizedName= "希莱姆";
//如果有翻译文件就不需要写这个
希莱姆.visible = true;
//可见
希莱姆.alwaysUnlocked = true;
希莱姆.prebuildBase= false;
希莱姆.orbitRadius = 90;
//星球公转半径
希莱姆.atmosphereColor = 希莱姆.lightColor = Color.valueOf("2F333C");
//大气层/发光颜色
希莱姆.atmosphereRadIn = 0.05;
//大气素
希莱姆.atmosphereRadOut = 0.5;
//大气输出
希莱姆.defaultEnv = Env.spores | Env.terrestrial;
//环境
希莱姆.startSector = 0;
//默认解锁的区块编号
希莱姆.clearSectorOnLose = true;
//失败是否重置区域存档
希莱姆.hiddenItems.addAll(Items.scrap, Items.copper, Items.lead, Items.coal, Items.plastanium, Items.titanium, Items.surgeAlloy, Items.sporePod, Items.blastCompound, Items.pyratite, Items.metaglass, Items.beryllium, Items.tungsten, Items.oxide, Items.carbide, Items.fissileMatter, Items.dormantCyst);
exports.希莱姆 = 希莱姆;
const lib = require("lib");

const 探索者基站 = extend(CoreBlock, "探索者基站", {});
exports.探索者基站 = 探索者基站;
探索者基站.category = Category.logic;
希莱姆.defaultCore = 探索者基站;

const map1 = new SectorPreset("1号安全区", 希莱姆, 0);
map1.description = "这里是一个没有敌人的安全区，只有基础资源与一个实验室。";
//引号内填msav的名字
map1.difficulty = 0;
//难度
map1.alwaysUnlocked = true;
//无需解锁
map1.addStartingItems = true;
//允许添加初始资源
map1.captureWave = 0;
//多少波可占领
map1.localizedName = "1号安全区";
exports.map1 = map1;