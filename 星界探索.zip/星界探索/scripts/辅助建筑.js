const 物品 = require("物品");
function newDun(name, ItemStack) {
	let nD = new ForceProjector(name);
	nD.itemConsumer = nD.consumeItems(ItemStack).boost();
	exports[name] = nD;
	return nD;
}
let z = new BurstDrill("聚能钻头");
z.drillMultipliers.put(物品.铉, 0.125);

let z1 = new BurstDrill("坍缩钻头");
z1.drillMultipliers.put(物品.铉, 0.165);

newDun("大型力墙投影器", ItemStack.with(Items.phaseFabric, 1))
newDun("力场投射器", ItemStack.with(Items.phaseFabric, 1))
newDun("力场穹顶仪", ItemStack.with(物品.锬, 1))
newDun("力场天穹塔", ItemStack.with(物品.铫, 1))
newDun("虚空力场塔", ItemStack.with(物品.铉, 1))