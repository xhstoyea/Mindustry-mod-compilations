let gd21d = 25000, gd22d = 125000, laser2d = 10000;
//  轨道轰炸落地/轨道轰炸爆炸/    毁灭光束伤害

let 落地音效 = Vars.tree.loadSound("文件名字不加后缀")

function float(speed, length) {
	return Mathf.absin(Time.time, speed, length);
}

function color(R) {
	return Color.valueOf(R);
}

function AngleTrns(ang, rad) {
	return {
		x: Angles.trnsx(ang, rad),
		y: Angles.trnsy(ang, rad)
	}
}

function DoubleTri(x, y, width, length, angle, len) {
	Drawf.tri(x, y, width, length, angle + 180);
	Drawf.tri(x, y, width, length / (len || 4), angle);
}

let laser2b = extend(ContinuousLaserBulletType, {//蓝激光
	lifetime: 900,//持续时间
	damage: 0,
	length: 800,
	width: 160,//粗细
	laserAbsorb: false,
	colors: [color("6D90BC"), color("87CEEB"), color("C0ECFF")],
	update(b) {
		this.super$update(b);
		let x = Core.camera.position.x, y = Core.camera.position.y;
		b.x = x;
		b.y = y + 800;
		Damage.damage(x, y, 160/*伤害半径*/, laser2d / 60);
		if (b.timer.get(5)) Object.assign(new ParticleEffect(), {
			line: true,
			particles: 12,
			lifetime: 20,
			length: 160,
			cone: 360,
			lenFrom: 6,
			lenTo: 6,
			strokeFrom: 3,
			strokeTo: 0,
			lightColor: color("87CEEB"),
			colorFrom: color("87CEEB"),
			colorTo: color("87CEEB")
		}).at(x, y);
	}
});

let hitExplosionMassive = new Effect(70, 370, e => {
	e.scaled(17, s => {
		Draw.color(Color.white, Color.lightGray, e.fin());
		Lines.stroke(s.fout() + 0.5);
		Lines.circle(e.x, e.y, e.fin() * 185);
	});
	Draw.color(Color.gray);
	Angles.randLenVectors(e.id, 12, 5 + 135 * e.finpow(), (x, y) => {
		Fill.circle(e.x + x, e.y + y, e.fout() * 22 + 0.5);
		Fill.circle(e.x + x / 2, e.y + y / 2, e.fout() * 9);
	});
	Draw.color(Pal.lighterOrange, Pal.lightOrange, Color.gray, e.fin());
	Lines.stroke(1.5 * e.fout());
	Angles.randLenVectors(e.id + 1, 14, 1 + 160 * e.finpow(), (x, y) => Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), 1 + e.fout() * 3));
})

let knellShoot = new Effect(300, e => {
	Draw.color(Tmp.c1.set(e.color).lerp(color("FF8663"), e.fout()));
	for (let i = 0; i < 4; i++) {
		Drawf.tri(e.x, e.y, 12 * e.fout(), 90, e.rotation + 90 * i + e.finpow() * 112);
	}
	for (let h = 1; h <= 5; h++) {
		let mul = h % 2;
		let rm = 1 + mul * 0.5;
		let rot = 90 + (1 - e.finpow()) * Mathf.randomSeed(e.id + (mul * 2), 210 * rm, 360 * rm);
		for (let i = 0; i < 2; i++) {
			let m = i == 0 ? 1 : 0.5;
			let w = 24 * e.fout() * m;
			let length = (8 * 3 / (2 - mul)) * 3;
			let fxPos = Tmp.v1.trns(rot, length - 12);
			length *= Interp.PowOut(25).apply(e.fout());
			Drawf.tri(fxPos.x + e.x, fxPos.y + e.y, w, length * m, rot + 180);
			Drawf.tri(fxPos.x + e.x, fxPos.y + e.y, w, length / 3 * m, rot);
			Draw.alpha(0.5);
			Drawf.tri(e.x, e.y, w, length * m, rot + 360);
			Drawf.tri(e.x, e.y, w, length / 3 * m, rot);
			Fill.square(fxPos.x + e.x, fxPos.y + e.y, 3 * e.fout(), rot + 45);
		}
	}
})

let xb = extend(PowerTurret, "定位基站", {
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.get(team).getCount(this) < 1;
	},
	drawPlace(x, y, rotation, valid) {
		this.super$drawPlace(x, y, rotation, valid);
		if (this.canPlaceOn(Vars.world.tile(x, y), Vars.player.team(), rotation)) return
		this.drawPlaceText(this.localizedName + "数量超限，限制1座", x, y, valid);
	}
});
xb.configurable = true;
let gd = false, gd2 = false, laser = false, laser2 = false;
xb.buildType = prov(() => {
	return extend(PowerTurret.PowerTurretBuild, xb, {
		buildConfiguration(table) {
			table.table(Tex.button, Cons(Table => {
				Table.add("轨道轰炸");
				Table.check("", gd2, judge => {
					gd2 = judge
					gd = false
					laser = false
					laser2 = false
				}).size(60);
				Table.add("泯灭光线");
				Table.check("", laser2, judge => {
					laser2 = judge
					gd = false
					gd2 = false
					laser = false
				}).size(60);
			}))
		},
		shoot(type) {
			let x = Core.camera.position.x, y = Core.camera.position.y;
			knellShoot.at(x, y, color("FF5845"));
			Timer.schedule(() => {
				if (gd2) {
					new Effect(30, 370, e => {
						Draw.z(111);
						Draw.color(color("00000000"), Color.black, e.fin());
						Fill.circle(e.x, e.y, e.fout() * 240);
					}).at(x, y);
					Timer.schedule(() => {
						Damage.damage(x, y, 80, gd21d);
						hitExplosionMassive.at(x, y);
						落地音效.at(x, y);
						Timer.schedule(() => {
							Damage.damage(x, y, 192, gd22d);
							Sounds.largeCannon.at(x, y);
							Fx.dynamicExplosion.at(x, y, 12);
						}, 2);
					}, 0.5);
				} else if (laser2) {
					this.bullet(laser2b, x, y, -180, null);
				}
			}, 5);
			this.heat = 1;
			this.useAmmo();
		},
		draw() {
			this.super$draw();
			if (!this.isControlled()) return
			let size = 5;
			let x = Core.camera.position.x, y = Core.camera.position.y;
			Draw.color(color("FF5845"));
			Draw.z(Layer.effect);
			for (let i = 0; i < 3; i++) {
				let ang = i * 360 / 3 + Time.time;
				let xy = AngleTrns(ang, (24 + float(4, 4)) * size);
				DoubleTri(x + xy.x, y + xy.y, size * 4, size * 16, ang);
			}
		},
		write(write) {
			this.super$write(write);
			write.bool(gd2);
			write.bool(laser2);
		},
		read(read, revision) {
			this.super$read(read, revision);
			gd2 = read.bool();
			laser2 = read.bool();
		}
	});
});
xb.shootType = extend(BulletType, {
	lifetime: 0,
	damage: 0,
	shootEffect: Fx.none,
	smokeEffect: Fx.none,
	hitEffect: Fx.none,
	despawnEffect: Fx.none
});
xb.recoil = 0;
xb.range = 8000;
xb.rotateSpeed = 0;
xb.shootCone = 360;
xb.size = 4;
xb.reload = 3600;
xb.consumePower(5);
xb.buildVisibility = BuildVisibility.shown;
xb.category = Category.turret;