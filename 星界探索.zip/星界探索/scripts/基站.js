const 物品 = require("物品");
const core3 = extend(CoreBlock, "征服者基站", {});
core3.configurable = true;

let 炮塔 = extend(ItemTurret, "双鲨", {});
function Pay(block) {
	return new BuildPayload(block, Team.derelict)
}
function cool(to, from) {
	if (物品.砛溶液.unlockedNow()) {
		if (to.acceptLiquid(from, 物品.砛溶液)) {
			to.handleLiquid(from, 物品.砛溶液, 1);
		}
	} else if (Liquids.water.unlocked()) {
		if (to.acceptLiquid(from, Liquids.water)) {
			to.handleLiquid(from, Liquids.water, 1);
		}
	}
}
const TItems = Seq.with(Items.graphite, Items.thorium, 物品.锺, 物品.锬);
core3.config(Item, new Cons2((build, item) => build.setBullet(item)));
core3.buildType = prov(() => {
	const p = Pay(炮塔);
	let Bullet = null;
	return extend(CoreBlock.CoreBuild, core3, {
		setBullet(item) {
			Bullet = item;
		},
		buildConfiguration(table) {
			ItemSelection.buildTable(this.block, table, TItems, () => Bullet, value => this.configure(value));
		},
		updateTile() {
			this.super$updateTile();
				if (p.build.team != this.team) p.build.team = this.team;
				p.update(null, this);
				let core = this.team.core();
				if (Bullet != null) {
					if (p.build.acceptItem(this, Bullet) && core.items.get(Bullet) >= 1) {
						p.build.handleItem(this, Bullet);
						core.items.remove(Bullet, 1);
					}
				} else {
					if (p.build.acceptItem(this, Items.graphite) && core.items.get(Items.graphite) >= 1) {
						p.build.handleItem(this, Items.graphite);
						core.items.remove(Items.graphite, 1);
					}
				}
				cool(p.build, this);
				p.set(this.x, this.y, p.build.payloadRotation);
		},
		draw() {
			this.super$draw();
			p.draw();
		}
	})
});