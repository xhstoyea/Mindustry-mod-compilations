function newItem(name) {
	exports[name] = extend(Item, name, {});
}
function newCellLiquid(name) {
	exports[name] = extend(CellLiquid, name, {});
}
function newLiquid(name) {
	exports[name] = extend(Liquid, name, {});
}
function newBlock(name) {
	exports[name] = extend(Block, name, {});
}

newItem("锺");
newItem("锬");
newItem("铫");
newItem("铉");
newItem("铧");
newItem("砛");
newLiquid("砛溶液");
newCellLiquid("污水");