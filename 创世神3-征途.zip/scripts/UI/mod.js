const meta = Vars.mods.locateMod("creators").meta;
meta.author = "[pink]N[cyan]O [red]95[violet]27";
meta.description = Core.bundle.format("9527-description")