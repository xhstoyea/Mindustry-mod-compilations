
//Java核心系统  勿删！//
function CreatorsPackage(name) {
	var p = Packages.rhino.NativeJavaPackage(name, Vars.mods.mainLoader());
	Packages.rhino.ScriptRuntime.setObjectProtoAndParent(p, Vars.mods.scripts.scope)
	return p
}
var CreatorsJavaPack = CreatorsPackage('creators')
importPackage(CreatorsJavaPack)
importPackage(CreatorsJavaPack.draw)
importPackage(CreatorsJavaPack.type)

//***********************************/

require('floor');//地板
require('Blocks/Blocks-ChuanShu');//物流
require('Blocks/Blocks-factory');//工厂
require('Blocks/Blocks-defense');//防御设施
require('Blocks/Blocks-power');
require('turrets/DC');//炮台
require('BlocksLibes/Build');//微晶导管桥防自然
require('core');
require('units');//单位
const BS = require('invincible');//沙盒测试相关方块
require('next-wave');//跳波器
require('Blocks/Blocks-drills');

//Vars.mods.locateMod("creators").meta.version += "----" +  "[violet]创世神-征途[]";//服务器
/*==================================================
以下服务器不可用
*/
require('BlocksLibes/chuansongdai');//传送带发光
require('BlocksLibes/xuwu');//服务器禁虚无

require('BlocksLibes/FenNei');//分类

require('techTree');//科技树     
require("BlocksLibes/chongzhigongju");//地图重置
Vars.mods.locateMod("creators").meta.version += "----" + Core.bundle.format("planet.creators.MODname");//本地
require("UI/mod");//模组描述彩色文本
require("BlocksLibes/units-factory");//沙盒兵工厂
require('ui');//更新，首页按钮等
const {NaMeiXing}=require('xingqiu');//星球

//删除 /* 和 */ 符号开启作弊模式：

/*
const lib = require('lib')
 lib.addToResearch(BS.BiSiPao, {
	 parent: "duo",}); 
BS.BiSiPao.buildVisibility = BuildVisibility.shown;
*/

// Creators.BlackListRun.add(run(()=>{
	//  NaMeiXing.accessible = false;
	//  NaMeiXing.visible = false;
	//  NaMeiXing.alwaysUnlocked = false;
// }))


//clearSectorOnLose = true;//扇区丢失时是否重置地图
//enemyCoreSpawnReplace = true;//攻击图核心变刷怪点