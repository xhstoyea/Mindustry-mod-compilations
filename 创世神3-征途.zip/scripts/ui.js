
Events.on(EventType.ClientLoadEvent,
    cons(e => {
        Vars.ui.hudGroup.fill(cons(t => {
            let style = CreatorsStyles.clearTransi;

            t.button(Icon.home, style, run(() => {
                new JoinDialog().connect("49.232.140.138", 9527);
            })).width(35).height(46).name("ores").tooltip(Core.bundle.get("9527-net2"));//国际大厅

            t.button(Icon.refresh, style, run(() => {
                Call.sendChatMessage("/sync");
            })).width(46).height(46).name("ores").tooltip(Core.bundle.get("refresh"));//联机刷新

            t.top().left().marginTop(155);
        }));
    }));
//@Le Zooom
//缩放加强
const defaultMinZoomLim = Vars.renderer.minZoom;
const defaultMaxZoomLim = Vars.renderer.maxZoom;
print("default min zoom: " + defaultMinZoomLim);
print("defaultn max zoom: " + defaultMaxZoomLim);
const minZoomLim = 0.3;
const maxZoomLim = 15;
// default extended zoom limits
const minZoom = 0.75;
const maxZoom = 20;
function resetZoomLim(toOriginal) {
    if (toOriginal) {
        Vars.renderer.minZoom = defaultMinZoomLim;
        Vars.renderer.maxZoom = defaultMaxZoomLim;
    } else {
        Vars.renderer.minZoom = minZoomLim;
        Vars.renderer.maxZoom = maxZoomLim;
    }
}
function updateZoom(min, max) {
    Vars.renderer.minZoom = min;
    Vars.renderer.maxZoom = max;
}
if (!Vars.headless) {
    updateZoom(minZoomLim, maxZoomLim);
}

//---------下列代码由 @miner 提供授权仅在（创世神）使用，任何人不得擅自盗取，要使用需联系作者同意：@9527或者@miner

//核心物资显示 #1 
const myCoreItems = require("UI/myCoreItems2");
Events.on(EventType.ClientLoadEvent, e => {
    let ui = Vars.ui;
    let hudGroup = ui.hudGroup;
    let hudfrag = ui.hudfrag;
    let settings = Core.settings;

    myCoreItems.load();

    let myItems = myCoreItems.rebuild();
    let collapser = hudGroup.find("coreinfo").getChildren().get(1).getChildren().get(0);
    let oldItems = collapser.getChildren().get(0);

    let change = () => {
        let s = settings.getBool("mycoreitems", false);
        let set = s ? myItems : oldItems;
        collapser.setTable(set);
    }

    collapser.setCollapsed(boolp(() => !(hudfrag.shown && settings.getBool("coreitems", false))));
    if (Vars.mobile) collapser.touchable = Touchable.disabled; // 核心资源显示会需要点击吗（

    if (Vars.mobile) ui.settings.graphics.checkPref("coreitems", true);
    ui.settings.graphics.checkPref("mycoreitems", false, s => change());//默认关闭

    change();
});

Events.on(ResetEvent, e => {
    myCoreItems.resetUsed();
});


//核心物资显示（下拉） #2
const ui = require("UI/library");
require("UI/areas");
Events.on(ClientLoadEvent, ui.load);

var target = null;
var display = null;

const updateTarget = Q => {
    display.clear();
    if (!Q) return;

    const items = Vars.content.items();
    const core = Vars.player.team().core();
    var i = 0;
    items.each(item => {
        display.image(item.uiIcon).size(15/*资源贴图大小 */);
        display.label(() => core == null ? "0" : UI.formatAmount(core.items.get(item))).padRight(3/*UI的间隔 */).left();
        i++;
        if (i % 6/*资源一排的数量 */ == 0) {
            display.row();
        }
    });
};

ui.addTable("top", "creators", table => {
    display = table;
    table.table().center().bottom();
    table.background(Tex.buttonTrans);
    //table.visibility = () => !!target && target.health > 0;
    table.touchable = Touchable.disabled
});

Events.on(WorldLoadEvent, () => {
    target = null;
});


// Find targets
Events.run(Trigger.update, () => {
    const p = Vars.player;
    target = p;
    updateTarget(target);
});

Blocks.payloadLoader.buildType = prov(() => {
    return new JavaAdapter(PayloadLoader.PayloadLoaderBuild, {
        draw() {
            this.super$draw();
            Draw.blend();
            Draw.color();
            Draw.rect(Core.atlas.find("creators-PayloadUnloader-1"), this.x, this.y, 90 - Time.time * 3);
        },
    }, Blocks.payloadLoader);
});
Blocks.siliconSmelter.buildType = () => {
    var transparency = 0.3
    var colors = [Color.valueOf("ffffff"), Color.valueOf("cdcddb"), Color.valueOf("7d7d7d"), Color.valueOf("242425")];
    var colorTimer = 30;
    var region = Core.atlas.find("creators-b");
    return extend(GenericCrafter.GenericCrafterBuild, Blocks.siliconSmelter, {
        draw() {
            this.super$draw();

            Draw.color(colors[Math.floor(this.totalProgress % (colors.length * colorTimer) / colorTimer)], transparency);
            Draw.rect(region, this.x, this.y);
        },
    })
}

//  Blocks.siliconSmelter.buildType = () => {
//     var transparency = 0.3
// 	var colors = [Color.valueOf("ffffff"), Color.valueOf("cdcddb"), Color.valueOf("7d7d7d"),Color.valueOf("242425")];
// 	var regionTimer = 0;
// 	var region = Core.atlas.find("creators-b");
//     return extend(GenericCrafter.GenericCrafterBuild, Blocks.siliconSmelter, {
//         draw(){
//         	this.super$draw();
//         	regionTimer += Time.delta / 20;
//         	regionTimer %= colors.length;
//         	Draw.color(colors[Math.floor(regionTimer)], transparency);
//         	Draw.rect(region, this.x, this.y);
//         },
//     })
// }


Blocks.payloadUnloader.buildType = prov(() => {
    return new JavaAdapter(PayloadUnloader.PayloadUnloaderBuild, {
        draw() {
            this.super$draw();
            Draw.blend();
            Draw.color();
            Draw.rect(Core.atlas.find("creators-PayloadLoader-1"), this.x, this.y, 90 - Time.time * 3);
        },
    }, Blocks.payloadUnloader);
});


/* //对话框
Events.on(EventType.ClientLoadEvent, cons(e => {

    Vars.ui.settings = new SettingsMenuDialog();

    var dialog = new JavaAdapter(BaseDialog, {}, "origin");
    dialog.shown(run(() => {
        dialog.cont.table(Tex.button, cons(t => {
            t.defaults().size(20, 20).left();
            t.button("close", Icon.trash, Styles.cleart, run(() => {
                dialog.hide();
            }));
            t.add("本模组部分方块需要地图上有微晶核心才会显示在建造栏");
        }));
    }));

    dialog.show();
})) */


//=========首页按钮

/* Events.on(EventType.ClientLoadEvent, cons(e => {
    let framer = Core.bundle.format("framer");
    let mod = Vars.mods.getMod("creators")
    let version = mod.meta.version
    let https1 = "https://jq.qq.com/?_wv=1027&k=rZ8D5XGE";
    let https2 = "http://sd674971336.ysepan.com"

    var dialog = new BaseDialog("[yellow]Creators[#7bebf2] " + version + "[] Adapt 136+" + "\n" + framer);

    //**========================================================= 
    let TZ = Core.bundle.format("TZ");
    let IP = Core.bundle.format("IP");
    let TX = Core.bundle.format("TX");
    var dialog1 = new BaseDialog("[yellow]Creators[#7bebf2] " + version + "[] Adapt 136+" + "\n" + framer);

    dialog1.buttons.defaults().size(210, 64);
    dialog1.buttons.button("@close", run(() => {
        dialog1.hide();
    })).size(210, 64);

    dialog1.cont.pane((() => {

        var table = new Table();
        table.add(Core.bundle.format("planet.creators.MODname") + IP).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();

        table.image().color(Color.valueOf("69dcee")).fillX().height(3).pad(3);
        table.row();

        table.image(Core.atlas.find("creators-logo", Core.atlas.find("clear"))).height(290).width(587).pad(3);
        table.row();
        table.add(TZ).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();
        table.add(version + TX).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();

        table.add(Core.bundle.format("update")).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();

        table.add(Core.bundle.format("notice")).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();
        return table;
    })()).grow().center().maxWidth(770);
    dialog1.show();
    //**========================================================= 



    dialog.buttons.defaults().size(210, 64);

    dialog.cont.pane(cons(t => {
        //  t.image(Core.atlas.find("dd")).scaling(Scaling.fit);//贴图
        t.button(Core.bundle.format("9527saver"), Styles.cleart, run(() => {
            new JoinDialog().connect("49.232.140.138", 9527);
        })).size(210, 64);
        t.row();


        t.button(Core.bundle.format("9527QQ"), run(() => {
            if (!Core.app.openURI(https1)) {
                Vars.ui.showErrorMessage("@linkfail");
                Core.app.setClipboardText(https1);
            }
        })).size(210, 64);
        t.row();

        t.button(Core.bundle.format("9527http"), run(() => {
            if (!Core.app.openURI(https2)) {
                Vars.ui.showErrorMessage("@linkfail");
                Core.app.setClipboardText(https2);
            }
        })).size(210, 64);
    }))
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(210, 64);
    dialog.buttons.button(Core.bundle.format("9527gengxin"), run(() => {
        dialog1.show();
    })).size(210, 64);

    const imagebutton = Creators.CreatorsIcon("Betelgeuse", Styles.defaulti, dialog)
    Vars.ui.menuGroup.fill(cons(t => {
        if (Vars.mobile) {
            t.add(imagebutton).size(50.0);
            t.bottom();
        } else {
            t.add(imagebutton).size(80.0);
            t.left().bottom()
            /**
bottom是下

right是右

left是左

top是上

左下角就是

left().bottom()

()里可以填值
             *
        };
    }));
}))
 */
const {NaMeiXing}=require('xingqiu');//科技树 
Events.on(EventType.ClientLoadEvent, cons(e => {

    let framer = Core.bundle.format("framer");
    let mod = Vars.mods.getMod("creators")
    let version = mod.meta.version
    let https1 = "https://jq.qq.com/?_wv=1027&k=rZ8D5XGE";
    let https2 = "http://sd674971336.ysepan.com"
    let https3 = "https://steamcommunity.com/sharedfiles/filedetails/?id=2747061532&searchtext=%E5%88%9B%E4%B8%96%E7%A5%9E"
    let TZ = Core.bundle.format("TZ");
    let IP = Core.bundle.format("IP");
    let TX2 = Core.bundle.format("TX2");
    let TX = Core.bundle.format("TX");


    //**========================================================= 
    //警告↓↓↓↓↓
    var JingGao = new BaseDialog("[yellow]Creators[#7bebf2] " + version + "[] Adapt 136+" + "\n" + framer);
    JingGao.buttons.defaults().size(210, 64);
    JingGao.buttons.button("@close", run(() => {
        JingGao.hide();
    })).size(210, 64);
    JingGao.cont.pane((() => {
        var table = new Table();
        table.add(Core.bundle.format("warning-txt")).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();
        return table;
    })()).grow().center().maxWidth(770);
    JingGao.addCloseButton();//按esc关闭

    //**========================================================= 
    //恰饭↓↓↓↓↓
    var love = new BaseDialog("[yellow]Creators[#7bebf2] " + version + "[] Adapt 136+" + "\n" + framer);
    // love.buttons.button("@close", run(() => {
    //     love.hide();
    // })).size(210, 64);
    love.addCloseButton();//按esc关闭
    love.cont.pane((() => {
        var table = new Table();
        table.add(Core.bundle.format("planet.creators.love")).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();
        table.image().color(Color.valueOf("69dcee")).fillX().height(3).pad(9);
        table.row();
        table.image(Core.atlas.find("creators-nandu")).height(210).width(440).pad(3);
        table.row();
        return table;
    })()).grow().center().maxWidth(770);
    love.buttons.button(Core.bundle.format("9527steam"), run(() => {
        if (!Core.app.openURI(https3)) {
            Vars.ui.showErrorMessage("@linkfail");
            Core.app.setClipboardText(https3);
        }
    })).size(210, 64)
    //**========================================================= 
    //历史更新↓↓↓↓↓
    var GengXin = new BaseDialog("[yellow]Creators[#7bebf2] " + version + "[] Adapt 136+" + "\n" + framer);
    GengXin.addCloseButton();//按esc关闭
    GengXin.buttons.defaults().size(210, 64);

    // GengXin.buttons.button("@close", run(() => {
    //     GengXin.hide();
    // })).size(210, 64);//关闭

    GengXin.cont.pane((() => {

        var table = new Table();
        table.add(Core.bundle.format("planet.creators.MODname") + IP).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();

        table.image().color(Color.valueOf("69dcee")).fillX().height(3).pad(3);
        table.row();

        table.image(Core.atlas.find("creators-logo", Core.atlas.find("clear"))).height(290).width(587).pad(3);
        table.row();
        table.add(TZ).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();
        table.add(TX2).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();

        table.add(Core.bundle.format("update2")).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();

        table.add(Core.bundle.format("notice")).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();
        return table;
    })()).grow().center().maxWidth(770);
    //**========================================================= 
    //开屏显示↓↓↓↓↓

    var kaiping = new BaseDialog("[yellow]Creators[#7bebf2] " + version + "[] Adapt 136+" + "\n" + framer);
    kaiping.addCloseButton();//按esc关闭
    kaiping.buttons.defaults().size(210, 64);
    // kaiping.buttons.button("@close", run(() => {
    //     kaiping.hide();
    // })).size(210, 64);//关闭

    // kaiping.buttons.button(Core.bundle.format("9527warning"), run(() => {
    //     JingGao.show();
    // })).size(150, 64);//警告

    kaiping.buttons.button(Core.bundle.format("9527love"), run(() => {
        love.show();
    })).size(150, 64);
    kaiping.cont.pane((() => {

        var table = new Table();
        table.add(Core.bundle.format("planet.creators.MODname") + IP).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();

        table.image().color(Color.valueOf("69dcee")).fillX().height(3).pad(3);
        table.row();

        table.image(Core.atlas.find("creators-logo", Core.atlas.find("clear"))).height(290).width(587).pad(3);
        table.row();
        table.add(TZ).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();
        table.add(version + TX).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();

        table.add(Core.bundle.format("update")).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();

        table.add(Core.bundle.format("notice")).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);
        table.row();
        return table;
    })()).grow().center().maxWidth(770);
    kaiping.show();
    //**========================================================= 
    var dialog = new BaseDialog("[yellow]Creators[#7bebf2] " + version + "[] Adapt 136+" + "\n" + framer);
    dialog.buttons.defaults().size(210, 64);
    dialog.cont.pane(cons(t => {
        //  t.image(Core.atlas.find("dd")).scaling(Scaling.fit);//贴图
        t.button(Core.bundle.format("9527saver"),/* Styles.cleart ,*/ run(() => {
            new JoinDialog().connect("ip", 6567),
                dialog.hide();
        })).size(210, 64); t.row();
        t.button(Core.bundle.format("9527QQ"), run(() => {
            if (!Core.app.openURI(https1)) {
                Vars.ui.showErrorMessage("@linkfail");
                Core.app.setClipboardText(https1);
            }
        })).size(210, 64);
        t.row();
        t.button(Core.bundle.format("9527http"), run(() => {
            if (!Core.app.openURI(https2)) {
                Vars.ui.showErrorMessage("@linkfail");
                Core.app.setClipboardText(https2);
            }
        })).size(210, 64);
        t.row();
        // t.button(Core.bundle.format("9527warning"), run(() => {
        //     JingGao.show();
        // })).size(210, 64);//警告
        t.button(Core.bundle.format("9527love"), run(() => {
            love.show();
        })).size(210, 64);

    }))
    // dialog.buttons.button("@close", run(() => {
    //     dialog.hide();
    // })).size(210, 64);//关闭
    dialog.buttons.button(Core.bundle.format("9527gengxin"), run(() => {
        GengXin.show();
    })).size(100, 64);
    dialog.buttons.button(Core.bundle.format("9527shouye"), run(() => {
        kaiping.show(), dialog.hide();
    })).size(100, 64);
    dialog.addCloseButton();//按esc关闭
    const imagebutton = Creators.CreatorsIcon("Betelgeuse", Styles.defaulti, dialog)
    Vars.ui.menuGroup.fill(cons(t => {
        if (Vars.mobile) {
            t.add(imagebutton).size(80.0);
            t.bottom();
        } else {
            t.add(imagebutton).size(80.0);
            t.left().bottom()
        };
    }));
}));

/* 
//esc键落监听器:
const KeyCode = Packages.arc.input.KeyCode;
        table.keyDown(key => {
            if(key == KeyCode.escape || key == KeyCode.back){
                Core.app.post(() => table.remove());
            }
        }); */
//白名单警告
require('wmod');