//原作者：神魂
Blocks.sand.playerUnmineable = false
Blocks.darksand.playerUnmineable = false