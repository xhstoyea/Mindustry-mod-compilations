
Events.on(ClientLoadEvent, () => {
    let msg ="本模组是基于塞普罗的拓展，没啥好讲的\n贴图屎山警告\n\n0.14版本更新:\n       修复bug\n\n就这些没了，祝你玩的愉快"
    const dialog = new BaseDialog("作者的话");

    dialog.cont.add(msg)
        .pad(5);

    dialog.buttons.button("好的", () => {
        dialog.hide();
    });
    dialog.show();
});


