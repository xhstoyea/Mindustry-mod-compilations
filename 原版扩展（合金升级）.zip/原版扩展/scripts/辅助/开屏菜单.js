
//以下注释为VSHES荔枝独立完成为了让其他蔚蓝开发者同样可以更新开屏显示窗口插件
Events.on(EventType.ClientLoadEvent, cons(e => {
       var dialogo = new BaseDialog("合金升级\n---The Epoch Of Eternity---");//新建一个显示窗口
	dialogo.buttons.button("@close", run(() => {
		dialogo.hide()//退出此界面
	})).size(210, 64);//按钮用原版@close贴图

    dialogo.cont.pane(table => {//滑动显示
        
        table.add(Core.bundle.get("主菜单")).left().growX().wrap().width(600).maxWidth(600).pad(4).labelAlign(Align.left).row();
        
		table.image(Core.atlas.find("logo")).left().size(1024, 270).pad(3).row();//显示logo图片

		table.add("\n——————————\n想要mod请自行加入QQ群聊以获取文件资源").left().growX().wrap().pad(4).labelAlign(Align.left).row();
		 let label = new FLabel("QQ群: 292545661");
		 table.add(label).left().row();
		 table.add("劳玩家的最爱,我从小玩到大!"
).left().growX().wrap().width(580).maxWidth(580).pad(4).labelAlign(Align.left).row();

	}).grow().center().maxWidth(600)
	 dialogo.cont.button("加入QQ",run(() => {
               Core.app.openURI("https://qm.qq.com/q/ky0vMCChOM");
             })).size(100,70).pad(2);//添加qq群功能为荔枝VSHES添加
             dialogo.show();
}))