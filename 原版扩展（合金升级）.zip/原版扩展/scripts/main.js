//Le Zooom (来源)
//盗窃者: 小酥联

const defaultMinZoomLim = Vars.renderer.minZoom;
const defaultMaxZoomLim = Vars.renderer.maxZoom;
print("default min zoom: "+defaultMinZoomLim);
print("defaultn max zoom: "+defaultMaxZoomLim);

const minZoomLim = 0.25;
const maxZoomLim = 50;

// default extended zoom limits
const minZoom = 0.5;
const maxZoom = 50;

function resetZoomLim(toOriginal){
	if(toOriginal){
		Vars.renderer.minZoom = defaultMinZoomLim;
		Vars.renderer.maxZoom = defaultMaxZoomLim;
	} else {
		Vars.renderer.minZoom = minZoomLim;
		Vars.renderer.maxZoom = maxZoomLim;
	}
}


function updateZoom(min, max){
	Vars.renderer.minZoom = min;
	Vars.renderer.maxZoom = max;
}

if(!Vars.headless){
	updateZoom(minZoomLim,maxZoomLim);
}



Vars.maxSchematicSize = 128;
//读取蓝图时大小不能超过128
//原作者miner
//盗窃者: 小酥联

MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 5000
require("辅助/辅助");
require("辅助/核心资源显示");
require("辅助/开屏菜单");
require("辅助/缩放强化");
require("ui");
require("lib");