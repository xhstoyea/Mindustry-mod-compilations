//信息栏
Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("[purple]重始信息栏");
    dialog.buttons.defaults().size(210, 64);
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(210, 64);
    dialog.cont.pane((() => {
        var table = new Table();   
         table.add("下面还有按键\n欢迎使用重始科技模组\n作者Rst，转载需经同意\n感谢[green]风琴[white]提供单位名字\n这好像是个屑mod(划掉\n以后会分成一些小版本更新\n[purple]破事提醒:敌人出生点有个彩蛋，本人不说是什么\n[white]作者qq1816364346，是活人，有事就问\n玩的开心qwq\n\n那什么......还有......\n[red]新年快乐！").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
table.button("更新记录", run(() => {
    var dialog2 = new BaseDialog("[red]更新日志");
    var table = new Table();
	
	var t = new Table();
	t.add("[blue]更新了进阶工业的一些机器\n修改原版发电机建造材料\n为避免一些麻烦，修改了本模组所有矿的贴图\n(熔铁炉和电解机的贴图出了点问题，但放置后没事)\n");
    dialog2.cont.add(new ScrollPane(t)).size(500, 600).row();
    dialog2.buttons.defaults().size(620, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(500, 64);
       dialog2.show();
    })).size(210, 64);
        return table;
    })()).grow().center().maxWidth(620);
    dialog.show();
}));

//感谢年年有鱼提供
