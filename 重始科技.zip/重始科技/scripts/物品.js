function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("钢锭")
newItem("钢板")
newItem("铁板")
newItem("om")