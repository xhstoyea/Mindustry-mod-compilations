const library = require("library");
const 实验室 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "实验室", [
  {
    input: {
      items: ["重始科技-铁板/75","重始科技-钢板/100"],     
      liquids: ["重始科技-原油/200"],
      power: 5,
    },
    output: {
      items: ["重始科技-om/1"],
    },
    craftTime: 3750,
  },]);