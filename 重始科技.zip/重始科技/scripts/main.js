require("qwer")
require("工厂/实验室");

require("物品");
require("液体");
