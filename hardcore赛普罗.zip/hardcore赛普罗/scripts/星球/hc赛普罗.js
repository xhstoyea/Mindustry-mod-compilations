const SFlib = require("base/SFlib");
const hc赛普罗 = new Planet("hc赛普罗", Planets.sun, 1, 3.3);
hc赛普罗.meshLoader = prov(() => new MultiMesh(
	new HexMesh(hc赛普罗, 8)
));
hc赛普罗.generator = extend(SerpuloPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nA3JMQ6AIBAAwQXFRr9i4XuMBR5XkCAYkP9LphwcbmLO/lHMwRq0SY3vF0sGluRvTQ17XoZNStU9d0na20gDduAHAc0Org==")
	}
});
hc赛普罗.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(hc赛普罗, 2, 0.15, 0.14, 5, Color.valueOf("AC4DC420"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(hc赛普罗, 3, 0.6, 0.15, 5, Color.valueOf("AC4DC4FF"), 2, 0.42, 1.2, 0.45)
));
hc赛普罗.generator = new SerpuloPlanetGenerator();
hc赛普罗.visible = hc赛普罗.accessible = hc赛普罗.alwaysUnlocked = true;
hc赛普罗.allowLaunchToNumbered = false
hc赛普罗.clearSectorOnLose = false;
hc赛普罗.tidalLock = false;
hc赛普罗.localizedName = "hc赛普罗";
hc赛普罗.prebuildBase = false;
hc赛普罗.bloom = false;
hc赛普罗.startSector = 1;
hc赛普罗.orbitRadius = 85;
hc赛普罗.clearSectorOnLose = true;
hc赛普罗.enemyCoreSpawnReplace = true;
hc赛普罗.orbitTime = 180 * 60;
hc赛普罗.rotateTime = 90 * 60;
hc赛普罗.atmosphereRadIn = 0.02;
hc赛普罗.atmosphereRadOut = 0.3;
hc赛普罗.atmosphereColor = hc赛普罗.lightColor = Color.valueOf("AC4DC480");
hc赛普罗.iconColor = Color.valueOf("AC4DC4"),
hc赛普罗.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);

const hc0号地区 = new SectorPreset("hc0号地区", hc赛普罗, 1);
hc0号地区.description = "";
hc0号地区.difficulty = 2;
hc0号地区.alwaysUnlocked = false;
hc0号地区.addStartingItems = true;
hc0号地区.captureWave = 40;
hc0号地区.localizedName = "hc0号地区";
exports.hc0号地区 = hc0号地区;
SFlib.addToResearch(hc0号地区, {
	parent: "planetaryTerminal",
	objectives: Seq.with(
	new Objectives.SectorComplete(SectorPresets.planetaryTerminal))
});

const hc冰冻森林 = new SectorPreset("hc冰冻森林", hc赛普罗, 86);
hc冰冻森林.description = "";
hc冰冻森林.difficulty = 2;
hc冰冻森林.alwaysUnlocked = false;
hc冰冻森林.addStartingItems = true;
hc冰冻森林.captureWave = 55;
hc冰冻森林.localizedName = "hc冰冻森林";
exports.hc冰冻森林 = hc冰冻森林;
SFlib.addToResearch(hc冰冻森林, {
	parent: "hc0号地区",
	objectives: Seq.with(
	new Objectives.SectorComplete(hc0号地区))
})

const hc陨石带 = new SectorPreset("hc陨石带", hc赛普罗, 18);
hc陨石带.description = "";
hc陨石带.difficulty = 2;
hc陨石带.alwaysUnlocked = false;
hc陨石带.addStartingItems = true;
hc陨石带.captureWave = 65;
hc陨石带.localizedName = "hc陨石带";
exports.hc陨石带 = hc陨石带;
SFlib.addToResearch(hc陨石带, {
	parent: "hc冰冻森林",
	objectives: Seq.with(
	new Objectives.SectorComplete(hc冰冻森林))
})

const hc生物质合成区 = new SectorPreset("hc生物质合成区", hc赛普罗, 81);
hc生物质合成区.description = "";
hc生物质合成区.difficulty = 2;
hc生物质合成区.alwaysUnlocked = false;
hc生物质合成区.addStartingItems = true;
hc生物质合成区.captureWave = 75;
hc生物质合成区.localizedName = "hc生物质合成区";
exports.hc生物质合成区 = hc生物质合成区;
SFlib.addToResearch(hc生物质合成区, {
	parent: "hc冰冻森林",
	objectives: Seq.with(
	new Objectives.SectorComplete(hc冰冻森林))
})

const hc遗迹海岸 = new SectorPreset("hc遗迹海岸", hc赛普罗, 218);
hc遗迹海岸.description = "";
hc遗迹海岸.difficulty = 2;
hc遗迹海岸.alwaysUnlocked = false;
hc遗迹海岸.addStartingItems = true;
hc遗迹海岸.captureWave = 90;
hc遗迹海岸.localizedName = "hc遗迹海岸";
exports.hc遗迹海岸 = hc遗迹海岸;
SFlib.addToResearch(hc遗迹海岸, {
	parent: "hc陨石带",
	objectives: Seq.with(
	new Objectives.SectorComplete(hc陨石带))
})

const hc增生区 = new SectorPreset("hc增生区", hc赛普罗, 134);
hc增生区.description = "";
hc增生区.difficulty = 2;
hc增生区.alwaysUnlocked = false;
hc增生区.addStartingItems = true;
hc增生区.captureWave = 0;
hc增生区.localizedName = "hc增生区";
exports.hc增生区 = hc增生区;
SFlib.addToResearch(hc增生区, {
	parent: "hc陨石带",
	objectives: Seq.with(
	new Objectives.SectorComplete(hc陨石带))
})

const hc绵延群山 = new SectorPreset("hc绵延群山", hc赛普罗, 20);
hc绵延群山.description = "";
hc绵延群山.difficulty = 2;
hc绵延群山.alwaysUnlocked = false;
hc绵延群山.addStartingItems = true;
hc绵延群山.captureWave = 100;
hc绵延群山.localizedName = "hc绵延群山";
exports.hc绵延群山 = hc绵延群山;
SFlib.addToResearch(hc绵延群山, {
	parent: "hc生物质合成区",
	objectives: Seq.with(
	new Objectives.SectorComplete(hc生物质合成区))
})

const hc真菌通道 = new SectorPreset("hc真菌通道", hc赛普罗, 21);
hc真菌通道.description = "";
hc真菌通道.difficulty = 2;
hc真菌通道.alwaysUnlocked = false;
hc真菌通道.addStartingItems = true;
hc真菌通道.captureWave = 0;
hc真菌通道.localizedName = "hc真菌通道";
exports.hc真菌通道 = hc真菌通道;
SFlib.addToResearch(hc真菌通道, {
	parent: "hc绵延群山",
	objectives: Seq.with(
	new Objectives.SectorComplete(hc绵延群山))
})

const hc核裂阵 = new SectorPreset("hc核裂阵", hc赛普罗, 130);
hc核裂阵.description = "";
hc核裂阵.difficulty = 2;
hc核裂阵.alwaysUnlocked = false;
hc核裂阵.addStartingItems = true;
hc核裂阵.captureWave = 200;
hc核裂阵.localizedName = "hc核裂阵";
exports.hc核裂阵 = hc核裂阵;
SFlib.addToResearch(hc核裂阵, {
	parent: "hc真菌通道",
	objectives: Seq.with(
	new Objectives.SectorComplete(hc真菌通道))
})

const hc风吹群岛 = new SectorPreset("hc风吹群岛", hc赛普罗, 246);
hc风吹群岛.description = "";
hc风吹群岛.difficulty = 2;
hc风吹群岛.alwaysUnlocked = false;
hc风吹群岛.addStartingItems = true;
hc风吹群岛.captureWave = 110;
hc风吹群岛.localizedName = "hc风吹群岛";
exports.hc风吹群岛 = hc风吹群岛;
SFlib.addToResearch(hc风吹群岛, {
	parent: "hc遗迹海岸",
	objectives: Seq.with(
	new Objectives.SectorComplete(hc遗迹海岸))
})