//
const colors = [Pal.lancerLaser.cpy().mul(1, 1, 1, 0.4), Pal.lancerLaser, Color.white];
//
const tscales = [1, 0.7, 0.5, 0.2];
//
const lenscales = [1, 1.1, 1.13, 1.14];
//
const length = 8000;

const 末日激光 = extend(BasicBulletType,{
    range(){
        return length;
    },
    //mindustry.entities.type.Bullet
    // init(b){
    // },
    update(b){
        if (b.time()<0.001) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), length);
        }
        print(b.time())
    },
    draw(b){
        const f = Mathf.curve(b.fin(), 0, 0.2);
        const baseLen = length * f;

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for(var s = 0; s < 3; s++){
            Draw.color(colors[s]);
            for(var i = 0; i < tscales.length; i++){
                Lines.stroke(7 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.3) * tscales[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscales[i]);
            }
        }
        Draw.reset();
    }
})
末日激光.damage = 10000;
末日激光.speed = 0.001;
末日激光.hitEffect = Fx.lancerLaserCharge;
末日激光.despawnEffect = Fx.none;
末日激光.hitSize = 64;
末日激光.lifetime = 240;
末日激光.pierce = true;

const 末日 = extendContent(ChargeTurret,"末日",{})

末日.shootType = 末日激光;

末日.chargeEffect = newEffect(600, e => {
    Draw.color(Color.valueOf("#7b68ee"),Color.valueOf("#e4ebff"),e.fin());
    
    Lines.stroke(e.fin() * 3);
    Lines.circle(e.x, e.y, e.fout() * 60);
    Lines.stroke(e.fin() * 1.75);
    Lines.circle(e.x, e.y, e.fout() * 45);
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 25, 1 + 120 * e.fout(), e.rotation, 100,d);
});



//
const colors1 = [Pal.lancerLaser.cpy().mul(1, 1, 1, 0.4), Pal.lancerLaser, Color.white];
//
const tscales1 = [1, 0.7, 0.5, 0.2];
//
const lenscales1 = [1, 1.1, 1.13, 1.14];
//
const length1 = 8000;

const 小激光 = extend(BasicBulletType,{
    range(){
        return length;
    },
    //mindustry.entities.type.Bullet
    // init(b){
    // },
    update(b){
        if (b.time()<0.001) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), length);
        }
        print(b.time())
    },
    draw(b){
        const f = Mathf.curve(b.fin(), 0, 0.2);
        const baseLen = length * f;

        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for(var s = 0; s < 3; s++){
            Draw.color(colors[s]);
            for(var i = 0; i < tscales.length; i++){
                Lines.stroke(7 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.3) * tscales[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscales[i]);
            }
        }
        Draw.reset();
    }
})
小激光.damage = 60;
小激光.speed = 0.001;
小激光.hitEffect = Fx.hitLancer;
小激光.despawnEffect = Fx.none;
小激光.hitSize = 8;
小激光.lifetime = 60;
小激光.pierce = true;

const 粒子光矛 = extendContent(ChargeTurret,"粒子光矛",{})

粒子光矛.shootType = 小激光;

粒子光矛.chargeEffect = newEffect(180, e => {
    Draw.color(Color.valueOf("#7b68ee"),Color.valueOf("#e4ebff"),e.fin());
    
    Lines.stroke(e.fin() * 1);
    Lines.circle(e.x, e.y, e.fout() * 32);
    Lines.stroke(e.fin() * 1);
    Lines.circle(e.x, e.y, e.fout() * 16);
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 25, 1 + 48 * e.fout(), e.rotation, 100,d);
});






