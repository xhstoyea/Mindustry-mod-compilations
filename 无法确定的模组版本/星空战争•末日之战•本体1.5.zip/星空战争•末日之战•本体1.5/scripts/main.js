if(typeof(require) !== "undefined"){ 
	require("blocks/末日");
	require("blocks/球球炮");
    require("blocks/粒子光矛");
    require("blocks/行星护盾");
}