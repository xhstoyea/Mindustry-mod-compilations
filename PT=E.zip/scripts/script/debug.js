try{F}catch(error){print("+ Loaded "+error.fileName)}

function datezero(x){return x.toString().padStart(2,"0")}

function date(){
	var d = new Date();
	var dt = d.getFullYear()+datezero(d.getMonth()+1)+datezero(d.getDate());
	var hr = datezero(d.getHours())+datezero(d.getMinutes())+datezero(d.getSeconds());
	return "crashlog_"+dt+"_"+hr+".txt";
}

var crashlog={"data":[],"ok":false};

var output = {
debug(x){
var data = x.fileName+"\nLine "+x.lineNumber+"\n"+x;
Vars.dataDirectory.child('qt/crash/'+date()).writeString(data);
print(data);
if(crashlog.ok)Vars.ui.showErrorMessage("[#ffdfdf]Unfortunately, PT=E v"+(global.pt?global.pt.modv:"null")+" has crashed.\n\n[white]Details: \n"+data);
else crashlog.data.push("[#ffdfdf]Unfortunately, PT=E v"+(global.pt?global.pt.modv:"null")+" has crashed.\n\n[white]Details: \n"+data);
},
debug2(data){
Vars.dataDirectory.child('qt/crash/'+date()).writeString(data);
print(data);
if(crashlog.ok)Vars.ui.showErrorMessage("[#ffdfdf]Unfortunately, PT=E v"+(global.pt?global.pt.modv:"null")+" has crashed.\n\n[white]Details: \n"+data);
else crashlog.data.push("[#ffdfdf]Unfortunately, PT=E v"+(global.pt?global.pt.modv:"null")+" has crashed.\n\n[white]Details: \n"+data);
},
}

module.exports=output;
global.ptdebug=output;

Events.on(EventType.ClientLoadEvent, cons(e => {
	crashlog.ok=true;
	crashlog.data.forEach(q=>{Vars.ui.showErrorMessage(q)});
}))