try{F}catch(error){print("+ Loaded "+error.fileName)}

global.pt0={}

function readDetails(str){
	try{return JSON.parse(str.split("\n")[0].substring(2));
	}catch(error){return {}}
}

function init2(qdata){
try{
var details = readDetails(qdata.readString());
	try{
		Vars.mods.scripts.run(null,qdata);
		print("<qtscripts> + Loaded: "+details.name+"[gray] | Version: "+details.version)
	}catch(error){print(error)}
}catch(error){print(error)}
}

var files=[
"init_qt",
"Dialog_MapINFO","Dialog_healthbar","Dialog_keybind","Dialog_keybindMobile","Dialog_MapsSelector","Dialog_playerfragplus","Dialog_pm",
"powerNodeFix","scheme_parse","StealUnit","command","AutoBluePrint",
"AI_builder2AI","AI_followbuildAI","AI_followingAI","AI_miner","AI_waypt",
"Cheat_Ship","pRecord_search",
"qt_AntiGrief","qt_encrypt","qt_SideBarDialog","qtf","QTlog","uuid2"];

files.forEach(q=>{
init2(Vars.tree.get("scripts/qtscript/"+q+".js"));
})