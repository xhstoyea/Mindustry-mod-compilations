//{"name":"AI_waypt","version":210.2,"date":20230127}

var _0x33=0;
var _0x30=0;
global.pt0.wayptAI=
extend(AIController,{
	wayptlist:[],
	zero(){
		_0x33=0
	},
	unitS(u){
		if(this.unit == u) return;
        this.unit = u;
        this.init();
	},
	updateMovement(){
		try{
		if(this.wayptlist.length>0){
		
		let _0x31=this.wayptlist[_0x30];
		let _0x32 = Vars.player.dst(_0x31[1]*8,_0x31[2]*8)/8;
		switch(_0x31[0]){
			case 1:
			if (_0x32 < 6 && Vars.state.tick>_0x33){
			Call.transferInventory(Vars.player,_0x31[3]);
			_0x33=Vars.state.tick+(_qtglobal.autotakedur*60);
			_0x30++;
			_0x30=_0x30 % this.wayptlist.length;
			}
			break;
			case 3:
			if (_0x32 < 6 && Vars.state.tick>_0x33){
			Call.requestItem(Vars.player,_0x31[3],_0x31[4],999);
			_0x33=Vars.state.tick+(_qtglobal.autotakedur*60);
			_0x30++;
			_0x30=_0x30 % this.wayptlist.length;
			}
			break;
			case 2:
			Call.dropItem(0);
			case 1:
			if(_0x32 < 6 && Vars.state.tick>_0x33){
				_0x30++;
				_0x30=_0x30 % this.wayptlist.length;
			}
			break;
		}
		this.moveTo(Vars.world.rawTile(_0x31[1],_0x31[2]),15,20);
		}
		}catch(error){debug(error)}
	}
})
