//{"name":"scheme_parse","version":1,"date":20230127}

function getbattery(k,b){
if(Math.abs(k)<1)return 0;
if(Math.abs(k)===Infinity)return Infinity;
var scale = [[1,""],[1e3,"k"],[1e6,"M"],[1e9,"G"],[1e12,"T"]].filter(f=>f[0]<=Math.abs(k)).reverse();
var num=Math.round(k/scale[0][0]*b)/b;
return num+(Math.floor(num)==num&&b>1?".0":"")+scale[0][1];
}

function getReq(sche){
var k=[
[0,0,0,0,0,0,0,0,0,0],
sche.height+"x"+sche.width,
getbattery(60*(sche.powerProduction()-sche.powerConsumption()),10),
parseSch2(sche)
];
return JSON.stringify(k);
}

var dict={
	"r2type":["炮塔","钻头","运输","液体","电力","墙","工厂","单位","其他","逻辑"],
	"A":"[Pt=E] 蓝图详细\n大小:",
	"B":"\n蓝图建筑类别: [gold]<1>[white]",
	"C":"\n[white]电力",
	"D":"\n\n全部建筑: ",
	"Blank":"",
}

function parseReq(str){
var r=JSON.parse(str);
var r2 = r[0].map((f,i)=>[f,i]);
r2[2]=0;r2.sort((a,b)=>{return a[0]>b[0]?-1:1});

return dict.A+r[1]+dict.B+dict.r2type[r2[0][1]]+" [gray]("+r2[0][0]+")"+"\n[gray]<2>[white]"+dict.r2type[r2[1][1]]+" [gray]("+r2[1][0]+")"+"\n[brown]<3>[white]"+dict.r2type[r2[2][1]]+" [gray]("+r2[2][0]+")"+dict.C+r[2]+dict.D+"\n"+r[3];
}

function parseSch2(sche){
	var a=[];
	for (var y=0;y<sche.height;y++){a[y]=[];for (var x=0;x<sche.width;x++)a[y][x]=dict.Blank};
	sche.tiles.each(q=>{
		if(!a[q.y])a[q.y]=[];
		a[q.y][q.x]=q.block.emoji()
	});
	
	a =a.map(q=>q.join("")).join("\n");
	return a;
}


function cleanPlans(){
var Plans=[];
Vars.player.team().data().plans.each((f,i)=>{
Plans.push(Point2.pack(f.x,f.y));
if(i%15==0){Call.deletePlans(Vars.player,Plans);Plans=[];}
});
Call.deletePlans(Vars.player,Plans);
}

//scheme_parse.cleanPlans();

global.pt0.scheme_parse={
getReq(x){
return getReq(x)
},
parseReq(x){
return parseReq(x)
},
cleanPlans(){
return cleanPlans()
},
}