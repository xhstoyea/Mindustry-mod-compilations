//{"name":"Dialog_healthbar","version":210.21,"date":20230127}

//210.2 修复unit==null 相关bug
//210.21 修复部分错误

var orig = null;

var maxwidth=314*0.9;
function get_hover(pp){
	var h3=Units.closestTarget(Vars.player.team(),Core.input.mouseWorldX(), Core.input.mouseWorldY(),16);
	if(h3 && h3.isAI)return (pp?h3:true);
	return (pp?Vars.ui.hudfrag.blockfrag.hover():false);
}

function parseNumber2(num){
	if(num<1.5e6)return num;
	if(num<1.5e9)return Math.floor(num/1e7)*10+'[gray]M[]';
	if(num<1.5e12)return Math.floor(num/1e10)*10+'[gray]G[]';
	return "[gray]Infinity[]";
}

var language=global.pt.getValue("language");
var GlobalDict={
	"selfHealth":"自己血量: ",
	"targetHealth":language==0?"目标血量: ":"目標血量: ",
	"power":language==0?"电力 : ":"電力: ",
	"powerStored":language==0?"电力储存 : ":"電力儲存 : ",
	"ammo2":language==0?"弹药: ":"彈藥 : ",
	"progress":language==0?"进度: ":"進度 : ",
	"heat":language==0?"热量: ":"熱量 : ",
	"min":"分","sec":"秒",
};

var messageTarget = null;
var messageTable = new Table();
const MessageTypeBlock = [Blocks.message,Blocks.reinforcedMessage,Blocks.worldMessage];

if(global.pt.getValue("otherTeamBuild"))
Events.run(Trigger.draw, () => {
	if(!global.pt.getValue("otherTeamBuild"))return;
	var h=get_hover(true);
	if(!h && Core.input.mouseWorldX() && Core.input.mouseWorldY()){h=Vars.world.build(Math.floor(Core.input.mouseWorldX()/8),Math.floor(Core.input.mouseWorldY()/8))}
	if(!h)return;
	if(h.range){
		Drawf.dashCircle(h.x,h.y,(isNaN(h.range)?h.range():h.range)+(h.phaseHeat?h.phaseHeat*h.block.phaseRangeBoost:0),h.team.color);
		Draw.color(h.team.color);
		Draw.alpha(0.15);
		Fill.circle(h.x,h.y,(isNaN(h.range)?h.range():h.range)+(h.phaseHeat?h.phaseHeat*h.block.phaseRangeBoost:0));
		Draw.color(Color.white);
	}
	
	if(Vars.state && Vars.state.rules && !Vars.state.rules.editor && h instanceof Building && ((h.block instanceof LogicBlock && h.team!=Vars.player.team()) || h.block==Blocks.worldProcessor)){
		if(messageTarget!=h){
		messageTarget=h;
		messageTable.remove();
		messageTable = new Table().margin(4);
		messageTable.button(Icon.pencil,q=>{Vars.ui.logic.show(h.code,h.executor,true,q=>{})});
		//messageTable.touchable = Touchable.disabled;
        messageTable.update(() => {
            if(Vars.state.isMenu()) messageTable.remove();
            var v = Core.camera.project(h.x, h.y-4);
            messageTable.setPosition(v.x, v.y, Align.bottom);
        });
        Core.scene.root.addChildAt(0, messageTable);
        messageTable.getChildren().first().act(0);
		}
		h.drawConfigure();
	}else if(messageTarget!=h){
		if(h instanceof Building && MessageTypeBlock.includes(h.block) && h.team!=Vars.player.team())h.drawSelect();
		messageTable.remove();messageTarget=null;
	}

})
Blocks.itemBridge.allowConfigInventory=true;

function parseMemory(b){if(!MemoryShow[0])MemoryShow[0]=0;MemoryShow[1]=b.memory.map((q,i)=>[i,q]).filter(w=>w[1])}
function returnMemory(){
	if(!MemoryShow[1])return;
	var k = MemoryShow[1].filter((q,i)=>MemoryShow[0]*5-1<i&&i<MemoryShow[0]*5+5);
	if((Date.now() - MemoryShow[2]) >2500){MemoryShow[0] = (MemoryShow[0]+1)%Math.ceil(MemoryShow[1].length/5);MemoryShow[2]=Date.now();}
	return k.map(q=>"[gray]#"+q[0].toString().padEnd(3," ")+" :[white] "+q[1]).join("\n");
}
var MemoryShow = [0,null,Date.now()];

/*
function havenext(b,lastx,lasty){
	Draw.color(Color.green);
	Fill.circle(b.x,b.y,1);
	Lines.stroke(1, Color.green);
	if(lastx || lasty)try{eval('Lines.line​(b.x,b.y,lastx,lasty)')}catch(error){print(error)}
	if(b.next || b.nextc || (b.next && b.next())){
		havenext(b.next || b.nextc || (b.next && b.next()),b.x,b.y)
	}
}
*/

function _load_newFrag(){
	if(Vars.ui && Vars.ui.hudfrag && !Reflect.get(Vars.ui.hudfrag.blockfrag, "topTable").visible){
	var k=get_hover(true);
	if(k){
		var kTEAM = (k.team instanceof Team?k.team:k.team());
	Vars.ui.showInfoPopup(GlobalDict.selfHealth+Math.floor(Vars.player.unit().health+Vars.player.unit().shield)+"\n[#"+kTEAM.color+"] "+kTEAM.localized()+" [white]"+(k&&k.type&&k.type.emoji?k.type.emoji():"")+" "+k.type.localizedName+"\n"+(k.shield?"[cyan]":"")+Math.floor(k.health+k.shield)+"[white] / "+Math.floor(k.maxHealth),0.35,16,0,0,0,0);
	}else{
		var h=Vars.world.build(Math.floor(Core.input.mouseWorldX()/8),Math.floor(Core.input.mouseWorldY()/8));
		if(h &&h.block instanceof MemoryBlock){
			parseMemory(h);
			Vars.ui.showInfoPopup(GlobalDict.selfHealth+Math.floor(Vars.player.unit().health+Vars.player.unit().shield)+"\n"+returnMemory(),0.35,16,0,0,0,0);
		}
	}
	}
}

function haseffects(k){
	var n="";
	for (var i in StatusEffects){try{let j=StatusEffects[i];if(k.hasEffect(j))n+=j.emoji()+" "+j+" "+Math.floor(k.getDuration(j)/60)}catch(error){}};
	return n
}

function _reload(){
orig = Reflect.get(Vars.ui.hudfrag.blockfrag, "topTable");
var origt = orig.children.get(0);
function getbattery(k,b){
if(Math.abs(k)<1)return 0;
if(Math.abs(k)===Infinity)return Infinity;
var scale = [[1,""],[1e3,"[gray]k[white]"],[1e6,"[gray]M[white]"],[1e9,"[gray]G[white]"],[1e12,"[gray]T[white]"]].filter(f=>f[0]<=Math.abs(k)).reverse();
var num=Math.round(k/scale[0][0]*b)/b;
return num+(Math.floor(num)==num&&b>1?".0":"")+scale[0][1];
}

var better_table = new Table();
var Drawn_Element= 0;
orig.clearChildren();
orig.row();
var ORIG_TABLE = orig.add(origt);
ORIG_TABLE.width(maxwidth);
orig.row();
orig.add(better_table).width(maxwidth);

better_table.update(f=>{
var h=get_hover(true);
var NEWTABLE = new Table();
var Drawn_ECount=0;
if(h instanceof Unit && (get_hover(false) || haseffects(h))){
	NEWTABLE.add("0").update(f=>{
		var k=get_hover(true);
		if(k && k.team){
		var kTEAM = (k.team instanceof Team?k.team:k.team());
		f.text="[#"+kTEAM.color+"] "+kTEAM.localized()+" [white]"+(k.type?k.type.emoji():"")+" "+(k.type?k.type.localizedName:"")+"\n"+haseffects(k);
		}
	});
	NEWTABLE.row();
	Drawn_ECount+=128;
}
if(Vars.player){
	var my_healthbar = Bar("1",Color.green,f=>0.5);
	my_healthbar.set(prov(()=>{
	return GlobalDict.selfHealth+Math.floor(Vars.player.unit().health+Vars.player.unit().shield);
	}),floatp(()=>{return Vars.player.unit().health/Vars.player.unit().maxHealth}),Color(0.082,0.435,0.188));
	NEWTABLE.add(my_healthbar).width(maxwidth).height(20).pad(4);
	NEWTABLE.row();
	Drawn_ECount+=1;
}
if(h && h.health){
	var opp_healthbar = Bar("1",Color.red,f=>0.5);
	opp_healthbar.set(prov(()=>{
	var h=get_hover(true);
	if(h){
		var hdata = (h.block ? (h.team instanceof Team?h.team:h.team()).rules().blockHealthMultiplier * Vars.state.rules.blockHealthMultiplier : 1);
		return (h.shield?"[cyan]":"")+
	GlobalDict.targetHealth+
	parseNumber2(Math.floor((h.health+(h.shield?h.shield:0)) * hdata))+" [gray]/ "+parseNumber2(Math.floor(h.maxHealth*hdata))+ (hdata==1?"":(hdata>1?"[#ddffdd]":"[#ffdddd]")+" x"+Math.round(hdata*100)/100)
	}
	}),floatp(()=>{
	var h=get_hover(true);
	if(h&&h.health&&h.maxHealth && h.health/h.maxHealth)return h.health/h.maxHealth;
	return 1;
	}),Color(0.514,0.078,0.329));
	NEWTABLE.add(opp_healthbar).width(maxwidth).height(20).pad(4);
	NEWTABLE.row();
	Drawn_ECount+=2;
}
if(h && h.block instanceof MemoryBlock){
	parseMemory(h);
	NEWTABLE.add("0").update(f=>{
		f.text=""+returnMemory();
	});
	NEWTABLE.row();
	Drawn_ECount+=256;
}
if(h && h.power){
	var power_bar = Bar("1",Color.yellow,f=>0.5);
	power_bar.set(prov(()=>{
	var h=get_hover(true);
	if(h&&h.power){
	var g=h.power.graph;
	return GlobalDict.power+getbattery(60*g.getPowerBalance(),10)
	}else{return ""}
	}),floatp(()=>{
		var h=get_hover(true);
		if(h && h.power){
			return h.efficiency
		}else return 1;
		}),Color(0.776,0.290,0.082));
	NEWTABLE.add(power_bar).width(maxwidth).height(20).pad(4);
	NEWTABLE.row();

	var battery_bar = Bar("1",Color.yellow,f=>0.5);
	battery_bar.set(prov(()=>{
	var h=get_hover(true);
	if(h&&h.power){
	var g=h.power.graph;
	return GlobalDict.powerStored+getbattery(g.totalBatteryCapacity-g.batteryCapacity,10)+"/"+getbattery(g.totalBatteryCapacity,10)
	}else{return ""}
	}),floatp(()=>{
	var h=get_hover(true);
	if(h&&h.power){
	var g=h.power.graph;
	return (g.totalBatteryCapacity-g.batteryCapacity)/g.totalBatteryCapacity
	}else{return 1};
	}),Color(0.776,0.290,0.082));
	NEWTABLE.add(battery_bar).width(maxwidth).height(20).pad(4);
	NEWTABLE.row();
	Drawn_ECount+=4;
}
if(h && h.liquids && h.liquids.currentAmount()>0){
	var liquid_bar = Bar("1",Color.yellow,f=>0.7);
	liquid_bar.set(prov(()=>{
	var h=get_hover(true);
	if(h && h.liquids){
	return h.liquids.current()+" [gray]"+Math.round(h.liquids.currentAmount())
	}else{return ""}
	}),floatp(()=>{
		return h.liquids.currentAmount()/h.block.liquidCapacity
	}),Color(h.liquids.current().color));
	NEWTABLE.add(liquid_bar).width(maxwidth).height(20).pad(4);
	NEWTABLE.row();
	Drawn_ECount+=8;
}
if(h && h.ammo && h.ammo.size>0){
	var AMMO_bar = Bar("1",Color.yellow,f=>0.7);
	AMMO_bar.set(prov(()=>{
	var h=get_hover(true);
	if(h && h.ammo && h.ammo.size>0){
	return GlobalDict.ammo2+h.ammo.get(0).amount+"/[gray]"+h.block.maxAmmo+" ("+h.ammo.get(0).item+")"
	}else{return ""}
	}),floatp(()=>{return 1}),Color(h.ammo.get(0).item.color));
	NEWTABLE.add(AMMO_bar).width(maxwidth).height(20).pad(4);
	NEWTABLE.row();
	Drawn_ECount+=16;
}
if(h && h.heat){
	var heat_bar = Bar("1",Color.yellow,f=>0.7);
	heat_bar.set(prov(()=>{
	var h=get_hover(true);
	if(h && h.heat){
	return GlobalDict.heat+" [gray]"+(h.heat>1?Math.round(h.heat):Math.round(h.heat*100)+"%")
	}else{return ""}
	}),floatp(()=>{return (h.heat>1?1:h.heat)}),Color.orange);
	NEWTABLE.add(heat_bar).width(maxwidth).height(20).pad(4);
	NEWTABLE.row();
	Drawn_ECount+=32;
}
const Strange_block=[Blocks.tankAssembler,Blocks.shipAssembler,Blocks.mechAssembler];
if(h && h.block && h.progress && h.progress>0 && h.currentPlan!=-1 && (h.block.plans||h.block.constructTime)){
	var progress_bar = Bar("1",Color.yellow,f=>0.7);
	progress_bar.set(prov(()=>{
	var h=get_hover(true);
	if(h && h.progress && (h.block.plans||h.block.constructTime)){
		if(Strange_block.includes(h.block)){
			return GlobalDict.progress+Math.round(h.progress*100)+"%"
		}else{
	var needed_time = (h instanceof UnitFactory.UnitFactoryBuild?h.block.plans.get(h.currentPlan).time:h.block.constructTime);
	var prog = h.progress / needed_time;
	var time_remain = ((needed_time-h.progress)/60)/(h.team.rules().unitBuildSpeedMultiplier*Vars.state.rules.unitBuildSpeedMultiplier);
	return GlobalDict.progress+Math.round(prog*100)+"% [gray]("+(time_remain>60?Math.round(time_remain/60)+GlobalDict.min+""+Math.round(time_remain%60)+GlobalDict.sec:Math.round(time_remain)+""+GlobalDict.sec)+")"
		}
	}else{return ""}
	}),floatp(()=>{
		var h=get_hover(true);
		if(h && h.block && h.progress && (h.block.plans||h.block.constructTime)){
			if(Strange_block.includes(h.block)){
				return h.progress
			}else{
		var prog = h.progress / (h instanceof UnitFactory.UnitFactoryBuild?h.block.plans.get(h.currentPlan).time:h.block.constructTime);
		return prog;
			}
		}else return 1;
		}),Color.orange);
	NEWTABLE.add(progress_bar).width(maxwidth).height(20).pad(4);
	NEWTABLE.row();
	Drawn_ECount+=64;
}
if(Drawn_ECount!=Drawn_Element){
better_table.clearChildren();
better_table.add(NEWTABLE);
Drawn_Element=Drawn_ECount;
}
});
}

global.pt0.healthbar={
reload(){if(Vars.ui.hudfrag&&Vars.ui.hudfrag.blockfrag && orig != Reflect.get(Vars.ui.hudfrag.blockfrag, "topTable"))_reload()},
loadFrag(){_load_newFrag()}
}