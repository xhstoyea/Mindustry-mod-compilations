//{"name":"Cheat_Ship","version":210,"date":20230127}

const RUnit = [
UnitTypes.risso,UnitTypes.minke,UnitTypes.bryde,UnitTypes.sei,UnitTypes.omura,UnitTypes.retusa,UnitTypes.oxynoe,UnitTypes.cyerce,UnitTypes.aegires,UnitTypes.navanax,
UnitTypes.stell,UnitTypes.locus,UnitTypes.precept,UnitTypes.vanquish,UnitTypes.conquer
];
var RSpeed=RUnit.map(q=>q.rotateSpeed);

global.pt0.Cheat_Ship={
reload(){
		if(!Vars || !Vars.player || !Vars.player.unit)return;
		if(Vars.player.unit().rotateSpeed!=144 && RUnit.includes(Vars.player.unit().type)){
			RUnit.forEach((q,i)=>q.rotateSpeed=RSpeed[i]);
			Vars.player.unit().type.rotateSpeed=144;
		}
},
reloadall(){
	RUnit.forEach(q=>q.rotateSpeed=144);
}
}