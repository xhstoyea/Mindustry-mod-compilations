//{"name":"QTlog","version":210.02,"date":20230616}

function allFI(){
	var t2 = new Table(Tex.whiteui.tint(0,0,2/16,0.5));
	var t4 = new Table(Tex.whiteui.tint(6/16,0,0,0.35));
	t4.labelWrap("pt LOG 查询").width(360).fillY().left();
	t4.button("X",Styles.cleart,e=>{
		t2.remove();
	}).width(40).height(35).right();
	t2.add(t4);
	var lastX,lastY;
	t4.addListener(extend(InputListener,{
		touchDown(event,x,y,pointer,buttwon){
			lastX=x;
			lastY=y;
			return true;
		},
		touchUp(event,x,y,pointer,button){
			t2.x+=x-lastX;
			t2.y+=y-lastY;
		}
	}));
	
	t2.row();

	var pane2 = null;
	
	t2.pane(cons(k=>{
		Vars.dataDirectory.child("qt/logs").findAll().each(w=>{
			k.button(w.name(),Styles.cleart,e=>{
				readFI(w.name());
			}).width(400).height(35).left().row();
		})
	})).width(400);
	Core.scene.table().add(t2);
}

function readFI(finame){
	finame = "qt/logs/"+finame;
	var t2 = new Table(Tex.whiteui.tint(0,0,2/16,0.5));
	var t4 = new Table(Tex.whiteui.tint(6/16,0,0,0.35));
	t4.labelWrap(finame).width(660).fillY().left();
	t4.button("[#ffffaa]",Styles.cleart,e=>{
		Core.app.setClipboardText(Vars.dataDirectory.child(finame).readString());Vars.ui.showInfoFade("已复制!");
	}).width(40).height(35).right();
	t4.button("X",Styles.cleart,e=>{
		t2.remove();
	}).width(40).height(35).right();
	t2.add(t4);
	var lastX,lastY;
	t4.addListener(extend(InputListener,{
		touchDown(event,x,y,pointer,buttwon){
			lastX=x;
			lastY=y;
			return true;
		},
		touchUp(event,x,y,pointer,button){
			t2.x+=x-lastX;
			t2.y+=y-lastY;
		}
	}));
	
	t2.row();
	
	var search = new Table(Tex.whiteui.tint(0,6/16,0,0.35));
	var searcher = "";
	search.field("",e=>{searcher=e}).left().width(400);
	search.button("搜寻",Styles.cleart,e=>{regen(searcher,pane2,finame)}).width(50);
	t2.add(search).row();
	
	var pane2 = null;
	
	t2.pane(cons(k=>{pane2=k}));
	regen("",pane2,finame);
	
Core.scene.table().add(t2);
}

function regen(parm,k,fi){
	print(parm);
	k.clear();
	Vars.dataDirectory.child(fi).readString().split("\n").forEach(w=>{
	
	if(parm=="" || w.includes(parm)){
	k.labelWrap(""+w).marginTop(30).width(700).left();
	k.button("[#ffffaa]",Styles.cleart,e=>{
		Core.app.setClipboardText(w);Vars.ui.showInfoFade("已复制!");
	}).width(40).height(45);
	k.button("[#aaffaa]",Styles.cleart,e=>{
		let text2 = w;
		while(text2.length>0){
			global.pt.sendChatMessageQueue(text2.substring(0,150));
			text2 = text2.substring(150);
		}
	}).width(40).height(45).row();
	}
	})
}

global.pt0.qtlog={
	"allFI":allFI
}