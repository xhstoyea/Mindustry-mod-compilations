//{"name":"powerNodeFix","version":1,"date":20230127}

var language=global.pt.getValue("language");


function getbattery(k,b){
if(Math.abs(k)<1)return 0;
if(Math.abs(k)===Infinity)return Infinity;
var scale = [[1,""],[1e3,"[gray]k[white]"],[1e6,"[gray]M[white]"],[1e9,"[gray]G[white]"],[1e12,"[gray]T[white]"]].filter(f=>f[0]<=Math.abs(k)).reverse();
var num=Math.round(k/scale[0][0]*b)/b;
return num+(Math.floor(num)==num&&b>1?".0":"")+scale[0][1];
}

function fixing(){
var powerNodes = Vars.state.teams.get(Vars.player.team()).buildings.filter(boolf(f=>f.block instanceof PowerNode));
var powerGraph = [];
var timeout=0;
powerNodes.each(f=>{if (!powerGraph.includes(f.power.graph))powerGraph.push(f.power.graph);});
if(powerGraph.length>0){
powerGraph.sort((a,b)=>{return (a.all.size>b.all.size?-1:1)});
var solved=[];
powerGraph.forEach((f,id)=>{
f.all.each(boolf(f=>f.block instanceof PowerNode),f=>{
	if(f.power.links.size<f.block.maxNodes){
	Vars.indexer.eachBlock(Vars.player.team(),f.x,f.y,f.block.laserRange*8,boolf(g=>g.block.hasPower),k=>{
		if(!solved.includes(k.power.graph.getID()) && k.power.graph.getID()!=f.power.graph.getID() && !PowerNode.insulated(f,k)){
			Timer.schedule(()=>{f.onConfigureBuildTapped(k);},timeout);
			timeout+=0.3;
			solved.push(k.power.graph.getID());
		}
	});
	}
})
});
timeout+=1;
Timer.schedule(()=>{getDecreased(powerGraph.length);},timeout);
Vars.ui.chatfrag.addMessage((language==0?"电网":"電網")+" processing . . .");
}
	
}

function getDecreased(origpowerG){
var powerNodes = Vars.state.teams.get(Vars.player.team()).buildings.filter(boolf(f=>f.block instanceof PowerNode));
var powerGraph = [];
powerNodes.each(f=>{if (!powerGraph.includes(f.power.graph))powerGraph.push(f.power.graph);});
powerGraph.sort((a,b)=>{return (a.all.size>b.all.size?-1:1)});
Vars.ui.chatfrag.addMessage("[scarlet][[Pt=E]"+(language==0?"[white]已连接":"[white]已連接")+(origpowerG-powerGraph.length)+"[gray]/"+powerGraph.length+"[white]"+(language==0?"个断开的电网":"個斷開的電網"));
powerGraph.forEach((f,id)=>{
	Vars.ui.chatfrag.addMessage((id==0?(language==0?"主电网":"主電網")+": ":(language==0?"电网":"電網")+id+": ")+"[gray]"+f.all.get(0).x/8+","+f.all.get(0).y/8+" [white]"+Core.bundle.format("bar.poweramount",getbattery(f.getPowerBalance()*60,100))+"  "+Core.bundle.format("bar.powerstored",getbattery(f.totalBatteryCapacity-f.batteryCapacity,100),getbattery(f.totalBatteryCapacity,100))+" [gray]("+Math.round(100*(f.totalBatteryCapacity-f.batteryCapacity)/f.totalBatteryCapacity)+"%) "+f.all.size+(language==0?"个建筑":"個建築"))
	});
}

global.pt0.powerNodeFix={
fix(){
	fixing()
},
}