//{"name":"qtf","version":109,"date":20230127}

var head2={};

head2.orig_cleanfiles = function(){
try{
var data = Vars.dataDirectory.child('qt/ptall').readString().split("\n");
var parsed = [];
var v2= data.shift();
Vars.dataDirectory.child('qt/ptall').writeString(v2);
parsed.push(v2.name+">|<"+v2.uuid+">|<"+v2.ip);
data.forEach(e=>{
	var f=JSON.parse(e);
	if(!parsed.includes(f.name+">|<"+f.uuid+">|<"+f.ip)){
		parsed.push(f.name+">|<"+f.uuid+">|<"+f.ip);
		Vars.dataDirectory.child('qt/ptall').writeString(",\n"+e,true);
	};
});
return parsed.length;
}catch(error){debug(error)}
}

head2._cleanfiles = function(){
try{
var data = JSON.parse("["+Vars.dataDirectory.child('qt/ptall').readString()+"]");
var parsed = [];
var ok=[];
data.forEach(f=>{
	if(!parsed.includes(f.name+">|<"+f.uuid+">|<"+f.ip)){
		parsed.push(f.name+">|<"+f.uuid+">|<"+f.ip);
		ok.push(JSON.stringify(f));
	};
});
Vars.dataDirectory.child('qt/ptall').writeString(ok.join(",\n"));
return parsed.length;
}catch(error){debug(error)}
}
//Remove Duplicated IP Records

function todayDate(e){
	var d = new Date();
	var k = d.getFullYear()+"-"+(d.getMonth()+1).toString().padStart(2,"0")+"-"+(d.getDate()).toString().padStart(2,"0");
	if(e)k+=" "+d.getHours().toString().padStart(2,"0")+":"+d.getMinutes().toString().padStart(2,"0")+":"+d.getSeconds().toString().padStart(2,"0");
	return k;
}

head2.schc = function (){
try{
	const Limit = 215;
	var text = Core.app.getClipboardText();
	var sch = Vars.schematics.create(0,0,0,0);
	var Width = Math.ceil(Math.sqrt(text.length/Limit));
	var Height = Math.ceil(text.length/Limit/Width);
	for (var iy=0;iy<Width;iy++)for (var ix=0;ix<Height+1;ix++){
	var text2=text.substring(iy*(Height+1)*Limit+ix*Limit,iy*(Height+1)*Limit+ix*Limit+Limit);
	if(text2)
	sch.tiles.add(Schematic.Stile(Blocks.message,ix,-iy,text2,0));
	}
	sch.tags.put("name","TXT_"+todayDate(1));
	sch.labels=new Seq(["txt"]);
	Vars.schematics.add(sch);
	return sch
}catch(error){print(error)}
}
//schematicscreate(Vars.schematics.writeBase64(Vars.schematics.all().find(f=>f.name()=='bad apple')))
//Schematics To Message Tiles

function word2u(){
	var str = Core.app.getClipboardText();
	var g="";
	for (var i=0;i<str.length;i++){
		if(str.charCodeAt(i)>128)
		g+="\\u"+str.charCodeAt(i).toString(16).toString().padStart(4,"0");
		else g+=str[i];
		};
	Core.app.setClipboardText(g);
	return g;
}
head2.word2u = word2u;
// not used


head2.test2 = function(){throw "hi"}

global.qtf=head2;