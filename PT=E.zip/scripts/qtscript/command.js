//{"name":"command","version":210,"date":20230127}

function _chkcrash(index){
var fi = Vars.dataDirectory.child('qt/crash').findAll();
if(!index)index=0;
if(fi.toArray().length>0){
var result = fi.toArray().slice(index*5,index*5+5);
result = result.map((e,i)=>"[gray]Crash Log [sky]#"+(i+index)+"[white] "+e.readString().replace("\n","  ")+"  [gray]"+e.name());
result.unshift("[sky]---  [white][PT=E] Crash Logs  [yellow]"+(index+1)+"[gray] / "+Math.ceil(fi.size/5));
return result;
}
}

function chathistorycount(){return Vars.dataDirectory.child("qt/logs").findAll().size}

function aboutinfo(){
if(Vars.dataDirectory.child("qt/starsky").exists()){
var about_details = JSON.parse(Vars.dataDirectory.child("qt/starsky").readString());
}else{
var about_details={};
};
var _0x94=Vars.dataDirectory.child('qt/ptall').readString().split("\n");
var result={
	"data":_0x94.length, 
	"chat":chathistorycount(), 
	"lv":about_details.lv, 
	"pts_next":about_details.pts_next, 
	"totalpts":(parseInt(about_details.pts_next)+parseInt(about_details.pts)), 
	"coins":about_details.coins
	};
return result;
}

global.pt0.command={
_crashlog(g){
return _chkcrash(g)
},
_about(g){
return aboutinfo()
},
}