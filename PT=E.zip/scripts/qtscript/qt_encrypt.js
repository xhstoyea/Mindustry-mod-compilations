//{"name":"qt_encrypt","version":210,"date":20230127}

function todayDate(){
	var d = new Date();
	return (Math.abs((d.getFullYear())-(d.getDate()*d.getMonth()))^(d.getDate()))%65536
}

function encrypt(key,msg,decrypt){
	if(key==0)key=todayDate();
	var temp=key,result="";
	for (var i=0;i<msg.length;i++){
		result+=String.fromCharCode(msg.charCodeAt(i)^temp);
		temp = msg.charCodeAt(i)^(decrypt?temp:0);
	}
	return result;
}

global.pt0.qt_encrypt={
encrypt(a,b,c){
return encrypt(a,b,c)
},
}