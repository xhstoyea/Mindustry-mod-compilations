//{"name":"qt_SideBarDialog","version":2.15,"date":20230127}

const Notfication = new Sound(Vars.tree.get("assets/Notfication.mp3"));

var SideDialogData = {
	"id":0,"menu":{},"vote":{},
};
var SideDialog=new Table();
var marks_type={
    Defend:"[green]",
    Attack:"[scarlet]",
    Gather:"[cyan]",
    What:"[pink]？",
    Mark:"[gold]"
};

function todayDate(e){
	var d = new Date();
	var k = d.getFullYear()+"-"+(d.getMonth()+1).toString().padStart(2,"0")+"-"+(d.getDate()).toString().padStart(2,"0");
	if(e)k+=" "+d.getHours().toString().padStart(2,"0")+":"+d.getMinutes().toString().padStart(2,"0")+":"+d.getSeconds().toString().padStart(2,"0");
	return k;
}

var MenuConst={
	"menuid2name":["快捷指令","投票","Test验证","塔防菜单","换领资源","地图列表","","帮助"],
	"menuid2time":[1.5,1.5,-1,1.5,1.5,2,1.5,2],
	"votes":1,
};

if(global._qt.MenuCall)
Vars.net.handleClient(MenuCallPacket,g=>{
var k=[];
if(g.menuId==1)MenuConst.votes=1;
g.options.forEach(q=>{q.forEach(w=>{k.push(w)})});
var data = ({
"id":SideDialogData.id++,
"timest":Date.now()+60000*(MenuConst.menuid2time[g.menuId]?MenuConst.menuid2time[g.menuId]:1.5),
"type":"MENU",
"menuid":g.menuId,
"title":g.title,
"msg":g.message,
"options":k,
"menutype":k.length==3 && k[0]=="<--" && k[2]=="-->",
});
if(data.menutype){
	if(SideDialogData.menu.rmv)SideDialogData.menu.rmv();
	v2newDialog(data,SideDialogData.menu.x,SideDialogData.menu.y);
}else{
v2newDialog(data);
}
global.pt.logfi(JSON.stringify(data));
MenuMSGSave(g.message,g.title,g.menuId);
});

if(global._qt.InfoToastCall)
Vars.net.handleClient(InfoToastCallPacket,g=>{
var message = g.message;
if(message.includes("目前票数为")){
	Vars.ui.showInfoToast(message,2)
	try{
	var voteC={
		"votes":parseInt(message.split("[scarlet]").reverse()[0].split("[]")[0]),
		"name": message.split("[sky]")[1].split("[]")[0],
		"agree":message.split("[lime]").length>2,
	}
	}catch(error){var voteC={"votes":0,}}
	MenuConst.votes= voteC.votes;
	message=voteC.name+" "+(voteC.agree?"[lime]赞成 [#dfffdf]":"[scarlet]反对 [#ffdfdf]")+"还差[scarlet]"+voteC.votes+"[]票";
}
if(message.endsWith("低级单位")||message.endsWith("资源点")){
	Vars.ui.showInfoToast(g.message,2)
}else{
global.pt.logfi(message);
Vars.ui.chatfrag.addMessage("[#ffdfff][[Server]: [white]"+message);
}
});

if(global._qt.SendMessageCall)
Vars.net.handleClient(AnnounceCallPacket,g=>{
Vars.ui.chatfrag.addMessage("[#ffdfdf][[Server]: [white]"+g.text);
});

var MapMode={"[red]攻击":"a","[green]生存":"s","[scarlet]玩家对战":"p"};
var scan_maps=false;

function InfoMSGSave(msg){
	if(msg.startsWith("您的[sky]个人信息")){
		var starsky=JSON.parse(Vars.dataDirectory.child("qt/starsky").readString());
		starsky.pts =  msg.split("[#0099FF]积分[]为 [lime]")[1].split("[] 分")[0];
		starsky.pts_next= msg.split("到达下一等级还需[scarlet]")[1].split("[]分")[0];
		starsky.coins= msg.split("您的当前可用[#0099FF]星尘[]数量为 [gold]")[1].split("[]")[0];
		Vars.dataDirectory.child("qt/starsky").writeString(JSON.stringify(starsky, null, 2));
	}else if(msg.includes(", 欢迎来到[yellow]星[red]空[purple]之[blue]梦[][][][]!")){
		var starsky=JSON.parse(Vars.dataDirectory.child("qt/starsky").readString());
		starsky.lv=msg.split("([lime]")[1].split("[])")[0];
		if(msg.split("自动登录[]账号<").length>1)starsky.account=msg.split("自动登录[]账号<")[1].split(">")[0];
		Vars.dataDirectory.child("qt/starsky").writeString(JSON.stringify(starsky, null, 2));
	}else if(msg.startsWith("[#FF0033]游戏结束[]") || msg.startsWith("上局游戏已结束，您的奖励如下：")){
		global.pt.openCore();
	}else if(msg.includes("最短胜利时间") || msg.includes("地图尺寸")){
		starsky=JSON.parse(Vars.dataDirectory.child("qt/starsky").readString());
		starsky.map_time="";
		if(msg.includes("最短胜利时间"))
			starsky.map_time+=msg.split("最短胜利时间[]: [scarlet]")[1].split("[]分钟")[0]+"分 ";
		if(msg.includes("最高生存波次"))
			starsky.map_time+=msg.split("最高生存波次[]: [scarlet]")[1].split("[]波")[0]+"波 ";
		if(msg.includes("本地图坚持")||msg.includes("波则视为通关"))
			starsky.map_time+="|"+msg.split("本地图坚持[scarlet]")[1].split("波则视为通关")[0]+"波 ";
		starsky.map_reward=!msg.includes("本地图本周已领取过通关奖励或未经管理审核");
		if(msg.includes("没有通关奖励"))starsky.map_reward=false;
		Vars.dataDirectory.child("qt/starsky").writeString(JSON.stringify(starsky, null, 2));
	}
}

function MenuMSGSave(msg,title,id){
	if(id==5){
		var starsky=JSON.parse(Vars.dataDirectory.child("qt/starsky").readString());
		msg.split("\n").forEach(f=>{
			try{
			if (f.includes("标记的地图本周已经") && scan_maps){
				scan_maps=false;
			}else if(f.includes("游戏次数")&&f.includes("赞")){
			starsky.map_list[parseInt(f.split("[sky][")[1])]={
				"mode":MapMode[f.split("[#CCFF99]<")[1].split("[]>")[0]],
				"name":f.split(">[]")[1].split(" 游戏次数[green]")[0],
				"times":parseInt(f.split(" 游戏次数[green]")[1]),
				"id":parseInt(f.split("[sky][")[1]),
			}
			}
			}catch(error){}
		});
		Vars.dataDirectory.child("qt/starsky").writeString(JSON.stringify(starsky, null, 2));
	}
}

if(global._qt.InfoMessageCall)
Vars.net.handleClient(InfoMessageCallPacket,g=>{
var data= ({
"id":SideDialogData.id++,
"timest":Date.now()+60000*1.5,
"type":"MSG",
"msg":g.message
});
global.pt.logfi(JSON.stringify(data));
v2newDialog(data);

InfoMSGSave(g.message);
})

if(global._qt.InfoMessageCall)
Vars.net.handleClient(TraceInfoCallPacket,(k)=>{
	var player=k.player,info=k.info
	if(!info)return;
	var data2={
	"name":player.name,
	"uuid":info.uuid,
	"ip":info.ip,
	"modclient":info.modded,
	"mobile":info.mobile,
	"join":info.timesJoined,
	"kick":info.timesKicked,
	"time":new Date().toString(),
	};
	print(JSON.stringify(data2));
	Vars.dataDirectory.child('qt/ptall').writeString(",\n"+JSON.stringify(data2),true);
	
	if(global.pt.getValue("auto_kick")){
		//data2.ip.match(/[0-9]+\.[0-9]+\.[0-9]+/)[0]
	if(global.pt.getValue("blacklist_uuid").includes(data2.uuid) || global.pt.getValue("blacklist_ip").includes(data2.ip)){
	Call.sendChatMessage("/kick "+player.id);
	Timer.schedule(f=>{Call.sendChatMessage("/kick "+player.id);},1);
	Timer.schedule(f=>{Call.adminRequest(player,Packages.mindustry.net.Packets.AdminAction.kick)},1.5);
	Vars.dataDirectory.child("qt/adminlog.txt").writeString("\nPt-"+global.pt.modv+" ["+todayDate(true)+"] !!! Potential Black List !!! => "+data2.name,true);
	}
	}
	
	if(Object.keys(global.pt.getValue("VIPuser")).includes(data2.uuid)){
		var t = global.pt.getValue("VIPuser");
		t[data2.uuid].laston = Date.now();
		t[data2.uuid].lastname = data2.name;
		global.pt.storeValue(t,"VIPuser");
	}
	
	if(global.pt.chktraced(player.id)){
		var data=({
		"id":SideDialogData.id++,
		"timest":Date.now()+60000*1.5,
		"type":"Trace",
		"msg":	"Name: "+player.name+" \n"+
				"IP: "+info.ip+" \n"+
				"UUID: "+info.uuid+" \n"+
				"Modded: "+info.modded+" \n"+
				"Mobile: "+info.mobile+" \n"+
				"Joined: "+info.timesJoined+" \n"+
				"Kicked: "+info.timesKicked
		});
		v2newDialog(data);
	}else{
	global.pt.traced(player.id,{"uuid":data2.uuid,"ip":data2.ip});
	}
})

if(global._qt.SendMessageCall)
Vars.net.handleClient(SendMessageCallPacket2,(k)=>{
	handleOnChat(k.message);

	if(k.playersender != null && k.unformatted != null){
		k.playersender.lastText = k.unformatted;
		k.playersender.textFadeTime = 1;
	}
	ChatMSGSave(k.message);
})

function handleOnChat(msg){
	if(Vars.ui == null)return;
	if(msg.startsWith("警告：敌人潜入了")){Vars.ui.showInfoToast(msg,2);return;}
	Vars.ui.chatfrag.addMessage(msg);
}

var colors=["yellow","gold","goldenrod","orange","brown","tan","brick","red","scarlet","coral","salmon","slate","sky","cyan","teal","green","acid","lime","forest","olive","blue","navy","royal","clear","black","white","lightgray","gray","grey","darkgray","pink","magenta","purple","violet","maroon","stat",""];
function decodeColor(str){
    colors.forEach(e=>{
        str=str.replace(new RegExp("\\["+e+"\\]","g"),"");
	});
    str=str.replace(new RegExp("\\[#[0-9a-fA-F]{1,}\\]","g"),"");
	return str;
}

var tilesSeq=[];
var tiles_last = {"show":0,"cmd":0};

function ChatMSGSave(msg){
print(msg);
if(global.pt.getValue("record_msg"))
	Vars.dataDirectory.child("qt/logs/"+todayDate(false)+".txt").writeString("["+todayDate(true)+"] "+msg+"\n",true);
if(msg.startsWith("您本次对局内已被禁言") && Vars.player.admin && (global.pt.chkcmdlist()[global.pt.chkcmdlist().length-1]!=("/mute "+Vars.player.id))){
	global.pt.cmdlist("/mute "+Vars.player.id)
}else if(msg.includes("发起了进攻[], 请注意防守")&&msg.startsWith("[red]敌人从")){
	global.pt.openCore2();
}else if((msg.startsWith("[#CCFF99]投票通过了[]。")||msg.startsWith("[scarlet]投票结束[]，还需要")) && SideDialogData.vote.rmv){
	SideDialogData.vote.rmv();
}else if(Vars.player.admin && msg.includes('[sky]"[#FF0033]踢出玩家[]'+Vars.player.name)){
	var ppl = msg.split("[#CCFF99]开始[]对[sky]")[1].split("[]发起的")[0];
	Groups.player.each(q=>{if(q.name.includes(ppl)){
		Call.adminRequest(q,Packages.mindustry.net.Packets.AdminAction.kick);
		global.pt.adminlog(" 【自动反踢】 "+ppl+" --> "+q.name);
	}})
}else if(msg.startsWith("有玩家认为您在挂机，")||msg.includes("输入错误，请输入")||msg.includes("请勿骚扰其他玩家")){
	if(msg.split("/test ")[1])global.pt.cmdlist("/test "+msg.split("/test ")[1].substring(0,2));
}else if(msg.startsWith("已开启记录查询模式")){
	tilesSeq.forEach(w=>{Call.tileTap(Vars.player,w);});
	tilesSeq=[];
}
if(msg.match(/[\d\s]+[\s,，；\:\;\-]\d+/g)){
	var reg_exp_position = msg.match(/[\d\s]+[\s,，；\:\;\-]\d+/g).pop().split(/[ ,，；:;-]/g);
	if(reg_exp_position[0]=="")reg_exp_position.shift();
	var reg_exp_desc = "[scarlet]";
	Object.keys(marks_type).forEach(e=>{
		if(msg.includes(e))reg_exp_desc=marks_type[e];
	});
	if (parseInt(reg_exp_position[0]) && parseInt(reg_exp_position[1])){
	global.pt.active_marks(reg_exp_position);
	Vars.ui.showLabel(reg_exp_desc,30,8*reg_exp_position[0],8*reg_exp_position[1])
	}
}

var umsg = msg.split("]:[white] ")[1];
if(umsg){
var upname = decodeColor(msg.split("]:[white] ")[0].split("[coral][[")[1]);
var up = Groups.player.find(e=>e.plainName()==upname);
let pplinfo = (up?global.pt._ptPlayer[up.id]:null);
if (global.pt.getValue("auto_vote") && (umsg=="0"||umsg=="1") && (pplinfo? pplinfo.key&& !global.pt.getValue("ftp_blacklist").includes(pplinfo.key) :false) && (getVIP(up)>0)){
	Call.menuChoose(Vars.player, 1, parseInt(umsg)^1);
	if(SideDialogData.vote.rmv)SideDialogData.vote.rmv();
}

if(umsg.startsWith("[#fed8d7][[Pt=E v") && (umsg.split("[#fed8d7][[Pt=E v")[1].includes(Vars.player.coloredName())||umsg.split("[#fed8d7][[Pt=E v")[1].includes(Vars.player.plainName()))){
	Vars.ui.announce("[scarlet]@ [white]你有一则新的提及");
	if(global.pt.getValue("p1palert"))Notfication.play(0.5);
}
if(global.pt.getValue("record_msg")){
	if(global.pt.pkick1().includes(up)){
		Vars.dataDirectory.child("qt/adminlog.txt").writeString("\n["+todayDate(true)+"] @"+upname+" 踢原因： "+umsg,true);
		global.pt.pkick2(global.pt.pkick1().indexOf(up), 1);
	}
}

global.pt.cmd(upname,umsg,up);
}
}



function getVIP(p){
	if(Object.keys(global.pt.getValue("VIPuser")).length<0)return 1;
	try{return global.pt.getValue("VIPuser")[global.pt.chktraced(p.id).uuid].lv}catch(error){return 1;}
}

function v2parseXY(q,x,y){
	if(q.menutype){
		SideDialogData.menu.x=x;
		SideDialogData.menu.y=y;
	}else if(q.menuid==1){
		SideDialogData.vote.x=x;
		SideDialogData.vote.y=y;
	}
}

function v2newDialog(q,x2,y2){
	var t2 = new Table(Tex.whiteui.tint(0,0,2/16,0.35));
	var t4 = new Table(Tex.whiteui.tint(6/16,0,0,0.35));
	t4.labelWrap("#"+q.id+" "+(q.menuid?"[#dfdfff]"+MenuConst.menuid2name[q.menuid]+"  ":"")+(q.title?"[cyan]"+q.title:"")).width(340).fillY().left();
	let indexid = q.id;
	t4.button("",Styles.cleart,e=>{
		Core.app.setClipboardText(q.msg);Vars.ui.showInfoFade("已复制!");
	}).width(35).height(35).right();
	t4.button("X",Styles.cleart,e=>{
		if(q.menutype)Call.menuChoose(Vars.player,q.menuid,1);
		t2.remove();
	}).width(35).height(35).right();
	t2.add(t4);
	var lastX,lastY;
	t4.addListener(extend(InputListener,{
		touchDown(event,x,y,pointer,button){
			lastX=x;
			lastY=y;
			return true;
		},
		touchUp(event,x,y,pointer,button){
			t2.x+=x-lastX;
			t2.y+=y-lastY;
			v2parseXY(q,t2.x,t2.y);
		}
	}));
	
	t2.row();
	t2.pane(cons(k=>{
	k.labelWrap(q.msg).width(400).left();
	if(q.options){
		k.row();
		var t3=new Table(Tex.whiteui.tint(0,0,6/16,0.35));
		q.options.forEach((w,i)=>{
			t3.button(w,Styles.cleart,e=>{
				Call.menuChoose(Vars.player,q.menuid,i);
				if(q.menuid==1){t2.remove()}
			}).color(Color.teal).width(95).left();		
			if((i+1)%4==0)t3.row();
		});
		k.add(t3).left();
	}
	})).maxHeight(450);
	if(q.menutype){
		SideDialogData.menu={
		"id":q.id,
		rmv(){t2.remove()},
		"x":0,"y":0}
	}else if(q.menuid==1){
		SideDialogData.vote={
		"id":q.id,
		rmv(){t2.remove()},
		};
		t2.update(w=>{
			t2.setPosition(t2.x,t2.y);
		})
	}
	Core.scene.table().add(t2);
	if(x2&&y2){
		t2.visible=false;
		Timer.schedule(()=>{t2.setPosition(x2,y2);v2parseXY(q,x2,y2);t2.visible=true;},0.01)
	};
	Timer.schedule(()=>{t2.remove();},360)
}

global.pt0.SideBarDialog={
"scan_maps":function(){scan_maps=true},
}
