//{"name":"StealUnit","version":1,"date":20230127}

var ucid=-1;
const unit=[["","","","",""],["","","","",""],["","","","",""],["","","","",""],["","","","",""],["","","","",""],["","","","",""],["","",""],["","","","",""],["","","","","",""],["","","","","",""],["","",""],["","","","","",""],["移除"]];



function getUnit(){
if(ucid==-1||ucid>=64)return;
Groups.unit.each(w=>!w.player&&w.type.id==ucid,e=>{
if(ucid>=0){
Call.unitControl(Vars.player,e);
ucid=-1;
}
});
}

global.pt0.stealunit={
menu(){
Vars.ui.showMenu("抢单位 - 选择单位","",unit,f=>{ucid=f})
},
refresh(){
getUnit();
},
getID(){return ucid}
}