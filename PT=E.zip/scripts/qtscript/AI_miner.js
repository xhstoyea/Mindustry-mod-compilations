//{"name":"AI_miner","version":210,"date":20230127}

function safemine(unit,type,ore){
	if (!unit.canMine(ore))return false;
	if ((_qtglobal.minertype&type)!=type)return false;
	if (!Vars.indexer.hasOre(ore))return false;
	if (Vars.indexer.findClosestOre(unit.closestCore().x,unit.closestCore().y,ore)===null)return false;
	if (!chkwaypt(Vars.indexer.findClosestOre(unit.closestCore().x,unit.closestCore().y,ore).x,Vars.indexer.findClosestOre(unit.closestCore().x,unit.closestCore().y,ore).y))return false;
	return true;
}

function hasAmmo(build){
	
	if(build.block instanceof PowerTurret || build.block instanceof PointDefenseTurret || build.block instanceof TractorBeamTurret){
		return build.power.status>0;
	}
	if(build.block instanceof Turret){
		return build.hasAmmo();
	}
	return false;
}

function chkwaypt(x,y){
	var _0x113 = true;
	if (_qtglobal.escturret){
	var _0x110=["scorch","hail","wave","lancer","arc","segment","tsunami","ripple"];
	Groups.build.each(e=>{
	if(hasAmmo(e) && (e.team!=Vars.player.team()) && !_0x110.includes(String(e.block))){
	if(e.dst(x*8,y*8)/8<(parseInt(Vars.world.toTile(e.range()))+6)){_0x113=false;};
	}
	});
	}
return _0x113;
}

var v7_mine_items=[Items.beryllium,Items.graphite];
function safemine_v7(unit){
	print("lag");
	var items=v7_mine_items.map(x=>x);
	items.sort((a,b)=>{return (unit.team.items().get(a)<unit.team.items().get(b)?-1:1)});
	var active_ore=findore_v7(unit);
	for (var e in items){
		if(active_ore[v7_mine_items.indexOf(items[e])])return [active_ore[v7_mine_items.indexOf(items[e])],items[e]];
	}
}

function findore_v7(unit){
	var ore_list=[null,null];
	Vars.world.tiles.eachTile(t=>{
		if(!t.build)
		if(t.overlay()=="ore-wall-beryllium"){
			if(!ore_list[0])ore_list[0]=t;
			else if(ore_list[0].dst(unit.core())>t.dst(unit.core()))ore_list[0]=t;
		}else if(t.cblock()==Blocks.graphiticWall){
			if(!ore_list[1])ore_list[1]=t;
			else if(ore_list[1].dst(unit.core())>t.dst(unit.core()))ore_list[1]=t;
		};
	});
	return ore_list;
}

const v7_Estar_unit=[
UnitTypes.evoke,
UnitTypes.incite,
UnitTypes.emanate,
]



global.pt0.minerAI={
	data:
extend(AIController,{
	mining:true,
	targetItem:null,
	ore:null,
	v7_plan:null,
	v7_unit:false,
	unitS(u){
		if(this.unit == u) return;
        this.unit = u;
		this.v7_unit = v7_Estar_unit.includes(this.unit.type);
        this.init();
	},
	updateMovement(){
		try{
		let unit = this.unit;
		var core = unit.closestCore();
		if(!unit.canMine() || core == null) return;
        if(unit.mineTile != null && !unit.mineTile.within(unit, unit.type.range)){
            unit.mineTile=null;
        }		
		this.v7_unit = v7_Estar_unit.includes(this.unit.type);

        if(this.mining){
            if(this.timer.get(1, 240) || this.targetItem == null){
				if(this.v7_unit){
					
				var items=v7_mine_items.map(x=>x);
				items.sort((a,b)=>{return (unit.team.items().get(a)<unit.team.items().get(b)?-1:1)});
				if(items[0]!=this.targetItem && this.timer.get(2, 75)){
				this.v7_plan = safemine_v7(unit);
				if(this.v7_plan && this.v7_plan[0]){this.ore=this.v7_plan[0];this.targetItem=this.v7_plan[1]}
				else {
					//Call.unitClear(unit.player)
					var build = Vars.player.team().cores().toArray().filter(q=>q.block.unitType.mineTier<3).sort((a,b)=>{return (a.block.unitType.mineTier>b.block.unitType.mineTier?-1:1)})[0];
					if(build)Call.buildingControlSelect(Vars.player,build)
				};
				}
				
				}else{
					
				var item=[Items.sand, Items.coal, Items.scrap, Items.titanium, Items.copper, Items.lead, Items.beryllium];
				item = item.filter((e,i)=>safemine(unit, Math.pow(2,i), e));
				item.sort((a,b)=>{return (unit.team.items().get(a)<unit.team.items().get(b)?-1:1)});
				this.targetItem = item[0];
				}
            }


            if(unit.stack.amount >= unit.type.itemCapacity || (this.targetItem != null && !unit.acceptsItem(this.targetItem))){
                this.mining = false;
            }else{
                if(this.targetItem != null){
					if(this.v7_unit){
						if(!this.v7_plan){
						if(this.timer.get(1, 240))this.v7_plan = safemine_v7(unit);
						if(this.v7_plan && this.v7_plan[0])this.targetItem=this.v7_plan[1];
						}
						if(this.v7_plan && this.v7_plan[0])this.ore=this.v7_plan[0];
					}else{
                    this.ore = Vars.indexer.findClosestOre(core.x,core.y, this.targetItem);
					}
                }

                if(this.ore != null){
                    this.moveTo(this.ore, (this.v7_unit?unit.type.range*0.4:unit.type.range*0.25), 20);

                    if(unit.within(this.ore, unit.type.range*0.5)){
                        unit.mineTile = this.ore;
                    }

                    if(this.ore && (this.ore.block() != Blocks.air) && !this.v7_unit){
                        this.mining = false;
                    }
                }
            }
        }else{
            unit.mineTile = null;

            if(unit.stack.amount == 0){
                this.mining = true;
                this.return;
            }

            if(unit.within(core, unit.type.range-30)){
                if(core.acceptStack(unit.stack.item, unit.stack.amount, unit) >= unit.stack.amount){
					Call.transferInventory(unit.player,core);
                    //Call.transferItemTo(unit, unit.stack.item, unit.stack.amount, unit.x, unit.y, core);
			}else{
			Call.dropItem(0);
			}
            this.mining = true;
            }else{
            this.circle(core, unit.type.range / 1.8);
			}
        }
		}catch(error){debug(error)}
    }
	})
}