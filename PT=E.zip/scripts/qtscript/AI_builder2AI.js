//{"name":"AI_buidler2AI","version":210,"date":20230127}

function check_req(x){
for (var ix in x.requirements){
if(x.requirements[ix].amount>Vars.player.team().items().get(x.requirements[ix].item))return false;
}
return true;
}

global.pt0.builder2AI={
	data:
extend(AIController,{
	unitS(u){
		if(this.unit == u) return;
        this.unit = u;
        this.init();
	},
	updateMovement(){
		try{
		if(this.unit.plans.size>0)
			this.moveTo(this.unit.plans.first(),this.unit.type.range/2);
		if(this.unit.plans.size>1){
			var _0x249 = this.unit.plans.first();
			if(!Build().validPlace(_0x249.block,this.unit.team,_0x249.x,_0x249.y,_0x249.rotation)){
			this.unit.plans.removeFirst();
			}else if (!check_req(_0x249.block)){
			this.unit.plans.removeFirst();
			this.unit.plans.addLast(_0x249);
			}
		}
		}catch(error){debug(error)}
	}
})
}