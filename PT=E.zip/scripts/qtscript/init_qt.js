//{"name":"init_qt","version":1,"date":20230218}

//generate needed files
["qt/ptall",
"qt/starsky"
].forEach(e=>{var k=Vars.dataDirectory.child(e);if(!k.exists())k.writeString("{}")});

["qt/adminlog.txt"
].forEach(e=>{var k=Vars.dataDirectory.child(e);if(!k.exists())k.writeString("")});

//remove unwanted files
const rmv_file = ["gamedata","gamedata2","ptconfig","ptall","starsky","qt/changelog.txt"];
rmv_file.forEach(e=>{var k=Vars.dataDirectory.child(e);if(k.exists())k.delete()});

//remove Old Captures
if(Vars.dataDirectory.child("qt/schSave").exists())Vars.dataDirectory.child("qt/schSave").emptyDirectory()
	
//remove Old Internal_Crashlog
if(Vars.dataDirectory.child("qt/crash").exists())
Vars.dataDirectory.child("qt/crash").findAll().each(q=>{
	var DateS = q.name().substring(9,17);
	var DateValue = new Date(DateS.substring(0,4),DateS.substring(4,6),DateS.substring(6,8));
	if((Date.now() - DateValue.getTime())>45*24*60*60*1000){
	q.delete()
}})

//remove Old Crashlog
if(Vars.dataDirectory.child("crashes").exists())
Vars.dataDirectory.child("crashes").findAll().each(q=>{
	if(q.name().split("report-").length>1){
	var DateS = q.name().split("report-")[1].split("_");
	DateS.length=3;
	var DateValue = new Date(DateS[2],DateS[1]-1,DateS[0]);
	}else{
	var DateS = q.name().split("crash_")[1];
	var DateValue = new Date(parseInt(DateS));
	}
	if((Date.now() - DateValue.getTime())>45*24*60*60*1000){
	q.delete()
}})

function rnd(){var text="";for (var i=0;i<13;i++){var rnd2 = Math.floor(Math.random()*62);text+=String.fromCharCode(rnd2<10?rnd2+48:(rnd2<36?rnd2+55:rnd2+61))};return text;}

//qt_init
const _qt={
	"keycode":{
	"pan":			"num3",
	"mapdesc":		"num4",
	"powernodeFix":	"num5",
	"removeBullet":	"num7",
	"removeDecal":	"num8",
	"disableUnit":	"num9",
	
	"air_range":	"r",
	"ground_range":	"t",
	"unitrange":	"y",
	"ore_show":		"u",
	"boost_range":	"i",
	"fix_range":	"o",
		
	"brokenbuild":	"l",
	"foobuild":		"semicolon",
	
	"auto_rejoin":	"",
	"autotransfer": "k",
	"disableWorldProcessors": "j",
	"pvp_destruct":	"h",
	},
	"keycode_mobile":[],
"brokenbuildmax":50,
"pvp_destruct":false,
"escturret":true,
"trace_remove":false,
"air_range":false,
"msg_talk":false,
"ground_range":false,
"ore_show":false,
"boost_range":false,
"fix_range":false,
"player_in_out":true,
"core_tips":false,
"remove_blueprint":true,
"auto_vote":true,
"msg_remove_mute":true,
"health_bar":true,
"map_spec_build":true,
"popup_style":false,
"language":true,
"playercursor":0,
"command":true,
"auto_rejoin":false,
"popup_rss":false,
"switch_mode_limit":1500,
"delay_chat":true,
"chk_pm":false,
"\u540d\u79f0_\u661f\u7a7a":"[yellow]\u661f[red]\u7a7a[purple]\u4e4b[blue]\u68a6",
"wpy_config":["copper","lead","metaglass","graphite","titanium","thorium","silicon","plastanium","phaseFabric","surgeAlloy"],
"minertype":56,
"autotakedur":0.25,
"record_msg":false,
"VIPuser":[],
"p1p_data":"\u5e76\u4e14\u63d0\u9192\u4f60\u6ce8\u610f\u804a\u5929\u6846",
"hidden_func":false,
"quickassist":false,
"quickassist_cursor":false,
"skip_line":false,
"admin_cmd":false,
"moderator":false,
"admin_menu":false,
"cmd_count":0,
"new_playerFrag":true,
"mainmenu_menu":true,
"player_frag_seq":[2,4,8,16,512,1024,32,64,128,256,2048],
"removeDecal":false,
"removeBullet":false,
"disableUnit":false,
"health_bar_y":0,
"auto_kick":true,
"p1palert":true,
"blueprint_pd":true,
"blacklist_ip":[],
"blacklist_uuid":[],
"pm_encrypt":-1,
"dropzone":false,
"unitrange":false,
"RTShealth":50,
"RTScommand":false,
"shipRotateSpeed":true,
"otherTeamBuild":true,
"computer_readKeyCode":false,
"schCapture":false,
"panCam":true,
"title2":"",
"functime":{"research":0},
"atrans_fact":true,
"atrans_vault":true,
"vote_blacklist":[],

"ftp_blacklist":[],
"pass":rnd(),

"MenuCall":true,
"InfoToastCall":true,
"InfoMessageCall":true,
"SendMessageCall":true,
"autotest":true,
"schignore":true,
}

//chkdsk
try{
	JSON.parse(Vars.dataDirectory.child('qt/starsky').readString())
}catch(error){
	global.pt.debug(error);
}

//parse config files
function parse2(){
try{
if(!Vars.dataDirectory.child('qt/ptsettings').exists())
	Vars.dataDirectory.child('qt/ptsettings').writeString(JSON.stringify(_qt, null, 2));

var result = JSON.parse(Vars.dataDirectory.child('qt/ptsettings').readString());
Object.keys(_qt).forEach(e=>{if(result[e]===undefined){result[e]=_qt[e]}});


["switch_poly","autorejoin","socket_id","socket_pw","vote_runwave","_removeminetile","logic_msg","health_bar_x","health_bar_y","factorystatus","health_bar_a","VIPuserdesc","mobilekeybind2","fi_capture","stealunit","ai_auto_vote","remove_popup","InfoMessageCallPacket"].forEach(f=>delete result[f]);

return result;
}catch(error){global.pt.debug(error);}
}

global.pt.parseqt(parse2());