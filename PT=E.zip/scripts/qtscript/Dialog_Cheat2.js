//{"name":"Dialog_MapsSelector","version":210.02,"date":20230127}

function cheat2(){
if(!Vars.indexer.isBlockPresent(Blocks.worldMessage)){Vars.ui.chatfrag.addMessage("找不到作弊器");return;}
var ok=[];
Vars.indexer.eachBlock(Vars.player.team(),Rect(0,0,Vars.world.tiles.width*8-1,Vars.world.tiles.height*8-1),q=>q && q.block == Blocks.worldMessage && q.config().startsWith("PT作弊器"),w=>{
	var buildp = Vars.world.build(w.x/8+1,w.y/8);
	if(buildp && buildp.block == Blocks.worldProcessor && buildp.code.startsWith('print "PT作弊器"'))
	ok.push(Vars.world.build(w.x/8+2,w.y/8));
});

if(ok.length==0){Vars.ui.chatfrag.addMessage("找不到作弊器");return;}
var t2 = new Table(Tex.whiteui.tint(0,0,2/16,0.35));
var t4 = new Table(Tex.whiteui.tint(6/16,0,0,0.35));
var t3 = new Table(),xytable=new Table(),teamtable=new Table(),buildtable=new Table(),unittable=new Table();
var mode = 1,req=[];

var _modv=2;

t4.labelWrap("[red][Pt=E v"+_modv+"][white]  [yellow]PT 世处作弊器").fillX().minWidth(400).fillY().left();
t4.button("X",Styles.cleart,e=>{t2.remove();}).width(35).height(35).right();
t2.add(t4).row();

var lastX,lastY;
t4.addListener(extend(InputListener,{
	touchDown(event,x,y,pointer,button){
		lastX=x;lastY=y;return true;
	},
	touchUp(event,x,y,pointer,button){
		t2.x+=x-lastX;t2.y+=y-lastY;
	}
}));
	
t3.button("生成建筑",Styles.cleart,q=>{mode=1;req[0]=18}).width(150).height(30);
t3.button("生成单位",Styles.cleart,q=>{mode=2;req[0]=22}).width(150).height(30);

xytable.add("X坐标: ");
xytable.field(0,e=>{req[1]=parseInt(e)}).left().width(100).row();
xytable.add("Y坐标: ");
xytable.field(0,e=>{req[2]=parseInt(e)}).left().width(100).row();
xytable.visibility = boolp(w=>mode==1);

teamtable.add("队伍: ");
teamtable.field(0,e=>{req[3]=parseInt(e)}).left().width(100).row();
teamtable.visibility = boolp(w=>mode==1);

buildtable.add("建筑: ");
buildtable.field(0,e=>{req[4]=e}).left().width(100).row();
buildtable.visibility = boolp(w=>mode==1);
unittable.add("单位: ");
unittable.field(0,e=>{req[4]=e}).left().width(100).row();
unittable.visibility = boolp(w=>mode==2);

t2.add(t3).row();
t2.image().color(Color(14/16,14/16,1)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(400).row();
t2.add(xytable).row();
t2.add(teamtable).row();
t2.button("确认",Styles.cleart,q=>{
	var xcode = "";
	req.forEach((w,i)=>{xcode+="write "+w+" cell1 "+i+"\n"});
	ok[0].code=xcode;
	ok[0].links = new Seq([LogicBlock.LogicLink(ok[0].x/8+1,ok[0].y/8,"cell1",true)]);
	print(ok[0]);
	}).fillX().height(30);
Core.scene.table().add(t2);
}

global.pt0.map_popup = function(){map_popup()};
