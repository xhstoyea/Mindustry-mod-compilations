//{"name":"AI_followbuildAI","version":210,"date":20230127}

function checksamePos(e){
	try{
	Vars.player.unit().plans.each(f=>{
		if(f.samePos(e))throw 144;
	});
	}catch(error){
		return false;
	}
	return true;
}

global.pt0.followbuildAI={
	playertarget:null,
	data:
extend(AIController,{
	unitS(u){
		if(this.unit == u) return;
        this.unit = u;
        this.init();
	},
	updateMovement(){
		try{
	if(this.playertarget.tileOn()){
		this.moveTo(this.playertarget.tileOn(), 32);  
	}
	
	if (this.playertarget.unit().plans.size!=0 && this.playertarget!=Vars.player && Vars.player.team()==this.playertarget.team()){		
		for (let i=0;i<this.playertarget.unit().plans.size;i++){
		if(checksamePos(this.playertarget.unit().plans.get(i))){
			Vars.player.unit().plans.addFirst(this.playertarget.unit().plans.get(i));
		}
		if (this.playertarget.unit().plans.get(i).breaking!=Vars.player.unit().plans.get(0).breaking && this.playertarget.unit().plans.get(i).samePos(Vars.player.unit().plans.get(0)))
		{Vars.player.unit().plans.removeFirst()}
	}}

		}catch(error){debug(error)}
	}
})
}