//{"name":"Dialog_pm","version":210.02,"date":20230404}

var msg_record={"all":[],};
var lastsec = 0;

Events.on(EventType.ConfigEvent, cons(e=>{
if(e.player&&e.tile.block instanceof CoreBlock){
try{
	if(!e.value)return;
var data = e.value.substring(e.value.indexOf("=")+1);
switch(e.value.split("=")[0]){
	case "pt_pm":
	if (data.split("=")[0]==Vars.player.id || data.split("=")[0]=="all" || e.player==Vars.player){ 
		var text2=data.substring(data.indexOf("=")+1);
		if(text2[0]=="Δ")text2="Δ"+global.pt0.qt_encrypt.encrypt(global.pt.getValue("pm_encrypt"),text2.substring(1,text2.length),true);

		if(e.player && !msg_record[e.player.id])msg_record[e.player.id]=[];
		if (e.player != Vars.player){
		if(data.split("=")[0]=="all"){
			msg_record["all"].push([Date.now(),e.player.name,e.player.name+"[yellow]: [white]"+text2,0]);
		}else{
			msg_record[e.player.id].push([Date.now(),e.player.name,text2,0]);
		}
		}
		if(pm_target)genpane(msg_record[pm_target.id]);
		Vars.ui.chatfrag.addMessage("[green]< PM []"+(data.split("=")[0]=="all"?"[white]To ALL[]":"")+"[["+e.player.name+"[white]]: "+text2);
		global.pt.logfi("[green]< PM []"+(data.split("=")[0]=="all"?"[white]To ALL[]":"")+"[["+e.player.name+"[green]]:[white] "+text2);
	}
	break;
	case "pt_v":
	global.pt._ptPlayer[e.player.id] = JSON.parse(data);
	if(Date.now() - lastsec > 30000){
		lastsec=Date.now();
		print("finding. . .")
		ConfigCooldown("pt_v="+JSON.stringify(global.pt.vconfig));
	}
	break;
	case "pt_req":
	
	if(data.split("=")[0]==Vars.player.id || data.split("=")[0]=="all")req_recieve(data.substring(data.indexOf("=")+1),e.player.id);
	break;
	case "pt_data":
	var multipart = JSON.parse(data);
	if(multipart.p == Vars.player.id || multipart.p == "all")data_recieve(multipart,e.player.id,data.length);
	break;
}

}catch(error){print(error)}
}}
));

function ConfigCooldown(data,tryagain){
	if(!global.pt.chk)return;
	global.pt.configTimes--;
	if(global.pt.configTimes<0){
		if(tryagain) Timer.schedule(()=>{ConfigCooldown(data,true)},1);
		else Vars.ui.announce("[#ffdfdf]文件传输功能 冷却中. . . [#dfffdf]请稍后再尝试 ：）",1);
	}else{
		Call.tileConfig(Vars.player,Vars.player.core(),data);
	}
}

var chatpane = null;
var pm_target= null;
var chatpaneframe = null;
function main(){
var t2 = new Table(Tex.whiteui.tint(0,0,2/16,0.4));
var t4 = new Table(Tex.whiteui.tint(6/16,0,0,0.35));
var t3 = new Table();
var mode = 1,req=[];

t4.labelWrap("[red][Pt=E v"+global.pt.modv+"][white]  [#dfffdf]pt私聊: 游戏内安全聊天").fillX().minWidth(600).fillY().left();
t4.button("X",Styles.cleart,e=>{t2.remove();pm_target=null}).width(35).height(35).right();
t2.add(t4).row();

var lastX,lastY;
t4.addListener(extend(InputListener,{
	touchDown(event,x,y,pointer,button){
		lastX=x;lastY=y;return true;
	},
	touchUp(event,x,y,pointer,button){
		t2.x+=x-lastX;t2.y+=y-lastY;
	}
}));
	
t3.pane(cons(k=>{
	k.button("全员频道",Styles.cleart,e=>{
		pm_target={"name":"全员频道","id":"all"};genpane(msg_record["all"]);ppldata.visible=false;ppldata.clear();
		}).left().width(170).height(35).padBottom(10).row();
	Groups.player.each(q=>{
		if(global.pt._ptPlayer[q.id])
		k.button(q.name,Styles.cleart,e=>{
			pm_target=q;genpane(msg_record[q.id]);ppldata.visible=false;ppldata.clear();
			}).left().width(170).height(35).padBottom(10).row();
	})
})).top().width(170);
	
t3.image().color(Color(14/16,14/16,1)).fillY().height(3).pad(6).colspan(4).padTop(0).padBottom(10).height(200);

var chatdata = new Table();
t3.add(chatdata);
var chattitle = new Table();
chattitle.add("<[sky]程序员[]> 144_").update(f=>f.text="聊天对象: [#ffffdf]"+(pm_target?(global.pt._ptPlayer[pm_target.id]?global.pt._ptPlayer[pm_target.id].title:"")+"[white] "+pm_target.name:pm_target)).padRight(45);
var ppldata = new Table(Tex.whiteui.tint(0,6/16,0,0.35));
ppldata.visible=false;
chattitle.button("i",Styles.cleart,e=>{
	ppldata.clear();
	let pplinfo = global.pt._ptPlayer[pm_target.id];
	if(!pplinfo)return;
	ppldata.add("头衔: ");
	ppldata.add(""+pplinfo.title).row();
	ppldata.add("Mod 版本: ");
	ppldata.add(""+pplinfo.modv+(pplinfo.cnarc?" [gray]("+pplinfo.cnarc+"[gray])":"")).row();
	ppldata.add("pt-key: ");
	ppldata.add(""+pplinfo.key).row();
		ppldata.button((pplinfo.key&&global.pt.getValue("ftp_blacklist").includes(pplinfo.key)?" [gray]解除封锁":" [gray]封锁"),Styles.cleart,e=>{
			var id = global.pt.getValue("ftp_blacklist");
			if(id.includes(pplinfo.key))id.splice(id.indexOf(pplinfo.key),1);
			else id.push(pplinfo.key);
			global.pt.storeValue(id,"ftp_blacklist");
		}).width(170).padBottom(10);
		//ppldata.button(" [#ffffdf]白名单",Styles.cleart,e=>{}).width(170).padBottom(10);
	ppldata.visible=!ppldata.visible;
}).left().width(35).height(35).row();
chatdata.add(chattitle).row();
chatdata.add(ppldata).row();
chatpane = new Table();
chatpaneframe = new ScrollPane(chatpane, Styles.smallPane);
chatdata.add(chatpaneframe).row();

pm_target=Vars.player;
genpane(msg_record[pm_target.id]);
var chatarea = TextArea("");
var chatarea2 = new Table(Tex.whiteui.tint(0,0,2/16,0.5));
var chatarea3 = new Table();
chatarea3.add(chatarea).height(150).width(400);
chatarea3.button(">",Styles.cleart,e=>{
	if(!msg_record[pm_target.id])msg_record[pm_target.id]=[];
	msg_record[pm_target.id].push([Date.now(),Vars.player.name,chatarea.text.substring(0,330),1]);
	if(pm_target)genpane(msg_record[pm_target.id]);
	
	var text3 = chatarea.text.substring(0,330);
	if(global.pt.getValue("pm_encrypt")>=0)text3="Δ"+global.pt0.qt_encrypt.encrypt(global.pt.getValue("pm_encrypt"),text3,false);
	
	ConfigCooldown("pt_pm="+pm_target.id+"="+text3);
	chatarea.text=""
	}).width(40).fillY();
var chatarea4 = new Table();
var chatarea5 = new Table();
chatarea4.button("",Styles.cleart,e=>{chatarea5.visible = !chatarea5.visible}).width(40);

chatarea5.button("[green]mod清单",Styles.cleart,f=>{ConfigCooldown("pt_req="+pm_target.id+"=modl")}).width(100);
chatarea5.button("[sky]蓝图清单",Styles.cleart,f=>{ConfigCooldown("pt_req="+pm_target.id+"=schl")}).width(100);
chatarea5.button("[#ffffbb]crash_log",Styles.cleart,f=>{ConfigCooldown("pt_req="+pm_target.id+"=crashl")}).width(100);
chatarea5.button("[royal]地蓝",Styles.cleart,f=>{ConfigCooldown("pt_req="+pm_target.id+"=mapschl")}).width(100);

chatarea5.visible=true;
chatarea4.add(chatarea5);
	
chatarea2.add(chatarea3).row();
chatarea2.add(chatarea4).row();
chatdata.add(chatarea2).top().height(170).width(450);

t2.add(t3);

Core.scene.table().add(t2);
}

function genpane(str){
	chatpane.clear();
	chatpane.add("[#ffffdf]== 你已经到达了世界的尽头 ==").row();
	chatpane.add("").width(450).row();
	for (var i in str){
		let w = chatpane.add((str[i][3]?"[#ddffdd]":"[#ffddff]")+(new Date(str[i][0]).toLocaleString())+"\n"+str[i][2]);
		if (str[i][3])w.right().padBottom(10).row();
		else w.left().padBottom(10).row();
	}
	Timer.schedule(()=>{chatpaneframe.setScrollPercentY(100)},0.1);
}

const colors=["yellow","gold","goldenrod","orange","brown","tan","brick","red","scarlet","coral","salmon","slate","sky","cyan","teal","green","acid","lime","forest","olive","blue","navy","royal","clear","black","white","lightgray","gray","grey","darkgray","pink","magenta","purple","violet","maroon","stat",""];
function decodeColor(str){
	str=JSON.stringify(str);
    colors.forEach(e=>{
        str=str.replace(new RegExp("\\["+e+"\\]","g"),"");
	});
    str=str.replace(new RegExp("\\[#[0-9a-fA-F]{1,}\\]","g"),"");
	return JSON.parse(str);
}

const PacketSizeLimit = 8000;
function textsplit(str,id,class2,decodeColor2){
	if(global.pt.configTimes<0)return;
	var multipart = {"p":id,"c":class2,"d":str,"n":1,"pc":1}
	//p: Player(target)		c:Class		d:Data		n:Packet Number		pc:Packet Count
	if(JSON.stringify(multipart).length< PacketSizeLimit)return ConfigCooldown("pt_data="+JSON.stringify(multipart),true);
	
	if(decodeColor2){
		multipart.d = decodeColor(multipart.d);
		if(JSON.stringify(multipart).length< PacketSizeLimit)return ConfigCooldown("pt_data="+JSON.stringify(multipart),true);
	}
	var list=[],str=JSON.stringify(multipart.d);
	while(str.length>0){
		list.push(str.substring(0,PacketSizeLimit-50));
		str=str.substring(PacketSizeLimit-50);
	};
	list.forEach((w,index)=>{
		print("Packet "+index+" "+w.length);
		let id2 = index;
		Timer.schedule(()=>{
			ConfigCooldown("pt_data="+JSON.stringify({"p":id,"c":class2,"d":w,"n":id2+1,"pc":list.length}),true);
			Vars.ui.announce("信息发送中. . . (#"+(id2+1)+"/"+list.length+")");
		},id2*0.3);
	})
}

function todayDate(e){
	var d = new Date();
	var k = d.getFullYear()+"-"+(d.getMonth()+1).toString().padStart(2,"0")+"-"+(d.getDate()).toString().padStart(2,"0");
	if(e)k+=" "+d.getHours().toString().padStart(2,"0")+":"+d.getMinutes().toString().padStart(2,"0")+":"+d.getSeconds().toString().padStart(2,"0");
	return k;
}

function req_recieve(f,pid){
	//发送
	//Vars.dataDirectory.child("qt/adminlog.txt").writeString("\n["+todayDate(true)+"] 发送信息： "+f,true);
	if(!msg_record[pid])msg_record[pid]=[];
	if(global.pt.getValue("ftp_blacklist").includes(global.pt._ptPlayer[pid].key)){
		print("黑名單配對! pid="+pid);
		msg_record[pid].push([Date.now(),"Server","黑名单: 尝试配对",1]);
		return;
	}
	msg_record[pid].push([Date.now(),"Server","配对： "+f,1]);
	switch(f.split("=")[0]){ 
		case "modl":
		var mods_enabled=[];
		Vars.mods.eachEnabled(e=>{mods_enabled.push({"author":e.meta.author,"dname":e.meta.displayName,"desc":e.meta.description,"min":e.meta.minMajor,"v":e.meta.version,"j":e.meta.java,"name":e.meta.name})});
		textsplit(mods_enabled,pid,"modl",true);
		break;
		case "schl":
		var result=[];
		Vars.schematics.all().each(e=>{
		f=[e.name()];
		if(e.labels)f.push(e.labels.toString());
		result.push(f);
		})
		textsplit(result,pid,"schl",true);
		break;
		case "crashl":
		textsplit(
		Vars.dataDirectory.child("qt/crash").findAll().toArray().map(q=>q.toString().split("qt/crash/")[1]).concat(
		Vars.dataDirectory.child("crashes").findAll().toArray().map(q=>q.toString().split("crashes/")[1]))
		,pid,"crashl");
		break;
		case "mapschl":
		textsplit(
		Vars.dataDirectory.child("qt/mapsch").findAll().toArray().map(q=>q.name()),pid,"mapschl");
		break;
		
		case "fi":
		textsplit(Vars.dataDirectory.child((f.split("=")[1].startsWith("crashlog")?"qt/crash/":"crashes/")+f.split("=")[1]).readString(),pid,"fi");
		break;
		case "sch":
		textsplit(Vars.schematics.writeBase64(Vars.schematics.all().find(g=>g.name()==f.split("=")[1])),pid,"sch");
		break;
		case "schinfo":
		textsplit(global.pt0.scheme_parse.getReq(Vars.schematics.all().find(g=>g.name()==f.split("=")[1])),pid,"schinfo",true);
		break;

		case "mapsch":
		textsplit(Vars.dataDirectory.child("qt/mapsch/"+f.split("=")[1].replace(".ptsch",".ptsch")).readString(),pid,"mapsch",true);
		break;
	}
}

var DataReciever={};
var lastName=["",false,[]];
function data_recieve(f,pid,origlength){
	print("Data Recieved! @"+pid+" Length: "+origlength);
if(f.pc!=f.n){
	if(!DataReciever[pid])DataReciever[pid]={"nc":1,"d":[]};
	DataReciever[pid].d[f.n]=f.d;
	DataReciever[pid].nc++;
	return;
}else if(DataReciever[pid] && f.pc!=1 && DataReciever[pid].nc==f.pc){
	try{
	DataReciever[pid].d[f.n]=f.d;
	f.d=JSON.parse("["+DataReciever[pid].d.join("")+"]")[0];
	}catch(error){print("Your File Is CORRUPTED E_Multipart_001"); 
	Vars.ui.chatfrag.addMessage("[#ffdfdf]无法传输文档（文档损坏） 详情: E_Multipart_001")}
}
delete DataReciever[pid];
try{
	switch(f.c){
		case "modl":
		var modlist = "";
		f.d.forEach(e=>{
			modlist+="名称: "+e.name+"\n[gray]显示名称: "+e.dname+"\n[white]描述: "+e.desc+"\n[gray]作者: "+e.author+"  [gray]版本: "+e.v+"\n\n[acid]===\n[white]"
		});
		popup_string(modlist);
		break;
		case "schinfo":
		popup_string(global.pt0.scheme_parse.parseReq(f.d));
		break;

		case "fi":
		popup_string(f.d);
		Core.app.setClipboardText(f.d);	
		Vars.ui.announce("已复制");
		break;
		case "schl":
		popup_listchoose(f.d,3,pid);
		break;
		case "crashl":
		popup_listchoose(f.d,1,pid);
		break;
		case "mapschl":
		try{f.d = f.d.filter(w=>w.includes("_id1_")).map(w=>"[#bbffbb][C] "+w.split("_id1_")[1]).concat(f.d)}catch(error){}
		popup_listchoose(f.d,2,pid);
		break;
		
		case "sch":
		var scheme= Schematics.readBase64(f.d);
		scheme.tags.put("description","Pt=E蓝图"+(Groups.player.find(w=>w.id==pid)?"From: "+Groups.player.find(w=>w.id==pid).name+"\n":"")+
		(scheme.tags.get("labels").toString()=="[]"?"":"\n原label: "+scheme.tags.get("labels").toString())+
		(scheme.tags.get("description").toString()?"\n原desc:\n"+scheme.tags.get("description").toString():""));
		scheme.labels=new Seq(["下载"]);
		Vars.schematics.add(scheme);
		Vars.ui.announce("已储存! "+f.c);
		break;
		case "mapsch":
		Vars.dataDirectory.child("qt/mapsch/"+lastName[0]).writeString(f.d);
		if(lastName[1] && lastName[2].length>0 && Vars.net.client()){
			lastName[0] = lastName[2].pop();
			ConfigCooldown("pt_req="+pid+"=mapsch="+lastName[0]);
			Vars.ui.announce("获取 "+lastName[0]+" 中\n要停止请离开服务器",1);
		}else{lastName=["",false,[]]}
		break;

	}
}catch(error){print(error)}
}

function popup_string(msg){
	var table = new Table(Tex.button);
	table.pane(cons(k=>{k.add(msg);}));
	table.row();
	var t2 = new Table();
	t2.field(msg,e=>{}).width(200);
	t2.button("[scarlet]X",e=>table.remove());
	table.add(t2);
	table.dragged((x,y)=>{
	table.moveBy(x,y);
	});
	Core.scene.table().add(table);
}
function popup_listchoose(data2,mode,pid){
	//DRAG
	var index=0;
	var table = new Table(Tex.button);
	
	var search = new Table();
	var searcher = "";
	search.field("",e=>{searcher=e}).left().width(250);
	search.button("搜寻",e=>{comm_parse_scheme(pan,label,mode,0,data2,pid,searcher);}).width(50);
	table.add(search).row();
	var pan = null;
	table.pane(cons(k=>{pan = k})).row();
	var t2=new Table();
	t2.button("[scarlet]X",e=>table.remove());
	var label = t2.add(index.toString()+" / ").width(100); //+data2.length
	t2.button("[sky]上一页",e=>{index-=50;if(index<0)index=0;comm_parse_scheme(pan,label,mode,index,data2,pid);}).width(100);
	t2.button("[sky]下一页",e=>{index+=50;comm_parse_scheme(pan,label,mode,index,data2,pid);}).width(100);
	comm_parse_scheme(pan,label,mode,index,data2,pid);
	table.add(t2);
	table.dragged((x,y)=>{table.moveBy(x,y);});
	Core.scene.table().add(table);
}

function comm_parse_scheme(p,l,mode,index,data2,pid,searcher){
	p.clear();if(data2.length==0)return;
	if(searcher){
		data2.map((w,i2)=>[w,i2]).filter(q=>JSON.stringify(q[0]).includes(searcher)).forEach(i=>{
			let rq = i[0];
			if(mode==1){
				p.add("[white]#"+i[1]+" \x03"+rq).left();
				p.button("获取",f=>{ConfigCooldown("pt_req="+pid+"=fi="+rq)}).width(100);
			}else if(mode==2){
				p.add("[white]#"+i[1]+" \x03"+rq).left();
				p.button("[#ddffdd]获取",f=>{
					if(rq.startsWith("[#bbffbb][C]")){
						lastName=[data2.filter(w=>w.includes(rq.split("[#bbffbb][C] ")[1]) && w.includes("_id1_"))[0],true,data2.filter(w=>w.includes(rq.split("[#bbffbb][C] ")[1]) && !w.includes("_id1_"))];
					}else{lastName=[rq,false]}
					ConfigCooldown("pt_req="+pid+"=mapsch="+lastName[0]);
				}).width(100);
			}else if(mode==3){
				p.add("[white]#"+i[1]+" \x03"+rq[0]+"\x03  "+(rq[1]?rq[1]:"")).left();
				p.button("[#ddffdd]获取",f=>{ConfigCooldown("pt_req="+pid+"=sch="+rq[0])}).width(100);
				p.button("[#ffffdd]详细",f=>{ConfigCooldown("pt_req="+pid+"=schinfo="+rq[0])}).width(100);
			}
			p.row();
		})
	l.table.children.get(1).setText("搜寻列表");
	}else{
	for (var i=index;i<index+50;i++){
		if(data2[i]){
			let rq = data2[i];
			if(mode==1){
				p.add("[white]#"+i+" \x03"+rq).left();
				p.button("获取",f=>{ConfigCooldown("pt_req="+pid+"=fi="+rq)}).width(100);
			}else if(mode==2){
				p.add("[white]#"+i+" \x03"+rq).left();
				p.button("[#ddffdd]获取",f=>{
					if(rq.startsWith("[#bbffbb][C]")){
						lastName=[data2.filter(w=>w.includes(rq.split("[#bbffbb][C] ")[1]) && w.includes("_id1_"))[0],true,data2.filter(w=>w.includes(rq.split("[#bbffbb][C] ")[1]))];
					}else{lastName=[rq,false]}
					ConfigCooldown("pt_req="+pid+"=mapsch="+lastName[0])
				}).width(100);
			}else if(mode==3){
				p.add("[white]#"+i+" \x03"+rq[0]+"\x03  "+(rq[1]?rq[1]:"")).left();
				p.button("[#ddffdd]获取",f=>{ConfigCooldown("pt_req="+pid+"=sch="+rq[0])}).width(100);
				p.button("[#ffffdd]详细",f=>{ConfigCooldown("pt_req="+pid+"=schinfo="+rq[0])}).width(100);
			};
			p.row();
		}
	};
	l.table.children.get(1).setText(index.toString()+" / "+data2.length);
	}
}

global.pt0.pm_dialog={
main(){
return main()
},
decodeColor(str){
    colors.forEach(e=>{str=str.replace(new RegExp("\\["+e+"\\]","g"),"");});
    str=str.replace(new RegExp("\\[#[0-9a-fA-F]{1,}\\]","g"),"");
	return str;
}
}
