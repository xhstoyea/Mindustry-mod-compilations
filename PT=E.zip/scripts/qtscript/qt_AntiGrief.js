//{"name":"qt_AntiGrief","version":210.1,"date":20230127}
//v210.1 修复chatfrag相关bug
function newSchCapture(){
	try{
var result=[];
rmv30minPlans();
Vars.player.team().data().buildings.each(q=>{if(q.block)result.push([q.block.id,q.tileX(),q.tileY(),storeConfig(q.config(),q.block,q.tileX(),q.tileY()),q.rotation<4?q.rotation:0])});
Vars.dataDirectory.child("qt/schSave/"+Date.now()+".schPt").writeString(JSON.stringify(result));
	}catch(error){if(Vars.ui && Vars.ui.chatfrag)Vars.ui.chatfrag.addMessage(error)}
}
//Tiles To Schematics Capture
function parseConfig(value){
	if(value === null)return null;
	var result=null;
	switch(value[0]){
		case "l": result = Vars.content.liquid(parseInt(value.substring(1)));
		break;
		case "b": result = Vars.content.block(parseInt(value.substring(1)));
		break;
		case "i": result = Vars.content.item(parseInt(value.substring(1)));
		break;
		case "u": result = Vars.content.unit(parseInt(value.substring(1)));
		break;
		case "s": 
		try{result = Vars.schematics.readBase64(value.substring(1)).tiles.get(0).config}catch(error){print(error);print(Vars.schematics.readBase64(value.substring(1)).tiles)};
		break;
		case "p": 
		var p2 = JSON.parse(value.substring(1));
		result=Point2(p2[0],p2[1]);
		break;
	}
	return result;
}

function storeConfig(config, block, x, y){
	if(config === null)return null;
	if(config instanceof Liquid)return "l"+config.id;
	if(config instanceof Block)return "b"+config.id;
	if(config instanceof UnitType)return "u"+config.id;
	if(config instanceof Item)return "i"+config.id;
	if(config instanceof Point2) return "p"+JSON.stringify([config.x,config.y]);
	if(block instanceof LogicBlock) return "s"+Vars.schematics.writeBase64(Vars.schematics.create(x,y,x,y));
}


//Schematics Capture To BuildPlan


//NEW FUNC BELOW !!!

function newSchBuildPlan(k){
if(!k.exists())return;
k=JSON.parse(k.readString());
var x=k.map(t => new BuildPlan(t[1], t[2] , t[4], Vars.content.block(t[0]), parseConfig(t[3])));
x.forEach(s => (!Vars.world.build(s.x,s.y) && !s.block.isVisible() && !(s.block instanceof CoreBlock)) || !s.block.unlockedNow());
x.sort((a,b)=>{return (a.block.schematicPriority>a.block.schematicPriority?-1:1)});
x.forEach(q=>Vars.player.unit().plans.add(q));
}

function sch2Plan(k){
if(!k.exists())return;
var sch2 = global.pt0.AutoBluePrint.read(k.readString());
global.pt0.AutoBluePrint.toPlans(sch2,0,0,0,0,true);
}

function newSchCapture2(x, y, x2, y2){

	var x=0,y=0,x2=Vars.world.width(),y2=Vars.world.height();
	rmv30minPlans();
	var tiles = new Seq();
	var width = x2 - x + 1, height = y2 - y + 1;
	var offsetX = -x, offsetY = -y;
	var counted = new IntSet();
	for(var cx = x; cx <= x2; cx++){
		for(var cy = y; cy <= y2; cy++){
			var tile = Vars.world.build(cx, cy);
			if(!tile) continue;
			var realBlock = tile instanceof ConstructBlock.ConstructBuild ? tile.current : tile.block;
			if(!realBlock) continue;
			if(Vars.player.team()!=tile.team)continue;
			if(!counted.contains(tile.pos()) && (realBlock.isVisible() || realBlock instanceof CoreBlock)){
				var config = (tile instanceof ConstructBlock.ConstructBuild? tile.lastConfig : tile.config());
				tiles.add(new Schematic.Stile(realBlock, tile.tileX() + offsetX, tile.tileY() + offsetY, config, Math.floor(tile.rotation)%4));
				counted.add(tile.pos());
			}
		}
	}
	var properties = {
	"offsetX":Math.ceil((x+x2)/2),
	"offsetY":Math.ceil((y+y2)/2),
	"x":x,"y":y,
	"x2":x2,"y2":y2,
	};
	var sch=new Schematic(tiles, new StringMap(), width, height);
	sch.labels=new Seq(["ptSCH"]);
	sch.tags.put("description",JSON.stringify(properties));
	sch.tags.put("name",Date.now()+".schPt");
	//Vars.schematics.add(sch);
	Vars.dataDirectory.child("qt/schSave/"+Date.now()+".schPt").writeString(Vars.schematics.writeBase64(sch));
	return sch;
};



function rmv30minPlans(){
if(!Vars.dataDirectory.child("qt/schSave").exists())return "Does Not Exists";
Vars.dataDirectory.child("qt/schSave").findAll().each(q=>{if((Date.now() - new Date(parseInt(q.name().split(".")[0])).getTime())>30*60*1000){
	q.delete()
}})
}

function GetColor(v,max){return Math.floor(v/max*255).toString(16)+Math.floor((max-v)/max*255).toString(16)}

function menu(){
	if(!Vars.dataDirectory.child("qt/schSave").exists())return "Does Not Exists";
	var core = new Table(Tex.button);
	core.add("\u8bf7\u9009\u62e9\u5feb\u7167").width(300);
	//请选择快照
	core.row();
	core.button("\u8bb0\u5f55\u5feb\u7167",q=>{
		if(global.pt0.AutoBluePrint && global.pt0.AutoBluePrint.read){newSchCapture2()}else{newSchCapture()}
	}).width(150);
	//save
	core.row();
	core.pane(q=>{
		var AllFi=Vars.dataDirectory.child("qt/schSave").findAll();
		var count=0;
		AllFi.reverse().each(w=>{
			let Sch = w;
			let date2 = new Date(parseInt(w.name().split(".")[0]));
			q.button("[#"+GetColor(count,AllFi.size)+"00]"+"h\u65f6 : m\u5206 : s\u79d2".replace("h",date2.getHours().toString().padStart(2,"0")).replace("m",date2.getMinutes().toString().padStart(2,"0")).replace("s",date2.getSeconds().toString().padStart(2,"0")),e=>{
				if(global.pt0.AutoBluePrint && global.pt0.AutoBluePrint.read){sch2Plan(Sch)}else{newSchBuildPlan(Sch)}
			}).width(300);
			q.row();count++;
		})
	});
	core.row();
	core.button("X",q=>{core.remove()});
	Core.scene.table().add(core);
}

global.pt0.qt_AntiGrief={
"newSchCapture":function(){
	if(global.pt0.AutoBluePrint && global.pt0.AutoBluePrint.read){newSchCapture2()}else{newSchCapture()}
},
"newSchBuildPlan":newSchBuildPlan,
"menu":menu,
}