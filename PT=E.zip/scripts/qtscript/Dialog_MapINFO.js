//{"name":"Dialog_MapINFO","version":1,"date":20230127}

global.pt0.mapinfo={};

function getTeams(){
	var teams2=[];
	Team.all.forEach(w=>{
		try{
		Vars.indexer.eachBlock(w,0,0,1280,boolf(g=>{return true}),f=>{
			throw f.team
		})
		}catch(error){
			teams2.push(error);
		}
	});
	Vars.state.teams.getActive().each(q=>{if(!teams2.includes(q.team))teams2.push(q.team)});
	return teams2.sort((a,b)=>{return (a.id>b.id?1:-1)})
}

global.pt0.mapinfo.reload = function(){
var activeteams = getTeams();
Dialog = new BaseDialog("@mode.help.title");
Dialog.addCloseButton();
Dialog.cont.clear();
function boolif(o,str,str2){return (o?"[orange]":"[darkgray]")+Core.bundle.format(str)+(str2?str2:"")};
function floatif(o,str){return (o!=1?"[white]":"[gray]")+Core.bundle.format(str)+"  =  "+(o>1?"[green]":(o<1?"[red]":""))+Math.round(o*100)/100};
function floatif2(o,id2){return (o==(id2?0:1)?"[#555555]":"")+Math.round(o*100)/100};
function _amount(e){
	if(e<1000)return e;
	if(e<1000000)return Math.round(e/100)/10+"k";
	return Math.round(e/100000)/10+"M";
}
Dialog.cont.pane(f=>{
var up=new Table();
var up1 = new Table();
var up2 = new Table();
f.add("[#ffd37d]"+Core.bundle.format("editor.rules")+" Vars.state.rules\n",Styles.outlineLabel);
f.row();
f.add(up).top().left();

up1.left();up2.right();
up1.add(boolif(Vars.state.rules.infiniteResources,"rules.infiniteresources")).left().row();
up1.add(boolif(Vars.state.rules.damageExplosions,"rules.explosions")).left().row();
up1.add(boolif(Vars.state.rules.reactorExplosions,"rules.reactorexplosions")).left().row();
up1.add(boolif(Vars.state.rules.schematicsAllowed,"rules.schematic")).left().row();
up1.add(boolif(Vars.state.rules.coreIncinerates,"rules.coreincinerates")).left().row();
up1.add(boolif(Vars.state.rules.onlyDepositCore,"rules.onlydepositcore")).left().row();
up1.add(boolif(Vars.state.rules.coreCapture,"rules.corecapture")).left().row();
up1.add(Core.bundle.get("rules.unitcap") + ": " + Vars.state.rules.unitCap + (Vars.state.rules.unitCapVariable ? "+"+Blocks.coreNucleus.emoji():"")).left();
up.add(up1).padLeft(15).padRight(15);

up2.row();
up2.add(floatif(Vars.state.rules.blockHealthMultiplier,"rules.blockhealthmultiplier")).left().row();
up2.add(floatif(Vars.state.rules.blockDamageMultiplier,"rules.blockdamagemultiplier")).left().row();
up2.add(floatif(Vars.state.rules.buildCostMultiplier,"rules.buildcostmultiplier")).left().row();
up2.add(floatif(Vars.state.rules.buildSpeedMultiplier,"rules.buildspeedmultiplier")).left().row();
up2.add(floatif(Vars.state.rules.deconstructRefundMultiplier,"rules.deconstructrefundmultiplier")).left().row();
up2.add(floatif(Vars.state.rules.unitDamageMultiplier,"rules.unitdamagemultiplier")).left().row();
up2.add(floatif(Vars.state.rules.unitHealthMultiplier,"rules.unithealthmultiplier")).left().row();
up2.add(floatif(Vars.state.rules.unitBuildSpeedMultiplier,"rules.unitbuildspeedmultiplier")).left().row();
up2.add(floatif(Vars.state.rules.solarMultiplier,"rules.solarmultiplier")).left();
up.add(up2).padLeft(15).padRight(15);

f.row();
f.add("\n[#ffd37d]"+Core.bundle.format("rules.title.teams")+Core.bundle.format("editor.rules")+" <team>.rules()\n");
f.row();
var mid=new Table();
	mid.add("@rules.title.teams").padLeft(5).padRight(5);
	mid.add("单位建造").padLeft(5).padRight(5);
	mid.add("单位攻击").padLeft(5).padRight(5);
	mid.add("单位血量").padLeft(5).padRight(5);
	mid.add("建筑攻击").padLeft(5).padRight(5);
	mid.add("建筑血量").padLeft(5).padRight(5);
	mid.add("建造速度").padLeft(5).padRight(5);
	mid.add("无限子弹").padLeft(5).padRight(5);
	mid.add("无限资源").padLeft(5).padRight(5);
activeteams.forEach(e=>{
	mid.row();
	var RULES = Vars.state.rules.teams.get(e);
	mid.add(e.localized()).color(e.color);
	mid.add(floatif2(RULES.unitBuildSpeedMultiplier)).color(e.color);
	mid.add(floatif2(RULES.unitDamageMultiplier)).color(e.color);
	mid.add(floatif2(RULES.unitHealthMultiplier)).color(e.color);
	mid.add(floatif2(RULES.blockDamageMultiplier)).color(e.color);
	mid.add(floatif2(RULES.blockHealthMultiplier)).color(e.color);
	mid.add(floatif2(RULES.buildSpeedMultiplier)).color(e.color);
	mid.add(floatif2(RULES.infiniteAmmo,-1)).color(e.color);
	mid.add(floatif2(RULES.infiniteResources||RULES.cheat,-1)).color(e.color);
});
f.row();
f.add(mid);

f.row();
f.add("\n[#ffd37d]"+Core.bundle.format("rules.title.teams")+Core.bundle.format("resources")+" <team>.items()\n");
f.row();
var mid2=new Table();
	mid2.add("@rules.title.teams").padLeft(5).padRight(5);
activeteams.forEach(e=>{
	mid2.row();
	mid2.add(e.localized()).color(e.color);
	var result="";
	var count=0;
	e.items().each((item,amount)=>{count++;result+=item.emoji()+"[gray]: "+_amount(amount)+((count%5!=0)?"[white], ":"\n[white]");});
	mid2.labelWrap(result+"\n").width(600);
});
f.add(mid2);

f.row();
f.add("\n[#ffd37d]"+Core.bundle.format("rules.title.teams")+Core.bundle.format("rules.title.unit")+" <team>.units()\n");
f.row();
var mid2=new Table();
	mid2.add("@rules.title.teams").padLeft(5).padRight(5);
	mid2.add("总数").padLeft(5).padRight(5);
activeteams.forEach(e=>{
	mid2.row();
	mid2.add(e.localized()).color(e.color);
	mid2.add(e.data().units.size+"").color(e.color);
	var result=[];
	e.data().units.map(f=>f.type).toArray().sort((a,b)=>{return (a.id>b.id?1:-1)}).forEach(g=>{
	if(!result.includes(g))result.push(g,1);else result[result.indexOf(g)+1]++;
	});
	var result7="";
	for (var ix=0;ix<result.length;ix+=2){
		result7+= result[ix].emoji()+" [gray]"+result[ix+1]+((ix%10==8)?"\n[white]":" [white], ");
	};
	mid2.labelWrap(result7+"\n").width(600);
});
f.add(mid2);

});
Dialog.show();
}
//借鉴MI2

