//{"name":"Dialog_MapsSelector","version":210.03,"date":20230127}

var 星空_mode2={"a":"[red]攻击","s":"[green]生存","p":"[purple]对战"};
var 星空_data={};


function map_popup_handler(e,t){
	e.forEach(f=>{
		t.add(f[0]).left().width(500);
		t.button(Icon.download,e=>{
		if(global.ptv.nowaddress.name.startsWith(global.pt.getValue("名称_星空"))){
			if(f[2]==0)global.pt.cmdlist("/host "+f[1]);
			else global.pt.cmdlist("/hostw "+f[1]);
		}else{
			global.pt.cmdlist("/host "+f[1]);
		}	
		});
		t.button(Icon.zoom,e=>{global.pt.sendChatMessageQueue("[#ffdfdf][[Pt=E v"+global.pt.modv+"] []分享一个地图： "+f[0])});
		t.row();
	})
}

function map_popup(){
	var mode=0;
	var search="";
	var table=new Table(Tex.button);
	var t2 = new Table();
	t2.field(search,e=>{search=e;}).left().width(550);
	t2.button(Icon.zoom,e=>{
		tableok.clear();
		switch(mode){
			case 0:
			map_popup_handler(map星空(search),tableok);
			break;
		}
	}).width(50);
	table.add(t2);
	table.row();
	var tableok = new Table();
	table.pane(cons(k=>{
		tableok=k
	}));
	table.row();
	table.button("[scarlet]X",e=>{table.remove()}).left();
	if(mode==0){
		table.row();
		table.button("[acid]重新获取地图",e=>{
		星空_data=JSON.parse(Vars.dataDirectory.child("qt/starsky").readString());
		星空_data["map_list"]=[];
		Vars.dataDirectory.child("qt/starsky").writeString(JSON.stringify(星空_data, null, 2));
		if(global.pt0.SideBarDialog)global.pt0.SideBarDialog.scan_maps();
		global.pt.cmdlist("/maps");
	}).width(200).left();
	}
	Core.scene.table().add(table);
}


function map星空(par){
	try{
	if(Vars.dataDirectory.child("qt/starsky").exists()){
	var maps_details = JSON.parse(Vars.dataDirectory.child("qt/starsky").readString());
	}else{
	var maps_details={
		map_list:[]
	};
	};
	var result=[];
	if(parseInt(par) && maps_details.map_list[parseInt(par)]){
		var maps_by_num = maps_details.map_list[parseInt(par)];
		result.push(["#"+maps_by_num.id+" "+星空_mode2[maps_by_num.mode]+"[white] "+maps_by_num.name+" [gray]游玩次数: "+maps_by_num.times,parseInt(par),0]);
	};
	var parameter = [par.trim()];
	if(par[par.length-1])
	if (par[par.length-1].match(/[asp]/)){
		var parameter = [par.substring(0,par.length-2).trim(),par.substring(par.length-1)];
	};
	maps_details.map_list.forEach(e=>{
		if(e){
		if(e.name.includes(parameter[0]) && (parameter[1]?parameter[1]==e.mode:true)){
			result.push(["#"+e.id+" "+星空_mode2[e.mode]+"[white] "+e.name+" [gray]游玩次数: "+e.times,e.id,0]);
		}
		}
	});
	return result;
	}catch(error){}
}

global.pt0.map_popup = function(){map_popup()};