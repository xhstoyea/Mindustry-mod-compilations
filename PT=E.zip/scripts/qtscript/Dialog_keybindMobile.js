//{"name":"Dialog_keybindMobile","version":1,"date":20230127}

var language=global.pt.getValue("language");

var GlobalDict={
	"others":"[gold] 通用 General",
	"mapdesc":language==0?" 地图资讯":" 地圖資訊",
	"powernodeFix":language==0?" 修复电网":" 修復電網",
	"removeBullet":language==0?" 移除子弹":" 移除子彈",
	"removeDecal":language==0?" 移除残骸":" 移除殘骸",
	"disableUnit":language==0?" 移除单位":" 移除單位",
	"allmapinfo":language==0?" 地图站":" 地圖站",
	"blueprint_store":language==0?" 蓝图快照":" 藍圖快照",
	"wpy_ctrl":" 物品元控制",
	"movementmode7":language==0?" 搬运模式":" 搬運模式",
	"stealunit":language==0?" 抢单位":" 搶單位",

	"starsky2":language==0?"[sky] 星空专属":"[sky] 星空專屬",

	"onchat":"[#ff66aa] 聊天功能 OnChat MSG",
	"sos":"SOS!",
	"pan":language==0?" 查看最近坐标":" 查看最近坐標",
	"pmdialog":"pm 私聊",

	"graphics":language==0?"[#aa66ff] 显示 Graphics":"[#aa66ff] 顯示 Graphics",
	"air_range":language==0?"对空炮台范围":"對空炮臺範圍",
	"ground_range":language==0?"对地炮台范围":"對地炮臺範圍",
	"unitrange":language==0?"单位攻击范围":"單位攻擊範圍",
	"ore_show":language==0?"显示矿种":"顯示礦種",
	"boost_range":language==0?"加速范围显示":"加速範圍顯示",
	"fix_range":language==0?"修复范围显示":"修復範圍顯示",

	"AIController":language==0?"[#6666ff] 挂机设置 AIController":"[#7777ff] 挂機設置 AIController",
	"brokenbuild":language==0?"修复破坏":"修復破壞",
	"foobuild":language==0?"foo建筑":"foo建築",
	
	"Cheat":"[orange] 作弊 Cheat",
	"auto_rejoin":language==0?"自动重进":"自動重進",
	"autotransfer":language==0?"自动搬运":"自動搬運",
	"disableWorldProcessors":language==0?"禁止世界处理器":"禁用世界處理器",
	"pvp_destruct":language==0?"pvp拆建筑":"pvp拆建築",
	"AutoBluePrintGen":language==0?"地蓝记录":"地藍記錄",
	"AutoBluePrintUse":language==0?"地蓝使用":"地藍使用",
	
	"remove":"移除",
	"bind":"已绑定",

};


function rebuild(q2,c){
	var x = new Table(Tex.button);
	x.add(Core.bundle.get("keybind.title")+q2);
	var t2 = new Table();
	x.row();
	var pref = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16];
	let na2 = global.pt.getValue("keycode_mobile");
	pref.forEach(i=>{
		if(i>1&&i%4==1)t2.row();
		let t=i;
		t2.button(na2[i]?na2[i][1]:i+"",q=>{
			let na = global.pt.getValue("keycode_mobile");
			print(q2);
			na[t]=q2?[q2,c+""+GlobalDict[q2],GlobalDict[q2]]:null;
			global.pt.storeValue(na,"keycode_mobile");
			x.remove();
		}).width(150);
	});
	x.add(t2);
	x.row();
	x.button("X",q=>x.remove());
	Core.scene.table().add(x);
}


var config2 = null;

function _load(){
config2=global.pt.getValue("keycode_mobile");
const preference=[
	"*others","mapdesc","powernodeFix","removeBullet","removeDecal","disableUnit","allmapinfo","blueprint_store","wpy_ctrl","movementmode7","stealunit",
	"*graphics","air_range","ground_range","unitrange","ore_show","boost_range","fix_range",
	"*AIController","brokenbuild","foobuild",
	"*onchat","sos","pan","pmdialog",
	"*Cheat","auto_rejoin","autotransfer","disableWorldProcessors","pvp_destruct","AutoBluePrintGen","AutoBluePrintUse"
];
var Dialog = new BaseDialog("@keybind.title");
var color2="[#ffffff]";
Dialog.addCloseButton();
Dialog.cont.clear();
Dialog.cont.pane(f=>{
	preference.forEach(q=>{
		if(q[0]=="*"){
			q=q.substring(1,f.length);
			f.add(" ");f.row();
			f.add(GlobalDict[q]+"").left();
			color2=GlobalDict[q].split(" ")[0];
		}else{
			f.add(GlobalDict[q]+"").width(300);
			let color = color2;
			f.add("").update(w=>w.text=(global.pt.getValue("keycode_mobile").map(j=>(j?j[0]:null)).includes(q)?color+GlobalDict.bind:"")).width(60);
			f.button("@settings.rebind",w=>{rebuild(q,color)}).width(100);
		}
		f.row();	
	});
	f.button(GlobalDict.remove,q=>{rebuild(null)}).width(250);
	f.row();
});
Dialog.show();
}

function _onload2(){
	var t2 = new Table();
	var pref = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16];
	pref.forEach(i=>{
		if(i>1&&i%4==1)t2.row();
		let t=i;
		t2.button("",q=>{
			if(global.pt.getValue("keycode_mobile")[t]){
			let f=global.pt.getValue("keycode_mobile")[t][0];
			switch(f){
	case "pan":
	case "mapdesc":
	case "powernodeFix":
	case "allmapinfo":
	case "blueprint_store":
	case "wpy_ctrl":
	case "movementmode7":
	case "stealunit":
	case "sos":
	case "pmdialog":
	case "AutoBluePrintGen":
	case "AutoBluePrintUse":
	Vars.ui.showInfoToast("[#3377ff]"+GlobalDict[f],1.5);
	global.pt.Dialog_keybind[f]();
	break;
	case "brokenbuild":
	case "foobuild":
	case "autotransfer":
	case "disableWorldProcessors":
	Vars.ui.showInfoToast((global.pt.Dialog_keybind[f]()?"[#ffffff]":"[gray]")+GlobalDict[f],1.5);
	break;
	default:
	Vars.ui.showInfoToast((!global.pt.getValue(f)?"[#ffffff]":"[gray]")+GlobalDict[f],1.5);
	global.pt.storeValue(!global.pt.getValue(f),f);
	break;
			}}
		}).update(q=>{
			q.setText(global.pt.getValue("keycode_mobile")[t]?global.pt.getValue("keycode_mobile")[t][2]:"");
			q.setColor(global.pt.getValue("keycode_mobile")[t]?Color(0,1,1):Color(0,0,0,0));
		}).width(175).height(50)
	});
	return t2;
}

global.pt0.keybind_mobile={
load(){
_load()
},
_onload(){
return _onload2()
},
}

