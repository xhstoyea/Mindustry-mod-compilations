//{"name":"AI_followingAI","version":210,"date":20230127}

global.pt0.followingAI={
	data:
extend(AIController,{
	_sat:[64,0.95],
	playertarget:null,
	unitS(u){
		if(this.unit == u) return;
        this.unit = u;
        this.init();
	},
	updateMovement(){
		try{
	if(this.playertarget.tileOn()){
		if(this.unit.within(this.playertarget.tileOn(), this._sat[0])){
        this.circle(this.playertarget.tileOn(), this._sat[0], this._sat[1]);               
        }else{
		this.circle(this.playertarget.tileOn(), this._sat[0]);
		}
	}
		}catch(error){debug(error)}
	}
})
}