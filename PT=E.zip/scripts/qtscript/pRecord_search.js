//{"name":"pRecord_search","version":210,"date":20230127}

global.pt0.pRecord={
search2(type){
try{
var _0x92 = [];
if(Vars.dataDirectory.child('qt/ptall').exists()){
    var _PTisExcellentnew= JSON.parse("["+Vars.dataDirectory.child('qt/ptall').readString()+"]");
	var _0x90 = 0;
	if (type.includes("as") || type.includes("de")){
		var _0x117 = [];
		if (type.includes("as")){
			_0x117=_PTisExcellentnew[type[type.indexOf("as")+1]];
			_0x117["seq"]=(type[type.indexOf("as")+1]);
		}else if(type.includes("de")){
			_0x117=_PTisExcellentnew[_PTisExcellentnew.length - type[type.indexOf("de")+1]-1];
			_0x117["seq"]=(_PTisExcellentnew.length - type[type.indexOf("de")+1]-1);
		}
		_0x92 = [_0x117];
	}else{
	_PTisExcellentnew.forEach((_0x91,index)=>{
		for (var _0x9a=0;_0x9a<type.length/2;_0x9a++){
			if (_0x91[type[_0x9a*2]].includes(type[_0x9a*2+1])){
				_0x91["seq"]=index;
				_0x92.push(_0x91);
				break;
			};
		}
	})
	}
return _0x92;
}}catch(k){return [k]}
},
search1(type){
try{
var _0x92 = [];
if(Vars.dataDirectory.child('qt/ptall').exists()){
    var _PTisExcellentnew= JSON.parse("["+Vars.dataDirectory.child('qt/ptall').readString()+"]");
	_PTisExcellentnew.forEach((_0x91,index)=>{
		var parsed = false;
		type.forEach(f=>{
			Object.keys(_0x91).forEach(g=>{
				if(_0x91[g] && _0x91[g].toString().includes(f) && !parsed){
					_0x91["seq"]=index;
					_0x92.push(_0x91);
					parsed=true;
				}
			})
		})
	})
	}
return _0x92;
}catch(k){return [k]}
},
}