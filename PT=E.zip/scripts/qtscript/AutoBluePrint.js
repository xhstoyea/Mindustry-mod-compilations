function Schematics_create(x, y, x2, y2, name2, desc2, team2, id2, uid2, parm2){
	var tiles = new Seq();
	var width = x2 - x + 1, height = y2 - y + 1;
	var offsetX = -x, offsetY = -y;
	var counted = new IntSet();
	for(var cx = x; cx <= x2; cx++){
		for(var cy = y; cy <= y2; cy++){
			var tile = Vars.world.build(cx, cy);
			if(!tile) continue;
			var realBlock = tile instanceof ConstructBlock.ConstructBuild ? tile.current : tile.block;
			if(!realBlock) continue;
			if(team2!="ALL" && team2!=tile.team)continue;
			if(!counted.contains(tile.pos()) && (realBlock.isVisible() || realBlock instanceof CoreBlock)){
				var config = (tile instanceof ConstructBlock.ConstructBuild? tile.lastConfig : tile.config());
				tiles.add(new Schematic.Stile(realBlock, tile.tileX() + offsetX, tile.tileY() + offsetY, config, Math.floor(tile.rotation)%4));
				counted.add(tile.pos());
			}
		}
	}
	var properties = {
	"offsetX":Math.ceil((x+x2)/2),
	"offsetY":Math.ceil((y+y2)/2),
	"x":x,"y":y,
	"x2":x2,"y2":y2,
	"parm":parm2
	};
	var sch=new Schematic(tiles, new StringMap(), width, height);
	sch.labels=new Seq(["pt地蓝"]);
	sch.tags.put("description",JSON.stringify(properties));
	sch.tags.put("name","地_id"+id2+"_v"+desc2+"_"+name2);
	//Vars.schematics.add(sch);
	Vars.dataDirectory.child("qt/mapsch/地_id"+id2+"_v"+desc2+"_"+name2+".ptsch").writeString(Vars.schematics.writeBase64(sch));
	return sch;
};

function SCH_fromClipboard(name2,desc2,id2,uid2,parm2){
	var sch=null;
	try{
		sch=read2(Core.app.getClipboardText());
	}catch(err){return err}
	var properties = {
	"offsetX":0,
	"offsetY":0,
	"x":0,"y":0,
	"x2":0,"y2":0,
	"parm":parm2
	};
	sch.labels=new Seq(["pt地蓝"]);
	sch.tags.put("description",JSON.stringify(properties));
	sch.tags.put("name","地_id"+id2+"_v"+desc2+"_"+name2);
	Vars.dataDirectory.child("qt/mapsch/地_id"+id2+"_v"+desc2+"_"+name2+".ptsch").writeString(Vars.schematics.writeBase64(sch));
	return sch;
}

const ROTATION_BUILD = [Conveyor,StackConveyor,ArmoredConveyor,PayloadConveyor,PayloadRouter,UnitFactory,Reconstructor,Conduit,ArmoredConduit,DirectionalUnloader];
const CONFIG_BUILD = [Sorter,Unloader];
function Schematics_ValidPlace(b,x,y,r,c){
var build=Vars.world.build(x,y);
if(build && build.block && build.block == b){
try{
	ROTATION_BUILD.forEach(w=>{
		if(build.block instanceof w && r!=build.rotation)throw 0;
	});
	if(build.config && build.config() && build.config() instanceof Point2 && c instanceof Point2 && build.config().pack()!=c.pack())throw 2;
	CONFIG_BUILD.forEach(w=>{
		if(build.block instanceof w && c!=build.config())throw 2;
	});
}catch(error){return error}
return 1;
}
if(Build.validPlace(b,Vars.player.team(),x,y,r))return 0;
return 2;
}
var POS=null;
Events.run(Trigger.draw, () => {
if(POS && POS.length==4)Lines.rect(POS[0]*8,POS[1]*8,(POS[2]-POS[0])*8,(POS[3]-POS[1])*8,3)
});

function Schematics_Apply(sch2,rotate,flip,ox,oy,fromOtherInstant){
	if(!sch2)return;
	var sch =sch2;
	var properties=null;
	try{properties = JSON.parse(sch.tags.get("description"))}catch(error){print(error+"E0x0010 NOT_A_PT_SCHEMATICS");return}
	if(rotate){
		if(rotate==3)sch = Schematics.rotate(sch,-1);
		if(rotate==1 || rotate==2)sch = Schematics.rotate(sch,1);
		if(rotate==2)sch = Schematics.rotate(copySch(sch),1);
	}
	if(flip){
		if((flip&1)==1)sch = flipPlans(sch,true);
		if((flip&2)==2)sch = flipPlans(sch,false);
	}
	var counted = new IntSet();
	var pend = Vars.schematics.toPlans(sch,(ox?ox:properties.offsetX),(oy?oy:properties.offsetY)).toArray();
	
	
	if(!global._qt.schignore || fromOtherInstant){
	pend.map(w=>counted.add(Point2.pack(w.x, w.y)));
	pend = pend.filter(w=>Schematics_ValidPlace(w.block,w.x,w.y,w.rotation,w.config)==0)
	.concat(pend.filter(w=>Schematics_ValidPlace(w.block,w.x,w.y,w.rotation,w.config)==2 && Build.validBreak(Vars.player.team(),w.x,w.y)).map(r=>new BuildPlan(r.x,r.y)));
	for(var cx = properties.x; cx <= properties.x2; cx++){
		for(var cy = properties.y; cy <= properties.y2; cy++){
			var tile = Vars.world.build(cx, cy);
			if(tile && tile.block && Build.validBreak(Vars.player.team(),tile.x/8,tile.y/8) && !counted.contains(tile.pos())){
				pend.push(new BuildPlan(cx,cy));
				counted.add(tile.pos());
			}
		}
	}
	}else{
		var pend2 = pend.map(w=>w);
		pend = pend.filter(w=>Schematics_ValidPlace(w.block,w.x,w.y,w.rotation,w.config)==0);
		try{
		pend2.filter(w=>(Schematics_ValidPlace(w.block,w.x,w.y,w.rotation,w.config)==2)).forEach(r=>{
			Vars.indexer.eachBlock(Vars.player.team(),
			Rect((r.x-Math.floor(r.block.size/2-0.1))*8,(r.y-Math.floor(r.block.size/2-0.1))*8,r.block.size*8-8,r.block.size*8-8),
			e=>Build.validBreak(Vars.player.team(),e.x/8,e.y/8)&&!counted.contains(e.pos()),
			f=>{
				pend.push(new BuildPlan(f.x/8,f.y/8));
				counted.add(f.pos())
			})
		})
		}catch(error){print(error)}
	}
	pend.forEach(w=>{
		try{if(w.block instanceof UnitFactory)w.config = w.block.plans.get(w.config).unit}catch(_){}
		Vars.player.unit().plans.addLast(w);
	});
	return pend.length;
}

function pane_gen2(){
	var t2 = new Table(Tex.whiteui.tint(0,0,2/16,0.5));
	var t4 = new Table(Tex.whiteui.tint(6/16,0,0,0.35));
	t4.labelWrap("pt地蓝记录器 v1").width(340).fillY().left();
	t4.button("X",Styles.cleart,e=>{
		t2.remove();
		POS=null;
	}).width(35).height(35).right();
	t2.add(t4);
	var lastX,lastY;
	t4.addListener(extend(InputListener,{
		touchDown(event,x,y,pointer,buttwon){
			lastX=x;
			lastY=y;
			return true;
		},
		touchUp(event,x,y,pointer,button){
			t2.x+=x-lastX;
			t2.y+=y-lastY;
		}
	}));
	
	t2.row();
	t2.add("").update(e=>e.text=
	"范围: "+GEN2.pos.toString()+
	"\n队伍: "+(GEN2.team=="ALL"?"[red]ALL":"[#"+GEN2.team.color+"]"+GEN2.team.name)+
	"\n[#dfffdf]文件名: 地_id"+GEN2.id+"_v"+GEN2.desc+"_"+GEN2.name+".ptsch"
	).row();
	var t3=new Table();
	t3.add("范围属性").color(Color(1,1,14/16)).colspan(4).pad(10).padBottom(4).row();
    t3.image().color(Color(1,1,14/16)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(300).row();
	t3.button("[#ffffdf]全图",Styles.cleart,w=>{GEN2.pos=[0,0,Vars.world.width(),Vars.world.height()];POS=GEN2.pos.map(e=>e)}).color(Color(1,1,14/16)).left().width(100).height(50);
	t3.field(GEN2.pos.toString(),e=>{GEN2.pos2=e.split(",").map(w=>parseInt(w))}).color(Color(1,1,14/16)).left().width(200);
	t3.button("[#ffffdf]确认",Styles.cleart,w=>{if(GEN2.pos2.length==4)GEN2.pos = GEN2.pos2.map(e=>e);POS=GEN2.pos.map(e=>e)}).color(Color(1,1,14/16)).left().width(50).height(50).row();
	var t7=new Table();
	t7.add("[#ffffdf]记录队伍").row();
	t7.button("[#ffffdf]本队",Styles.cleart,w=>{GEN2.team=Vars.player.team()}).color(Color(1,1,14/16)).left().width(70).height(50);
	t7.button("[#ffffdf]所有队",Styles.cleart,w=>{GEN2.team="ALL"}).color(Color(1,1,14/16)).left().width(70).height(50);
	t7.field(GEN2.team2,e=>{try{Team.get(e);GEN2.team2=e}catch(error){}}).color(Color(1,1,14/16)).left().width(160);
	t7.button("[#ffffdf]确认",Styles.cleart,w=>{GEN2.team=Team.get(GEN2.team2)}).color(Color(1,1,14/16)).left().width(50).height(50).row();
	
	var t5=new Table();
	t5.add("蓝图详细").color(Color(14/16,14/16,1)).colspan(4).pad(10).padBottom(4).row();
    t5.image().color(Color(14/16,14/16,1)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(300).row();
	t5.add("蓝图名称: ").color(Color(14/16,14/16,1));
	t5.field(GEN2.name,e=>{GEN2.name=e;GEN2.id=1;}).left().width(300).row();
	t5.add("蓝图版本: ").color(Color(14/16,14/16,1));
	t5.field(GEN2.desc,e=>{GEN2.desc=e;}).left().width(300).row();
	t5.add("蓝图ID: ").color(Color(14/16,14/16,1));
	t5.field(GEN2.id,e=>{GEN2.id=parseInt(e);}).left().width(300);
	
	var t6=new Table();
	t6.add("操作").color(Color(14/16,1,14/16)).colspan(4).pad(10).padBottom(4).row();
    t6.image().color(Color(14/16,1,14/16)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(300).row();
	t6.button("[#ffbbff]剪贴板导入",Styles.cleart,w=>{
		SCH_fromClipboard(GEN2.name,GEN2.desc,GEN2.id,chatarea.text);GEN2.id++;
	}).left().width(150).height(50).row();
	var chatarea = TextArea("");
	t6.add("[#ffffdf]参数 (下面填写)");
	t6.button("[#ffffdf]确认参数",Styles.cleart,w=>{GEN2.parm = chatarea.text}).left().width(150).height(50).row();
	
	t2.add(t3).row();
	t2.add(t7).row();
	t2.add(t5).row();
	t2.add(t6).row();
	t2.add(chatarea).width(450).height(100).row();
	Core.scene.table().add(t2);
}

var GEN2 = {};
var GENpane=false;
function pane_gen(){
	GENpane=true;
	var pt2 = Core.scene.find("PT_MENU");
	var pt3 = new Table(Tex.whiteui.tint(0,0,2/16,0.5));
	pt2.add(pt3).width(340).row();
	var t4 = new Table(Tex.whiteui.tint(6/16,0,0,0.35));
	t4.add("pt地蓝记录器 v1").width(300).left();
	t4.button("X",Styles.cleart,e=>{
		pt3.remove();GENpane=false;GEN2={};
	}).width(40).height(30).right();
	
	if(Object.keys(GEN2).length ==0)GEN2={
		"pos":[0,0,Vars.world.width(),Vars.world.height()],
		"team":Vars.player.team(),
		"name":Vars.state.map.name(),
		"desc":"1",
		"pos2":[0,0,0,0],
		"team2":1,
		"id":1,
		"parm":""
	};
	pt3.add(t4).row();
	pt3.label(() => "[#dfffdf]文件名: 地_id"+GEN2.id+"_v"+GEN2.desc+"_"+GEN2.name+".ptsch").row();
	
	var t7 = new Table();
	t7.button("[#ffbbbb]",Styles.cleart,e=>{
		Schematics_create(GEN2.pos[0],GEN2.pos[1],GEN2.pos[2],GEN2.pos[3],GEN2.name,GEN2.desc,GEN2.team,GEN2.id,GEN2.parm);GEN2.id++;
	}).width(60).height(50);
	
	
	t7.button("[#ffbbff]修改地蓝 ",Styles.cleart,e=>{
		Vars.ui.showConfirm("","[red]确认修改地蓝? 此操作无法挽回！\n[gray]参数: "+RSS2.name.replace(".ptsch","")+" v"+RSS2.desc+" id"+RSS2.bid,()=>{
			GEN2.name=RSS2.name.replace(".ptsch","");
			GEN2.desc=RSS2.desc;
			GEN2.id=RSS2.bid;
			Schematics_create(GEN2.pos[0],GEN2.pos[1],GEN2.pos[2],GEN2.pos[3],GEN2.name,GEN2.desc,GEN2.team,GEN2.id,GEN2.parm);
			GEN2.id++;
		})
	}).width(150).height(40);
	
	t7.button("[#ffffbb]",Styles.cleart,e=>{pane_gen2();}).width(60).height(50);
	pt3.add(t7).row();
}

function chkallsch(){
	var valid = [];
	/*Vars.schematics.all().each(w=>w.labels.contains("pt地蓝"),e=>{
		if(e.name().includes("_id1_"))valid.push(e);
	});*/
	Vars.dataDirectory.child("qt/mapsch").findAll().each(e=>{
		if(e.name().includes("_id1_"))valid.push(e.name());
	})
	return valid;
}

var RSS2 = {};
var RSSpane = false;
function autouse(num,name2){
if(Object.keys(RSS2).length ==0 || num==0){
	var w = chkallsch().filter(w=>w.includes(name2)).sort((a,b)=>{
		try{
			return (parseInt(a.split("_v")[1].split("_")[0])<parseInt(b.split("_v")[1].split("_")[0])?-1:1)
		}catch(error){return 0;}
		}).reverse()[0];
	if(!w)return -1;
	RSS2={
	"bid":1,"tbid":Vars.dataDirectory.child("qt/mapsch").findAll().toArray().filter(e=>e.name().endsWith("_v"+w.split("_v")[1])).length,
	"name":w.split("_")[3],
	"rotate":0,
	"flip":0,
	"ox":0,
	"oy":0,
	"origx":0,
	"origy":0,
	"origpos2":[0,0],
	"bestFit":[[0,0,0],[0,0,0],[0,0,0],[0,0,0]],
	"desc":w.split("_v")[1].split("_")[0],
	};
	findCore2(w,RSS2);
}else{
	findCore2("地_id"+RSS2.bid+"_v"+RSS2.desc+"_"+RSS2.name,RSS2);
}
var ok = true;
if(RECENT_SCH){
var prop = JSON.parse(RECENT_SCH.tags.get("description"));
if(prop.parm)
prop.parm.split("\n").forEach(w=>{
	if(w.startsWith("rss=")){
		try{
		if(Vars.player.team().items().get(w.split("rss=@")[1].split("=")[0])< parseInt(w.split("=")[2]))ok=false;
		}catch(error){Vars.ui.chatfrag.addMessage(error);}
	}
})
}

if(RSS2.bid==1 || ok){
	if(!RSSpane){RSSpane=true;pane_use();}
	var schbuild = Schematics_Apply(RECENT_SCH,RSS2.rotate,RSS2.flip,RSS2.ox,RSS2.oy);
	if(schbuild==0){RSS2.bid++;}
}
return RSS2.bid;
}

function findCore2(name2,rss){
try{
	RECENT_SCH = read2(Vars.dataDirectory.child("qt/mapsch/"+name2).readString());
	var prop = JSON.parse(RECENT_SCH.tags.get("description"));
	//rss.ox = prop.offsetX;rss.oy = prop.offsetY;
	rss.origx = prop.offsetX;rss.origy = prop.offsetY;
}catch(error){print(error+"E0x0010 NOT_A_PT_SCHEMATICS");rss.bid=-144;return}

var tempsch2 = copySch(RECENT_SCH);
var highscr = [0,0];
for (var i=0;i<4;i++){
	rss.bestFit[i] = chkCore(tempsch2);
	tempsch2=copySch(Schematics.rotate(tempsch2,1));
	if(rss.bestFit[i][2]>highscr[1])highscr=[i,rss.bestFit[i][2]]
}
//print(JSON.stringify(highscr)+" "+JSON.stringify(rss.bestFit));

rss.rotate=highscr[0];
rss.ox=rss.bestFit[highscr[0]][0];
rss.oy=rss.bestFit[highscr[0]][1];
}

const ROTATION = "";
var RECENT_SCH=null;
function pane_use(){
	RSSpane=true;
	var pt2 = Core.scene.find("PT_MENU");
	var pt3 = new Table(Tex.whiteui.tint(0,0,2/16,0.5));
	pt2.add(pt3).width(340).row();
	var t4 = new Table(Tex.whiteui.tint(6/16,0,0,0.35));
	t4.add("pt地蓝使用器 v1").width(300).left();
	t4.button("X",Styles.cleart,e=>{
		pt3.remove();RSSpane=false;
	}).width(40).height(30).right();
	
	if(Object.keys(RSS2).length ==0)RSS2={
		"bid":1,"tbid":1,
		"name":"",
		"rotate":0,
		"flip":0,
		"ox":0,
		"oy":0,
		"origx":0,
		"origy":0,
		"origpos2":[0,0],
		"bestFit":[[0,0,0],[0,0,0],[0,0,0],[0,0,0]],
		"desc":1,
	};
	
	pt3.add(t4).row();
	pt3.label(() => 
	"[#bbbbff]蓝图档案: []v"+RSS2.desc+" "+RSS2.name+
	"\n[#bbffbb]进度: [white]"+RSS2.bid+" [gray]/ "+RSS2.tbid
	).row();
	
	var t7 = new Table();
	t7.button(Icon.players,Styles.clearTogglei,e=>{
		global._qt.autotest=!global._qt.autotest;
	}).update(b=>b.setChecked(!!global._qt.autotest)).width(60).height(50);
	t7.button("[#ffbbbb]",Styles.cleart,e=>{RSS2.bid--;findCore2("地_id"+RSS2.bid+"_v"+RSS2.desc+"_"+RSS2.name,RSS2)}).width(60).height(50);
	t7.button("[#ffbbbb]",Styles.cleart,e=>{
		Schematics_Apply(RECENT_SCH,RSS2.rotate,RSS2.flip,RSS2.ox,RSS2.oy)
	}).width(60).height(50);
	t7.button("[#ffbbbb]",Styles.cleart,e=>{
		RSS2.bid++;
		findCore2("地_id"+RSS2.bid+"_v"+RSS2.desc+"_"+RSS2.name,RSS2);
		Schematics_Apply(RECENT_SCH,RSS2.rotate,RSS2.flip,RSS2.ox,RSS2.oy)
	}).width(60).height(50);
	t7.button("[#ffffbb]",Styles.cleart,e=>{
		pane_use2();
	}).width(60).height(50);
	pt3.add(t7).row();
}
function pane_use2(){	
	var t2 = new Table(Tex.whiteui.tint(0,0,2/16,0.5));
	var t4 = new Table(Tex.whiteui.tint(6/16,0,0,0.35));
	t4.labelWrap("pt地蓝使用器 v1").width(410).fillY().left();
	t4.button("X",Styles.cleart,e=>{
		t2.remove();
	}).width(40).height(35).right();
	t2.add(t4);
	var lastX,lastY;
	t4.addListener(extend(InputListener,{
		touchDown(event,x,y,pointer,buttwon){
			lastX=x;
			lastY=y;
			return true;
		},
		touchUp(event,x,y,pointer,button){
			t2.x+=x-lastX;
			t2.y+=y-lastY;
		}
	}));
	
	t2.row();

	var t6=new Table(Tex.whiteui.tint(0,6/16,0,0.35));
	
	t6.add("选择").color(Color(14/16,1,14/16)).colspan(4).pad(10).padBottom(4).row();
    t6.image().color(Color(14/16,1,14/16)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(300).row();
	t6.pane(cons(k=>{
		chkallsch().forEach((w,id)=>{
			let name2 = w;
			k.button("#"+id+". "+w,Styles.cleart,e=>{
				RSS2.name=w.split("_")[3];
				RSS2.desc=w.split("_v")[1].split("_")[0];
				RSS2.bid=1;
				RSS2.tbid=Vars.dataDirectory.child("qt/mapsch").findAll().toArray().filter(e=>e.name().endsWith("_v"+w.split("_v")[1])).length;
				RSS2.ox=0;RSS2.oy=0;
				RSS2.origx=0;RSS2.origy=0;
				findCore2(name2,RSS2);
			}).width(380).height(55);
			k.button("[red]",Styles.cleart,e=>{
			Vars.ui.showConfirm("","确认删除 地蓝: "+name2,()=>{
				Vars.dataDirectory.child("qt/mapsch").findAll().toArray().filter(w=>
					w.name().endsWith("_v"+name2.split("_v")[1])
				).forEach(e=>e.delete());
			//Vars.dataDirectory.child("qt/mapsch/"+name2).delete();
			Vars.ui.showInfoToast(name2+" 已经删除",2);
			});
			}).width(30).height(30).row();
		})
	})).height(300).width(410);
	var t7 = new Table();
	
	t7.button("旋转 ",Styles.cleart,e=>{RSS2.rotate = (RSS2.rotate+1)%4}).width(100).height(40);
	t7.button("纵翻 ",Styles.cleart,e=>{RSS2.flip^=2;}).width(100).height(40);
	t7.button("横翻 ",Styles.cleart,e=>{RSS2.flip^=1;}).width(100).height(40);
	
	var t8 = new Table();
	t8.button("[#ffffdf]预设",Styles.cleart,w=>{RSS2.ox=RSS2.origx;RSS2.oy=RSS2.origy}).color(Color(1,1,14/16)).left().width(100).height(40);
	t8.field("0,0",e=>{RSS2.origpos2=e.split(",").map(w=>parseInt(w))}).color(Color(1,1,14/16)).left().width(200);
	t8.button("[#ffffdf]确认",Styles.cleart,w=>{if(RSS2.origpos2.length==2){RSS2.ox=RSS2.origpos2[0],RSS2.oy=RSS2.origpos2[1]}}).color(Color(1,1,14/16)).left().width(50).height(40).row();
	
	t2.add(t6).row();
	t2.add("[#ffbbbb]旋转: "+ROTATION[RSS2.rotate]+"  | 翻转: "+((RSS2.flip&2)==2?"":"")+((RSS2.flip&1)==1?"":"")+"  | 中心XY坐标: "+RSS2.ox+", "+RSS2.oy).row();
	t2.add(t7).row();
	t2.add(t8).row();
	Core.scene.table().add(t2);
}

function copySch(sch){
var tmpsch =  new Schematic(new Seq(), new StringMap(), 0, 0);
tmpsch.width = sch.width;tmpsch.height = sch.height;
sch.tiles.each(w=>tmpsch.tiles.add(new Schematic.Stile(w.block, w.x, w.y, w.config, w.rotation)));
return tmpsch;
}

function flipPlans(sch,flipxy){
var tmpsch = copySch(sch);

var origin = -1+(flipxy ? sch.width/2 : sch.height/2);
tmpsch.tiles.each(req => {
    var value = (flipxy ? req.x : req.y) - 2*((flipxy ? req.x : req.y) - origin);
	if(flipxy){req.x = value;}else{req.y = value;}

	req.config = BuildPlan.pointConfig(req.block, req.config, p => {
       var cx = p.x, cy = p.y;
	   if(flipxy){
			cx = p.x - 2*(p.x-origin);
		}else{
			cy = p.y - 2*(p.y-origin);
		}
       p.set(cx, cy);
    });

	if(flipxy == (req.rotation % 2 == 0)){
       req.rotation = (req.rotation + 2) % 4;
    }
    });
return tmpsch;
}

global.pt0.AutoBluePrint={
"gen":function(){if(!GENpane){GENpane=true;pane_gen()}},
"use":function(){if(!RSSpane){RSSpane=true;pane_use()}},
"read":read2,
"autouse":autouse,
"toPlans":Schematics_Apply,
}

//MODIFIED blueprint reader from ANUKE
//Exceed 128x128 limit
function read2(k){
var input=new java.io.ByteArrayInputStream(Base64Coder.decode(k.trim()));
[109,115,99,104].forEach(w=>{if(input.read()!=w)return ("E_NOT A SCHEMATIC")});

var ver = input.read();
var stream = new java.io.DataInputStream(new java.util.zip.InflaterInputStream(input));
var width = stream.readShort(), height = stream.readShort();
var map = new StringMap();
var tags = stream.readUnsignedByte();
for(i = 0; i < tags; i++){map.put(stream.readUTF(), stream.readUTF())}
var labels = "";
try{labels = map.get("labels", "[]")}catch(ignored){}

var blocks = new IntMap();
var length = stream.readByte();

for(var i = 0; i < length; i++){
	var name = stream.readUTF();
	var block = Vars.content.getByName(ContentType.block, SaveFileReader.fallback.get(name, name));
	blocks.put(i, block == null || block instanceof LegacyBlock ? Blocks.air : block);
}
var total = stream.readInt();

var tiles = new Seq(total);
for(var i = 0; i < total; i++){
	var block = blocks.get(stream.readByte());
	var position = stream.readInt();
	var config = ver == 0 ? mapConfig(block, stream.readInt(), position) : TypeIO.readObject(Reads.get(stream));
	var rotation = stream.readByte();
	if(block != Blocks.air){
		tiles.add(new Schematic.Stile(block, Point2.x(position), Point2.y(position), config, rotation));
	}
}

var out = new Schematic(tiles, map, width, height);
if(labels != null) out.labels.addAll(labels);
return out;
}

function mapConfig(block, value, position){
	if(block instanceof Sorter || block instanceof Unloader || block instanceof ItemSource) return Vars.content.item(value);
	if(block instanceof LiquidSource) return Vars.content.liquid(value);
	if(block instanceof MassDriver || block instanceof ItemBridge) return Point2.unpack(value).sub(Point2.x(position), Point2.y(position));
	if(block instanceof LightBlock) return value;

	return null;
}

function chkCore(k){
	var schcores = k.tiles.toArray().filter(w=>w.block instanceof CoreBlock).sort((a,b)=>{return (a.x*a.y<b.x*b.y?1:-1)});
	var teamcores = Vars.player.team().cores().toArray().sort((a,b)=>{return (a.x*a.y<b.x*b.y?1:-1)});
	
	var offset = [Math.floor(teamcores[0].x/8) - schcores[0].x, Math.floor(teamcores[0].y/8) - schcores[0].y];
	
	var pt=0;
	schcores.forEach(w=>{
		var build = Vars.world.build(offset[0]+w.x,offset[1]+w.y);
		if(build && build.block && build.block==w.block)pt++;
	});
	return [Math.floor(k.width/2)+offset[0],Math.floor(k.height/2)+offset[1],pt]
}

