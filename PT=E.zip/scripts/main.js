const _modv = "99";

var AImode=1;
var autotransfer=false;
var atrans_fact=false;
var foobuild=false;
var brokenbuild=false;
var _wpyall=true;
var _wpy=false;
var item_source=[];
var _foowaypt_1=false;
var playerKicker = [];

//TODO: customize fog render
var FOGRENDER = false;

const uptime = Date.now();
function readfi(){_qt = JSON.parse(Vars.dataDirectory.child('qt/ptsettings').readString());global._qt=_qt;return "[green]Finish reading ptsettings.json"}

var Cal2= require("script/Calendar");
const debug = require("script/debug");

var wpy_config=[];
var _qt={};
global.pt={
	"chk":true,
	"modv":_modv,
	vconfig:{"title":_qt.title2,"cnarc":cnarc,"modv":_modv,"key":_qt.pass},
	storeValue(f,g){_qt[g]=f;store_settings();},
	getValue(f){return _qt[f]},
	
	fullchat(k){_fullchat(k)},
	openCore(){_开核次数=0;autouserss = [0,Vars.state.map.name()]},
	openCore2(){_开核次数++},
	logfi(str){if(_qt.record_msg)Vars.dataDirectory.child("qt/logs/"+todayDate(false)+".txt").writeString("["+todayDate(true)+"] "+str+"\n",true)},
	adminlog(str){if(_qt.record_msg)Vars.dataDirectory.child("qt/adminlog.txt").writeString("\nPt-"+_modv+" ["+todayDate(true)+"] "+str+"\n",true)},
	traced(id,data){traced_list[id] = data},
	chktraced(id){return traced_list[id]},
	cmdlist(msg){_command_list.push(msg)},
	chkcmdlist(){return _command_list},
	
	cmd(a,b,c){return command(a,b,c)},
	active_marks(a){active_marks=a},
	
	pkick1(){return playerKicker},
	pkick2(a,b){playerKicker.splice(a,b)},
	parseqt(v){
		print("parseQT");
		_qt=v;global._qt=_qt;
		wpy_config=[Items.copper,Items.lead,Items.metaglass,Items.graphite,Items.titanium,Items.thorium,Items.silicon,Items.plastanium,Items.phaseFabric,Items.surgeAlloy];
		wpy_config=_qt.wpy_config.map(e=>Items[e]);
		store_settings();
	},
	sendChatMessageQueue(msg){
		sendChatMessageQueue(msg);
	},
	debug(e){debug(e)},
	
	_pted_player_list(e,f){if(e)_pted_player.push(e,f);return _pted_player},
	_ptPlayer:{},
	configTimes:0,
};
global.ptv={
	nowaddress:{"ip":"localhost","port":6567,"name":"144的个人服务器","chk":true},
}

const ModuleLoader = require("script/Module_loader");
const AntiGrief = global.pt0.qt_AntiGrief;

global.pt.Dialog_keybind={
	disableWorldProcessors(){Vars.state.rules.disableWorldProcessors=!Vars.state.rules.disableWorldProcessors;return Vars.state.rules.disableWorldProcessors},
	autotransfer(){autotransfer=!autotransfer;autotransfer_item=null;return autotransfer},
	atrans_fact(){atrans_fact=!atrans_fact;return atrans_fact},
	"brokenbuild":function(){brokenbuild=!brokenbuild;return brokenbuild},
	"foobuild":function(){foobuild=!foobuild;return foobuild},
	"mapdesc":function(){global.pt0.mapinfo.reload()},
	"powernodeFix":function(){powerNodeFix.fix()},
	"pan":function(){
		if(Vars.control.input instanceof DesktopInput){Vars.control.input.panning = true;}
			Core.camera.position.x=parseInt(active_marks[0])*8;
	Core.camera.position.y=parseInt(active_marks[1])*8;
	},
	"allmapinfo":global.pt0.map_popup,
	"blueprint_store":AntiGrief.menu,
	"wpy_ctrl":wpymenu,
	movementmode7(){mode7menu()},
	stealunit(){StealUnit.menu()},
	sos(){sendChatMessageQueue("[[Pt=E v"+_modv+"] <Gather> 集结点： ("+Math.floor(Vars.player.x/8)+","+Math.floor(Vars.player.y/8)+")")},
	"pmdialog":global.pt0.pm_dialog.main,
	
	"AutoBluePrintUse":global.pt0.AutoBluePrint.use,
	"AutoBluePrintGen":global.pt0.AutoBluePrint.gen,
};


const encrypt= global.pt0.qt_encrypt;
const pRecord = global.pt0.pRecord;
const cheat_ship= global.pt0.Cheat_Ship;
const wayptAI = global.pt0.wayptAI;
const cmd = global.pt0.command;
const StealUnit= global.pt0.stealunit;
const keybind = global.pt0.keybind;
const healthbar = global.pt0.healthbar;
const keybind2 = global.pt0.keybind_mobile;
const powerNodeFix = global.pt0.powerNodeFix;
var SideBarDialog = global.pt0.SideBarDialog;

var GAME_NOW=[];
var GAME_func={
	gen:function(){return Math.floor(Math.random()*9000+1000)},
	remove:function(e){
		var x = -1;
		GAME_NOW.forEach((a,i)=>{if(a.rm==e)x=i});
		GAME_NOW.splice(x,1);
		},
	chk_inrm:function(e,t){
		GAME_NOW.forEach(f=>{
			if((f.player=="*" || f.player.includes(e.id)) && t==f.type)return false;
			});
		return true;
	},
	pwn_ans:function(){
		var r = Math.floor(Math.random()*6);
		return [0,1,2,3,4,5,6,7,8,9].sort( () => .5 - Math.random()).slice(r,r+4);
	},
}

var _0x97 = [];
var _valid_msg=null;

function Num2parse(int2){
	int2=int2.toString();
	["０","１","２","３","４","５","６","７","８","９"].forEach((q,i)=>{
	int2=int2.replace(RegExp(i,"g"),q);
	});
	return int2;
}

function store_settings(){
	_qt.wpy_config = wpy_config.map(e=>(e.name.match(/-./)?e.name.replace(/-./,e.name.match(/-./)[0].substring(1).toUpperCase()):e.name));
	Vars.mods.scripts.runConsole("_qtglobal = "+ JSON.stringify(_qt));
	Vars.dataDirectory.child('qt/ptsettings').writeString(JSON.stringify(_qt, null, 2));
}
function get_minemode(type){
	if((_qt.minertype&Math.pow(2,type))==Math.pow(2,type)){_qt.minertype &= 63-Math.pow(2,type)}else{_qt.minertype|=Math.pow(2,type)};
	store_settings();
}

function mode7menu(){
	var table = new Table(Tex.whiteui.tint(5/16,9/16,5/16,0.5));
	table.add("[red][Pt=E v"+_modv+"][white]  搬运模式 | Foo Waypt");
	table.row();
	var _0x401 = new Table();
	_0x401.button(((_qt.language==0)?"[cyan]移动位置记录":"[cyan]移動位置記錄"),Styles.cleart,e=>{
		_foowaypt_1=true;
		wayptAI.wayptlist.push([0,Vars.player.tileX(),Vars.player.tileY()]);
	}).left().width(150).height(50);
	_0x401.button(((_qt.language==0)?"[cyan]移除物品":"[cyan]移除物品"),Styles.cleart,e=>{
		_foowaypt_1=true;
		wayptAI.wayptlist.push([2,Vars.player.tileX(),Vars.player.tileY(),]);
	}).left().width(150).height(50);
	table.add(_0x401).left;
	table.row();
	var _0x402 = new Table();
	_0x402.button(((_qt.language==0)?"[green]开始记录/清除":"[green]開始記錄/清除"),Styles.cleart,e=>{
		wayptAI.wayptlist=[];
		_foowaypt_1=true;
	}).left().width(150).height(50);
	_0x402.button(((_qt.language==0)?"[green]结束记录":"[green]結束記錄"),Styles.cleart,e=>{
		_foowaypt_1=false;
	}).left().width(150).height(50);
	table.add(_0x402).left;table.row();
	var _0x403 = new Table();
	//move    [0,x,y] 
	//drop    [1,x,y,build,item]
	//dispose [2,x,y]  
	//take    [3,x,y,build,item] 
	_0x403.button(((_qt.language==0)?"[yellow]显示节点":"[yellow]顯示節點"),Styles.cleart,e=>{
		let _0xd=0;
		let _0xe=["[cyan]"+((_qt.language==0)?("移动"):((_qt.language==1)?("移動"):("waypt"))),"[acid]"+((_qt.language==0)?("放下"):((_qt.language==1)?("放下"):("deposit"))),"[brown]"+((_qt.language==0)?("移除"):((_qt.language==1)?("移除"):("remove"))),"[violet]"+((_qt.language==0)?("拾取"):((_qt.language==1)?("拾取"):("withdraw")))];
		for (_0xd in wayptAI.wayptlist){
			Vars.ui.showLabel(_0xe[wayptAI.wayptlist[_0xd][0]],5,(wayptAI.wayptlist[_0xd][1]*8),(wayptAI.wayptlist[_0xd][2]*8));
		}
	}).left().width(150).height(50);
	_0x403.button("[yellow]教程 | Help",Styles.cleart,e=>{
		var table2 = new Table(Tex.button);
		table2.add("[red][Pt=E v"+_modv+"][white]  搬运模式 教程 | Foo Waypt");
		table2.row();
		table2.add("点击[green]开始记录[white] \n搬运时照常取/放 资源(点一次就可以)\n\n移动位置记录: 记录你所在的位置，并且前往\n移除物品:  移除目前在单位的资源 \n\n完成后点击[green]结束记录\n[white]\n提示: 搬运模式视窗可拖动").width(400);
		table2.row();
		table2.button("X",e=>{table2.remove()}).left().left();
		Core.scene.table().add(table2);
	}).left().width(150).height(50);
	table.add(_0x403).left;table.row();
	table.button("X",Styles.cleart,e=>{table.remove()}).height(50).width(50).left().left();
	var lastX,lastY;
	table.addListener(extend(InputListener,{
		touchDown(event,x,y,pointer,button){
			lastX=x;
			lastY=y;
			return true;
		},
		touchUp(event,x,y,pointer,button){
			table.x+=x-lastX;
			table.y+=y-lastY;
		}
	}));
	Core.scene.table().add(table);
}

var ItemSource_ALLCONFIG=[Items.copper,Items.lead,Items.metaglass,Items.graphite,Items.sand,Items.coal,Items.titanium,Items.thorium,Items.scrap,Items.silicon,Items.plastanium,Items.phaseFabric,Items.surgeAlloy,Items.sporePod,Items.blastCompound,Items.pyratite,Items.beryllium,Items.tungsten,Items.oxide,Items.carbide,Items.fissileMatter, Items.dormantCyst];
function wpyhandler(e){
if (wpy_config.includes(ItemSource_ALLCONFIG[e])){
	wpy_config.splice(wpy_config.indexOf(ItemSource_ALLCONFIG[e]), 1);
}else{
	wpy_config.push(ItemSource_ALLCONFIG[e])
}
store_settings();
}

function wpymenu(){
	var table = new Table(Tex.button);
	table.add("[red][Pt=E v"+_modv+"][white]  手操物品元 | Item Source");
	table.row();
	table.pane(cons(k=>{
		let _0x16 = new Table();
		ItemSource_ALLCONFIG.forEach((item,seq)=>{
			_0x16.check(item.emoji()+"  ",wpy_config.includes(item),e=>{wpyhandler(seq);});
			if((seq+1)%4==0){k.add(_0x16);k.row();_0x16 = new Table()};
		});
		k.add(_0x16);
	}));
	table.row();
	var _0x17 = new Table();
	_0x17.check(((_qt.language==0)?"开关  ":"開關  "),_wpy,e=>{_wpy=!_wpy});
	_0x17.check("所有物品元",_wpyall,e=>{_wpyall=!_wpyall});
	table.add(_0x17);
	table.row();
	_0x17 = new Table();
	_0x17.button("移除所有",e=>{item_source=[];}).width(100);
	_0x17.button("增加地址",e=>{
		item_source.push(found.build);
		Vars.ui.announce(((_qt.language==0)?("成功加入清单"):((_qt.language==1)?("已加入清單"):("Item Added Successfully"))))
		}).width(100);
	_0x17.button("移除地址",e=>{
		if(item_source.includes(found.build)){
			item_source.splice(item_source.indexOf(found.build), 1);
			Vars.ui.announce(((_qt.language==0)?("成功移除清单"):((_qt.language==1)?("項目已移除"):("Item Removed Successfully"))))
		}else{
			Vars.ui.announce(((_qt.language==0)?("错误"):((_qt.language==1)?("錯誤"):("Error"))))
		}
		}).width(100);
	table.add(_0x17);
	table.row();
	table.button("X",e=>{table.remove()}).left().update(e=>{e.setText(" X [gray]"+item_source.length)});
	Core.scene.table().add(table);
}

function email_popup(){
	var table = new Table(Tex.button);
	table.add("[red][Pt=E v"+_modv+"][white]  [sky]查看留言");
	table.row();
	table.pane(cons(k=>{
		星空_data=JSON.parse(Vars.dataDirectory.child("qt/starsky").readString());
		if(星空_data.msg)
		星空_data.msg.forEach(e=>{
			k.add(e.name).width(250).left();
			k.add(e.msg[0]+" ").width(500).left();
			k.add("[gray]"+e.time.split("GMT")[0]).width(300).left();
			k.button(Icon.paste,f=>{Core.app.setClipboardText(JSON.stringify(e))});
			k.row();
		});
	}));
	table.row();
	var t2=new Table();
	t2.button("[scarlet]X",e=>{table.remove()}).width(50).left();
	t2.button(_qt.language==0?"[red]移除记录":"[red]移除記錄",e=>{
		星空_data=JSON.parse(Vars.dataDirectory.child("qt/starsky").readString());
		星空_data.msg=[];
		Vars.dataDirectory.child("qt/starsky").writeString(JSON.stringify(星空_data, null, 2));
	}).width(100).left();
	table.add(t2);
	Core.scene.table().add(table);
}

function js(){
	var t2 = new Table(Tex.whiteui.tint(0,0,2/16,0.35));
	var t4 = new Table(Tex.whiteui.tint(6/16,0,0,0.35));
	var f2,jsmode=true,onchat=true,jsruntime=0;
	t4.labelWrap("[red][Pt=E v"+_modv+"][white]  [yellow]JS 控制台").fillX().minWidth(400).fillY().left();
	t4.button("X",Styles.cleart,e=>{t2.remove();}).width(35).height(35).right();
	t2.add(t4).row();
	var lastX,lastY;
	t4.addListener(extend(InputListener,{
		touchDown(event,x,y,pointer,button){
			lastX=x;lastY=y;return true;
		},
		touchUp(event,x,y,pointer,button){
			t2.x+=x-lastX;t2.y+=y-lastY;
		}
	}));
	
	f2 = t2.add(new TextArea(""));
	f2.left().height(400).fillX().row();
	var t3 = new Table();
	t3.button("切换",Styles.cleart,e=>{
		jsmode=!jsmode;
		}).update(q=>{q.setText("js模式: \n"+(jsmode?"[#ffdfdf]PT":"[#dfffdf]Console"))}).width(150).height(45).left();
	t3.button("onchat",Styles.cleart,e=>{
		onchat=!onchat;
		}).update(q=>{q.setText("代码结果显示: \n"+(onchat?"[#dfffdf]个人Chatfrag":"[#dfdfdf]公屏"))}).width(150).height(45).left();
	t3.button("[#ffffdf]Run",Styles.cleart,e=>{
		jsruntime=Date.now();
		try{
			if(jsmode){
				var result = eval(f2.get().getText())
			}else{
				var result = Vars.mods.scripts.runConsole(f2.get().getText())
			}
		}catch(error){var result = error+" (console.js#"+error.lineNumber+")"};
		jsruntime=Date.now() - jsruntime;
		
		if(onchat)
			Vars.ui.chatfrag.addMessage("> "+result+"[sky] "+jsruntime+"ms");
		else{
			sendChatMessageQueue("< JS： "+f2.get().getText());
			sendChatMessageQueue("> "+result+"[sky] "+jsruntime+"ms");
		}
		print("[PT] > "+result+"[sky] "+jsruntime+"ms")
	}).width(150).height(45).left();
	t2.add(t3).row();
	Core.scene.table().add(t2);
}

function popup_change_details(seq,k){
	var pt2mode=["只限玩家",((_qt.language==0)?"敌人+玩家":"敵人+玩家"),"只限炮台","以上所有",((_qt.language==0)?"关闭":"關閉")];
    var pt1mode=["简中","繁中","EN"];
	var pt3mode=["","挖矿[gray] mono","建筑[gray] poly","建筑+[gray] gamma","搬运[gray] <foo>","无此模式","无此模式","搬运","",""];
	k.clear();
	var left=new Table(),right = new Table();
	switch(seq){
	case 0:
		var _0x420 = new Table(Tex.whiteui.tint(4/16,0,0,0.8));
		_0x420.add("[#dfdfff]@"+Vars.player.plainName()+"，"+getDateString()).width(250).padRight(24).left();
		_0x420.button("[yellow] JS",Styles.cleart,e=>{js()}).fillY().left().padRight(24).width(80);
		_0x420.button("[#bfbfff]",Styles.cleart,e=>{keybind2.load()}).fillY().right().width(80);
		k.add(_0x420).fillX().row();
		k.add(keybind2._onload()).row();
	break;
	case 2:
		left.add(_qt.language==0?"移除显示":"移除顯示").color(Color(1,14/16,1)).colspan(4).pad(10).padBottom(4).row();
        left.image().color(Color(1,14/16,1)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();
		left.check(_qt.language==0?"移除子弹":"移除子彈",_qt.removeBullet>0,e=>{
		_qt.removeBullet=!_qt.removeBullet;store_settings();
		}).left().row();
		left.check(_qt.language==0?"移除残骸":"移除殘骸",_qt.removeDecal>0,e=>{
		_qt.removeDecal=!_qt.removeDecal;store_settings();
		}).left().row();
		left.check(_qt.language==0?"移除单位":"移除單位",_qt.disableUnit>0,e=>{
		_qt.disableUnit=!_qt.disableUnit;store_settings();
		}).left().row();

		left.add(_qt.language==0?"玩家资讯":"玩家資訊").color(Color(1,14/16,1)).colspan(4).pad(10).padBottom(4).row();
        left.image().color(Color(1,14/16,1)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();
		left.check(_qt.language==0?"显示矿种":"顯示礦種",_qt.ore_show,e=>{_qt.ore_show=!_qt.ore_show;store_settings();}).left().row();
		left.check(_qt.language==0?"显示特殊建筑":"顯示特殊建築",_qt.map_spec_build,e=>{_qt.map_spec_build=!_qt.map_spec_build;store_settings();}).left().row();
		left.check(_qt.language==0?"心灵探测器":"心靈探測器",_qt.playercursor>0,e=>{_qt.playercursor=!_qt.playercursor;store_settings();}).left().row();
		left.check("拍一拍提醒",_qt.p1palert,e=>{_qt.p1palert=!_qt.p1palert;store_settings();}).left().row();
	
		right.add(_qt.language==0?"重置源码 (重启生效)":"重置源碼 (重啟生效)").color(Color(1,14/16,1)).colspan(4).pad(10).padBottom(4).row();
        right.image().color(Color(1,14/16,1)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();
		right.check(_qt.language==0?"血量显示":"血量顯示",_qt.health_bar,e=>{_qt.health_bar=!_qt.health_bar;store_settings();}).left().row();
		right.check(_qt.language==0?"Menu 多选菜单":"Menu 多選菜單",_qt.MenuCall,e=>{_qt.MenuCall=!_qt.MenuCall;store_settings();}).left().row();
		right.check(_qt.language==0?"Toast 弹窗":"Toast 彈窗",_qt.InfoToastCall,e=>{_qt.InfoToastCall=!_qt.InfoToastCall;store_settings();}).left().row();
		right.check(_qt.language==0?"Info 资讯框":"Info 資訊框",_qt.InfoMessageCall,e=>{_qt.InfoMessageCall=!_qt.InfoMessageCall;store_settings();}).left().row();
		right.check(_qt.language==0?"Chat 聊天":"Chat 聊天",_qt.SendMessageCall,e=>{_qt.SendMessageCall=!_qt.SendMessageCall;store_settings();}).left().row();
		right.button(_qt.language==0?"自定义玩家清单":"自定義玩家清單",f=>{
			player_frag_combo()
		}).width(200).color(Color(14/16,1,14/16)).height(35).row();
		
		right.add(_qt.language==0?"范围显示":"範圍顯示").color(Color(1,14/16,1)).colspan(4).pad(10).padBottom(4).row();
        right.image().color(Color(1,14/16,1)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();	
		right.check(_qt.language==0?"单位攻击范围":"單位攻擊範圍",_qt.unitrange,e=>{_qt.unitrange=!_qt.unitrange;store_settings();}).left().row();
		right.check(_qt.language==0?"对空炮台范围":"對空炮臺範圍",_qt.air_range,e=>{_qt.air_range=!_qt.air_range;store_settings();}).left().row();
		right.check(_qt.language==0?"对地炮台范围":"對地炮臺範圍",_qt.ground_range,e=>{_qt.ground_range=!_qt.ground_range;store_settings();}).left().row();		
		right.check(_qt.language==0?"加速范围":"加速範圍",_qt.boost_range,e=>{_qt.boost_range=!_qt.boost_range;store_settings();}).left().row();
		right.check(_qt.language==0?"修复范围":"修復範圍",_qt.fix_range,e=>{_qt.fix_range=!_qt.fix_range;store_settings();}).left().row();
		right.check(_qt.language==0?"刷怪点范围":"刷怪點",_qt.dropzone,e=>{_qt.dropzone=!_qt.dropzone;store_settings();}).left().row();
	break;
	case 1:
		left.add(_qt.language==0?"服务器":"伺服器").color(Color(14/16,1,14/16)).colspan(4).pad(10).padBottom(4).row();
        left.image().color(Color(14/16,1,14/16)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();
		left.check(_qt.language==0?"玩家进出":"玩家進出",_qt.player_in_out,e=>{_qt.player_in_out=!_qt.player_in_out;store_settings();}).left().row();
		left.check("核心摧毁",_qt.core_tips,e=>{_qt.core_tips=!_qt.core_tips;store_settings();}).left().row();
		left.check("指令",_qt.command,e=>{
			_qt.command=!_qt.command;
			store_settings();
			if(_qt.command)sendChatMessageQueue("Pt-"+_modv+" [sky]聊天中输入'_help'查看指令。")
		}).left().row();
		left.check(_qt.language==0?"讯息板聊天":"訊息板聊天",_qt.msg_talk,e=>{_qt.msg_talk=!_qt.msg_talk;store_settings();}).left().row();
		left.check(_qt.language==0?"延迟说话":"延遲說話",_qt.delay_chat,e=>{_qt.delay_chat=!_qt.delay_chat;store_settings();}).left().row();
		left.check(_qt.language==0?"跟随投票":"跟隨投票",_qt.auto_vote,e=>{_qt.auto_vote=!_qt.auto_vote;store_settings();}).left().row();
		left.check(_qt.language==0?"自动重进":"自動重進",_qt.auto_rejoin,e=>{_qt.auto_rejoin=!_qt.auto_rejoin;store_settings()}).left().row();
	
		right.add(_qt.language==0?"通讯":"通訊").color(Color(14/16,1,14/16)).colspan(4).pad(10).padBottom(4).row();
        right.image().color(Color(14/16,1,14/16)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();	
		right.check("加密pm",_qt.pm_encrypt>=0,e=>{_qt.pm_encrypt=(_qt.pm_encrypt<0?0:-1);store_settings();}).left().row();
		//right.check(_qt.language==0?"蓝图配对":"藍圖配對",_qt.blueprint_pd,e=>{_qt.blueprint_pd=!_qt.blueprint_pd;}).left().row();	
		right.button(_qt.language==0?"检查留言":"檢查留言",e=>{email_popup()}).width(200).color(Color(14/16,1,14/16)).height(35).row();
		right.button(_qt.language==0?"自定义拍一拍":"自定義拍一拍",e=>{
			Vars.ui.showTextInput(_qt.language==0?"自定义拍一拍":"自定義拍一拍","@player代替玩家名称",100,_qt.p1p_data,e=>{
				_qt.p1p_data = e;store_settings();
			});
		}).width(200).color(Color(14/16,1,14/16)).height(35).row();
	
		right.add("其他").color(Color(14/16,1,14/16)).colspan(4).pad(10).padBottom(4).row();
        right.image().color(Color(14/16,1,14/16)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();		
		right.check("mod語言: 繁中",_qt.language,e=>{_qt.language=!_qt.language;store_settings();}).left().row();		
		right.check(_qt.language==0?"主页菜单":"主頁菜單",_qt.mainmenu_menu,e=>{_qt.mainmenu_menu=!_qt.mainmenu_menu;store_settings();}).left().row();
		right.check(_qt.language==0?"蓝图快照":"藍圖快照",_qt.schCapture,e=>{_qt.schCapture=!_qt.schCapture;Vars.ui.chatfrag.addMessage("[Pt=E] 每1分钟记录一次蓝图快照 防内鬼\n重启游戏后删除")}).left().row();

		left.add(_qt.language==0?"快捷按键":"快捷按键").color(Color(14/16,1,14/16)).colspan(4).pad(10).padBottom(4).row();
        left.image().color(Color(14/16,1,14/16)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();
		if(Vars.control.input instanceof DesktopInput)
			left.button(_qt.language==0?"电脑版设置":"電腦版設置",e=>{keybind.load()}).width(200).color(Color(14/16,1,14/16)).height(35).row();
		left.check(_qt.language==0?"电脑快捷键":"電腦快捷鍵",_qt.computer_readKeyCode,e=>{_qt.computer_readKeyCode=!_qt.computer_readKeyCode;}).left().row();
	break;
	case 3:
		left.add(_qt.language==0?"系统作弊":"系統作弊").color(Color.orange).colspan(4).pad(10).padBottom(4).row();
        left.image().color(Color.orange).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();			
		left.check("[#ff9999]光影",Vars.enableLight,e=>{Vars.enableLight=!Vars.enableLight}).left().row();
		left.check(_qt.language==0?"[#ff9999]阴影":"[#ff9999]陰影",Vars.enableDarkness,e=>{Vars.enableDarkness=!Vars.enableDarkness}).left().row();
		left.check(_qt.language==0?"[#ff9999]迷雾":"[#ff9999]迷霧",FOGRENDER,e=>{FOGRENDER=!FOGRENDER;}).left().row();
		left.check(_qt.language==0?"[#ff9999]禁止世界处理器":"[#ff9999]禁用世界處理器",Vars.state.rules.disableWorldProcessors,e=>{Vars.state.rules.disableWorldProcessors=!Vars.state.rules.disableWorldProcessors}).left().row();
		left.check(_qt.language==0?"解除蓝图限制":"解除藍圖限制",_qt.remove_blueprint,e=>{_qt.remove_blueprint=!_qt.remove_blueprint;store_settings();}).left().row();
		left.check(_qt.language==0?"控制单位":"控制單位",Vars.state.rules.possessionAllowed,e=>{Vars.state.rules.possessionAllowed=!Vars.state.rules.possessionAllowed}).left().row();
		
		left.add(_qt.language==0?"自动搬运":"自動搬運").color(Color.orange).colspan(4).pad(10).padBottom(4).row();
		left.image().color(Color.orange).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();	
		left.check("[#ff9999]"+(_qt.language==0?"一键装弹":"一鍵裝彈"),autotransfer,e=>{autotransfer=!autotransfer;autotransfer_item=null;}).left().row();
		left.check(_qt.language==0?"物品获取: 仓库":"物品獲取: 倉庫",_qt.atrans_vault,e=>{_qt.atrans_vault=!_qt.atrans_vault}).left().row();
		left.check("[#ff9999]"+(_qt.language==0?"自动搬运: 工厂":"自動搬運: 工廠"),atrans_fact,e=>{atrans_fact=!atrans_fact}).left().row();
		left.check(_qt.language==0?"放到 工厂":"放到 工廠",_qt.atrans_fact,e=>{_qt.atrans_fact=!_qt.atrans_fact}).left().row();
		
		
		right.add(_qt.language==0?"模组作弊":"模組作弊").color(Color.orange).colspan(4).pad(10).padBottom(4).row();
        right.image().color(Color.orange).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();	
		right.check(_qt.language==0?"pvp拆建筑":"pvp拆建築",_qt.pvp_destruct,e=>{_qt.pvp_destruct=!_qt.pvp_destruct;store_settings()}).left().row();
		right.check(_qt.language==0?"船转动速度":"船轉動速度",_qt.shipRotateSpeed,e=>{_qt.shipRotateSpeed=!_qt.shipRotateSpeed;store_settings()}).left().row();
		right.check(_qt.language==0?"显示其他队伍建筑":"顯示其他隊伍建築",_qt.otherTeamBuild,e=>{_qt.otherTeamBuild=!_qt.otherTeamBuild;store_settings()}).left().row();
		var _0x406 = new Table();
		_0x406.check(_qt.language==0?"RTS自动撤离":"RTS自動撤離",_qt.RTScommand,q=>{_qt.RTScommand=!_qt.RTScommand;store_settings()});
		_0x406.add("").update(e=>{e.text="   "+_qt.RTShealth+"%"});
		right.add(_0x406).row();
		right.button(_qt.language==0?"地蓝记录":"地藍記錄",e=>{global.pt0.AutoBluePrint.gen()}).width(200).color(Color(14/16,1,14/16)).height(35).row();
		right.button(_qt.language==0?"地蓝使用":"地藍使用",e=>{global.pt0.AutoBluePrint.use()}).width(200).color(Color(14/16,1,14/16)).height(35).row();
		right.button(_qt.language==0?"物品元控制":"物品元控制",e=>{wpymenu()}).width(200).color(Color(14/16,1,14/16)).height(35).row();
		right.check(_qt.language==0?"全自动地蓝":"全自動地藍",_qt.autotest,e=>{_qt.autotest=!_qt.autotest;store_settings()}).left().row();
		right.check(_qt.language==0?"自动地蓝 忽略其他建筑":"自動地藍 忽略其他建築",_qt.schignore,e=>{_qt.schignore=!_qt.schignore;store_settings()}).left().row();
		
		
		right.slider​(0,100,1,_qt.RTShealth,e=>{_qt.RTShealth = e;store_settings()}).width(200).row();
	break;
	case 4:
		var _0x412 = new Table();
		_0x412.slider​(1,5,1,(AImode<8?AImode:5),e=>{AImode = e;}).width(200);
		_0x412.add("").update(e=>{e.text=(AImode<8?pt3mode[AImode]:"")+"  模式: "+AImode;}).row();
		k.add(_0x412).row();
		var _0x404 = new Table();
		_0x404.check("  "+((_qt.language==0)?"废料":"廢料"),(_qt.minertype&4)==4,e=>{get_minemode(2)}).left();
		_0x404.check("  沙  ",(_qt.minertype&1)==1,e=>{get_minemode(0)}).left();
		_0x404.check("  碳",(_qt.minertype&2)==2,e=>{get_minemode(1)}).left().row();

		_0x404.check("  "+((_qt.language==0)?"铜  ":"銅  "),(_qt.minertype&16)==16,e=>{get_minemode(4)}).left();
		_0x404.check("  "+((_qt.language==0)?"铅  ":"鉛  "),(_qt.minertype&32)==32,e=>{get_minemode(5)}).left();		
		_0x404.check("  "+((_qt.language==0)?"钛  ":"鈦  "),(_qt.minertype&8)==8,e=>{get_minemode(3)}).left();
		_0x404.check("  "+((_qt.language==0)?"铍  ":"鈹  "),(_qt.minertype&64)==64,e=>{get_minemode(6)}).left();
		k.add(_0x404).row();
		
		left.check(((_qt.language==0)?"挖矿(炮台范围)":"挖礦(炮臺範圍)"),_qt.escturret,e=>{_qt.escturret=!_qt.escturret;store_settings();}).left().row();
		right.check	(_qt.language==0?"[#ff9999]修复破坏":"[#ff9999]修復破壞",brokenbuild,e=>{brokenbuild=!brokenbuild}).left().row();
		right.check(_qt.language==0?"[#ff9999]foo建筑":"[#ff9999]foo建築",foobuild,e=>{foobuild=!foobuild}).left().row();
	break;
	case 5:
		left.check(_qt.language==0?"显示隐藏功能":"顯示隱藏功能",_qt.hidden_func,e=>{_qt.hidden_func=!_qt.hidden_func;store_settings();}).left();
		left.row();
		left.button(_qt.language==0?"恢复预设":"[scarlet]恢復預設",e=>{
			Vars.ui.showConfirm("Pt=E [scarlet]重置全部设置","点击确定，清除[red]所有[]设置",()=>{
			_qt={};global._qt=_qt;store_settings();Vars.ui.chatfrag.addMessage("请重新启动游戏");
			});
			}).left().width(200);
		left.row();
		
		if(_qt.hidden_func){
		right.button(_qt.language==0?"换领所有资源":"換領所有資源",e=>{
			for (let ki=0;ki<10;ki++){Call.menuChoose(Vars.player, 4, ki)}
		}).left().width(180);
		right.row();
		var _0x411 = new Table();
		_0x411.add(((_qt.language==0)?"修复破坏队列":"修復破壞隊列"));
		_0x411.field(_qt.brokenbuildmax,e=>{_qt.brokenbuildmax=parseFloat(e);store_settings()}).left().width(100);
		right.add(_0x411).left();
		right.row();
		var _0x402 = new Table();
		_0x402.add(((_qt.language==0)?"自动装弹间距":"自動裝彈間距"));
		_0x402.field(_qt.autotakedur,e=>{_qt.autotakedur=parseFloat(e);wayptAI.zero();store_settings();}).left().width(100);
		right.add(_0x402).left();
		right.row();
		}
	break;
	case 6:
		left.add("聊天").color(Color(14/16,14/16,1)).colspan(4).pad(10).padBottom(4).row();
        left.image().color(Color(14/16,14/16,1)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();
		left.check(_qt.language==0?"管理指令":"管理指令",_qt.admin_cmd,e=>{_qt.admin_cmd=!_qt.admin_cmd;store_settings();}).left().row();
		right.button("[#ffffaa]查LOG",e=>{global.pt0.qtlog.allFI()}).width(200).color(Color(14/16,1,14/16)).height(35).row();
		right.check(_qt.language==0?"[#ffffbb]记录聊天":"[#ffffbb]記錄聊天",_qt.record_msg,e=>{_qt.record_msg=!_qt.record_msg;store_settings();}).left().row();
		left.check(_qt.language==0?"自动解禁言":"自動解禁言",_qt.msg_remove_mute,e=>{_qt.msg_remove_mute=!_qt.msg_remove_mute;store_settings()}).left().row();

		left.add("伺服器").color(Color(14/16,14/16,1)).colspan(4).pad(10).padBottom(4).row();
		left.image().color(Color(14/16,14/16,1)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();
		left.check(_qt.language==0?"自动踢":"自動踢",_qt.auto_kick,e=>{_qt.auto_kick=!_qt.auto_kick;store_settings();}).left().row();
		left.check(_qt.language==0?"检查ip":"檢查ip",_qt.trace_remove,e=>{_qt.trace_remove=!_qt.trace_remove;store_settings();}).left().row();
		right.button(_qt.language==0?"mod自定义头衔":"mod自定義頭銜",e=>{
			Vars.ui.showTextInput(_qt.language==0?"mod自定义头衔":"mod自定義頭銜","",100,_qt.title2,e=>{
				_qt.title2 = e;store_settings();
			});
		}).width(200).color(Color(14/16,14/16,1)).height(35).row();

		right.check("quickassist 控制",_qt.quickassist,e=>{_qt.quickassist=!_qt.quickassist;if(_qt.quickassist)AS_unit = Vars.player;Vars.ui.chatfrag.addMessage("[gold]JS : [white]AS_unit = Vars.player")}).left().row();
		right.check("quickassist cursor",_qt.quickassist_cursor,e=>{_qt.quickassist_cursor=!_qt.quickassist_cursor;store_settings();}).left().row();
		
		right.add("Pt-II").color(Color(14/16,14/16,1)).colspan(4).pad(10).padBottom(4).row();
		right.image().color(Color(14/16,14/16,1)).fillX().height(3).pad(6).colspan(4).padTop(0).padBottom(10).width(200).row();
		right.button("ptII 换uuid",e=>{global.pt2.changeuuid()}).width(200).color(Color(14/16,14/16,1)).height(35).row();
		right.button("原版 换uuid",e=>{global.uuid2.main()}).width(200).color(Color(14/16,14/16,1)).height(35).row();
		right.button("搞破坏",e=>{global.uuid2.pohuai()}).width(200).color(Color(14/16,14/16,1)).height(35).row();
		right.check("旋转",global.uuid2.pohuai2.r,e=>{global.uuid2.pohuai2.r=!global.uuid2.pohuai2.r}).left().row();
		right.check("桥",global.uuid2.pohuai2.b,e=>{global.uuid2.pohuai2.b=!global.uuid2.pohuai2.b}).left().row();
		right.check("装卸/分类",global.uuid2.pohuai2.c,e=>{global.uuid2.pohuai2.c=!global.uuid2.pohuai2.c}).left().row();
		right.check("逻辑",global.uuid2.pohuai2.c3,e=>{global.uuid2.pohuai2.c3=!global.uuid2.pohuai2.c3}).left().row();
	break;
	};
	var _0x405 = new Table();
	_0x405.add(left).top();
	_0x405.add("[clear].").width(75);
	_0x405.add(right).top();
	k.add(_0x405);
}



function popup_change_title(table,seq){
	table.forEach((e,i)=>{
		if(i==seq){
			e.get().setText(e.get().text.toString().replace(/\[#7f7f7f]/g,"[#ffffff]"));
			e.get().checked = true;
		}else{
			e.get().setText(e.get().text.toString().replace(/\[#ffffff]/g,"[#7f7f7f]"));
			e.get().checked = false;
		}
	});
}

function getDateString(){var d = new Date();
return (d.getHours()<2||d.getHours()>23?"午夜好  [#aaaaff]还没睡呢?[white]":(d.getHours()<7?"清晨好  [#aaaaff]这么早醒?[white]":(d.getHours()<12?"早安  [#aaaaff]吃早饭了没?[white]":(d.getHours()<14?"午安  [#aaaaff]午安好(doge)[white]":(d.getHours()<18?"下午好  [#aaaaff]:)":"晚安  [#aaaaff]做个好梦吧![white]")))))
}

function popup_settings(){
	var table = new Table(Tex.whiteui.tint(1/16,0,1/16,0.8));
	table.margin(8,8,8,8);
	var list=[];
	var table_pan=null;
	table.add("[red][Pt=E v"+_modv+"]"+(_qt.language==0?"设置     [#dfdfff]持续完善中，如有问题/建议  qq 340765776":"設置     [#dfdfff]持續完善中，如有問題/建議  qq 340765776")).row();
	var t1=new Table();
	t1.row();
	list.push(t1.button("[gold]\n[#ffffff]快速指令",Styles.flatTogglet,e=>{popup_change_title(list,0);popup_change_details(0,table_pan)}).color(Color.gold).width(80));
	list.push(t1.button(_qt.language==0?"[acid]\n[#7f7f7f]模组设置":"[acid]\n[#7f7f7f]模組設置",Styles.flatTogglet,e=>{popup_change_title(list,1);popup_change_details(1,table_pan)}).color(Color.acid).width(80));
	list.push(t1.button(_qt.language==0?"[purple]\n[#7f7f7f]显示":"[purple]\n[#7f7f7f]顯示",Styles.flatTogglet,e=>{popup_change_title(list,2);popup_change_details(2,table_pan)}).color(Color.purple).width(80));
	list.push(t1.button("[orange]\n[#7f7f7f]作弊功能",Styles.flatTogglet,e=>{popup_change_title(list,3);popup_change_details(3,table_pan)}).color(Color.orange).width(80));
	list.push(t1.button(_qt.language==0?"[blue]\n[#7f7f7f]挂机设置":"[blue]\n[#7f7f7f]挂機設置",Styles.flatTogglet,e=>{popup_change_title(list,4);popup_change_details(4,table_pan)}).color(Color.blue).width(80));
	list.push(t1.button(_qt.language==0?"[white]⚠\n[#7f7f7f]隐藏设置":"[white]⚠\n[#7f7f7f]隱藏設置",Styles.flatTogglet,e=>{popup_change_title(list,5);popup_change_details(5,table_pan)}).color(Color.white).width(80));
	if(_qt.admin_menu || Date.now() <1688140800000)list.push(t1.button("[#bfbfff]\n[#7f7f7f]管理指令",Styles.flatTogglet,e=>{popup_change_title(list,6);popup_change_details(6,table_pan)}).color(Color(10/16,10/16,1)).width(80));
	t1.button("[scarlet]\n关闭",Styles.flatTogglet,e=>table.remove()).color(Color.red).width(80);
	table.add(t1).padTop(8).padBottom(8).row();
	table.pane(cons(k=>{table_pan=k}));
	popup_change_title(list,0);
	popup_change_details(0,table_pan);
	Core.scene.table().add(table);
}


Events.on(EventType.ClientPreConnectEvent, cons(e=>{
	global.ptv.nowaddress={"ip":e.host.address,"port":e.host.port,"desc":e.host.description,"name":e.host.name,"chk":false};
	print(JSON.stringify(global.ptv.nowaddress));
}));

function uptimechk(t){
var time=[[60,"秒"],[60,"分"],[24,"时"],[1e10,"日"]];
var diff = [Math.round((new Date().getTime() - t) / 1000)];
time.forEach(e=>{
	if (diff[diff.length-1]>e[0]){
		diff.push(Math.floor(diff[diff.length-1]/e[0]));
	}else{diff.push(0)}
	});
diff=diff.filter(e=>e>0).map((f,i)=>f=f%time[i][0]+time[i][1]).reverse();
return diff.join(" ");
}

function timechk(t){
var time=[[60,"秒"],[60,"分钟"],[24,"小时"],[7,"日"],[4,"周"],[13,"月"],[1e10,"年"]];
var i = 0;
var diff = Math.round((new Date().getTime() - t.getTime()) / 1000);
for (i in time){
	if (diff>time[i][0]){
		diff = diff/time[i][0];
	}else{
		break;
	}
}
return Math.floor(diff)+" "+time[i][1]+"前";
}

var _开核次数=0;

var active_marks=[];

function todayDate(e){
	var d = new Date();
	var k = d.getFullYear()+"-"+(d.getMonth()+1).toString().padStart(2,"0")+"-"+(d.getDate()).toString().padStart(2,"0");
	if(e)k+=" "+d.getHours().toString().padStart(2,"0")+":"+d.getMinutes().toString().padStart(2,"0")+":"+d.getSeconds().toString().padStart(2,"0");
	return k;
}

function player_frag_combo_draw1(table,num,seq){
	_qt.player_frag_seq=seq;store_settings();
	table.clearChildren();
	seq.forEach(num2=>{
		if((num2&2)!=0)table.button("",f=>{seq.splice(seq.indexOf(2),1);player_frag_combo_draw1(table,num^2,seq);}).color(Color.orange).height(50);
		if((num2&4)!=0)table.button("144_",Styles.cleart,f=>{seq.splice(seq.indexOf(4),1);player_frag_combo_draw1(table,num^4,seq);}).color(Color.teal).height(50).width(170);
		if((num2&8)!=0)table.button("拍一拍",f=>{seq.splice(seq.indexOf(8),1);player_frag_combo_draw1(table,num^8,seq);}).color(Color.slate).height(50).width(80);
		if((num2&16)!=0)table.button("[red]踢",f=>{seq.splice(seq.indexOf(16),1);player_frag_combo_draw1(table,num^16,seq);}).color(Color.scarlet).height(50).width(50);
		if((num2&32)!=0)table.button("[yellow]ID",f=>{seq.splice(seq.indexOf(32),1);player_frag_combo_draw1(table,num^32,seq);}).color(Color.yellow).height(50).width(50);
		if((num2&512)!=0)table.button("[red]test",f=>{seq.splice(seq.indexOf(512),1);player_frag_combo_draw1(table,num^512,seq);}).color(Color.purple).height(50).width(50);
		if((num2&1024)!=0)table.button("[red]禁言",f=>{seq.splice(seq.indexOf(1024),1);player_frag_combo_draw1(table,num^1024,seq);}).color(Color.royal).height(50).width(50);
		if((num2&64)!=0)table.button("[green]pm",f=>{seq.splice(seq.indexOf(64),1);player_frag_combo_draw1(table,num^64,seq);}).color(Color.green).height(50).width(50);
		if((num2&128)!=0)table.button("[yellow]复制动作",f=>{seq.splice(seq.indexOf(128),1);player_frag_combo_draw1(table,num^128,seq);}).color(Color.olive).height(50).width(50);
		if((num2&256)!=0)table.button("[yellow]查询ip",f=>{seq.splice(seq.indexOf(256),1);player_frag_combo_draw1(table,num^256,seq);}).color(Color.sky).height(50).width(50);
		if((num2&2048)!=0)table.button("v144",f=>{seq.splice(seq.indexOf(2048),1);player_frag_combo_draw1(table,num^2048,seq);}).color(Color.gold).height(50);
		if((num2&4096)!=0)table.button("[green]拷贝对话",f=>{seq.splice(seq.indexOf(4096),1);player_frag_combo_draw1(table,num^4096,seq);}).color(Color.gold).height(50);
		if((num2&8192)!=0)table.button("[yellow]额外操作",f=>{seq.splice(seq.indexOf(8192),1);player_frag_combo_draw1(table,num^8192,seq);}).color(Color.gold).height(50);
	});
	table.row();
	table.add("设置");
	table.row();
	if((num&2)==0)table.button("(检视)",f=>{seq.push(2);player_frag_combo_draw1(table,num|=2,seq);}).color(Color.orange).height(50).width(100);
	if((num&4)==0)table.button(" 名称 (拷贝)",f=>{seq.push(4);player_frag_combo_draw1(table,num|=4,seq);}).color(Color.teal).height(50).width(100);
	if((num&8)==0)table.button("拍一拍",f=>{seq.push(8);player_frag_combo_draw1(table,num|=8,seq);}).color(Color.slate).height(50).width(100);
	if((num&16)==0)table.button("踢",f=>{seq.push(16);player_frag_combo_draw1(table,num|=16,seq);}).color(Color.scarlet).height(50).width(100);
	if((num&512)==0)table.button("Test",f=>{seq.push(512);player_frag_combo_draw1(table,num|=512,seq);}).color(Color.purple).height(50).width(100);
	if((num&1024)==0)table.button("禁言",f=>{seq.push(1024);player_frag_combo_draw1(table,num|=1024,seq);}).color(Color.royal).height(50).width(100);
	table.row();
	if((num&32)==0)table.button("拷贝ID",f=>{seq.push(32);player_frag_combo_draw1(table,num|=32,seq);}).color(Color.yellow).height(50).width(100);
	if((num&64)==0)table.button("PM 信息板单对单聊天",f=>{seq.push(64);player_frag_combo_draw1(table,num|=64,seq);}).color(Color.green).height(50).width(100);
	if((num&128)==0)table.button("复制动作",f=>{seq.push(128);player_frag_combo_draw1(table,num|=128,seq);}).color(Color.olive).height(50).width(100);
	if((num&256)==0)table.button("管理",f=>{seq.push(256);player_frag_combo_draw1(table,num|=256,seq);}).color(Color.sky).height(50).width(100);
	if((num&2048)==0)table.button("v144",f=>{seq.push(2048);player_frag_combo_draw1(table,num|=2048,seq);}).color(Color.gold).height(50).width(100);
	if((num&4096)==0)table.button("拷贝对话内容",f=>{seq.push(4096);player_frag_combo_draw1(table,num|=4096,seq);}).color(Color.gold).height(50).width(100);
	if((num&8192)==0)table.button("额外操作",f=>{seq.push(8192);player_frag_combo_draw1(table,num|=8192,seq);}).color(Color.gold).height(50).width(100);
}
function player_frag_combo(){
	var table=new Table(Tex.pane);
	table.labelWrap("玩家清单 -- 自定义设置").left().width(800);
	table.row();
	var Data = new Table();
	table.add(Data);
	table.row();
	var k=0;
	_qt.player_frag_seq.map(f=>k+=f);
	player_frag_combo_draw1(Data,k,_qt.player_frag_seq);
	table.button("关闭",f=>table.remove());
	Core.scene.table().add(table);
}

var cnarc=null;
var follow_cam=null;
function 延迟(){
global.pt.vconfig = {"title":_qt.title2,"cnarc":cnarc,"modv":_modv,"key":_qt.pass}
if(_qt.computer_readKeyCode)keybind.autobind();
try{cnarc=Vars.arcVersionPrefix}catch(error){}
//if(cnarc)eval('throw("本mod无法与学术端同时运行\n请转用原端或其他端继续使用PT=E\n感谢你的支持!")')
var k2 = Core.scene.find("fps/ping");
k2.label(() => "建筑: "+(Vars.player && Vars.player.unit && Vars.player.unit().plans? Vars.player.unit().plans.size : "0")).left().style(Styles.outlineLabel).name("plans2").row();
	

if(_qt.new_playerFrag && !cnarc){
var orig_playerList = Vars.ui.listfrag;
var npL=new JavaAdapter(PlayerListFragment,
{
t : new Table(Tex.pane),
top: new Table(),
content: new Table(),
bottom: new Table(),
firstload : false,
toggle(){
	if(!this.firstload){
		this.load();
		this.firstload=true;
	}
	this.reload_framework();
	this.reload_inside();
	this.t.visible=!this.t.visible;
},
load(){
	Core.scene.table().add(this.t);
	this.t.add(this.top);
	this.t.row();
	this.t.add(this.content);
	this.t.row();
	this.t.add(this.bottom);
	this.t.visible=!this.t.visible;
},
reload_framework(){
	this.top.clear();
	this.top.add("[red][[Pt=E v"+_modv+"] [white]"+Core.bundle.format(Groups.player.size() == 1 ? "players.single" : "players", Groups.player.size()));
},
reload_inside(){
	this.content.clear();
	this.content.pane(tt=>{
		var PLAYER = [],team2=[],lastteam2=null;
	Groups.player.each(k=>{PLAYER.push(k);if(!team2.includes(k.team().id))team2.push(k.team().id)});
	PLAYER.sort((a,b)=>{return (a.team().id>b.team().id?1:-1)}).forEach(user=>{
		if(team2.length>1 && lastteam2!=user.team()){
		lastteam2=user.team();
		tt.add(" ");tt.add("[#"+user.team().color+"]#"+user.team().id+" "+user.team());
		tt.image().color(user.team().color).fillX().pad(6).colspan(4).padTop(5).padBottom(10).fillX().row();
		}
		_qt.player_frag_seq.forEach(num=>{
			if((num&2)!=0)tt.button(
			(user.unit().type == "block"?user.unit().blockOn():user.unit().type).emoji(),Styles.flatTogglet,f=>{
				if(follow_cam==user){
					follow_cam=null;
					if(Vars.control.input instanceof DesktopInput){Vars.control.input.panning = false;}
				}else{
				follow_cam=user;
				Vars.ui.showInfoFade(Core.bundle.format("viewplayer", user.name), 1);
				if(Vars.control.input instanceof DesktopInput){Vars.control.input.panning = true;}
				Core.camera.position.set(follow_cam.unit());
				}
			}).update(b=>b.setChecked(follow_cam==user)).color(Color(user.team().color)).height(45).width(50);
			if((num&4)!=0)tt.button((user.admin?"[gold][white]":"")+(global.pt._ptPlayer[user.id]?"[orange][white]":"")+user.coloredName(),Styles.cleart,f=>{
				Core.app.setClipboardText(user.name);Vars.ui.showInfoFade("已复制!")
			}).color(Color(user.team().color)).width(210).height(50);
			if((num&8)!=0)tt.button("拍一拍",Styles.cleart,f=>{
				var PlayerName = (user.coloredName().length<180-_qt.p1p_data.length?user.coloredName():
					(user.plainName().length<180-_qt.p1p_data.length?user.plainName():
					(user.plainName().substring(0,180-_qt.p1p_data.length))
					)
				);
				var PlayerName2 = (
				_qt.p1p_data.includes("@player")?
				_qt.p1p_data.replace("@player",PlayerName):
				"拍了拍"+PlayerName+" "+_qt.p1p_data
				);
				sendChatMessageQueue("[#fed8d7][[Pt=E v"+_modv+"][white] "+PlayerName2);
			}).color(Color(user.team().color)).width(80).height(50);
			if(global.ptv.nowaddress.name.startsWith(_qt.名称_星空)){
				if((num&16)!=0)tt.button("[red]",Styles.cleart,e=>{_command_list.push("/kick "+user.id);}).color(Color(user.team().color)).height(50).width(50);
				if((num&512)!=0)tt.button("[red]验证",Styles.cleart,e=>{_command_list.push("/test "+user.id);}).color(Color(user.team().color)).height(50).width(60);
				if((num&1024)!=0)tt.button("[red]禁言",Styles.cleart,e=>{_command_list.push("/mute "+user.id);}).color(Color(user.team().color)).height(50).width(60);
			}else{
				if((num&16)!=0)tt.button("[red]",Styles.cleart,e=>{_command_list.push("/votekick "+user.id);}).color(Color(user.team().color)).height(50).width(50)
			}
			if((num&32)!=0)tt.button("[yellow]ID",Styles.cleart,e=>{
				if(Core.input && Core.input.shift && Core.input.shift()){
					Core.app.setClipboardText("Groups.player.find(q=>q.id=="+user.id+")");Vars.ui.showInfoFade("[#ffdfdf]JS 已复制!")
				}else{
					Core.app.setClipboardText(user.id);Vars.ui.showInfoFade("已复制!")	
				}
			}).color(Color(user.team().color)).height(50).width(50);
			if((num&64)!=0)tt.button("[green]",Styles.cleart,e=>{
				if(_valid_msg?(!(_valid_msg.block()=="message" || _valid_msg.block()=="reinforced-message")):true){
					var _0x3 = true;
					Vars.world.tiles.eachTile(t=>{
					if ((t.block()=="message"||t.block()=="reinforced-message")&&_0x3&& t.build.team==Vars.player.team()){
						_valid_msg=t;
						_0x3 = false;
						};
					})
				}
				Vars.ui.showTextInput("[green]<pm>", "", "", _0x5=>{
				try{
					if(_qt.pm_encrypt>=0)_0x5="Δ"+encrypt.encrypt(_qt.pm_encrypt,_0x5,false);
				_valid_msg.build.configure("pm=?"+user.id+"?[clear]"+_0x5);
				}catch(error){print(">278 "+error)}
				})
			}).color(Color(user.team().color)).height(50).width(50);
			if((num&128)!=0)tt.button("[#ffffdf]",Styles.cleart,e=>{
				AImode = 8;AItype(AImode);
				playerAI.playertarget=user;
			}).color(Color(user.team().color)).height(50).width(50);
			if(Vars.player.admin && (num&256)!=0){
				tt.button("[#ffffdf]",Styles.cleart,e=>{Call.adminRequest(user, Packages.mindustry.net.Packets.AdminAction.trace)}).color(Color(user.team().color)).height(50).width(50);
				tt.button("[#ffffdf]",Styles.cleart,e=>{Vars.ui.showConfirm("@confirm", Core.bundle.format("confirmkick",  user.name), e=> {
					Call.adminRequest(user, Packages.mindustry.net.Packets.AdminAction.kick);
					Vars.dataDirectory.child("qt/adminlog.txt").writeString("\nPt-"+_modv+" ["+todayDate(true)+"] ADMINKICK : "+Vars.player.name+" => "+user.name,true);
				})}).color(Color(user.team().color)).height(50).width(50);
			}
			if((num&4096)!=0)tt.button("[green]",Styles.cleart,f=>{
				Core.app.setClipboardText(user.lastText);Vars.ui.showInfoFade("已复制!");
			}).color(Color(user.team().color)).height(50).width(50);
			if((num&8192)!=0)tt.button("[yellow]++",Styles.cleart,f=>{
				
			}).color(Color(user.team().color)).height(50).width(50);
			if(global.pt._ptPlayer[user.id] && (num&2048)!=0)
				tt.add("v"+global.pt._ptPlayer[user.id].modv+(global.pt._ptPlayer[user.id].cnarc?" ("+global.pt._ptPlayer[user.id].cnarc+")":"")).height(50);
		})
		tt.row();
	})
	});
	this.bottom.clear();
	this.bottom.button(" 关闭",Styles.cleart,f=>{this.t.visible=false}).color(Color.red).width(70).height(40);
	this.bottom.button("[cyan]SOS!",Styles.cleart,e=>{
		sendChatMessageQueue("[[Pt=E v"+_modv+"] <Gather> 集结点： ("+Math.floor(Vars.player.x/8)+","+Math.floor(Vars.player.y/8)+")")
	}).width(100).height(40);
	this.bottom.button("[green]聊天 / 配对",Styles.cleart,f=>{
		global.pt0.pm_dialog.main();
		Vars.ui.listfrag.toggle();	
	}).width(100).height(40);
}
});

Vars.ui.listfrag=npL;

}
}

var _command_list=[];
var _chat_list=[];
var AS_unit = null;
var CHAT_timeout=0;
Timer.schedule(()=>{
if(_qt.schCapture)AntiGrief.newSchCapture();
},1,90);

var autouserss = [0,null];
Timer.schedule(()=>{
	if(_command_list.length>0)Call.sendChatMessage(_command_list.shift());
	if(_chat_list.length>0){
		if(CHAT_timeout==0)Call.sendChatMessage(_chat_list.shift());
		else{
			CHAT_timeout=0;
			let length=(_chat_list.length>8?8:_chat_list.length);
			for (var i=0;i<length;i++){
				Call.sendChatMessage(_chat_list.shift());
				CHAT_timeout++;
			}
		}
	}else{CHAT_timeout=0;};
	if(!global.ptv.nowaddress.chk && Vars.player && !Vars.player.unit().null){
		global.pt.configTimes--;if(global.pt.configTimes>0 && global.pt.chk)Call.tileConfig(Vars.player,Vars.player.core(),"pt_v="+JSON.stringify(global.pt.vconfig));
		global.ptv.nowaddress.chk=true;
		}
	if(_qt.quickassist)assistUnit(AS_unit);
	if(_qt.RTScommand)RTScommand2();
	global.pt.configTimes=9;
	if(_qt.autotest && Vars.player && Vars.player.unit && Vars.player.unit() && Vars.player.unit().plans && Vars.player.unit().plans.size<2){
		if(autouserss[1] != Vars.state.map.name()){autouserss = [0,Vars.state.map.name()]}
		if(autouserss[0]>-100)autouserss = [global.pt0.AutoBluePrint.autouse(autouserss[0],Vars.state.map.name()),Vars.state.map.name()]
	};
},1,1.5);

function sendChatMessageQueue(str){
	if(_qt.delay_chat && _chat_list.length<11){
		_chat_list.push(str);
	}else if(CHAT_timeout<8){
		CHAT_timeout++;
		Call.sendChatMessage(str);
	}else{
		_chat_list.push(str);
	}
}

var _popupcatch=false;
Timer.schedule(()=>{
	if(Vars.state.isGame() && _qt.health_bar)healthbar.reload();
	try{
	if(playerAI){AItype(AImode);}
	if(_wpyall){
	item_source=[];
	Groups.build.each(e=>{
	if(e.block=="item-source"&&e.team==Vars.player.team()){
	item_source.push(e);
	}})
	}
	
	if(_qt.auto_rejoin && global.ptv.nowaddress.ip!="localhost"){
	if(!Vars.net.client()){Vars.ui.join.connect(global.ptv.nowaddress.ip,global.ptv.nowaddress.port);}
	}
	//show special building
	if(_qt.map_spec_build){
	try{
	Groups.build.each(e=>{
		if (e.team==Vars.player.team()){
		if (e.block==null){
		Vars.ui.showLabel("[#ff0000]"+e.displayName,7.5,e.x,e.y)
		}else{
		if(e.block.name.includes("source")){Vars.ui.showLabel("[#00ff00]"+e.block.localizedName,7.5,e.x,e.y)};
		if(e.block.name.includes("void")){Vars.ui.showLabel("[#ff0000]"+e.block.localizedName,7.5,e.x,e.y)};
		}}
		if(e.block && e.block.name.includes("core")){
		Vars.ui.showLabel("[#"+e.team.color.toString()+"]"+e.team.localized()+((_qt.language==0)?"队":"隊")+e.block.localizedName,7.5,e.x,e.y)	
		};
	})
	}catch(t){print(">682 "+t)}
	};
	}catch(error){}
},1,8);

Events.on(EventType.DepositEvent, cons(e=>{
	if(e.player==Vars.player && _foowaypt_1){
		wayptAI.wayptlist.push([1,Vars.player.tileX(),Vars.player.tileY(),e.tile,e.item])
	}
}))

Events.on(EventType.WithdrawEvent, cons(e=>{
	if(e.player==Vars.player && _foowaypt_1){
		wayptAI.wayptlist.push([3,Vars.player.tileX(),Vars.player.tileY(),e.tile,e.item])
	}
}));


function pm_id(e){
	try{return Groups.player.getByID(parseInt(e)).coloredName();}catch(error){return "NaN";}
}

function create_build_plan(msg){
	Vars.player.unit().plans.addFirst(BuildPlan(0,0,0,Blocks.message,msg))
}

var _pted_player=[];
Events.on(EventType.ConfigEvent, cons(e=>{
if(e.player&&(e.tile.block=="message"||e.tile.block=="reinforced-message")){
switch(e.value.split("=")[0]){
	
	case "mute":
		if (Vars.player.admin && _qt.msg_remove_mute && get_VIP(e.player)){
		_command_list.push("/mute "+e.player.id);
		if(e.tile.team == Vars.player.team())e.tile.configure("已完成 多谢使用本服务");
		}
	break;
	case "pm":
	if (_qt.chk_pm || (e.value.includes("?all")||e.value.includes(Vars.player.id)) || e.player==Vars.player){ 
		var text2=(e.value.split("[clear]").length>1?e.value.split('[clear]')[1]:e.value);
		if(text2[0]=="Δ")text2="Δ"+encrypt.encrypt(_qt.pm_encrypt,text2.substring(1,text2.length),true);
	Vars.ui.chatfrag.addMessage("[green]<PM> "+(e.value.split("?")[1]!="all"?("(To [white]"+pm_id(e.value.split("?")[1])+"[green])"):"(To All)")+" [white][["+e.player.name+"[white]]: "+text2);
	global.pt.logfi("[green]<PM> "+(e.value.split("?")[1]!="all"?("(To [white]"+pm_id(e.value.split("?")[1])+"[green])"):"(To All)")+" [white][["+e.player.name+"[white]]: "+text2);
	}
	break;
	case "mod":
		global.pt.configTimes--;if(global.pt.configTimes>0 && global.pt.chk)Call.tileConfig(Vars.player,Vars.player.core(),"pt_v="+JSON.stringify(global.pt.vconfig));
	break;
	case "msg2":
		Vars.ui.chatfrag.addMessage(e.value.substring(5))
	break;
	default:
	if (e.value.includes("109+") && e.player){
		//109+ 211-的钉子户
		if(!global.pt._ptPlayer[e.player.id])global.pt._ptPlayer[e.player.id] = {"title":"旧版本钉子户","cnarc":null,"modv":e.value.split("\n")[3],"key":"0"}
	}else if(_qt.msg_talk){
	sendChatMessageQueue(e.player.name+"[white]："+e.value);
	}
	break;
};

}
}))

var _0x20=[];
var _0x21=[];
function _checkp(){
	Groups.player.each(e=>{
		if (_0x20.includes(e)){
			_0x20.splice(_0x20.indexOf(e), 1);
			_0x21.push(e);
		}else{
			_0x21.push(e);
			if(_qt.player_in_out){Vars.ui.chatfrag.addMessage("[#ffd37f]+ "+e.name+"[#ffd37f] has connected.")};
			if(!traced_list[e.id])traces_list.push(e);
		}
	});
	if(_qt.player_in_out){
	let _0x20a=0;
	for (_0x20a in _0x20){
	Vars.ui.chatfrag.addMessage("[#ffd37f]- "+_0x20[_0x20a].name+"[#ffd37f] has disconnected.")
	};
	}
	_0x20=_0x21;
	_0x21=[];
}

function _fullchat(e,f){
	var length = (f?140:150);
	var prefix = (f?";tell "+f+" ":"");
	for (var i=0;i<Math.ceil(e.length/length);i++)
	sendChatMessageQueue(prefix+e.substring(i*length,(i+1)*length));
}

function _fillz(e){return e.toString().padStart(2,"0")}
var _0x1d=0;
var starsky_t5data = [25,45,70];

function starsky(x){
	if(Vars.state.tick/3600+x>starsky_t5data[2])return "T5";
	var g = starsky_t5data.filter(e=>Vars.state.tick/3600+x>e);
	return "T"+(g.length+1)
}
function starsky2(){
	var g = starsky_t5data.filter(e=>Vars.state.tick/3600<e);
	return (g.length>0)?"[orange]  "+(g[0]-Math.trunc(Vars.state.tick/3600))+" 分钟后出 "+starsky(g[0]-Math.trunc(Vars.state.tick/3600)):"";
}

function timeresult(){
	if (Vars.state.rules.pvp){
		if(Math.trunc(Vars.state.tick/3600)<10){
		return(" [gold]pvp保护时间剩余 "+Math.round((600-Math.floor(Vars.state.tick/60))/60)+"分"+((600-Math.floor(Vars.state.tick/60))%60)+"秒");
		}else{
		return(" [gold]pvp保护时间已结束，发起进攻吧。")
		}
		}
	if (Vars.state.rules.attackMode)return(	" [acid]核心出"+starsky(0)+"或以下"+starsky2()+" [red]| 开核次数: "+_开核次数+"[gray]/6");
	return (" [salmon]生存模式");
}

function checksamePos(e){
	try{Vars.player.unit().plans.each(f=>{if(f.samePos(e))throw 144;});
	}catch(error){return false;}
	return true;
}

function get_Ammo(b){
	return (!b || !b.ammo || !b.block instanceof Turret ? 0.9 : 
	(b.ammo.size==0 ? 0 : b.ammo.first().amount/b.block.maxAmmo))
}
function getRss(b){
	return (!b || !b.items ? 1e4 : (b.items.get(Vars.player.unit().stack.item)===undefined?0:b.items.get(Vars.player.unit().stack.item)))
}

var 星空_data={};
var autotransfer_item=null;
function autotransfer2(){
if(!autotransfer_item)try{autotransfer_item=Vars.player.unit().stack.item}catch(error){return}
if(!autotransfer_item)return;
var autotransferlist=[];
var tookalr=2;
if(Vars.player.unit().stack.amount<(Vars.player.unit() && Vars.player.unit().itemCapacity ? Vars.player.unit().itemCapacity()/2 : 0)){
	Vars.indexer.eachBlock(Vars.player.team(),Vars.player.x,Vars.player.y,25*8,boolf(q=>(_qt.atrans_vault || q.block instanceof CoreBlock) && q.block instanceof StorageBlock && q.items.has(Vars.player.unit().stack.item)),g=>{autotransferlist.push(g)});
	autotransferlist.sort((a,b)=>{
		return (a.block instanceof CoreBlock ? -1 : (b.block instanceof CoreBlock ? 1 : 0))
	});
	if(autotransferlist.length>0)
	Call.requestItem(Vars.player,autotransferlist[0],autotransfer_item,Vars.player.unit().type.itemCapacity);
	autotransferlist=[];tookalr=1;
}
Vars.indexer.eachBlock(Vars.player.team(),Vars.player.x,Vars.player.y,25*8,boolf(q=>
q.block && q.block.hasItems && ((_qt.atrans_fact && (q.block instanceof GenericCrafter || q.block instanceof PowerGenerator || q.block instanceof UnitFactory || q.block instanceof Reconstructor || q.block == Blocks.oilExtractor)) || q.block instanceof Turret) && (q.acceptStack(Vars.player.unit().stack.item,1,Vars.player.unit())==1)
),g=>{autotransferlist.push(g)});
autotransferlist.sort((a,b)=>{
	return (get_Ammo(a)!=get_Ammo(b)?(get_Ammo(a)<get_Ammo(b)?-1:1):(getRss(a)<getRss(b)?-1:1))
});
if(autotransferlist.length>0)Call.transferInventory(Vars.player,autotransferlist.shift());
}

Timer.schedule(()=>{
	if(StealUnit)StealUnit.refresh();
	
	if(brokenbuild){
	Vars.player.team().data().plans.each(_0x224=>{
		if(Vars.player.team().data().plans.size>_qt.brokenbuildmax){
			if(Vars.player.dst(_0x224.x*8,_0x224.y*8)<50*8 && Vars.player.unit().plans.size<_qt.brokenbuildmax){
				var _0x225 = BuildPlan(_0x224.x,_0x224.y,_0x224.rotation,Vars.content.block(_0x224.block),_0x224.config);
				if(checksamePos(_0x225))
				Vars.player.unit().plans.addFirst(_0x225);
			}
		}else if (Vars.player.unit().plans.size<_qt.brokenbuildmax){
		var _0x225 = BuildPlan(_0x224.x,_0x224.y,_0x224.rotation,Vars.content.block(_0x224.block),_0x224.config);
		if(checksamePos(_0x225))
			Vars.player.unit().plans.addFirst(_0x225);
		}
	})	
	}

	if(foobuild){
	Groups.player.each(e=>{
	if (e.unit().plans.size!=0 && e!=Vars.player && Vars.player.team()==e.team()){		
	for (let i=0;i<e.unit().plans.size;i++){
		if(checksamePos(e.unit().plans.get(i))){
			Vars.player.unit().plans.addFirst(e.unit().plans.get(i));
		}
		if (e.unit().plans.get(i).breaking!=Vars.player.unit().plans.get(0).breaking && e.unit().plans.get(i).samePos(Vars.player.unit().plans.get(0)))
		{Vars.player.unit().plans.removeFirst()}
	}}
	})
	}
	


	if(_wpy){
		var _0x1c=0;
		var _0x1e=2147483647;
		var _istype=Items.copper;
		for (_0x1c in wpy_config){
		if (_0x1e>Vars.player.team().items().get(wpy_config[_0x1c])){
		_0x1e = Vars.player.team().items().get(wpy_config[_0x1c]);
		_istype = wpy_config[_0x1c];
		}
		}
		_0x1d++;
		_0x1d=_0x1d % item_source.length;
		if (isNaN(_0x1d)){_0x1d=0;}
		if( item_source.length>0 && item_source[_0x1d]){
		if (item_source[_0x1d].config()!=_istype){
			item_source[_0x1d].configure(_istype)
		}
		}
	}	
	_checkp();
	if(autotransfer)autotransfer2();
	if(_qt.trace_remove && traces_list.length>0 && Vars.player.admin && Vars.net.client()){
		Call.adminRequest(traces_list.shift(), Packages.mindustry.net.Packets.AdminAction.trace);
	}
	if(healthbar)healthbar.loadFrag();
	if(_qt.shipRotateSpeed)cheat_ship.reload();
},1,0.35);


var traces_list=[],traced_list={};


function get_player_byname(name,newlv){
	if(name && name.trim()){
	var num = parseInt(name);
	return Groups.player.find(f=> f!=Vars.player && (f.id==num || f.plainName().includes(name)) && (newlv==true ? true : !get_VIP(f,(newlv?get_VIPlv(newlv):null))));
	}
}

function get_VIP(player,newlv){
	if(!Vars.player.admin || !global.ptv.nowaddress.name.startsWith(_qt.名称_星空))return false;
	if(player==Vars.player || (player && traced_list[player.id] && Object.keys(_qt.VIPuser).includes(traced_list[player.id].uuid) && _qt.VIPuser[traced_list[player.id].uuid].lv>(newlv?newlv:0)))return true;
	return false;
}

function get_VIPlv(player){
	if(!Vars.player.admin || !global.ptv.nowaddress.name.startsWith(_qt.名称_星空))return 1;
	if(player==Vars.player)return 144;
	if(player && traced_list[player.id] && Object.keys(_qt.VIPuser).includes(traced_list[player.id].uuid))return _qt.VIPuser[traced_list[player.id].uuid].lv;
	return 1;
}

var CMDLIST = {};
function DICT_copy(ori,name){CMDLIST[name]={"func":CMDLIST[ori].func,"r":CMDLIST[ori].r}}

CMDLIST.run = function(name,text,player){
	var req = {"name":name,"cmd":text.split(" ")[0],"para":text.split(" ").slice(1),"whole":text.split(' ').slice(1).join(' '),"player":player};
	if(req.cmd.startsWith("_") && CMDLIST[req.cmd]){
	_qt.cmd_count+=1;store_settings();
	var r = {
		"samep":req.player==Vars.player,
		"samepcmd":req.player==Vars.player || _qt.command,
		"ALL":true,
	};
	if(get_VIPlv(req.player)<=0)return;
		r.NORMAL=		_qt.command || r.samep;
		r.ADMINNORMAL=	r.samepcmd && _qt.admin_cmd;
		r.SELF=		 	r.samep;
		r.ADMIN=		r.samep && _qt.admin_cmd;
		r.WHITELIST=	r.samepcmd && _qt.admin_cmd && get_VIP(req.player) && get_VIPlv(req.player) >= CMDLIST[req.cmd].lv;
		if(_qt.admin_cmd && CMDLIST[req.cmd].r == "WHITELIST" && !r.WHITELIST)sendChatMessageQueue("[#ffdfdf]你并非白名单玩家 / 白名单等级不够  [#ffffdf]白名单功能只开放予已信任玩家");
		if(r[CMDLIST[req.cmd].r])return CMDLIST[req.cmd].func(req);
	}
}

function lyear2(){
	var k=new Date();
	k=Cal2.c2.solar2lunar(k.getFullYear(),k.getMonth()+1,k.getDate());
	return (k?
	"[#dfdfff]"+k.cYear+"年"+k.cMonth+"月"+k.cDay+"日 "+k.IMonthCn+k.IDayCn+" "+k.ncWeek
	:"")
}

CMDLIST._about = {
	"desc":"查询mod资讯、游戏数据",
	"type":"Mod",
	"r":"ALL",
	"func":function(req){
	var r = cmd._about();
	sendChatMessageQueue((_qt.moderator?lyear2()+" ":"[sky]此mod由144开发，")+"版本："+_modv+" | QQ[acid]340765776[] 群[acid]745730529[] "+(r.data>1?"| [green]"+r.data+" []项玩家资讯| 聊天记录 [green]"+r.chat+" []日":""));
	sendChatMessageQueue("[cyan]运行时间："+uptimechk(new Date(uptime))+" | 指令使用次数："+_qt.cmd_count+" |[sky] "+(r.totalpts==2147483647?"分数: [white]"+(r.totalpts-r.pts_next):"升级分数：[white]"+r.pts_next+"[gray]/"+r.totalpts)+"[sky] 星尘数量：[orange]"+r.coins);
	}
}

CMDLIST._time = {
	"desc":"显示游戏时间",
	"type":"Mod",
	"r":"NORMAL",
	"func":function(req){
		if(Vars.dataDirectory.child("qt/starsky").exists()){
			var time_details = JSON.parse(Vars.dataDirectory.child("qt/starsky").readString());
		}else{
			var time_details={};
		};
		sendChatMessageQueue("[sky]游戏时间 "+Math.trunc(Vars.state.tick/3600)+":"+Math.trunc(Vars.state.tick/600%6)+Math.trunc(Vars.state.tick/60%10)+" [gray]/ "+
		(parseInt(time_details.map_time)>Math.trunc(Vars.state.tick/3600)?"[green]":"[red]")+time_details.map_time+(time_details.map_reward?"*":"")+" [white]| "+timeresult());
	}
}

CMDLIST._msg = {
	"desc":"留言",
	"type":"Mod",
	"p":"<msg...>",
	"r":"NORMAL",
	"func":function(req){
		星空_data = JSON.parse(Vars.dataDirectory.child("qt/starsky").readString());
		if (!星空_data.msg){星空_data.msg=[];}
		sendChatMessageQueue("[Pt=E v"+_modv+"]  [sky] 已成功留言 [gray]留言id: "+星空_data.msg.length);
		星空_data.msg.push(
			{"time":new Date().toString(),
			"name":req.name,
			"msg":req.para
			}
			);
		Vars.dataDirectory.child("qt/starsky").writeString(JSON.stringify(星空_data, null, 2));
	}
}

CMDLIST._sr = {
	"desc":"查询玩家列表",
	"p":"<number>",
	"r":"ADMINNORMAL",
	"func":function(req){
		var _0x96 =parseInt(req.para[0]);
		var _0x95 = _0x97[_0x96];
		try {
			_fullchat("#"+_0x95.seq+" "+_0x95["name"]+" [acid]进入次数："+_0x95["join"]+" 加入于 "+new Date(_0x95["time"]).toLocaleString().replace(" HKT","")+" （"+timechk(new Date(_0x95["time"]))+"）ip: "+_0x95.ip.split(".")[0]+" uuid: "+_0x95.uuid.substring(0,5));
		}catch(k){sendChatMessageQueue("[#ff0000]"+k)};
	}
}

CMDLIST._math = {
	"desc":"算术比赛",
	"type":"Game",
	"r":"ADMINNORMAL",
	"func":function(req){
		var math_symbol=["+","-","*","/"][Math.floor(Math.random() *4)];
			if (math_symbol=="/"){
				var mathans=(Math.floor(Math.random() *15)+1);
				var mathans2 = (Math.floor(Math.random() *15)+1);
				mathans = (mathans * mathans2)+"/"+mathans2;
			}else if (math_symbol=="*"){
				var mathans=(Math.floor(Math.random() *15)+1)+math_symbol+(Math.floor(Math.random() *15)+1);	
			}else{
				var mathans=Math.floor(Math.random() *100)+math_symbol+Math.floor(Math.random() *100);
			};
		if(GAME_func.chk_inrm(req.player,"math")){
			GAME_NOW.push({
				"rm":GAME_func.gen(),
				"answer":mathans,
				"time":Date.now(),
				"type":"math",
				"player":"*",
				"chance":0
			});
		let M_rm = GAME_NOW[GAME_NOW.length-1].rm;
		let M_ans = mathans;
		Timer.schedule(function(){
			sendChatMessageQueue("[acid]Room "+M_rm+" [sky]数学竞速游戏 算式 : [acid]"+M_ans);
		},3);	
			sendChatMessageQueue("[acid]Room "+GAME_NOW[GAME_NOW.length-1].rm+" "+req.name+" [sky]开始了新的数学竞速游戏！3秒后开始，准备好！");
		}
	}
}	
		
CMDLIST._join = {
	"desc":"加入比赛",
	"type":"Game",
	"p":"<number>",
	"r":"ADMINNORMAL",
	"func":function(req){
		GAME_NOW.forEach((f,index)=>{if(req.para[0]==f.rm){
			if(f.type=="PWN" && !f.player.includes(req.player.id)){
				GAME_NOW[index].chance+=2;
				GAME_NOW[index].player.push(req.player.id);
				sendChatMessageQueue("成功加入 [acid]Room "+ f.rm+"  | 玩法为: "+f.type)
			};
			}
		})
	}
}		

CMDLIST._bomb = {
	"desc":"数字炸弹",
	"type":"Game",
	"p":"<number>",
	"r":"ADMINNORMAL",
	"func":function(req){
		var bomblimit = (parseInt(req.para[0])?parseInt(req.para[0]):100);
		var bombans = Math.floor(Math.random() * bomblimit);
		if(GAME_func.chk_inrm(req.player,"bomb")){
			GAME_NOW.push({
				"rm":GAME_func.gen(),
				"answer":bombans,
				"highlimit":bomblimit,
				"time":Date.now(),
				"lowlimit":0,
				"type":"bomb",
				"player":"*",
				"chance":0
			});
			sendChatMessageQueue("[acid]Room "+GAME_NOW[GAME_NOW.length-1].rm+" "+req.name+" [sky]开始了新的数字炸弹！范围：1 - "+bomblimit);
		}
	}
}			

CMDLIST._pwn = {
	"desc":"解密游戏",
	"type":"Game",
	"r":"ADMINNORMAL",
	"func":function(req){
		if(GAME_func.chk_inrm(req.player,"PWN")){
			GAME_NOW.push({
				"rm":GAME_func.gen(),
				"answer":GAME_func.pwn_ans(),
				"time":Date.now(),
				"chance":5,
				"type":"PWN",
				"player":[req.player.id]
			});
			sendChatMessageQueue("[acid]Room "+GAME_NOW[GAME_NOW.length-1].rm+" [sky]猜密码 请输入四位数字 例子: [acid]5678   [green]绿色 数字&位置都对 [yellow]黄色 数字对 位置不对 [gray]灰色 数字不对 [sky]数字不会重复");
		}
	}
}	

CMDLIST._help = {
	"desc":"HELP",
	"type":"Mod",
	"r":"NORMAL",
	"func":function(req){
		const type = ["ALL","NORMAL","ADMINNORMAL","WHITELIST","ADMIN","SELF"];
		const color = ["[orange]","[goldenrod]","[gold]","[#999aff]","[scarlet]","[coral]"];
		if(req.para[0] == "VIP"){
			var _helplist = Object.keys(CMDLIST).filter(w=>CMDLIST[w].r=="WHITELIST" && get_VIPlv(req.player)>=CMDLIST[w].lv).map(e=>(CMDLIST[e].type?[e,CMDLIST[e].type,CMDLIST[e].desc,CMDLIST[e].r,CMDLIST[e].p,CMDLIST[e].lv]:undefined)).sort((a,b)=>{return (a[5]>b[5]?1:-1)})
		}else{
		var _helplist = Object.keys(CMDLIST).map(e=>(CMDLIST[e].type?[e,CMDLIST[e].type,CMDLIST[e].desc,CMDLIST[e].r,CMDLIST[e].p,CMDLIST[e].lv]:undefined));
		var typeused = [true,true,_qt.admin_cmd,get_VIP(req.player),_qt.admin_cmd&&req.player==Vars.player,req.player==Vars.player];
		_helplist = _helplist.filter(e=>(e && typeused[type.indexOf(e[3])]));
		_helplist = _helplist.sort((a,b)=>{
			if(a[3]!=b[3])return (type.indexOf(a[3])>type.indexOf(b[3])?1:-1)
			if(a[1]!=b[1])return (a[1]>b[1]?1:-1)
			return(a[0]>b[0]?1:-1)
		})
		}
		var help_length=Math.ceil(_helplist.length/5);
		var help_index= req.para[1] && parseInt(req.para[1]) ?parseInt(req.para[1])-1 : parseInt(req.para[0])-1;
		if(!help_index)help_index=0;
		_helplist = _helplist.slice(help_index*5,help_index*5+5);
		if(_helplist.length!=0){
		sendChatMessageQueue("[sky]---  [white][Pt=E] v"+_modv+"  指令大全  Commands  [acid]"+(help_index+1)+"[gray]/"+help_length+" [sky]---");
		_helplist.forEach(g=>{
			sendChatMessageQueue("[gray]["+g[1]+"] "+color[type.indexOf(g[3])]+" "+g[0]+" "+(g[5]?"【"+Num2parse(g[5])+"】":"")+(g[4]?"[gray]"+g[4]:"")+"[white] "+g[2]);
		});
		}
		}
}

CMDLIST._sync = {
	"desc":"_syncall 强制sync", 
	"type":"白名单",
	"r":"WHITELIST",
	"lv":9,
	"func":function(req){
		_command_list.push("/syncall");
	}
}
DICT_copy("_sync","_syncall");	

CMDLIST._ban = {
	"desc":"免投票 直接踢（封禁时长45秒）", 
	"p":"<player/name>",
	"type":"白名单",
	"r":"WHITELIST",
	"lv":4,
	"func":function(req){
		if(get_player_byname(req.whole,req.player)){	
		Call.adminRequest(get_player_byname(req.whole,req.player),Packages.mindustry.net.Packets.AdminAction.kick);
		Vars.dataDirectory.child("qt/adminlog.txt").writeString("\nPt-"+_modv+" ["+todayDate(true)+"] ADMINKICK : "+req.name+" => "+get_player_byname(req.whole,req.player).name,true);
		sendChatMessageQueue(get_player_byname(req.whole,req.player).name+" [white]已被踢出游戏 （约45秒） 应[royal]鸽子[]要求， @"+req.name+"[white] 请输入原因以作备份，谢谢。");
		playerKicker.push(req.player);
		}
	}
}		

CMDLIST._kick = {
	"desc":"免投票 踢(游戏指令)", 
	"p":"<player/name>",
	"type":"白名单",
	"r":"WHITELIST",
	"lv":4,
	"func":function(req){
		if(get_player_byname(req.whole,req.player)){	
		_command_list.push("/kick "+get_player_byname(req.whole,req.player).id);
		Vars.dataDirectory.child("qt/adminlog.txt").writeString("\nPt-"+_modv+" ["+todayDate(true)+"] 服务器KICK: "+req.name+" => "+get_player_byname(req.whole,req.player).name,true);
		sendChatMessageQueue("☑ 投票踢 "+get_player_byname(req.whole,req.player).name+" [white]| 投票途中无法使用本功能，请以_ban代替 | 应[royal]鸽子[]要求， @"+req.name+"[white] 请输入原因以作备份，谢谢。");
		playerKicker.push(req.player);
		}
	}
}	

CMDLIST._mute = {
	"desc":"免投票 禁言 [red]信息板输入'mute'解禁言[]", 
	"p":"<player/name>",
	"type":"白名单",
	"r":"WHITELIST",
	"lv":3,
	"func":function(req){
		if(get_player_byname(req.whole,req.player)){
		_command_list.push("/mute "+get_player_byname(req.whole,req.player).id);
		Vars.dataDirectory.child("qt/adminlog.txt").writeString("\nPt-"+_modv+" ["+todayDate(true)+"] 服务器MUTE: "+req.name+" => "+get_player_byname(req.whole,req.player).name,true);
		}
	}
}		

CMDLIST._VIPdesc = {
	"desc":"修改VIP个人显示", 
	"p":"<desc>",
	"type":"白名单",
	"r":"WHITELIST",
	"lv":2,
	"func":function(req){
		var uuid = traced_list[req.player.id];
		if(uuid){
			uuid=uuid.uuid;
			_qt.VIPuser[uuid].desc = req.whole;
			store_settings();
			sendChatMessageQueue("[royal]@白名单玩家 [white]已记录此描述  输入_VIP 查看 ：）");
		}
	}
}

DICT_copy("_VIPdesc","_vipdesc");	

CMDLIST._runwave = {
	"desc":"跳波", 
	"p":"<number 1-75>",
	"type":"白名单",
	"r":"WHITELIST",
	"lv":4,
	"func":function(req){
		if(parseInt(req.para[0]) && parseInt(req.para[0]) <= 75){
		for (var runwave_rnd=0;runwave_rnd<parseInt(req.para[0]);runwave_rnd++)Call.adminRequest(Vars.player, Packages.mindustry.net.Packets.AdminAction.wave);
		sendChatMessageQueue("[royal]@白名单玩家 [white]"+req.name+"[white] 已手动跳 [red]"+parseInt(req.para[0])+" [white]波");
		Vars.dataDirectory.child("qt/adminlog.txt").writeString("\nPt-"+_modv+" ["+todayDate(true)+"] 跳波 "+req.name+" | x"+parseInt(req.para[0]),true);
		}else{
			sendChatMessageQueue("[royal]@白名单玩家 [white]请输入有效数字 1-75 例子: [acid]_runwave 1");
		}
	}
}			

CMDLIST._miner = {
	"desc":"帮助 144 召唤矿机", 
	"type":"星空",
	"r":"NORMAL",
	"func":function(req){
		_command_list.push("/miner");
	}
}	

CMDLIST._savemap = {
	"desc":"保存网络换图", 
	"type":"白名单",
	"r":"WHITELIST",
	"lv":9,
	"p":"",
	"func":function(req){
		_command_list.push("/savemap");
		sendChatMessageQueue("[#dfffdf]已尝试保存此图 输/maps查看地图清单 | 请善用此指令作网络传图之用(无法覆盖现有地图)");
	}
}

CMDLIST._closeserver = {
	"desc":"协助重启服务器", 
	"type":"白名单",
	"r":"WHITELIST",
	"lv":12,
	"p":"",
	"func":function(req){
		_command_list.push("/closeserver");
		Vars.dataDirectory.child("qt/adminlog.txt").writeString("\nPt-"+_modv+" ["+todayDate(true)+"] 服务器重启: "+req.name,true);
		sendChatMessageQueue("[#dfffdf]☑ 重启成功 @[white]"+get_player_byname(req.whole,req.player).name+" [#dfffdf] 请输入原因以作备份，谢谢。");
		playerKicker.push(req.player);
	}
}

CMDLIST._team = {
	"desc":"ｐｖｐ换队伍", 
	"type":"白名单",
	"r":"WHITELIST",
	"lv":2,
	"p":"[playerID] <team>",
	"func":function(req){
		if(Vars.player.admin && global.ptv.nowaddress.name.startsWith(_qt.名称_星空)){
		if(req.para.length==1){
		_command_list.push("/assign "+req.player.id+" "+req.para[0]);
		sendChatMessageQueue("玩家 "+req.name+" [white]已换队 "+req.para[0] + (Vars.state.rules.pvp?"":"[acid]  目前模式并非PVP, 可能无法换队。"));
		}else if(req.para.length==2){
			var Player2 = get_player_byname(req.para[0],true);
		if(Player2){
		_command_list.push("/assign "+Player2.id+" "+req.para[1]);
		sendChatMessageQueue("玩家 "+Player2.name+" [white]已换队 "+req.para[1] + (Vars.state.rules.pvp?"":"[acid]  目前模式并非PVP, 可能无法换队。"));
		}
		}else{
			sendChatMessageQueue("[#ffdfdf]玩家参数错误 用法: _team <team> 自行换队 | _team <ID/name> <team> 帮别人换队");
		}
		}
	}
}			

function viplistlv(f,online){
	if(f<=0)return (online?"[#bbbbbb]":"[#666666]");
	if(f==2)return (online?"[#ffaaaa]":"[#cc5555]");
	if(f==6)return (online?"[#ffaaff]":"[#cc55cc]");
	if(f<=10)return (online?"[#aaffaa]":"[#00cc00]");
	if(f<=10)return (online?"[#ffffaa]":"[#cccc00]");
	return "";
}

CMDLIST._VIP = {
	"desc":"VIP列表  < 纪 律 委 员 > ", 
	"type":"白名单",
	"r":"ADMINNORMAL",
	"func":function(req){
		var data= JSON.parse("["+Vars.dataDirectory.child('qt/ptall').readString()+"]");
		data=data.filter(f=>Object.keys(_qt.VIPuser).includes(f.uuid));
		data.reverse();
	if(!req.para[0]){
	Object.keys(_qt.VIPuser).forEach((e,i)=>{
		var findp = Groups.player.find(f=>f.id==Object.keys(traced_list).filter(g=>traced_list[g].uuid==e).reverse()[0]);
		if(findp)_fullchat(viplistlv(_qt.VIPuser[e].lv,true)+"第 "+Num2parse(i+1)+" 位"+(_qt.VIPuser[e].lv>0?"白":"黑")+"名单玩家: Lv. "+Num2parse(_qt.VIPuser[e].lv)+" [white]"+findp.name+" [sky]("+e.substring(0,3)+")[white]"+(_qt.VIPuser[e].desc?" | "+_qt.VIPuser[e].desc:""))
	});
	}else if(parseInt(req.para[0])<=Math.ceil(Object.keys(_qt.VIPuser).length/6)){
		for (var i=(parseInt(req.para[0])-1)*6;i<parseInt(req.para[0])*6;i++){
			var e = Object.keys(_qt.VIPuser)[i];
			if(e){
			var findp = Groups.player.find(f=>f.id==Object.keys(traced_list).filter(g=>traced_list[g].uuid==e).reverse()[0]);
		_fullchat(viplistlv(_qt.VIPuser[e].lv,findp)+(findp?"［在场］":"")+"第 "+Num2parse(i+1)+" 位"+(_qt.VIPuser[e].lv>0?"白":"黑")+"名单玩家: Lv. "+Num2parse(_qt.VIPuser[e].lv)+" [white]"+data.find(g=>g.uuid==e).name+" [sky]("+e.substring(0,3)+")[white]"+(_qt.VIPuser[e].desc?" | "+_qt.VIPuser[e].desc:""))
			}
		}
		_fullchat("[#ffdfff]页"+parseInt(req.para[0])+"/[gray]"+Math.ceil(Object.keys(_qt.VIPuser).length/6)+" []共 "+Object.keys(_qt.VIPuser).length+" 个白名单 | [#ddffdd]能力越大，责任越大 请善用白名单指令 []| _help VIP <num> 查看白名单指令");
	}
	}
}				
	
CMDLIST._addVIP = {
	"desc":"新增 VIP", 
	"type":"白名单",
	"r":"WHITELIST",
	"lv":11,
	"p":"<name>",
	"func":function(req){
		if(Vars.player.admin){
		var addVIPname = Groups.player.find(e=>e.id == req.whole || e.name.includes(req.whole));
		if(addVIPname){
		var addVIPbyuuid = traced_list[addVIPname.id].uuid;
		if(!Object.keys(_qt.VIPuser).includes(addVIPbyuuid)){
			_qt.VIPuser[addVIPbyuuid]={"laston":Date.now(),"desc":"","lv":2};
			Vars.dataDirectory.child("qt/adminlog.txt").writeString("\nPt-"+_modv+" ["+todayDate(true)+"] 新增VIP: "+addVIPname.name,true);
			sendChatMessageQueue("[#dfffdf]！已新增 第 "+Object.keys(_qt.VIPuser).length+" 位白名单玩家: [white]"+addVIPname.name+" [sky]("+addVIPbyuuid.substring(0,3)+")");
			store_settings();
		}
		}
		}
	}
}				

CMDLIST._setlv = {
	"desc":"改变白名单成员等级", 
	"type":"白名单",
	"r":"WHITELIST",
	"lv":11,
	"p":"<name>",
	"func":function(req){
		if(Vars.player.admin){
			var ppl = Groups.player.find(e=>e.id == req.para[0] || e.name.includes(req.para[0]));
			if(ppl){
			var ppluuid = traced_list[ppl.id].uuid;
			if(Object.keys(_qt.VIPuser).includes(ppluuid)){
				if(req.player != Vars.player && !(parseInt(req.para[1])<11))req.para[1]=10;
				_qt.VIPuser[ppluuid].lv = parseInt(req.para[1]);
				Vars.dataDirectory.child("qt/adminlog.txt").writeString("\nPt-"+_modv+" ["+todayDate(true)+"] 更改VIP等级: "+ppl.name+" --> lv. "+parseInt(req.para[1]),true);
				sendChatMessageQueue("[#ffdfdf] 更改VIP等级: [white]"+ppl.name+" [sky]("+ppluuid.substring(0,3)+") [white]Lv. "+parseInt(req.para[1]));
				store_settings();
			}
			}
		}
	}
}

CMDLIST._rmVIP = {
	"desc":"移除 VIP", 
	"type":"白名单",
	"r":"WHITELIST",
	"lv":11,
	"p":"<name>",
	"func":function(req){
		if(Vars.player.admin){
			var addVIPname = Groups.player.find(e=>e.id == req.whole || e.name.includes(req.whole));
			if(addVIPname){
			var addVIPbyuuid = traced_list[addVIPname.id].uuid;
			if(Object.keys(_qt.VIPuser).includes(addVIPbyuuid)){
				delete _qt.VIPuser[addVIPbyuuid];
				Vars.dataDirectory.child("qt/adminlog.txt").writeString("\nPt-"+_modv+" ["+todayDate(true)+"] 移除VIP: "+addVIPname.name,true);
				sendChatMessageQueue("[#ffdfdf]！已移除白名单玩家: [white]"+addVIPname.name+" [sky]("+addVIPbyuuid.substring(0,3)+")");
				store_settings();
			}
			}
		}
	}
}

CMDLIST._s = {
	"desc":"_s 寻找玩家记录,可输入多个变数 类型：[as]cending 顺序，[de]scending 倒序，name 名称，ip，uuid", 
	"type":"Info",
	"r":"ADMINNORMAL",
	"p":"<data..>",
	"func":function(req){
		try{
			var _0x99 = req.whole.split(" ");
			if ((_0x99.length>=2) && (_0x99.length%2==0)){
				_0x97 = pRecord.search2(_0x99);
			}else{
				_0x97 = pRecord.search1(_0x99);	
			}
			if (_0x97.length==1){
				try {
				_fullchat("#"+_0x97[0].seq+" "+_0x97[0].name+" [acid]进入次数："+_0x97[0].join+" 加入于 "+new Date(_0x97[0].time).toLocaleString().replace(" HKT","")+" （"+timechk(new Date(_0x97[0]["time"]))+"）ip: "+_0x97[_0x97.length-1].ip.split(".")[0]+" uuid: "+_0x97[0].uuid.substring(0,5));
				}catch(k){sendChatMessageQueue("[#ff0000]"+k)}
				}else{
				_fullchat("共获得[#dfffdf]"+_0x97.length+"[]个搜寻结果，输入 _sr <int> 查看页数 #"+_0x97[_0x97.length-1]["seq"]+" "+_0x97[_0x97.length-1]["name"]+" [acid]进入次数："+_0x97[_0x97.length-1]["join"]+" 加入于 "+new Date(_0x97[_0x97.length-1]["time"]).toLocaleString().replace(" HKT","")+" （"+timechk(new Date(_0x97[_0x97.length-1]["time"]))+"）ip: "+_0x97[_0x97.length-1].ip.split(".")[0]+" uuid: "+_0x97[_0x97.length-1].uuid.substring(0,5));
			}
			}catch(error){
				print(error);
			}
	}
}

function assistUnit(up){
if(up && up.unit()){
up=up.unit();var k=[];
if(_qt.quickassist_cursor){var dst = Vec2(up.aimX,up.aimY)}else{var dst = Vec2(up.x,up.y)}
if(up.activelyBuilding()){
Groups.unit.each(e=>{if(e.isAI()&&e.type.buildSpeed>0)k.push(e)});
var k_bad = k.filter(e=>(e.dst?e.dst(up)>500:false));
var k_good = k.filter(e=>(e.dst?e.dst(up)<=500:false));
Call.setUnitCommand(Vars.player,k_good.map(g=>g.id),UnitCommand.assistCommand);
Call.commandUnits(Vars.player,k_bad.map(g=>g.id),null,null,dst);
}else{
Groups.unit.each(e=>{if(e.isAI()&&e.type.buildSpeed>0)k.push(e.id)});
Call.commandUnits(Vars.player,k,null,null,dst);
}
}
}

function command(pname,ptext,player){
	CMDLIST.run(pname,ptext,player);
	if(!_qt.command && player!=Vars.player)return;
	if (!isNaN(parseInt(ptext.split(" ")[0]))){
		var game_in_charge = GAME_NOW.filter(e=>e.player=="*"||e.player.includes(player.id));
		game_in_charge.forEach((e)=>{
			switch(e.type){
			case "PWN":
			try{
			if(ptext.split(" ")[0].length!=4)throw("hi");
			game_in_charge.forEach((f,index)=>{if(f.rm==e.rm)game_in_charge[index].chance--})
			var _0x302 = 0;
			var _0x300 = "";
			for (var _0x301 in ptext.split(" ")[0]){
				if(ptext.split(" ")[0][_0x301]==e.answer[_0x301]){
					_0x300+="[green]"+ptext.split(" ")[0][_0x301]+"[]|";
					_0x302++;
				}else if(e.answer.includes(parseInt(ptext.split(" ")[0][_0x301]))){
					_0x300+="[yellow]"+ptext.split(" ")[0][_0x301]+"[]|";
				}else{
					_0x300+="[gray]"+ptext.split(" ")[0][_0x301]+"[]|";
				}
			};
			if(_0x302>3){
				sendChatMessageQueue("[acid]Room "+e.rm+" [green]你猜出答案了。 密码为：[acid]"+e.answer.toString()+" [sky]时间为: "+Math.round((Date.now()-e.time)/1000))
				GAME_func.remove(e.rm);
			}else{
				if(e.chance<1){
					sendChatMessageQueue("[acid]Room "+e.rm+" [red]未能猜出答案。 正确答案为：[acid]"+e.answer.toString()+" [sky]时间为: "+Math.round((Date.now()-e.time)/1000))
					GAME_func.remove(e.rm);
				}else{
					sendChatMessageQueue("[acid]Room "+e.rm+" 猜密码: |"+_0x300+" [acid]剩余 "+(e.chance)+" 次机会");
				}
			}
			}catch(error){
				sendChatMessageQueue("[acid]Room "+e.rm+" [red]未能识别数字，请输入数字 例子: [acid]5678");
			}
			break;
			case "bomb":
			game_in_charge.forEach((f,index)=>{if(f.rm==e.rm)game_in_charge[index].chance++})
			if (e.answer == parseInt(ptext.split(" ")[0])){
				sendChatMessageQueue("[acid]Room "+e.rm+" [sky]答案正确！ 数字为：[green]"+e.answer+" [sky] 时间为: "+Math.round((Date.now()-e.time)/1000));
				GAME_func.remove(e.rm);
			}else{
				if (parseInt(ptext.split(" ")[0])>e.answer){
					if (parseInt(ptext.split(" ")[0])<e.highlimit){
					game_in_charge.forEach((f,index)=>{if(f.rm==e.rm)game_in_charge[index].highlimit = parseInt(ptext.split(" ")[0])});
					sendChatMessageQueue("[acid]Room "+e.rm+" [sky]数字炸弹， 范围： "+e.lowlimit+" - "+ parseInt(ptext.split(" ")[0]));
					}else{
					sendChatMessageQueue("[acid]Room "+e.rm+" [red]范围错误；数字炸弹， 范围： "+e.lowlimit+" - "+ e.highlimit);
					}
				}else{
					if (parseInt(ptext.split(" ")[0])>e.lowlimit){
					game_in_charge.forEach((f,index)=>{if(f.rm==e.rm)game_in_charge[index].lowlimit = parseInt(ptext.split(" ")[0])});
					sendChatMessageQueue("[acid]Room "+e.rm+" [sky]数字炸弹， 范围： "+ parseInt(ptext.split(" ")[0])+" - "+e.highlimit);
					}else{
					sendChatMessageQueue("[acid]Room "+e.rm+" [red]范围错误；数字炸弹， 范围： "+ e.lowlimit+" - "+e.highlimit);	
					}		
				}
			}
			break;
			case "math":
			if(eval(e.answer) == ptext.split(" ")[0]){
				sendChatMessageQueue("[acid]Room "+e.rm+" [sky]玩家 "+pname+" [sky]算出了正确答案! 时间为: "+Math.round((Date.now()-e.time)/1000));
				GAME_func.remove(e.rm);
			}
			break;
			}
		})
	}
}

function RTSfindpos(x1,y1,r1){
	for (var x=x1;x<x1+r1;x++)for (var y=y1;y<y1+r1;y++){
		if(!Vars.world.tile(x,y).build)return Vars.world.tile(x,y);
	}
	for (var x=x1;x<x1+r1;x--)for (var y=y1;y<y1+r1;y++){
		if(!Vars.world.tile(x,y).build)return Vars.world.tile(x,y);
	}
	for (var x=x1;x<x1+r1;x++)for (var y=y1;y<y1+r1;y--){
		if(!Vars.world.tile(x,y).build)return Vars.world.tile(x,y);
	}
	for (var x=x1;x<x1+r1;x--)for (var y=y1;y<y1+r1;y--){
		if(!Vars.world.tile(x,y).build)return Vars.world.tile(x,y);
	}
}

var removedRTSUnit=[];
function RTScommand2(){
	if(!Vars || !Vars.control || !Vars.control.input || Vars.control.input.selectedUnits.size==0)return;
	var healthid = Vars.control.input.selectedUnits.toArray().filter(q=>(q.health/q.maxHealth*100)<_qt.RTShealth);
	removedRTSUnit.concat(healthid);
	if(healthid.length==0)return;
	var repair = Vars.indexer.findClosestFlag(healthid[0].x,healthid[0].y,Vars.player.team(),BlockFlag.repair);
	if(!repair){Vars.ui.announce("Pt-E RTS自动撤离 [red]找不到修复器");return;}
	var okpos = RTSfindpos(repair.x/8,repair.y/8,Math.floor(repair.block.repairRadius/12));
	if(!okpos)return;
	Call.commandUnits(Vars.player,healthid.map(q=>q.id),null,null,new Vec2(okpos.x*8,okpos.y*8));
	Vars.control.input.selectedUnits = new Seq(Vars.control.input.selectedUnits.toArray().filter(q=>!healthid.includes(q)).concat(removedRTSUnit.filter(q=>(q.health/q.maxHealth)>0.95)));
	removedRTSUnit = removedRTSUnit.filter(q=>(q.health/q.maxHealth)<0.95);
}

Events.on(EventType.BlockDestroyEvent, cons(e => {
if(_qt.core_tips&&(e.tile.build instanceof CoreBlock.CoreBuild)){
		sendChatMessageQueue("[sky]游戏时间　"+Math.trunc(Vars.state.tick/3600)+"："+Math.trunc(Vars.state.tick/600%6)+Math.trunc(Vars.state.tick/60%10)+"[#"+e.tile.team().color.toString()+(e.tile.team()!= Vars.player.team()?"] ":"]  \x03我方 ")+e.tile.team().localized()+"队 核心[#ff0000] ["+e.tile.x+" , " + e.tile.y + "][] 被打爆了！  \x03核心剩余："+(e.tile.team().cores().size-1)+" 个")
	}
}));



Events.on(EventType.ClientLoadEvent, 
cons(e => {
	延迟();
	if(_qt.mainmenu_menu)popup_settings();
	Vars.maxSchematicSize=1024;
	Vars.renderer.minZoom=0.06;
	Vars.renderer.maxZoom=25;
	//缩放加强
Vars.ui.hudGroup.fill(cons(t => {
t.name = "PT_MENU";
t.top().right().marginTop(190);
var k = new Table();
k.name = "PT_MENU2";
k.button(Icon.terminal,Styles.clearTogglei,e=>{if(playerAI){playerAI = null;}else{AItype(AImode)}}).update(b=>b.setChecked(!!playerAI)).width(45).height(45);
k.button(Icon.menu,Styles.cleari,e=>{popup_settings("");}).width(45).height(45);
t.add(k).right().row();
}));
}));



function hasAmmo(build){
	if(build.block instanceof PowerTurret || build.block instanceof PointDefenseTurret || build.block instanceof TractorBeamTurret){return build.power.status>0;}
	if(build.block instanceof Turret){return build.hasAmmo();}
	return false;
}

Events.run(Trigger.draw, () => {
	if(_qt.remove_blueprint)Vars.state.rules.schematicsAllowed=true;
	//TODO: customize fog render
	Vars.state.rules.fog=FOGRENDER;
	Vars.state.rules.staticFog=FOGRENDER;
	
	var minx = (Core.camera.position.x-(Core.camera.width/1.6));
	var maxx = (Core.camera.position.x+(Core.camera.width/1.6));
	var xh = Core.camera.width*1.1;
	var miny = (Core.camera.position.y-(Core.camera.height/1.6));
	var maxy = (Core.camera.position.y+(Core.camera.height/1.6));
	var yh = Core.camera.height*1.1;
	
	if(_qt.dropzone){
		Vars.spawner.getSpawns().each(q=>{
			Lines.dashCircle(q.worldx(), q.worldy(), Vars.state.rules.dropZoneRadius)
		});
	}
	
	if(_qt.fix_range||_qt.boost_range){
	const overdrive=[Blocks.overdriveProjector,Blocks.overdriveDome];
	const mend = [Blocks.mender,Blocks.mendProjector];
	const big = [].concat(_qt.boost_range?overdrive:[]).concat(_qt.fix_range?mend:[]);
	Vars.indexer.eachBlock(Vars.player.team(),Rect(minx,miny,xh,yh),
	f=>big.includes(f.block)&&f.efficiency>0,
	e=>{
	Drawf.dashCircle(e.x,e.y,e.range() + e.phaseHeat * e.block.phaseRangeBoost,e.block.baseColor);
	Draw.color(e.block.baseColor);
	Draw.alpha(mend.includes(e.block)?0.05:0.15);
	Fill.circle(e.x,e.y,e.range() + e.phaseHeat * e.block.phaseRangeBoost);
	});
	}
	
	if(_qt.playercursor){
	Groups.player.each(e=>{
		if(!e.shooting)Draw.color(1,1,1,0.5);else Draw.color(1,0,0,0.5);
		Lines.line​(e.x,e.y,e.mouseX,e.mouseY);
	});
	}
	
	if(_qt.ground_range||_qt.air_range){
	var xmax = Math.max(Core.camera.height*1.1,Core.camera.width*1.1,500);
	Vars.indexer.allBuildings(Core.camera.position.x,Core.camera.position.y,xmax,f=>{
		if(f.block && f.block instanceof Turret && hasAmmo(f) && f.team!=Vars.player.team()){
			if((_qt.air_range&&f.block.targetAir)||(_qt.ground_range&&f.block.targetGround)){
				var color=Color.red;
				if(f.block.targetAir && !f.block.targetGround)color=Color.green;
				if(!f.block.targetGround && f.block.targetGround)color=Color.yellow;
			Drawf.dashCircle(f.x,f.y,f.range(),color);
			Draw.color(color);
			Draw.alpha(0.05);
			Fill.circle(f.x,f.y,f.range());
			}
		}
	});
	
	if(_qt.unitrange)
	Groups.unit.each(w=>w.team!=Vars.player.team()&& minx<w.x && w.x<maxx && miny<w.y && w.y<maxy && w.type.canAttack,q=>{
		var color=Color.red;
			if(q.type.targetAir && !q.type.targetGround)color=Color.green;
			if(!q.type.targetGround && q.type.targetGround)color=Color.yellow;
		Drawf.dashCircle(q.x,q.y,q.range(),color);
		Draw.color(color);
		Draw.alpha(0.05);
		Fill.circle(q.x,q.y,q.range());
	})
	
	}
	
	Draw.color(1,1,1,1);
	if(_qt.ore_show){
		Draw.draw(Layer.block+0.01, run(()=>{
			var camera = Core.camera;
			var avgx = Math.floor(camera.position.x / Vars.tilesize);
			var avgy = Math.floor(camera.position.y / Vars.tilesize);
			var rangex = Math.floor(camera.width / Vars.tilesize / 2) + 3;
			var rangey = Math.floor(camera.height / Vars.tilesize / 2) + 3;
			var minx = Math.max(avgx - rangex - 1, 0);
			var miny = Math.max(avgy - rangey - 1, 0);
			var maxx = Math.min(Vars.world.width() - 1, avgx + rangex + 1);
			var maxy = Math.min(Vars.world.height() - 1, avgy + rangey + 1);
			
			for(var x = minx; x <= maxx; x++){
				for(var y = miny; y <= maxy; y++){
					var tile = Vars.world.rawTile(x,y);
					if(!tile.build){
						continue;
					}
					var tb = tile.drop();
					if(tb){
						Draw.rect(tb.fullIcon,tile.drawx(),tile.drawy());
					}
				}
			}
		}));
	}
})

Events.on(WorldLoadEvent, () => {
	_popupcatch=true;
	wayptAI.wayptlist=[];
	_valid_msg = null;
	Vars.player.unit().plans.clear();
	Vars.ui.chatfrag.addMessage(((_qt.language==0)?"欢迎使用[red][Pt=E][white]mod版本":"歡迎使用[red][Pt=E][white]mod版本")+_modv);
	if(cnarc)Vars.ui.chatfrag.addMessage("已侦测到你同时使用[gray]CNARC[white]以及 [red][[PT=E]\n[white]请转用[acid]原端[white]或其他端继续使用[red][[PT=E]\n[white]感谢你的支持! :)")
});

function AItype(e){
	switch(e){
		case 1:
		playerAI = global.pt0.minerAI.data;
		playerAI.unitS(Vars.player.unit());
		break;
		case 2:
		playerAI = new BuilderAI();
		playerAI.unit(Vars.player.unit());
		break;
		case 3:
		playerAI = global.pt0.builder2AI.data;
		playerAI.unitS(Vars.player.unit());
		break;
		case 6:
		playerAI = global.pt0.followingAI.data;
		playerAI.unitS(Vars.player.unit());
		break;
		case 4:
		playerAI = wayptAI;
		playerAI.unitS(Vars.player.unit());
		break;
		case 8:
		playerAI = global.pt0.followbuildAI.data;
		playerAI.unitS(Vars.player.unit());
		break;	
	}
}
var playerAI = null;
var hiddenUnit=[];

Events.run(Trigger.update, () => {
	//pan cam
	if(follow_cam && follow_cam.unit()){
	if(Vars.control.input.panning || Vars.control.input instanceof MobileInput){Core.camera.position.set(follow_cam.unit());}else{follow_cam=null;}
	}
	if(Vars.control.input instanceof MobileInput){Core.input.getInputProcessors().get(4).targetPos=Vec2(Vars.player.x,Vars.player.y)}
	//拆建筑辅助器
	if(Vars.player.unit().plans.size>1 && _qt.pvp_destruct)
	if(Vars.player.unit().plans.first().progress!=0 && Vars.player.unit().plans.get(1).progress==0){
	Vars.player.unit().plans.addLast(Vars.player.unit().plans.first());
	Vars.player.unit().plans.removeFirst();
	}
	if(AImode!=0 && Vars.player.unit() && playerAI){
		playerAI.updateUnit();
		if(Vars.mobile){Core.camera.position.set(Vars.player);}
	}
	if(_qt.removeBullet||_qt.removeDecal||_qt.disableUnit)
	Groups.draw.each(d => {
	if(d instanceof Bullet && _qt.removeBullet) Groups.draw.remove(d);
	if(d instanceof Decal  && _qt.removeDecal) d.remove();
	if(d instanceof Unit){
	if(_qt.disableUnit){
		Groups.draw.remove(d);hiddenUnit.push(d);
	}
	}
	});
	if(!_qt.disableUnit && hiddenUnit.length>0){hiddenUnit.forEach(f=>{if(f.health>0)Groups.draw.add(f)});hiddenUnit=[];}
});
