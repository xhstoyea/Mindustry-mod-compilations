require("星球/离子源星");
require("星球/核心");
require('qwer');
require('辅助/缩放强化');
require('特殊/替换背景');
require("物品");
require("液体");
MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000