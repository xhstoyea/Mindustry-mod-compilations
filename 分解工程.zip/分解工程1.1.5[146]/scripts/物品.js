function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("离子电池")
newItem("欧米伽")
newItem("铜离子")
newItem("铅离子")
newItem("钛离子")
newItem("钍离子")
newItem("铜铅合金")
newItem("强化硅")
newItem("钻石")