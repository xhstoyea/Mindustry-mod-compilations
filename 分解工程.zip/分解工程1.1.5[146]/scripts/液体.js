function newLiquid(name) {
	exports[name] = (() => {
		let myLiquid = extend(Liquid, name, {});
		return myLiquid;
	})();
}
newLiquid("绝零流体")
newLiquid("欧米伽流体")
newLiquid("奇点流体")
newLiquid("离子液体")