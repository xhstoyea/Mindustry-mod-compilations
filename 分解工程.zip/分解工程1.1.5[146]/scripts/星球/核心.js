const 离子核心 = new CoreBlock('离子核心');
exports.离子核心 = 离子核心;