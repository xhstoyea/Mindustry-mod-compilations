Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("[red]分解工程分析报告");
    dialog.cont.image(Core.atlas.find("分解工程-图片")).row();;
    dialog.buttons.defaults().size(210, 64);
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(210, 64);
    dialog.cont.pane((() => {
        var table = new Table();   
         table.add("[green]分解工程，你能体验到分解的快乐\n也能体验到更多的乐趣，这个模组制作不简单，希望你能珍惜\n如果有问题可以找作者(cat)").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
table.button("[blue]加QQ", run(() => {
    var dialog2 = new BaseDialog("[white]分解工程模组[red]作者QQ[white]二维码");
    var table = new Table();
    dialog2.cont.image(Core.atlas.find("分解工程-二维码")).row();
    dialog2.buttons.defaults().size(210, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 64);
       dialog2.show();
    })).size(210, 64).row();
table.button("[red]更新日志", run(() => {
    var dialog2 = new BaseDialog("[red]更新日志");
    var table = new Table();
	var t = new Table();
	t.add("[white]可能会新增一些更多有趣的东西\n如果想很快的体验到更新后的乐趣耐心等待即可 \n[blue]头绪:感谢qq@星星有泪3580147220的建议。 \n感谢qq@玲纱是维生素的2484910089的贴图建议。 \n作者的群qq:Mindustry分解工程mod交流群857490491 \n:-)[red]正在更新中……");
    dialog2.cont.add(new ScrollPane(t)).size(500, 600).row();
    dialog2.buttons.defaults().size(620, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(500, 64);
       dialog2.show();
    })).size(210, 64);
        return table;
    })()).grow().center().maxWidth(620);
    dialog.show();
}));