Events.on(EventType.ClientLoadEvent, cons(e => {
	var dialog = new BaseDialog("[#9CB664FF]钍工业");
	dialog.buttons.defaults().size(210, 64);
	dialog.buttons.button("@close", run(() => {
		dialog.hide();
	})).size(210, 64);
	dialog.cont.pane((() => {
		var table = new Table();
		table.add("[#9CB664FF]欢迎来玩钍工业模组!\n这是一个灰常辣鸡的模组![doge] \n进QQ群556163877来van").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
		table.row();
		table.button("[green]你点一下", run(() => {
			var dialog2 = new BaseDialog("[green]更新日志");
			var table = new Table();
			dialog2.cont.add("[yellow]当前版本v30\n工厂\n更新了普通电路板制作厂\n二阶电路板制作厂\n三阶电路板制作厂\n四阶电路板制作厂\n电力\nt2钍反应堆\n物品\n电路板\n钛电路板\n合金电路板\n绝缘晶体电路板\n数据\n削弱T－31防空炮\n削弱GCT气体炮\n快来群556163877一起来van啊\n这也会鸽").row();;
			dialog2.buttons.defaults().size(210, 64);
			dialog2.buttons.button("@close", run(() => {
				dialog2.hide();
			})).size(210, 64);
			dialog2.show();
		})).size(210, 64);
		return table;
	})()).grow().center().maxWidth(620);
	dialog.show();
}));