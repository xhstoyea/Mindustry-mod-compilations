const lib = require("钍工业lib");
const 塞尔塔 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(塞尔塔, 4));
        this.super$load();
    }
}, "塞尔塔", Planets.sun, 1);
const sS = require("sectorSize");
sS.planetGrid(塞尔塔, 3.3);
//上面的是区块大小 ▲ 正常是3.3不建议乱改
塞尔塔.generator = new SerpuloPlanetGenerator();
//可以将[Erekir]改成任何游戏中有的星球
塞尔塔.atmosphereColor = Color.valueOf("#00cccc");//大气颜色
塞尔塔.atmosphereRadIn = 0.09;//？？？
塞尔塔.atmosphereRadOut = 0.3;//密度？
塞尔塔.localizedName = "塞尔塔-[废料产地]";;
塞尔塔.visible = true;//能否看得见
塞尔塔.bloom = false;//这个不确定
塞尔塔.accessible = true;//可达到？
塞尔塔.alwaysUnlocked = true;//始终未锁定
塞尔塔.startSector = 2;//开始的地方数量
塞尔塔.orbitRadius = 100;//距离太阳
塞尔塔.rotateTime = 2400;//一昼夜的时间(s)
//----分界线----从这往下可以复制增加区块
const 开局进攻图 = new SectorPreset("开局进攻图", 塞尔塔, 23);
开局进攻图.alwaysUnlocked = true;
开局进攻图.captureWave = 30;
开局进攻图.difficulty = 3;
开局进攻图.localizedName = "开局进攻图";
exports.开局进攻图 = 开局进攻图;
lib.addToResearch(开局进攻图, {
    parent: 'planetaryTerminal',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.groundZero))
});
//---------分----界----线---------------
//防呆列表
//（塞尔塔）随便写算是星球的名字
//想改turn或false的酌情使用,最好翻译一下
//想加新的区块可以复制上面的
//请不要乱改sectorSize.js
//记得自己加地图到外面的maps文件夹里
//
//
