//作者VSHES/荔枝 qq2595168568 未经允许禁止私自使用别删此行如果在其他mod见到此文件切未经过授权后果自负
const HealCore = new Effect(100, e =>{
     Draw.color(Color.valueOf('8BE8AAFF'));
     Fill.square(e.x,e.y,e.fslope() * 1.5 + 0.14, 45);
});

const item = require("物品");

const 自塑 = new UnitType("自塑");
Object.assign(自塑, {
    coreUnitDock : true,
	aiController: UnitTypes.evoke.aiController,
	isEnemy: false,
	fogRadius: 0,
	lowAltitude: true,
	flying: true,
	mineSpeed: 5,
	mineHardnessScaling: false,
	mineTier: 1,
	buildSpeed: 1,
	drag: 0.05,
	speed: 3,
	rotateSpeed: 15,
	accel: 0.1,
	itemCapacity: 40,
	health: 150,
	engineOffset: 7,
	hitSize: 8,
	alwaysUnlocked: true,
	targetable : false,
    hittable : false,
	constructor: () => new UnitEntity.create(),
})
自塑.weapons.add(
Object.assign(new RepairBeamWeapon(), {
	top: true,
	mirror: false,
	rotate: false,
	widthSinMag: 0.11,
	beamWidth: 0.7,
    repairSpeed: 3.1,
    fractionRepairSpeed: 0.06,
	x: 0,
	y: 3,
	reload: 20,
	targetUnits: false,
    targetBuildings: true,
    autoTarget: false,
    controllable: true,
	bullet: Object.assign(new BulletType(), {
        maxRange: 60,
	})
})
)

const 自塑核心 = new CoreBlock('core-自塑核心');
自塑核心.size = 3;
自塑核心.health = 1500;
自塑核心.configurable = true;
自塑核心.buildVisibility = BuildVisibility.shown;
自塑核心.category = Category.effect;
自塑核心.solid = true;
自塑核心.update = true;
自塑核心.unitType = 自塑;
自塑核心.itemCapacity = 3000;
自塑核心.unitCapModifier = 10;
自塑核心.destructible = true;
自塑核心.requirements = ItemStack.with(
    Items.graphite, 1500,
    item.钴, 1200,
);
自塑核心.buildType = prov(() =>
    extend(CoreBlock.CoreBuild, 自塑核心,{
      i : 0,
        update() {
            this.super$update();
            this.i += Time.delta;
            if(this.health < 1500){
                    this.health += 1500/18000;
                    if(this.i == 0.5){
                    HealCore.at(this.x + Mathf.range(3 * Vars.tilesize / 2 - 1), this.y + Mathf.range(3 * Vars.tilesize / 2 - 1));
                      }
                    if(this.i >= 8.5){
                    HealCore.at(this.x + Mathf.range(3 * Vars.tilesize / 2 - 1), this.y + Mathf.range(3 * Vars.tilesize / 2 - 1));
                    this.i = 0;
                      }
                    }
               else{
                           this.health = 1500;
               }
        },
}));
exports.自塑核心 = 自塑核心;