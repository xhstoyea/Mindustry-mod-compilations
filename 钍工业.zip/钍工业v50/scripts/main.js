MapResizeDialog.
minSize = 0
MapResizeDialog.maxSize = 40000
require("塞尔塔");
require("简介");