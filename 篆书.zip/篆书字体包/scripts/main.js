const FreeTypeFontGenerator = Packages.arc.freetype.FreeTypeFontGenerator
const AssetManager = Packages.arc.assets.AssetManager

const ROOT = Vars.mods.locateMod(modName).root;

function registerFont(raw, file) {
    Reflect.invoke(AssetManager, Core.assets, "addAsset",
        [raw + ".gen", FreeTypeFontGenerator, new FreeTypeFontGenerator(file)],
        Packages.java.lang.String, Packages.java.lang.Class, Packages.java.lang.Object
    )
}

registerFont("fonts/font.woff", ROOT.child("cao.woff"))
registerFont("fonts/tech.ttf", ROOT.child("cao.ttf"))
