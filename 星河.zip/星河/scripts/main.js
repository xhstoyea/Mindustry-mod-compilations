MapResizeDialog.minSize = 50
MapResizeDialog.maxSize = 50000
require("xhitems");
require("xhliquids");
require("blocks/大型熔炼炉")
require("blocks/高级装配站")
require("blocks/临时核心")
require("blocks/弹药组装厂")
require("planets/桃园");