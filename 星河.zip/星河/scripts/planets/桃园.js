const xhlib = require("base/xhlib");
const TBLY = new Planet("桃园", Planets.sun, 1, 3.3);
TBLY.meshLoader = prov(() => new MultiMesh(
	new HexMesh(TBLY, 2)
));
TBLY.generator = extend(SerpuloPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nA3JMQ6AIBAAwQXFRr9i4XuMBR5XkCAYkP9LphwcbmLO/lHMwRq0SY3vF0sGluRvTQ17XoZNStU9d0na20gDduAHAc0Org==")
	}
});
TBLY.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(TBLY, 2, 0.15, 0.14, 5, Color.valueOf("25C9AB80"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(TBLY, 3, 0.6, 0.15, 5, Color.valueOf("25C9AB"), 2, 0.42, 1.2, 0.45)
));
TBLY.generator = new SerpuloPlanetGenerator();
TBLY.visible = TBLY.accessible = TBLY.alwaysUnlocked = true;
TBLY.clearSectorOnLose = true;//
TBLY.tidalLock = true;//
TBLY.localizedName = "桃园";
TBLY.prebuildBase = true;//
TBLY.bloom = true;
TBLY.startSector = 1;
TBLY.orbitRadius = 85;
TBLY.orbitTime = 360 * 110;
TBLY.rotateTime = 70 * 50;
TBLY.atmosphereRadIn = 0.02;
TBLY.atmosphereRadOut = 0.3;
TBLY.atmosphereColor = TBLY.lightColor = Color.valueOf("25C9AB90");
TBLY.iconColor = Color.valueOf("25C9AB"),
TBLY.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems)
/*
map n head2
SC map n head2
SC map name
*/
const map1hw = new SectorPreset("登录", TBLY, 1);
map1hw.description = "这里人烟稀少，矿物相对匮乏。但也给我们在这里发展壮大的机会我们只要在意稍加隐蔽即可在这里扎稳脚跟";
map1hw.difficulty = 2;
map1hw.alwaysUnlocked = false;
map1hw.addStartingItems = true;
map1hw.captureWave = 24;
map1hw.localizedName = "登录";
exports.map1hw = map1hw;
xhlib.addToResearch(map1hw, {
	parent: "planetaryTerminal",
	objectives: Seq.with(
	new Objectives.SectorComplete(SectorPresets.planetaryTerminal))
});

const map2hw = new SectorPreset("进军", TBLY, 2);
map2hw.description = "这里的敌人只有大概几只t4实力那么大,但绝不可以掉以轻心，以免招来更强大的敌人。";
map2hw.difficulty = 6;
map2hw.alwaysUnlocked = false;
map2hw.addStartingItems = true;
map2hw.captureWave = 34;
map2hw.localizedName = "进军";
exports.map2hw = map2hw;
xhlib.addToResearch(map2hw, {
	parent: "登录",
	objectives: Seq.with(
	new Objectives.SectorComplete(map1hw))
})
