function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("铁");
newItem("钢铁");
newItem("火药");
newItem("精炼钢");
newItem("精炼钛");
newItem("精炼铜");
newItem("精炼金");
newItem("金");
newItem("超导体");
newItem("电动机");
newItem("高爆弹");
newItem("电磁弹");
newItem("红宝石");
newItem("硝");
newItem("硫");
newItem("电路板");
newItem("塑料");
newItem("电子管");
newItem("晶体管");
newItem("芯片");
newItem("集成电路");
newItem("铀");
newItem("浓缩铀");
newItem("齿轮");
newItem("氢");
newItem("氧");
newItem("引擎");
newItem("钛合金");
newItem("子弹");
newItem("炮弹");
newItem("碳纤维");
newItem("碳织布");