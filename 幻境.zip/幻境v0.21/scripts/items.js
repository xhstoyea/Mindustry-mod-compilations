function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("幻钢")
newItem("幻钛钢")
newItem("幻荧合金")
newItem("玄晶")
newItem("翼精金属")
newItem("翼石")
newItem("荧羽石")
newItem("有机玻璃")
newItem("纳米碳合金")
newItem("玄钢")