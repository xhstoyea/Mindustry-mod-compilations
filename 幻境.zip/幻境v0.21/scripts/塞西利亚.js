const lib = require("lib");
const 塞西利亚 = new Planet("塞西利亚", Planets.sun, 1, 3.3);
塞西利亚.meshLoader = prov(() => new MultiMesh(
	new HexMesh(塞西利亚, 6)
));
塞西利亚.generator = extend(SerpuloPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nA3JMQ6AIBAAwQXFRr9i4XuMBR5XkCAYkP9LphwcbmLO/lHMwRq0SY3vF0sGluRvTQ17XoZNStU9d0na20gDduAHAc0Org==")
	}
});
塞西利亚.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(塞西利亚, 2, 0.15, 0.14, 5, Color.valueOf("97B5EDFF"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(塞西利亚, 3, 0.6, 0.15, 5, Color.valueOf("97B5EDFF"), 2, 0.42, 1.2, 0.45)
));;
塞西利亚.generator = new SerpuloPlanetGenerator();
塞西利亚.visible = 塞西利亚.accessible = 塞西利亚.alwaysUnlocked = true;
塞西利亚.clearSectorOnLose = false;
塞西利亚.tidalLock = false;
塞西利亚.localizedName = "塞西利亚";
塞西利亚.prebuildBase = false;
塞西利亚.bloom = false;
塞西利亚.startSector = 1;
塞西利亚.orbitRadius = 40;
塞西利亚.rotateTime = 3000;
塞西利亚.atmosphereRadIn = 0.02;
塞西利亚.atmosphereRadOut = 0.3;
塞西利亚.atmosphereColor = 塞西利亚.lightColor = Color.valueOf("97B5EDFF");
塞西利亚.iconColor = Color.valueOf("97B5EDFF"),
塞西利亚.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);

const 降落区 = new SectorPreset("降落区", 塞西利亚, 1);
降落区.description = "我军在平叛的时候在经过这个星系的时候己方舰队和敌方舰队遭遇到了，我军舰队规模较小，被全部击沉，但敌方也因为受损过于严重，需要大量的时间来进行重建和修复，我们得拿下这块薄弱的地区，这样我们才能在这颗星球上生存下去"
降落区.alwaysUnlocked = true;
降落区.addStartingItems = true;
降落区.captureWave = 0;
降落区.difficulty = 2;
降落区.localizedName = "降落区";
exports.降落区 = 降落区;
lib.addToResearch(降落区, {
    parent: 'planetaryTerminal',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.groundZero))
});

const 深幽丛林 = new SectorPreset("深幽丛林", 塞西利亚, 8);
深幽丛林.description = "我们沿着着陆区深处走，走到了一片深幽的丛林，这里似乎有敌人存在过的痕迹，摧毁敌人的基地并防御来自塞普罗与埃里克尔的追击，不要放松，保持警惕"
深幽丛林.alwaysUnlocked = false;
深幽丛林.addStartingItems = true;
深幽丛林.captureWave = 81;
深幽丛林.difficulty = 6;
深幽丛林.localizedName = "深幽丛林";
exports.深幽丛林 = 深幽丛林;
lib.addToResearch(深幽丛林, {
    parent: '降落区',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.groundZero))
});

const 深幽丛林2 = new SectorPreset("深幽丛林2", 塞西利亚, 12);
深幽丛林2.description = "利用匮乏的资源防守"
深幽丛林2.alwaysUnlocked = false;
深幽丛林2.addStartingItems = true;
深幽丛林2.captureWave = 82;
深幽丛林2.difficulty = 8;
深幽丛林2.localizedName = "深幽丛林2";
exports.深幽丛林2 = 深幽丛林2;
lib.addToResearch(深幽丛林2, {
    parent: '深幽丛林',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.groundZero))
});

const 凛冬冰谷 = new SectorPreset("凛冬冰谷", 塞西利亚, 16);
凛冬冰谷.description = "我们摆脱了敌人的部分追兵，但更强的威胁正在追赶着我们，我们一路向北逃到了北极地区，但我们似乎自投罗网了"
凛冬冰谷.alwaysUnlocked = false;
凛冬冰谷.addStartingItems = true;
凛冬冰谷.captureWave = 41;
凛冬冰谷.difficulty = 8;
凛冬冰谷.localizedName = "凛冬冰谷";
exports.凛冬冰谷 = 凛冬冰谷;
lib.addToResearch(凛冬冰谷, {
    parent: '深幽丛林',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.groundZero))
});

const 交叉冰谷 = new SectorPreset("交叉冰谷", 塞西利亚, 20);
交叉冰谷.description = "防守来自叛军的攻击"
交叉冰谷.alwaysUnlocked = false;
交叉冰谷.addStartingItems = true;
交叉冰谷.captureWave = 41;
交叉冰谷.difficulty = 8;
交叉冰谷.localizedName = "交叉冰谷";
exports.交叉冰谷 = 交叉冰谷;
lib.addToResearch(交叉冰谷, {
    parent: '凛冬冰谷',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.groundZero))
});;

const 普里港口 = new SectorPreset("普里港口", 塞西利亚, 24);
普里港口.description = "我们一路南下来到了一处港口，这里似乎没有什么防御且资源丰富，我们可以占领这里，但追兵来的更猛烈了，我们之间好像出现了叛军，他们不合我们的意见，他们认为我们一路逃跑还不如在一个地方发展"
普里港口.alwaysUnlocked = false;
普里港口.addStartingItems = true;
普里港口.captureWave = 51;
普里港口.difficulty = 8;
普里港口.localizedName = "普里港口";
exports.普里港口 = 普里港口;
lib.addToResearch(普里港口, {
    parent: '凛冬冰谷',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.groundZero))
});

const 尔利罗群岛 = new SectorPreset("尔利罗群岛", 塞西利亚, 32);
尔利罗群岛.description = "我们沿着小路走了很久，来到一处资源富饶的群岛，但我们似乎被敌人包围了，赶快加强防御抵御四周来敌"
尔利罗群岛.alwaysUnlocked = false;
尔利罗群岛.addStartingItems = true;
尔利罗群岛.captureWave = 61;
尔利罗群岛.difficulty = 10;
尔利罗群岛.localizedName = "尔利罗群岛";
exports.尔利罗群岛 = 尔利罗群岛;
lib.addToResearch(尔利罗群岛, {
    parent: '普里港口',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.groundZero))
});

const 寂静盆地 = new SectorPreset("寂静盆地", 塞西利亚, 40);
寂静盆地.description = "我们艰难的守下了敌军的攻击，来自敌人更加快速猛烈了，但我们的支援已经来了，这里矿产资源丰富，尽快发展科技"
寂静盆地.alwaysUnlocked = false;
寂静盆地.addStartingItems = true;
寂静盆地.captureWave = 36;
寂静盆地.difficulty = 12;
寂静盆地.localizedName = "寂静盆地";
exports.寂静盆地 = 寂静盆地;
lib.addToResearch(寂静盆地, {
    parent: '尔利罗群岛',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.groundZero))
});

const 荧幻群山 = new SectorPreset("荧幻群山", 塞西利亚, 48);
荧幻群山.description = "我们艰难的守下了寂静盆地，忽然听到远处传来的战斗声，我们朝着声音的方向前进，是我方与SE方在抢夺一块具有稀有矿物的地区，帮助我方开发并守下这块地区，并抵御来自SE方的精英单位"
荧幻群山.alwaysUnlocked = false;
荧幻群山.addStartingItems = true;
荧幻群山.captureWave = 51;
荧幻群山.difficulty = 12;
荧幻群山.localizedName = "荧幻群山";
exports.荧幻群山 = 荧幻群山;
lib.addToResearch(荧幻群山, {
    parent: '寂静盆地',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.groundZero))
});

const 三叶峡谷 = new SectorPreset("三叶峡谷", 塞西利亚, 56);
三叶峡谷.description = "利用匮乏的资源防守"
三叶峡谷.alwaysUnlocked = false;
三叶峡谷.addStartingItems = true;
三叶峡谷.captureWave = 61;
三叶峡谷.difficulty = 14;
三叶峡谷.localizedName = "三叶峡谷";
exports.三叶峡谷 = 三叶峡谷;
lib.addToResearch(三叶峡谷, {
    parent: '荧幻群山',
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.groundZero))
});