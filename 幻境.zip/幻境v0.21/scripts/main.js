MapResizeDialog.minSize = 50
MapResizeDialog.maxSize = 50000
require("blocks/分类桥");
require("items");
require("lib");
require("blocks/初代核心完备型")
require("blocks/基站核心")
require("blocks/终端核心")
require("blocks/终焉核心")
require("blocks/基座核心")
require("塞西利亚");
const ContinuousChainTurret = require('blocks/ContinuousChainTurret')
const AdaptiveWall = require('blocks/AdaptiveWall');


function consume(block,consume) {
  if (block.consume instanceof ConsumePower) {
    //there can only be one power consumer
    block.consumeBuilder.removeAll(cons(b => b instanceof ConsumePower));
    block.consPower = consume;
  }
  block.consumeBuilder.add(consume);
  return consume;
}

const adaptiveWall = AdaptiveWall('联合墙', {
  size: 1,
  health: 400,
  //标记，gname值相同的blocks会共享血量
  gname: 'adaptive',
  category: Category.defense,
  buildVisibility: BuildVisibility.shown,
  update: true,
  configurable: true,
  alwaysUnlocked: true,
  requirements: ItemStack.with(Items.graphite, 6)
});
const largeAdaptiveWall = AdaptiveWall('大型联合墙', {
  size: 2,
  health: 1200,
  //标记，gname值相同的blocks会共享血量
  gname: 'adaptive',
  category: Category.defense,
  buildVisibility: BuildVisibility.shown,
  update: true,
  configurable: true,
  alwaysUnlocked: true,
  requirements: ItemStack.with(Items.graphite, 24)
});

const hunter = ContinuousChainTurret('追猎', function() {
  this.size = 2
  this.health = 600
  this.category = Category.turret
  this.hasPower = true
  this.range = 220
  this.buildVisibility = BuildVisibility.shown
  this.update = true
  this.alwaysUnlocked = true
  this.requirements = ItemStack.with(Items.silicon, 300)

  consume(this,new ConsumePower(6, 0.0, false));
})