const Basecore = extend(CoreBlock, "基座核心", {
	canBreak(tile) {
		return Vars.state.teams.cores(tile.team()).size > 1;
	},
	canReplace(other) {
		return other.alwaysReplace;
	},
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.cores(team);
	}
});

Basecore.buildType = prov(() => {
	let kill = false, num = 1, time = 60 * num;
	return extend(CoreBlock.CoreBuild, Basecore, {
		updateTile() {
			this.super$updateTile();
			if (Vars.state.teams.cores(this.team).size > 20) kill = true;
			if (kill) {
				time--
				if (time == 0) {
					this.kill();
				}
			}
		},
	})
})