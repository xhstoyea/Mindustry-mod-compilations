const myitems = require("items");

let range = 600; //俩圆半径，炮塔射程
const light = extend(ItemTurret, "曙光2", {});
const core = extend(CoreBlock, "终焉核心", {
	drawPlace(x, y, rotation, valid) {
		this.super$drawPlace(x, y, rotation, valid);
		Drawf.dashCircle(x * 5 + this.offset, y * 5 + this.offset, range, Pal.accent);
	}
});

function cool(to, from, erekir) {
	if (Liquids.cryofluid.unlockedNow()) {
		if (to.acceptLiquid(from, Liquids.cryofluid)) {
			to.handleLiquid(from, Liquids.cryofluid, 1);
		}
	} else if (Liquids.water.unlocked()) {
		if (to.acceptLiquid(from, Liquids.water)) {
			to.handleLiquid(from, Liquids.water, 1);
		}
	}
}

core.buildType = prov(() => {
	const p = new BuildPayload(light, Team.derelict); //这里写炮塔
	return extend(CoreBlock.CoreBuild, core, {
		updateTile() {
			this.super$updateTile();
			if (p.build.team != this.team) {
				p.build.team = this.team;
			}
			p.update(null, this);
			if (p.build.acceptItem(this, myitems.荧羽石) && this.team.core().items.get(myitems.荧羽石) >= 1) {
				p.build.handleItem(this, myitems.荧羽石);
				this.team.core().items.remove(myitems.荧羽石, 1);
			}
			p.set(this.x, this.y, p.build.payloadRotation);
		},
		draw() {
			this.super$draw();
				p.draw();
		},
		drawSelect() {
			this.super$drawSelect();
			Drawf.dashCircle(this.x, this.y, range, Pal.accent); //点击时显示的虚线圆
		},
		handleDamage(amount) {
			amount = Math.min(amount * 10, amount + this.block.armor);
			return Damage.applyArmor(amount / 1.055, this.block.armor); 
		}
	})
});