/***
 * 联合墙
 * 作者 森然呢Yuri 画盒豆腐
 */

function WallList() {

  let array = []

  this.push = function(entity) {
    array.push(entity)
  }

  this.find = function(entity) {
    if (entity == null) return null
    const index = array.findIndex(other => entity.pos() === other.pos());
    if (index !== -1) {
      return array[index]
    }
    return null
  }

  this.findByPos = function(pos) {
    const index = array.findIndex(other => pos === other.pos());
    if (index !== -1) {
      return array[index]
    }
    return null
  }

  this.remove = function(entity) {
    const index = array.findIndex(other => entity.pos() === other.pos());
    if (index !== -1) {
      array.splice(index, 1)
    }
  }

}

function WallData(entity) {

  if (entity) {
    this.health = entity.health
    this.max = entity.block.health
  }

  this.add = function(ent) {
    this.health += ent.health
    this.max += ent.block.health
  }

  this.set = function(h, m) {
    this.health = h
    this.max = m
    return this
  }

}

let walls = new WallList();

module.exports = function AdaptiveWall(name, overwrite) {
  if (!overwrite.gname) overwrite.gname = 'default'
  let block = extend(Wall, name, overwrite)
  block.buildType = prov(() => extend(Wall.WallBuild, block, {

    _linked: [],
    _wallData: null,
    _needUpdat: false,

    _gname: overwrite.gname,

    init: function(tile, team, shouldAdd, rotation) {
      this.super$init(tile, team, shouldAdd, rotation)
      walls.push(this)
      this._wallData = new WallData(this)
      this._linked.push(this)
      return this;
    },

    onProximityAdded: function() {
      this.super$onProximityAdded()
      /*const proximity = this.proximity;
      if (proximity.size <= 0) return
      const gname = this._gname
      const other = walls.find(proximity.get(proximity.size - 1))
      if (other && other._gname === gname && other._linked !== this._linked) {
        other._linked.forEach(entity => {
          const isDuplicate = this._linked.some(ent => ent.pos() === entity.pos());
          if (!isDuplicate) {
            this._linked.push(entity);
            this._wallData.add(entity)
          }
        });
        other._linked = this._linked
        other._wallData = this._wallData
      }*/
      this._linked.forEach(entity => {
        entity._needUpdat = true
      })
    },

    updateTile: function() {
      this.super$updateTile()
      if (this._needUpdat) {
        const gname = this._gname
        for (let i = 0; i < 4; i++) {
          const other = walls.find(this.nearby(i));
          if (other && other._gname === gname && other._linked !== this._linked) {
            other._linked.forEach(entity => {
              const isDuplicate = this._linked.some(ent => ent.pos() === entity.pos());
              if (!isDuplicate) {
                this._linked.push(entity)
                this._wallData.add(entity)
              }
            });
            other._linked = this._linked
            other._wallData = this._wallData
          }
        }
        this._needUpdat = false
      }
      this._linked.forEach(ent => {
        //防止_linked不同步
        if (ent._linked.length < this._linked.length) {
          ent._linked = this._linked
          ent._wallData = this._wallData
        }
      })
    },

    //damage方法有多种，因为js限制，需要自己判断
    damage: function() {
      let damage = 0
      if (arguments[0] instanceof Bullet) damage = arguments[2]
      else if (arguments[0] instanceof Team || !arguments[0]) damage = arguments[1]
      else damage = arguments(0)

      const data = this._wallData

      data.health -= damage
      if (data.health < 0) {
        this._linked.forEach(entity => entity.kill())
        return
      }
      this._linked.forEach(other => other.health = data.health / other._linked.length)
    },

    heal: function(amount) {
      const data = this._wallData
      if (!amount) {
        data.health = data.max
      }
      data.health += amount
      this._linked.forEach(other => other.health = data.health / other._linked.length)
    },

    remove: function() {
      this.super$remove()
      walls.remove(this);
      this._linked.forEach(entity => {
        entity._linked = [entity]
        entity._wallData = new WallData(entity)
        entity._needUpdat = true
      })
    },

    displayBars: function(table) {
      const data = this._wallData
      table.add(new Bar(prov(() => '生命值：' + Mathf.round(data.health)), prov(() => Pal.health), floatp(() => data.health / data.max)))
    },

    display: function(table) {
      this.super$display(table)
      if (Vars.player.team() == this.team) {
        table.row()
        table.table(cons(con => {
          con.defaults().growX().height(18).pad(4);
          let label = new Label('')
          label.update(() => label.setText('连接数量：' + this._linked.length))
          con.add(label);
        }))
      }
    }

  }))
  return block
}