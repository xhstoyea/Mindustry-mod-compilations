const core = extend(CoreBlock, "终端核心", {
	configurable: true 
});

function Pay(block) {
	return new BuildPayload(block, Team.derelict)
}
function cool(to, from, erekir) {
	if (Liquids.cryofluid.unlockedNow()) {
		if (to.acceptLiquid(from, Liquids.cryofluid)) {
			to.handleLiquid(from, Liquids.cryofluid, 1);
		}
	} else if (Liquids.water.unlocked()) {
		if (to.acceptLiquid(from, Liquids.water)) {
			to.handleLiquid(from, Liquids.water, 1);
		}
	}
}

core.buildType = prov(() => {
	const pays = [Pay(Blocks.spectre)];
	return extend(CoreBlock.CoreBuild, core, {
		updateTile() {
			this.super$updateTile();
			for (let p of pays) {
				let pb = p.build;
				if (pb.team != this.team) pb.team = this.team;
				p.update(null, this);
				cool(pb, this);
			}
			if (pays[0].build.acceptItem(this, Items.thorium)) {
				pays[0].build.handleItem(this, Items.thorium);
			}
			pays[0].set(this.x, this.y - 0, pays[0].build.payloadRotation)
		},
		draw() {
			this.super$draw();
			for (let p of pays) p.draw();
		},
		drawSelect() {
			this.super$drawSelect();
			Drawf.dashCircle(this.x, this.y - 0, Blocks.spectre.range, Pal.accent);
		}
	})
});