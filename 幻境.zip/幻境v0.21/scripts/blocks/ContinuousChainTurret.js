const chainBullet = extend(BulletType, 8, 8, {

  lifetime: 45,
  absorbable: false,
  hittable: false,
  impact: true,

  draw: function(b) {
    this.super$draw(b)
    const data = b.data
    if (data == null || !data.block || !data.entity) return
    const block = data.block
    const entity = data.entity
    //Drawf.laser(block._chainLineRegion, block._chainStartRegion, block._chainEndRegion, entity.x, entity.y, b.x, b.y)
    /*const angle = b.angleTo(entity.x, entity.y) - 180;
    const dst = b.dst(entity.x, entity.y);
    const
      vec1 = new Vec2().trns(angle, dst / 3),
      vec2 = new Vec2().trns(angle, dst / 3 * 2);
    Draw.color(Color.valueOf("D3806A"), Color.valueOf("FFFF8F"), b.fin());
    Lines.stroke(5 * b.fout());
    let len = Mathf.curve(b.fslope(), 0.1, 0.8) * 60 + b.fin() * 50;
    Angles.randLenVectors(b.id, 2, len, (x, y) => {
      Angles.randLenVectors(b.id / 2 + 12, 1, len, (x2, y2) => {
        Lines.curve(
          entity.x, entity.y,
          entity.x + vec1.x + x, entity.y + vec1.y + y,
          entity.x + vec2.x + x2, entity.y + vec2.y + y2,
          b.x, b.y,
          5
        );
        Drawf.tri(entity.x + vec1.x + x, entity.y + vec1.y + y, 2 * b.finpow(), 5 * b.finpow(), 90 + Time.time);
        Drawf.tri(entity.x + vec1.x + x, entity.y + vec1.y + y, 2 * b.finpow(), 5 * b.finpow(), 180 + Time.time);
        Drawf.tri(entity.x + vec1.x + x, entity.y + vec1.y + y, 2 * b.finpow(), 5 * b.finpow(), 270 + Time.time);
        Drawf.tri(entity.x + vec1.x + x, entity.y + vec1.y + y, 2 * b.finpow(), 5 * b.finpow(), 360 + Time.time);
      });
    });*/
    Draw.color(Color.valueOf("D3806A"), Color.valueOf("FFFF8F"), b.fin());
    Drawf.tri(b.x, b.y, 8 * b.finpow(), 16 * b.finpow(), 90);
    Drawf.tri(b.x, b.y, 8 * b.finpow(), 16 * b.finpow(), 180);
    Drawf.tri(b.x, b.y, 8 * b.finpow(), 16 * b.finpow(), 270);
    Drawf.tri(b.x, b.y, 8 * b.finpow(), 16 * b.finpow(), 360);
  },

  update: function(b) {
    const data = b.data
    if (data == null || !data.entity) return
  },

  hitEntity: function(b, target, health) {
    this.super$hitEntity(b, target, health)
    const data = b.data
    if (data == null || !data.entity) return
    const entity = data.entity
    if (!target.dead) {
      entity._target = target
    }
  },

  removed: function(b) {
    const data = b.data
    if (data == null || !data.block || !data.entity) return
    const entity = data.entity
    entity._canShoot = true
  },

})

module.exports = function ContinuousChainTurret(name, fun) {
  let block = extend(PowerTurret, name, {})
  block._damage = 24
  block._searchRange = 100
  fun.apply(block)
  block.shootType = chainBullet
  block.buildType = prov(() => extend(PowerTurret.PowerTurretBuild, block, {

    _canShoot: true,
    _target: null,

    draw: function() {
      this.super$draw()
      if (this._target) {
        const target = this._target
        const fin = this._target.healthf()
        const fout = 1 - fin
        const finpow = Interp.pow3Out.apply(fin);
        const
          vec1 = Tmp.v1.trns(this.rotation + 90 + Time.time, 8 * fin),
          vec2 = Tmp.v2.trns(this.rotation - 90 - Time.time, 8 * fin),
          xSpread = Mathf.range(block.xRand),
          startX = this.x + Angles.trnsx(this.rotation - 90, block.shootX + xSpread, block.shootY),
          startY = this.y + Angles.trnsy(this.rotation - 90, block.shootX + xSpread, block.shootY)
        Draw.z(Layer.effect)
        Draw.color(Color.valueOf("D3806A"), Color.valueOf("FFFF8F"), fin);
        Lines.stroke(5 * fout);
        Lines.line(startX + vec1.x, startY + vec1.y, target.x, target.y)
        Lines.line(startX + vec2.x, startY + vec2.y, target.x, target.y)
        Draw.z(Layer.overlayUI)
        for(let i=1;i<5;i++) {
          const vec3 = Tmp.v2.trns(90*i + Time.time, target.type.hitSize * 1.5).add(target.x, target.y)
          Drawf.tri(vec3.x, vec3.y, 8 * finpow, 16 * finpow, Angles.angle(vec3.x,vec3.y,target.x,target.y));
        }
        Draw.reset()
      }
    },

    updateTile: function() {
      this.super$updateTile()
      if (this._target) {
        const target = this._target
        this.turnToTarget(this.angleTo(target))
        //target.vel.set(0, 0)
        target.damage(block._damage)
        /*if (this.timer.get(4)) {
          Lightning.create(this.team, Color.valueOf("D3806A"), 10, target.x, target.y, Time.time, 10 * Time.delta)
        }*/
        if (target.dead) {
          const entity = Units.closestEnemy(this.team, target.x, target.y, block._searchRange, () => true)
          if (entity) {
            this._target = entity
          } else {
            this._target = null
          }
        }
      }
    },

    shouldTurn: function() {
      return this._target ? false : this.super$shouldTurn()
    },

    bullet: function(type, xOffset, yOffset, angleOffset, mover) {
      this.queuedBullets--;

      if (this.dead || (!block.consumeAmmoOnce && !this.hasAmmo())) return;

      let
        xSpread = Mathf.range(block.xRand),
        bulletX = this.x + Angles.trnsx(this.rotation - 90, block.shootX + xOffset + xSpread, block.shootY + yOffset),
        bulletY = this.y + Angles.trnsy(this.rotation - 90, block.shootX + xOffset + xSpread, block.shootY + yOffset),
        shootAngle = this.rotation + angleOffset + Mathf.range(block.inaccuracy + type.inaccuracy);

      let lifeScl = type.scaleLife ? Mathf.clamp(Mathf.dst(bulletX, bulletY, this.targetPos.x, this.targetPos.y) / type.range, block.minRange / type.range, this.range() / type.range) : 1;

      this.handleBullet(type.create(this, this.team, bulletX, bulletY, shootAngle, -1, (1 - block.velocityRnd) + Mathf.random(block.velocityRnd), lifeScl, { block: block, entity: this }, mover, this.targetPos.x, this.targetPos.y), xOffset, yOffset, shootAngle - this.rotation);

      (block.shootEffect == null ? type.shootEffect : block.shootEffect).at(bulletX, bulletY, this.rotation + angleOffset, type.hitColor);
      (block.smokeEffect == null ? type.smokeEffect : block.smokeEffect).at(bulletX, bulletY, this.rotation + angleOffset, type.hitColor);
      block.shootSound.at(bulletX, bulletY, Mathf.random(block.soundPitchMin, block.soundPitchMax));

      block.ammoUseEffect.at(
        this.x - Angles.trnsx(this.rotation, block.ammoEjectBack),
        this.y - Angles.trnsy(this.rotation, block.ammoEjectBack),
        this.rotation * Mathf.sign(xOffset)
      );

      if (block.shake > 0) {
        Effect.shake(block.shake, block.shake, this);
      }

      this.curRecoil = 1;
      this.heat = 1;
      this._canShoot = false

      if (!block.consumeAmmoOnce) {
        this.useAmmo();
      }
    },

    hasAmmo: function() {
      return (this._canShoot && !this._target) ? this.super$hasAmmo() : false
    },

  }))
}