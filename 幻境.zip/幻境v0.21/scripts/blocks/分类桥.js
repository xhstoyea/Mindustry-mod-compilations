var invert = false
const bridgeSorter = extend(ItemBridge, '分类桥', {
  health: 640,
  range: 6,
  size: 1,
  update: true,
  configurable: true,
  instantTransfer: true,
  category: Category.distribution,
  buildVisibility: BuildVisibility.shown,
  requirements: ItemStack.with(
    Items.silicon, 15
  ),
  buildType: prov(() => extend(ItemBridge.ItemBridgeBuild,bridgeSorter, {
  
    sortItem: null,
    
    acceptItem: function(source, item) {
      if(this.link == -1) {
        let to = this.getTileTarget(item, source, false)
        
        return to != null && to.acceptItem(this, item) && to.team == this.team;
      }else {
        return this.super$acceptItem(source,item)
      }
      
    },
    
    handleItem: function(source, item) {
      if(this.link == -1) {
        this.getTileTarget(item, source, true).handleItem(this, item)
      }else {
        this.super$handleItem(source,item)
      }
    },
    
    isSame: function(other) {
      return other != null && other.block.instantTransfer
    },
    
    getTileTarget: function(item,source,flip) {
      let dir = source.relativeTo(this.tile.x, this.tile.y)
      if (dir == -1) return null
      let to
      if (((item == this.sortItem) != invert) == this.enabled) {
        //prevent 3-chains
        if (this.isSame(source) && this.isSame(this.nearby(dir))) {
          return null
        }
        to = this.nearby(dir)
      } else {
        let a = this.nearby(Mathf.mod(dir - 1, 4))
        let b = this.nearby(Mathf.mod(dir + 1, 4))
        let ac = a != null && !(a.block.instantTransfer && source.block.instantTransfer) &&
          a.acceptItem(this, item)
        let bc = b != null && !(b.block.instantTransfer && source.block.instantTransfer) &&
          b.acceptItem(this, item)
      
        if (ac && !bc) {
          to = a
        } else if (bc && !ac) {
          to = b
        } else if (!bc) {
          return null
        } else {
          to = (this.rotation & (1 << dir)) == 0 ? a : b
          if (flip) this.rotation ^= (1 << dir)
        }
      }
      
      return to
    },
  
    buildConfiguration: function(table) {
      if(this.link == -1) {
        ItemSelection.buildTable(table, Vars.content.items(), prov(() => this.sortItem), cons(item => this.sortItem = item))
      }
    },
    
    write: function(write) {
      this.super$write(write)
      write.s(this.sortItem == null ? -1 : this.sortItem.id)
    },
    
    read: function(read,revision) {
      this.super$read(read,revision)
      this.sortItem = Vars.content.item(read.s())
    }
  
  }))
})