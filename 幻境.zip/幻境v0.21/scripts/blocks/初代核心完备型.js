const core = extend(CoreBlock, "初代核心完备型", {
	configurable: true
});

function Pay(block) {
	return new BuildPayload(block, Team.derelict)
}
function cool(to, from, erekir) {
	if (Liquids.cryofluid.unlockedNow()) {
		if (to.acceptLiquid(from, Liquids.cryofluid)) {
			to.handleLiquid(from, Liquids.cryofluid, 1);
		}
	} else if (Liquids.water.unlocked()) {
		if (to.acceptLiquid(from, Liquids.water)) {
			to.handleLiquid(from, Liquids.water, 1);
		}
	}
}

core.buildType = prov(() => {
	const pays = [Pay(Blocks.duo), Pay(Blocks.duo)];
	return extend(CoreBlock.CoreBuild, core, {
		updateTile() {
			this.super$updateTile();
			for (let p of pays) {
				let pb = p.build;
				if (pb.team != this.team) pb.team = this.team;
				p.update(null, this);
				cool(pb, this);
			}
			pays[0].build.handleItem(this, Items.silicon);
			pays[1].build.handleItem(this, Items.graphite);
			pays[0].set(this.x - 4, this.y, pays[0].build.payloadRotation);
			pays[1].set(this.x + 4, this.y, pays[1].build.payloadRotation);
		},
		draw() {
			this.super$draw();
			for (let p of pays) p.draw();
		},
		drawSelect() {
			this.super$drawSelect();
			Drawf.dashCircle(this.x - 4, this.y, Blocks.duo.range, Pal.accent);
			Drawf.dashCircle(this.x + 4, this.y, Blocks.duo.range, Pal.accent);
		}
	})
});