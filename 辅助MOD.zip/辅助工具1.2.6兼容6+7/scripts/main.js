Events.on(EventType.ClientLoadEvent, cons(e => {

    var dialog = new JavaAdapter(BaseDialog, {}, "辅助工具");
    var icon =new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find("封面", Core.atlas.find("clear")));
    dialog.shown(run(() => {
        dialog.cont.table(Tex.button, cons(t => {
            t.defaults().size(250, 45).left();
            t.button("返回", icon, Styles.cleart, run(() => {
                dialog.hide();
            }));
        t.add("修复电磁动能炮抽搐问题")
        }));
    }));
    dialog.show();
}));

require("极光");
require("lib");