function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
};
newItem("钛铅合金");
newItem("芯片");
//newItem("天蓝晶霜钢")

const 天蓝晶霜钢 = new Item("天蓝晶霜钢", Color.valueOf("8CA9E8"));
Object.assign(天蓝晶霜钢, {
    radioactivity : 0.9,
 hardness:7,
 flammability : 0.1,
  explosiveness : 0,
 charge : 0.9,
 cost: 5.3,
})
exports.天蓝晶霜钢 = 天蓝晶霜钢;
/*newItem("纳米流体桶")
newItem("泰勒合金")
newItem("莱普合金")
newItem("镄")
newItem("铬")
newItem("一级协议")
newItem("二级协议")
newItem("三级协议")
newItem("硅钢")
newItem("裂位能")
newItem("集束")
newItem("纳米核")*/


