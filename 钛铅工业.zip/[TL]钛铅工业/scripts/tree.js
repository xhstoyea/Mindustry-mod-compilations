const lib = require("lib");
const myItem = require("物品");

const { 导弹发射器 } = require("block/炮台/导弹发射器");
lib.addToResearch(导弹发射器, { parent: "hail", });