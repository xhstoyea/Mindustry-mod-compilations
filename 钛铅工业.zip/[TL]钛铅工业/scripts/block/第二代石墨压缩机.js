const myitems = require("物品");

const 第二代石墨压缩机 = extend(GenericCrafter, "第二代石墨压缩机", {});
第二代石墨压缩机.craftEffect = Fx.pulverizeMedium;
第二代石墨压缩机.hasPower = true;
第二代石墨压缩机.consumesPower = true;
第二代石墨压缩机.hasLiquids = true;
第二代石墨压缩机.hasItems = true;
第二代石墨压缩机.buildVisibility = BuildVisibility.shown;
第二代石墨压缩机.craftTime = 49.2;
第二代石墨压缩机.itemCapacity = 24;
第二代石墨压缩机.liquidCapacity = 81;
第二代石墨压缩机.size = 3;
第二代石墨压缩机.health = 340;
第二代石墨压缩机.consumeLiquid(Liquids.water, 0.17);
第二代石墨压缩机.outputItem = new ItemStack(Items.graphite, 4);
第二代石墨压缩机.consumeItems(ItemStack.with(Items.coal, 5));
第二代石墨压缩机.consumePower(1.485);
第二代石墨压缩机.requirements = ItemStack.with(
    Items.lead, 45,
    Items.graphite, 102,   
    Items.titanium, 40,
    Items.copper, 40,
    myitems.钛铅合金, 46,
    myitems.芯片, 8
);
第二代石墨压缩机.category = Category.crafting;
exports.第二代石墨压缩机 = 第二代石墨压缩机
//第二代石墨压缩机
//4煤炭+8.1水+0.87s+79.2电=3石墨