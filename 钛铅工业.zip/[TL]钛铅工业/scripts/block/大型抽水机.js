var weBoost = 1.4;
var weItem = Items.graphite;
const weUseTime = 120;
const 大型抽水机 = extend(SolidPump, "大型抽水机", {
    setStats(){
        this.stats.timePeriod = weUseTime;
        this.super$setStats();
        this.stats.add(Stat.boostEffect, weBoost, StatUnit.timesSpeed);
    },
});
大型抽水机.buildType = prov(() => {
    var timer = 0;
    return new JavaAdapter(SolidPump.SolidPumpBuild, {
        updateTile(){
            this.efficiency *= this.items.get(weItem) > 0 ? weBoost : 1;
            this.super$updateTile();
            var entity = this;
            if(this.efficiency > 0){
                timer += entity.power.status * entity.delta();
            }
            if(timer >= weUseTime){
                entity.consume();
                timer -= weUseTime;
            }
        },        
        // efficiency(){
        //     if(!this.enabled) return 0;
        //     return this.items.get(weItem) > 0 ? weBoost : 1;
        // },
    }, 大型抽水机);
});
大型抽水机.consumePower(3);
大型抽水机.consumeItem(Items.graphite).boost();
大型抽水机.buildVisibility = BuildVisibility.shown;
exports.大型抽水机 = 大型抽水机;