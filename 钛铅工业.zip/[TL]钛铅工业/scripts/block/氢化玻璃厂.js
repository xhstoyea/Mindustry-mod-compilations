const myitems = require("物品");

const 氢化玻璃厂 = extend(AttributeCrafter, "氢化玻璃厂", {});
氢化玻璃厂.craftEffect = Fx.smeltsmoke;
氢化玻璃厂.hasPower = true;
氢化玻璃厂.consumesPower = true;
氢化玻璃厂.hasLiquids = true;
氢化玻璃厂.hasItems = true;
氢化玻璃厂.buildVisibility = BuildVisibility.shown;
氢化玻璃厂.attribute = Attribute.heat;
氢化玻璃厂.craftTime = 72;
氢化玻璃厂.itemCapacity = 60;
氢化玻璃厂.liquidCapacity = 90;
氢化玻璃厂.size = 3;
氢化玻璃厂.health = 400;
氢化玻璃厂.consumeLiquid(Liquids.water, 0.3);
氢化玻璃厂.boostScale = 0.25
氢化玻璃厂.outputItem = new ItemStack(Items.metaglass, 12);
氢化玻璃厂.consumeItems(ItemStack.with(
    Items.lead, 7,
    Items.sand, 10
));
氢化玻璃厂.consumePower(4);
氢化玻璃厂.requirements = ItemStack.with(
    Items.lead, 42,
    Items.graphite, 95,
    Items.titanium, 45,
    Items.copper, 65,
    myitems.钛铅合金, 64,
    myitems.芯片, 4
);
氢化玻璃厂.drawer = new DrawMulti(new DrawDefault(), new DrawCrucibleFlame(), new DrawHeatInput(), new DrawArcSmelt());
氢化玻璃厂.ambientSound = Sounds.smelter;
氢化玻璃厂.ambientSoundVolume = 0.07;
氢化玻璃厂.maxBoost = 2;
氢化玻璃厂.legacyReadWarmup = true;
氢化玻璃厂.minEfficiency = 0.5;
氢化玻璃厂.baseEfficiency = 1;
氢化玻璃厂.displayEfficiency = true;
氢化玻璃厂.category = Category.crafting;
exports.氢化玻璃厂 = 氢化玻璃厂