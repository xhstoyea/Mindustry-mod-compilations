const myitems = require("物品");
const 工业级巨浪合金厂 = extend(AttributeCrafter, "工业级巨浪合金厂", {});
工业级巨浪合金厂.craftEffect = Fx.smeltsmoke;
工业级巨浪合金厂.hasPower = true;
工业级巨浪合金厂.consumesPower = true;
工业级巨浪合金厂.hasLiquids = false;
工业级巨浪合金厂.hasItems = true;
工业级巨浪合金厂.buildVisibility = BuildVisibility.shown;
工业级巨浪合金厂.craftTime = 75.2562;
工业级巨浪合金厂.itemCapacity = 56;
工业级巨浪合金厂.size = 3;
工业级巨浪合金厂.attribute = Attribute.heat;
工业级巨浪合金厂.health = 759;
工业级巨浪合金厂.outputItem = new ItemStack(Items.surgeAlloy, 4);
工业级巨浪合金厂.boostScale = 1.83;
工业级巨浪合金厂.consumeItems(ItemStack.with(
    Items.copper, 9,
    Items.lead, 10,
        Items.titanium, 7,
            Items.silicon, 10
));
工业级巨浪合金厂.consumePower(12);
Object.assign(工业级巨浪合金厂,{	
	drawer: new DrawMulti(
		new DrawRegion("-bottom"),	
		Object.assign(new DrawCultivator(), {
			plantColor: Color.valueOf("FCF387"),
			plantColorLight: Color.valueOf("FCF387"),
			bottomColor: Color.valueOf("FCF387")
		}		
		),
			new DrawDefault()	
	)
})
工业级巨浪合金厂.requirements = ItemStack.with(
myitems.天蓝晶霜钢, 65,
    Items.lead, 135,
    Items.graphite, 260,
    Items.metaglass, 80,
    Items.titanium, 60,
    myitems.钛铅合金, 64,
    myitems.芯片, 13
);
工业级巨浪合金厂.category = Category.crafting;
exports.工业级巨浪合金厂 = 工业级巨浪合金厂
工业级巨浪合金厂.maxBoost = 3.042;
工业级巨浪合金厂.legacyReadWarmup = true;
工业级巨浪合金厂.minEfficiency = 0.3;
工业级巨浪合金厂.baseEfficiency = 1;
工业级巨浪合金厂.displayEfficiency = true;
//工业级巨浪合金厂:9铜+10铅+7钛+10硅+1.5s+720电=4巨浪合金