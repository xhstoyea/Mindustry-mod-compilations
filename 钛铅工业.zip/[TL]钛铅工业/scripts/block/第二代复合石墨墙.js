/*
* @author <Uenhe>
* 实际上就是把原版的力墙抄了过来, 再根据js作相应调整, 不过还是花了我一天时间...我好蔡, 悲
*/
const radius = 64
const range = 64
const shieldHealth = 1154//复合石墨墙.regenSpeed = 1;//这里的比例是1:60
//复合石墨墙.cooldown = 300;
//复合石墨墙.shieldHealth = 500;
const cooldown = 280
const cooldownBrokenBase = 1 //定义力墙接口
const 第二代复合石墨墙 = extend(CoreBlock, '第二代复合石墨墙', {
	canBreak(tile){
		if(this.team = Team.derelict) return true //灰队? 不就是用来回收资源的吗(
		return Vars.state.teams.cores(tile.team()).size > 1 //当核心数大于1时可被拆除
	},
	canPlaceOn(tile, team) {return true}, //可被放置
	init(){
		this.updateClipRadius(radius + 3)
		this.super$init()
	},
	setBars(){
		this.super$setBars()
		this.addBar('shield', func(e => new Bar(
			prov(() => Core.bundle.format('stat.shieldhealth') + ' ' + Math.floor(shieldHealth - e.buildup()) + ' / ' + shieldHealth),
			prov(() => Pal.accent),
			floatp(() => e.broken() ? 0 : 1 - e.buildup() / shieldHealth)
		).blink(Color.white)))
	}, //设置方块力墙状态栏
	setStats(){
		this.super$setStats()
		this.stats.add(Stat.shieldHealth, shieldHealth, StatUnit.none)
		this.stats.add(Stat.cooldownTime, Math.floor(shieldHealth / cooldownBrokenBase / 60), StatUnit.seconds)
		this.stats.add(Stat.range, range / Vars.tilesize, StatUnit.blocks)
	}, //设置方块详细界面力墙属性
	drawPlace(x, y, roration, vaild){
		this.super$drawPlace(x, y, roration, vaild)
		Draw.color(Pal.gray)
		Lines.stroke(3)
		Lines.poly(x * Vars.tilesize + this.offset, y * Vars.tilesize + this.offset, 6, radius)
		Draw.color(Vars.player.team().color)
		Lines.stroke(1)
		Lines.poly(x * Vars.tilesize + this.offset, y * Vars.tilesize + this.offset, 6, radius)
		Draw.color()
	} //方块放置预览力墙绘制
})
第二代复合石墨墙.buildType = prov(() => {
	var broken = true
	var buildup = 0
	var radscl = 0
	var warmup = 0
	var hit = 1 //初始化值, 其中buildup是当前力墙累计受到的伤害, 超过盾容(buildup>=shieldHealth)力墙就会破碎(broken=true)
	return new JavaAdapter(CoreBlock.CoreBuild, {
		onRemoved(){
			if(!broken && radius * radscl > 1) Fx.forceShrink.at(this.x, this.y, radius * radscl, this.team.color)
			this.super$onRemoved()
		}, 
		inFogTo(viewer) {return false},
		updateTile(){
			radscl = Mathf.lerpDelta(radscl, broken ? 0 : warmup, 0.05)
			if(Mathf.chanceDelta(buildup / shieldHealth * 0.1)) {Fx.reactorsmoke.at(this.x + Mathf.range(Vars.tilesize / 2), this.y + Mathf.range(Vars.tilesize / 2))}
			warmup = Mathf.lerpDelta(warmup, 1, 0.1)
			if(buildup > 0) {
				var scale = !broken ? cooldown : cooldownBrokenBase
				buildup -= this.delta() * scale
			}
			if(broken && buildup <= 0) {broken = false}
			if(buildup >= shieldHealth && !broken) {
				broken = true
				buildup = shieldHealth
				Fx.shieldBreak.at(this.x, this.y, radius * radscl, this.team.color)
			}
			if(hit > 0) {hit -= 1 / 5 * Time.delta}
			if(radius * radscl > 0 && !broken) {Groups.bullet.intersect(this.x - radius * radscl, this.y - radius * radscl, radius * radscl * 2, radius * radscl * 2, cons(bullet => {
				if(bullet.team != this.team && bullet.type.absorbable && Intersector.isInsideHexagon(this.x, this.y, radius * radscl * 2, bullet.x, bullet.y)) {
					bullet.absorb()
					Fx.absorb.at(bullet)
					hit = 1
					buildup += bullet.damage
				}
			}))}
		},
		broken() {return broken},
		buildup() {return buildup},
		sense(sensor){
			if(sensor == LAccess.heat) return buildup
			return this.super$sense(sensor)
		}, //当逻辑sensor这个块的heat属性时, 返回buildup的值
		draw(){
			this.super$draw()
			if(buildup > 0) {
				Draw.alpha(buildup / shieldHealth * 0.75)
				Draw.z(Layer.blockAdditive)
				Draw.blend(Blending.additive)
				Draw.blend() //去掉这个有惊喜
				Draw.z(Layer.block)
				Draw.reset()
			}
			if(!broken) {
				Draw.z(Layer.shields)
				Draw.color(this.team.color, Color.white, Mathf.clamp(hit))
				if(Core.settings.getBool('animatedshields')) {Fill.poly(this.x, this.y, 6, radius * radscl)}
				else{
					Lines.stroke(1.5)
					Draw.alpha(0.09 + Mathf.clamp(0.08 * hit))
					Fill.poly(this.x, this.y, 6, radius * radscl)
					Draw.alpha(1)
					Lines.poly(this.x, this.y, 6, radius * radscl)
					Draw.reset()
				}
			}
			Draw.reset()
		},
		write(write){
			this.super$write(write)
			write.bool(broken)
			write.f(buildup)
			write.f(radscl)
			write.f(warmup)
		},
		read(read, revision){
			this.super$read(read, revision)
			broken = read.bool()
			buildup = read.f()
			radscl = read.f()
			warmup = read.f()
		} //write和read部分可以让值被存档&读取
	}, 第二代复合石墨墙)
})
exports.第二代复合石墨墙 = 第二代复合石墨墙
