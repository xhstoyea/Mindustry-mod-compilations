const 复合石墨墙 = extend(ShieldWall, "复合石墨墙", {});
复合石墨墙.requirements = ItemStack.with(
    Items.graphite, 27,
    Items.titanium, 12,
    Items.lead, 6,
    Items.phaseFabric, 5
);
复合石墨墙.armor = 15;
复合石墨墙.chanceDeflect = 9;
复合石墨墙.flashHit = true;
复合石墨墙.insulated = false;
复合石墨墙.size = 3;
复合石墨墙.health = 4500;
复合石墨墙.absorbLasers = true;
复合石墨墙.consumePower(0.05);
复合石墨墙.outputsPower = true;
复合石墨墙.hasPower = true;
复合石墨墙.consumesPower = true;
复合石墨墙.conductivePower = true;
复合石墨墙.buildVisibility = BuildVisibility.shown;
复合石墨墙.regenSpeed = 1;//这里的比例是1:60
复合石墨墙.placeableLiquid = true;
复合石墨墙.cooldown = 300;
复合石墨墙.shieldHealth = 500;
复合石墨墙.consumePowerBuffered(4500);
复合石墨墙.category = Category.defense;
exports.复合石墨墙 = 复合石墨墙;