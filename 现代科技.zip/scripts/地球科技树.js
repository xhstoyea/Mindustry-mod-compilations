const {归鸿核心} = require("归鸿核心");
const lib = require("lib");
const {地球} = require("地球");
地球.techTree = TechTree.nodeRoot( "地球", 归鸿核心, true, run(() => {}));

			