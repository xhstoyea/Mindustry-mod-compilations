const {星际核心} = require("星际核心");
const lib = require("lib");
const {月球} = require("月球");
月球.techTree = TechTree.nodeRoot( "月球", 星际核心, true, run(() => {}));

			