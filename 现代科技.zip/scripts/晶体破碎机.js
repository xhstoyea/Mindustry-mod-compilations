const lib = require("base/lib");
const myitems = require("物品");
const 电磁脉冲 = new StatusEffect("电磁脉冲");

function r(a, m){
    return Math.round(a * Math.pow(10, m)) / Math.pow(10, m);
}

function flp(sl){
    const diff = Math.abs(sl - 7);
    return Math.max(0, 1 - diff * 0.05);
}

const 晶体破碎机 = extend(ConsumeGenerator, '晶体破碎机', {
    setStats() {
        this.super$setStats();
        this.stats.add(Stat.input, new JavaAdapter(StatValue,{
            display(table){
                table.add(new ItemDisplay(myitems.石英晶体, 1)).padRight(5).left()
                table.add("[accent] ~ ") 
                table.add(new ItemDisplay(myitems.石英晶体, 10)).padRight(5).left()
            }}))
    },
    
    setBars() {
        this.super$setBars();
        this.addBar("效率", func(e => new Bar(
            prov(() => lib.b("text-效率")),
            prov(() => Pal.ammo),
            floatp(() => e.getEfficiency())
        )));
        this.addBar("石英消耗量", func(e => new Bar(
            prov(() => lib.b("text-石英消耗量")),
            prov(() => Pal.ammo),
            floatp(() => e.getSl() / 10)
        )));
    },
});

晶体破碎机.configurable = true;
晶体破碎机.itemCapacity = 50;

晶体破碎机.buildType = prov(() => {
    let sl = 0;
    let counter = 0;
    let efficiency = 0;
    let detectCounter = 0;
    
    let dx = 2.5;
    
    return new JavaAdapter(ConsumeGenerator.ConsumeGeneratorBuild, {
        // 动态范围和状态效果
        draw() {
            this.super$draw();
            
            if(this.productionEfficiency > 0 && ++detectCounter >= 10) {
                const effectSize = (dx * sl + 3) * 8;
                const effectRange = effectSize / 2;
                
                Units.nearby(null, this.x, this.y, effectRange, unit => {
                    if(unit.team !== this.team && unit.type !== UnitTypes.block) {
                        unit.apply(电磁脉冲, effectSize);
                    }
                });
                detectCounter = 0;
            }
        },

        // 动态边框绘制
        drawSelect() {
            if (sl === 0) return;
            const size = (dx * sl + 3) * 8;
            Drawf.dashSquare(
                Color.valueOf("D3EBE0"),
                this.x, this.y, size
            );
        },

        // 配置;显示界面
        buildConfiguration(table){
            table.add("        [accent]"+lib.b("text-石英晶体消耗量")+": " + sl)
                .update(t => t.setText("        [accent]"+lib.b("text-石英晶体消耗量")+": " + sl))
                .left();
            table.row();
            table.add("        [accent]"+lib.b("text-效率")+": "+r((efficiency * 100),1)+"%")
                .left();
            table.row();
            table.add("        [accent]"+lib.b("text-石英消耗量设置")).left();
            table.row();
            table.slider(0, 10, 1, sl, g => sl = g).width(200);
        },

        // 核心逻辑，就这两行浪费了我一小时
        getEfficiency: () => efficiency,
        getSl: () => sl,

        updateTile(){
            this.super$updateTile();
            efficiency = flp(sl);
            
            const hasEnough = this.items.has(myitems.石英晶体) && 
                            this.items.get(myitems.石英晶体) >= sl;
            this.productionEfficiency = hasEnough ? 
                efficiency * (sl / 10) : 
                0;
            
            if(++counter >= 10){
                if(hasEnough){
                    this.items.remove(myitems.石英晶体, sl);
                }
                counter = 0;
            }
        },
        
        acceptItem(source, item){
            return item == myitems.石英晶体 && this.items.get(myitems.石英晶体) < this.block.itemCapacity;
        },
        
        write(write){
            this.super$write(write);
            write.i(sl);
        },
        
        read(read, revision){
            this.super$read(read, revision);
            sl = read.i();
        }
    }, 晶体破碎机);
});