Vars.renderer.minZoom = 0.1;//最小缩放尺寸
Vars.renderer.maxZoom = 50;//最大缩放尺寸
require("lib")
require("library")
require("sectorSize")
require("归鸿核心")
require("星际核心")
require("地球")
require("月球")
require("地球科技树")
require("月球科技树")
require("晶体破碎机");
require("物品")