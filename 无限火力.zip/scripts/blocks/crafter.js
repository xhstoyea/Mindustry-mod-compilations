function LightningCrafter(type, buildType, name, lightningLength, lightningLengthRand, lightningColor, lightningDamage, count, soundVolume){
	var g = extend(type, name, {
		setStats(){
			this.super$setStats();
			this.stats.add(new Stat("arcDamage", StatCat.function), lightningDamage, StatUnit.none);
			this.stats.add(new Stat("arcLength", StatCat.function), lightningLength, StatUnit.none);
			this.stats.add(new Stat("arcCount", StatCat.function), count, StatUnit.none);
		},
	});
	g.buildType = prov(() => extend(buildType, g, {
		craft() {
			this.super$craft();
			for(var i = 0; i < count; i++){
				Lightning.create(this.team, lightningColor, lightningDamage, this.x, this.y, Mathf.range(360), lightningLength + Mathf.random(lightningLengthRand));
			}
			Sounds.spark.at(this.x, this.y, 1.0, soundVolume);
		},
	}))
	return g;
};

exports.ArcSiliconSmelter = LightningCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "电弧硅炉", 6, 1, Color.valueOf("FF6B54"), 20, 1, 0.8);
exports.Magnetizer = LightningCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "a1充磁机", 6, 1, Color.valueOf("D79FFF"), 20, 1, 0.8);
exports.SuperMagnetizer = LightningCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "a3强磁机", 10, 1, Color.valueOf("B8F8FF"), 40, 1, 0.8);
exports.SuperMagnetizer = LightningCrafter(HeatCrafter, HeatCrafter.HeatCrafterBuild, "磁能冶炼机", 10, 1, Color.valueOf("B8F8FF"), 40, 2, 0.9);

