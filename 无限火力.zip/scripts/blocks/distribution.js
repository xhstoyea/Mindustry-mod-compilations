function NewOverLimitUnloader(name) {
	var u = extend(Unloader, name, {});
	u.buildType = prov(() => extend(Unloader.UnloaderBuild, u, {
		realTimer: 0.0,
		update(){
			this.unloadTimer = -1145141919810;
			this.super$update();
			
			this.realTimer += this.delta();
			var time = Math.floor(this.realTimer / u.speed);
			this.realTimer %= u.speed;
			for(var i = 0; i < time; i++){
				this.unloadTimer = u.speed;
				this.updateTile();
			}
		},
	}))
	return u
}

exports.overLimitUnloader = NewOverLimitUnloader("超限装卸器");

function NewOverLimitBridge(name) {
	var b = extend(ItemBridge, name, {});
	b.buildType = prov(() => extend(ItemBridge.ItemBridgeBuild, b, {
		handleItem(source, item){
			this.super$handleItem(source, item);
			var other = Vars.world.tile(this.link);
			if(!this.block.linkValid(this.tile, other)){
				this.doDump();
			}
		}
	}))
	return b
}
exports.magneticBridge = NewOverLimitBridge("a7磁能传送带桥");
