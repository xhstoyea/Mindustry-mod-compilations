const mb = require("无限火力/base/bullet");
const su = require("无限火力/base/stat");

function NewSpeedUpTurret(type, buildType, name, maxTime, charge){
	//此方法代码作者 pardon
	var t = extend(type, name, {
		setStats(){
			this.super$setStats();
			this.stats.add(new Stat("speedUpMaxTime", StatCat.function), maxTime, su.times);
			this.stats.add(new Stat("speedUpCharge", StatCat.function), charge, su.times);
			
			if(this.coolant != null){
				this.stats.remove(Stat.booster);
				this.stats.add(Stat.booster, StatValues.boosters(t.reload, t.coolant.amount * maxTime, t.coolantMultiplier / maxTime, true, l => l.coolant && this.consumesLiquid(l)));
			}
		},
		setBars() {
			this.super$setBars();
			this.addBar("speedUp", func(e => new Bar(
				prov(() => Core.bundle.format("bar.fastReload", Strings.fixed(e.getTime() * 100, 0))),
				prov(() => Color.valueOf("FF5845")),
				floatp(() => e.getTime())
			)));
		},
	});
	t.buildType = () => {
		var nowTime = 1.0, downTimer = 0.0;
		return extend(buildType, t, {
			getTime() {
				return (nowTime - 1) / (maxTime - 1);
			},
			baseReloadSpeed() {
				return this.efficiency * nowTime;
				//炮塔的装填速度乘上这个倍数
			},
			edelta() {
				return this.efficiency * this.delta() * nowTime;
			},
			shoot(type){
				this.super$shoot(type);
				nowTime = Math.min(nowTime + charge, maxTime);
				downTimer = 0.0;
				//炮塔射击时增加射击速度
			},
			updateTile(){
				this.super$updateTile();
				downTimer += Time.delta;
				if (downTimer >= 30 + t.reload) nowTime = Math.max(nowTime - charge / 5, 1);
				//炮塔装填完毕半秒后开始将增幅归零
			},
			//读写不能再轻易改了 不然原版有此种类炮塔的存档(或地图文件)都得损坏
		})
	};
	return t;
};

//
function NewDamageUpTurret(type, buildType, name, maxTime, charge){
	var t = extend(type, name, {
		setStats(){
			this.super$setStats();
			this.stats.add(new Stat("damageUpMaxTime", StatCat.function), maxTime, su.times);
			this.stats.add(new Stat("damageUpCharge", StatCat.function), charge, su.times);
		},
		setBars() {
			this.super$setBars();
			this.addBar("damageUp", func(e => new Bar(
				prov(() => Core.bundle.format("bar.damageUp", Strings.fixed(e.getTime() * 100, 0))),
				prov(() => Color.valueOf("FF5845")),
				floatp(() => e.getTime())
			)));
		},
	});
	t.buildType = () => {
		var nowTime = 1.0, downTimer = 0.0;
		return extend(buildType, t, {
			getTime(){
				return (nowTime - 1) / (maxTime - 1);
			},
			shoot(type){
				this.super$shoot(type);
				nowTime = Math.min(nowTime + charge, maxTime);
				downTimer = 0.0;
				//炮塔射击时增加伤害
			},
			updateTile(){
				this.super$updateTile();
				downTimer += Time.delta;
				if (downTimer >= 30 + t.reload) nowTime = Math.max(nowTime - charge / 5, 1);
				//炮塔装填完毕半秒后开始将增幅归零
			},
			handleBullet(bullet, offsetX, offsetY, angleOffset){
				bullet.damage *= nowTime;

			}
		})
	};
	return t;
};

exports.Single = NewSpeedUpTurret(ItemTurret, ItemTurret.ItemTurretBuild, "a00单管", 2.5, 0.25);
exports.Tesla = NewSpeedUpTurret(PowerTurret, PowerTurret.PowerTurretBuild, "a01特斯拉", 2.0, 0.2);
exports.StarShine = NewSpeedUpTurret(ItemTurret, ItemTurret.ItemTurretBuild, "星闪", 4.0, 0.2);
exports.StarExtinction = NewSpeedUpTurret(ItemTurret, ItemTurret.ItemTurretBuild, "星灭", 8.0, 0.3);

function newMultiBulletTurret(name, bulletTypes) {
	var t = extend(Turret, name, {
	});
	t.buildType = () => {
		return extend(Turret.TurretBuild, t, {
			shoot(type){
				this.super$shoot(type);
			},
			useAmmo(){
				return this.peekAmmo();
			},
			hasAmmo(){
				return true;
			},
			peekAmmo(){
				var subscript = Math.floor(Math.random() * bulletTypes.length);
				return bulletTypes[subscript];
			},
		})
	};
}

var RealRedImpulseGun = new PowerTurret("真红冲击枪");
RealRedImpulseGun.range = 300;
RealRedImpulseGun.reload = 45;
exports.RealRedImpulseGun = RealRedImpulseGun;
RealRedImpulseGun.buildType = () => {
	return extend(PowerTurret.PowerTurretBuild, RealRedImpulseGun, {
		handleBullet(bullet, offsetX, offsetY, angleOffset){
			/*for(var i = 0; i < 20; i++){ //12.5%的概率再发射一颗子弹 上限20颗
				if (Mathf.chance(0.875)) break;
				this.bullet(this.peekAmmo(), offsetX, offsetY, angleOffset, bullet.mover);
			}*/
			for(var i = 0; i < 20; i++){ //2%造成1000%伤害 上限10^20倍
				if(Mathf.chance(0.98)) break;
				bullet.damage *= 10;
			}
		},
		shoot(type){
			this.super$shoot(type);
			if(Mathf.chance(0.4)) { //40%立即减少40~100%攻击间隔
				this.reloadCounter += this.block.reload * (Math.random() * 0.6 + 0.4);
			}
		},
	})
}
RealRedImpulseGun.shootType = Object.assign(mb.RealRedImpulseWave(80, RealRedImpulseGun.range), {
	frontColor: Color.valueOf("EEFAFF"),
	backColor: Color.valueOf("BBCCFF"),
	knockback: 2,
	pierceCap: 7,
	damage: 100,
	speed: 7.5,
	lifetime: 900,
	width: 1,
	height: 20,
	pierceBuilding: true,
	pierce: true,
	removeAfterPierce: false,
})

exports.Horizon = newMultiBulletTurret("天顶", [
	//Blocks.duo.ammoTypes.get(Items.copper),
	//Blocks.scatter.ammoTypes.get(Items.lead),
	//Blocks.scorch.ammoTypes.get(Items.pyratite),
	Blocks.hail.ammoTypes.get(Items.graphite),
	Blocks.swarmer.ammoTypes.get(Items.surgeAlloy),
	Blocks.salvo.ammoTypes.get(Items.thorium),
	Blocks.fuse.ammoTypes.get(Items.thorium),
	Blocks.ripple.ammoTypes.get(Items.plastanium),
	Blocks.cyclone.ammoTypes.get(Items.surgeAlloy),
	Blocks.foreshadow.ammoTypes.get(Items.surgeAlloy),
	Blocks.spectre.ammoTypes.get(Items.thorium),
	Blocks.breach.ammoTypes.get(Items.beryllium),
	Blocks.diffuse.ammoTypes.get(Items.graphite),
	Blocks.disperse.ammoTypes.get(Items.tungsten),
	Blocks.titan.ammoTypes.get(Items.thorium),
	Blocks.smite.ammoTypes.get(Items.surgeAlloy),
	Blocks.malign.shootType,
	Blocks.lancer.shootType,
	//Blocks.arc.shootType,
	Blocks.afflict.shootType,
]);

var Tracking = new ItemTurret("追迹");
Tracking.range = 240;
exports.Tracking = Tracking;
Tracking.ammo(
	Items.thorium, Object.assign(mb.HomingBulletType(Tracking.range), {
		speed: 6,
		damage: 25,
		width: 8,
		height: 18,
		ammoMultiplier: 1,
		lifetime: 120,
		homingRange: 180,
		homingPower: 1.0,
		frontColor: Color.valueOf("ffaaee"),
		backColor: Color.valueOf("bb5599"),
		trailColor: Color.valueOf("ffaaee"),
		trailLength: 6,
		trailWidth: 1,
		pierceCap: 2,
		pierceBuilding: true,
		pierceArmor: true,
		buildingDamageMultiplier: 0.25
	}),
	Items.phaseFabric, Object.assign(mb.HomingBulletType(Tracking.range + 40), {
		reloadMultiplier: 0.75,
		speed: 8,
		damage: 50,
		width: 8,
		height: 18,
		ammoMultiplier: 1,
		lifetime: 180,
		homingRange: 240,
		homingPower: 1.5,
		frontColor: Color.valueOf("ffeeaa"),
		backColor: Color.valueOf("bbaa66"),
		trailColor: Color.valueOf("ffeeaa"),
		trailLength: 6,
		trailWidth: 1,
		pierceCap: 2,
		pierceBuilding: true,
		pierceArmor: true,
		rangeChange: 40,
		buildingDamageMultiplier: 0.25
	}),
);

var BlackHole = new PowerTurret("黑洞");
exports.BlackHole = BlackHole;
BlackHole.shootType = Object.assign(mb.PointBulletType(), {
	lifetime: 80,
	splashDamageRadius: 48,
	splashDamage: 200,
	fragBullets: 1,
	fragBullet: Object.assign(mb.BlackHoleBulletType(20, 60.0, Color.valueOf("ffeeaa"), 2.5, 2.0, 3.0), {
		damage: 1,
		lifetime: 600,
		frontColor: Color.valueOf("ffeeaa"),
		backColor: Color.valueOf("bbaa66"),
	}),
});

var SunFire = new PowerTurret("火阳");
exports.SunFire = SunFire;
SunFire.range = 240;
SunFire.shootType = Object.assign(mb.PointBulletType(), {
	hitEffect: Fx.flakExplosionBig,
	splashDamageRadius:32,
	splashDamage: 60,
	damage: 0,
	hitSound: Sounds.bang,
	fragBullets: 2,
	fragLifeMin: 0.5,
	fragVelocityMin: 0.4,
	fragVelocityMax: 1.0,
	fragBullet: Object.assign(mb.UncollideableBulletType(), {
		hitEffect: Fx.none,
		despawnEffect: Fx.none,
		speed: 3.0,
		lifetime: 60,
		width: 8,
		height: 8,
		drag: 0.05,
		trailWidth: 2,
		trailLength: 5,
		trailColor: Color.valueOf("FF6B54"),
		backColor: Color.valueOf("FF6B54"),
		frontColor: Color.valueOf("FF6B54"),
		hitSound: Sounds.none,
		fragBullets: 1,
		fragRandomSpread: 0,
		fragSpread: 0,
		fragAngle: 180,
		fragBullet: Object.assign(mb.LimitRangeBulletType(SunFire.range), {
			speed: 0.5,
			drag: -0.05,
			lifetime: 120,
			width: 8,
			height: 8,
			damage: 40,
			splashDamageRadius: 20,
			splashDamage: 30,
			trailWidth: 2,
			trailLength: 5,
			trailColor: Color.valueOf("FF6B54"),
			backColor: Color.valueOf("FF6B54"),
			frontColor: Color.valueOf("FF6B54"),
			homingRange: 160,
			homingPower: 0.1,
		}),
	}),
});


var Retreat = new PointDefenseTurret("退散");
const retreatVel = 50;
Retreat.buildType = prov(() => extend(PointDefenseTurret.PointDefenseBuild, Retreat, {
	updateTile(){
		this.super$updateTile();
		if(this.reloadCounter == 0){
			if(this.target != null){
				var a = this.target.angleTo(this) + 180;
				var realVel = retreatVel / this.target.damage;
				var tx = Angles.trnsx(a, realVel);
				var ty = Angles.trnsy(a, realVel);
				this.target.vel.x += tx;
				this.target.vel.y += ty;
			}else{
				this.target = Groups.bullet.intersect(this.x - this.block.range, this.y - this.block.range, this.block.range*2, this.block.range*2).min(b => b.team != this.team && b.type.hittable, b => b.dst2(this));
				this.reloadCounter += 0.001;
			}
		}
	}
}))




