const su = require("无限火力/base/stat");

//回血墙
function NewHealableWall(name, percent, amount){
	var w = extend(Wall, name, {
		setStats(){
			this.super$setStats();
			if(percent > 0) this.stats.add(new Stat("healPercent", StatCat.function), percent * 60 * 100, StatUnit.percent);
			if(amount > 0) this.stats.add(new Stat("healAmount", StatCat.function), amount * 60, StatUnit.none);
		},
	});
	w.update = true;
	w.buildType = prov(() => extend(Wall.WallBuild, w, {
		update() {
			this.super$update();
			this.heal((this.block.health * percent * Time.delta + amount * Time.delta) * this.efficiency);
		},
	}))
	return w
}

//增防墙
function NewArmorUpWall(name, percent, addArmor){
	var w = extend(Wall, name, {
		setStats(){
			this.super$setStats();
			this.stats.add(new Stat("addArmorPercent", StatCat.function), percent * 100, StatUnit.percent);
			this.stats.add(new Stat("addArmor", StatCat.function), addArmor, StatUnit.none);
		},
	});
	w.buildType = prov(() => extend(Wall.WallBuild, w, {
		handleDamage(amount) {
			if (this.health / this.block.health <= percent) {
				return Damage.applyArmor(amount, addArmor);
			}
			return amount;
		}
	}));
	return w
}

//反甲墙
function NewDamageBackWall(name, radius, DamageMulti, max, reload, pierce, air, ground){
	var w = extend(Wall, name, {
		update: true,
		setStats(){
			this.super$setStats();
			this.stats.add(new Stat("danageBackRadius", StatCat.function), radius / 8, StatUnit.blocks);
			this.stats.add(new Stat("damageBackThreshold", StatCat.function), max, StatUnit.none);
			this.stats.add(new Stat("damageBack", StatCat.function), max * DamageMulti, StatUnit.none);
			this.stats.add(new Stat("damageBackReload", StatCat.function), reload / 60, StatUnit.seconds);
			this.stats.add(new Stat("damageBackAir", StatCat.function), air, StatUnit.none);
			this.stats.add(new Stat("damageBackGround", StatCat.function), ground, StatUnit.none);
		},
		setBars() {
			this.super$setBars();
			this.addBar("damage", func(e => new Bar(
				prov(() => Core.bundle.format("bar.damageProgress", Strings.fixed(e.getProg() * 100, 0))),
				prov(() => Color.valueOf("FF5845")),
				floatp(() => e.getProg())
			)));
		},
	});
	w.buildType = prov(() => extend(Wall.WallBuild, w, {
		allDamage: 0.0,
		Timer: 0.0,
		getProg() {
			return this.allDamage / max;
		},
		update(){
			this.super$update();
			this.Timer += Time.delta;
		},
		handleDamage(amount) {
			if(this.Timer >= reload){
				this.allDamage = Math.min(this.allDamage + amount, max);
				if(this.allDamage >= max){
					Damage.damage(this.team, this.x, this.y, radius, max * DamageMulti, pierce, air, ground);
					this.allDamage = 0.0;
					this.Timer = 0.0;
				};
			}
			return amount;
		},
		
		write(write){
			this.super$write(write);
			write.f(this.allDamage);
			write.f(this.Timer);
		},
		read(read, revision){
			this.super$read(read, revision);
			this.allDamage = read.f();
			this.Timer = read.f();
		},
	}))
	return w
}

//锁血墙
function NewLockHealthWall(name, duration, reload, absorbMulti){
	var w = extend(Wall, name, {
		update: true,
		setStats(){
			this.super$setStats();
			this.stats.add(new Stat("lockTime", StatCat.function), duration / 60, StatUnit.seconds);
			this.stats.add(new Stat("lockReload", StatCat.function), reload / 60, StatUnit.seconds);
			this.stats.add(new Stat("absorbMulti", StatCat.function), absorbMulti, su.times);
		},
	});
	w.buildType = prov(() => extend(Wall.WallBuild, w, {
		Timer: 0.0,
		canLock: true,
		isLocking: false,
		update() {
			this.super$update();
			if(this.isLocking || !this.canLock) this.Timer += Time.delta;
			if(this.isLocking && this.Timer >= duration){
				this.isLocking = false;
				this.Timer = 0.0;
			};
			if(!this.isLocking && !this.canLock && this.Timer >= reload){
				this.canLock = true;
				this.Timer = 0.0;
			};
		},
		handleDamage(amount) {
			if(this.health <= amount && this.canLock) {
				this.isLocking = true;
				this.canLock = false;
			};
			if(this.isLocking) {
				this.heal(amount);
				Fx.healBlockFull.at(this);
				return Math.max(-amount * absorbMulti, this.health - w.health);
			};
			return amount;
		},
		write(write){
			this.super$write(write);
			write.f(this.Timer);
			write.bool(this.canLock);
			write.bool(this.isLocking);
		},
		read(read, revision){
			this.super$read(read, revision);
			this.Timer = read.f();
			this.canLock = read.bool();
			this.isLocking = read.bool();
		},
	}));
	return w
}

exports.graphiteWall = NewArmorUpWall("石墨墙", 0.5, 12);
exports.graphiteWallLarge = NewArmorUpWall("大型石墨墙", 0.5, 12);

exports.sporeWall = NewHealableWall("孢子墙", 0.01, 0);
exports.sporeWallLarge = NewHealableWall("大型孢子墙", 0.01, 0);

exports.glassSteelWall = NewDamageBackWall("玻璃钢墙", 48, 1.5, 50, 10, false, true, true);
exports.glassSteelWallLarge = NewDamageBackWall("大型玻璃钢墙", 48, 1.5, 50, 10, false, true, true);

exports.baseAlloyWall = NewLockHealthWall("基础合金墙", 120, 600, 0.5);
exports.baseAlloyWallLarge = NewLockHealthWall("大型基础合金墙", 120, 600, 0.5);

exports.carbonSteelWall = NewArmorUpWall("碳钢墙", 0.5, 50);
exports.carbonSteelWallLarge = NewArmorUpWall("大型碳钢墙", 0.5, 50);

