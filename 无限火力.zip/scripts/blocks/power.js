function NewConsumeItemVariableReactor(name, item, count) {
	var r = extend(VariableReactor, name, {
		hasItems: true,
		setStats(){
			this.super$setStats();
			this.stats.add(Stat.productionTime, r.powerProduction / 60, StatUnit.seconds);
		},
	});
	r.consumeItem(item, count);
	r.buildType = prov(() => extend(VariableReactor.VariableReactorBuild, r, {
		consumeItemTimer: 0.0,
		updateTile(){
			this.heat = this.calculateHeat(this.sideHeat);
			this.productionEfficiency = this.efficiency;
			this.warmup = Mathf.lerpDelta(this.warmup, this.productionEfficiency > 0 ? 1 : 0, r.warmupSpeed);
			if(this.instability >= 1) this.kill();
			
			this.totalProgress += this.productionEfficiency * Time.delta;
			if(Mathf.chanceDelta(r.effectChance * this.warmup)){
				r.effect.at(this.x, this.y, r.effectColor);
				Damage.damage(this.team, this.x, this.y, 40, 100, true, true, true, true, null);
			}
			
			this.consumeItemTimer += Time.delta * this.efficiency;
			if(this.efficiency > 0 && this.consumeItemTimer >= r.powerProduction){
				this.consumeItemTimer %= r.powerProduction;
				this.consume();
			};
		},
	}));
	return r;
};

exports.BlastReactor = NewConsumeItemVariableReactor("热能反应堆", Items.blastCompound, 1);





const lightningDamage = 50;
const lightningColor = Color.valueOf("AABBFF");
const lightningLength = 14;
const lightningLengthRand = 3
const reload = 20;
const lightningCount = 4;
const maxRadius = 5;

const mag = 2;
const scl = 0.5;
const rotateSpeed = 0.5;
var ArcReactor = extend(ImpactReactor, "电弧反应堆", {
	setStats(){
		this.super$setStats();
		this.stats.add(new Stat("arcDamage", StatCat.function), lightningDamage, StatUnit.none);
		this.stats.add(new Stat("arcLength", StatCat.function), lightningLength, StatUnit.none);
		this.stats.add(new Stat("arcCount", StatCat.function), lightningCount, StatUnit.none);
	},
})
ArcReactor.buildType = prov(() => extend(ImpactReactor.ImpactReactorBuild, ArcReactor, {
	lightningTimer: 0.0,
	updateTile(){
		this.super$updateTile();
		this.lightningTimer += this.delta();
		while(this.lightningTimer >= reload / this.warmup){
			var any = false;
			for(var i = 0; i < Math.floor(Mathf.pow(this.warmup, 5) * lightningCount); i++){
				Lightning.create(this.team, lightningColor, lightningDamage, this.x, this.y, Mathf.range(360), lightningLength + Mathf.random(lightningLengthRand));
				any = true;
			}
			if(any) Sounds.spark.at(this.x, this.y, 1.0, 0.75);
			this.lightningTimer -= reload / this.warmup
		}
	},
	draw(){
		this.super$draw();
		var prog = Mathf.pow(this.warmup, 5);
		if(prog >= 0.01){
			var radius = maxRadius * prog;
			var offset = Math.sin(Time.time / 60 * mag) * prog;
			radius += offset * scl;
			var p = prog + offset * 0.1;
			
			Draw.z(100);
			Fill.circle(this.x, this.y, radius);
			Draw.color(lightningColor);
			Fill.circle(this.x, this.y, radius);
			Lines.stroke(p);
			const sectors = 3;
			for(var i = 0; i < sectors; i++){
				var rot = i * 360/sectors - Time.time * rotateSpeed;
				Lines.arc(this.x, this.y, radius + 3, 0.9/sectors, rot);
			}
			for(var i = 0; i < sectors; i++){
				var rot = i * 360/sectors + Time.time * rotateSpeed;
				Lines.arc(this.x, this.y, radius*2 + 3, 0.9/sectors, rot);
			}
			
			for(var i = 0; i < 4; i++){
				//x y width length rotation
				Drawf.tri(this.x, this.y, prog*4, p*45, i*90);
			}
			Draw.color();
			for(var i = 0; i < 4; i++){
				Drawf.tri(this.x, this.y, prog*3, p*40, i*90);
			}
			
			Draw.z(Layer.light);
			Drawf.light(0, 0, radius * 1.2, lightningColor, 0.2);
			
			Draw.reset();
		}
	},
}))
