function NewBurstDrill(name, itemCountPerGrid){
	//作者哔哩哔哩四分之一个锅碳 3431442688 群号676380795
	var b = extend(BurstDrill, name, {
		setStats(){
			this.super$setStats();
			this.stats.remove(Stat.drillTier);
			this.stats.add(
				Stat.drillTier,
				StatValues.drillables(
					b.drillTime / itemCountPerGrid, b.hardnessDrillMultiplier, b.size * b.size, b.drillMultipliers,
					f => f instanceof Floor && !f.wallOre && f.itemDrop != null && f.itemDrop.hardness <= b.tier && f.itemDrop != b.blockedItem && (Vars.indexer.isBlockPresent(f) || Vars.state.isMenu()))
			);
			
			this.stats.add(Stat.drillSpeed, 60 / b.drillTime * b.size * b.size / itemCountPerGrid, StatUnit.itemsSecond);
		},
	});
	
	b.buildType = prov(() => extend(BurstDrill.BurstDrillBuild, b, {
		updateTile(){
			if(this.dominantItem == null) return;
			if(this.invertTime > 0) this.invertTime -= this.delta() / this.invertedTime;
			if(this.timer.get(0, 5)) this.dump(this.items.has(this.dominantItem) ? this.dominantItem : null);
			
			var ICPG = Math.max(itemCountPerGrid - this.block.hardnessDrillMultiplier * this.dominantItem.hardness, 0.01);
			var drillTime = this.block.getDrillTime(this.dominantItem);
			
			this.smoothProgress = Mathf.lerpDelta(this.smoothProgress, this.progress / (drillTime - 20), 0.1);
			
			if(this.items.total() <= this.block.itemCapacity - this.dominantItems * ICPG && this.dominantItems > 0 && this.efficiency > 0){
				this.warmup = Mathf.approachDelta(this.warmup, this.progress / drillTime, 0.01);
				
				var speed = this.efficiency;
				if(this.block.liquidBoostIntensity > 1 && this.liquids.get(Liquids.water) >= 0.01){
					speed *= this.block.liquidBoostIntensity * this.block.liquidBoostIntensity
				};
				
				this.timeDrilled += this.block.speedCurve.apply(this.progress / drillTime) * speed;
				
				this.lastDrillSpeed = ICPG / drillTime * speed * this.dominantItems;
				this.progress += this.delta() * speed;
			}else{
				this.warmup = Mathf.approachDelta(this.warmup, 0, 0.01);
				this.lastDrillSpeed = 0;
				return;
			};
			
			if(this.dominantItems > 0 && this.progress >= drillTime && this.items.total() < this.block.itemCapacity){
				for(var i = 0; i < this.dominantItems * ICPG; i++){
					this.offload(this.dominantItem);
				}
				this.invertTime = 1;
				this.progress %= drillTime;
				
				if(this.block.wasVisible || true){
					Effect.shake(this.block.shake, this.block.shake, this);
					this.block.drillSound.at(this.x, this.y, 1 + Mathf.range(this.block.drillSoundPitchRand), this.block.drillSoundVolume);
					this.block.drillEffect.at(this.x + Mathf.range(this.block.drillEffectRnd), this.y + Mathf.range(this.block.drillEffectRnd), this.dominantItem.color);
				}
			}
		},
	}));
	return b;
};

Blocks.blastDrill.buildVisibility = BuildVisibility.hidden;
exports.BlastDrill = NewBurstDrill("爆破钻头", 3.0);
