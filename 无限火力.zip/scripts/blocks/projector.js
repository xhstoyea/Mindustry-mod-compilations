function NewForceProjector(name, items){
	var p = new ForceProjector(name);
	p.itemConsumer = new ConsumeItems(items);
	p.buildType = prov(() => extend(ForceProjector.ForceBuild, p, {
		shieldRotation: 0.0,
		updateTile(){
			this.super$updateTile();
			this.shieldRotation = this.phaseHeat * 360 + p.shieldRotation;
		},
		drawShield(){
			if(!this.broken){
				var radius = this.realRadius();
				
				if(radius > 0.001){
					Draw.color(this.team.color, Color.white, Mathf.clamp(this.hit));
					
					if(Vars.renderer.animateShields){
						Draw.z(Layer.shields + 0.001 * this.hit);
						Fill.poly(this.x, this.y, p.sides, radius, this.shieldRotation);
					}else{
						Draw.z(Layer.shields);
						Lines.stroke(1.5);
						Draw.alpha(0.09 + Mathf.clamp(0.08 * this.hit));
						Fill.poly(this.x, this.y, p.sides, radius, this.shieldRotation);
						Draw.alpha(1);
						Lines.poly(this.x, this.y, p.sides, radius, this.shieldRotation);
						Draw.reset();
					}
				}
			}

			Draw.reset();
		},
	}))
	return p;
};




exports.smallForceProjector = NewForceProjector("小型力墙场", [new ItemStack(Items.silicon, 1)]);
exports.ForceDome = NewForceProjector("力墙穹顶", [new ItemStack(Items.phaseFabric, 1)]);

