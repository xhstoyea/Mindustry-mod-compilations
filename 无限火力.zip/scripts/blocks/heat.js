function NewHeatConductor(name){
	var h = new HeatConductor(name);
	h.buildType = prov(() => extend(HeatConductor.HeatConductorBuild, h, {
		/*updateTile(){
			this.super$updateTile();
			this.heat = Math.min(this.heat, MaxHeat);
		}*/
	}));
	return h;
};

function NewHeatProducer(name, consumeItemFilter, outputMulti){
	var h = extend(HeatProducer, name, {});
	h.consume(consumeItemFilter);
	h.buildType = prov(() => extend(HeatProducer.HeatProducerBuild, h, {
		itemMultiplier: 1.0,
		updateEfficiencyMultiplier(){
			if(consumeItemFilter != null){
				var m = consumeItemFilter.efficiencyMultiplier(this);
				if(m > 0) this.itemMultiplier = m;
			};
		},
		updateTile(){
			this.super$updateTile();
			//this.updateEfficiencyMultiplier();
			this.heat = h.heatOutput * this.efficiency * this.itemMultiplier * outputMulti;
		},
	}));
	return h;
};

exports.combustionHeatGenerator = NewHeatProducer("火力制热机", new ConsumeItemFlammable(), 1.0);
exports.powerHeatGeneratorLarge = new HeatProducer("大型电制热机");
exports.rtgHeatGenerator = NewHeatProducer("RTG制热机", new ConsumeItemRadioactive(), 1.0);
exports.ArcHeatGenerator = NewHeatProducer("电弧制热机", new ConsumeItemCharged(), 2.0);
exports.smallheatRedirector = NewHeatConductor("热能传输机");
exports.smallHeatRouter = NewHeatConductor("热能路由器");
