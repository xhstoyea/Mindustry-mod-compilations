exports.IndependentCore = extend(CoreBlock, "独立核心", {
	canBreak(tile){
		return Vars.state.teams.playerCores().size > 1;
	},
	canPlaceOn(tile,team,rotation){
		return Vars.state.teams.playerCores().size < 3;
	},
});

