function newItem(name){
	exports[name] = new Item(name);
};

newItem("磁能铅");
newItem("玻璃钢");
newItem("磁能钛");


