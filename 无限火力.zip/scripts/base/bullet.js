exports.ChangeMovementBulletType = (changeDelay, angleRand) => {
	return extend(BasicBulletType, {
		scaleLife: true,
		update(b){
			this.super$update(b);
			if(b.time >= changeDelay && !b.hasChanged && angleRand != 0){
				var randomAngle = (0.5 - Math.random()) * angleRand;
				b.vel.setAngle(b.rotation() + randomAngle);
				//angleRand = 0;
			}
		},
	})
};

exports.LimitRangeBulletType = (limitRange) => {
	return extend(BasicBulletType, {
		update(b){
			if(Mathf.dst(b.x - b.owner.x, b.y - b.owner.y) >= limitRange) {
				this.despawned(b);
				b.remove();
				return;
			};
			this.super$update(b);
		},
	})
};


exports.PointBulletType = () => {
	return extend(PointBulletType, {
		hitEffect: Fx.none,
		despawnEffect: Fx.none,
		trailEffect: Fx.none,
		speed: 200,
		lifetime: 60,
		shootEffect: Fx.none,
		
	})
};
exports.UncollideableBulletType = () => {
	return extend(BasicBulletType, {
		collidesTeam: false,
		collideFloor: false,
		collides: false,
		collideTerrain: false,
		absorbable: false,
		hittable: false,
		collidesAir: false,
		collidesGround: false,
		reflectable: false,
	})
};


exports.HomingBulletType = (limitRange) => {
	return extend(BasicBulletType, {
		absorbable: false,
		reflectable: false,
		update(b){
			
			//这部分是和LimitRangeBulletType一样的 
			if(Mathf.dst(b.x - b.originX, b.y - b.originY) >= limitRange) {
				this.despawned(b);
				b.remove();
				return;
			};
			//到这里
			
			this.super$update(b);
			b.damage = this.damage * Time.delta;
			b.collided.clear();
		},
	})
}



exports.BlackHoleBulletType = (maxRadius, expansionTime, outlineColor, baseForce, scl, mag) => {
	const multi = 0.02;
	const minDama = 1;
	return extend(BasicBulletType, {
		lightRadius: maxRadius,
		collides: false,
		absorbable: false,
		hittable: false,
		reflectable: false,
		realRadius: 0.0,
		speed: 0.0,
		getDamage(dst) {
			return this.damage / dst * 300;
		},
		update(b) {
			this.super$update(b);
			b.vel.x = 0;
			b.vel.y = 0;
			var maxDis = this.damage * 500 / minDama / 2;
			var targetRadius = this.realRadius * 10;
			Units.nearbyEnemies(b.team, b.x, b.y, targetRadius, cons(u => {
				const dst = Math.max(b.dst(u) - maxRadius, 40.0);
				var damage = this.getDamage(dst);
				if (damage >= minDama) {
					u.damageContinuousPierce(damage);
					u.impulseNet(Tmp.v3.set(b).sub(u).nor().scl(baseForce / dst * 5000 * Time.delta));
					b.time += damage * multi;
				}
			}));
			Vars.indexer.allBuildings(b.x, b.y, targetRadius, cons(build => {
				if (build.team != b.team) {
					const dst = Math.max(b.dst(build), 15.0);
					var damage = this.getDamage(dst);
					if(damage >= minDama) {
						build.damageContinuousPierce(damage * b.type.buildingDamageMultiplier);
						b.time += damage * multi * Time.delta;
					}
				}
			}));
			Groups.bullet.intersect(b.x - maxDis, b.y - maxDis, maxDis * 2, maxDis * 2, bullet => {
				if (bullet.team != b.team) {
					const dst = Math.max(b.dst(bullet), 25.0);
					if(dst <= maxDis) {
						if(dst == 25.0) {
							bullet.remove();
							b.time += (bullet.damage + bullet.type.splashDamage) * multi * Time.delta;
						} else{
							var a = bullet.angleTo(b);
							var tx = Angles.trnsx(a, baseForce / dst * 30 * Time.delta);
							var ty = Angles.trnsy(a, baseForce / dst * 30 * Time.delta);
							bullet.vel.x += tx;
							bullet.vel.y += ty;
						}
					}
				}
			})
		},
		draw(b) {
			Draw.color(Color.valueOf("000000"));
			var reduceRadius = 0.0;
			var radiusOffset = Math.sin(Time.time / 60 * mag) * scl;
			
			if(b.time <= expansionTime) reduceRadius = Math.pow((expansionTime - b.time) / expansionTime, 3) * maxRadius;
			if(b.time >= b.lifetime - expansionTime) reduceRadius = Math.pow((b.time - b.lifetime + expansionTime) / expansionTime, 3) * maxRadius;
			
			this.realRadius = maxRadius - reduceRadius + radiusOffset;
			
			Draw.z(Layer.light + 0.001);
			Fill.circle(b.x, b.y, this.realRadius);
			Draw.color(outlineColor);
			Draw.z(Layer.bullet);
			Lines.stroke(4);
			Lines.circle(b.x, b.y, this.realRadius);
			
			Draw.z(Layer.light);
			Drawf.light(0, 0, this.realRadius * 1.2, Color.valueOf(outlineColor), 0.2);
			Draw.reset();
			
			//Draw.z(150);
		},
	})
}

exports.RealRedImpulseWave = (randomDis, limitRange) => {
	var status = [
		StatusEffects.burning, StatusEffects.freezing, StatusEffects.slow,
		StatusEffects.wet, StatusEffects.melting, StatusEffects.sapped,
		StatusEffects.sporeSlowed, StatusEffects.tarred, StatusEffects.corroded
	];
	return extend(LaserBoltBulletType, {
		update(b){
			//这部分是和LimitRangeBulletType一样的 
			if(Mathf.dst(b.x - b.originX, b.y - b.originY) >= limitRange) {
				this.despawned(b);
				b.remove();
				return;
			};
			
			this.super$update(b);
		},
		
		hitTile(b, build, x, y, initialHealth, direct){
			this.super$hitTile(b, build, x, y, initialHealth, direct);
			this.effects(b);
		},
		hitEntity(b, entity, health){
			this.super$hitEntity(b, entity, health);
			this.effects(b);
			
			if(entity instanceof Unit) {
				if(Mathf.chance(0.05)) { //0.05%造成三十倍击退
					Tmp.v3.set(entity).sub(b).nor().scl(this.knockback * 80 * 29);
					entity.impulse(Tmp.v3);
				}
				
				if(Mathf.chance(0.1)) { //10%使敌人随机套上debuff
					var subscript = Math.floor(Math.random() * status.length);
					entity.apply(status[subscript], Math.random() * 30 + 30);
				}
			}
		},
		effects(b){
			if(Mathf.chance(0.1)) { //10%减少90%~99.5%弹速
				b.vel.trns(b.vel.angle(), Mathf.dst2(b.vel.x, b.vel.y) * Time.delta * (Math.random() * 0.09 + 0.005));
				b.collided.clear();
			};
			if(Mathf.chance(0.05)) { //5%刷新子弹起始位置(让子弹可以飞出范围一段距离)
				b.originX = b.x;
				b.originY = b.y;
			};
			if(Mathf.chance(0.14)) { //14%向左或向右传送
				var direction = Math.floor(Math.random() * 2) * 2 - 1;
				b.x += direction * Math.random() * randomDis;
			};
			if(Mathf.chance(0.14)) { //14%向上或向下传送
				var direction = Math.floor(Math.random() * 2) * 2 - 1;
				b.y += direction * Math.random() * randomDis;
			};
			if(Mathf.chance(0.67)) { //67%向反方向传送一定距离
				var rand = Math.random() * randomDis / 4;
				b.x += Angles.trnsx(180, b.vel.x * rand, b.vel.y * rand);
				b.y += Angles.trnsy(180, b.vel.x * rand, b.vel.y * rand);
				b.collided.clear();
			};
			if(Mathf.chance(0.07)) { //7%向弹道反方向移动
				b.rotation(b.vel.angle() + 180)
				b.collided.clear();
			};
			if(Mathf.chance(0.07)) { //7%向弹道垂直方向移动
				var direction = (Math.floor(Math.random() * 2) * 2 - 1) * 90;
				b.rotation(b.vel.angle() + direction)
				b.collided.clear();
			};
			
			if(Mathf.chance(0.05)) b.damage *= 1.5;
			//5%使子弹伤害提升至原来的1.5倍
		},
	})
}










