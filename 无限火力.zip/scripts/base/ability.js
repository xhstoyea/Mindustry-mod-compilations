function NearHealAbility(reload, range, amount){
	return extend(Ability,{
		i: 0,
		update(unit){
			this.i += Time.delta;
			if(this.i >= reload){
				var all = 0;
				Units.nearby(unit.team, unit.x, unit.y, range, other => {
					if(other.type == unit.type || other != unit){
						all += amount;
					}
				})
				if(all > 0){
					Fx.heal.at(unit);
					unit.heal(all);
				}
				this.i = 0;
			}
		},
		localized(){
			return Core.bundle.format("ability.NearHealAbility" ,reload/60, range/8, amount);
		}
	})
}
exports.NearHealAbility = NearHealAbility;


