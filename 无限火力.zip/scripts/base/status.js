function newStatus(name){
	exports[name] = new StatusEffect(name);
};

//newStatus("terror");


