//const ab = require("无限火力/base/ability");
const st = require('无限火力/base/status');

function mech(name){
	return extend(UnitType, name, {
		//outlineColor: Color.valueOf("2e3466"),
		//healColor: Color.valueOf("7e8ae6"),
		envDisabled: Env.none,
		lightOpacity: 0.1,
	})
};

