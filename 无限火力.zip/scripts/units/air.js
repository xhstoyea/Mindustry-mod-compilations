const ab = require("无限火力/base/ability");

const 萤火 = new UnitType("萤火");
exports.萤火 = 萤火;
Object.assign(萤火, {
	health: 400,
	speed: 4.0,
	flying: true,
	hitSize: 8,
	engineOffset: 5.75,
	armor: 1,
	accel: 0.08,
	constructor: () => new UnitEntity.create(),
	drag: 0.3,
	itemCapacity: 10,
	range: 160,
})
萤火.abilities.add(
	ab.NearHealAbility(30, 40, 2),
)