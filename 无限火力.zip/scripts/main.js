//require('无限火力/base/itemValues');
require('无限火力/blocks/wall');
require('无限火力/blocks/drill');
require('无限火力/blocks/turret');
require('无限火力/blocks/projector');
require('无限火力/blocks/heat');
require('无限火力/blocks/power');
require('无限火力/blocks/crafter');
require('无限火力/blocks/core');
require('无限火力/blocks/distribution');

require('无限火力/units/ground');
require('无限火力/units/air');

require('无限火力/base/item');
require('无限火力/base/status');
