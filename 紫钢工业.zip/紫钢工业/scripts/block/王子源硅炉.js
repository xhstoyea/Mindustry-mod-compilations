const myitems = require("物品");
const 王子源硅炉 = extend(AttributeCrafter, "王子源硅炉", {});
王子源硅炉.craftEffect = Fx.smeltsmoke;
王子源硅炉.hasPower = true;
王子源硅炉.consumesPower = true;
王子源硅炉.hasLiquids = false;
王子源硅炉.hasItems = true;
王子源硅炉.buildVisibility = BuildVisibility.shown;
王子源硅炉.craftTime = 85.2;
王子源硅炉.itemCapacity = 36;
王子源硅炉.size = 3;
王子源硅炉.attribute = Attribute.heat;
王子源硅炉.health = 330;
王子源硅炉.ambientSound = Sounds.smelter;
王子源硅炉.ambientSoundVolume = 0.07;
王子源硅炉.outputItem = new ItemStack(Items.silicon, 6);
王子源硅炉.consumeItems(ItemStack.with(
    Items.sand, 6,
    Items.coal, 2
));
王子源硅炉.consumePower(2.516);
王子源硅炉.drawer = new DrawMulti( new DrawRegion("-bottom"), new DrawDefault(), new DrawFlame(Color.valueOf("FFEF99")));
王子源硅炉.flameColor = Color.valueOf("FFEF99");
王子源硅炉.requirements = ItemStack.with(
    Items.lead, 135,
    Items.graphite, 60,
    Items.metaglass, 40,
    Items.titanium, 60,
    myitems.紫钢, 42,
    myitems.芯片, 8
);
王子源硅炉.category = Category.crafting;
exports.王子源硅炉 = 王子源硅炉
//王子源硅炉
//2煤炭+6沙子+1.22s+145电=6硅