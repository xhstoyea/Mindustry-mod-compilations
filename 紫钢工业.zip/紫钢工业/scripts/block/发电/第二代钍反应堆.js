const myitems = require("物品");
const 第二代钍反应堆 = extend(NuclearReactor, "第二代钍反应堆", {});//NuclearReactor
第二代钍反应堆.hasPower = true;
第二代钍反应堆.consumesPower = false;
第二代钍反应堆.hasLiquids = true;
第二代钍反应堆.hasItems = true;
第二代钍反应堆.buildVisibility = BuildVisibility.shown;
第二代钍反应堆.requirements = ItemStack.with(
Items.thorium, 250,
Items.lead, 400,
myitems.芯片,14,
myitems.紫钢,94,
Items.graphite,325,
Items.metaglass,120,
Items.plastanium,49
);
第二代钍反应堆.canOverdrive = true;
第二代钍反应堆.ambientSound = Sounds.hum;
第二代钍反应堆.flashThreshold = 0.1;//报警温度
第二代钍反应堆.ambientSoundVolume = 0.24;
第二代钍反应堆.explosionRadius = 30;
        //爆炸半径(格
第二代钍反应堆.explosionDamage = 4500;
        //爆炸伤害
第二代钍反应堆.explodeEffect = Fx.reactorExplosion;
        //爆炸特效
第二代钍反应堆.lightColor = Color.valueOf("7f19ea");
第二代钍反应堆.smokeThreshold = 0.42;
第二代钍反应堆.hotColor = Color.valueOf("ff9575a3");
第二代钍反应堆.consumeItems(ItemStack.with(Items.thorium, 2));
第二代钍反应堆.envEnabled = Env.groundWater;
第二代钍反应堆.rebuildable = false;
第二代钍反应堆.baseExplosiveness = 500;
第二代钍反应堆.liquidCapacity = 78;
第二代钍反应堆.itemCapacity = 11;
第二代钍反应堆.warmupSpeed = 0.023;
第二代钍反应堆.size = 3;
第二代钍反应堆.explosionShake = 7;
第二代钍反应堆.explosionShakeDuration = 18;
第二代钍反应堆.shieldHealth = 900;
第二代钍反应堆.breakCooldown = 60 * 10;
第二代钍反应堆.regenSpeed = 2;
第二代钍反应堆.glowColor = Color.valueOf("ff7531");
第二代钍反应堆.glowMag = 0.6;
第二代钍反应堆.glowScl = 8;
第二代钍反应堆.explodeSound = Sounds.explosionbig;
第二代钍反应堆.schematicPriority = 1;
第二代钍反应堆.health = 1749;
第二代钍反应堆.itemDuration = 452.5788;
第二代钍反应堆.powerProduction = 78.65;
第二代钍反应堆.heating = 0.012;
第二代钍反应堆.consumeLiquid(Liquids.cryofluid, 0.1);//js的在consume里面update等的7.0写法为赋值
第二代钍反应堆.category = Category.power;
exports.第二代钍反应堆 = 第二代钍反应堆


