const myitems = require("物品");
const 导弹发射器= extend(ItemTurret, "导弹发射器" ,{});
导弹发射器.itemCapacity = 72;
导弹发射器.liquidCapacity = 80;
导弹发射器.consumePower(1.32);
导弹发射器.health = 456;
导弹发射器.size= 2;
导弹发射器.shootY = -2;
导弹发射器.reload= 18.1;
导弹发射器.range= 256;
导弹发射器.maxAmmo = 24;
导弹发射器.shake= 2;
导弹发射器.recoil = 3;
导弹发射器.hasPower = true;
导弹发射器.consumesPower = true;
导弹发射器.hasLiquids = true;
导弹发射器.hasItems = true;
导弹发射器.targetGround = true;
导弹发射器.targetAir = true;
导弹发射器.ammoUseEffect= Fx.none;
导弹发射器.shootSound= Sounds.missile;
导弹发射器.inaccuracy= 4;
导弹发射器.rotateSpeed= 4;
导弹发射器.category = Category.turret;
exports.导弹发射器 = 导弹发射器;
导弹发射器.heatColor = Color.red;
导弹发射器.buildVisibility = BuildVisibility.shown;
导弹发射器.requirements = ItemStack.with(
    Items.lead, 45,
    Items.graphite, 70,
    Items.metaglass, 20,
    myitems.芯片,3,
    Items.titanium, 64,
    myitems.紫钢,28
);
导弹发射器.ammo(
Items.graphite, Object.assign(new MissileBulletType(8, 18),{
	splashDamageRadius: 24,
			splashDamage: 27,		
			//sprite: 饱和火力-导弹,		
			backColor: Color.valueOf("B0C4DE"),
			frontColor: Color.valueOf("E3E3E3"),
			trailColor: Color.valueOf("B0C4DE"),
			lifetime: 32,
			reloadMultiplier: 0.76,
			homingPower: 0.03,
			homingRange: 40,
			width: 4,
			height: 16,
			ammoMultiplier: 2,
			hitEffect: Fx.flakExplosion,
       shootEffect:Fx.shootBig,
        trailEffect: Fx.artilleryTrail
}
),
Items.pyratite, Object.assign(new MissileBulletType(8, 30),{
		backColor: Color.valueOf("FFB90F"),
			frontColor: Color.valueOf("E3E3E3"),
			trailColor: Color.valueOf("FFB90F"),
				//sprite: 饱和火力-导弹,	
				splashDamageRadius: 40,
			splashDamage: 32,		
			makeFire: true,		
			lifetime: 32,	
	    shootEffect:Fx.shootBig,
        trailEffect: Fx.artilleryTrail,
			status: StatusEffects.burning,
	     	statusDuration: 240,
			homingPower: 0.03,
			homingRange: 40,
			knockback:0.9,
			width: 4,
			height: 16,
			ammoMultiplier: 2,
			hitEffect: Fx.flakExplosion	
	}),
		Items.blastCompound, Object.assign(new MissileBulletType(8, 38),{
		lifetime: 35,
		rangeChange: 5,
			homingPower: 0.03,
			homingRange: 40,
			width: 4,
			height: 16,
					//sprite: 饱和火力-导弹,
	       shootEffect:Fx.shootBig,
        trailEffect: Fx.artilleryTrail,
			ammoMultiplier: 3,
		    splashDamageRadius: 45,
			splashDamage: 47,
		status: StatusEffects.blasted,
		hitEffect: Fx.flakExplosion,
		backColor: Color.valueOf("FF7F24"),
			frontColor: Color.valueOf("E3E3E3"),
			trailColor: Color.valueOf("FF7F24")
	}),
	Items.silicon, Object.assign(new MissileBulletType(8, 22),{
	splashDamageRadius: 40,
			splashDamage: 27,		
			//sprite: 饱和火力-导弹,		
			backColor: Color.valueOf("FCF387"),
			frontColor: Color.valueOf("FCF387"),
			trailColor: Color.valueOf("FCF387"),		
			lifetime: 32,
			reloadMultiplier: 1.42,
			homingPower: 0.16,
			homingRange: 40,
			width: 4,
			height: 16,
			ammoMultiplier: 3,
			hitEffect: Fx.flakExplosion,
       shootEffect:Fx.shootBig,
        trailEffect: Fx.artilleryTrail
}
),
	Items.surgeAlloy, Object.assign(new MissileBulletType(8, 72),{
		lifetime: 40,
		rangeChange: 10,
			homingPower: 0.03,
			homingRange: 40,
			width: 4,
			height: 16,
			pierceCap: 3,		
				pierce: true,
            pierceBuilding: true,
			pierceArmor: true,
					//sprite: 饱和火力-导弹,
			statusDuration: 300,		
	       shootEffect:Fx.shootBig,
        trailEffect: Fx.artilleryTrail,
			ammoMultiplier: 5,
		    splashDamageRadius: 62.4,
			splashDamage: 62,
		status: StatusEffects.shocked,
		hitEffect: Fx.flakExplosion,
		backColor: Color.valueOf("FF7F24"),
			frontColor: Color.valueOf("E3E3E3"),
			trailColor: Color.valueOf("FF7F24"),
			lightningDamage:22,//（击中产生闪电伤害）
lightning:3,// （击中产生闪电数量）
lightningLength:5,//（击中产生闪电长度）
	})
)