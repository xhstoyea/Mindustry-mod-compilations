const 孢子生产中心 = extend(AttributeCrafter, "孢子生产中心", {});
孢子生产中心.craftEffect = Fx.none;
孢子生产中心.hasPower = true;
孢子生产中心.consumesPower = true;
孢子生产中心.hasLiquids = true;
孢子生产中心.hasItems = true;
孢子生产中心.buildVisibility = BuildVisibility.shown;
孢子生产中心.maxBoost = 3;
孢子生产中心.legacyReadWarmup = true;
孢子生产中心.craftTime = 85.2;
孢子生产中心.itemCapacity = 25;
孢子生产中心.liquidCapacity = 144;
孢子生产中心.size = 3;
孢子生产中心.attribute = Attribute.spores;
孢子生产中心.health = 230;
孢子生产中心.consumeLiquid(Liquids.water, 0.4);
孢子生产中心.outputItem = new ItemStack(Items.sporePod, 4);
孢子生产中心.consumePower(3.35);
孢子生产中心.category = Category.production;
exports.孢子生产中心 = 孢子生产中心;
//孢子生产中心
//24水+201电+1.45s=4孢子夹