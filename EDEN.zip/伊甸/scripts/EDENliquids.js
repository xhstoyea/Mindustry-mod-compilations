function newLiquid(name) {
	exports[name] = (() => {
		let myLiquid = extend(Liquid, name, {});
		return myLiquid;
	})();
}
newLiquid("汞")
newLiquid("煤焦油")
newLiquid("甲苯")
newLiquid("氧气")