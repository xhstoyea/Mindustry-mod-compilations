require("blocks/冶金服务模块")
require("blocks/核心扩容模块")
require("blocks/远程核心连接模块")
require("EDENliquids");
require("EDENitems");
require("blocks/还原冶金厂");
require("blocks/塞普罗伊甸转换器");
require("blocks/电解冶金厂");