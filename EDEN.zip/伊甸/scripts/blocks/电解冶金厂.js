const library = require("base/library");
const myitems = require("EDENitems");
const 电解冶金厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "电解冶金厂", [
	{
		input: {
			items: ["伊甸-铝土/3"],
			power: 3
		},
		output: {
			items: ["伊甸-铝/3"],
		},
		craftTime: 12,
	},
]);