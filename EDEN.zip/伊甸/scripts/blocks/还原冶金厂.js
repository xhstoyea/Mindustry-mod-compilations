const library = require("base/library");
const myitems = require("EDENitems");
const 还原冶金厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "还原冶金厂", [
	{
		input: {
			items: ["伊甸-赤铁矿/3","coal/1"],
		},
		output: {
			items: ["伊甸-铁/3"],
		},
		craftTime: 20,
	},
	{
		input: {
			items: ["伊甸-黄铜矿/3","coal/1"],
		},
		output: {
			items: ["伊甸-铜/3"],
		},
		craftTime: 20,
	},
    {
		input: {
			items: ["伊甸-方铅矿/3","coal/1"],
		},
		output: {
			items: ["伊甸-铅/3"],
		},
		craftTime: 20,
	},  
    {
		input: {
			items: ["伊甸-朱砂/3","coal/1"],
		},
		output: {
			liquids: ["伊甸-汞/10"],
		},
		craftTime: 20,
	},
]);