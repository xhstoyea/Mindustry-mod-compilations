const library = require("base/library");
const myitems = require("EDENitems");
const 塞普罗伊甸转换器 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "塞普罗伊甸转换器", [
	{
		input: {
			items: ["copper/1"],    
		},
		output: {
			items: ["伊甸-铜/1"],
		},
		craftTime: 1,
	}, 
	{
		input: {
			items: ["伊甸-铜/1"],     
		},
		output: {
			items: ["copper/1"],
		},
		craftTime: 1,
	},
	{
		input: {
			items: ["lead/1"],     
		},
		output: {
			items: ["伊甸-铅/1"],
		},
		craftTime: 1,
	},
	{
		input: {
			items: ["伊甸-铅/1"],
		},
		output: {
			items: ["lead/1"],
		},
		craftTime: 1,
	}, 

]);
