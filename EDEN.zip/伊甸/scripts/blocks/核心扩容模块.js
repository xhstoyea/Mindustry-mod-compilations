//by zxs(转载勿删
function ipo(x, y) {
    return [[x + 2, y], [x - 2, y], [x, y + 2], [x, y - 2]];
}

function getIR(x, y) {
    let ir = ["null"];
    let n = 0;
    let f = 0;
    const a = ipo(x, y);
    for (let i = 0; i < a.length; i++) {
        if (Vars.world.tile(a[i][0], a[i][1])
            .block() instanceof CoreBlock) {
            ir[n] = Vars.world.tile(a[i][0], a[i][1]);
            n++;
            if (Vars.world.tile(a[i][0], a[i][1]).build.productionEfficiency > 0.8) {
                f++;
            }
        }
    }
    ir[4] = f;
    return ir;
}


const 核心扩容模块 = extend(StorageBlock, "核心扩容模块", {
    drawPlace(x, y, rotation, valid) {
        Drawf.dashSquare(Color.white, x * 8, y * 8, 5 * 8);
    }, canPlaceOn(tile, team, rotation) {
        return !getIR(tile.x, tile.y)
            .includes("null");
    }, 
    setStats() {
        this.super$setStats();
        this.stats.add(new Stat("建造", new StatCat("建造")), jz());
    }
});


function jz() {
    return function (table) {
        table.add("需建造在核心边上");
        table.row();
    };
}