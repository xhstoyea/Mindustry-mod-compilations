function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("铝土")
newItem("铝")
newItem("铜")
newItem("铅")
newItem("铁")
newItem("方铅矿")
newItem("黄铜矿")
newItem("赤铁矿")
newItem("朱砂")