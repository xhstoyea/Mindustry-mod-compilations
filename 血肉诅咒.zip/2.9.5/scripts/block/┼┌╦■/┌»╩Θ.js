const lib = require("base/coflib");
lib.DamageUpTurret(ItemTurret, "诏书", {}, 100, 0.05, 50);