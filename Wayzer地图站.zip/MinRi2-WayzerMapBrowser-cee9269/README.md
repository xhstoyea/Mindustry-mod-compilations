<center>

# Wayzer地图站 客户端Mod <img width=50 src="./assets/WayzerMapsLogo.png">

<img width=600 src="./assets/mapsBrowser.png">

</center>

### 高度自定义UI
<img width=600 src="./assets/drag.gif">

### 快速下载导入地图
可用于一些装载Wayzer插件服务器

<img width=600 src="./assets/download.gif">

### 快速服务器内投票
<img width=600 src="./assets/voteMap.gif">

### 地图详情

* 地图规则
* 波次查询

<img width=600 src="./assets/mapDetails.png">


## [Wayzer地图站]

由 wayzer 搭建运营

是国内**生态最完善**的地图站

<img width=600 src="./assets/wayzerMaps.png">

[Wayzer地图站]: https://www.mindustry.top/map