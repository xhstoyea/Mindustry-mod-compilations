let bilibili = "https://b23.tv/728mI9X"
let githud = "https://github.com/nodada/CT-origin/releases/tag/NO"
let myQQ = "http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=WOq1nS9tN2rMGVUVIZy7CpkypoXzVGpu&authKey=AzDYAr0RDF62lORA%2B%2FiRucrLDRE3avEP%2BqimlUMzMx1TAzrb3qu49eVFPGoY7E%2BF&noverify=0&group_code=665884639";//let三条为总链接 以下为配置文件的代称
//ch的更改
//其他的该ch为其他的语言
Events.on(EventType.ClientLoadEvent, cons(e => {
    var kaiping = new BaseDialog(Core.bundle.format("http00"));//title最上面的
    kaiping.cont.pane((() => {
    
        var table = new Table();
        table.add(Core.bundle.format("http000")).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left);//配置几？（自己看
        table.row();


table.button(Core.bundle.format("githud"), run(() => {
    if (!Core.app.openURI(githud)) {
        Vars.ui.showErrorMessage("@linkfail");
        Core.app.setClipboardText(githud);//配置
    }
})).size(620, 67).row();
table.button(Core.bundle.format("bilibili"), run(() => {
    if (!Core.app.openURI(bilibi)) {
        Vars.ui.showErrorMessage("@linkfail");//配置
        Core.app.setClipboardText(bilibili);//配置文件的文字
    }
})).size(620, 67);
table.row();
table.button(Core.bundle.format("myQQ"), run(() => {
    if (!Core.app.openURI(myQQ)) {
        Vars.ui.showErrorMessage("@linkfail");
        Core.app.setClipboardText(myQQ);
    }
})).size(620, 67).row();//这里接入
/*
table.row();
table.button(Core.bundle.format("http111"), run(() => {
    if (!Core.app.openURI(https111)) {
        Vars.ui.showErrorMessage("@linkfail");
        Core.app.setClipboardText(https111);
    }
})).size(620, 67).row();
//模板 如果要改名则在配置文件里添加
*/


/*table.row();
table.button(Core.bundle.format("bilibili"), run(() => {
    if (!Core.app.openURI(bilibili)) {//(扣号是指打开的网址的变量？但是是配置文件里所指的)
        Vars.ui.showErrorMessage("@linkfail");
        Core.app.setClipboardText(bilibili);
    }
})).size(620, 67).row();
*/

return table;
})()).grow().center().maxWidth(770);
kaiping.addCloseListener();//按esc关闭
kaiping.buttons.button("@close", run(() => {
    kaiping.hide();
})).size(114514, 64);
kaiping.show();
}));
