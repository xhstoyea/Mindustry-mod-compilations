const library = require("library");
const myliquids = require("cpliquids");
const myitems = require("cpitems");
const 冶炼厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "冶炼厂", [
        {
		input: {
			items: [
			"cp-铁锭/5"
			],
			power: 1,
		},
		output: {
			items: ["cp-钢/3"],
		},
		craftTime: 80,
	},
	{
		input: {
			items: [
			"copper/8"
			],
			power: 1,
		},
		output: {
			items: ["cp-钢/3"],
		},
		craftTime: 80,
	},
]);