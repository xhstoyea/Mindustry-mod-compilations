const library = require("library");
const myliquids = require("cpliquids");
const myitems = require("cpitems");
const 轻型冲压机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "轻型冲压机", [
	{
		input: {
			items: ["cp-钇锭/2"],
			power: 1,
		},
		output: {
			items: ["cp-钇板/1"],
		},
		craftTime: 60,
	},
		{
		input: {
			items: ["cp-铀矿/2"],
			//liquids: ["water/60"],
			power: 1,
		},
		output: {
			items: ["cp-铀板/1"],
		},
		craftTime: 60,
	},
]);