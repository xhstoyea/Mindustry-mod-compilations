const library = require("library");
const myliquids = require("cpliquids");
const myitems = require("cpitems");
const 重型冲压机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "重型冲压机", [
        {
		input: {
			items: [
			"cp-铁锭/10"
			],
			power: 2.3,
		},
		output: {
			items: ["cp-钢/6"],
		},
		craftTime: 80,
	},
        {
		input: {
			items: [
			"cp-铀矿/10"
			],
			power: 3.3,
		},
		output: {
			items: ["cp-铀板/6"],
		},
		craftTime: 160,
	},
		{
		input: {
			items: ["cp-钇锭/10"],
			power: 3,
		},
		output: {
			items: ["cp-钇板/6"],
		},
		craftTime: 120,
	},

]);