const library = require("library");
const myliquids = require("cpliquids");
const myitems = require("cpitems");
const 通用离心机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "通用离心机", [
	{
		input: {
			items: [
			"cp-碳酸硅/2",
			"cp-简易芯片/1"
			],
			liquids: ["water/60"],
			power: 1,
		},
		output: {
			items: ["cp-Ether/1"],
		},
		craftTime: 60,
	},
	{
		input: {
			items: ["cp-钇板/20","cp-简易芯片/5"],
			liquids: ["water/60"],
			power: 1.1,
		},
		output: {
			items: ["cp-Ether/5"],
		},
		craftTime: 120,
	},
	
	

]);