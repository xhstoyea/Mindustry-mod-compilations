const 污染区 = new SectorPreset("污染区", DXT, 1);
污染区.description = "这里的敌人文明比较落后，我们要尽快前往中央主轴与取得联系";
污染区.difficulty = 1;
污染区.alwaysUnlocked = true;
污染区.addStartingItems = true;
污染区.captureWave = 20;
污染区.localizedName = "污染区";
exports.污染区 = 污染区;
SFlib.addToResearch(污染区, {
	parent: "芳草山谷",
	objectives: Seq.with(
	new Objectives.SectorComplete(SectorPresets.芳草山谷))
});