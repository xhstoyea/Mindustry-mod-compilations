const lib = require("lib");
const NX = require("血肉之神js/effect/normalFx");
const {宙斯} = require("units");

const nuck = extend(UnitCargoLoader, "临界迁跃终纽", {
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.cores(team).size >= 4 && Vars.state.teams.get(team).getCount(this) < 4;
	},
	drawPlace(x, y, rotation, valid) {
		this.super$drawPlace(x, y, rotation, valid);
		if (Vars.state.teams.cores(Vars.player.team()).size < 4) {
			this.drawPlaceText(lib.bundle("text-needCore", 4), x, y, valid);
		} else if (Vars.state.teams.get(Vars.player.team()).getCount(this) >= 4) {
			this.drawPlaceText(lib.limitBuild(this, 4), x, y, valid);
		}
	}
});
nuck.size = 8;

lib.setBuilding(UnitCargoLoader.UnitTransportSourceBuild, nuck, {
	spawned(id) {
		this.super$spawned(id);
		NX.JumpIn(this, 宙斯).at(this);
	},
	draw() {
		this.super$draw();
		if (this.unit == null) {
			if (this.buildProgress == 0) return
			NX.DoubleAim(this, this.buildProgress, 宙斯.hitSize * 3, 1, 12, nuck.size);
		} else {
			NX.CenterTri(this, nuck.size * 4, 0.5, 4);
		}
		//NX.QuadrupleTri(this, 5, 7, 5);
	}
})