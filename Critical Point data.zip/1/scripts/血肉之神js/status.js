const lib = require("lib");
const FX = require("血肉之神js/effect/fightFx");

let minDamage = Stat("minDamage");
let percentDamage = Stat("percentDamage");
let minHealth = Stat("minHealth");
let percentHealth = Stat("percentHealth");
let minShieldDamage = Stat("minShieldDamage");
let percentShieldDamage = Stat("percentShieldDamage");
let reduceArmor = Stat("reduceArmor");
let reduceMaxHealth = Stat("reduceMaxHealth");
let killHealth = Stat("killHealth");
let chainDamage = Stat("chainDamage");
function newStatus(name, cons) {
	return exports[name] = extend(StatusEffect, name, cons || {});
}

function PercentStatus(name, percent /*百分比*/ , min /*保底值*/ , damage, obj) {
	return newStatus(name, {
		transitionDamage: damage || 0,
		update(unit, time) {
			this.super$update(unit, time);
			let UMAX = unit.type.health / 100 / 60; //每秒1%生命值
			let UP = UMAX * percent, Max = Math.max(UP, Math.abs(min));
			if (min < 0) unit.heal(Math.abs(Max));
			else unit.damageContinuousPierce(Max);
		},
		setStats() {
			this.super$setStats();
			if (min < 0) {
				this.stats.add(percentHealth, lib.bundle("percentHealth", percent));
				this.stats.add(minHealth, lib.bundle("minHealth", 60 * -min));
			} else {
				this.stats.add(percentDamage, lib.bundle("percentDamage", percent));
				this.stats.add(minDamage, lib.bundle("minDamage", 60 * min));
			}
		},
		init() {
			if (!obj) return
			if (obj.opposite) {
				for (let i = 0; i < obj.opposite.length; i++) {
					this.opposite(obj.opposite[i]);
				}
			}
			if (!obj.affinity) return
			this.affinity(obj.affinity[0], (unit, result, time) => {
				unit.damagePierce(this.transitionDamage);
				obj.affinity[1].at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
				result.set(this, Math.min(time + result.time, 300));
			});
		}
	})
}

function ChainLightningStatus(name, range, reload, damage, status, statusDuration, color) {
	let timer = 0, all = new Seq();
	newStatus(name, {
		update(unit, time) {
			this.super$update(unit, time);
			if ((timer += Time.delta) >= reload) {
				all.clear();
				Units.nearby(null, unit.x, unit.y, range, other => {
					if (other.team == unit.team && other.hittable) {
						all.add(other);
					}
				});
				all.sort(floatf(e => e.dst2(unit.x, unit.y)));
				if (all.size > 1) {
					let other = all.get(1);
					let absorber = Damage.findAbsorber(Vars.player.unit().team, unit.x, unit.y, other.getX(), other.getY());
					if (absorber != null) other = absorber;
					other.damagePierce(damage);
					if (other instanceof Unit) {
						other.unapply(this);
						other.apply(this, reload + 30);
					}
					Sounds.spark.at(unit);
					Fx.chainLightning.at(unit.x, unit.y, 0, color, other);
					Fx.hitLaserBlast.at(other.x, other.y, unit.angleTo(other), color);
				} else {
					unit.apply(status, statusDuration);
					Sounds.pulseBlast.at(unit);
				}
				unit.damagePierce(damage);
				Fx.hitLaserBlast.at(unit.x, unit.y, 0, color);
				timer = 0;
			}
		},
		setStats() {
			this.super$setStats();
			this.stats.add(chainDamage, lib.bundle("chainDamage", damage));
		},
		init() {
			this.affinity(instableEnergy, (unit, result, time) => {
				unit.damagePierce(unit.type.health / 100 * 2);
				Fx.dynamicSpikes.wrap(lib.Color("C0ECFF"), unit.hitSize / 2).at(unit.x + Mathf.range(unit.bounds() / 2), unit.y + Mathf.range(unit.bounds() / 2));
				result.set(this, Math.min(time + result.time, 60));
			});
		}
	})
}


Events.on(UnitDestroyEvent, e => {
	let u = e.unit, bits = u.statusBits();
	if (bits.isEmpty()) return;
	trigger.each(s => bits.get(s.id), s => s.death(u));
});