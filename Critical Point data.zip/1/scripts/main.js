var startColor = Color.valueOf("A0BEFFFF"); //初始颜色
var shiftValue = 32; //颜色跨度，360度为一次轮回
var mod = Vars.mods.locateMod("cp");//这里的换成你的mod.(h)json里面写的name
var st = mod.meta.displayName;
var fin = new java.lang.StringBuilder();
for(var i = 0; i < st.length; i++){
  var s = java.lang.String.valueOf(st.charAt(i));
  var c = startColor.shiftHue(i * (shiftValue/st.length));
  var ci = c.rgb888();
  var ct = java.lang.Integer.toHexString(ci);
  var fct = "[" + "#" + ct + "]";
  fin.append(fct).append(s);
}

mod.meta.displayName = fin.toString();

//❤来自EU❤


require('临界反应驻存仪');
require('帝辛特');
require('lk');
require('supercamera');
require('cpitems');
require('cpliquids');
require('blocks/轻型冲压机');
require('blocks/重型冲压机');
require('blocks/通用离心机');
require('blocks/冶炼厂');
//require('特效');
require('庇护');
//require('血肉之神js/临界迁跃终纽')

