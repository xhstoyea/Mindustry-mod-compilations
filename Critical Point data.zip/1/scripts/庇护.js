const 庇护特效 = extend(ItemTurret, "庇护特效", {});
const 庇护炮 = extend(PowerTurret, "庇护炮", {});
//const 防空塔高射炮 = extend(ItemTurret, "防空塔高射炮", {});

const 庇护立场 = extend(ForceProjector, "庇护立场", {});
const cpitems = require("cpitems");

const 庇护 = extend(Wall, "庇护", {
	canReplace(other) {
		return true;
	}
	});


庇护.buildVisibility = BuildVisibility.shown;

//这是必需的
庇护.update = true;
//设置方块可使用物品
庇护.hasItems = true;

//设置可使用的弹药
const TItems = [cpitems.硅钢,cpitems.暗物质]

庇护.buildType = prov(() => {
	//创建多炮塔
	//(方块，队伍(不需要设置))
	const payloads = [
		new BuildPayload(庇护特效, Team.derelict),
		new BuildPayload(庇护立场, Team.derelict),
			new BuildPayload(庇护炮, Team.derelict),
	];
	const build = extend(Wall.WallBuild, 庇护, {
	    //设置物品进入规则
		acceptItem(source, item) {
			for(var i = 0; i < TItems.length; i++){
				if(TItems[i] == item){
					if(this.items.get(TItems[i]) < this.block.itemCapacity){
						return true;
					}
				}
			}
            return false;
        },

		updateTile() {
			this.super$updateTile();

			//可以让炮塔转起来的代码
			//删除注释以使用
			/*for (var i = 0; i < payloads.length; i++) {
                var t = payloads[i];
                var rotation = (360.0 / payloads.length) * i + Time.time;

				//这里的24为距离本体方块中心的多少距离旋转(8为1格)
                t.set(x + Angles.trnsx(rotation, 24), y + Angles.trnsy(rotation, 24), t.build.payloadRotation);
            }*/

			//设置模块
		
			for(var id = 0; id < payloads.length; id++){
				//设置队伍，如果在上面的创建位置设置，无用
                if(payloads[id].build.team != this.team){
                    payloads[id].build.team = this.team;
                }
				
				//执行炮塔更新
                payloads[id].update(null, this);

				//为物品炮塔添加弹药
				//你们需要可自己定义
				for(var i = 0; i < TItems.length; i++){
					if(payloads[id].build.acceptItem(payloads[id].build, TItems[i]) && this.items.get(TItems[i]) >= 1) {
						payloads[id].build.handleItem(payloads[id].build, TItems[i]);
						this.items.remove(TItems[i], 1);
					}
				}
            }

			//设置炮塔的位置
			//有需求你们可以自己定义
			//（x, y, r）
			payloads[0].set(this.x + 0, this.y + 0, payloads[0].build.payloadRotation);
			payloads[1].set(this.x + 0, this.y - 0, payloads[1].build.payloadRotation);
			payloads[2].set(this.x - 0, this.y + 0, payloads[2].build.payloadRotation);
		},
		draw(){
			this.super$draw();

			//执行多炮塔的动画
			for(var i = 0; i < payloads.length; i++){
                payloads[i].draw();
            }
		},
	});

	return build;
});