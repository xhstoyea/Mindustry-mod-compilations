const SFlib = require("lib2");
const DXT = new Planet("帝辛特", Planets.sun, 1, 3.3);
DXT.meshLoader = prov(() => new MultiMesh(
	new HexMesh(DXT, 8)
));
DXT.generator = extend(SerpuloPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgZmBmZmDJS8xNZWA0ZOBOSS1OLsosKMnMz2NgYGDLSUxKzSlmYIqOZWTgSs4vStUtzkgsSgFKMYIQkAAA2WoNuQ==")
	}
});
DXT.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(DXT, 2, 0.15, 0.14, 5, Color.valueOf("9F62D1FF80"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(DXT, 3, 0.6, 0.15, 5, Color.valueOf("9F62D1FF"), 2, 0.42, 1.2, 0.45)
));
DXT.generator = new SerpuloPlanetGenerator();
DXT.visible = DXT.accessible = DXT.alwaysUnlocked = true;
DXT.clearSectorOnLose = false;
DXT.tidalLock = false;
DXT.localizedName = "帝辛特";
DXT.prebuildBase = false;
DXT.bloom = false;
DXT.startSector = 1;
DXT.orbitRadius = 85;
DXT.orbitTime = 180 * 60;
DXT.rotateTime = 90 * 60;
DXT.atmosphereRadIn = 0.02;
DXT.atmosphereRadOut = 0.3;
DXT.atmosphereColor = DXT.lightColor = Color.valueOf("9F62D1FF90");
DXT.iconColor = Color.valueOf("9F62D1FF"),
DXT.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);

const 芳草山谷 = new SectorPreset("芳草山谷", DXT, 1);
芳草山谷.description = "这里的敌人文明比较落后，我们要尽快前往中央主轴与取得联系";
芳草山谷.difficulty = 1;
芳草山谷.alwaysUnlocked = true;
芳草山谷.addStartingItems = true;
芳草山谷.captureWave = 20;
芳草山谷.localizedName = "芳草山谷";
exports.芳草山谷 = 芳草山谷;
SFlib.addToResearch(芳草山谷, {
	parent: "groundZero",
	objectives: Seq.with(
	new Objectives.SectorComplete(SectorPresets.groundZero))
});