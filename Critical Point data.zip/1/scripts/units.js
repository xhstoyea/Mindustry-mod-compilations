const lib = require("lib");
const FX = require("血肉之神js/effect/fightFx");
//const liquid = require("base/液体");
//const ability = require("base/ability");
const status = require("血肉之神js/status");


function newUnit(name, unitType, cons, cons2) {
	const u = extend(UnitType, name, cons || {});
	u.constructor = () => extend(unitType, cons2 || {});
	return exports[name] = u;
}
exports.newUnit = newUnit;
function newUnitList(name, unitType, num) {
	for (let i = 1; i <= num; i++) newUnit(name + i, unitType);
}
/*
flying -> UnitEntity;
mech -> MechUnit;
legs -> LegsUnit;
naval -> UnitWaterMove;
payload -> PayloadUnit;
missile -> TimedKillUnit;
tank -> TankUnit;
hover -> ElevationMoveUnit;
tether -> BuildingTetherPayloadUnit;
crawl -> CrawlUnit;
*/
function BottleUnitType(name, lifeTime, damage, range, status, effect, color) {
	let i = 0, dx = 0, dy = 0;
	let u = extend(MissileUnitType, name, {
		health: 10000,
		lifetime: lifeTime,
		speed: 0,
		trailLength: 0,
		flying: false,
		drawCell: false,
		hittable: false,
		targetable: false,
		loopSound: Sounds.none,
		update(unit) {
			this.super$update(unit);
			if ((i += Time.delta) >= 6) {
				Damage.damage(unit.x, unit.y, range, damage);
				Damage.status(null, unit.x, unit.y, range, status, 900, true, true);
				dx = unit.x + Mathf.range(range * 0.6);
				dy = unit.y + Mathf.range(range * 0.7);
				if (Mathf.chance(0.5)) effect.at(dx, dy, color);
				i = 0;
			}
		},
		draw(unit) {
			this.super$draw(unit);
			Draw.color(Pal.accent);
			Draw.z(Layer.effect);
			for (let i = 0; i < 4; i++) {
				let r = Time.time + i * 90;
				Lines.arc(unit.x, unit.y, range, 0.2, r);
			}
		}
	});
	u.immunities.add(status);
	return exports[name] = u;
}

//newUnit("伊普西龙", PayloadUnit);
//newUnit("泽塔", PayloadUnit);
newUnit("宙斯", UnitEntity, {
	draw(unit) {
		this.super$draw(unit);
		FX.PlayerAim(unit, lib.FF5845);
	}
});
