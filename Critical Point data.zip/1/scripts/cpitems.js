function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("Ether")
newItem("钇锭")
newItem("钇板")
newItem("铁锭")
newItem("碳酸硅")
newItem("简易芯片")
newItem("极位能")
newItem("暗物质")
newItem("硅钢")
