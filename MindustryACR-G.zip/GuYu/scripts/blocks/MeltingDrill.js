const itemMap = ObjectMap.of(
  Items.copper, Items.surgeAlloy,
  Items.sand, Items.metaglass
)

const MyDrill = name => {
  const a = new Drill(name)

  a.buildType = () => {

    var timer = 0
    return extend(Drill.DrillBuild, a, {

      updateTile(){

        timer += Time.delta
        if(timer >= 5){
          timer -= 5
          this.dump(this.dominantItem != null && this.items.has(this.dominantItem) ? this.dominantItem : null)
        }

        if(!this.dominantItem)
          return

        const item = itemMap.get(this.dominantItem) ? itemMap.get(this.dominantItem) : this.dominantItem

        this.timeDrilled += this.warmup * this.delta()

        const delay = this.block.getDrillTime(item)

        if(this.items.total() < this.block.itemCapacity && this.dominantItems > 0 && this.efficiency > 0){
          const speed = Mathf.lerp(1, this.block.liquidBoostIntensity, this.optionalEfficiency) * this.efficiency

          this.lastDrillSpeed = (speed * this.dominantItems * this.warmup) / delay
          this.warmup = Mathf.approachDelta(this.warmup, speed, this.block.warmupSpeed)
          this.progress += this.delta() * this.dominantItems * speed * this.warmup

          if(Mathf.chanceDelta(this.block.updateEffectChance * this.warmup))
            this.block.updateEffect.at(this.x + Mathf.range(this.block.size * 2), this.y + Mathf.range(this.block.size * 2))

        }else{
            this.lastDrillSpeed = 0
            this.warmup = Mathf.approachDelta(this.warmup, 0, this.block.warmupSpeed)
            return
        }

        if(this.dominantItems > 0 && this.progress >= delay && this.items.total() < this.block.itemCapacity){
          this.offload(item)
          this.progress %= delay

          if(this.wasVisible && Mathf.chanceDelta(this.block.updateEffectChance * this.warmup))
            this.block.drillEffect.at(this.x + Mathf.range(this.block.drillEffectRnd), this.y + Mathf.range(this.block.drillEffectRnd), item.color)
        }
      }
    })
  }
  return a
}

exports.MyDrill = MyDrill
