const WeatherBlockb = (name, weather) => {
  const b = extend(Block, name, {
      buildVisibility: BuildVisibility.hidden,
      update: true,
      targetable: false,
      forceDark: true,
      hasShadow: false,
      size: 1,

      canBreak(tile){
          return false
      }
  });

  b.buildType = () => extend(Building, {

      update(){
          this.super$update();

          Groups.weather.each(w => {
              if(w.weather != weather) w.remove()
          });
          if(Groups.weather.isEmpty())
              weather.create();
      },

      onRemoved(){
          Groups.weather.each(w => {
              if(w.weather == weather) w.remove()
          })
      }
  });

  return b
};

exports.WeatherBlockb = WeatherBlockb
