// "buildCount" codes are inspired from the mod "Creator".
const Laboratory = name => {
    const buildCount = [];
    const a = extend(Block, name, {

        canPlaceOn(tile, team, rotation){
            return buildCount[Vars.player.team().id] >= 1
            ? false
            : this.super$canPlaceOn(tile, team, rotation);
        },

        drawPlace(x, y, rotation, valid){
            this.super$drawPlace(x, y, rotation, valid);
            if(buildCount[Vars.player.team().id] >= 1)
                this.drawPlaceText("该区块已经存在实验室了！", x, y, valid)
        },

        buildCount(){return buildCount},

        update: true,
        configurable: true
    });

    return a
};

exports.Laboratory = Laboratory
