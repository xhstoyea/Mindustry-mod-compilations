Events.run(EventType.ClientLoadEvent, () => {

    /* ==== The following is config. ==== */

    //code "[L3, L3, L3, L2, L2]" states the ItemStack.with(copper, L3, graphite, L3, thorium, L3, plastanium, L2, surgeAlloy, L2)
    const DEBUG_forceResearch = false;
    const L1 = 100, L2 = 200, L3 = 1000, L4 = 2000, L5 = 5000;
    const tickToWait = 3600;
    const updateEffectChance = 0.06, updateSoundVolume = 0.06;
    const updateEffect = Fx.pulverizeMedium, updateSound = Sounds.grinding;
    const groups = Seq.with(
        [Blocks.duo, L1],
        [Blocks.scatter, L2, L2],
        [Blocks.spectre, L3, L3, L3, L2, L2],
        [Blocks.duct, L2]
    );

    /* ==== The above is config. ==== */



    /*
     * The codes below are core part... except for the hardcode part.
     * Please fell welcome to modify the string codes.
     * Do not modify the non-string codes unless you certainly know what you're doing.
     * @author Kochiya Ueneh
     */

    const laboratoryDialog = extend(BaseDialog, "", {
        currentBlock: groups.get(0)[0],
        parentBuilding: null,
        itemStacks: Seq.with(),
        canResearch: false,
        timer: -1,

        updateDialog(){
            this.itemStacks.sort();
            this.cont.clear();
            this.cont.pane(main => {
                main.setSize(640);

                main.table(cons(t1 => {
                    t1.image(this.currentBlock.fullIcon).size(160).left().scaling(Scaling.fit);
                    t1.add("[accent]" + this.currentBlock.localizedName).left()
                })).left();

                main.table(cons(t2 => {
                    t2.add("研究需花费的物品:").left().row();
                    this.itemStacks.each(s => {
                        t2.image(s.item.fullIcon).size(40).left().scaling(Scaling.fit);
                        t2.add(s.item.localizedName + ", " + s.amount).left();
                        t2.row()
                    })
                })).right();

                main.row();
                const text = this.timer >= 0
                    ? "请等待" + Strings.fixed((tickToWait - this.timer) / 60, 1) + "秒..."
                    : "开始研究!"
                const button = main.button(text, () => {
                    if(DEBUG_forceResearch){
                        this.succeedResearch()
                    }else{
                        const group = groups.find(g => g[0] == this.currentBlock);
                        const lenEq = group.length == this.itemStacks.size + 1;
                        const stacks = Seq.with();

                        if(lenEq)
                            for(let i = 0; i < group.length - 1; i++)
                                stacks.add(new ItemStack(group[0].requirements[i].item, group[i + 1]));

                        this.timer = 0;
                        this.canResearch = laboratoryDialog.itemStacks.equals(stacks)
                    }

                }).size(210, 64);

                if(!DEBUG_forceResearch){
                    if(this.currentBlock.unlocked()){
                        button.disabled(true).tooltip("你已经解锁/研究过这个了!")
                    }else if(this.itemStacks.isEmpty()){
                        button.disabled(true).tooltip("请先选择研究需要的物品!")
                    }else if(this.timer >= 0){
                        button.disabled(true)
                    }else{
                        if(!Vars.ui.research.items) Vars.ui.research.rebuildItems();
                        const items = Vars.ui.research.items.copy();
                        this.itemStacks.each(s => items.remove(s));
                        if(items.toSeq().contains(s => s.amount < 0)){
                            button.disabled(true).tooltip("物品不足!")
                        }
                    }
                }
            })
        },

        succeedResearch(){
            this.currentBlock.unlock();
            Vars.ui.announce("研究成功!")
        },

        failedResearch(){
            Vars.ui.announce("研究失败!")
        },

        //???
        a(e){
            if(e == 1) return L1;
            else if(e == 2) return L2;
            else if(e == 3) return L3;
            else if(e == 4) return L4;
            else if(e == 5) return L5;
            else return 0
        }
    });

    laboratoryDialog.addCloseButton();

    laboratoryDialog.buttons.button("帮助", () => {
        const dialog = new BaseDialog("帮助");
        dialog.addCloseButton();
        dialog.cont.pane(t => t.add("[cyan]---===教程===---\n[white]1.[yellow]选择要研究的方块\n[white]2.[yellow]选择研究使用的物品以及数量的等级\n[white]3.[yellow]物品的来源为研究中的行星物品\n[white]4.[yellow]选定好研究的方块以及物品后点击开始研究，并等待一段时间\n[white]5.[yellow]最后以获得研究结果失败/成功\n[cyan]---===提示===---\nLevel 1 => 100个物品\nLevel 2 => 200个物品\nLevel 3 => 1000个物品\nLevel 4 => 2000个物品\nLevel 5 => 5000个物品\nClear清除就是取消选定这个物品"));
        dialog.show()
    });

    laboratoryDialog.buttons.button("选择研究方块", () => {
        const dialog = new BaseDialog("选择研究方块");
        dialog.addCloseButton();
        dialog.cont.pane(main => {
            groups.each(g => {
                main.table(cons(t => {
                    t.button(new TextureRegionDrawable(g[0].uiIcon), Styles.emptyi, 40, () => laboratoryDialog.currentBlock = g[0]).size(64).scaling(Scaling.fit);
                    t.add("[accent]" + g[0].localizedName).left()
                }));
                main.row()
            })
        });
        dialog.show()
    });

    laboratoryDialog.buttons.button("选择研究物品", () => {
        const dialog = new BaseDialog("选择研究物品");
        dialog.addCloseButton();
        dialog.cont.pane(main => {
            main.setWidth(1280);

            Items.serpuloItems.each(item => {
                if(item.unlocked()){
                    main.image(item.uiIcon).size(40).left().scaling(Scaling.fit);
                    main.left().table(Styles.grayPanel, t => {
                        t.left().add("[accent]" + item.localizedName).left();
                        t.row();

                        let text;
                        for(let i = 0; i < 6; i++){
                            const j = i; //this is really stupid

                            switch(j){
                                case 0:
                                    text = "Clear";
                                    break;
                                case 1:
                                    text = "Level 1";
                                    break;
                                case 2:
                                    text = "Level 2";
                                    break;
                                case 3:
                                    text = "Level 3";
                                    break;
                                case 4:
                                    text = "Level 4";
                                    break;
                                case 5:
                                    text = "Level 5";
                                    break;
                                default:
                                    text = "";
                            }

                            t.button(text, Styles.flatTogglet, () => {
                                // remove(s => {...}) is unavailable???
                                laboratoryDialog.itemStacks.each(s => {
                                    if(s.item == item) laboratoryDialog.itemStacks.remove(s)
                                }); 
                                laboratoryDialog.itemStacks.add(new ItemStack(item, laboratoryDialog.a(j)));
                                laboratoryDialog.itemStacks.each(s => {
                                    if(s.amount == 0) laboratoryDialog.itemStacks.remove(s)
                                })
                            }).size(80, 40).growX().pad(5)
                        }
                    });
                    main.row();
                }
            })
        });

        dialog.show()
    });

    laboratoryDialog.buttons.button("清除当前研究项目", () => {
        laboratoryDialog.cont.clear();
        laboratoryDialog.currentBlock = groups.get(0)[0];
        laboratoryDialog.itemStacks.clear()
    });

    //update this through a weird way...

    laboratoryDialog.addListener(extend(InputListener, {
        mouseMoved(event, x, y){
            if(laboratoryDialog.timer < 0) laboratoryDialog.updateDialog();
            return this.super$mouseMoved(event, x, y)
        }
    }));

    laboratoryDialog.addCaptureListener(extend(ElementGestureListener, {
        pan(event, x, y, dX, dY){
            if(laboratoryDialog.timer < 0) laboratoryDialog.updateDialog()
        }
    }));

    exports.laboratoryDialog = laboratoryDialog;
    exports.tickToWait = tickToWait;
    exports.updateEffectChance = updateEffectChance;
    exports.updateSoundVolume = updateSoundVolume;
    exports.updateEffect = updateEffect;
    exports.updateSound = updateSound
})
