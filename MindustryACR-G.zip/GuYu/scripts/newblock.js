/*=== ___ ===*/
Blocks.pneumaticDrill.findConsumer(c => c instanceof ConsumeLiquidBase).amount = 0.066
const {MyDrill} = require("blocks/MeltingDrill")
const myItems = require("newitem")
/*=== ___ ===*/

const BronzeSwall = new Wall("BronzeSwall");
const BronzeBwall = new Wall("BronzeBwall");
const PrimaryContainer = new StorageBlock("PrimaryContainer");
const BronzeAlloy = new GenericCrafter("BronzeAlloy");
const PowerPlants = new ConsumeGenerator("PowerPlants");
const BronzeConveyor = new Conveyor("BronzeConveyor");
const BronzeBAlloy = new GenericCrafter("BronzeBAlloy");
const ForceMapping = new ForceProjector("ForceMapping");
const aurora = new ItemTurret("aurora");
const MediumBattery = new Battery("MediumBattery");
const sporetempest = new ParticleWeather("sporetempest");
const splitsky = new ItemTurret("splitsky");

/*=== 原创 ===*/

const MeltingDrill = Object.assign(MyDrill("MeltingDrill"), {
  size: 3,
  health: 800,
  itemCapacity: 20,
  drillTime: 225,
  tier: 5,
  hasPower: true,

  drawRim: true,
  updateEffect: Fx.pulverizeRed,
  updateEffectChance: 0.03,
  drillEffect: Fx.mineHuge,
  rotateSpeed: 6,
  warmupSpeed: 0.02
})
MeltingDrill.setupRequirements(Category.production, ItemStack.with(
  myItems.Bronze, 120,
  Items.titanium, 100,
  myItems.Stannum, 80,
  Items.silicon, 50
))
MeltingDrill.consumePower(6)
MeltingDrill.consumeLiquid(Liquids.water, 0.11)
MeltingDrill.consumeLiquid(Liquids.cryofluid, 0.09).boost()

/*=== 原创 ===*/

const {Laboratory} = require("blocks/Laboratory");
const LaboratoryDialog = require("LaboratoryDialog");

const lab = Object.assign(Laboratory("Laboratory"), {
    buildVisibility: BuildVisibility.shown,
    category: Category.effect,
    size: 3,
    solid: true
});

lab.buildType = () => extend(Building, {

    buildConfiguration(table){
        if(!Vars.state.isCampaign() || Vars.net.client()){
            this.deselect();
            return
        };

        table.button(Icon.upOpen, Styles.cleari, () => {
            this.dialog().show();
            this.deselect()
        }).size(40)
    },

    update(){
        this.super$update();
        if(this.dialog().timer < 0) return;

        this.dialog().timer += Time.delta;
        this.dialog().updateDialog();

        if(Mathf.chanceDelta(LaboratoryDialog.updateEffectChance)) LaboratoryDialog.updateEffect.at(this);
        Vars.control.sound.loop(LaboratoryDialog.updateSound, this, LaboratoryDialog.updateSoundVolume * this.efficiency);

        if(this.dialog().timer >= LaboratoryDialog.tickToWait){
            this.dialog().timer = -1;

            if(this.dialog().canResearch){
                this.dialog().succeedResearch()
            }else{
                this.dialog().failedResearch()
            };

            this.dialog().itemStacks.each(s => Vars.ui.research.items.remove(s))
        }
    },

    draw(){
        this.super$draw();
        if(this.dialog().timer < 0) return;

        Draw.color(Color.white);
        Draw.alpha(0.4 + Mathf.absin(Time.time, 8, 0.6));
        Draw.rect(Core.atlas.find(this.block.name + "-top"), this.x, this.y);
        Draw.reset()
    },

    readBase(read){
        this.super$readBase(read);
        if(!this.block.buildCount()[this.team.id]) this.block.buildCount()[this.team.id] = 0;
        this.block.buildCount()[this.team.id]++
    },

    add(){
        this.super$add();
        if(!this.block.buildCount()[this.team.id]) this.block.buildCount()[this.team.id] = 0;
        this.block.buildCount()[this.team.id]++
    },

    remove(){
        if(this.added) this.block.buildCount()[this.team.id]--
        this.super$remove();
    },

    dialog(){
        return LaboratoryDialog.laboratoryDialog
    }
})


/*=== 原创 ===*/

const {WeatherBlocka} = require("blocks/WeatherBlocka");
const {WeatherBlockb} = require("blocks/WeatherBlockb");
const snowman = WeatherBlocka("snowman", Weathers.snow);
const sporetempestman = WeatherBlockb("sporetempestman", sporetempest);

/*=== 原创 ===*/

module.exports = {
  BronzeSwall: BronzeSwall,
  PrimaryContainer: PrimaryContainer,
  BronzeBwall: BronzeBwall,
  BronzeAlloy: BronzeAlloy,
  PowerPlants: PowerPlants,
  BronzeConveyor: BronzeConveyor,
  BronzeBAlloy: BronzeBAlloy,
  MeltingDrill: MeltingDrill,
  ForceMapping: ForceMapping,
  Laboratory: Laboratory,
  aurora: aurora,
  MediumBattery: MediumBattery,
  splitsky: splitsky,
}
