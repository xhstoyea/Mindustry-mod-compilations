const launchBases = Object.assign(new SectorPreset("LaunchBases", Planets.serpulo, 175), {
  difficulty: 6,//难度
  captureWave: 25,//波次（0的话是敌方基地）
  localizedName: "发射基地",//名称
  alwaysUnlocked: false,
  description: "[yellow]占领零号地区后，我朝着四周走了走，发现只能通过核心发射前往附近。"
})
module.exports = {
  launchBases: launchBases
};
/* ---=== 原版区块 ===--- */


/* ---=== 零号基地 ===--- */
SectorPresets.groundZero.captureWave = 20
SectorPresets.groundZero.difficulty = 4
SectorPresets.groundZero.description = "[yellow]不知为何我坠落在此，大脑一片空白，想不起来大多事情了。首要目标是活下去，收集这些叫什么铜和铅的东西，研究他们的科技。"
/* ---=== 零号基地 ===--- */

/* ---=== 冰冻森林 ===--- */
SectorPresets.frozenForest.captureWave = 25
SectorPresets.frozenForest.difficulty = 6
SectorPresets.frozenForest.description = "具有多个分叉口交错的区域，白雪覆盖了这里，它们还是蔓延到了这里。更强大的友军聚集在那里。\n\n[yellow]从发射基地了解到坐标后我从那发射到了这里。感觉有好多谜团，我只能一个个去解开."
/* ---=== 冰冻森林 ===--- */


/* ---=== 陨石带 ===--- */
SectorPresets.craters.captureWave = 20
SectorPresets.craters.difficulty = 4
SectorPresets.craters.description = "陨石坠落于此，带来了科技爆发，它们没能来到这里，但是不妨碍还是有一部分...\n\n[yellow]'他'没能到这里，原定再次撤离的地点，撤离地感觉敌人会很强大，我选择先来这里提升一下科技。"
/* ---=== 陨石带 ===--- */

/* ---=== 生物质合成区 ===--- */
SectorPresets.biomassFacility.captureWave = 35
SectorPresets.biomassFacility.difficulty = 10
SectorPresets.biomassFacility.description = "上级派下任务来此地研究{&@#&%}，我们投入了大量人力物力，但是...\n\n[yellow]'他'从这里逃离了出来，这就是逃离地啊，现在科技水平得到大增强，出发！"
/* ---=== 生物质合成区 ===--- */
