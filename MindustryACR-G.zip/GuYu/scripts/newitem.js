const Bronze = new Item("Bronze", Color.valueOf("ffd37f"))
const Stannum = new Item("Stannum", Color.valueOf("cfcfcf"))

module.exports = {
    Bronze: Bronze,
    Stannum: Stannum
  }
  