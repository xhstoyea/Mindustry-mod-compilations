const MySectors = require("sectors")
const myBlocks = require("newblock");
const myItems = require("newitem");
/*---------------------------------------------------------------------------*/

const Wit = Seq.with
const node = TechTree.node
const nodeProduce = TechTree.nodeProduce
const SectorComplete = Objectives.SectorComplete
const Research = Objectives.Research
const OnSector = Objectives.OnSector

/* ==== 改建造消耗 /= requirements =/ ==== */
Blocks.unloader.requirements = ItemStack.with(
  Items.copper, 30,
  Items.graphite, 15
)
Blocks.salvo.requirements = ItemStack.with(
  Items.copper, 100,
  Items.graphite, 20,
  myItems.Bronze, 50
)
Blocks.coreFoundation.requirements = ItemStack.with(
  Items.copper, 3000,
  Items.lead, 3000,
  myItems.Bronze, 3000
)
Blocks.scorch.requirements = ItemStack.with(
  Items.copper, 35,
  Items.graphite, 17
)
Blocks.illuminator.requirements = ItemStack.with(
  Items.lead, 4,
  Items.silicon, 4,
  Items.metaglass, 4
)
Blocks.hail.requirements = ItemStack.with(
  Items.copper, 60,
  Items.graphite, 37
)
Blocks.powerNodeLarge.requirements = ItemStack.with(
  myItems.Stannum, 10,
  Items.lead, 5,
  myItems.Bronze, 3
)
Blocks.steamGenerator.requirements = ItemStack.with(
  myItems.Bronze, 20,
  Items.lead, 20,
  Items.graphite, 30,
  Items.silicon, 25
)
Blocks.container.requirements = ItemStack.with(
  myItems.Bronze, 200
)
Blocks.groundFactory.requirements = ItemStack.with(
  myItems.Bronze, 90,
  Items.lead, 120,
  Items.silicon, 80
)
Blocks.airFactory.requirements = ItemStack.with(
  myItems.Bronze, 70,
  Items.lead, 100,
  Items.silicon, 70
)
Blocks.rotaryPump.requirements = ItemStack.with(
  Items.copper, 50,
  Items.metaglass, 90,
  myItems.Bronze, 20,
  Items.silicon, 20
)
Blocks.liquidContainer.requirements = ItemStack.with(
  Items.metaglass, 50,
  myItems.Bronze, 20,
)
myBlocks.splitsky.requirements = ItemStack.with(
  myItems.Bronze, 85,
  Items.lead, 75,
  Items.graphite, 45
)
myBlocks.aurora.requirements = ItemStack.with(
  myItems.Bronze, 100,
  myItems.Stannum, 60,
  Items.silicon, 60
)
myBlocks.aurora.buildVisibility = BuildVisibility.shown
myBlocks.splitsky.buildVisibility = BuildVisibility.shown
/* ==== 改建造消耗 /= requirements =/ ==== */


/* ==== 改研究消耗 /= researchCost =/ ==== */
Blocks.liquidContainer.researchCost = ItemStack.with(
  Items.metaglass, 4000,
  myItems.Bronze, 2500,
)
Blocks.rotaryPump.researchCost = ItemStack.with(
  Items.copper, 4000,
  Items.metaglass, 3000,
  myItems.Bronze, 2500,
  Items.silicon, 2000
)
Blocks.airFactory.researchCost = ItemStack.with(
  myItems.Bronze, 4000,
  Items.lead, 5000,
  Items.silicon, 4000
)
Blocks.groundFactory.researchCost = ItemStack.with(
  myItems.Bronze, 4000,
  Items.lead, 5000,
  Items.silicon, 4000
)
Blocks.unloader.researchCost = ItemStack.with(
  Items.copper, 1000,
  Items.graphite, 700
)
myBlocks.ForceMapping.researchCost = ItemStack.with(
  Items.lead, 3000,
  myItems.Stannum, 2500,
  myItems.Bronze, 2000,
  Items.silicon, 2000
)
Blocks.kiln.researchCost = ItemStack.with(
  Items.copper, 100,
  Items.lead, 100,
  Items.graphite, 100
)
myBlocks.MediumBattery.researchCost = ItemStack.with(
  myItems.Bronze, 2000,
  myItems.Stannum, 4000,
  Items.lead, 4000
) 
myBlocks.aurora.researchCost = ItemStack.with(
  myItems.Bronze, 1000,
  myItems.Stannum, 600,
  Items.graphite, 500
)
Blocks.salvo.researchCost = ItemStack.with(
  Items.copper, 500,
  Items.graphite, 50,
  myItems.Bronze, 300
)
Blocks.graphitePress.researchCost = ItemStack.with(
  Items.copper, 1000,
  Items.lead, 900
)
Blocks.arc.researchCost = ItemStack.with(
  Items.copper, 1000,
  Items.lead, 1000
)
myBlocks.BronzeAlloy.researchCost = ItemStack.with(
  Items.copper, 250,
  myItems.Stannum, 250,
  Items.graphite, 100
)
myBlocks.BronzeSwall.researchCost = ItemStack.with(
  myItems.Bronze, 60
)
myBlocks.BronzeBwall.researchCost = ItemStack.with(
  myItems.Bronze, 240
)
myBlocks.PrimaryContainer.researchCost = ItemStack.with(
  Items.copper, 1500,
  Items.graphite, 750
)
Blocks.itemBridge.researchCost = ItemStack.with(
  Items.copper, 100,
  Items.lead, 100
)
Blocks.combustionGenerator.researchCost = ItemStack.with(
  Items.copper, 250,
  Items.lead, 150
)
Blocks.battery.researchCost = ItemStack.with(
  Items.copper, 100,
  Items.lead, 400
)
myBlocks.PowerPlants.researchCost = ItemStack.with(
  Items.copper, 700,
  Items.graphite, 300,
  myItems.Stannum,100
)
Blocks.coreFoundation.researchCost = ItemStack.with(
  Items.copper, 8000,
  Items.lead, 8000,
  myItems.Bronze, 8000
)
myBlocks.BronzeConveyor.researchCost = ItemStack.with(
  myItems.Bronze, 1000,
  myItems.Stannum, 1000
)
myBlocks.BronzeBAlloy.researchCost = ItemStack.with(
  Items.graphite, 5000,
  myItems.Stannum, 6000,
  myItems.Bronze, 5000
)
Blocks.pneumaticDrill.researchCost = ItemStack.with(
  Items.graphite, 3000,
  myItems.Bronze, 3000
)
Blocks.copperWallLarge.researchCost = ItemStack.with(
  Items.copper, 200
)
Blocks.junction.researchCost = ItemStack.with(
  Items.copper, 20
)
Blocks.router.researchCost = ItemStack.with(
  Items.copper, 50
)
Blocks.itemBridge.researchCost = ItemStack.with(
  Items.copper, 60,
  Items.lead, 60
)
Blocks.itemBridge.researchCost = ItemStack.with(
  Items.copper, 60,
  Items.lead, 60
)
myBlocks.splitsky.researchCost = ItemStack.with(
  myItems.Bronze, 100,
  Items.lead, 100,
  Items.graphite, 50
)
/* ==== 改研究消耗 /= researchCost =/ ==== */

/* 钻头：240÷n/s = drillTime */


/*OnSector降落区块,SectorComplete占领区块*/
TechTree.roots.remove(0)
Planets.serpulo.techTree = TechTree.nodeRoot("serpulo", Blocks.coreShard, () => {

  node(Blocks.conveyor, () => {
    node(Blocks.junction, () => {
      node(Blocks.router, () => {

        node(Blocks.launchPad, Wit(new SectorComplete(SectorPresets.extractionOutpost)), () => {

        })
        
        node(Blocks.distributor)
        node(Blocks.sorter, () => {
          
          node(Blocks.invertedSorter)
          node(Blocks.overflowGate, () => {
            node(Blocks.underflowGate)
          })
        })

            node(Blocks.unloader, Wit(new OnSector(MySectors.launchBases)), () => { 
            node(myBlocks.PrimaryContainer, Wit(new Research(Items.graphite)), () => {
            node(Blocks.container, () => {
            node(Blocks.vault, () => {

           })
          })
         })
        })

        node(Blocks.itemBridge, () => {
          node(Blocks.titaniumConveyor, Wit(new SectorComplete(SectorPresets.craters)), () => {
            node(Blocks.phaseConveyor, () => {
              node(Blocks.massDriver, () => {

              })
            })

            node(Blocks.payloadConveyor, () => {
              node(Blocks.payloadRouter, () => {

              })
            })

            node(Blocks.armoredConveyor, () => {
              node(Blocks.plastaniumConveyor, () => {

              })
            })
          })
        })
      })
    })
  })

  node(Blocks.coreFoundation, Wit(new SectorComplete(SectorPresets.frozenForest)), () => {
    node(Blocks.coreNucleus, () => {

    })
  })

  node(Blocks.mechanicalDrill, () => {

    node(Blocks.mechanicalPump, () => {
      node(Blocks.conduit, () => {
        node(Blocks.liquidJunction, () => {
          node(Blocks.liquidRouter, () => {
            node(Blocks.liquidContainer, Wit(new OnSector(SectorPresets.biomassFacility)), () => {
              node(Blocks.liquidTank)
            })

            node(Blocks.bridgeConduit, () =>{
              node(Blocks.platedConduit, () => {

              })
            })

            node(Blocks.wave, () =>{
              node(Blocks.tsunami, () =>{

              })
            })

            node(Blocks.pulseConduit, Wit(new SectorComplete(SectorPresets.windsweptIslands)), () => {
              node(Blocks.phaseConduit, () => {

              })
            })
          })
        })
      })
      node(Blocks.rotaryPump, Wit(new OnSector(SectorPresets.biomassFacility)), () =>{
        node(Blocks.impulsePump, () => {

        })
      })
    })

    node(Blocks.graphitePress, Wit(new OnSector(MySectors.launchBases)), () => {

      node(myBlocks.BronzeAlloy, Wit(new OnSector(SectorPresets.frozenForest)), () => {
          node(myBlocks.BronzeConveyor, Wit(new SectorComplete(SectorPresets.frozenForest)), () => {

       })
       node(myBlocks.BronzeBAlloy, Wit(new SectorComplete(SectorPresets.frozenForest)), () => {

       })
      })

      node(Blocks.pneumaticDrill, Wit(new SectorComplete(SectorPresets.frozenForest)), () => {
        node(Blocks.cultivator, Wit(new OnSector(SectorPresets.biomassFacility)), () => {

        })

        node(Blocks.laserDrill, () => {
          node(Blocks.blastDrill, Wit(new SectorComplete(SectorPresets.nuclearComplex)), () => {

          })

          node(Blocks.waterExtractor, Wit(new SectorComplete(SectorPresets.saltFlats)), () => {
            node(Blocks.oilExtractor, () => {

            })
          })
        })
      })

      node(Blocks.pyratiteMixer, Wit(new SectorComplete(SectorPresets.craters)), () => {
        node(Blocks.blastMixer, () => {

        })
      })
      node(Blocks.kiln, Wit(new OnSector(SectorPresets.craters)), () => {
        node(Blocks.pulverizer, () => {
          node(Blocks.incinerator, () => {
            node(Blocks.melter, () => {
              node(Blocks.surgeSmelter, () => {

              })

              node(Blocks.separator, () => {
                node(Blocks.disassembler, () => {

                })
              })

              node(Blocks.cryofluidMixer, () => {

              })
            })
          })
        })
      })

      node(Blocks.siliconSmelter, Wit(new OnSector(SectorPresets.craters)), () => {

        node(Blocks.sporePress, Wit (new SectorComplete(SectorPresets.biomassFacility)), () => {
          node(Blocks.coalCentrifuge, () => {
            node(Blocks.multiPress, () => {
              node(Blocks.siliconCrucible, () => {

              })
            })
          })

          node(Blocks.plastaniumCompressor, Wit(new SectorComplete(SectorPresets.windsweptIslands)), () => {
            node(Blocks.phaseWeaver, Wit(new SectorComplete(SectorPresets.tarFields)), () => {

            })
          })
        })


        node(Blocks.microProcessor, Wit(new SectorComplete(SectorPresets.biomassFacility)), () => {
          node(Blocks.switchBlock, () => {
            node(Blocks.message, () => {
              node(Blocks.logicDisplay, () => {
                node(Blocks.largeLogicDisplay, () => {

                })
              })

              node(Blocks.memoryCell, () => {
                node(Blocks.memoryBank, () => {

                })
              })
            })

            node(Blocks.logicProcessor, () => {
              node(Blocks.hyperProcessor, () => {

              })
            })
          })
        })

        node(Blocks.illuminator, () => {

        })
      })
    })


    node(Blocks.combustionGenerator, Wit(new Research(Items.coal)), () => {
      node(Blocks.arc, () => {
        node(myBlocks.aurora,  Wit(new OnSector(SectorPresets.craters)), () => {
        node(Blocks.lancer, () => {
          node(Blocks.meltdown, () => {

            })
          })
        })
      })
      node(myBlocks.PowerPlants, Wit(new OnSector(SectorPresets.frozenForest)), () => {
      })
       node(Blocks.powerNode, () => {
        node(Blocks.powerNodeLarge, Wit(new OnSector(SectorPresets.frozenForest)), () => {
          node(Blocks.diode, () => {
            node(Blocks.surgeTower, () => {

            })
          })
        })

        node(Blocks.battery, () => {
          node(myBlocks.MediumBattery, Wit(new SectorComplete(SectorPresets.frozenForest)), () => {
            node(Blocks.batteryLarge, () => {

            })
          })
        })

        node(Blocks.mender, () => {
          node(Blocks.mendProjector, () => {
            node(Blocks.forceProjector, Wit(new SectorComplete(SectorPresets.impact0078)), () => {
              node(Blocks.overdriveProjector, Wit(new SectorComplete(SectorPresets.impact0078)), () => {
                node(Blocks.overdriveDome, Wit(new SectorComplete(SectorPresets.impact0078)), () => {

                })
              })
            })

            node(Blocks.repairPoint, () => {
              node(Blocks.repairTurret, () => {

              })
            })
          })
        })

        node(Blocks.steamGenerator, Wit(new OnSector(SectorPresets.craters)), () => {
          node(Blocks.thermalGenerator, Wit(new SectorComplete(SectorPresets.craters)) ,() => {
            node(Blocks.differentialGenerator, () => {
              node(Blocks.thoriumReactor, Wit(new Research(Liquids.cryofluid)), () => {
                node(Blocks.impactReactor, () => {

                })

                node(Blocks.rtgGenerator, () => {

                })
              })
            })
          })
        })

        node(Blocks.solarPanel, () => {
          node(Blocks.largeSolarPanel, () => {

          })
        })
      })
    })

  node(Blocks.duo, () => {
    node(Blocks.copperWall, () => {
      node(Blocks.copperWallLarge, () => {

        node(myBlocks.BronzeSwall, Wit(new Research(myItems.Bronze)), () => {
          node(myBlocks.BronzeBwall, Wit(new Research(myItems.Bronze)), () => {
          })
        })

        node(Blocks.titaniumWall, () => {
          node(Blocks.titaniumWallLarge)

          node(Blocks.door, () => {
            node(Blocks.doorLarge)
          })
          node(Blocks.plastaniumWall, () => {
            node(Blocks.plastaniumWallLarge, () => {

            })
          })
          node(Blocks.thoriumWall, () => {
            node(Blocks.thoriumWallLarge)
            node(Blocks.surgeWall, () => {
              node(Blocks.surgeWallLarge)
              node(Blocks.phaseWall, () => {
                node(Blocks.phaseWallLarge)
              })
            })
          })
        })
      })
      node(Blocks.shockMine, () => {
      })
      node(Blocks.segment, () => {
      })
      node(myBlocks.ForceMapping, Wit(new OnSector(SectorPresets.craters)), () => {

      })
    })
    
    node(Blocks.salvo, Wit(new OnSector(SectorPresets.frozenForest)), () => {
      node(Blocks.cyclone, () => {
        node(Blocks.swarmer, () => {
          node(Blocks.spectre, Wit(new SectorComplete(SectorPresets.nuclearComplex)), () => {
          })
        })  
      })
    })
    node(Blocks.hail, Wit(new SectorComplete(MySectors.launchBases)), () => {
      node(Blocks.ripple, () => {
        node(Blocks.foreshadow, () => {

          })
        })
      node(Blocks.fuse, () => {
      })

    })

    node(Blocks.scatter, () => {
      node(myBlocks.splitsky, Wit(new OnSector(SectorPresets.biomassFacility)), () => {

      })
        node(Blocks.parallax, () => {
      })
    })

    node(Blocks.scorch, Wit(new OnSector(MySectors.launchBases)),() => {

      })
    })
  })

  node(Blocks.groundFactory, Wit(new SectorComplete(SectorPresets.biomassFacility)), () => {

    node(UnitTypes.dagger, () => {
      node(UnitTypes.mace, () => {
        node(UnitTypes.fortress, () => {
          node(UnitTypes.scepter, () => {
            node(UnitTypes.reign, () => {

            })
          })
        })
      })

      node(UnitTypes.nova, () => {
        node(UnitTypes.pulsar, () => {
          node(UnitTypes.quasar, () => {
            node(UnitTypes.vela, () => {
              node(UnitTypes.corvus, () => {

              })
            })
          })
        })
      })

      node(UnitTypes.crawler, () => {
        node(UnitTypes.atrax, () => {
          node(UnitTypes.spiroct, () => {
            node(UnitTypes.arkyid, () => {
              node(UnitTypes.toxopid, () => {

              })
            })
          })
        })
      })
    })

    node(Blocks.airFactory, () => {
      node(UnitTypes.flare, () => {
        node(UnitTypes.horizon, () => {
          node(UnitTypes.zenith, () => {
            node(UnitTypes.antumbra, () => {
              node(UnitTypes.eclipse, () => {

              })
            })
          })
        })

        node(UnitTypes.mono, () => {
          node(UnitTypes.poly, () => {
            node(UnitTypes.mega, () => {
              node(UnitTypes.quad, () => {
                node(UnitTypes.oct, () => {

                })
              })
            })
          })
        })
      })

      node(Blocks.navalFactory, Wit(new SectorComplete(SectorPresets.ruinousShores)), () => {
        node(UnitTypes.risso, () => {
          node(UnitTypes.minke, () => {
            node(UnitTypes.bryde, () => {
              node(UnitTypes.sei, () => {
                node(UnitTypes.omura, () => {

                })
              })
            })
          })

          node(UnitTypes.retusa, Wit(new SectorComplete(SectorPresets.windsweptIslands)), () => {
            node(UnitTypes.oxynoe, Wit(new SectorComplete(SectorPresets.coastline)), () => {
              node(UnitTypes.cyerce, () => {
                node(UnitTypes.aegires, () => {
                  node(UnitTypes.navanax, Wit(new SectorComplete(SectorPresets.navalFortress)), () => {

                  })
                })
              })
            })
          })
        })
      })
    })

    node(Blocks.additiveReconstructor, Wit(new SectorComplete(SectorPresets.biomassFacility)), () => {
      node(Blocks.multiplicativeReconstructor, () => {
        node(Blocks.exponentialReconstructor, Wit(new SectorComplete(SectorPresets.overgrowth)), () => {
          node(Blocks.tetrativeReconstructor, () => {

          })
        })
      })
    })
  })
   node(SectorPresets.groundZero, () => {
    node(MySectors.launchBases, Wit(new SectorComplete(SectorPresets.groundZero)), () => {
     node(SectorPresets.frozenForest, Wit(new SectorComplete(MySectors.launchBases),
                                           new Research(Blocks.hail)), () => {
      node(SectorPresets.craters, Wit(new SectorComplete(SectorPresets.frozenForest),
                                            new Research(myBlocks.BronzeConveyor)), () => {
       node(SectorPresets.biomassFacility, Wit(new SectorComplete(SectorPresets.craters),
                                                new Research(Blocks.thermalGenerator)), () => {
        node(SectorPresets.fungalPass, Wit (new SectorComplete(SectorPresets.biomassFacility),
                                             new Research(Blocks.sporePress)), () => {
         node(SectorPresets.overgrowth, Wit(new SectorComplete(SectorPresets.fungalPass)), () => {
          node(SectorPresets.impact0078, Wit(new SectorComplete(SectorPresets.overgrowth)), () => {
           node(SectorPresets.desolateRift, Wit(new SectorComplete(SectorPresets.impact0078)), () => {
              
           })
          })
          node(SectorPresets.extractionOutpost, Wit(new SectorComplete(SectorPresets.overgrowth)), () => {
           node(SectorPresets.saltFlats, Wit(new SectorComplete(SectorPresets.extractionOutpost)), () => {
            node(SectorPresets.coastline, Wit(new SectorComplete(SectorPresets.saltFlats)), () => {
             node(SectorPresets.navalFortress, Wit(new SectorComplete(SectorPresets.coastline)), () => {
              node(SectorPresets.planetaryTerminal, Wit(new SectorComplete(SectorPresets.navalFortress)), () => {

             })
            })
           })
          })
         })
        })
       })
        node(SectorPresets.ruinousShores, Wit(new SectorComplete(SectorPresets.biomassFacility),
                                               new Research(Blocks.sporePress)), () => {
         node(SectorPresets.windsweptIslands, Wit(new SectorComplete(SectorPresets.ruinousShores)), () => {
          node(SectorPresets.stainedMountains, Wit(new SectorComplete(SectorPresets.windsweptIslands)), () => {
           node(SectorPresets.tarFields, Wit(new SectorComplete(SectorPresets.stainedMountains)), () => {
            node(SectorPresets.nuclearComplex, Wit(new SectorComplete(SectorPresets.tarFields)), () => {

            })
           })
          })
         })
        })
       })
      })
     })
    })
   })
     
  
  nodeProduce(Items.copper, () => {
    nodeProduce(Liquids.water, () => {

    })
    nodeProduce(myItems.Stannum,() => {
      nodeProduce(myItems.Bronze,() =>{

      })
    })

    nodeProduce(Items.lead, () => {
      nodeProduce(Items.titanium, () => {
        nodeProduce(Liquids.cryofluid, () => {

        })

        nodeProduce(Items.thorium, () => {
          nodeProduce(Items.surgeAlloy, () => {

          })

          nodeProduce(Items.phaseFabric, () => {

          })
        })
      })

      nodeProduce(Items.metaglass, () => {

      })
    })

    nodeProduce(Items.sand, () => {
      nodeProduce(Items.scrap, () => {
        nodeProduce(Liquids.slag, () => {

        })
      })

      nodeProduce(Items.coal, () => {
        nodeProduce(Items.graphite, () => {
          nodeProduce(Items.silicon, () => {

          })
        })

        nodeProduce(Items.pyratite, () => {
          nodeProduce(Items.blastCompound, () => {

          })
        })

        nodeProduce(Items.sporePod, () => {

        })

        nodeProduce(Liquids.oil, () => {
          nodeProduce(Items.plastanium, () => {

          })
        })
      })
    })
  })
})
TechTree.roots.swap(0, 1)
