const chilly = extend(StatusEffect, "chilly", {
    color: Color.valueOf("6ecdec"),
    speedMultiplier: 0.95,
    reloadMultiplier: 0.95,
    transitionDamage: 3,
    effect: Fx.freezing
});
chilly.init(() => {
    chilly.opposite(StatusEffects.melting);

    chilly.affinity(StatusEffects.wet, (unit, result, time) =>
        unit.apply(StatusEffects.freezing, 300)
    );
    chilly.affinity(StatusEffects.shocked, (unit, result, time) => {
        unit.damagePierce(chilly.transitionDamage);
        unit.apply(StatusEffects.electrified, 300);
    });

    Weathers.snow.status = chilly
});

exports.chilly = chilly