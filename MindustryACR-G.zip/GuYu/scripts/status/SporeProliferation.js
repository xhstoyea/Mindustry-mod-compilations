const Incineration = require("status/Incineration");
const SporeProliferation = extend(StatusEffect, "SporeProliferation", {
    color: Color.valueOf("7457ce"),
    speedMultiplier: 0.75,
    reloadMultiplier: 0.7,
    effect: Fx.sapped
});
SporeProliferation.init(() => {
    SporeProliferation.opposite(StatusEffects.burning,StatusEffects.melting,Incineration.Incineration)
});

exports.SporeProliferation = SporeProliferation