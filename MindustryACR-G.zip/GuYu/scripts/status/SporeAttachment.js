const SporeProliferation = require("status/SporeProliferation");
const Incineration = require("status/Incineration");
const SporeAttachment = extend(StatusEffect, "SporeAttachment", {
  color: Color.valueOf("7457ce"),
  speedMultiplier: 0.85,
  effect: Fx.sapped,
  transitionDamage: 9
});
SporeAttachment.init(() => {
    SporeAttachment.affinity(StatusEffects.wet, (unit, result, time) => 
        unit.apply(SporeProliferation.SporeProliferation, 360)
    );
    SporeAttachment.affinity(StatusEffects.burning, (unit, result, time) => {
        unit.apply(Incineration.Incineration, 300);
        unit.damagePierce(SporeAttachment.transitionDamage);
    });
});

exports.SporeAttachment = SporeAttachment