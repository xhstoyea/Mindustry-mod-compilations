const chilly = require("status/chilly");
const Incineration = extend(StatusEffect, "Incineration", {
    color: Color.valueOf("ffa939"),
    speedMultiplier: 0.85,
    damage: 0.35,
    effect: Fx.burning
});
Incineration.init(() => {
    Incineration.opposite(StatusEffects.wet,StatusEffects.freezing,chilly.chilly)
});

exports.Incineration = Incineration