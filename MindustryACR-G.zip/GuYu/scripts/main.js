require("status/SporeAttachment");
require("status/SporeProliferation");
require("status/Incineration");
require("status/chilly");
require("sectors");
clearSectorOnLose = true;
//-------------------------------------------战役图结束后不禁用世界处理器
Events.run(EventType.ClientLoadEvent, () => {
    Events.run(EventType.SectorCaptureEvent, () => {
      Time.run(5, () => Vars.state.rules.disableWorldProcessors = false)
    })
  })
/* difficulty = 数字/2取整 2低度 4中度 6高度 8极高 */
require("newitem");
require("newblock");
require("research");
require("blocks/MeltingDrill");
require("LaboratoryDialog");