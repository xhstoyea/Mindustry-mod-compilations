Events.on(WorldLoadEvent, () => {
        Blocks.tankAssembler.plans.get(0).requirements.get(1).amount = 14,
        Blocks.tankAssembler.plans.get(0).time = 60 * 70,
    Blocks.tankAssembler.nonOptionalConsumers[4] = new ConsumeLiquid(Liquids.cyanogen, 12 / 60)
    }
)