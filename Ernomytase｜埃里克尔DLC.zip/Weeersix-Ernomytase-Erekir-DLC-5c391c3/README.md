# Ernomytase - Erekir DLC

Hi!
The mod is a continuation of Erekir's campaign. The units of the sixth tier and many new blocks have been added. I make the mod alone, so updates may not come out as often.
Good luck!

The mod is in development...
