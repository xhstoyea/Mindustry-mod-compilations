
SectorPresets.groundZero.captureWave = 10
SectorPresets.groundZero.difficulty = 2

SectorPresets.frozenForest.captureWave = 15
SectorPresets.frozenForest.difficulty = 2

SectorPresets.craters.captureWave = 20
SectorPresets.craters.difficulty = 2

SectorPresets.biomassResearchFacility.captureWave = 20
SectorPresets.biomassResearchFacility.difficulty = 2

SectorPresets.ruinousShores.captureWave = 30
SectorPresets.ruinousShores.difficulty = 2

SectorPresets.fungalPass.captureWave = 0
SectorPresets.fungalPass.difficulty = 2
