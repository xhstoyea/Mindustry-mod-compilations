Events.on(EventType.ClientLoadEvent, () => {
    var url = "https://mdt.wayzer.top/api/servers/servers.json?version=" + Version.build
    var callback = d => {
        try {
            let list = JSON.parse(new java.lang.String(d.getResult(), "UTF-8"));
            Core.app.post(() => {
                try {
                    //Vars.defaultServers.clear();
                    list.forEach(t => {
                        Vars.defaultServers.add(ServerGroup(t.name, t.address))
                    })
                } catch (error) { print(error) }
            })
        } catch (error) { print(error) }
    }

    if (Version.build >= 128)
        Http.get(url, callback)
    else
        Core.net.httpGet(url, callback, () => { })
})