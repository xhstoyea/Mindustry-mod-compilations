const nodeRoot = TechTree.nodeRoot;
const node = TechTree.node;
const { 核心 } = require("星球/核心");
const { TBLY } = require("星球/泰伯利亚");
const { LiquidUnloader } = require("液体装卸器");
const { itemNode,liquidNode } = require("nodes");


TBLY.techTree = nodeRoot("泰伯利亚", 核心, true, () => {
	node(LiquidUnloader, () => {

	});
	node(itemNode, () => {

	});
	node(liquidNode, () => {

	});
});

function addToResearch(map, obj) {
	let parentNode = map.planet.techTree.all.find(node => { return node.name == obj.parent });
	parentNode.children.add(node(map, obj.objectives, () => { }));
}
