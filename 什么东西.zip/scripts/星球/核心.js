const 核心 = new CoreBlock('核心');
exports.核心 = 核心;