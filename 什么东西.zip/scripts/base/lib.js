const loader = Vars.mods.mainLoader();
const scripts = Vars.mods.scripts;
const NativeJavaClass = Packages.rhino.NativeJavaClass;
function getClass(name) {
    return NativeJavaClass(scripts.scope, loader.loadClass("avaritia." + name));
};

const MultiCrafter = getClass("multicraft.MultiCrafter")

const PhaseNode = getClass("world.blocks.PhaseNode")

const LiquidUnloader = getClass("world.blocks.LiquidUnloader")

module.exports = {
    MultiCrafter: MultiCrafter,
    PhaseNode: PhaseNode,
    LiquidUnloader: LiquidUnloader
}