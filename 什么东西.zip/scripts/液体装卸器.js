const { LiquidUnloader } = require("base/lib");

let lu = new LiquidUnloader("液体装卸器");
lu.localizedName = "液体装卸器";
lu.speed = 6;
lu.health = 70;
lu.liquidCapacity = 10;
lu.requirements = ItemStack.with(
    Items.metaglass, 10,
    Items.silicon, 20
);
lu.buildVisibility = BuildVisibility.shown;
lu.category = Category.effect;
exports.LiquidUnloader = lu;