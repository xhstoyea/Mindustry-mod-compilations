const { PhaseNode } = require("base/lib");

const itemNode = new PhaseNode("物品节点");
itemNode.localizedName = "物品节点";
itemNode.buildCostMultiplier = 0.25;
itemNode.range = 25;
itemNode.hasPower = true;
itemNode.envEnabled |= 2;
itemNode.consumePower(1.0);
itemNode.transportTime = 1.0;
itemNode.placeableLiquid = true;
itemNode.setupRequirements(
    Category.distribution,
    ItemStack.with(
        Items.copper, 110,
        Items.lead, 80,
        Items.silicon, 100,
        Items.graphite, 85,
        Items.titanium, 45,
        Items.thorium, 40,
        Items.phaseFabric, 18
    )
);
exports.itemNode = itemNode;

const liquidNode = new PhaseNode("液体节点");
liquidNode.localizedName = "液体节点";
liquidNode.buildCostMultiplier = 0.25;
liquidNode.range = 25;
liquidNode.hasPower = true;
liquidNode.canOverdrive = false;
liquidNode.hasLiquids = true;
liquidNode.hasItems = false;
liquidNode.outputsLiquid = true;
liquidNode.consumePower(1.0);
liquidNode.placeableLiquid = true;
liquidNode.setupRequirements(
    Category.liquid, ItemStack.with(
        Items.metaglass, 80,
        Items.silicon, 90,
        Items.graphite, 85,
        Items.titanium, 45,
        Items.thorium, 40,
        Items.phaseFabric, 25
    )
);
exports.liquidNode = liquidNode;
