MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000
require("星球/tree");
require("液体装卸器");
require("nodes");