const 水 =Attribute.add("水")
exports.水 =水