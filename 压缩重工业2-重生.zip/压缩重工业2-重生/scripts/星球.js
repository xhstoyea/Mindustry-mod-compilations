//此代码来自无限宇
Planets.sun.meshLoader = () => new SunMesh(Planets.sun, 5, 6, 3.4, 2.8, 1.3, 0.8, 1.1,
    Color.valueOf("8FFBFFFF"),
    Color.valueOf("5AAAFF"),
    Color.valueOf("4CA3FF"),
    Color.valueOf("488CD6"),
    Color.valueOf("90C6FF"),
    Color.valueOf("B2D7FF")
);

Planets.sun.radius = 5; //太阳大小
const lib = require("lib");
const {初代核心} = require('核心');
const 斯特文 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(斯特文, 7));//行星网格数量 2的7次幂加一
        this.super$load();
    }//行星构建
}, "斯特文", Planets.sun, 2);//类型:行星
斯特文.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(斯特文, 2, 0.15, 0.14, 5, Color.valueOf("D65050FF"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(斯特文, 3, 0.6, 0.15, 5, Color.valueOf("D81919FF"), 2, 0.42, 1.2, 0.45)
));
const c1 = Color.valueOf("881E1EFF"), c2 = Color.valueOf("881E1EFF"), c3 = Color.valueOf("7CAEF3FF");//行星总体颜色
const sS = require("sectorSize");
sS.planetGrid(斯特文, 3);//行星网格大小

斯特文.generator = /*星球生成*/extend(SerpuloPlanetGenerator,{//生成塞普罗植物
	allowLanding (sector) {
		return false
	},//所有区块全部应用此生成
    getColor(position) {
        var depth = Simplex.noise3d(4, 4, 0.56, 1.6, position.x, position.y, position.z) / 2;/*三维柏林噪声生成
        变量 深度 =三维柏林噪声(坐标，1.7，xyz位置)/2 
        建议别改*/
        return c1.write(c3).lerp(c2, Mathf.clamp(Mathf.round(depth, 0.25)));//返回值
    },
});

斯特文.atmosphereColor = Color.valueOf("881E1EFF");//大气层颜色
斯特文.landCloudColor = Color.valueOf("C42424FF");//云层颜色
斯特文.atmosphereRadIn = 0.005;
斯特文.atmosphereRadOut = 6;//星球大气层厚度
斯特文.lightSrcTo = 2.5;//区块光照变化
斯特文.lightDstFrom  = 10;//大气层
斯特文.localizedName = "斯特文";//行星名
斯特文.visible = true;//星球是否可见
斯特文.bloom = false;//开花(？不知道什么东西，关了)
斯特文.updateLighting = true;//区块的昼夜交替
斯特文.accessible = true;//星球是否可以到达
斯特文.launchCapacityMultiplier = 0.9;//发射核心时最大可携带的资源量，“1”为发射的核心的100%容量，0.5为50%
斯特文.allowLaunchSchematics = true;//开启发射核心蓝图
斯特文.description = "被赛普罗首次发现后进行探索的星球 ";//星球介绍
斯特文.allowSectorInvasion = true;//模拟攻击图入侵
斯特文.allowWaveSimulation = true;//模拟后台波次
斯特文.alwaysUnlocked = true;//默认解锁
斯特文.clearSectorOnLose = false;//不知道什么玩意，关了吧
斯特文.allowLaunchLoadout = true;//允许带资源发射核心
斯特文.startSector = 273;//星球起始公转方向(相对于太阳，1~360随便填)
斯特文.orbitRadius = 50;//星球轨道半径
斯特文.tidalLock = false//星球潮汐锁定
斯特文.iconColor = Color.valueOf("#C42424FF");//图标颜色
斯特文.rotateTime = 1.2;//星球自转一周的时间
斯特文.defaultCore= 初代核心//默认发射核心

exports.斯特文= 斯特文




const map1 = new SectorPreset("Welcome",斯特文, 1);
map1.alwaysUnlocked = true;//默认解锁此区块
map1.difficulty = 0;//难度
map1.captureWave = 1;//敌人波数
map1.description = "欢迎来到本模组 本模组的话这是一张开局的预备地图 玩家在这里发展  同时#代表支线 *代表主线 ";//统计资料顶上的简介
map1.localizedName = "*Welcome";//区块名
exports.map1 = map1//地图排序

const map2 = new SectorPreset("岩浆湖",斯特文, 2);
map2.alwaysUnlocked = false;//默认解锁此区块
map2.difficulty = 1;//难度
map2.captureWave = 15;//敌人波数
map2.description = "这里被一个巨大的岩浆湖泊所笼罩，留给我们发展的空间不多，但是资源极多------资源碳化物 ";//统计资料顶上的简介
map2.localizedName = "*熔江湖泊";//区块名
exports.map2 = map2//地图排序

const map3 = new SectorPreset("沿岸点",斯特文, 216);
map3.alwaysUnlocked = false;//默认解锁此区块
map3.difficulty = 2;//难度
map3.captureWave = 25;//敌人波数
map3.description = "这颗星球上为数不多水源充分的地方 好好利用这里的水资源以及沙子！ ";//统计资料顶上的简介
map3.localizedName = "*沿岸点";//区块名
exports.map3 = map3//地图排序

const map4 = new SectorPreset("前哨基地",斯特文, 4);
map4.alwaysUnlocked = false;//默认解锁此区块
map4.difficulty = 4;//难度
map4.description = "这里是他们的一个小型的前哨基地，我们的任务是摧毁他，以绝后患";//统计资料顶上的简介
map4.localizedName = "#前哨基地";//区块名
exports.map4 = map4//地图排序

const map5 = new SectorPreset("熔桨溪流",斯特文, 5);
map5.alwaysUnlocked = false;//默认解锁此区块
map5.difficulty = 3;//难度
map5.captureWave = 30;//敌人波数
map5.description = "我们发现大大小小的地方都有一定的敌方基地 这里也不例外 是击退这里的敌人或者是将敌方的基地击败 ";//统计资料顶上的简介
map5.localizedName = "*熔桨溪流";//区块名
exports.map5 = map5//地图排序

const map6 = new SectorPreset("边缘矿区",斯特文, 6);
map6.alwaysUnlocked = false;//默认解锁此区块
map6.difficulty = 4;//难度
map6.captureWave = 30;//敌人波数
map6.description = "这里是一处矿区 距离其他区块偏 资源量分布较少 好好利用资源";//统计资料顶上的简介
map6.localizedName = "*边缘矿区";//区块名
exports.map6 = map6//地图排序

const map7 = new SectorPreset("前哨中心",斯特文, 7);
map7.alwaysUnlocked = false;//默认解锁此区块
map7.difficulty = 4;//难度
map7.description = "这里是他们的前哨总部 防御力极其森严 做好与其战斗的打算 ";//统计资料顶上的简介
map7.localizedName = "#前哨中心";//区块
exports.map7 = map7//地图排序

const map8 = new SectorPreset("山区",斯特文, 8);
map8.alwaysUnlocked = false;//默认解锁此区块
map8.difficulty = 5;//难度
map8.captureWave = 45;//敌人波数
map8.description = "这处山谷的敌人非常多 注意好防御以及后勤部分 一定要共同发展 防止其空中火力 ";//统计资料顶上的简介
map8.localizedName = "*段横山谷";//区块名
exports.map8 = map8//地图排序

const map9 = new SectorPreset("冰川地下",斯特文, 129);
map9.alwaysUnlocked = false;//默认解锁此区块
map9.difficulty = 5;//难度
map9.captureWave = 20;//敌人波数
map9.description = "不敢想象这颗星球竟然还有冰川 不过是在地下  但是这里的信号波动异常 感觉会有一场大战等着我们...... ";//统计资料顶上的简介
map9.localizedName = "*地下冰川";//区块名
exports.map9 = map9//地图排序

const map10 = new SectorPreset("核爆区",斯特文, 119);
map10.alwaysUnlocked = false;//默认解锁此区块
map10.difficulty = 6;//难度
map10.captureWave = 50;//敌人波数
map10.description = " ";//统计资料顶上的简介
map10.localizedName = "*核爆区";//区块名
exports.map10 = map10//地图排序