const library = require("library");
const myitems = require("物品");
const 双重资源炼制厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "双重资源炼制厂", [
  {
    input: {//输入
    items: 
    ["压缩重工业2-重生-碳化物/2"],     
    },
    output: {//输出
    items: ["压缩重工业2-重生-压缩石墨/3"],
    },
    craftTime: 58,
  }, 
  
  {
    input: {//输入
    items: 
    ["压缩重工业2-重生-压缩铅/2"],     
    },
    output: {//输出
    items: ["压缩重工业2-重生-压缩玻璃/3"],
    },
    craftTime: 28,
  }, 
]
)