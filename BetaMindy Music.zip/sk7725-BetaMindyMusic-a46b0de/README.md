# BetaMindyMusic
Music assets for sk7725/BetaMindy.

## Music Credits
```
Roccow - Echiptian Swaggah
Roccow - Sweet Self Satisfaction
```
