Planets.tantros.visible = true;//可见
Planets.tantros.accessible = true;
//在行星菜单可见
Planets.tantros.localizedName = "萨伏伊尔"; //名字
Planets.tantros.alwaysUnlocked = true;
Planets.tantros.hiddenItems.add(Items.serpuloItems).add(Items.erekirItems);/** 隐藏物品  *///解锁
Planets.notva.visible = true;//可见
Planets.notva.drawOrbit = true, 
Planets.notva.accessible = true;//在行星菜单可见
Planets.notva.localizedName = "纳维塔"; //名字
Planets.notva.alwaysUnlocked = true;//解锁
Planets.gier.visible = true;//可见
Planets.gier.accessible = true;
Planets.gier.drawOrbit = true, //在行星菜单可见
Planets.gier.localizedName = "吉尔"; 
Planets.gier.alwaysUnlocked = true;//解锁
