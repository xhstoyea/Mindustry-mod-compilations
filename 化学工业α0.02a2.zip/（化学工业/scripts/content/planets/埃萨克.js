const lib = require("lib");
const ASK = new Planet("埃萨克", Planets.sun, 1.2, 2.5);
ASK.meshLoader = prov(() => new MultiMesh(
	new HexMesh(ASK, 6)
));
ASK.generator = extend(ErekirPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nA3JMQ6AIBAAwQXFR56r9i4XuMBR5XkCAYkP9LphwcbmLO75/lHMwRq0SY3vF470sGluHdTdRFH+RvTQ17XoZNStU9d0na20gDduA463HAc0Org==")
	}
});
ASK.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(ASK, 2, 0.15, 0.14, 5, Color.valueOf("E28654FF"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(ASK, 3, 0.6, 0.15, 5, Color.valueOf("E28654FF"), 2, 0.42, 1.2, 0.45)
));
ASK.generator = new ErekirPlanetGenerator();
ASK.visible = ASK.accessible = ASK.alwaysUnlocked = true;
ASK.clearSectorOnLose = true;
ASK.tidalLock = false;
ASK.defaultAttributes.set(Attribute.heat, 0.8);
ASK.allowLaunchLoadout = true, 
ASK.allowLaunchSchematics = true, 
ASK.updateLighting = false;
ASK.lightSrcTo = 0.5;
ASK.allowLaunchToNumbered = true
ASK.lightDstFrom = 0.2;
ASK.defaultEnv = Env.scorching | Env.terrestrial;
ASK.defaultCore = Blocks.coreBastion;
ASK.localizedName = "埃萨克";
ASK.prebuildBase = true;
ASK.bloom = false;
ASK.startSector = 2;
ASK.orbitRadius = 25;
ASK.atmosphereRadIn = 0.02;
ASK.atmosphereRadOut = 0.3;
ASK.atmosphereColor = ASK.lightColor = Color.valueOf("E28654FF");
ASK.iconColor = Color.valueOf("E28654FF"),
ASK.hiddenItems.addAll(Items.serpuloItems).removeAll(Items.erekirItems);
