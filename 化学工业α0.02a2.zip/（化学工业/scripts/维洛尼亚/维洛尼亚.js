Planets.verlius.visible = true;//可见
Planets.verlius.accessible = true;//在行星菜单可见
Planets.verlius.localizedName = "维洛尼亚"; //名字
Planets.verlius.alwaysUnlocked = true;//解锁