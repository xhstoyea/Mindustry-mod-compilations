require("物品");
require("盖羲茨亚");
require("旅途");