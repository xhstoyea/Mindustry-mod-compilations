require("Z核心");
require('开屏菜单');
//鬼知道我从哪整的