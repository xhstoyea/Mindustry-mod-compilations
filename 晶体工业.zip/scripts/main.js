MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 40000

require("核心");

require('开屏菜单');
//鬼知道我从哪整的