const Z核心 = extend(CoreBlock, "Z核心", {

     canBreak() {
         return Vars.state.teams.cores(Vars.player.team()).size > 1;
     },
     canReplace(other) {
         return other.alwaysReplace;
     },
     canPlaceOn(tile, team) {
         return true;
     },
 });
 exports.Z核心 = Z核心;