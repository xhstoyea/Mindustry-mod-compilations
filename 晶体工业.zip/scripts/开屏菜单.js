Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("晶体工业"); //新建一个显示窗口
    
    // 添加贴图（假设贴图ID是 "alphaaaa"）
    dialog.cont.image(Core.atlas.find("logo")).row();
    
    dialog.buttons.button("@close", run(() => {
        dialog.hide(); //退出界面
    })).size(128, 64); //@close
    
    dialog.cont.button("加入晶体工业群", run(() => {
        Core.app.openURI("http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=mq_AXhT-_V9XjFJ14YFghhabuavwHK3o&authKey=F%2Bz%2BnZw%2FhN3eVxRb%2BARpKFVbkowFMn%2Fuims2GUWHK1wJASvXBopmE54BWlZgocbi&noverify=0&group_code=2158027406");
    })).size(100, 70).pad(3);
    
    dialog.cont.pane((() => {
        var table = new Table();
        table.add("作者b站:[yellow]一个屑爬重");
        table.row();
        table.add("附属制作:[green]花瓶星");
        table.row();
        table.add("现在更新:铍双管能上碳化物").left().growX().wrap().width(200).maxWidth(300).pad(4).labelAlign(Align.left);
        table.row();
        return table;
    })()).grow().center().maxWidth(300);
    
    dialog.show();
}));