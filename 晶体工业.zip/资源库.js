        一些不知有啥的东西
        
    "bullet": {
        "weaveScale": 3,   // 摆动幅度（数值越大，摆动越宽）
        "weaveMag": 6,     // 摆动频率（数值越大，摆动越快）
        }
        
                    // === 连发配置 ===
            "shoot": {
                "shots": 2,              // 每次触发发射
                "shotDelay": 0           // 连发间隔（0=同时发射）
            },
            这是单位的
            
        
      	"rangeChange": 30,
      	这是加子弹射程的
        
        单位工厂
        {
            "type": "UnitSpawnAbility", // 单位生成能力
            "unit": "单位名", // 生成的单位类型
            "spawnTime": 800, // 生成单位的时间间隔（单位：帧，每秒60帧）
            "spawnY": 0, // 生成单位的Y轴偏移
            "spawnX": 0 // 生成单位的X轴偏移
        }
        
        让你的炮台动起来
"drawer":{
"type":"DrawTurret",
    "parts":[
       {
    "type":"RegionPart",
    "mirror":false,//是否开启镜像
    "x":0,
    "y":0,//初始位置
    "suffix":"-1"//,贴图后缀 在你的贴图后面写一个就行
    "layer":50,//层，49-110
    "moveX":0,//改变位置
    "moveY":8.5
    }
    ]
    },
        
        
   类似于生物的翅膀  不知道为啥有人拿这玩意做螺旋桨
        "parts": [  // 单位部件（用于装饰或动画效果）
        {
            "type": "RegionPart",  // 部件类型：区域部件
            "mirror": true,  // 是否镜像（是否在两侧各显示一个）
            "x": 0,  // 部件位置（X坐标）
            "y": 0,  // 部件位置（Y坐标）
            "suffix": "-wing",  // 部件后缀（用于指定显示的图像）//贴图写这个 你要动的贴图-wing
            "moveX": 0,  // 部件水平移动偏移量
            "moveY": 0,  // 部件垂直移动偏移量
            "moveRot": 30,  // 部件旋转角度
            "outline": false,  // 是否绘制轮廓
            "progress": {  // 部件动画进度
                "type": "smoothReload",  // 动画类型：平滑重载
                "op": "sin",  // 操作函数：正弦
                "offset": 20,  // 偏移量
                "scl": 1,  // 缩放值
                "mag": 1  // 幅度
            }
        }
    ]
    
    
    
    一堆的特效
    {
  "type": "LaserTurret",
  "drawer": {
    "type": "drawTurret",
    "parts": [
      // 主发光圆环 (白色高亮核心)
      {
        "type": "shapePart",       // 基础图形部件
        "progress": {             // 动态效果控制
          "type": "charge",       // 随充能进度变化
          "op": "blend",          // 混合其他效果
          "other": "recoil",      // 混合后坐力效果
          "amount": 0.5          // 混合比例
        },
        "y": 9,                  // Y轴偏移位置
        "circle": true,           // 绘制圆形
        "layer": 114,             // 渲染层级(较高)
        "color": "ffFFFFff",      // 纯白色带透明度
        "radiusTo": 4.5,          // 最大半径
        "radius": 0               // 初始半径(从0开始增长)
      },
      
      // 次级发光圆环 (蓝色光晕)
      {
        "type": "shapePart",
        "progress": {             // 与主圆环同步变化
          "type": "charge",
          "op": "blend",
          "other": "recoil",
          "amount": 0.5
        },
        "y": 9,                   // 与主圆环同位置
        "circle": true,
        "layer": 110,              // 稍低的渲染层级
        "color": "66B1FFFF",       // 天蓝色带透明度
        "radiusTo": 6,             // 更大的半径(光晕效果)
        "radius": 0
      },

      // 副发光圆环 (顶部白色光点)
      {
        "type": "shapePart",
        "progress": {             // 同步充能效果
          "type": "charge",
          "op": "blend",
          "other": "recoil",
          "amount": 0.5
        },
        "moveY": -5,              // 上移5单位(炮管顶部位置)
        "circle": true,
        "layer": 114,             // 高渲染层级
        "color": "ffFFFFff",      // 纯白光
        "radiusTo": 5.5,          // 中等大小
        "radius": 0
      },

      // 副光晕圆环 (顶部蓝色光晕)
      {
        "type": "shapePart",
        "progress": {             // 同步变化
          "type": "charge",
          "op": "blend",
          "other": "recoil",
          "amount": 0.5
        },
        "moveY": -5,              // 与白色光点同位置
        "circle": true,
        "layer": 110,             // 稍低层级
        "color": "66B1FFFF",       // 天蓝色
        "radiusTo": 7,             // 最大光晕范围
        "radius": 0
      }
    ]
  }
}
    
    
    
    