物品
{
    "name":"钢",//名字
    "description":"通过铁炼出的一种",//介绍
    "details ":"金属",//介绍但是会在最底下
    "color":"808080",//颜色
    "explosiveness":0,//爆炸能力
    "flammability":0,//燃烧能力
    "radioactivity":0,//核辐射能力
    "hardness":0.6,//建造时间
    "cost":1,//我不知道有啥用应该没用
    "alwaysUnlocked":false,//是否直接研究
    "research":"铁"//研究前置
}
液体
{
	"name": "铁水",//名字
	"description": "通过将铁融化获得的液体",//介绍
	"alwaysUnlocked":false,//是否直接研究//介绍但是会在最底下
	"color": "ff4019",//颜色
	"flammability": 0,//可燃性
	"temperature": 20,//温度
	"heatCapacity": 0,//热容量
	"viscosity": 0,//粘性
	"explosiveness": 0,//爆炸性
	"research": "铁"//研究前置
}
注意JSON所有代码都是这样
{代码}
或者这样
{
代码
}
"这是一个数组":[{"这是数组里的代码":false},{"他还可以放两个":2}],"代码就是这样"
这是一个样板炮台代码
{
    "type": "ItemTurret",//类型炮台
    "name": "炮台",//名字
    "description": "这里没什么",//介绍
    "health": 114514,//血量
    "size": 1~16,//炮台大小最大16X16只能设置成正方形比如设置为1=1X1
    "reload": 60,//子弹发射间隔60=1秒
    "range": 400,//自动攻击范围(10=1格)
    "maxAmmo": 20,//最大弹药数
    "recoilTime": 10,//后坐力恢复时间60=1秒
    "recoil": 10,//后坐力60=1秒
    "heatRequirement":114514,//热力要求可以不加
	"cooldownTime": 300,//冷却时间
	"minWarmup": 0.5,//展开到百分之多少的时候开始射击1=100%设置最大0.99
    "consumes": {//消耗
        "coolant": {//液体消耗
            "amount": 0.1,//消耗量(实际消耗量=这里写的Ⅹ60)
            "optional": true//是否为强化效果，否将作为弹药，是将作为冷却液
        }//冷却液
    },
    "shoot": {//炮台炮口设置
        "shots": 1,//开火炮口数
        "shotDelay": 0//多个炮口之间发射延迟。
	"type":"ShootAlternate",//炮口类似双管炮
	"shootY":3,//子弹发射之后出现的位置这里为偏移Y3
	"barrels":2,//子弹出现点数量
	"spread":8//两个子弹出现点之间的长度
    },
    "drawer": {//攻击效果
    "type": "DrawMulti",
    "drawers": [
    {
    "type": "DrawTurret",
    "parts": [
    {
    "type":"RegionPart",//攻击效果转起来
    "progress":"recoil",//贴图那边名字设置为 炮台-r 和 炮台-l 注意画贴图的时候是不用改炮台-r炮台-l的方向他们的方向在贴图里是一个方向比如炮台-r是左边炮台-l一定要是左边
    "mirror":true,//镜像不知道有什么用但是不用改
    "under":false,//贴图是否在最下面
    "suffix":"-blade",//不知道有什么用
    "layer":51,//贴图50~51
    "moveX":0,//贴图位置X坐标
    "moveY":0,//贴图位置Y坐标
    "moveRot":-25转的角度
    }
    ]
    }
    ]
},
    "ammoPerShot": 1,//弹药消耗倍数。
    "shootSound": "shootBig",//子弹音效
    "targetGround": true,//可以攻击陆地单位
    "targetAir": true,//可以攻击天空单位
    "inaccuracy": 2,//误差角度
    "shake": 5,//振动
    "shootCone": 45,
    "ammoTypes": {//弹药
      "使用物品": {//使用物品
        "type": "LaserBulletType",//类型激光
        "ammoMultiplier": 1,//弹药倍数意思就是你设置他为2放一个物品炮台里就是两个物品注意炮台里的东西不可以取出
        "damage": 150,//伤害
        "length": 500,//激光长度
        "lifetime": 120,//激光存在时间设置60=1秒
        "pierceCap":20,
        "lightColor": "e63939",//颜色
        "colorFrom": "e61717",//颜色
        "colorTo": "e63939",//颜色
        "buildingDamageMultiplier":0.2//攻击建筑的时候建筑收到的伤害X0.2
      }
   },//弹药类型
    "rotateSpeed": 2,//炮台转头速度
    "requirements": [
    "铜铅合金/114514",
    "铁/114514"
    ],//造价
    "category":"turret",建筑菜单位置这里是炮台
    "research": {//研究
        "parent": "完整",//研究前置
        "requirements": [//研究费用
            "铜铅合金/114514"
	    "铁/114514"
       ]
    }
}
工厂样板
{
	"name":"电硅炉",//名字
	"type":"GenericCrafter",//工厂类型
	"description": "就是不需要煤炭的硅",//介绍
	"itemCapacity":20,//物品容量
	"health":500,//血量
	"size":2,////炮台大小最大16X16只能设置成正方形比如设置为1=1X1
	"hasPower": true,//是否消耗电力这里是开启
	"hasLiquids": false,//是否消耗液体这里是关闭
	"hasItems": true,//是否消耗物品这里是开启
	"craftTime":25,//制作要使用的时间
	"updateEffect": "none",//工作效果
	"consumes": {//消耗
		"power":1,//消耗电力设置为1=60单位的电力
		"items": {
			"items": [
				{ "item": "sand", "amount": 2 }//这里是材料消耗设置为沙子
			]
}
	},
  	"liquidCapacity": 600,//
	"outputItem": { "item": "silicon", "amount": 1/*这里是输出数量这里的设置为1*/ },//输出物品这里是硅
	"requirements": [//建造材料
		"铜铅合金/25",//这还用说
		"copper/250",//铜
		"lead/100"//铅
	],
	"category": "crafting",//建筑菜单位置这里是工厂
	"research": {//研究
		"parent": "机械铜铅合金制作机",//研究前置
        "requirements": [//研究消耗材料
            		"铜铅合金/25",//这个要是不知道你别做模组了
			"copper/150",//铜
			"lead/50"//铅
		]
    },
	"idleSound": "respawning",
	"idleSoundVolume": 0.5
}
模组结构
模组名字-模组名字
			|-content----------|-blocks
			|-maps	                |-items
			|-music                   |-liquids
			|-scripts                 |-status
			|-sounds                |-planets
			|-sprites                 |-sectors
			|-icon.png           units
		mod.json
--------------------------------分割线--------------------------------
blocks(建筑)
items(物品)
liquids(液体)
planets(JSON星球)
sectors(JSON星球区块)
status(效果)
units(单位)
content(模组的内容)
maps(模组里的地图)
music(模组里的音乐)
scripts(JS代码)
sounds(模组里的声音)
sprites(模组里的贴图)
icon.png(模组在游戏中显示的贴图)
mod.json(没有他游戏识别不出来这是个模组)
物品代码
copper -铜
lead -铅
metaglass -钢化玻璃
graphite -石墨
sand -沙
coal -煤炭
titanium -钛
thorium -钍
scrap -废料
silicon -硅
plastanium -塑钢
phase-fabric -相织物
surge-alloy -巨浪合金
spore-pod -孢子荚
blast-compound -爆炸混合物
pyratite -硫
beryllium -铍
tungsten -钨
oxide -氧化物
carbide -碳化物
dormant-cyst -休眠囊肿
液体代码
water -水
slag -矿渣
oil -石油
cryofluid -冷却液
neoplasm -瘤液
arkycite -芳油
gallium -镓
ozone -臭氧
hydrogen -氢气
nitrogen -氮气
cyanogen -氰气
建筑
电力
赛普罗
power-node  -电力节点
power-node-large  -大型电力节点
surge-tower  -合金电力塔
diode  -二极管
battery  -电池
battery-large  -大型电池
solar-panel  -太阳能板
solar-panel-large  -大型太阳能板
combustion-generator  -火力发电机
steam-generator  -涡轮发电机
rtg-generator  -RTG 发电机
differential-generator  -温差发电机
thorium-reactor  -钍反应堆
impact-reactor  -冲击反应堆
埃里克尔
beam-node = 激光节点
beam-tower = 激光塔
beam-link = 激光连接器
turbine-condenser = 涡轮冷凝器
chemical-combustion-chamber = 化学燃烧室
pyrolysis-generator = 热解发生器
钻头
赛普罗
mechanical-drill  -机械钻头
pneumatic-drill  -气动钻头
laser-drill  -激光钻头
blast-drill  -爆破钻头
water-extractor  -抽水机
cultivator  -培养机
oil-extractor  -石油钻井
埃里克尔
vent-condenser  -排气冷凝器
cliff-crusher  -墙壁粉碎机
plasma-bore  -等离子钻机
large-plasma-bore  -大型等离子钻机
impact-drill  -冲击钻头
eruption-drill  -爆裂钻头
炮台
赛普罗
wave  -波浪
tsunami  -海啸
swarmer  -蜂群
salvo  -齐射
ripple  -浪涌
cyclone  -气旋
fuse  -雷光
arc  -电弧
segment  -裂解
spectre  -幽灵
meltdown  -熔毁
foreshadow  -厄兆
duo  -双管
scorch  -火焰
scatter  -分裂
hail  -冰雹
lancer  -蓝瑟
埃里克尔
breach  -撕裂
sublimate  -升华
titan  -泰坦
disperse  -驱离
afflict  -劫难
lustre  -光辉
scathe  -创伤
diffuse  -扩散
smite  -天谴
malign  -魔灵
墙
赛普罗
copper-wall  -铜墙
copper-wall-large  -大型铜墙
titanium-wall  -钛墙
titanium-wall-large  -大型钛墙
plastanium-wall  -塑钢墙
plastanium-wall-large  -大型塑钢墙
phase-wall  -相织布墙
phase-wall-large  -大型相织布墙
thorium-wall  -钍墙
thorium-wall-large  -大型钍墙
door  -门
door-large  -大门
埃里克尔
beryllium-wall  -铍墙
beryllium-wall-large  -大型铍墙
tungsten-wall  -钨墙
tungsten-wall-large  -大型钨墙
blast-door  -防爆闸门
carbide-wall  -碳化物墙
carbide-wall-large  -大型碳化物墙
reinforced-surge-wall  -强化合金墙
reinforced-surge-wall-large  -大型强化合金墙
shielded-wall  -盾墙
工厂
赛普罗
silicon-smelter  -硅冶炼厂
phase-weaver  -相织布编织器
pulverizer  -粉碎机
cryofluid-mixer  -冷冻液混合器
melter  -熔炉
incinerator  -焚化炉
spore-press  -孢子压缩机
separator  -分离机
coal-centrifuge  -煤炭离心机
disassembler  -解离机
kiln  -窑炉
graphite-press  -石墨压缩机
multi-press  -多重压缩机
plastanium-compressor  -塑钢压缩机
pyratite-mixer  -硫化物混合器
blast-mixer  -爆炸物混合器
埃里克尔
silicon-arc-furnace  -电弧硅炉
electrolyzer  -电解机
atmospheric-concentrator  -大气收集器
oxidation-chamber  -氧化室
electric-heater  -电制热机
slag-heater  -矿渣制热机
phase-heater  -相织制热机
heat-redirector  -热量传输机
heat-router  -热量路由器
slag-incinerator  -矿渣焚化炉
carbide-crucible  -碳化物坩埚
slag-centrifuge  -矿渣离心机
surge-crucible  -合金坩埚
cyanogen-synthesizer  -氰合成机
phase-synthesizer  -相织布合成机
运输
赛普罗
phase-conveyor  -相织布传送带桥
bridge-conveyor  -传送带桥
conveyor  -传送带
titanium-conveyor  -钛传送带
plastanium-conveyor  -塑钢传送带
armored-conveyor  -装甲传送带
junction  -交叉器
router  -路由器
distributor  -分配器
sorter  -分类器
inverted-sorter  -反向分类器
overflow-gate  -溢流门
underflow-gate  -反向溢流门
埃里克尔
duct-router  -物品管道路由器
duct-bridge  -物品管道桥
duct  -物品管道
armored-duct  -装甲管道
overflow-duct  -溢流管道
underflow-duct  -反向溢流管
duct-unloader  -管道装卸器
surge-conveyor  -合金传送带
surge-router  -合金路由器
地图
地板
sand-boulder  -砂岩
basalt-boulder  -玄武岩石块
grass  -草地
molten-slag  -矿渣液
pooled-cryofluid  -冷冻液
space  -太空
salt  -盐碱地
pebbles  -鹅卵石
tendrils  -卷须
spore-pine  -孢子树
boulder  -石块
snow-boulder  -雪石块
snow-pine  -雪树
shale  -页岩地
shale-boulder  -页岩石块
moss  -苔藓地
shrubs  -灌木丛
spore-moss  -孢子苔藓地
deep-water  -深水
shallow-water  -水
tainted-water  -污水
deep-tainted-water  -深污水
darksand-tainted-water  -黑沙污水
tar  -石油
stone  -石头
sand-floor  -沙子
darksand  -黑沙
ice  -冰
snow  -雪
crater-stone  -陨石坑
sand-water  -浅滩
darksand-water  -黑沙浅滩
char  -焦土
dacite  -安山岩
rhyolite  -流纹岩
dacite-boulder  -安山石块
ice-snow  -冰雪地
pine  -松树
dirt  -泥土
mud  -泥巴
spore-cluster  -孢子簇
metal-floor  -金属地板1
metal-floor-2  -金属地板2
metal-floor-3  -金属地板3
metal-floor-4  -金属地板4
metal-floor-5  -金属地板5
metal-floor-damaged  -损坏的金属地板
dark-panel-1  -暗面板1
dark-panel-2  -暗面板2
dark-panel-3  -暗面板3
dark-panel-4  -暗面板4
dark-panel-5  -暗面板5
dark-panel-6  -暗面板6
dark-metal  -暗金属
basalt  -玄武岩
hotrock  -灼热岩石
magmarock  -熔融岩石
empty  -空
rhyolite-crater  -流纹岩坑
rough-rhyolite  -粗糙流纹岩
regolith  -流纹岩
yellow-stone  -黄石
carbon-stone  -碳石
ferric-stone  -铁石
ferric-craters  -铁陨石坑
beryllic-stone  -铍石
crystalline-stone  -晶石
crystal-floor  -晶石地板
yellow-stone-plates  -黄石地板
red-stone  -红石
dense-red-stone  -高密红石
red-ice  -红冰
arkycite-floor  -芳油
arkyic-stone  -芳石
rhyolite-vent  -流纹石喷口
carbon-vent  -碳石喷口
arkyic-vent  -芳石喷口
yellow-stone-vent  -黄石喷口
red-stone-vent  -红石喷口
crystalline-vent  -晶石喷口
redmat  -红地垫
bluemat  -蓝地垫
墙
salt-wall  -盐墙
sand-wall  -沙墙
spore-wall  -孢子墙
shale-wall  -页岩墙
dacite-wall  -安山岩墙
stone-wall  -石墙
ice-wall  -冰墙
snow-wall  -雪墙
dune-wall  -沙丘岩
dirt-wall  -泥土墙