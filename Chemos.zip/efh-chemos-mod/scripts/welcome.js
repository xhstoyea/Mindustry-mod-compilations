Log.info("Loading Chemos mod.");
Events.on(EventType.ClientLoadEvent,cons(e => {
  var dialog = new BaseDialog("Welcome!");
  dialog.cont.image(Core.atlas.find("chemos-icon")).row();
  dialog.cont.add("\nThanks for playing Chemos mod.\nNow let's dive into a [red]hardcore[white] world D:\n").row();
  dialog.cont.image(Core.atlas.find("chemos-ohno")).row();
  dialog.cont.add("\nThis mod is still [blue]WIP[white] without any campaign contents.\n").row();
  dialog.cont.button("OK",run(() => {
    dialog.hide();
  })).size(100,50);
  dialog.show();
}));
