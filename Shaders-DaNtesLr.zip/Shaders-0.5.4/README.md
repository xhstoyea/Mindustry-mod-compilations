# RU
 Шейдер, который изменяет внешний вид жидкостей. Взято из мода "[FactoryDustry-Texture Pack](https://github.com/Xeloboyo/Factoriodustry)". 
 
 Специално для канала "[Mindustry - Рестор](https://www.youtube.com/channel/UCgKL4PVJRt_2rAGOwOVhOMw)". 
 
 Мой Дискорд DaNtEsLr#0746 \
Советую версию мода от [FallenDraggon - BetterLiquids](https://github.com/FallenDraggon/BetterLiquids)

# EN
 A shader that changes the appearance of liquids. Taken from the mod "[FactoryDustry-Texture Pack](https://github.com/Xeloboyo/Factoriodustry)". 
 
Especially for the channel "[Mindustry - Рестор](https://www.youtube.com/channel/UCgKL4PVJRt_2rAGOwOVhOMw)".
 
 My Discord DaNtEsLr#0746 \
I recommend the mod version from [FallenDraggon - BetterLiquids](https://github.com/FallenDraggon/BetterLiquids)
