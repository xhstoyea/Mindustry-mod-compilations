// 文件：mod-core/content/scripts/drone_core.js

// 1. 核心自由放置逻辑
const droneCore = extendContent(CoreBlock, "drone-core", {
  canPlaceOn(tile, team) {
    return true; // 无视地形限制
  },
  
  placed(tile) {
    this.super$placed(tile);
    // 初始化生产计时器（单位：帧）
    tile.entity.timer = 0;
  }
});

// 2. 无人机自动生产系统
droneCore.update = (tile) => {
  this.super$update(tile);
  
  // 每10秒生产一架原版无人机（60帧/秒 × 10秒 = 600帧）
  if(tile.entity.timer++ >= 600) {
    // 生成原版"dagger"无人机
    const unit = UnitTypes.dagger.spawn(tile.team, tile.drawx(), tile.drawy());
    unit.controller(LogicAI); // 设为自动模式
    tile.entity.timer = 0; // 重置计时器
    
    // 生产特效
    Fx.spawnShockwave.at(tile.drawx(), tile.drawy());
  }
  
  // 3. 自动防御炮塔系统
  const enemy = Units.closestEnemy(tile.team, tile.drawx(), tile.drawy(), 20);
  if(enemy) {
    // 生成无限弹药激光
    const angle = Mathf.angle(enemy.x - tile.drawx(), enemy.y - tile.drawy());
    Bullets.lancerLaser.create(
      tile.team, tile.drawx(), tile.drawy(), 
      angle, 3, 75, 2 // 伤害75，穿透2个目标
    );
    Fx.lightningShoot.at(tile.drawx(), tile.drawy(), angle);
  }
};