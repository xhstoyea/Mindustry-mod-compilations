//@Minxyzgo，使用标注来源
const applyspeed = extendContent(StatusEffect,"applyspeed",{});
applyspeed.damage = 0.;
applyspeed.armorMultiplier = 1;
applyspeed.speedMultiplier = 1.2;
applyspeed.color = Color.valueOf("#003261");
applyspeed.effect = Fx.none;


const trainState = new UnitState(){
    entered(){
    },

    exited(){
    },

    update(){
    },
};//在getStartState()中返回它，否则新建的trainType无法运输.
const trainType = extendContent(UnitType, "train", {});
trainType.create(prov(()=> extend(MinerDrone, {
  /*  tr:new Vec2(),
    tr2:new Vec2(),
    region:null,
    weaponRotation:90,
    drawWeapons(){
        Draw.rect(this.region, this.x + this.tr2.x, this.y + this.tr2.y, this.weaponRotation - 90);
    },*/
    /*load(){
        this.super$load();
        this.region = Core.atlas.find(this.name + "-weapon");
    },*/
    
    
    /*drawWeapons(){
        if(this.type.rotateWeapon){
            for(var x in Mathf.signs){
                var i = Mathf.signs[x];
                var tra = this.rotation - 90, trY = -(this.type.weapon.getRecoil(this, i > 0)) + this.type.weaponOffsetY;
                if(this.target != null && this.isOnConveyor()) tra = Angles.angle(this.x, this.y, this.target.getX(), this.target.getY()) - 90;
                var w = -i * this.type.weapon.region.getWidth() * Draw.scl;
                Draw.rect(this.type.weapon.region,
                    this.x + Angles.trnsx(tra, this.getWeapon().width * i, trY),
                    this.y + Angles.trnsy(tra, this.getWeapon().width * i, trY), w, this.type.weapon.region.getHeight() * Draw.scl, this.rotation - 90);
            }
        }else{
            this.super$drawWeapons();
        }
    },之后再试.*/
    
    getStartState(){
        return trainState;
    },
    isOnConveyor(){
        if(this.tileOn() == null) return false;
        return this.tileOn().block() instanceof Conveyor;
    },
    
    update(){
        this.super$update();
        this.target = Units.findAllyTile(this.getTeam(), this.getX(), this.getY(), 300, boolf(other =>{
            return other.block() instanceof Conveyor;
        }));
        
        
        if(!this.isOnConveyor()){
            this.moveTo(0);
        }else{
            this.target = Units.closestTarget(this.getTeam(), this.getX(), this.getY(), this.getWeapon().bullet.range());
        }
    },
    avoidOthers(){
        this.super$avoidOthers();
        if(this.isOnConveyor() || this.hasEffect(applyspeed)){
            var fsize = this.getSize() * 1.5;
            var cx = this.x - fsize/2, cy = this.y - fsize/2;
            
            this.convoid(Vars.unitGroup.intersect(cx, cy, fsize, fsize));
        }
    },
    convoid(arr){
        if(arr == null) return;
        arr.each(cons(unit =>{
            if(!unit.isFlying() && unit.id != this.id && unit.getTeam() != this.getTeam()){
                unit.onDeath();
            }
        }))
    },
    behavior(){
        if(!this.isOnConveyor()) return;
        if(!Units.invalidateTarget(this.target, this)){
            if(this.dst(this.target) < this.getWeapon().bullet.range()){
                if(this.type.rotateWeapon){
                    for(var i in Mathf.booleans){
                        var left = Mathf.booleans[i];
                    
                        var wi = Mathf.num(left);
                        var wx = this.x + Angles.trnsx(this.rotation - 90, this.getWeapon().width * Mathf.sign(left));
                        var wy = this.y + Angles.trnsy(this.rotation - 90, this.getWeapon().width * Mathf.sign(left));

                        this.weaponAngles[wi] = Mathf.slerpDelta(this.weaponAngles[wi], Angles.angle(wx, wy, this.target.getX(), this.target.getY()), 0.1);
                        Tmp.v2.trns(this.weaponAngles[wi], this.getWeapon().length);
                        this.getWeapon().update(this, wx + Tmp.v2.x, wy + Tmp.v2.y, this.weaponAngles[wi], left);
                    }
                }else if(Angles.near(this.angleTo(this.target), this.rotation, 13)){
                    const ammo = this.getWeapon().bullet;

                    const to = Predict.intercept(this, this.target, ammo.speed);

                    this.getWeapon().update(this, to.x, to.y);
                }
            }
        }
    },
})));
trainType.speed = 0;
trainType.health = 5000;
trainType.mass = 3;
trainType.itemCapacity = 1000;

const trainUnloader = extendContent(Block, "trainUnloader", {
    update(tile){
        
        const e = tile.ent();
        if(e.items.total() > 0){
            this.tryDump(tile);
        };
        const unit = this.getUnit(tile);
        if(unit == null) return;
        var isUnitIRange = unit.withinDst(tile.drawx(), tile.drawy(), this.range);
        if(isUnitIRange){
            const capacity = unit.getItemCapacity();
            const amount = unit.item().amount;
            if(amount == 0) return;
            const item = unit.item().item;
            var za = this.itemCapacity - e.items.total();
            var ai = Math.min(amount, za);
            if(ai <= 0){
                return;
            }else{
                Calls.transferItemTo(item, ai, unit.getX(), unit.getY(), tile);
                unit.item().amount -= ai;
            }
        }
    },
    configured(tile, player, value){
        tile.ent().linkId = value;
    },
    onConfigureTileTapped(tile, other){
        if(tile == other) return false;
        const entity = tile.ent();
        const unit = this.getUnit(tile);
        const otherUnit = Units.closest(tile.getTeam(), other.drawx(), other.drawy(), 35, boolf(unit =>{
                if(unit instanceof Player) return false;
                
                if(unit.getStartState() == trainState) return true;
                
                return false;
                
        }));
        if(otherUnit != null && other.dst(tile) <= this.range){
            
            tile.configure(otherUnit.id);
            return false;
        }

        return true;
    },
    drawConfigure(tile){
        const sin = Mathf.absin(Time.time(), 6, 1);

        Draw.color(Pal.accent);
        Lines.stroke(1);
        Drawf.circles(tile.drawx(), tile.drawy(), (tile.block().size / 2 + 1) * Vars.tilesize + sin - 2, Pal.accent);

        const entity = tile.ent();
        const unit = this.getUnit(tile);
        if(unit != null){
            Drawf.circles(unit.getX(), unit.getY(), unit.getSize() + sin - 2, Pal.place);
            Drawf.arrow(tile.drawx(), tile.drawy(), unit.getX(), unit.getY(), this.size * Vars.tilesize + sin, 4 + sin);
        }

        Drawf.dashCircle(tile.drawx(), tile.drawy(), this.range, Pal.accent);
    },
    getUnit(tile){
        const e = tile.ent();
        if(e.linkId == -1) return null;
        return Vars.unitGroup.getByID(e.linkId);
    },
    acceptItem(item, tile, source){
        const unit = this.getUnit(tile);
        if(unit == null) return false;
        return item.id == unit.item().item.id;
    },
});
trainUnloader.entityType = prov(() =>extend(Unloader.UnloaderEntity, {
    getlinkId(){return this._linkId},
    setlinkId(value){this._linkId = value},
    _linkId:-1,
}));
trainUnloader.range = 60

const trainInput = extendContent(Block, "trainInput", {
    update(tile){
        const e = tile.ent();
        const unit = this.getUnit(tile);
        const firstItem = e.items.first();
        
        
        if(unit == null || firstItem == null) return;
        var isUnitIRange = unit.withinDst(tile.drawx(), tile.drawy(), this.range);
        var firstAmount = e.items.get(firstItem);
        if(isUnitIRange){
            
            const capacity = unit.getItemCapacity();
            const amount = unit.item().amount;
            const item = unit.item().item;
            var za = capacity - amount;
            var ai = Math.min(firstAmount, za);
            if(ai <= 0){
                return;
            }else{
                
                for(var i = 0; i < Mathf.clamp(ai / 3, 1, 8); i++){
                    Time.run(i * 3, run(() =>{
               Calls.transferItemToUnit(firstItem, tile.drawx(), tile.drawy(), unit);
                    }));
                }
                
                e.items.remove(firstItem, ai);
            }
        }
    },
    configured(tile, player, value){
        tile.ent().linkId = value;
    },
    onConfigureTileTapped(tile, other){
        if(tile == other) return false;
        const entity = tile.ent();
        const unit = this.getUnit(tile);
        const otherUnit = Units.closest(tile.getTeam(), other.drawx(), other.drawy(), 35, boolf(unit =>{
                if(unit instanceof Player) return false;
                
                if(unit.getStartState() == trainState) return true;
                
                
                return false;
                
        }));
        if(otherUnit != null && other.dst(tile) <= this.range){
            
            tile.configure(otherUnit.id);
            return false;
        }

        return true;
    },
    drawConfigure(tile){
        const sin = Mathf.absin(Time.time(), 6, 1);

        Draw.color(Pal.accent);
        Lines.stroke(1);
        Drawf.circles(tile.drawx(), tile.drawy(), (tile.block().size / 2 + 1) * Vars.tilesize + sin - 2, Pal.accent);

        const entity = tile.ent();
        const unit = this.getUnit(tile);
        if(unit != null){
            Drawf.circles(unit.getX(), unit.getY(), unit.getSize() + sin - 2, Pal.place);
            Drawf.arrow(tile.drawx(), tile.drawy(), unit.getX(), unit.getY(), this.size * Vars.tilesize + sin, 4 + sin);
        }

        Drawf.dashCircle(tile.drawx(), tile.drawy(), this.range, Pal.accent);
    },
    getUnit(tile){
        const e = tile.ent();
        if(e.linkId == -1) return null;
        return Vars.unitGroup.getByID(e.linkId);
    },
    acceptItem(item, tile, source){
        const entity = tile.ent();
        const item2 = entity.items.first();
        if(item2 == null || (item2 == item && entity.items.get(item2) < this.itemCapacity)){
            return true;
        }else{
            return false;
        }
    },
});
trainInput.entityType = prov(() =>extend(Unloader.UnloaderEntity, {
    getlinkId(){return this._linkId},
    setlinkId(value){this._linkId = value},
    _linkId:-1,
}));
trainInput.range = 80
