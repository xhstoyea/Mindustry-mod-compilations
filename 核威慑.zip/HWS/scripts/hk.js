const ys = extendContent(Block, "ys", {
    update(tile){
        const unitType = ContentType.unit;
        var unit2 = Vars.content.getByName(unitType, "[#adff2f]核威慑-ravager");
        UnitCreate(tile, unit2, 1);
        tile.ent().kill();
        
    }
})

const xv = extendContent(Block, "xv", {
    update(tile){
        const unitType = ContentType.unit;
        var unit2 = Vars.content.getByName(unitType, "[#adff2f]核威慑-storm-unit");
        UnitCreate(tile, unit2, 1);
        tile.ent().kill();
        
    }
})

const sc = extendContent(Block, "sc", {
    update(tile){
        const unitType = ContentType.unit;
        var unit2 = Vars.content.getByName(unitType, "[#adff2f]核威慑-scourge");
        UnitCreate(tile, unit2, 1);
        tile.ent().kill();
        
    }
})

const hk = extendContent(Block, "hk", {
    update(tile){
        const unitType = ContentType.unit;
        var unit2 = Vars.content.getByName(unitType, "[#adff2f]核威慑-pestilence");
        UnitCreate(tile, unit2, 1);
        tile.ent().kill();
        
    }
})

function UnitCreate(itile,iUnit,range){
    const units = Vars.content.units();
    var unitI = units.get(iUnit.id).create(itile.getTeam());
    unitI.set(itile.drawx() + Mathf.range(range), itile.drawy() + Mathf.range(range) + range);
    Effects.effect(Fx.unitSpawn, unitI.x, unitI.y, 0, unitI);
    unitI.add();
    unitI.velocity().y = 0;
}