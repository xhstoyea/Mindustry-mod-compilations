const effectColor = Color.valueOf("7070BF");
const effectColor2 = Color.valueOf("FFFFFF");

const shieldRange = 50;

const sepShield = extend(BasicBulletType,{
	update(b){
		
	},
	init(b){
		if(b == null)return;
		Effects.effect(newEffect(35,e => {
			Draw.color(effectColor);
			Lines.stroke(e.fout() * 4); 
			Lines.poly(e.x, e.y, 6, shieldRange * 0.525 + 75 * e.fin());
		}), effectColor, b.x, b.y, b.rot());
	},
	draw(b){
		const f = Mathf.curve(b.fout(), 0.8, 0);
		Draw.color(effectColor);
		Lines.stroke(f * 3); 
		Lines.poly(b.x, b.y, 6, (shieldRange * 0.525) * f * f);
	}
});
sepShield.damage = 0;
sepShield.speed = 0;
sepShield.lifetime = 80;
sepShield.despawnEffect = Fx.none;
sepShield.drawSize = shieldRange * 1.5;


const sepEnergyCloud = extend(MissileBulletType,{
	range(){return 800},
	update(b){
		b.velocity(Mathf.curve(b.finpow(), 0.12, 0.85) * this.speed + 0.75, b.rot());
		Effects.effect(newEffect(40,e => {
			Draw.color(effectColor, Color.valueOf("#1C3057"), e.fin());
			const trnsB = new Vec2();
			trnsB.trns(e.rotation, e.fin() * (22));
			Fill.poly(e.x + trnsB.x, e.y + trnsB.y, 6, e.fout() * 6, e.rotation);
		}), b.x, b.y, b.rot());
		const target = Units.closestTarget(b.getTeam(), b.x,b.y,720)
		if(target != null && b.time() > 30) {
			b.velocity().setAngle(Mathf.slerpDelta(b.velocity().angle(), b.angleTo(target), 0.225));
		}
	},
	draw(b){},
	init(b){
		if(b == null)return;
		Sounds.laser.at(b, Mathf.random(0.9, 1.1));
		
		Effects.effect(this.shootEffect, b.x, b.y, b.rot());
		Effects.effect(this.smokeEffect, b.x, b.y, b.rot());
	}
});
sepEnergyCloud.splashDamage = 25;
sepEnergyCloud.damage = 175;
sepEnergyCloud.splashDamageRadius = 40;
sepEnergyCloud.speed = 7;
sepEnergyCloud.lifetime = 210;
sepEnergyCloud.collidesTiles = true;
sepEnergyCloud.pierce = true;

sepEnergyCloud.hitEffect = newEffect(40,e => {
	Draw.color(effectColor);
	const f = new Floatc2({get(x, y){
		Fill.poly(e.x + x, e.y + y, 6, 4 * e.fout());
	}})
	Angles.randLenVectors(e.id, 1, 60 * e.fin(), 0, 360,f);
});
sepEnergyCloud.shootEffect = newEffect(25,e => {
	Draw.color(effectColor, effectColor2, e.fin() * 0.5);
	Drawf.tri(e.x, e.y, 3 * e.fout(), 40 * e.fout(), e.rotation + 90);
    Drawf.tri(e.x, e.y, 3 * e.fout(), 40 * e.fout(), e.rotation + 270);
});
sepEnergyCloud.smokeEffect = newEffect(25,e => {
	Draw.color(effectColor, effectColor2,e.fin() * 0.5);
    const d = new Floatc2({get(x,y){
		Fill.circle(e.x + x, e.y + y, e.fout() * 3);
	}}) 
	Angles.randLenVectors(e.id, 3, 40 * e.fin(), e.rotation, 55, d);
});


const separaterWeapon = extend(Weapon, {});
separaterWeapon.reload = 240;
separaterWeapon.bullet = sepEnergyCloud;
separaterWeapon.recoil = 5;
separaterWeapon.length = 0;
separaterWeapon.width = 26;
separaterWeapon.shots = 3;
separaterWeapon.shotDelay = 25;
separaterWeapon.spacing = 0;
separaterWeapon.velocityRnd = 0;
separaterWeapon.shootSound = Sounds.none;
separaterWeapon.inaccuracy = 0;
separaterWeapon.ejectEffect = Fx.none;
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
const totalReload = 60;
const duration = 270;
const shieldBrokenReload = 120;
const weaponYnd = -40;
const weaponSize = 47;
const shieldTotalHP = 900;
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
const separater = extendContent(UnitType, "jqr", {});

separater.create(prov(() => new JavaAdapter(HoverUnit, {
	shieldReload: 0,
	shieldHP: shieldTotalHP,
	shield: null,
	getPowerCellRegion(){
		return Core.atlas.find("[#adff2f]核威慑-jqr-cell");
	},
	draw(){
		this.super$draw();
	},
	update(){
		this.super$update();
		
		const x = this.x; const y = this.y; const rotation = this.rotation; const type = this.type; 
		
		//shield:
		
		if(this.shield == null){
			this.shieldReload += 1;
		}
 
		if(this.shieldReload >= shieldBrokenReload){
			this.shieldReload = 0;
			this.shield = Bullet.create(sepShield, this, this.getTeam(), x, y, rotation);
			this.shieldHP = shieldTotalHP;
		}
		
		if(this.shieldHP >= 0 && this.shieldHP <= shieldTotalHP){
			this.shieldHP += 5;
		}
		
		if(this.shield != null && this.shieldHP >= 0){
			Vars.bulletGroup.intersect(x - shieldRange, y - shieldRange, shieldRange * 2, shieldRange * 2, cons(trait =>{
				if(trait.canBeAbsorbed() && trait.getTeam() != this.getTeam() && Intersector.isInsideHexagon(trait.getX(), trait.getY(), shieldRange, x, y) ){
					this.shieldHP -= trait.getShieldDamage();
					trait.absorb();
					Effects.effect(newEffect(20, e => {
						Draw.color(effectColor);
						Lines.stroke(e.fslope() * 2.5);
						Lines.poly(e.x, e.y, 6, 4 * e.fout() + 16);
						const d = new Floatc2({get(x, y){
							Lines.poly(e.x + x, e.y + y, 6, 4 * e.fout() + 4);
						}});
						Angles.randLenVectors(e.id, 2, 32 * e.fin(), 0, 360,d);
					}), trait);
				}
			}));
		} 
		
		if(this.shieldHP <= 0){
			this.shield = null;
		}
		
		if(this.shield != null && this.shieldHP >= 0){
			this.shield.set(x, y);
			this.shield.time(0);
		}
		
	},
	init(type, team){
		this.super$init(type, team);
		this.shield = Bullet.create(sepShield, this, this.getTeam(), this.x, this.y, 0);
	},
	damage(amount){
		if(!Vars.net.client()){
			this.super$damage(this.calculateDamage(amount * 0.3));
		}
		this.hitTime = this.hitDuration;
    },
})))
