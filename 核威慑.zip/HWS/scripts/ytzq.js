const ytdg = extendContent(LiquidExtendingBridge, "ytdg4", {
	update(tile){
		const entity = tile.ent();
		this.super$update(tile);
		const other = Vars.world.tile(entity.link);
		if(other != null && this.linkValid(tile, other)){
			
			
			if(other.entity != null && this.linkValid(tile, other)){
				other.entity.drop = 1;
				
				if(Vars.world.tile(other.entity.link) == null){
					
					other.entity.rotation = Mathf.slerpDelta(other.entity.rotation, other.entity.angleTo(entity), 0.125 * other.entity.power.status);
					entity.rotation = Mathf.slerpDelta(entity.rotation, entity.angleTo(other), 0.125 * entity.power.status);
				}
			}
		}
		entity.drop = 0;
	},
    linkValid(tile, other, checkDouble){
		if(other == null || tile == null || other == tile) return false;
		if(Math.pow(other.x - tile.x, 2) + Math.pow(other.y - tile.y, 2) > Math.pow(this.range + 0.5, 2)) return false;
		return other.block() == this && (!checkDouble || other.ent().link != tile.pos());
	},
	drawPlace(x, y, rotation, valid){
		link = this.findLink(x, y);
		if (link != null) {
			const sin = Mathf.absin(Time.time(), 6, 1);
			Tmp.v1.set(x * Vars.tilesize + this.offset(), y * Vars.tilesize + this.offset()).sub(link.drawx(), link.drawy()).limit((this.size / 2 + 1) * Vars.tilesize + sin + 0.5);
			const x2 = x * Vars.tilesize - Tmp.v1.x;
			const y2 = y * Vars.tilesize - Tmp.v1.y;
            const x1 = link.drawx() + Tmp.v1.x;
			const y1 = link.drawy() + Tmp.v1.y;
			const segs = Math.floor(link.dst(x * Vars.tilesize, y * Vars.tilesize) / Vars.tilesize);
			
			Lines.stroke(4, Pal.gray);
			Lines.dashLine(x1, y1, x2, y2, segs);
			Lines.stroke(2, Pal.placing);
			Lines.dashLine(x1, y1, x2, y2, segs);
			Drawf.circles(link.drawx(), link.drawy(), (this.size / 3 + 1) * Vars.tilesize + sin - 2, Pal.accent);
			Drawf.arrow(link.drawx(), link.drawy(),x * Vars.tilesize + this.offset(), y * Vars.tilesize + this.offset(), 2 * Vars.tilesize + sin, 4 + sin, Pal.accent);
			Draw.reset();
		}
		Drawf.dashCircle(x * Vars.tilesize, y * Vars.tilesize, (this.range + 1) * Vars.tilesize, Pal.accent);
    },
	drawConfigure(tile) {
		const entity = tile.ent();
        
		const sin = Mathf.absin(Time.time(), 6, 1);

		Draw.color(Pal.accent);
		Lines.stroke(1);
		Drawf.circles(tile.drawx(), tile.drawy(), (tile.block().size / 2 + 1) * Vars.tilesize + sin - 2, Pal.accent);
		const other = Vars.world.tile(entity.link);
		if(other != null){
			Drawf.circles(other.drawx(), other.drawy(), (tile.block().size / 3 + 1) * Vars.tilesize + sin - 2, Pal.place);
			Drawf.arrow(tile.drawx(), tile.drawy(), other.drawx(), other.drawy(), this.size * Vars.tilesize + sin, 4 + sin, Pal.accent);
		}
		Drawf.dashCircle(tile.drawx(), tile.drawy(), this.range * Vars.tilesize, Pal.accent);
	},
	drawLayer2(tile){
		const entity = tile.ent();
		if(entity.power.status < 0.5)return;
		const other = Vars.world.tile(entity.link);
		if(!this.linkValid(tile, other)) return;
		if(other != null){
			if(Angles.angleDist(other.entity.rotation, entity.rotation - 180) > 3)return;
			if(Vars.world.tile(other.entity.link) != null)return;
		}
		const opacity = Core.settings.getInt("bridgeopacity") / 100.0;
		
		if(Mathf.zero(opacity)) return;
		if(other == null && !this.linkValid(tile, other)){
			if(other.entity == null && !this.linkValid(tile, other)){
				if(Vars.world.tile(other.entity.link) != null){
					return;
				}
			}
		}
		var uptime = Vars.state.isEditor() ? 1.0 : entity.uptime;
		const dx = other.worldx() - tile.worldx();
		const dy = other.worldy() - tile.worldy();
		
		var ex = dx * uptime;
		var ey = dy * uptime;
		
		Draw.color(Color.white, Color.black, Mathf.absin(Time.time(), 6.0, 0.07));
		Draw.alpha(Math.max(entity.uptime, 0.25) * opacity);
		
		const angle = entity.rotation;
		
		Draw.rect(Core.atlas.find(this.name + "-end"), tile.worldx(), tile.worldy(), entity.rotation + 90);
		Draw.rect(Core.atlas.find(this.name + "-end"), tile.worldx() + ex, tile.worldy() + ey, entity.rotation - 90);
		
		Lines.stroke(Vars.tilesize);
		Lines.line(Core.atlas.find(this.name + "-bridge"),
		tile.worldx(),tile.worldy(),
		tile.worldx() + ex,tile.worldy() + ey,
		CapStyle.none, -Vars.tilesize / 2.0);
		
		const arrows = Math.floor(Math.sqrt(Math.pow(other.x - tile.x, 2) + Math.pow(other.y - tile.y, 2)) * Vars.tilesize / 6) - 1;
		
		for(var a = 0; a != arrows; ++a) {
			const ox = dx / arrows * 2 / 3;
			const oy = dy / arrows * 2 / 3;
			
			Draw.alpha(Mathf.absin(a / arrows - entity.time / 100.0, 0.1, 1) * uptime * opacity);
			Draw.rect(Core.atlas.find(this.name + "-arrow"),
			tile.worldx() + ox + (dx - ox) * a / arrows * uptime,
			tile.worldy() + oy + (dy - oy) * a / arrows * uptime, entity.rotation);
		}
		Draw.reset();
	},
	drawLayer(tile){
		const entity = tile.ent();
		Draw.rect(Core.atlas.find(this.name), tile.drawx(), tile.drawy(), entity.rotation - 90);
	},
	draw(tile){
		Draw.rect(Core.atlas.find(this.name + "-base"), tile.worldx(), tile.worldy(), 0);
	},
	canDumpLiquid(tile, to, liquid){
		const entity = tile.ent();
		if(entity.drop > 0)return true;
	},
	acceptItem(item, tile, source){
		return false;
	},
	acceptLiquid(tile, source, liquid, amount){
		if(tile.getTeam() != source.getTeam() || !this.hasLiquids) return false;
		
		const entity = tile.ent();
		if(entity.drop > 0)return false;
		
		const other = Vars.world.tile(entity.link);
		if(this.linkValid(tile, other)) return tile.entity.liquids.get(liquid) + amount < this.liquidCapacity && (tile.entity.liquids.current() == liquid || tile.entity.liquids.get(tile.entity.liquids.current()) < 0.2);
		return source.block() instanceof ItemBridge && source.ent().link == tile.pos();
	},
    generateIcons(){
		return [
			Core.atlas.find(this.name + "-base"),
			Core.atlas.find(this.name),
		];
	}
});
ytdg.layer = Layer.turret;
ytdg.hasPower = true;
ytdg.layer2 = Layer.power;
ytdg.entityType=prov(()=>extend(ItemBridge.ItemBridgeEntity,{
    getrotation(){return this._rotation},
    setrotation(value){this._rotation = value},
    _rotation:90,
    getdrop(){return this._drop},
    setdrop(value){this._drop = value},
    _drop:0,
    write(stream){
		this.super$write(stream);
		stream.writeFloat(this._rotation);
		stream.writeFloat(this._drop);
	},
	read(stream,revision){
		this.super$read(stream,revision);
		this._rotation = stream.readFloat();
		this._drop = stream.readFloat();
	}
}));
ytdg.localizedName = Core.bundle.get("Block."+ "liquid-driver"+".name");
ytdg.description = Core.bundle.get("Block."+ "liquid-driver"+".description");
