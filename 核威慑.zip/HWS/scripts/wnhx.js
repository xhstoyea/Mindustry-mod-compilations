Vars.content.getByName(ContentType.item,"blast-compound").type=ItemType.material
Vars.content.getByName(ContentType.item,"coal").type=ItemType.material
Vars.content.getByName(ContentType.item,"pyratite").type=ItemType.material
Vars.content.getByName(ContentType.item,"sand").type=ItemType.material
Vars.content.getByName(ContentType.item,"scrap").type=ItemType.material
Vars.content.getByName(ContentType.item,"spore-pod").type=ItemType.material