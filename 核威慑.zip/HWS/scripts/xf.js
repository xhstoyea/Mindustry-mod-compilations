
const Xcs = extendContent(Block,"x-cs",{
	update(tile){
		const entity = tile.ent();
		//entity.heat = Mathf.lerpDelta(entity.heat, entity.power.status > 0.5 || tile.isEnemyCheat() ? entity.power.status : 0, 0.08);
		entity.chargeProgress += entity.power.status * entity.delta();
		
		if(entity.chargeProgress >= this.reload){
			entity.chargeProgress = 0;
			
			Units.nearby(tile.getTeam(), tile.drawx(), tile.drawy(), this.range, cons(unit =>{
				if(unit.health < unit.maxHealth()){
					Effects.effect(newEffect(45,e => {
						Draw.color(this.baseColor);
						const si = 20 * e.fout() * e.fout();
						Draw.rect(Core.atlas.find("[#adff2f]核威慑-upgrade"), e.x, e.y, si, si, si, si, 0);
					}), unit);
					Effects.effect(newEffect(45,e => {
						Draw.color(this.baseColor);
						Lines.stroke(e.fout() * 3);
						Lines.circle(e.x, e.y, e.fin() * 220);
					}), tile);
					unit.healBy(unit.maxHealth() / 40);
				}
			}));
			
		}
	},
	draw(tile){
		const entity = tile.ent();
		Draw.rect(Core.atlas.find(this.name), tile.drawx(), tile.drawy());
		const f = 1 - (Time.time() / 100) % 1;
		Draw.color(this.baseColor);	
		Draw.alpha(entity.power.status * Mathf.absin(Time.time(), 10, 1) * 0.5);
		Draw.rect(Core.atlas.find(this.name + "-top"), tile.drawx(), tile.drawy());
		Draw.alpha(1);
		Lines.stroke((2 * f + 0.2) * entity.power.status);
		Lines.square(tile.drawx(), tile.drawy(), ((1 - f) * 8) * this.size / 2);
		Draw.reset();
	},
	drawPlace(x, y, rotation, valid){
		Drawf.dashCircle(x * Vars.tilesize + this.offset(), y * Vars.tilesize + this.offset(), this.range, this.baseColor);
	},
	drawSelect(tile){
		Drawf.dashCircle(tile.drawx(), tile.drawy(), this.range, this.baseColor);
	}
});
Xcs.range = 200;
Xcs.consumes.power(30);
Xcs.reload = 150;
Xcs.solid = true;
Xcs.update = true;
Xcs.size = 3;
Xcs.baseColor = Color.valueOf("#40FF40");
Xcs.hasPower = true;
Xcs.entityType=prov(()=>extend(TileEntity,{
    getchargeProgress(){return this._chargeProgress},
    setchargeProgress(value){this._chargeProgress = value},
    _chargeProgress:0
}));
