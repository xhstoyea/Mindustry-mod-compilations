

const DX = extendContent(Block, "dx", {
	draw(tile){
		const entity = tile.ent();
		Draw.rect(Core.atlas.find(this.name), tile.drawx(), tile.drawy(), 0);
		Draw.rect(Core.atlas.find(this.name + "-center"), tile.drawx(), tile.drawy(), tile.rotation() * 90);
	},
	
	findAng(tile,angle){
		const findAng = tile.rotation() + angle == 4 ? 0 : tile.rotation() + angle == -1 ? 3 : tile.rotation() + angle;
		return findAng;
	},
	
	handleItem(item, tile, source){
		const entity = tile.ent();
		entity.items.add(item, 1);
		entity.sortItem = item;
    },
    
	acceptItem(item, tile, source){
		const entity = tile.ent();
		if(source.block() == tile.block())return false;
		if(tile.back() == source && tile.getTeam() == source.getTeam() && entity.items.total() == 0 )return true;
		return false;
	},
	
	canDump(tile, to, item){
		return true;
	},
	
	update(tile){
		const entity = tile.ent();
		if(entity.sortItem != null){
			
			const toF = tile.front();
			const toL = tile.left();
			const toR = tile.right();
			
			if(toR != null){
				if(tile.entity.items.get(entity.sortItem) > 0 && toR.block().acceptItem(entity.sortItem,toR,Edges.getFacingEdge(tile,toR))){
					tile.entity.items.remove(entity.sortItem,1);
					toR.block().handleItem(entity.sortItem,toR,tile);
				}
			}
			if(toL != null){
				if(tile.entity.items.get(entity.sortItem) > 0 && toL.block().acceptItem(entity.sortItem,toL,Edges.getFacingEdge(tile,toL))){
					tile.entity.items.remove(entity.sortItem,1);
					toL.block().handleItem(entity.sortItem,toL,tile);
				}
			}
			if(toF != null){
				if(tile.entity.items.get(entity.sortItem) > 0 && toF.block().acceptItem(entity.sortItem,toF,Edges.getFacingEdge(tile,toF))){
					tile.entity.items.remove(entity.sortItem,1);
					toF.block().handleItem(entity.sortItem,toF,tile);
				}
			}
		}
		
	},
	drawConfigure(tile){
		const entity = tile.ent();
		Draw.color(Pal.accent);
		Draw.rect("bridge-arrow", tile.drawx() + Angles.trnsx(this.findAng(tile, -1) * 90, Vars.tilesize), tile.drawy() + Angles.trnsy(this.findAng(tile, -1) * 90, Vars.tilesize), this.findAng(tile, -1) * 90);
		Draw.rect("bridge-arrow", tile.drawx() + Angles.trnsx(this.findAng(tile,  1) * 90, Vars.tilesize), tile.drawy() + Angles.trnsy(this.findAng(tile,  1) * 90, Vars.tilesize), this.findAng(tile,  1) * 90);
		Draw.rect("bridge-arrow", tile.drawx() + Angles.trnsx(this.findAng(tile,  0) * 90, Vars.tilesize), tile.drawy() + Angles.trnsy(this.findAng(tile,  0) * 90, Vars.tilesize), this.findAng(tile,  0) * 90);
		Lines.square(tile.drawx(), tile.drawy(),this.size * Vars.tilesize / 2.0 );
		
		Draw.reset();
	},
	generateIcons(){
		return [Core.atlas.find(this.name),Core.atlas.find(this.name + "-center")];
	}
});
DX.size = 3;
DX.update = true;
DX.configurable = true;
DX.rotate = true;
DX.entityType=prov(()=>extend(Unloader.UnloaderEntity,{}));