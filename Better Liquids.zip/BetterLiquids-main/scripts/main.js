// init settings
require("settings");