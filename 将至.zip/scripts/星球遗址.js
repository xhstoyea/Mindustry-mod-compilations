const lib = require("将至lib");

const 星球遗址 = new Planet("星球遗址", Planets.sun, 1, 3.3);
星球遗址.meshLoader = prov(() => new MultiMesh(
	new HexMesh(星球遗址, 8)
));
星球遗址.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(星球遗址, 2, 0.15, 0.14, 5, Color.valueOf("f1dd418e"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(星球遗址, 3, 0.6, 0.15, 5, Color.valueOf("ffee80aa"), 2, 0.42, 1.2, 0.45)
));
星球遗址.generator = new SerpuloPlanetGenerator();
星球遗址.visible = true
/*const sS = require("sectorSize");
sS.planetGrid(星球遗址, 3.3);
*/
星球遗址.accessible = 星球遗址.alwaysUnlocked = 星球遗址.clearSectorOnLose = true;
星球遗址.tidalLock = false
星球遗址.localizedName = "星球遗址";
星球遗址.bloom = false
星球遗址.startSector = 1//星球的起始地图
星球遗址.orbitRadius = 85;
星球遗址.orbitTime = 1200
星球遗址.rotateTime = 180
星球遗址.atmosphereRadIn = 0.02;
星球遗址.atmosphereRadOut = 0.3;
星球遗址.atmosphereColor = 星球遗址.lightColor = Color.valueOf("eb8585b9");

const dt1 = new SectorPreset("战争遗迹", 星球遗址, 99);
dt1.description = "距离那次战争已经过去200世纪了，那些胜利者肮脏的机器人现在仍然占领着这个地方……"
dt1.alwaysUnlocked = true
dt1.difficulty = 1
dt1.captureWave = 35
dt1.localizedName = "战争遗迹"
