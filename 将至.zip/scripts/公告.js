
Events.on(EventType.ClientLoadEvent, cons(e => {

    var dialog = new JavaAdapter(BaseDialog, {}, "v7将至工业     当前版本号:v2.0-----2023 1.26 11时50分");
    var icon =new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find("将至-提示", Core.atlas.find("clear")));
    dialog.shown(run(() => {
        dialog.cont.table(Tex.button, cons(t => {
            t.defaults().size(350, 450).left();
            t.button("Welcome !", icon, Styles.cleart, run(() => {
                dialog.hide();
            }));
        t.add("欢迎使用将至工业模组\n[red]鸣谢:制图师（贴图制作）\n[white]上次更新:\n上次更新:\n对部分物品进行修改，bug修改，星球修改\n本次更新:\n对部分物品修改，添加矩阵")
        }));
    }));
    dialog.show();
}));