//by 晓伟
module.exports={
    BaseBlock:function (name,con) {
        const baseB = extend(Block,name,con);
        baseB.solid = true;
        baseB.destructible = true;
        baseB.group = BlockGroup.none;
        baseB.drawDisabled = true;
        baseB.priority = TargetPriority.base;
        baseB.envEnabled = Env.any;
        return baseB
    },
    hasItemsBlock:function (name,con) {
        const hib = this.BaseBlock(name,con);
        hib.hasItems = true;
        hib.separateItemCapacity = true;
        hib.itemCapacity = 10;
        return hib
    },
    newBuilding:function(building,vars,con){
        return () => extend(building,con(vars))
    },
    AngleTrns:function(ang,rad){
        return {x:Angles.trnsx(ang,rad),y:Angles.trnsy(ang,rad)}
    }
};