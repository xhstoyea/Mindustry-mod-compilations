public class BuilderAI_PRO extends UnitAIController {
    @Override
    public void update(Unit unit) {
        if (unit.type == UnitTypes.gammama) {
            // 检查单位是否空闲，即没有执行任何命令
            if (unit.isIdle()) {
                // 设置目标位置为地图原点 (0,0)
                Vec2 targetPosition = new Vec2(0f, 0f);
                // 使用游戏提供的路径寻找功能来移动单位到目标位置
                // 'true' 表示单位到达目标后应停止
                unit.command().move(targetPosition, true);
            }
        }
    }
}
