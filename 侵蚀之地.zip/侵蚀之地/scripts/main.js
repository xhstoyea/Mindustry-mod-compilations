require('缩放强化');
require('替换背景');
require('library');
require('熔炼炉');
require('items')