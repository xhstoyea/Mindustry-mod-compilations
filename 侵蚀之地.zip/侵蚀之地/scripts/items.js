function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("铜矿石")
newItem("铅矿石")
newItem("钛矿石")
newItem("硅芯片")
newItem("T1单位快速升级装置")
newItem("T1压缩单位")
newItem("冰晶")
newItem("建筑废料")
newItem("铜铅合金")
newItem("异变孢子")
newItem("污染芯片")
newItem("杂质")