const library = require("library");
const myitems = require("items");
const 熔炼炉 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "熔炼炉", [
  {
    input: {
      items: ["侵蚀之地-铜矿石/4","coal/2"],     
     power: 1,
    },
    output: {
      items: ["copper/7"],
    },
    craftTime: 15,
  }, 
  {
    input: {
      items: ["侵蚀之地-铅矿石/4","coal/2"],     
     power: 1.5,
    },
    output: {
      items: ["lead/6"],
    },
    craftTime: 30,
  }, 
  {
    input: {
      items: ["侵蚀之地-钛矿石/4","coal/2"],     
      power: 2,
    },
    output: {
      items: ["titanium/5"],
    },
    craftTime: 60,
  },  
])