	require("blocks/effect/量子传输器");
	require("blocks/大型相织布编织厂");
	require("blocks/巨型石墨压缩厂");
	require("blocks/大型塑钢压缩机");