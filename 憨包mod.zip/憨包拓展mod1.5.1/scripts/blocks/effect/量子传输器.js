const 量子传输器 = extendContent(Unloader,"量子传输器",{
    acceptItem(item,tile,source){
        const entity = tile.ent();
        return entity.linkedCore != null ? entity.linkedCore.block().acceptItem(item, entity.linkedCore, source) : tile.entity.items.get(item) < this.getMaximumAccepted(tile, item);
    },
    drawPlace(x, y, rotation, valid){
        Drawf.dashCircle(x * Vars.tilesize, y * Vars.tilesize,this.range, Pal.placing);
    },
    update(tile){
		const entity = tile.ent();
		const core = Vars.state.teams.closestCore(tile.drawx(),tile.drawy(),tile.getTeam());
		if(core != null && Mathf.dst(tile.drawx(),tile.drawy(),core.x,core.y) < this.range && entity.power.status > 0.25){
			entity.rotation = Mathf.slerpDelta(entity.rotation, entity.angleTo(core), 0.0125 * entity.power.status);
			//entity.progress += 1 * entity.timeScale * entity.power.status;
			if (tile.entity.timer.get(this.timerUnload,this.speed / entity.timeScale / 2)){
				if(Angles.angleDist(entity.angleTo(core), entity.rotation) < 30 && entity.power.status > 0.125 && entity.sortItem !== null && tile.entity.items.get(entity.sortItem) > 4 &&
				core.tile.block().acceptItem(entity.sortItem,core.tile,Edges.getFacingEdge(tile,core.tile))){
					Calls.transferItemTo(entity.sortItem,5,tile.drawx(),tile.drawy(),core.tile)
					entity.items.remove(entity.sortItem,5);
					
				}
			}
			if(entity.sortItem !== null){
				if(Angles.angleDist(entity.angleTo(core), entity.rotation) < 15 && tile.entity.items.get(entity.sortItem) > 0){
					entity.progress = Mathf.lerpDelta(entity.progress, 0.65, 0.08 * Time.delta() * entity.power.status);
				}else{
					entity.progress = Mathf.lerpDelta(entity.progress, 0, 0.09 * Time.delta());
				}
			}else{
				entity.progress = Mathf.lerpDelta(entity.progress, 0, 0.09 * Time.delta());
			}
		}else{
			entity.progress = Mathf.lerpDelta(entity.progress, 0, 0.09 * Time.delta());
		}
	},
	draw(tile){
		Draw.rect(Core.atlas.find(this.name + "-base"),tile.drawx(),tile.drawy());
	},
	drawLayer(tile){
		const entity = tile.ent();
		Draw.rect(this.region,tile.drawx(),tile.drawy(), entity.rotation - 90);
		if(entity.sortItem != null){
			Draw.color(entity.sortItem.color);
		}else{
			Draw.color();
		}
		Draw.rect(Core.atlas.find(this.name + "-center"),tile.drawx(),tile.drawy(), entity.rotation - 90);
		Draw.color();
	},
	drawLayer2(tile){
		const entity = tile.ent();
		const core = Vars.state.teams.closestCore(tile.drawx(),tile.drawy(),tile.getTeam());
		if(core != null){
			const ang = entity.angleTo(core);
			const len = 6;
			Drawf.laser(Core.atlas.find("minelaser"), Core.atlas.find("minelaser-end"),tile.drawx() + Angles.trnsx(ang, len), tile.drawy() + Angles.trnsy(ang, len),core.x, core.y, entity.progress);
			Draw.color();
		}
	},
	generateIcons(){
		return [
			Core.atlas.find(this.name + "-base"),
			Core.atlas.find(this.name),
		];
	}
})
// 量子传输器.hasItem = true
量子传输器.itemCapacity = 6;
量子传输器.range = 2400;
量子传输器.solid = true;
量子传输器.expanded = true;
量子传输器.layer = Layer.turret;
量子传输器.layer2 = Layer.power;
量子传输器.update = false;
量子传输器.destructible = true;
量子传输器.consumes.power(4);
量子传输器.entityType = prov(() => extend(Unloader.UnloaderEntity,{
	getrotation(){return this._rotation},
	setrotation(value){this._rotation = value},
	_rotation:90,
	getprogress(){return this._progress},
	setprogress(value){this._progress = value},
	_progress:0,
	write(stream){
		this.super$write(stream);
		stream.writeFloat(this._rotation);
	},
	read(stream,revision){
		this.super$read(stream,revision);
		this._rotation = stream.readFloat();
	}
}));