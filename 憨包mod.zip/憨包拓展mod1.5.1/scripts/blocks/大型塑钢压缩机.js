const 大型塑钢压缩机 = extendContent(GenericSmelter,"大型塑钢压缩机",{         
    draw(tile){ 
        var frameRegions = new Array();
        for(var i = 0; i < 5; i++){
            frameRegions[i] = "[gold]憨包mod-大型塑钢压缩机-"+i;
        }
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color(Color.valueOf("CCFFCC16"));
        Draw.alpha(tile.entity.liquids.total() / this.liquidCapacity);
        Draw.rect(Core.atlas.find(this.name + "-top"), tile.drawx(), tile.drawy());
        Draw.color()
        Draw.rect(Core.atlas.find(frameRegions[Math.floor(Mathf.absin(tile.ent().totalProgress, 5.2, 4.999))]), tile.drawx(), tile.drawy());
    },
    generateIcons(){
        return [
            Core.atlas.find(this.name),
        ];
    }
});
