const 焚烧 = extend(StatusEffect,"焚烧",{
    init(){
        this.affinity(霜冻, (unit, result, time) => {
            unit.damagePierce(100);
            unit.unapply(焚烧);
        });
    }
});

const 霜冻 = extend(StatusEffect,"霜冻",{
    init(){
        this.affinity(焚烧, (unit, result, time) => {
            unit.damagePierce(70);
            unit.unapply(霜冻);
        });
    }
});