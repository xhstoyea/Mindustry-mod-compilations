const item = require("items");

let 天罚落地 = extend(ArtilleryBulletType,{
  lifetime : 40,
  speed : 30,

  damage : 172,
  splashDamage : 86,
  splashDamageRadius : 128,
  buildingDamageMultiplier: 0.01,

  pierceArmor : true,

  hitShake : 14,

  fragBullets : 1,
  fragBullet : Object.assign(new FlakBulletType(),{
    instantDisappear : true,
    lightning : 6,
    lightningLength : 16,
    pierceArmor : true,
    absorbable: false
  }),

  trailColor : Pal.bulletYellow,
  trailLength : 48,
  trailWidth : 2.4,
  trailRotation : true,
  trailChance : 1,
  trailEffect : new MultiEffect(
    Object.assign(new ParticleEffect(),{
      line : true,
      lifetime : 20,
      interp : Interp.pow5Out,

      particles : 5,
      cone : 15,
      strokeFrom : 1.2,
      strokeTo : 1,
      baseLength : 2,
      length : -48,
      lenFrom : 24,
      lenTo : 0
    })
  ),

  collidesAir : true,

  despawnEffect : new MultiEffect(
    Object.assign(new WaveEffect(),{
      lifetime : 22,
      interp : Interp.circleOut,
      
      sizeFrom : 4,
      sizeTo : 128,
    }),
    Object.assign(new ParticleEffect(),{
      lifetime : 50,
      interp : Interp.circleOut,

      colorFrom : Pal.bulletYellow,
      colorTo : Color.valueOf("fff8e800"),
      sizeFrom : 8,
      sizeTo : 3,
      baseLength : 0,
      length : -126,
      cone : 16,
      particles : 12
    })
  )
});
let 天罚升天 = extend(BasicBulletType,{
  lifetime : 120,
  speed : 1,
  drag : -0.064,

  trailColor : Pal.bulletYellow,
  trailLength : 24,
  trailWidth : 2.4,
  trailRotation : true,
  trailChance : 1,
  trailEffect : new MultiEffect(
    Object.assign(new ParticleEffect(),{
      line : true,
      lifetime : 20,
      interp : Interp.pow5Out,

      particles : 5,
      cone : 15,
      strokeFrom : 1.2,
      strokeTo : 1,
      baseLength : 2,
      length : -48,
      lenFrom : 24,
      lenTo : 0
    })
  ),
  shootEffect: new MultiEffect(
    Object.assign(new ParticleEffect(),{
      line : true,
      interp : Interp.circleOut,
      sizeInterp : Interp.pow10In,

      lifetime : 80,
      particles : 24,
      baseLength : 0,
      length : 256,
      cone : 12,
      colorFrom : Pal.bulletYellow,
      colorTo : Color.valueOf("fff8e800"),
      lenFrom : 12,
      lenTo : 8,
      strokeFrom : 1.2,
      strokeTo : 0.8,
    })
  ),
  chargeEffect: new MultiEffect(
    Object.assign(new ParticleEffect(),{
      interp : Interp.circleOut,

      lifetime : 40,
      particles : 1,
      baseLength : 0.1,
      length : 0,
      cone : 0,
      colorFrom : Pal.bulletYellow,
      colorTo : Pal.bulletYellow,
      sizeFrom : 0,
      sizeTo : 6
    })
  ),

  collides : false,
  absorbable : false,

  despawned(b){
    this.super$despawned(b);
    if(b.owner != null && b.owner instanceof Turret.TurretBuild){
      let realAimX = b.aimX < 0 ? b.x : b.aimX;
      let realAimY = b.aimY < 0 ? b.y : b.aimY;
      let target = Units.closestTarget(b.team, realAimX, realAimY, 640,
                        e => e != null && e.checkTarget(this.collidesAir, this.collidesGround) && !b.hasCollided(e.id),
                        t => t != null && this.collidesGround && !b.hasCollided(t.id));
      if(target != null)天罚落地.create(b,target.x,target.y + 1200,-90);
      else 天罚落地.create(b,b.owner.x,b.owner.y + 1200,-90);
    }
  }
});

const 天罚 = extend(ItemTurret,"天罚",{
  
});

天罚.ammo(
  Items.surgeAlloy,天罚升天
);