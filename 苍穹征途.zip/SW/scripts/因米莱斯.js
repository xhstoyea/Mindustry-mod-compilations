const lib = require("lib");
const myitems = require("items");
const 魔能之核 = require("魔能之核").魔能之核;

const 因米莱斯 = new Planet("因米莱斯", Planets.sun, 1.2,3);
Object.assign(因米莱斯, {
	generator: extend(SerpuloPlanetGenerator,  {
		getDefaultLoadout() {
			return Schematics.readBase64("bXNjaAF4nGNgZmBmZmDJS8xNZeB5uXbKi+a9T3Z2P1uwg4E7JbU4uSizoCQzP4+BgYEtJzEpNaeYgSk6lpFB8kV37/OVO5/ua3zZMEUXRRsDAyMIAQkAUBYjwQ==");
		},
		allowLanding(sector){return false},
getColor(position){
            let noise = Simplex.noise3d(this.seed, 8, 1, 1, position.x, position.y, position.z);
            if(noise > 0.5){
                return Color.valueOf("9E9E9EFF");
            }
            if(noise < 0.5){
                return Color.valueOf("DCBFFFFF");
            }
            /*let deep = Simplex.noise3d(this.seed, 5, 0.3, 1/3, position.x, position.y, position.z);
            return Tmp.c1.set(colorSrc).lerp(Color.black, deep);*/
        },
        generateSector(sector){
            this.super$generateSector(sector);
        },
    }),

	/*meshLoader: prov(() => new HexMesh(因米莱斯, 4)),
	cloudMeshLoader: () => new MultiMesh(
		new HexSkyMesh(因米莱斯, 2, 0.15, 0.14, 5, Color.valueOf("FFFFFFD2"), 2, 0.42, 1, 0.45)
	),*/

        meshLoader: prov(() => new HexMesh(因米莱斯, 5)),
        cloudMeshLoader : () => new MultiMesh(
            new HexSkyMesh(因米莱斯, 3, 0.15, 0.14, 5, Color.valueOf("DCBFFFC5"), 2, 0.42, 1, 0.45),
            new HexSkyMesh(因米莱斯, 1, 0.6, 0.16, 5, Color.valueOf("DCBFFFC5"), 2, 0.45, 1, 0.41)
        ),

	atmosphereColor: Color.valueOf("BF92F9FF"),
	atmosphereRadIn: 0.01,
	atmosphereRadOut: 0.4,
	visible: true,
	bloom: true,
	accessible: true,
	alwaysUnlocked: true,
	startSector: 2,
	updateLighting: false,
	lightSrcTo: 0,
	lightDstFrom: 0,
	camRadius: 0.5,
	orbitRadius: 75,
	orbitSpacing: 2,
	orbitTime: 1 * 1,
	rotateTime: 1.1 * 1.2,
	defaultCore: 魔能之核,
	iconColor: Color.valueOf("FFD7F9FF"),
    clearSectorOnLose: true, 
})

因米莱斯.ruleSetter = r => {
	r.attributes.set(Attribute.heat, 0);
	r.attributes.set(Attribute.light, -0.5);
	            r.waveTeam = Team.blue,
                r.placeRangeCheck = false,
                r.showSpawns = true,
                r.fog = false,
                r.staticFog = false,
                r.lighting = false,
                r.coreDestroyClear = true,
                r.onlyDepositCore = true
	            r.defaultTeam = Team.malis;
}
因米莱斯.totalRadius += 2.6;
因米莱斯.hiddenItems.addAll(
	Items.scrap,
	Items.copper,
	Items.lead,
	Items.titanium,
	Items.thorium,
	Items.plastanium,
	Items.sporePod,
	Items.blastCompound,
	Items.pyratite,
	Items.metaglass,
	Items.beryllium,
	Items.carbide,
	myitems.碲,
myitems.锂,
myitems.钚,
myitems.钠,
myitems.铋,
myitems.铟,
myitems.莱特合金,
myitems.铀,
myitems.伊泰普合金,
myitems.朱砂,
);
Planets.serpulo.hiddenItems.addAll(
	myitems.碲,
myitems.锂,
myitems.钚,
myitems.钠,
myitems.铋,
myitems.铟,
myitems.莱特合金,
myitems.铀,
myitems.伊泰普合金,
myitems.朱砂,
)
Planets.erekir.hiddenItems.addAll(
	myitems.碲,
myitems.锂,
myitems.钚,
myitems.钠,
myitems.铋,
myitems.铟,
myitems.莱特合金,
myitems.铀,
myitems.伊泰普合金,
myitems.朱砂,
)

exports.因米莱斯 = 因米莱斯;

const 始源之地 = new SectorPreset("始源之地", 因米莱斯, 2);
 始源之地.planet = 因米莱斯;
 始源之地.difficulty = 1;
 始源之地.alwaysUnlocked = true;
 始源之地.addStartingItems = false;
 始源之地.captureWave = 10;
 始源之地.localizedName = "始源之地";
 始源之地.description = "我们降落在一颗紫色的星球上，它看上去充满了某种能量...";
 exports.始源之地 = 始源之地;
 lib.addToResearch(始源之地, {
 parent: "groundZero",
 objectives: Seq.with(
 new Objectives.SectorComplete(SectorPresets.groundZero))
 });
 