const AI = require("拓展AI");

const 落雨 = new UnitType("落雨");
落雨.constructor = prov(() => extend(UnitTypes.flare.constructor.get().class, {}));

落雨.aiController = () => AI.灭火AI(80);
落雨.controller = () => AI.灭火AI(80);

exports.落雨 = 落雨;