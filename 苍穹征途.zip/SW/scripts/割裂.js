const myitems = require("items");
const killAdd = 30; //击杀充能
const killTime = 360; // 杀戮光环持续时间
const damageMultiplier = 0.85;//杀戮光环提供的伤害加成
const speedUp = 1.7; //杀戮光环提供的攻速加成

let 割裂子弹 = extend(BasicBulletType,{
  lifetime : 40,
  speed : 5,

  damage : 120,

  sprite : "circle",
  frontColor : Color.valueOf("C496FF"),
  trailColor : Color.valueOf("C496FF"),
  trailLength : 6,
  trailWidth : 2,

  hitEntity(b,entity,health){
    this.super$hitEntity(b,entity,health);
    if(entity instanceof Healthc && entity.dead){
      b.owner.addKills();
    }
  }
})
const 割裂 = extend(ItemTurret,"割裂",{
  setBars(){
    this.super$setBars();
    this.addBar("kills",func(e => new Bar(
      () => Core.bundle.get("bar.kills"),
      () => e.getColor(),
      () => e.getKills()
    )))
  }
})

割裂.ammoTypes.put(myitems.魔晶,割裂子弹);

割裂.buildType = () => {
  let kills = 0;
  let killing = false;
  return extend(ItemTurret.ItemTurretBuild,割裂,{
    getKills(){
      return kills / killTime;
    },
    getColor(){
      return killing ? Color.valueOf("E05438") : Color.valueOf("C496FF");
    },
    addKills(){
      if(!killing) kills += killAdd;

      if(kills >= killTime){
        killing = true;
        kills = killTime;
      }
    },
    updateTile(){
      this.super$updateTile();

      if(killing){
        this.reloadCounter += Time.delta * speedUp;
        kills -= Time.delta;
        if(kills <= 0) killing = false;
      }
    },
    handleBullet(b,x,y,a){
      if(killing) b.damage *= damageMultiplier;
    },
    write(w){
      this.super$write(w);
      w.f(kills);
      w.bool(killing);
    },
   read(r,rv){
     this.super$read(r,rv);
     kills = r.f();
     killing = r.bool();
   }
  })
}