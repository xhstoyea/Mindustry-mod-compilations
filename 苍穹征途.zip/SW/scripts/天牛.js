const 枪羽 = new UnitType("枪羽");

枪羽.constructor = prov(() => extend(UnitTypes.flare.constructor.get().class, {}));


const points = 20;//节点数目，越多越平滑，最佳数目应视特效大小而定

let 枪羽消失 = new Effect(30,e => {
  Draw.color(Color.white);//颜色
  Lines.stroke(2 * e.fout());//线条粗细
  Lines.beginLine();

  for(let i = 0;i <= points;i++){
    let px = 8 * e.fin() * Math.cos(2 * Math.PI * i / points);
    let py = 40 * e.fin() * Math.sin(2 * Math.PI * i / points);
    let vec = new Vec2(px,py).rotate(e.rotation).add(e.x,e.y);
    Lines.linePoint(vec.x,vec.y);
  }

  Lines.endLine();
})
let 枪羽主弹frag = extend(LaserBulletType,{
  lifetime : 20,
  length : 560,
  shake : 10,

  damage : 24000,
  pierceArmor : true
})
let 枪羽主弹 = extend(ContinuousLaserBulletType,{
  lifetime : 80,

  length : 440,
  shake : 4,

  damage : 85,
  despawnEffect : 枪羽消失,

  fragBullets : 1,
  fragRandomSpread : 0,
  fragBullet : 枪羽主弹frag
})
let 枪羽主武 = extend(Weapon,{
  continuous : true,
  x : 0,
  y : 0,
  reload : 120,
  recoil : 0.2,
  bullet : 枪羽主弹
})

枪羽.weapons.add(枪羽主武);