const myitem = require("items")
const 破冲 = new BurstDrill("破冲");
exports.破冲 = 破冲;