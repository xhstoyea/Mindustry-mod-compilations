const 底数 = 8;//越大增长速率越慢
const myitems = require("items");
const 生产倍率 = 1;
const 生产物品 = myitems.魔晶;
const 生产时间 = 190;
const 落地给予物品 = 50;

const 魔能之核  = extend(CoreBlock,"魔能之核",{
  update : true,
  setBars(){
    this.super$setBars();
  }
})

魔能之核.buildType = () => {
  let craftTimer  = 0;
  let effTimer = 0;
  let gift = 0;
  return extend(CoreBlock.CoreBuild,魔能之核,{
    getProgress(){
      return craftTimer / 生产时间;
    },
    updateTile(){
      this.super$updateTile();
      craftTimer += Time.delta;
      effTimer += Time.delta;

      if(gift == 0){
        gift = 1;
        this.items.add(生产物品,落地给予物品);
      }

      if(craftTimer > 生产时间){
        craftTimer -= 生产时间;
        let items = 生产倍率 * Math.floor(Mathf.log(底数,effTimer / 60 + 1));
        if(this.items.get(生产物品) + items < this.getMaximumAccepted(生产物品)){
          this.items.add(生产物品,items);
        } else {
          this.items.add(生产物品,this.getMaximumAccepted(生产物品) - this.items.get(生产物品));
        }
      }
    },
    write(w){
      this.super$write(w);
      w.f(craftTimer);
      w.f(effTimer);
    },
    read(r,rv){
      this.super$read(r,rv);
      craftTimer = r.f();
      effTimer = r.f();
    }
  })
}

exports.魔能之核 = 魔能之核;