const lib = require("lib");
const myitems = require("items");
const 开拓核心 = extend(CoreBlock, "开拓核心", {});

const 泰克博斯 = new Planet("泰克博斯", Planets.sun, 1,2);
Object.assign(泰克博斯, {
	generator: extend(SerpuloPlanetGenerator,  {
		getDefaultLoadout() {
			return Schematics.readBase64("bXNjaAF4nGNgZmBmZmDJS8xNZeB5uqfhWffkZwt2PN3fzMCdklqcXJRZUJKZn8fAwMCWk5iUmlPMwBQdy8gg+aK79/nKnU/3Nb5smKKLoo2BgRGEgAQAQDwjZQ==");
		},
		allowLanding(sector){return false},
getColor(position){
            let noise = Simplex.noise3d(this.seed, 8, 1, 1, position.x, position.y, position.z);
            if(noise > 0.48){
                return Color.valueOf("D5FFC893");
            }
            if(noise < 0.48){
                return Color.valueOf("3A5651FF");
            }
            /*let deep = Simplex.noise3d(this.seed, 5, 0.3, 1/3, position.x, position.y, position.z);
            return Tmp.c1.set(colorSrc).lerp(Color.black, deep);*/
        },
        generateSector(sector){
            this.super$generateSector(sector);
        },
    }),

	/*meshLoader: prov(() => new HexMesh(泰克博斯, 4)),
	cloudMeshLoader: () => new MultiMesh(
		new HexSkyMesh(泰克博斯, 2, 0.15, 0.14, 5, Color.valueOf("FFFFFFD2"), 2, 0.42, 1, 0.45)
	),*/

        meshLoader: prov(() => new HexMesh(泰克博斯, 5)),
        cloudMeshLoader : () => new MultiMesh(
            new HexSkyMesh(泰克博斯, 3, 0.15, 0.14, 5, Color.valueOf("D4FFC7CE"), 2, 0.42, 1, 0.45),
            new HexSkyMesh(泰克博斯, 1, 0.6, 0.16, 5, Color.valueOf("3A5751C0"), 2, 0.45, 1, 0.41)
        ),

	atmosphereColor: Color.valueOf("3A5651FF"),
	atmosphereRadIn: 0.02,
	atmosphereRadOut: 0.3,
	visible: true,
	bloom: false,
	accessible: true,
	alwaysUnlocked: true,
	startSector: 1,
	camRadius: 0.5,
	orbitRadius: 75,
	orbitSpacing: 2,
	orbitTime: 240 * 60,
	rotateTime: 15 * 60,
	defaultCore: 开拓核心,
	iconColor: Color.valueOf("D5FFC893"),
    clearSectorOnLose: true, 
})

泰克博斯.ruleSetter = r => {
	r.attributes.set(Attribute.heat, 0);
	r.attributes.set(Attribute.light, -0.5);
	            r.waveTeam = Team.malis,
                r.placeRangeCheck = false,
                r.showSpawns = true,
                r.fog = true,
                r.staticFog = true,
                r.lighting = false,
                r.coreDestroyClear = true,
                r.onlyDepositCore = true
	
}
泰克博斯.totalRadius += 2.6;
泰克博斯.hiddenItems.addAll(
	Items.scrap,
	Items.copper,
	Items.lead,
	Items.titanium,
	Items.thorium,
	Items.plastanium,
	Items.sporePod,
	Items.blastCompound,
	Items.pyratite,
	Items.metaglass,
	Items.beryllium,
	Items.carbide,
	myitems.碲,
myitems.锂,
myitems.钚,
myitems.钠,
myitems.朱砂,
myitems.魔晶,
myitems.星辰,
);
Planets.serpulo.hiddenItems.addAll(
myitems.铋,
myitems.铟,
myitems.莱特合金,
myitems.铀,
myitems.伊泰普合金,
)
Planets.erekir.hiddenItems.addAll(
myitems.铋,
myitems.铟,
myitems.莱特合金,
myitems.铀,
myitems.伊泰普合金,
)

exports.泰克博斯 = 泰克博斯;

 const 紧急迫降区 = new SectorPreset("紧急迫降区", 泰克博斯, 1);
 紧急迫降区.planet = 泰克博斯;
 紧急迫降区.difficulty = 1;
 紧急迫降区.alwaysUnlocked = true;
 紧急迫降区.addStartingItems = false;
 紧急迫降区.captureWave = 10;
 紧急迫降区.localizedName = "紧急迫降区";
 紧急迫降区.description = "我们迫降在一个贫瘠的地区，尽快学习如何发展并寻找更加富有的地区";
 exports.紧急迫降区 = 紧急迫降区;
 lib.addToResearch(紧急迫降区, {
 parent: "groundZero",
 objectives: Seq.with(
 new Objectives.SectorComplete(SectorPresets.groundZero))
 });
 
 const 弥尘峡谷 = new SectorPreset("弥尘峡谷", 泰克博斯, 5);
 弥尘峡谷.planet = 泰克博斯;
 弥尘峡谷.difficulty = 1;
弥尘峡谷.description = "这条峡谷中隐藏着未知敌人的雷达站，放任不管必会留下后患，建造单位，摧毁它";
 弥尘峡谷.localizedName = "弥尘峡谷";
 exports.弥尘峡谷 = 弥尘峡谷;
 lib.addToResearch(弥尘峡谷, {
 parent: "紧急迫降区",
 objectives: Seq.with(
 new Objectives.SectorComplete(紧急迫降区))
 });
 
 const 碎裂污湖 = new SectorPreset("碎裂污湖", 泰克博斯, 2);
 碎裂污湖.planet = 泰克博斯;
 碎裂污湖.description = "一片岛屿众多的湖泊，先前的地质探测已表明这本是一块盆地。这片区域矿藏丰富，但附近敌人的海军基地发现了我们的行动，抵御他们，占领这里。此外，这边区域有大量不明结构，探查它们";
 碎裂污湖.difficulty = 2;
 碎裂污湖.captureWave = 20;
 碎裂污湖.localizedName = "碎裂污湖";
 exports.碎裂污湖 = 碎裂污湖;
 lib.addToResearch(碎裂污湖, {
 parent: "弥尘峡谷",
 objectives: Seq.with(
 new Objectives.SectorComplete(弥尘峡谷))
 });
 
 const 遗迹火山 = new SectorPreset("遗迹火山", 泰克博斯, 4);
 遗迹火山.planet = 泰克博斯;
 遗迹火山.difficulty = 3;
 遗迹火山.captureWave = 20;
 遗迹火山.description = "一座仍然活跃的火山坐落于此。这里矿藏丰富，得益于干燥的气候,此处的遗迹大多仍可以使用。敌方注意到我们的动向，各方向的前哨正被大量摧毁。抵御敌人的猛烈攻势，占领这里研究遗迹";
 遗迹火山.localizedName = "遗迹火山";
 exports.遗迹火山 = 遗迹火山;
 lib.addToResearch(遗迹火山, {
 parent: "碎裂污湖",
 objectives: Seq.with(
 new Objectives.SectorComplete(碎裂污湖))
 });
 const 横断丘壑 = new SectorPreset("横断丘壑", 泰克博斯, 6);
 横断丘壑.planet = 泰克博斯;
 横断丘壑.difficulty = 3;
 横断丘壑.description = "一块偏远的山脉，盘踞着大量的敌人基地。复杂的地形让其他单位难以适应，利用爬行单位的优势，击破敌人的防线，摧毁敌人的要塞，占领这里";
 横断丘壑.localizedName = "横断丘壑";
 exports.横断丘壑 = 横断丘壑;
 lib.addToResearch(横断丘壑, {
 parent: "遗迹火山",
 objectives: Seq.with(
 new Objectives.SectorComplete(遗迹火山))
 });
 const 污染边河 = new SectorPreset("污染边河", 泰克博斯, 10);
 污染边河.planet = 泰克博斯
 污染边河.captureWave = 20;;
 污染边河.difficulty = 4;
 污染边河.description = "一条火山边的河流，扫描显示这里出现了铀矿石，显然敌人要和我们争夺这块铀床";
 污染边河.localizedName = "污染边河";
 exports.污染边河 = 污染边河;
 lib.addToResearch(污染边河, {
 parent: "遗迹火山",
 objectives: Seq.with(
 new Objectives.SectorComplete(遗迹火山))
 });
 const 冰封堡垒 = new SectorPreset("冰封堡垒", 泰克博斯, 13);
 冰封堡垒.planet = 泰克博斯;
 冰封堡垒.difficulty = 3;
 冰封堡垒.description = "两座冰封的山脉组成了特殊的地形，被另一波敌人占领。这里易守难攻，使用高级单位进行反击";
 冰封堡垒.localizedName = "冰封堡垒";
 exports.冰封堡垒 = 冰封堡垒;
 lib.addToResearch(冰封堡垒, {
 parent: "污染边河",
 objectives: Seq.with(
 new Objectives.SectorComplete(污染边河))
 });
 const 边陲海湾 = new SectorPreset("边陲海湾", 泰克博斯, 20);
边陲海湾.alwaysUnlocked = false;
边陲海湾.difficulty = 5;
边陲海湾.localizedName = "边陲海湾";
exports.边陲海湾 = 边陲海湾;
lib.addToResearch(边陲海湾, {
    parent: 冰封堡垒,
    objectives: Seq.with(
        new Objectives.SectorComplete(冰封堡垒))
});