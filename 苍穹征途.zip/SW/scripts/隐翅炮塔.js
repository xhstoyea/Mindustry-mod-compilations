const 隐翅炮塔 = extend(UnitType,"隐翅炮塔",{});
隐翅炮塔.constructor = () => extend(TimedKillUnit,{});