const lib = require("lib");
const myitems = require("items");
const 破冲 = require("破冲");
const 开拓者基站 = extend(CoreBlock, "开拓者基站", {});

const 克莱希特 = new Planet("克莱希特", Planets.sun, 1,1.8);
Object.assign(克莱希特, {
	generator: extend(SerpuloPlanetGenerator,  {
		getDefaultLoadout() {
			return Schematics.readBase64("bXNjaAF4nGNgZmBmYWDJS8xNZeB/1rfo+ZZFLxpan87f9Xz1TAb24pLUxNzMFAau4uSM1NzEkszkYgbulNTi5KLMgpLM/DwGBga2nMSk1JxiBqboWEYGmRfdvc9X7ny6r/FlwxTdp3sannVPRhjHwMAIQkACAK8nLpg=");
		},
		allowLanding(sector){return false},
getColor(position){
            let noise = Simplex.noise3d(this.seed, 8, 1, 1, position.x, position.y, position.z);
            if(noise > 0.48){
                return Color.valueOf("8CA9E8FF");
            }
            if(noise < 0.48){
                return Color.valueOf("272F4FFF");
            }
            /*let deep = Simplex.noise3d(this.seed, 5, 0.3, 1/3, position.x, position.y, position.z);
            return Tmp.c1.set(colorSrc).lerp(Color.black, deep);*/
        },
        generateSector(sector){
            this.super$generateSector(sector);
        },
    }),

	/*meshLoader: prov(() => new HexMesh(克莱希特, 4)),
	cloudMeshLoader: () => new MultiMesh(
		new HexSkyMesh(克莱希特, 2, 0.15, 0.14, 5, Color.valueOf("FFFFFFD2"), 2, 0.42, 1, 0.45)
	),*/

        meshLoader: prov(() => new HexMesh(克莱希特,4)),
        cloudMeshLoader : () => new MultiMesh(
            new HexSkyMesh(克莱希特, 2, 0.15, 0.14, 5, Color.valueOf("272F4FB6"), 2, 0.42, 1, 0.45),
            new HexSkyMesh(克莱希特, 1, 0.6, 0.16, 5, Color.valueOf("D1EFFFD5"), 2, 0.45, 1, 0.41)
        ),

	atmosphereRadIn: 0.2,
	atmosphereRadOut: 0.3,
	visible: true,
	bloom: false,
	accessible: true,
	alwaysUnlocked: true,
	atmosphereColor : Color.valueOf("272F4FFF"),
	lightColor : Color.valueOf("8CA9E8FF"),
	startSector: 2,
	camRadius: 0.5,
	orbitRadius: 75,
	orbitSpacing: 2,
	orbitTime: 300 * 60,
	rotateTime: 5 * 60,
	defaultCore: 开拓者基站,
	iconColor: Color.valueOf("8CA9E8FF"),
    clearSectorOnLose: true, 
})

克莱希特.ruleSetter = r => {
	r.attributes.set(Attribute.heat, -2);
	r.attributes.set(Attribute.light, -3);
	            r.waveTeam = Team.blue;
	            r.defaultTeam = Team.crux;
                r.placeRangeCheck = false;
                r.showSpawns = false;
                r.lighting = false;
                r.coreDestroyClear = true;
                r.onlyDepositCore = true
}
克莱希特.totalRadius += 2.6;

克莱希特.hiddenItems.addAll(
	Items.copper,
	Items.lead,
	Items.thorium,
	Items.sporePod,
	Items.blastCompound,
	Items.beryllium,
	myitems.铋,
	myitems.铟,
	myitems.铀,
	myitems.莱特合金,
	myitems.伊泰普合金,
	myitems.魔晶,
	myitems.星辰,
);
Planets.serpulo.hiddenItems.addAll(
myitems.碲,
myitems.锂,
myitems.钚,
myitems.钠,
myitems.朱砂,
)
Planets.erekir.hiddenItems.addAll(
myitems.碲,
myitems.锂,
myitems.钚,
myitems.钠,
myitems.朱砂,
myitems.魔晶,
myitems.星辰,
)

破冲.requirements = ItemStack.with(
myitems.铋,20
);
Log.info(破冲)
Log.info(破冲.requirements)
Log.info(!Structs.contains(破冲.requirements, i => 克莱希特.hiddenItems.contains(i.item)));

const 伊始之湖 = new SectorPreset("伊始之湖", 克莱希特, 2);
 伊始之湖.planet = 克莱希特;
 伊始之湖.alwaysUnlocked = true; //总是解锁
 伊始之湖.captureWave = 11;
 伊始之湖.difficulty = 2;
 伊始之湖.addStartingItems = false;
 伊始之湖.description = "一条宽广的湖，适宜初期发展，抵御敌人，占领这里";
 伊始之湖.localizedName = "伊始之湖";
 exports.伊始之湖 = 伊始之湖;
 lib.addToResearch(伊始之湖, {
 parent: "groundZero",
 objectives: Seq.with(
 new Objectives.SectorComplete(SectorPresets.groundZero))
 });
 
 const 荒芜海峡 = new SectorPreset("荒芜海峡", 克莱希特, 10);
 荒芜海峡.planet = 克莱希特;
 荒芜海峡.captureWave = 15;
 荒芜海峡.difficulty = 2;
 荒芜海峡.description = "扫描发现这里出现大量空中敌人，生产钢化玻璃，使用新武器消灭他们";
 荒芜海峡.localizedName = "荒芜海峡";
 exports.荒芜海峡 = 荒芜海峡;
 lib.addToResearch(荒芜海峡, {
 parent: "伊始之湖",
 objectives: Seq.with(
 new Objectives.SectorComplete(伊始之湖))
 });
 
 const 广阔河谷 = new SectorPreset("广阔河谷", 克莱希特, 8);
 广阔河谷.planet = 克莱希特;
 广阔河谷.captureWave = 20;
 广阔河谷.difficulty = 4;
 广阔河谷.description = "我们中埋伏了，敌人正从四面八方涌来，抵御他们，研究科技";
 广阔河谷.localizedName = "广阔河谷";
 exports.广阔河谷 = 广阔河谷;
 lib.addToResearch(广阔河谷, {
 parent: "荒芜海峡",
 objectives: Seq.with(
 new Objectives.SectorComplete(荒芜海峡))
 });
 
 const 双子海峡 = new SectorPreset("双子海峡", 克莱希特, 12);
 双子海峡.planet = 克莱希特;
 双子海峡.captureWave = 18;
 双子海峡.difficulty = 5;
 双子海峡.description = "前方不远处发现地方据点，或许我们应该先处理追兵？ 干掉他们！";
 双子海峡.localizedName = "双子海峡";
 exports.双子海峡 = 双子海峡;
 lib.addToResearch(双子海峡, {
 parent: "荒芜海峡",
 objectives: Seq.with(
 new Objectives.SectorComplete(荒芜海峡))
 });
 
 const 暗礁要塞 = new SectorPreset("暗礁要塞", 克莱希特, 20);
 暗礁要塞.planet = 克莱希特;
 暗礁要塞.difficulty = 5;
 暗礁要塞.description = "我们抵达了敌方要塞，研发单位，摧毁这里！";
 暗礁要塞.localizedName = "暗礁要塞";
 exports.暗礁要塞 = 暗礁要塞;
 lib.addToResearch(暗礁要塞, {
 parent: "广阔河谷",
 objectives: Seq.with(
 new Objectives.SectorComplete(广阔河谷))
 });
exports.克莱希特 = 克莱希特;

