const 星翼 = new UnitType("星翼");

星翼.constructor = prov(() => extend(UnitTypes.flare.constructor.get().class, {}));

let 坍星Interval = extend(BasicBulletType,{
  lifetime : 80,
  speed : 8,

  damage : 80,
  splashDamage : 64,
  splashDamageRadius : 24,
  pierceArmor : true


})

let 坍星粒子 = new MultiEffect(
  extend(ParticleEffect,{
    interp : Interp.pow3In,
    line : true,
    particles : 3,
    lifetime : 60,

    baseLength : 200,
    length : -196,
    strokeFrom : 0,
    strokeTo : 2,
    lenFrom : 4,
    lenTo : 12,
    colorFrom : Color.valueOf("FFB1EB"),
    colorTo : Color.valueOf("FFB1EB")
  })
)
let 坍星爆炸 = new MultiEffect(
  new Effect(360,e => {
    if(e.time < 240)坍星粒子.at(e.x,e.y);
    Effect.shake(20 * e.fout(),20 * e.fout(),e.x,e.y);

    let a = e.time;
    Draw.z(110);
    Draw.color(Color.valueOf("FFB1EB"));
    Fill.circle(e.x,e.y,-0.000525 * a * a + 0.084 * a + 37.8);
    Drawf.tri(e.x,e.y,10 * e.fout(),-0.00525 * a * a + 5.25 * a + 240,0);
    Drawf.tri(e.x,e.y,10 * e.fout(),-0.00525 * a * a + 5.25 * a + 240,180);
    Draw.z(115);
    Draw.color(Color.black);
    Fill.circle(e.x,e.y,-0.0005 * a * a + 0.08 * a + 36);
    Drawf.tri(e.x,e.y,6 * e.fout(),-0.005 * a * a + 5 * a + 240,0);
    Drawf.tri(e.x,e.y,6 * e.fout(),-0.005 * a * a + 5 * a + 240,180);
  }),
  extend(WaveEffect,{
    interp : Interp.pow10In,
    lifetime : 120,
    sizeFrom : 37.8,
    sizeTo : 800,
    strokeFrom : 12,
    strokeTo : 0,
    colorFrom : Color.valueOf("FFB1EB"),
    colorTo : Color.valueOf("FFB1EB"),
  })
)
let 坍星之卵 = extend(BasicBulletType,{
  lifetime : 480,
  speed : 4,
  drag : 0.008,

  damage : 800000,
  splashDamge : 360000,
  splashDamageRadius : 240,

  hitShake : 80,

  absorbable : false,
  reflectable : false,
  hittable : false,
  collides : false,

  shake : 24,
  despawnEffect : 坍星爆炸,

  bulletInterval : 10,
  intervalBullets : 3,
  intervalRandomSpread : 360,
  intervalBullet : 坍星Interval,
})
坍星之卵.parts.addAll(
  extend(ShapePart,{
    progress : DrawPart.PartProgress.life.curve(Interp.pow10Out),
    circle : true,
    radius : 0,
    radiusTo : 4,
    color : Color.valueOf("000000"),
    colorTo : Color.valueOf("000000"),
    layer : 115
  }),
  extend(ShapePart,{
    progress : DrawPart.PartProgress.life.curve(Interp.pow10Out),
    circle : true,
    radius : 0,
    radiusTo : 6,
    color : Color.valueOf("FFB1EB"),
    colorTo : Color.valueOf("FFB1EB"),
    layer : 110
  }),
  extend(HaloPart,{
    progress : DrawPart.PartProgress.life.curve(Interp.pow10Out),
    tri : true,
    radius : 0,
    radiusTo : 2.4,
    triLength : 3,
    triLengthTo : 8,
    haloRadius : 0,
    haloRadiusTo : 3.2,
    rotateSpeed : 0.8,
    color : Color.valueOf("FFB1EB"),
    colorTo : Color.valueOf("FFB1EB"),
    layer : 110
  }),
  extend(ShapePart,{
    progress : DrawPart.PartProgress.life.curve(Interp.pow10Out),
    hollow : true,
    sides : 12,
    rotateSpeed : 1.2,
    radius : 0,
    radiusTo : 36,
    stroke : 0,
    strokeTo : 2.2,
    color : Color.valueOf("FFB1EB"),
    colorTo : Color.valueOf("FFB1EB"),
    layer : Layer.effect
  }),
  extend(ShapePart,{
    progress : DrawPart.PartProgress.life.curve(Interp.pow10Out),
    hollow : true,
    sides : 10,
    rotateSpeed : -1.6,
    radius : 0,
    radiusTo : 30,
    stroke : 0,
    strokeTo : 1.4,
    color : Color.valueOf("FFB1EB"),
    colorTo : Color.valueOf("FFB1EB"),
    layer : Layer.effect
  }),
  extend(ShapePart,{
    progress : DrawPart.PartProgress.life.curve(Interp.pow10In),
    circle : true,
    radius : 0,
    radiusTo : 36,
    color : Color.valueOf("FFB1EB00"),
    colorTo : Color.valueOf("FFB1EB"),
    layer : 111
  }),
)
let 星翼主武 = extend(Weapon,{
  reload : 200,
  bullet : 坍星之卵
})
星翼.weapons.add(星翼主武)