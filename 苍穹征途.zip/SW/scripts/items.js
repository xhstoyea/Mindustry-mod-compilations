function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("铋")
newItem("碲")
newItem("锂")
newItem("钚")
newItem("钠")
newItem("铟")
newItem("铀")
newItem("莱特合金")
newItem("伊泰普合金")
newItem("魔晶")
newItem("星辰")