let 夺魄蓄力 = new MultiEffect(
  
)
let 夺魄轨迹 = new MultiEffect(
  new Effect(30,e => {
    Angles.randLenVectors(e.id + 1,8, 46 * e.finpow(),new Floatc2({
      
    }))
  })
)
let 夺魄子弹 = extend(BasicBulletType,{
  lifetime : 80,
  speed : 6,

  frontColor : Color.valueOf("c1ffff"),
  backColor : Color.valueOf("c1ffff"),
  trailColor : Color.valueOf("fe98ff"),
  trailWidth : 4,
  trailLength : 20,

  homingPower : 0.32,
  homingRange : 360,

  pierce : true,
  pierceArmor : true,

  damage : 512,

  init(b){
    if(b === undefined) return;
    this.super$init();
    this.super$init(b);
    b.damage *= 1 + b.owner.getAddition(); 
  },
  hitEntity(b,entity,health){
    this.super$hitEntity(b,entity,health);
    if(entity instanceof Healthc){
      if(entity.health < b.damage){
        b.damage -= entity.health;
        b.time += 20;
        b.owner.addDamage();
      } else {
        b.lifetime = b.time;
      }
    }
  }
})

const 夺魄 = extend(PowerTurret,"夺魄",{
  shootType : 夺魄子弹,

  setBars(){
    this.super$setBars();

    this.addBar("damageMultiplier",e => new Bar(
      () => Core.bundle.get("damageMultiplier") + Math.floor(e.getAddition() * 100) / 100,
      () => Color.valueOf("ffffff"),
      () => 1
    ))
  }
})

夺魄.buildType = () => {
  let addDamage = 0;
  return new JavaAdapter(PowerTurret.PowerTurretBuild,{
    getAddition(){
      return addDamage;
    },
    addDamage(){
      addDamage = addDamage + 0.05;
    },
    write(write){
      write.i(addDamage);
    },
    read(read,revision){
      this.super$read(read,revision);
      addDamage = read.i();
    }
  },夺魄)
}

