exports.灭火AI = (retargetTime) => {
	let TARGET;
	let retargetTimer = 0;
	return extend(AIController,{
		updateMovement(){
			if(TARGET != null){
				if(this.unit.type.circleTarget) this.circleAttack(120);
				else if(!TARGET.within(this.unit,this.unit.type.range * 0.65)) this.moveTo(TARGET,this.unit.type.range * 0.65);
				else this.moveTo(TARGET,this.unit.type.range * 0.65);

				this.unit.lookAt(TARGET);

				let shoot = false;
				if(TARGET.within(this.unit,this.unit.type.range)){
					this.unit.aim(TARGET);
					shoot = true;
				}
				this.unit.controlWeapons(shoot);
			} else if(retargetTimer > 0 && TARGET == null){
				this.unit.controlWeapons(true);
			} else {
				let core = this.unit.closestCore();
				this.moveTo(core,this.unit.type.range * 0.35);
				this.unit.controlWeapons(false);
			}
		},
		updateTargeting(){
			let result = null;
			let realRange = Math.max(this.unit.type.range,800);
			result = Groups.bullet.intersect(this.unit.x - realRange,this.unit.y - realRange,realRange * 2,realRange * 2).min(b => b.type == Bullets.fireball,b => b.dst2(this.unit.x,this.unit.y));

			TARGET = result;

			retargetTimer -= Time.delta;
			if(TARGET != null) retargetTimer = retargetTime;
		}
	})
}