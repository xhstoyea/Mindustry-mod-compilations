        一些不知有啥的东西
        
    "hovering": true, //盘旋。身子转，腿不转。false就是一起转
  "legCount": 6,  // 腿部数量
  "legMoveSpace": 1,  // 腿部移动间距
  "legPairOffset": 2,  // 腿部配对偏移
  "legLength": 22.5,  // 腿部长度
  "legExtension": -1.3,  // 腿部伸展度
  "legBaseOffset": 6.5,  // 腿部基础偏移
  "stepShake": 0.5,  // 步伐震动强度
  "legLengthScl": 1,  // 腿部长度比例
        腿部
        
        
  "treadRects": [
    {
      "type": "Rect",
      "x": -111,
      "y": -128,
      "width": 47,
      "height": 112
    },
    {
      "type": "Rect",
      "x": -111,
      "y": 16,
      "width": 47,
      "height": 112
    }
  ],
  来源 火星人 
  大致把这个坦克履带接口搞懂了，怕以后有人写坦克出现履带细节错误在这放个教程
接口有三个：treadRects、treadPullOffset、treadFrames
与其他大部分贴图相关接口不同的是这仨的数值的单位就是像素，即1对应1像素，而非1对应4像素
treadRects是和weapons类似的列表，格式是这样：
"treadRects": [
  {
    "type": "Rect",
    "x": 履带左下角到贴图中心的x轴距离
    "y": 履带左下角到贴图中心的y轴距离
    "width": 履带宽
    "height": 履带长
  }
]
（这个type不清楚要不要写，反正写了不报错）
花括号及以内的可以复制，就跟武器一样可以搞多对履带，每个履带会自动镜像
根据屑猫的注释，treadPullOffset表示履带上方被“裁掉”的长度
就拿最基本的明暗交替矩形履带举例，有时候履带中除了循环交替出现的、相同长度的明暗色块，在两端可能出现一些长度更短的色块，这时就要用到treadPullOffset进行修正
画图时建议让最上端和最下端的色块颜色相同，上面的被裁掉也无所谓，不过下面和中间的色块要保持相同长度
此时，其他色块的长度减去最上端色块的长度就是treadPullOffset的值
例如，有长度均为9（指y轴长度，不是履带宽）的明暗色块组成履带，最上端是个长度为4的、与最下端颜色相同的色块，那么treadPullOffset为5
treadFrames就比较好算，它的值就是除了被裁掉的的色块长的两倍，上面这个情况treadFrames就是18，使得履带能够通过18帧，每帧移动1像素完成一次完整的循环运动，防止视觉上的卡顿
埃里克尔的坦克treadFrames值都是18，即源码里的默认值，它们的色块长也都是9，如果懒得填可以也照着画成9
        
        不到.有什么用
        healColor: B572F7FF//被修复时颜色
  shieldColor: 8A48CC00//护盾颜色
        
      "parts": [
        {
          "type": "RegionPart",
          "suffix": "-tube",
          "progress": "reload",
          "x": 0,
          "y": 0,
          "moveX": 1.5,
          "moveY": 0
          "under": true,
          "layerOffset": -0.001,
          "mirror": false
        },
        ]
        转
        {
		    "name": "886"
			"x": 10
			"y": 9
			"reload": 10,
			"shootY": 0,
			"mirror": true,
			"rotate": true,
			"rotateSpeed": 0,
			"useAmmo": false,
			"alwaysShooting": true,
			"continuous": true,
			"display":false
			"ejectEffect":"none",
	        "shootSound":"none",
			"recoil": 0,
			"parts":[
        	    {
                    "type":"RegionPart",
                    "mirror":false,
                    "x":0,"y":0,
                    "suffix":"叶"
                    "layer":120,
                    "moveX":0,
                    "moveY":0
                    "moveRot":360
                    "outline": false,
                    "progress":"reload",
                }
            ]
			"bullet": {
                "speed": 999
                "lifetime":1
                "width": 0,"height": 0,
                "damage":0
                "shootEffect": "none",
				"hitEffect": "none",
				"despawnEffect": "none"
				"smokeEffect": "none"
				"despawnSound":"none",
			}
		}
		从隔壁顺的螺旋桨
		
		"parts": [
        {
          "type": "RegionPart", // 区域部件
          "suffix": "围护-1", // 纹理后缀
          "progress": "reload", // 随装弹进度动画
          "moveRot": 90, // 移动旋转
          "rotation": -90, // 初始旋转
          "mirror": false, // 无镜像
          "color": "ffffff00", // 颜色
          "colorTo": "ffffffff" // 目标颜色
        }
		]
		也是顺的
		
"parts": [
  {
    "type": "FlarePart"
    "x": 0
    "y": -3.5
    "color1": "89E3EDFF"
    "color2": "8CAAE8FF"
    "spinSpeed": -0.65
    "radius": 15
    "followRotation": true,
    "sides": 4
    },
  ]
		特效
    "bullet": {
        "weaveScale": 3,   // 摆动幅度（数值越大，摆动越宽）
        "weaveMag": 6,     // 摆动频率（数值越大，摆动越快）
        }
        
                    // === 连发配置 ===
            "shoot": {
                "shots": 2,              // 每次触发发射
                "shotDelay": 0           // 连发间隔（0=同时发射）
            },
            这是单位的
            
        
      	"rangeChange": 30,
      	这是加子弹射程的
        
        单位工厂
        {
            "type": "UnitSpawnAbility", // 单位生成能力
            "unit": "单位名", // 生成的单位类型
            "spawnTime": 800, // 生成单位的时间间隔（单位：帧，每秒60帧）
            "spawnY": 0, // 生成单位的Y轴偏移
            "spawnX": 0 // 生成单位的X轴偏移
        }
        
        让你的炮台动起来
"drawer":{
"type":"DrawTurret",
    "parts":[
       {
    "type":"RegionPart",
    "mirror":false,//是否开启镜像
    "x":0,
    "y":0,//初始位置
    "suffix":"-1"//,贴图后缀 在你的贴图后面写一个就行
    "layer":50,//层，49-110
    "moveX":0,//改变位置
    "moveY":8.5
    }
    ]
    },
        
        
   类似于生物的翅膀
   可以做点扑棱蛾子之类的
        "parts": [  // 单位部件（用于装饰或动画效果）
        {
            "type": "RegionPart",  // 部件类型：区域部件
            "mirror": true,  // 是否镜像（是否在两侧各显示一个）
            "x": 0,  // 部件位置（X坐标）
            "y": 0,  // 部件位置（Y坐标）
            "suffix": "-wing",  // 部件后缀（用于指定显示的图像）//贴图写这个 你要动的贴图-wing
            "moveX": 0,  // 部件水平移动偏移量
            "moveY": 0,  // 部件垂直移动偏移量
            "moveRot": 30,  // 部件旋转角度
            "outline": false,  // 是否绘制轮廓
            "progress": {  // 部件动画进度
                "type": "smoothReload",  // 动画类型：平滑重载
                "op": "sin",  // 操作函数：正弦
                "offset": 20,  // 偏移量
                "scl": 1,  // 缩放值
                "mag": 1  // 幅度
            }
        }
    ]
    
    
    
    一堆的特效
    {
  "type": "LaserTurret",
  "drawer": {
    "type": "drawTurret",
    "parts": [
      // 主发光圆环 (白色高亮核心)
      {
        "type": "shapePart",       // 基础图形部件
        "progress": {             // 动态效果控制
          "type": "charge",       // 随充能进度变化
          "op": "blend",          // 混合其他效果
          "other": "recoil",      // 混合后坐力效果
          "amount": 0.5          // 混合比例
        },
        "y": 9,                  // Y轴偏移位置
        "circle": true,           // 绘制圆形
        "layer": 114,             // 渲染层级(较高)
        "color": "ffFFFFff",      // 纯白色带透明度
        "radiusTo": 4.5,          // 最大半径
        "radius": 0               // 初始半径(从0开始增长)
      },
      
      // 次级发光圆环 (蓝色光晕)
      {
        "type": "shapePart",
        "progress": {             // 与主圆环同步变化
          "type": "charge",
          "op": "blend",
          "other": "recoil",
          "amount": 0.5
        },
        "y": 9,                   // 与主圆环同位置
        "circle": true,
        "layer": 110,              // 稍低的渲染层级
        "color": "66B1FFFF",       // 天蓝色带透明度
        "radiusTo": 6,             // 更大的半径(光晕效果)
        "radius": 0
      },

      // 副发光圆环 (顶部白色光点)
      {
        "type": "shapePart",
        "progress": {             // 同步充能效果
          "type": "charge",
          "op": "blend",
          "other": "recoil",
          "amount": 0.5
        },
        "moveY": -5,              // 上移5单位(炮管顶部位置)
        "circle": true,
        "layer": 114,             // 高渲染层级
        "color": "ffFFFFff",      // 纯白光
        "radiusTo": 5.5,          // 中等大小
        "radius": 0
      },

      // 副光晕圆环 (顶部蓝色光晕)
      {
        "type": "shapePart",
        "progress": {             // 同步变化
          "type": "charge",
          "op": "blend",
          "other": "recoil",
          "amount": 0.5
        },
        "moveY": -5,              // 与白色光点同位置
        "circle": true,
        "layer": 110,             // 稍低层级
        "color": "66B1FFFF",       // 天蓝色
        "radiusTo": 7,             // 最大光晕范围
        "radius": 0
      }
    ]
  }
}
    
    
    
    