Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("晶新战争"); //新建一个显示窗口
    dialog.buttons.button("@close", run(() => {
        dialog.hide(); //退出界面
    })).size(128, 64); //@close
    
    dialog.cont.button("加入晶新战争群", run(() => {
        Core.app.openURI("http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=mq_AXhT-_V9XjFJ14YFghhabuavwHK3o&authKey=F%2Bz%2BnZw%2FhN3eVxRb%2BARpKFVbkowFMn%2Fuims2GUWHK1wJASvXBopmE54BWlZgocbi&noverify=0&group_code=2158027406");
    })).size(100, 70).pad(4);
    
    dialog.cont.pane((() => {
        var table = new Table();
        table.add("作者b站:[yellow]一个屑爬重");
        table.row();
        table.add("附属制作:[green]花瓶星");
        table.row();
        table.add("更新:由于作者不想做一大堆东西\n导致模组内存减少").left().growX().wrap().width(200).maxWidth(300).pad(4).labelAlign(Align.left);
        table.row();
        return table;
    })()).grow().center().maxWidth(300);
    
    dialog.show();
}));