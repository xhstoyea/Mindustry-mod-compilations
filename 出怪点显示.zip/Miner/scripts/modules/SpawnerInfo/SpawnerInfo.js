var infoTable = require("modules/SpawnerInfo/ui/SpawnerInfoTable");
var destoryTiles = require("modules/SpawnerInfo/DestoryTiles");
var rangeRander = require("modules/SpawnerInfo/graphics/SpawnerRange");
var utils = require("utils");

// 常数
const spawner = Vars.spawner;
const tilesize = Vars.tilesize;

let rangeGround = 0, rangeFlyer = tilesize * 6;

// 反射需用工具
let eachFlyerSpawnMethod = utils.getMethod(
    WaveSpawner.__javaObject__, 
    "eachFlyerSpawn", 
    [java.lang.Integer.TYPE, Floatc2.__javaObject__]
);

let parameter1 = new java.lang.Integer(-1);
let floatc2 = (method) => new Floatc2(){get: method};

// 由出怪点位置(格子位置) 映射到出怪组 Int -> Seq<SpawnGroup>;
let spawnCounter = new IntMap();

// 出怪点参数
let spawnerGroup = {
    groundSpawnerGroup: new Seq(),
    flyerSpawnerGroup: new Seq(),
}

infoTable.setCounter(spawnCounter);
infoTable.setSpawnerGroup(spawnerGroup);
rangeRander.setSpawnerGroup(spawnerGroup);
rangeRander.setDestoryBuildings(destoryTiles.getDestoryBuildings());

Events.on(CoreChangeEvent, e => {
    let rules = Vars.state.rules;
    let teams = Vars.state.teams;
        
    if(spawner.countSpawns() > 20){
        clear();
        return;
    }
    
    if(rules.attackMode && teams.isActive(rules.waveTeam)){
        clear();
        updateSpawnCounter();
        updateSpawnerPos();
        updateInfoTables();
    }
})

Events.on(WorldLoadEvent, e => {
    clear();
    
    if(spawner.countSpawns() > 20){
        return;
    }
    
    let rules = Vars.state.rules;
    rangeGround = rules.dropZoneRadius;
    
    rangeRander.setRange(rangeGround, rangeFlyer, rules.waveTeam.color);
    destoryTiles.setRange(rangeGround);
    
    Timer.schedule(() => {
        updateSpawnCounter();
        updateSpawnerPos();
        destoryTiles.load();
        updateInfoTables();
    }, 0.5);
});

Events.on(WaveEvent, e => {
    updateInfoTables();
});

function clear(){
    spawnCounter.clear();
    
    let {groundSpawnerGroup, flyerSpawnerGroup} = spawnerGroup;
    
    groundSpawnerGroup.clear();
    flyerSpawnerGroup.clear();
    
    infoTable.clear();
}

function updateSpawnCounter(){
    let spawnGroups = Vars.state.rules.spawns;
        
    spawnGroups.each(spawnGroup => {
        let {type, spawn} = spawnGroup;
        
        if(spawn != -1){
            spawnCounter.get(spawn, prov(() => new Seq())).add(spawnGroup);
            return;
        }
        
        if(type.flying){
            eachFlyerSpawnMethod.invoke(spawner, [parameter1, floatc2((spawnX, spawnY) => {
                let spawnWorldX = World.toTile(spawnX), spawnWorldY = World.toTile(spawnY);
                let position = Point2.pack(spawnWorldX, spawnWorldY);
                
                spawnCounter.get(position, prov(() => new Seq())).add(spawnGroup);
            })]);
        }else{
            spawner.eachGroundSpawn((spawnWorldX, spawnWorldY) => {
                let position = Point2.pack(spawnWorldX, spawnWorldY);
                
                spawnCounter.get(position, prov(() => new Seq())).add(spawnGroup);
            });
        }
    });
}

// 更新出怪位置
function updateSpawnerPos(){
    let groundSpawnerPos = new Seq();
    let flyerSpawnerPos = new Seq();
    
    let groundSpawnerMaxDst = rangeGround * 1.5;
    let flyerSpawnerMaxDst = rangeFlyer;

    spawner.eachGroundSpawn((spawnWorldX, spawnWorldY) => {
        groundSpawnerPos.add({
            x: spawnWorldX * tilesize,
            y: spawnWorldY * tilesize,
        });
    });
    
    eachFlyerSpawnMethod.invoke(spawner, [parameter1, floatc2((spawnX, spawnY) => {
        flyerSpawnerPos.add({
            x: spawnX,
            y: spawnY,
        });
    })]);
    
    let {groundSpawnerGroup, flyerSpawnerGroup} = spawnerGroup;
    
    getSpawnerGroup(groundSpawnerGroup, groundSpawnerPos, groundSpawnerMaxDst);
    getSpawnerGroup(flyerSpawnerGroup, flyerSpawnerPos, flyerSpawnerMaxDst);
}

function updateInfoTables(){
    infoTable.update();
}

const tmpSeq = new IntSeq();
function getSpawnerGroup(out, spawnerPos, maxDst){
    if(spawnerPos.isEmpty()){
        return;
    }

    let maxDst2 = maxDst * maxDst;
        
    spawnerPos.each(pos => {
        let group = createSpawnerGroup().addSpawner(pos);
        out.add(group);
    });
    
    let size = out.size;
    let isize = size - 1;
    for(let i = 0; i < isize; i++){
        let pos = spawnerPos.get(i);
        let spawnerGroup = out.get(i);
        
        let px = pos.x, py = pos.y;
        
        for(let j = i + 1; j < size; j++){
            let otherPos = spawnerPos.get(j);
            let otherSpawnerGroup = out.get(j);
            
            if(spawnerGroup == otherSpawnerGroup){
                continue;
            }
            
            let ox = otherPos.x, oy = otherPos.y;
                        
            if(Mathf.dst2(px, py, ox, oy) <= maxDst2){
                spawnerGroup.addGroup(otherSpawnerGroup);
                
                out.set(j, spawnerGroup);
            }
        }
    }
    
    out.removeAll(group => group.spawnerPos.isEmpty()).distinct();
    
    out.each(group => group.init());
}

function createSpawnerGroup(){
    return {
        // 出怪点位置(世界位置)
        spawnerPos: new Seq(),
        centroid: null,
        
        init(){
            this.centroid = getCentroid(this.spawnerPos).cpy();
        },
        
        addSpawner(pos){
            this.spawnerPos.add(pos);
            return this;
        },
        
        addGroup(otherGroup){
            let otherPos = otherGroup.spawnerPos;
            this.spawnerPos.addAll(otherPos);
            otherPos.clear();
            return this;
        },
    }
}

function getCentroid(points){
    let size = points.size;
    if(size == 1){
        let centroid = points.first();
        return Tmp.v1.set(centroid.x, centroid.y);
    }else if(size == 2){
        let p1 = points.get(0), p2 = points.get(1);
        let v1 = Tmp.v1.set(p1.x, p1.y), v2 = Tmp.v2.set(p2.x, p2.y);
        return Tmp.v3.set(v1).mulAdd(v2.sub(v1), 0.5);
    }else if(utils.isSamePoint(points)){
        let point = points.first();
        return Tmp.v1.set(point.x, point.y);
    }else if(utils.isOnLine(points)){
        let pointsArray = utils.pointSeqToFloatArray(points);
        
        utils.sortPoints(pointsArray);
        
        let p1 = points.first(), p2 = points.peek();
        let v1 = Tmp.v1.set(p1.x, p1.y), v2 = Tmp.v2.set(p2.x, p2.y);
        return Tmp.v3.set(v1).mulAdd(v2.sub(v1), 0.5);
    }else{
        let pointsArray = utils.pointSeqToFloatArray(points);
        return Geometry.polygonCentroid(pointsArray, 0, pointsArray.length, Tmp.v1);
    }
}