let tiles = new Seq();
let destoryBuildings = new Seq();

let rangeGround = 0;

let tilesize = Vars.tilesize;

function load(){
    updateTiles();
    updateDestoryBuildings();
}

function getDestoryBuildings(){
    return destoryBuildings;
}

function setRange(r){
    rangeGround = r;
}

module.exports = {
    load: load,
    getDestoryBuildings: getDestoryBuildings,
    setRange: setRange,
}

Events.on(TilePreChangeEvent, e => {
    if(tiles.isEmpty()){
        return;
    }

    let {tile} = e;
    let {build} = tile;
    if(build != null && tiles.contains(tile)){
        destoryBuildings.remove(build);
    }
});

Events.on(TileChangeEvent, e => {
    if(tiles.isEmpty()){
        return;
    }

    let {tile} = e;
    let {build} = tile;
    if(build != null && tiles.contains(tile)){
        destoryBuildings.addUnique(build);
    }
});

function updateTiles(){
    tiles.clear();
    
    let spawners = Vars.spawner.getSpawns();
    
    let world = Vars.world;
    spawners.each(spawner => {
        Geometry.circle(spawner.x, spawner.y, rangeGround / tilesize, (tx, ty) => {
            let tile = world.tile(tx, ty);
            
            if(tile != null){
                tiles.addUnique(tile);
            }
        });
    });
}

function updateDestoryBuildings(){
    destoryBuildings.clear();
    
    tiles.each(tile => {        
        let build = tile.build;
        
        if(build == null){
            return;
        }
        
        destoryBuildings.addUnique(build);
    });
}