let tilesize = Vars.tilesize;

let spawnerGroup = null;
let destoryBuildings = null;

let groundSpawneDrawRange = 0;
let flyerSpawnerDrawRange = 0;
let color = Team.crux.color;

function setSpawnerGroup(g){
    spawnerGroup = g;
}

function setDestoryBuildings(buildings){
    destoryBuildings = buildings;
}

function setRange(rangeGround, rangeFlayer, color2){
    groundSpawneDrawRange = rangeGround;
    flyerSpawnerDrawRange = rangeFlayer;
    color = color2;
}

module.exports = {
    setSpawnerGroup: setSpawnerGroup,
    setDestoryBuildings: setDestoryBuildings,
    setRange: setRange,
}

Events.run(Trigger.draw, () => {
    Draw.z(Layer.overlayUI);
    
    let {groundSpawnerGroup, flyerSpawnerGroup} = spawnerGroup;
    
    Draw.color(color);
   
    // groundSpawnerGroup.each(group => {
        // drawSpawnerRange(group.spawnerPos, groundSpawneDrawRange);
    // });
    
    flyerSpawnerGroup.each(group => {
        drawSpawnerRange(group.spawnerPos, flyerSpawnerDrawRange);
    });
    
    if(destoryBuildings.any()){
        drawDestoryBuildings();
    }
    
    Draw.reset();
});

function drawSpawnerRange(points, range){
    points.each(point => {
        Drawf.circles(point.x, point.y, range);
    });
}

function drawDestoryBuildings(){
    Draw.color(Color.white, 0.3);
    Draw.mixcol(Pal.remove, 0.4 + Mathf.absin(Time.globalTime, 6, 0.28));
    
    let bounds = Core.camera.bounds(Tmp.r1);
    destoryBuildings.each(build => {
        let {x, y} = build;
        
        if(!bounds.contains(x, y)){
            return;
        }
        
        let block = build.block;
        let size = block.size * tilesize;
        
        Fill.rect(x, y, size, size);
    });
}