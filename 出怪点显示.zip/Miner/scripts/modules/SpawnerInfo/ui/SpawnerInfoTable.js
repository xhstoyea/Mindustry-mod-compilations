let numImage = require("ui/NumImage");

let spawnGroupCounter = null;
let spawnerGroup = null;

let uiGroup = new WidgetGroup();

uiGroup.touchable = Touchable.childrenOnly;
uiGroup.setFillParent(true);

let worldCenter = new Vec2();
let length = Vars.tilesize * 4;

let wave = 0;

Events.on(ClientLoadEvent, () => {
    Vars.ui.hudGroup.addChild(uiGroup);
});

function setCounter(c){
    spawnGroupCounter = c;
}

function setSpawnerGroup(g){
    spawnerGroup = g;
}

const tmpSeq = new Seq();
function update(){
    clear();
    
    worldCenter.set(
        Vars.world.unitWidth() / 2,
        Vars.world.unitHeight() / 2
    );
    wave = Vars.state.wave - 1;
    
    let {groundSpawnerGroup, flyerSpawnerGroup} = spawnerGroup;
    setupGroupTables(groundSpawnerGroup);
    setupGroupTables(flyerSpawnerGroup);
}

function clear(){
    uiGroup.clear();
}

module.exports = {
    setCounter: setCounter,
    setSpawnerGroup: setSpawnerGroup,
    update: update,
    clear: clear,
}

function setupGroupTables(spawnerGroups){
    spawnerGroups.each(spawnerGroup => {
        let {spawnerPos, centroid} = spawnerGroup;
        
        let spawnGroups = getSpawnGroups(spawnerPos);
        let v1 = Tmp.v1.set(centroid.x, centroid.y);
        let v2 = Tmp.v2.set(v1).sub(worldCenter).setLength(length).add(v1).cpy();
        
        uiGroup.fill(null, container => {
            let table = extend(Table, null, table => {
                setupTable(table, spawnerPos, spawnGroups);
                
                table.update(() => {
                    let v3 = Core.input.mouseScreen(v2.x, v2.y);
                    table.setPosition(v3.x, v3.y, Align.top);
                });
            }, {
                draw(){
                    let v3 = Core.input.mouseScreen(v2.x, v2.y);
                    let startX = v3.x, startY = v3.y;
                    
                    Lines.stroke(3, Pal.accent);
                    
                    spawnerPos.each(point => {
                        let {x, y} = point;
                        
                        let pv = Core.input.mouseScreen(x, y);
                        
                        Lines.line(startX, startY, pv.x, pv.y);
                    });
                    
                    Draw.color();
                    
                    this.super$draw();
                },
            });
            
            container.add(table).minSize(64, 64);
        });
    });
}

function setupTable(table, spawnerPos, spawnGroups){
    table.touchable = Touchable.childrenOnly;
    
    table.table(Styles.black3, spawnerInfoTable => {
        setupSpawnerInfoTable(spawnerInfoTable, spawnerPos);
    }).growX().row();
    
    table.table(Styles.black3, counterTable => {
         let counter = countUnits(spawnGroups, wave);
         setupCounterTable(counterTable, counter);
    }).growX().row();
    
    table.pane(Styles.noBarPane, detailsTable => {        
        setupDetailsTable(detailsTable, spawnGroups);
    }).width(256).maxHeight(32 * 3.5).scrollX(false);
}

function setupSpawnerInfoTable(table, spawnerPos){
    table.touchable = Touchable.disabled;
    
    table.image(Blocks.spawn.uiIcon).size(32);
    table.add("x" + spawnerPos.size);
}

function setupCounterTable(table, counter){
    table.left();
    
    addInfo(null, "下一波", wave + 1);
    
    table.table(null, unitTable => {
        unitTable.left();
        
        unitTable.add("总单位").color(Pal.lightishGray).style(Styles.outlineLabel);
        
        unitTable.table(null, container => {
            let map = counter.units;
            
            if(map.isEmpty()){
                container.image(Icon.none).size(32);
                return;
            }
            
            let i = 0;
            Vars.content.units().each(unitType => {
                let count = map.get(unitType);
                
                if(count == 0){
                    return;
                }
                
                let image = numImage.create(unitType.uiIcon, count);
                container.add(image).size(32).padLeft(8);
                
                if(++i % 4 == 0){
                    container.row();
                }
            });
        }).padLeft(8);
    }).growX().row();
    
    addInfo(Icon.defense, "总血量", counter.totalHealth);
    addInfo(Icon.commandRally, "总护盾", counter.totalShield);
    
    function addInfo(icon, text, value){
        table.table(null, t => {
            t.left();
            
            if(icon != null){
                t.image(icon).size(32);
            }
            
            t.add(text).color(Pal.lightishGray).style(Styles.outlineLabel);
            t.add("" + value).color(Pal.accent).style(Styles.outlineLabel).padLeft(8);
        }).growX().row();
    }
}

function setupDetailsTable(table, spawnGroups){    
    table.touchable = Touchable.childrenOnly;

    spawnGroups.each(spawnGroup => {
        let spawnCount = spawnGroup.getSpawned(wave);
        
        if(spawnCount == 0){
            return;
        }
        
        let {type, items, payloads, effect} = spawnGroup;
        let shield = spawnGroup.getShield(wave);
                
        table.table(Styles.black3, groupTable => {
            let image = numImage.create(type.uiIcon, spawnCount);
            
            groupTable.add(image);
            groupTable.add(type.localizedName).growX().left().padLeft(8);
            
            groupTable.table(null, t => {
                t.defaults().growX().right();
                
                let i = 0;
                if(items != null){
                    let {item, amount} = items;
                    let image = numImage.create(item.uiIcon, amount);
                    t.add(image);
                    i++;
                }
                if(payloads != null){
                    payloads.each(payloadUnitType => {
                        t.image(payloadUnitType.uiIcon)
                            .size(32).padLeft(4);
                        
                        if(++i % 4 == 0){
                            t.row();
                        }
                    });
                }
                if(effect != null && effect != StatusEffects.none){
                    t.image(effect.uiIcon).size(32);
                    if(++i % 4 == 0){
                        t.row();
                    }
                }
            }).growX().right();
        }).growX().row();
    });
}

function getSpawnGroups(spawnerPos){
    tmpSeq.clear();
    
    spawnerPos.each(point => {
        let spawnWorldX = World.toTile(point.x), spawnWorldY = World.toTile(point.y);
        let position = Point2.pack(spawnWorldX, spawnWorldY);
        
        let spawnGroups = spawnGroupCounter.get(position);
        
        if(spawnGroups == null){
            return;
        }
        
        tmpSeq.addAll(spawnGroups);
    });
    
    return tmpSeq;
}

const unitCounter = {
    totalHealth: 0,
    totalShield: 0,
    units: new ObjectIntMap(),
    
    clear(){
        this.totalHealth = 0;
        this.totalShield = 0;
        this.units.clear();
    },
}
function countUnits(spawnGroups, wave){
    unitCounter.clear();
    
    spawnGroups.each(spawnGroup => {
        let spawnCount = spawnGroup.getSpawned(wave);
        
        if(spawnCount == 0){
            return;
        }
        
        let {type} = spawnGroup;
        let shield = spawnGroup.getShield(wave);
        
        unitCounter.totalHealth += type.health;
        unitCounter.totalShield += shield;
        unitCounter.units.increment(type, spawnCount);
    });
    
    return unitCounter;
}