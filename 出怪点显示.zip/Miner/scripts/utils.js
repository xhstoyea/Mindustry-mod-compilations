let floatArrayClass = java.lang.reflect.Array.newInstance(java.lang.Float.TYPE, 1).getClass();

function getMethod(clazz, name, parameterTypes){
    let method = clazz.getDeclaredMethod(name, parameterTypes);
    method.setAccessible(true);
    return method;
}

function pointSeqToFloatArray(points){
    let size = points.size;
    let length = size * 2;
    
    let array = java.lang.reflect.Array.newInstance(java.lang.Float.TYPE, length);
    
    for(let i = 0; i < size; i++){
        let point = points.get(i);
        
        array[i * 2] = point.x;
        array[i * 2 + 1] = point.y;
    }
    
    return array;
}

function isOnLine(points){
    if(points.size < 3){
        return true;
    }

    let point1 = points.get(0);
    let point2 = points.get(1);
    
    let x1 = point1.x, x2 = point2.x,
        y1 = point1.y, y2 = point2.y;
    
    let k = Math.abs((x1 - x2) / (y1 - y2));
        
    for(let i = 2, size = points.size; i < size; i++){
        let point = points.get(i);
        
        let px = point.x, py = point.y;
        
        let nk = Math.abs((px - x1) / (py - y1));
                
        if(nk != k){
            return false;
        }
    }
    
    return true;
}

function isSamePoint(points){
    let first = points.get(0);
    let fx = first.x, fy = first.y;
    
    for(let i = 1, size = points.size; i < size; i++){
        let point = points.get(i);
        let px = point.x, py = point.y;
        
        if(!(fx == px && fy == py)){
            return false;
        }
    }
    return true;
}

let sorter = new DelaunayTriangulator();
let sortPointsMethod = getMethod(
    DelaunayTriangulator.__javaObject__,
    "sort",
    [floatArrayClass, java.lang.Integer.TYPE]
);
function sortPoints(floatArray){
    sortPointsMethod.invoke(sorter, [floatArray, java.lang.Integer(floatArray.length)]);
}

module.exports = {
    getMethod: getMethod,
    pointSeqToFloatArray: pointSeqToFloatArray,
    isOnLine: isOnLine,
    isSamePoint: isSamePoint,
    sortPoints: sortPoints,
}