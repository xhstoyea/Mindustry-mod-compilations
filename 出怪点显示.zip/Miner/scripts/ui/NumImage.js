module.exports = {
    create(region, amount){
        let stack = new Stack();
        
        stack.add(new Table(null, i => {
            i.left();
            i.image(region).size(32).scaling(Scaling.fit);
        }));

        if(amount != 0){
            stack.add(new Table(null, t => {
                t.left().bottom();
                t.add((amount >= 1000 ? UI.formatAmount(amount) : amount) + "").style(Styles.outlineLabel);
                t.pack();
            }));
        }
        
        return stack;
    },
}