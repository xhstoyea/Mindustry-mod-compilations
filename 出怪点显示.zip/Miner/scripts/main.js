let mod = Vars.mods.getMod(modName);

mod.meta.author = "[yellow]miner";
mod.meta.description = 
"显示 [green]陆军 空军的[]出怪点!" + 
"\n v1.2: 优化性能" + 
"\nminer的mod群:757679470";

require("modules/SpawnerInfo/SpawnerInfo");