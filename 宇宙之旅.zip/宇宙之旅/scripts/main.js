require("混乱核心");
//阿巴阿巴