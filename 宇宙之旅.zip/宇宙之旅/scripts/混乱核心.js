const 混乱核心 = extend(CoreBlock, "混乱核心", {

     canBreak() {
         return Vars.state.teams.cores(Vars.player.team()).size > 1;
     },
     canReplace(other) {
         return other.alwaysReplace;
     },
     canPlaceOn(tile, team) {
         return true;
     },
 });
 exports.混乱核心 = 混乱核心;