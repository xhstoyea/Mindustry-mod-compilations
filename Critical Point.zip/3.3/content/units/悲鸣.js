"splashDamage":0,//溅射伤害
		"splashDamageRadius":-1,//溅射伤害范围:使用负值禁用飞溅伤害。8/格
		{
			"name": "悲鸣炮",
			"x": 0,
			"recoil": 8,
			"shake": 20,
			"shootY": 73,
			"reload": 480,
			"shootCone": 1,
			"mirror": false,
			"rotate": true,
			"rotateSpeed": 1,
			"layerOffset": 0.01,
			"cooldownTime": 660,
			"heatColor": "F03B0E",
			"shootSound": "聚爆",
			"bullet": {
				"damage": 4970,
				"lifetime": 33.6,
				"speed": 20,
				"shrinkY": 0,
				"width": 32,
				"height": 32,
				"trailLength": 12,
				"trailWidth": 6.4,
				"trailColor": "F9C27B",
				"absorbable": false,
				"reflectable": false,
				"status": "EMP",
				"statusDuration": 60,
				"splashDamage": 2730,
				"splashDamageRadius": 210,
				"buildingDamageMultiplier": 2.5,
				"shootEffect": {
					"type": "MultiEffect",
					"effects": [
						{
							"type": "ParticleEffect",
							"followParent": false,
							"particles": 12,
							"lifetime": 25,
							"line": true,
							"strokeFrom": 5,
							"lenFrom": 24,
							"lenTo": 0,
							"cone": 30,
							"length": 109,
							"colorFrom": "F9C27B",
							"colorTo": "F9C27A"
						},
						{
							"type": "WaveEffect",
							"lifetime": 10,
							"sizeFrom": 5,
							"sizeTo": 80,
							"strokeFrom": 3,
							"strokeTo": 0,
							"colorFrom": "F9C27B",
							"colorTo": "F9C27A"
						}
					]
				},
				"smokeEffect": {
					"type": "MultiEffect",
					"effects": [
						{
							"type": "ParticleEffect",
							"followParent": false,
							"particles": 23,
							"lifetime": 125,
							"sizeFrom": 8,
							"sizeTo": 0,
							"cone": 30,
							"length": 60,
							"interp": "pow10Out",
							"sizeInterp": "pow10In",
							"colorFrom": "727272",
							"colorTo": "727272"
						},
						"smokeCloud"
					]
				},
				"trailChance": 1,
				"trailEffect": {
					"type": "ParticleEffect",
					"region": "blank",
					"particles": 1,
					"lifetime": 55,
					"sizeFrom": 3,
					"sizeTo": 0,
					"cone": 360,
					"length": 43,
					"offset": 45,
					"sizeInterp": "pow5In",
					"colorFrom": "F9C27B",
					"colorTo": "F9C27A"
				},
				"hitShake": 20,
				"hitSound": "plasmaboom",
				"despawnEffect": "none",
				"hitEffect": {
					"type": "MultiEffect",
					"effects": [
						{
							"type": "ParticleEffect",
							"particles": 23,
							"lifetime": 145,
							"sizeFrom": 24,
							"sizeTo": 0,
							"cone": 360,
							"length": 135,
							"baseLength": 33,
							"interp": "pow10Out",
							"sizeInterp": "pow10In",
							"colorFrom": "F9C27A",
							"colorTo": "F9C27B"
						},
						{
							"type": "ParticleEffect",
							"particles": 19,
							"lifetime": 32,
							"line": true,
							"strokeFrom": 8,
							"lenFrom": 23,
							"lenTo": 0,
							"cone": 360,
							"length": 193,
							"baseLength": 47,
							"colorFrom": "F9C27B",
							"colorTo": "F9C27A"
						},
						{
							"type": "WaveEffect",
							"lifetime": 15,
							"sizeFrom": 20,
							"sizeTo": 240,
							"strokeFrom": 12,
							"strokeTo": 0,
							"colorFrom": "F9C27A",
							"colorTo": "F9C27B"
						}
					]
				},
				"parts": [
					{
						"type": "HaloPart",
						"tri": true,
						"shapes": 2,
						"radius": 6,
						"triLength": 64,
						"haloRadius": 64,
						"haloRotation": 90,
						"color": "F9C27A",
						"layer": 110
					},
					{
						"type": "HaloPart",
						"tri": true,
						"shapeRotation": 180,
						"shapes": 2,
						"radius": 6,
						"triLength": 16,
						"haloRadius": 64,
						"haloRotation": 90,
						"color": "F9C27A",
						"layer": 110
					},
					{
						"type": "ShapePart",
						"hollow": true,
						"sides": 4,
						"radius": 24,
						"stroke": 2,
						"color": "F9C27A",
						"layer": 110
					},
					{
						"type": "ShapePart",
						"hollow": true,
						"sides": 4,
						"radius": 42,
						"stroke": 2,
						"color": "F9C27A",
						"layer": 110
					}
				],
				"fragBullets": 4,
				"fragLifeMin": 0.2,
				"fragVelocityMin": 1,
				"fragBullet": {
					"type": "BulletType",
					"damage": 360,
					"lifetime": 40,
					"speed": 4,
					"splashDamage": 280,
					"splashDamageRadius": 80,
					"hitShake": 8,
					"hitSound": "棱镜",
					"hitEffect": {
						"type": "MultiEffect",
						"effects": [
							{
								"type": "ParticleEffect",
								"particles": 11,
								"lifetime": 121,
								"sizeFrom": 8,
								"sizeTo": 0,
								"cone": 360,
								"length": 56,
								"baseLength": 15,
								"interp": "pow10Out",
								"sizeInterp": "pow10In",
								"colorFrom": "F9C27A",
								"colorTo": "F9C27B"
							},
							{
								"type": "ParticleEffect",
								"particles": 19,
								"lifetime": 33,
								"line": true,
								"strokeFrom": 5,
								"lenFrom": 29,
								"lenTo": 0,
								"cone": 360,
								"length": 147,
								"baseLength": 33,
								"colorFrom": "F9C27A",
								"colorTo": "F9C27B"
							},
							{
								"type": "WaveEffect",
								"lifetime": 15,
								"sizeFrom": 5,
								"sizeTo": 180,
								"strokeFrom": 9,
								"strokeTo": 0,
								"colorFrom": "F9C27A",
								"colorTo": "F9C27B"
							}
						]
					},
					"despawnEffect": "none",
					"fragBullets": 3,
					"fragLifeMin": 0.2,
					"fragVelocityMin": 1,
					"fragBullet": {
						"type": "BulletType",
						"damage": 155,
						"lifetime": 30,
						"speed": 4,
						"hitShake": 4,
						"hitSound": "棱镜",
						"hitEffect": {
							"type": "MultiEffect",
							"effects": [
								{
									"type": "ParticleEffect",
									"particles": 5,
									"lifetime": 97,
									"sizeFrom": 6,
									"sizeTo": 0,
									"cone": 360,
									"length": 46,
									"baseLength": 5,
									"interp": "pow10Out",
									"sizeInterp": "pow10In",
									"colorFrom": "F9C27A",
									"colorTo": "F9C27B"
								},
								{
									"type": "ParticleEffect",
									"particles": 13,
									"lifetime": 33,
									"line": true,
									"strokeFrom": 4,
									"lenFrom": 23,
									"lenTo": 0,
									"cone": 360,
									"length": 100,
									"baseLength": 20,
									"colorFrom": "F9C27B",
									"colorTo": "F9C27A"
								},
								{
									"type": "WaveEffect",
									"lifetime": 15,
									"sizeFrom": 0,
									"sizeTo": 120,
									"strokeFrom": 6,
									"strokeTo": 0,
									"colorFrom": "F9C27A",
									"colorTo": "F9C27B"
								}
							]
						},
						"despawnEffect": "none",
						"splashDamage": 95,
						"splashDamageRadius": 40,
						"fragBullets": 7,
						"fragLifeMin": 0.2,
						"fragVelocityMin": 1,
						"fragBullet": {
							"type": "BulletType",
							"damage": 9,
							"lifetime": 20,
							"speed": 4,
							"splashDamage": 7,
							"splashDamageRadius": 20,
							"hitShake": 2,
							"hitEffect": {
								"type": "MultiEffect",
								"effects": [
									{
										"type": "ParticleEffect",
										"particles": 2,
										"lifetime": 73,
										"sizeFrom": 4,
										"sizeTo": 0,
										"cone": 360,
										"length": 26,
										"interp": "pow10Out",
										"sizeInterp": "pow10In",
										"colorFrom": "F9C27A",
										"colorTo": "F9C27B"
									},
									{
										"type": "ParticleEffect",
										"lifetime": 33,
										"particles": 8,
										"line": true,
										"strokeFrom": 3,
										"lenFrom": 17,
										"lenTo": 0,
										"cone": 360,
										"length": 47,
										"baseLength": 13,
										"colorFrom": "F9C27A",
										"colorTo": "F9C27B"
									},
									{
										"type": "WaveEffect",
										"lifetime": 15,
										"sizeFrom": 0,
										"sizeTo": 60,
										"strokeFrom": 3,
										"strokeTo": 0,
										"colorFrom": "F9C27A",
										"colorTo": "F9C27B"
									}
								]
							},
							"despawnEffect": "none"
						}
					}
				}
			},
			"parts": [
				{
					"type": "RegionPart",
					"progress": "recoil",
					"suffix": "-shot",
					"under": true,
					"moveY": -18.5,
					"children": [
						{
							"type": "RegionPart",
							"suffix": "-shot-glow",
							"outline": false,
							"color": "FF0000",
							"blending": "additive"
						}
					]
				},
				{
					"type": "RegionPart",
					"suffix": "-glow",
					"outline": false,
					"color": "FF0000",
					"blending": "additive"
				}
			]
		}
	],