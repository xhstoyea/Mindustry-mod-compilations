
function Shader(name) {
	let shaders = Vars.mods.locateMod("cp").root.child("shaders");
	let s = new Shaders.SurfaceShader(Shaders.getShaderFi("screenspace.vert").readString(), shaders.child(name + ".frag").readString());
	let m = new CacheLayer.ShaderLayer(s);
	CacheLayer.add(m);
	return m
}
function liquidf(name, shader) {
	let l = new Floor(name, 0);
	l.cacheLayer = Shader(shader);
	return exports[name] = l;
}

const 量子合金墙 = new StaticWall("量子合金墙");
exports.量子合金墙 = 量子合金墙;

const 量子充能合金墙 = new StaticWall("量子充能合金墙");
exports.量子充能合金墙 = 量子充能合金墙;

const 合金地 = new Floor("合金地");
exports.合金地 = 合金地;
Object.assign(合金地, {
	variants: 4,
})

const 暗合金地 = new Floor("暗合金地");
exports.暗合金地 = 暗合金地;
Object.assign(暗合金地, {
	variants: 3,
})

liquidf("量子液", "laz");
liquidf("失活液体", "killLiquds");

/*
function liquidf(name, shader) {
	let l = new Floor(name, 0);
	l.cacheLayer = Shader(shader);
	return exports[name] = l;
}
liquidf("量子液", "langzi");
*/
/*
const 以太结晶 = new Floor("以太结晶");
exports.以太结晶 = 以太结晶;
Object.assign(以太结晶, {
	variants: 3,
	itemDrop: items.以太结晶,
})
*/