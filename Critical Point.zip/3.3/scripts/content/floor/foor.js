//const items = require("CPitems");

const 蓝绒草墙 = new StaticWall("蓝绒草墙");
exports.蓝绒草墙 = 蓝绒草墙;

const 蓝绒草 = new Floor("蓝绒草");
exports.蓝绒草 = 蓝绒草;
Object.assign(蓝绒草, {
	variants: 3,
})

const 墨绿草墙 = new StaticWall("墨绿草墙");
exports.墨绿草墙 = 墨绿草墙;

const 墨绿草 = new Floor("墨绿草");
exports.墨绿草 = 墨绿草;
Object.assign(墨绿草, {
	variants: 3,
})
