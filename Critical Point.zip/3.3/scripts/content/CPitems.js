/*本模组所有的物品都在这里，可以直接作为模板QAQ
详细注释看下面a*/

//来自蔚蓝行星
//物品总，液体总
function newItem(name, color, obj) {
	Object.assign(exports[name] = new Item(name,
		Color.valueOf(color)), obj);
}
function newLiquid(name, color, obj) {
	Object.assign(exports[name] = new Liquid(name,
		Color.valueOf(color)), obj);
}

newItem("重质碳钢", "808080FF", {
	cost: 1,
})

newItem("以太结晶", "A45AFFFF", {
	cost: 1.35,
	hardness: 3, //硬度
})

newItem("芯片", "F9D572FF", {
	cost: 2.5,
	charge: 0.5, //放电性
})

newItem("量子芯片", "525682FF", {
	cost: 2,
	charge: 1.5, //放电性
})

newItem("超频芯片", "B86E6EFF", {
	cost: 2,
	charge: 1.5, //放电性
})


newItem("铱钢", "D0E6FFFF", {
	cost: 2,

})

newItem("暗物质", "202124FF", {
	cost: 6,
	radioactivity: 0.3, //放射性
	charge: 0.5, //放电性

})

//注释在这里a
newItem("矢量合金", "F6BB64FF", { //物品详细信息
	hardness: 0, //硬度，只有矿物有，与挖掘速度、挖掘等级有关
	radioactivity: 0, //放射性
	explosiveness: 1, //爆炸性
	flammability: 0, //燃烧性
	charge: 1.5, //放电性
	cost: 1.5, //建筑时间消耗倍率
	frames: 10,//动态贴图帧数
})