const lib = require("base/NCPlib");
const FX = require("base/fightFx");

let minDamage = Stat("minDamage");
let percentDamage = Stat("percentDamage");
let minHealth = Stat("minHealth");
let percentHealth = Stat("percentHealth");
let minShieldDamage = Stat("minShieldDamage");
let percentShieldDamage = Stat("percentShieldDamage");
let reduceArmor = Stat("reduceArmor");
let reduceMaxHealth = Stat("reduceMaxHealth");
let killHealth = Stat("killHealth");
let chainDamage = Stat("chainDamage");


function newStatus(name, cons) {
	return exports[name] = extend(StatusEffect, name, cons || {});
}
/*

newStatus("EMP", {
	update(unit, time) {
		this.super$update(unit, time);
		if (unit.shield > 0) {
			let damage = Math.max(unit.type.health / 500, unit.shield / 100);
			unit.damageContinuousPierce(damage / 60);
		}
		//unit.abilities.remove();
		//if (time <= 3) unit.abilities = unit.type.abilities;
	},
	setStats() {
		this.super$setStats();
		this.stats.add(percentShieldDamage, lib.bundle("percentShieldDamage", 300));
		this.stats.add(minShieldDamage, lib.bundle("minShieldDamage", 80));
	}
});stat
*/

//const EMP = extend(status, "EMP", {});
//exports.EMP = EMP;