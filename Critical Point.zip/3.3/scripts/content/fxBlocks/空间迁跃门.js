const lib = require("base/NCPlib");
const NX = require("base/normalFx");
const {帝俊} = require("units");

const nuck = extend(UnitCargoLoader, "空间迁跃门", {
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.cores(team).size >= 10 && Vars.state.teams.get(team).getCount(this) < 10;
	},
	drawPlace(x, y, rotation, valid) {
		this.super$drawPlace(x, y, rotation, valid);
		if (Vars.state.teams.cores(Vars.player.team()).size < 10) {
			this.drawPlaceText(lib.bundle("text-maxBuild", 10), x, y, valid);
		} else if (Vars.state.teams.get(Vars.player.team()).getCount(this) >= 10) {
			this.drawPlaceText(lib.limitBuild(this, 10), x, y, valid);
		}
	}
});
nuck.size = 13;
//set fx 
lib.setBuilding(UnitCargoLoader.UnitTransportSourceBuild, nuck, {
	spawned(id) {
		this.super$spawned(id);
		NX.JumpIn(this, 帝俊).at(this);
	},
	draw() {
		this.super$draw();
		if (this.unit == null) {
			if (this.buildProgress == 0) return
			NX.DoubleAim(this, this.buildProgress, 帝俊.hitSize * 3, 1, 14, nuck.size);
		} else {
			NX.CenterTri(this, nuck.size * 4, 0.5, 4);
		}
		//NX.QuadrupleTri(this, 5, 7, 5);
	}
})