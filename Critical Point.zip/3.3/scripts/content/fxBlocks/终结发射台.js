const lib = require("base/NCPlib");
const NX = require("base/normalFx");
const FX = require('base/fightFx')
let FF5845 = lib.FF5845, F03B0E = lib.Color("F03B0E");

const t2LaunchPad = extend(LaunchPad, "终结发射台", {
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.cores(team).size >= 1 && Vars.state.teams.get(team).getCount(this) < 50;
	},
	drawPlace(x, y, rotation, valid) {
		this.super$drawPlace(x, y, rotation, valid);
		if (Vars.state.teams.cores(Vars.player.team()).size < 50) {
			this.drawPlaceText(lib.bundle("text-maxBuild", 50), x, y, valid);
		} else if (Vars.state.teams.get(Vars.player.team()).getCount(this) >= 50) {
			this.drawPlaceText(lib.limitBuild(this, 50), x, y, valid);
		}
	}
	
});
//代码可以抄
lib.setBuilding(LaunchPad.LaunchPadBuild, t2LaunchPad, {
	draw() {
		this.super$draw();
		if (this.power == 0) {
		   if(this.launchTime == 0) return
			//NX.CenterTri(this, t2LaunchPad.size * 4, 0.5, 4);
		      }
		 else {
			NX.CenterTri(this, t2LaunchPad.size * 4, 0.5, 4);
		}
		//NX.QuadrupleTri(this, 3, 7, 3);
	}
})

//lib
/*
exports.setBuilding = (building, block, con) => {
	block.buildType = prov(() => {
		if (building == Building) {
			return extend(building, con);
		} else {
			return extend(building, block, con);
		}
	})
}
*/

/*
lib.setBuilding(UnitCargoLoader.UnitTransportSourceBuild, t2LaunchPad, {
	spawned(id) {
		this.super$spawned(id);
		NX.JumpIn(this, 帝俊).at(this);
	},
	draw() {
		this.super$draw();
		if (this.unit == null) {
			if (this.buildProgress == 0) return
			NX.DoubleAim(this, this.buildProgress, 帝俊.hitSize * 3, 1, 14, t2LaunchPad.size);
		} else {
			NX.CenterTri(this, t2LaunchPad.size * 4, 0.5, 4);
		}
		//NX.QuadrupleTri(this, 5, 7, 5);
	}
})
*/