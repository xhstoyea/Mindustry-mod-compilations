const library = require("base/library");
const 轻型冲压机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "轻型冲压机", [
	{
		input: {
			items: ["copper/2"],
			power: 1,
		},
		output: {
			items: ["lead/1"],
		},
		craftTime: 60,
	},
		
]);

/*

items: [
			"cp-碳酸硅/2",
			"cp-简易芯片/1"
			],
			
*/