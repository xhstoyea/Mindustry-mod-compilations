const cpitem = require('content/CPitems');

const T2PC = extend(GenericCrafter, "T2-PC", {});

T2PC.hasItems = true;
T2PC.liquidCapacity = 90;
T2PC.itemCapacity = 50;
T2PC.craftTime = 90;
T2PC.outputItem = new ItemStack(Items.plastanium, 10);
T2PC.size = 3;
T2PC.health = 820;
T2PC.hasPower = true;
T2PC.hasLiquids = true;
T2PC.craftEffect = Fx.formsmoke;
T2PC.updateEffect = Fx.plasticburn;
T2PC.drawer = new DrawMulti(new DrawRegion("-bottom"), new DrawDefault(), /*new DrawLiquidRegion(),*/ new DrawFrames(), new DrawFade());

T2PC.consumeLiquid(Liquids.oil, 0.5);
T2PC.consumePower(8.5);
T2PC.consumeItem(Items.titanium, 8);
T2PC.requirements = ItemStack.with(
    Items.silicon, 105,
    Items.lead, 155,
    Items.graphite, 60,
    Items.plastanium, 50
);
T2PC.buildVisibility = BuildVisibility.shown;
T2PC.category = Category.crafting;

exports.T2PC = T2PC;



const T2KL = extend(GenericCrafter, "T2-KL", {});
T2KL.hasItems = true;
T2KL.liquidCapacity = 90;
T2KL.itemCapacity = 60;
T2KL.craftTime = 120;
T2KL.outputItem = new ItemStack(Items.metaglass, 6);
T2KL.size = 3;
T2KL.health = 820;
T2KL.hasPower = true;
T2KL.hasLiquids = true;
T2KL.craftEffect = Fx.formsmoke;
//T2KL.updateEffect = Fx.plasticburn;
T2KL.drawer = new DrawMulti(new DrawRegion("-bottom"), new DrawDefault(), new DrawFade(), new DrawFrames());

T2KL.consumePower(5.5);
T2KL.consumeItems(ItemStack.with(
Items.sand, 5,
Items.lead, 5
));
T2KL.requirements = ItemStack.with(
    Items.silicon, 105,
    Items.lead, 155,
    Items.graphite, 60,
    Items.plastanium, 50
);
T2KL.buildVisibility = BuildVisibility.shown;
T2KL.category = Category.crafting;

exports.T2KL = T2KL;