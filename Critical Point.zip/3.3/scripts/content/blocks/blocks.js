const cpitem = require('content/CPitems');

const 铱钢传送带 = new Conveyor("铱钢传送带");
exports.铱钢传送带 = 铱钢传送带;
铱钢传送带.researchCostMultiplier = 0.5;
Object.assign(铱钢传送带, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
	//Items是原版
	//cpitem是mod物品
		cpitem.铱钢, 2,
		cpitem.重质碳钢, 2
	),
	health: 70,
	speed: 0.13,
	displayedSpeed: 16,
});


const 铱钢传送桥 = new ItemBridge("铱钢传送桥");
exports.铱钢传送桥 = 铱钢传送桥;
铱钢传送桥.consumePower(1.2);
铱钢传送桥.itemCapacity = 20;
Object.assign(铱钢传送桥, {
	requirements: ItemStack.with(
		Items.graphite, 10,
		Items.silicon, 10,
		cpitem.铱钢, 5
	),
	health: 80,
	fadeIn: false,
	moveArrows: false,
	range: 15,
	//arrowSpacing: 2,
	hasPower:true,
    hasItems:true,
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
})
/*
const 溢流阀 = new OverflowGate("溢流阀");
exports.溢流阀 = 溢流阀;
Object.assign(溢流阀, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		Items.graphite, 5,
		item.钴, 5
	),
	health: 40,
})

const 反向溢流阀 = new OverflowGate("反向溢流阀");
exports.反向溢流阀 = 反向溢流阀;
Object.assign(反向溢流阀, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		Items.graphite, 5,
		item.钴, 5
	),
	invert: true,
	health: 40,
})
*/
//i don't know where From

const 光束钻头 = extend(Drill, "光束钻头", {});
光束钻头.requirements = ItemStack.with(
    Items.copper, 20,
    Items.graphite, 18,
    Items.titanium, 15,
);
光束钻头.buildVisibility = BuildVisibility.shown;
光束钻头.category = Category.production;
光束钻头.consumePower(3.56);
光束钻头.itemCapacity = 80;
光束钻头.drillTime = 160;
光束钻头.size = 4;
光束钻头.tier = 8;
光束钻头.consumeLiquid(Liquids.water, 0.06).boost();
exports.光束钻头 = 光束钻头;
/*
const 散射节点 = new PowerNode("散射节点");
exports.散射节点 = 散射节点;
Object.assign(散射节点, {
	size: 3,
	maxNodes: 20,
	laserRange: 35,
	health: 100,
	category: Category.power,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
        cpitem.重质碳钢, 5,
        Items.sillicon, 10,
	)
})

//电池
const 电容器 = new Battery("电容器");
exports.电容器 = 电容器;
Object.assign(电容器, {
	baseExplosiveness: 1,
	category: Category.power,
	buildVisibility: BuildVisibility.shown,
	requirements: ItemStack.with(
		//item.钴, 5,
		Items.silicon, 10,
	)
});
电容器.consumePowerBuffered(5000)
*/

const 以太反应堆 = extend(ConsumeGenerator, "以太反应堆", {});
以太反应堆.drawer = new DrawMulti(new DrawRegion("-bottom"), new DrawLiquidRegion(), new DrawDefault());
exports.以太反应堆 = 以太反应堆;


