const lib = require("base/NCPlib");
const NX = require("base/normalFx");
const FX = require('base/fightFx')

const qymt1 = extend(UnitFactory, "迁跃门", {});//引用他
lib.setBuilding(UnitFactory.UnitFactoryBuild, qymt1, {
    draw() {
        this.super$draw();
        if (this.unit == null) {
            if (this.buildProgress == 0) return;
            NX.CenterTri(this, qym1.size * 4, 0.5, 4);
        } else {
            // 此处不需要再判断 working 是否为 null
            if (this.buildProgress > 0) {
                NX.DoubleAim(this, this.buildProgress, this.Size * 3, 1, 14, qym1.size);
            }
            NX.QuadrupleTri(this, 4, 32, 4);
        }
    }
})
/*
	draw() {
		this.super$draw();
		if (this.unit == null) {
			if (this.buildProgress == 0) return
			NX.DoubleAim(this, this.buildProgress, 帝俊.hitSize * 3, 1, 14, qym1.size);
		} else {
			NX.CenterTri(this, qym1.size * 4, 0.5, 4);
		}
		//NX.QuadrupleTri(this, 5, 7, 5);
	}
	*/
	
	
