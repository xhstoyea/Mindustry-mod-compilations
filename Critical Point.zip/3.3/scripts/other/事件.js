Events.on(PickupEvent, e => {
    if (e.build == null) return; // 防止拾起的荷载不为方块后游戏崩溃
    if (e.build.block.size == 1) {
        Vars.ui.hudfrag.showToast("你已捡起此方块：" + e.build.block.name);
    }
});
/*
Events.on(PickupEvent, e => {
    if (e.build == null) return; // 防止拾起的荷载不为方块后游戏崩溃
    if (e.build.block.size == 2) {
        Vars.ui.hudfrag.showToast("你已捡起此方块：" + e.build.block.name);
    }
});
*/
Events.on(PickupEvent, e => {
    if (e.build == null) return; // 防止拾起的荷载不为方块后游戏崩溃
    if (e.build.block.size == 3) {
        Vars.ui.hudfrag.showToast("你已捡起此方块：" + e.build.block.name);
    }
});
Events.on(PickupEvent, e => {
    if (e.build == null) return; // 防止拾起的荷载不为方块后游戏崩溃
    if (e.build.block.size == 4) {
        Vars.ui.hudfrag.showToast("你已捡起此方块：" + e.build.block.name);
    }
});
Events.on(PickupEvent, e => {
    if (e.build == null) return; // 防止拾起的荷载不为方块后游戏崩溃
    if (e.build.block.size == 5) {
        Vars.ui.hudfrag.showToast("你已捡起此方块：" + e.build.block.name);
    }
});
Events.on(PickupEvent, e => {
    if (e.build == null) return; // 防止拾起的荷载不为方块后游戏崩溃
    if (e.build.block.size == 6) {
        Vars.ui.hudfrag.showToast("你已捡起此方块：" + e.build.block.name);
    }
});



Events.on(PickupEvent, e => {
    if (e.build == null) return; // 防止拾起的荷载不为方块后游戏崩溃
    if (e.build.block.size == 2) {
//--------------------------------------------
//Raid Event|空袭事件
const event = extend(RaidEventClass, "custom-raid-event", {});
event.bulletType = Bullets.artilleryExplosive; //BulletType Reference|子弹可引用自类: NHBullets, Bullets
event.number = 100; //Shots|发射数
event.shootDelay = 3; //Spacing between shots|每次发生间隔 [Unit:tick]|[单位:帧]
event.inaccuracy = 3; //散布/角度
event.sourceSpread = 200; //The spread range of shoot positions|射击源的散布范围
event.reloadTime = 60 * 60; //Interval between alert and raid|每次从警报到袭击的间隔 [Unit:tick]|[单位:帧]
handleEvent(event);
//Copy Above as the constructor|复制以上代码作为构造器
   }
});
/*

    Bullets.
        //artillery
        artilleryDense, artilleryPlastic, artilleryPlasticFrag, artilleryHoming, artilleryIncendiary, artilleryExplosive,

        //flak
        flakScrap, flakLead, flakGlass, flakGlassFrag,

        //frag (flak-like but hits ground)
        fragGlass, fragExplosive, fragPlastic, fragSurge, fragGlassFrag, fragPlasticFrag,

        //missiles
        missileExplosive, missileIncendiary, missileSurge,

        //standard
        standardCopper, standardDense, standardThorium, standardHoming, standardIncendiary,
        standardDenseBig, standardThoriumBig, standardIncendiaryBig,

        //liquid
        waterShot, cryoShot, slagShot, oilShot, heavyWaterShot, heavyCryoShot, heavySlagShot, heavyOilShot,

        //environment, misc.
        damageLightning, damageLightningGround, fireball, basicFlame, pyraFlame;
*/