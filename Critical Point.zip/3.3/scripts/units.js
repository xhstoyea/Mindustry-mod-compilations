const lib = require("base/NCPlib");
const FX = require("base/fightFx");
const ability = require("base/ability");

function newUnit(name, unitType, cons, cons2) {
	const u = extend(UnitType, name, cons || {});
	u.constructor = () => extend(unitType, cons2 || {});
	return exports[name] = u;
}
exports.newUnit = newUnit;
function newUnitList(name, unitType, num) {
	for (let i = 1; i <= num; i++) newUnit(name + i, unitType);
}

newUnit("帝俊", UnitEntity, {
	draw(unit) {
		this.super$draw(unit);
		FX.PlayerAim(unit, lib.FF5845);
	}
});
