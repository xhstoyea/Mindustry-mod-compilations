const SFlib = require("base/NCPlib");
const DX = require('content/floor/environment')
const AYSD = new Planet("厄亚瑟德", Planets.sun, 1, 3.3);
AYSD.meshLoader = prov(() => new MultiMesh(
	new HexMesh(AYSD, 8)
));

AYSD.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(AYSD, 2, 0.15, 0.14, 5, Color.valueOf("FF4F43FF80"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(AYSD, 3, 0.6, 0.15, 5, Color.valueOf("FF4F43FF"), 2, 0.42, 1.2, 0.45)
));
exports.AYSD = AYSD;


AYSD.generator = extend(SerpuloPlanetGenerator, {
/*
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nA3JMQ6AIBAAwQXFRr9iYXyOscDzChIEA/J/yZSDww2MyT+K3XbmW6uU8H4hJ2CK/tJYscdpWCQXXVOTqK32NGA7fg6sDuI=")
	};
	*/
	arr: [Blocks.basalt, DX.量子合金墙, DX.量子充能合金墙, DX.合金地, DX.暗合金地, /*DX.curseFloor,*/ /*DX.blood,*/ DX.量子液],
	genTile(position, tile) {
		let block = this.getBlock(position);
		tile.floor = block;
		if (this.vec.y < 0.5 || this.vec.y > 0.6 || this.vec.z > 0.7 || this.vec.z < 0.3) {
			tile.block = tile.floor.asFloor().wall
		}
	},
	getColor(position) {
		return Tmp.c1.set(this.getBlock(position).mapColor);
	},
	getSizeScl() {
		return 7200
	},
	getBlock(position) {
		const noise = (amount, a, b, c) => {
			return Simplex.noise3d(this.seed + amount, a, b, c, position.x, position.y, position.z);
		};
		this.vec = new Vec3(noise(1, 16, 0.2, 8 / 3), noise(6, 72, 0.8, 9 / 2), noise(3, 2, 0.4, 3 / 2));
		let amo = Mathf.round(Mathf.clamp(this.vec.x * this.arr.length, 0, this.arr.length - 1));
		return this.arr[amo]
	},
	vec: 0
});


AYSD.generator = new SerpuloPlanetGenerator();
AYSD.visible = AYSD.accessible = AYSD.alwaysUnlocked = true;
AYSD.clearSectorOnLose = false;
AYSD.tidalLock = false;
AYSD.localizedName = "厄亚瑟德";
AYSD.prebuildBase = false;
AYSD.bloom = false;
AYSD.startSector = 1;
AYSD.orbitRadius = 85;
AYSD.orbitTime = 180 * 60;
AYSD.rotateTime = 90 * 60;
AYSD.atmosphereRadIn = 0.02;
AYSD.atmosphereRadOut = 0.3;
AYSD.atmosphereColor = AYSD.lightColor = Color.valueOf("FF4F43FF90");
AYSD.iconColor = Color.valueOf("FF4F43FF"),
AYSD.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);
