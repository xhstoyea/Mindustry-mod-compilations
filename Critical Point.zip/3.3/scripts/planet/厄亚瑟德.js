
const lib = require("base/NCPlib");
const DX = require("content/floor/environment");
const AYSD = new Planet("厄亚瑟德", Planets.sun, 1, 4);
AYSD.meshLoader = prov(() => new HexMesh(AYSD, 6));
AYSD.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(AYSD, 2, 0.15, 0.14, 5, lib.Color("B5AAFFFF"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(AYSD, 3, 0.6, 0.15, 5, lib.Color("9283EDFF"), 2, 0.42, 1.2, 0.45)
));
exports.AYSD = AYSD;

AYSD.generator = extend(SerpuloPlanetGenerator, {

	arr: [Blocks.basalt, DX.量子合金墙, DX.量子充能合金墙, DX.合金地, DX.暗合金地, /*DX.curseFloor,*/ DX.量子液, DX.失活液体],
	genTile(position, tile) {
		let block = this.getBlock(position);
		tile.floor = block;
		if (this.vec.y < 0.5 || this.vec.y > 0.6 || this.vec.z > 0.7 || this.vec.z < 0.3) {
			tile.block = tile.floor.asFloor().wall
		}
	},
	getColor(position) {
		return Tmp.c1.set(this.getBlock(position).mapColor);
	},
	getSizeScl() {
		return 7200
	},
	getBlock(position) {
		const noise = (amount, a, b, c) => {
			return Simplex.noise3d(this.seed + amount, a, b, c, position.x, position.y, position.z);
		};
		this.vec = new Vec3(noise(1, 16, 0.2, 8 / 3), noise(6, 72, 0.8, 9 / 2), noise(3, 2, 0.4, 3 / 2));
		let amo = Mathf.round(Mathf.clamp(this.vec.x * this.arr.length, 0, this.arr.length - 1));
		return this.arr[amo]
	},
	vec: 0
});

AYSD.visible = AYSD.accessible = AYSD.alwaysUnlocked = AYSD.allowLaunchLoadout = true; //可见 在行星菜单内显示 总是解锁 可携带初始物资
AYSD.clearSectorOnLose = false; //重置战败区块
AYSD.bloom = true; //启用Bloom渲染效果
AYSD.startSector = 0; //初始区块
AYSD.orbitRadius = 36; //公转半径
AYSD.orbitTime = 180 * 60; //公转一圈时间
AYSD.rotateTime = 60 * 45; //自转一圈时间
AYSD.lightSrcFrom = 0;
AYSD.lightSrcTo = 0.04; //0.1
AYSD.lightDstFrom = 0.01; //0.05
AYSD.lightDstTo = 0.05; //0.15
AYSD.prebuildBase = false; //落地建造
AYSD.launchCapacityMultiplier = 0.5;
AYSD.defaultCore = Blocks.coreNucleus;
AYSD.atmosphereRadIn = 0.03; //进入大气层距离
AYSD.atmosphereRadOut = 0.45; //离开大气层距离
AYSD.atmosphereColor = AYSD.lightColor = AYSD.iconColor = lib.Color("9283EDFF"); //大气层 发光颜色
AYSD.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);

const map1 = new SectorPreset("a1", AYSD, 0);
map1.difficulty = 3;
map1.addStartingItems = true;
exports.map1 = map1;