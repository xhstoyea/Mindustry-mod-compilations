const lib = require('base/NCPlib')

var startColor = Color.valueOf("C4FBFFFF"); //初始颜色
var shiftValue = 60; //颜色跨度，360度为一次轮回
var mod = Vars.mods.locateMod("cp");//这里的换成你的mod.(h)json里面写的name
var st = mod.meta.displayName;
var fin = new java.lang.StringBuilder();
for(var i = 0; i < st.length; i++){
  var s = java.lang.String.valueOf(st.charAt(i));
  var c = startColor.shiftHue(i * (shiftValue/st.length));
  var ci = c.rgb888();
  var ct = java.lang.Integer.toHexString(ci);
  var fct = "[" + "#" + ct + "]";
  fin.append(fct).append(s);
}

mod.meta.displayName = fin.toString();

//❤来自EU❤


require('content/blocks/MultiCrafter')
require('other/事件')
require('bh')
require('content/blocks/sblocks')
require('content/fxBlocks/终结发射台')
require('yh')
require('content/fxBlocks/空间迁跃门')
require('planet/厄亚瑟德');
require('lk');
require("other/资源显示");
require("other/作弊菜单A");
//require("other/作弊菜单B");
require('other/supercamera');
require('content/CPitems');
require('content/blocks/临界反应驻存仪');
require('content/blocks/blocks')
require('content/floor/environment')








//根据游戏设置的语言改模组介绍和名字
lib.mod.meta.displayName = lib.getMessage('mod', 'displayName');
lib.mod.meta.description = lib.getMessage('mod', 'description');