let bilibili = "https://b23.tv/728mI9X"
let githud = "https://github.com/nodada/CT-origin/releases/tag/NO"
let myQQ = "http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=WOq1nS9tN2rMGVUVIZy7CpkypoXzVGpu&authKey=AzDYAr0RDF62lORA%2B%2FiRucrLDRE3avEP%2BqimlUMzMx1TAzrb3qu49eVFPGoY7E%2BF&noverify=0&group_code=665884639";//let三条为总链接 以下为配置文件的代称
//ch的更改
//其他的该ch为其他的语言
Events.on(EventType.ClientLoadEvent, cons(e => {
    var kaiping = new BaseDialog(Core.bundle.format("http00"));//title最上面的
    kaiping.cont.pane((() => {
    
        var table = new Table();        
        table.image(Core.atlas.find("cp-texto")).row();
		    // dialog2.cont.image(Core.atlas.find("cp-聚恒-p")).row();;
        
            table.add(Core.bundle.format("http000")).growX().wrap().width(700).maxWidth(700).pad(4).labelAlign(Align.left);//配置几？（自己看
        table.row();
/*
table.button(Core.bundle.format("githud"), run(() => {
    if (!Core.app.openURI(githud)) {
        Vars.ui.showErrorMessage("@linkfail");
        Core.app.setClipboardText(githud);//配置
    }
})).size(620, 67).row();

table.button(Core.bundle.format("bilibili"), run(() => {
    if (!Core.app.openURI(bilibi)) {
        Vars.ui.showErrorMessage("@linkfail");//配置
        Core.app.setClipboardText(bilibili);//配置文件的文字
    }
})).size(620, 67);
table.row();
*/
table.button(Core.bundle.format("myQQ"), run(() => {
    if (!Core.app.openURI(myQQ)) {
        Vars.ui.showErrorMessage("@linkfail");
        Core.app.setClipboardText(myQQ);
    }
})).size(620, 67).row();//这里接入
/*
table.row();
table.button(Core.bundle.format("http111"), run(() => {
    if (!Core.app.openURI(https111)) {
        Vars.ui.showErrorMessage("@linkfail");
        Core.app.setClipboardText(https111);
    }
})).size(620, 67).row();
//模板 如果要改名则在配置文件里添加
*/
    table.button('背景故事', Icon.infoCircle, run(() => {
    var dialog = new BaseDialog("UNKNOW");
    dialog.cont.pane(t => {
        t.add("-未知-")
    });
    dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
    dialog.show();
})).size(620, 64);
        table.row();
        
        
            table.button('更新', Icon.infoCircle, run(() => {
    var dialog2 = new BaseDialog("MOD NEWS");
    dialog2.cont.pane(t => {
        t.add("[red]新的炮台!\n[white]▲[blue]聚恒[white]▲\n把少量的原弹药改为多的子弹\n但我要知道[red]精准度很低[white]但是对付简易前线还是绰绰有余的")
    });
    //WFK 
     dialog2.cont.image(Core.atlas.find("cp-聚恒-p")).row();;
   //FUCK ME BOR  
    
   
       dialog2.cont.pane(t => {
        t.add("[red]新的物品!\n[white]▲[purple]以太结晶[white]▲\n[white]圣人把以太认为是第五元素，在[red]UNKNOW[white]上它起初\n带有一种神秘色彩")
    });
    //WFK 
     dialog2.cont.image(Core.atlas.find("cp-以太结晶")).height(64).width(64).row();;
   //FUCK ME BOR
    dialog2.buttons.button("@close", ()=>{dialog2.hide()}).size(400, 64);;
    dialog2.show();
})).size(620, 64);
        table.row();


        
   //                 table.add(Core.bundle.format("http001")).left().growX().wrap().width(700).maxWidth(700).pad(4).labelAlign(Align.left);//配置几？（自己看
    //    table.row();

return table;
})()).grow().center().maxWidth(1800).maxHeight(1800)
kaiping.addCloseListener();//按esc关闭
kaiping.buttons.button("@close", run(() => {
    kaiping.hide();
})).size(114514, 64);
kaiping.show();
}));
