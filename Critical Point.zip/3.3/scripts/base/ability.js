const lib = require("base/NCPlib");

exports.PurificationAbility = (reload) => { //清除状态
	let timer = new Interval();
	if (!reload) reload = 600;
	return extend(Ability, {
		localized() {
			return lib.bundle("PurificationAbility", reload / 60);
		},
		update(unit) {
			if (timer.get(reload)) unit.clearStatuses();
		}
	})
};

exports.ShieldAbility = (amount, max, tier, size, color) => { //持续护盾
	return extend(Ability, {
		localized() {
			return lib.bundle("ShieldAbility", amount, max);
		},
		update(unit) {
			if (unit.shield < max) unit.shield += amount / 60;
		},
		draw(unit) {
			Draw.color(color);
			Draw.z(Layer.shields);
			for (let i = 1; i <= tier; i++) {
				for (let j = 0; j < 360; j += 360 / (i * 6)) {
					let xy = lib.AngleTrns(j + 30, size * i * 2 - (j % 60 != 0 ? size / 2.1547 * i : size / 2 / 2.1547 * i));
					let ex = xy.x + unit.x, ey = xy.y + unit.y;
					Fill.poly(ex, ey, 6, size * Mathf.absin(-Time.time / 2 + i * 10, 8, 0.8 * unit.shield / max));
				}
			}
		}
	})
};

exports.SwapHealthAbility = (percent, reload) => { //交换生命值
	let all = new Seq(), timer = new Interval();
	if (!reload) reload = 3600;
	if (!percent) percent = 0.05;
	return extend(Ability, {
		localized() {
			return lib.bundle("SwapHealthAbility", reload / 60, percent * 100);
		},
		update(unit) {
			if (!timer.get(reload) || unit.healthf() >= percent) return
			all.clear();
			Units.nearby(null, unit.x, unit.y, unit.type.range, u => {
				if (u.team != unit.team) all.add(u);
			});
			all.sort(floatf(e => 1 - e.healthf()));
			if (all.size > 0) {
				let other = all.get(0);
				FX.chainLightningFade.at(unit.x, unit.y, 0, Pal.heal, other);
				let ohpf = other.healthf();
				other.health = unit.healthf() * other.maxHealth;
				unit.health = ohpf * unit.maxHealth;
			}
		},
		displayBars(unit, bars) {
			bars.add(new Bar("换血冷却", Pal.accent, new Floatp(() => i / reload))).row();
		}
	})
};

exports.StatusAbility = (status, range, time, ground, air) => { //敌方状态场
	let i = 0;
	return extend(Ability, {
		localized() {
			return status.localizedName + lib.bundle("StatusAbility");
		},
		update(unit) {
			Damage.status(unit.team, unit.x, unit.y, range, status, time, ground || true, air || true);
		},
		copy() {
			return exports.StatusAbility(status, range, time, ground, air);
		}
	})
};

exports.HealthRequireAbility = (percent, status, status2) => { //状态切换
	return extend(Ability, {
		localized() {
			return lib.bundle("HealthRequireAbility", percent * 100);
		},
		update(unit) {
			if (unit.healthf() >= percent) unit.apply(status, 60);
			else if (status2) unit.apply(status2, 60);
		},
		copy() {
			return exports.HealthRequireAbility(percent, status, status2);
		}
	})
};

function Rotator(name, x, y, s, speed, rot) {
	Draw.rect(name, x, y, s, s, speed);
	//Draw.rect(name + "-glow", x, y, -speed / 2);
	Draw.rect(name + "-top", x, y, rot);
}

exports.RotatorAbility = (name, x, y, speed, s, mirror) => { //螺旋桨
	return extend(Ability, {
		display: false,
		draw(unit) {
			let rot = unit.rotation - 90;
			let xy = lib.AngleTrns(rot, x, y);
			let xy2 = lib.AngleTrns(rot, -x, y);
			let Speed = Time.time * speed * 6;
			let ux = unit.x + xy.x, uy = unit.y + xy.y;
			let nx = unit.x + xy2.x, ny = unit.y + xy2.y;
			Rotator(unit.type.name + "-" + name, ux, uy, s, Speed, rot);
			if (mirror) Rotator(unit.type.name + "-" + name, nx, ny, s, -Speed, rot);
		}
	})
};

exports.MindControlFieldAbility = (damage, threshold, reload, range) => { //精控
	let hasInterfere = false, time = 0;
	return extend(Ability, {
		localized() {
			return lib.bundle("MindControlFieldAbility");
		},
		update(unit) {
			if ((time += Time.delta) >= reload) {
				Units.nearbyEnemies(unit.team, unit.x, unit.y, range, other => {
					hasInterfere = true;
					if (other.health <= threshold) {
						other.team = unit.team,
						other.heal();
					} else {
						other.health -= damage;
					}
				})
				Units.nearbyBuildings(unit.x, unit.y, range, other => {
					if (other.team != unit.team) {
						hasInterfere = true;
						if (other.health <= threshold) {
							other.team = unit.team,
							other.heal();
							Ef.interfere.at(other)
						} else {
							other.health -= damage;
						}
					}
				})
				if (hasInterfere) {
					extend(WaveEffect, {
						lifetime: 25,
						sizeFrom: 0,
						sizeTo: size,
						strokeFrom: 1.5,
						strokeTo: 0,
						colorFrom: lib.Color("AFFFFF"),
						colorTo: unit.team.color
					}).at(unit);
				}
				hasInterfere = false;
				time = 0;
			}
		}
	});
}