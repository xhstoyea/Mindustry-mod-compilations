//From cof[cof血肉诅咒]
//don't ask me where from
const lib = require('base/NCPlib');
const bullets = require("base/bullet");
const NX = require('base/normalFx')
const FX = require('base/fightFx')
const items = require("content/CPitems");
const status = require('content/status')
//let FF5845 = lib.FF5845, F03B0E = lib.Color("F03B0E");


let blackHole = new ItemTurret("blackHole");
Object.assign(blackHole, {
	size: 5,
	range: 360,
	shoot: Object.assign(new ShootPattern(), {
		firstShotDelay: 120
	}),
	//shootType: bu
	});
	
	
	let aimShoot = FX.aimShoot(lib.Color("97FF91FF"), 110, blackHole.range, 1, 15/*密集度*/);
lib.setBuilding(ItemTurret.ItemTurretBuild, blackHole, {
	shoot(type) {
		let vec = new Vec2();
		vec.trns(this.rotation, blackHole.size * 8 / 2);
		let length = Math.hypot(this.x - this.targetPos.x, this.y - this.targetPos.y);
		aimShoot.at(this.x + vec.x, this.y + vec.y, this.rotation, {
			length: Math.min(length, blackHole.range)
		});
		this.super$shoot(type);
	},
	/*
	draw() {
		this.super$draw();
		FX.PlayerAim(this, FF5845);
	}
	*/
})