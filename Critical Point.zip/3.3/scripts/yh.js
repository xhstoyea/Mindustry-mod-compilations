//From cof[cof血肉诅咒]
//don't ask me where from
const lib = require('base/NCPlib');
const bullets = require("base/bullet");
const NX = require('base/normalFx')
const FX = require('base/fightFx')
const items = require("content/CPitems");
const status = require('content/status')
//let FF5845 = lib.FF5845, F03B0E = lib.Color("F03B0E");
let FF5845 = lib.FF5845, FF6666 = lib.FF6666;

function dm(size) {
	return new MultiEffect(Fx.dynamicSpikes.wrap(Pal.redLight, size), Fx.mineImpactWave.wrap(Pal.redLight, size * 2.5))
}
let bu = Object.assign(extend(PointBulletType, {}), {
	lifetime: 6,
	speed: 160,
	ammoMultiplier: 1,
	shootEffect: new MultiEffect(
		dm(30),
		FX.railShoot
	),
	hitColor: Pal.redLight,
	smokeEffect: Fx.mineImpact.wrap(Pal.redLight),
	trailSpacing: 24,
	trailEffect: Object.assign(new ParticleEffect(), {
		region: "cp-aim",
		baseRotation: -90,
		particles: 1,
		length: 8,
		lifetime: 45,
		sizeFrom: 40,
		cone: 0,
		colorFrom: Pal.lightOrange,
		colorTo: Pal.redLight
	}),
	hitEffect: dm(120),
	fragBullets: 8,
	fragVelocityMin: 0.5,
	fragBullet: Object.assign(extend(PointBulletType, {}), {
		lifetime: 24,
		speed: 5.6,
		status: status.EMP,
		statusDuration: 45,
		splashDamage: 7200,
		splashDamageRadius: 64,
		trailEffect: Fx.disperseTrail,
		despawnShake: 4,
		despawnSound: Sounds.plasmaboom,
		despawnEffect: dm(60),
		fragBullets: 4,
		hitEffect: Fx.titanExplosion.wrap(Pal.redLight),
		fragBullet: Object.assign(extend(PointBulletType, {}), {
			lifetime: 12,
			speed: 8,
			status: StatusEffects.melting,
			statusDuration: 30,
			splashDamage: 4800,
			splashDamageRadius: 32,
			trailEffect: Fx.disperseTrail,
			despawnShake: 4,
			despawnSound: Sounds.plasmaboom,
			despawnEffect: dm(30)
		})
	})
})

let yh = new PowerTurret("yh");
Object.assign(yh, {
	size: 16,
	range: 960,
	shoot: Object.assign(new ShootPattern(), {
		firstShotDelay: 120
	}),
	shootType: bu
	});
	
let aimShoot = FX.aimShoot(lib.B5AAFFFF, 120, yh.range, 2.5, 10/*密集度*/);
lib.setBuilding(PowerTurret.PowerTurretBuild, yh, {
	shoot(type) {
		let vec = new Vec2();
		vec.trns(this.rotation, yh.size * 8 / 2);
		let length = Math.hypot(this.x - this.targetPos.x, this.y - this.targetPos.y);
		aimShoot.at(this.x + vec.x, this.y + vec.y, this.rotation, {
			length: Math.min(length, yh.range)
		});
		this.super$shoot(type);
	},
	draw() {
		this.super$draw();
		FX.PlayerAim(this, FF5845);
	}
})
