let mod = Vars.mods.getMod(modName);

mod.meta.author = "[yellow]miner";
mod.meta.description = 
"[accent]显示蓝图[green]产出[red]消耗[accent]效率[white]" + 
"\n[red]计划建筑过多可能会造成卡顿![white]"+ 
"\n[gray]热量和电力计算 下次一定([white]" + 
"\n[v1.1]: 修复拆除建筑造成崩溃 钻头加水倍率决定钻头是否应该加水[white]" + 
"\n[v1.2]: 修复泵空导致崩溃(感谢@1569237619提出的问题)[white]" + 
"\nminer的mod群:757679470";

require("IOCounter");