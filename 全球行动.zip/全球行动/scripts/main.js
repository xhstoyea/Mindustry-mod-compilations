MapResizeDialog.minSize = 50
MapResizeDialog.maxSize = 50000
require("blocks/战术核心");
require("planets/苎澜伯特");
require("xditems");
require("blocks/无敌核心");
require("status");
require("blocks/多重合金炉");
require("blocks/坦克重构厂");
