const XDlib = require("base/XDlib");
const ZLBT = new Planet("苎澜伯特", Planets.sun, 1, 3);
ZLBT.meshLoader = prov(() => new MultiMesh(
new HexMesh(ZLBT, 7)));
ZLBT.generator = extend(SerpuloPlanetGenerator, {
    getDefaultLoadout() {
        return Schematics.readBase64("bXNjaAF4nA3JMQ6AIBAAwQXFRr9i4XuMBR5XkCAYkP9LphwcbmLO/lHMwRq0SY3vF0sGluRvTQ17XoZNStU9d0na20gDduAHAc0Org==")
    }
});
ZLBT.cloudMeshLoader = prov(() => new MultiMesh(
new HexSkyMesh(ZLBT, 2, 0.15, 0.14, 5, Color.valueOf("354f59fc"), 2, 0.42, 1, 0.43),
new HexSkyMesh(ZLBT, 3, 0.6, 0.15, 5, Color.valueOf("354f59fc"), 2, 0.42, 1.2, 0.45)));
ZLBT.generator = new SerpuloPlanetGenerator();
ZLBT.visible = ZLBT.accessible = ZLBT.alwaysUnlocked = true;
ZLBT.clearSectorOnLose = false;
ZLBT.tidalLock = false;
ZLBT.localizedName = "苎澜伯特";
ZLBT.prebuildBase = false;
ZLBT.bloom = false;
ZLBT.startSector = 1;
ZLBT.orbitRadius = 90;
ZLBT.orbitTime = 180 * 80;
ZLBT.rotateTime = 90 * 90;
ZLBT.atmosphereRadIn = 0.09;
ZLBT.atmosphereRadOut = 0.2;
ZLBT.atmosphereColor = ZLBT.lightColor = Color.valueOf("354f59fc");
ZLBT.iconColor = Color.valueOf("8b28a1bb"),
ZLBT.hiddenItems.addAll(Items.erekirItems)
    .removeAll(Items.serpuloItems);

const maps1 = new SectorPreset("搁浅滩", ZLBT, 1);
maps1.description = "我们已经派出了一支部队强行登陆，此地段废墟居多敌人势力并不庞大，占领此地，研究该星球科技";
maps1.difficulty = 2;
maps1.alwaysUnlocked = false;
maps1.addStartingItems = true;
maps1.captureWave = 31;
maps1.localizedName = "搁浅滩";
exports.maps1 = maps1;
XDlib.addToResearch(maps1, {
    parent: "planetaryTerminal",
    objectives: Seq.with(
    new Objectives.SectorComplete(SectorPresets.planetaryTerminal))
});


const maps2 = new SectorPreset("3号禁区", ZLBT, 2);
maps1.description = "我们悄悄的在此地建立了前哨基地，敌人正驻扎此地，我们的信号被阻断导致陷入了僵局，敌人已请求增援，留给我们的时间已经不多了，迅速摧毁敌人基地";
maps2.difficulty = 5;
maps2.alwaysUnlocked = false;
maps2.addStartingItems = true;
maps2.captureWave = 41;
maps2.localizedName = "3号禁区";
exports.maps2 = maps2;
XDlib.addToResearch(maps2, {
    parent: "搁浅滩",
    objectives: Seq.with(
    new Objectives.SectorComplete(maps1))
});

const maps3 = new SectorPreset("冰原壁垒", ZLBT, 3);
maps3.description = "我们比敌人提前发现了此处，并且建立了基础防线，我们将参与雷达系统研究，大批敌人正在向此靠近";
maps3.difficulty = 10;
maps3.alwaysUnlocked = false;
maps3.addStartingItems = true;
maps3.captureWave = 51;
maps3.localizedName = "冰原壁垒";
exports.maps3 = maps3;
XDlib.addToResearch(maps3, {
    parent: "3号禁区",
    objectives: Seq.with(
    new Objectives.SectorComplete(maps2))
});
