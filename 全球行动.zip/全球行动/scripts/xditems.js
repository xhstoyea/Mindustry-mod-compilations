function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("铁")
newItem("电工钢")
newItem("压缩钢")
newItem("钛铁合金")
newItem("放射物混合物")
