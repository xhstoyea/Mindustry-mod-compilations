const lib = require("lib");

require('发电机')
require('科技树');
require('星球');
require('翠鸟');
require('AI');
require('物品');
require('天气控制器');
require('核心');
require('钻头');
require('地板');
require('液驱');

Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("铧金工业2.1");
    dialog.buttons.defaults().size(400, 64);
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(400, 64);

    dialog.cont.pane((() => {

        var table = new Table();
        table.add("[red]铧金工业V2.1")
        table.row();
        //换行
		table.image(Core.atlas.find("铧金工业-logo", Core.atlas.find("clear"))).left().fillX().height(200).width(620).pad(3);
		table.row();
        table.add('[yellow]来自' + modName + '[][yellow]作者的话:');
        table.row();
        table.add('感谢游玩，本Mod属于半原版拓展mod，拥有大量的，基于原版的物品。\n如果想要最快获取最新版，或有什么创意想要提供，乃至反馈Bug ，\n那么请加QQ群：[yellow]285250622\n[red]［注意］：\n[white]一、本mod内含[red]原版修改[white]，请谨慎与其他[red]原版修改[white]mod[red]同时加载[white]。\n以免[red]产生冲突[white]，导致[red]游戏崩溃[]。\n二、本mod内含战役星球，有可能与其他mod星球[red]产生冲突[white]，导致[red]游戏崩溃[white]。\n三、本mod[red]未完结前[white]，数据可能[red]每代版本都会更改[white]，请谨慎更新。\n四、未经允许，[red]禁止转载本Mod[white]！\n以下是[yellow]更新日志[white]与[orange]背景介绍[white]以及[green]鸣谢名单[white]：')
        table.row();
table.button('[yellow]更新日志', Icon.infoCircle, run(() => {
    var dialog = new BaseDialog("更新日志");
    dialog.cont.pane(t => {
        t.add("[yellow]〔2021/4/3为：mod创作始期〕");
        t.row();
        t.button("V0.18.1——V1.4.1", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("v0.18.1——V1.4.1");
            dialog.cont.pane(t => {
                t.add("[yellow]V0.18.1——V0.19.1\n（时间段：2021/4/6——2021/4/8）\n[white]主要更新了星球：希莱姆-822\n（一颗被孢子入侵过，被阿兰达舰队洗地过的可怜星球……）\n\n[yellow]V0.19.3——V0.20.0\n（时间段：2021/4/11——2021/5/5）\n[white]更新了第一个单位：歼星\n\n[yellow]V0.21.0——V1.4.1\n（时间段：2021/5/8——2022/5/3）\n[white]更新了很多东西，这里在此省略(真不是我懒)。");
                t.row();
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
            dialog.show();
        })).size(400, 64);
        t.row();
        t.button("V2.0先行版", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("v2.0先行版");
            dialog.cont.pane(t => {
                t.add("[yellow]本次的版本为先行版，以下只放出部分更新内容。\n具体请自行游玩查阅。")
                t.row();
                t.image(Core.atlas.find("铧金工业-铉晶", Core.atlas.find("clear"))).left().fillX().height(64).width(64).pad(3);
                t.row();
                t.add("[brown]铉晶（矿物）\n数量及其稀少，并且挖掘难度颇大，\n无法用钻头开采……");
                t.row();
                t.image(Core.atlas.find("铧金工业-孢子抑制液", Core.atlas.find("clear"))).left().fillX().height(64).width(64).pad(3);
                t.row();
                t.add("[green]孢子抑制液（液体）\n专门用来对付孢兽的液体，只对孢兽\n有效……");
                t.row();
                t.image(Core.atlas.find("铧金工业-铧塑传送带", Core.atlas.find("clear"))).left().fillX().height(64).width(64).pad(3);
                t.row();
                t.add("[cyan]铧塑传送带\n用于前线的超强传送带，可以吸收\n激光与电弧，还可放置在液体上……")
            });
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
            dialog.show();
        })).size(400, 64);
        t.row();
        t.button("V2.1（端午节快乐！）", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("v2.1");
            dialog.cont.pane(t => {
                t.add("[yellow]本次的更新属于加急更新，以下只放出部分更新内容。\n具体请自行游玩查阅。")
                t.row();
                t.image(Core.atlas.find("铧金工业-水解炮", Core.atlas.find("clear"))).left().fillX().height(64).width(64).pad(3);
                t.row();
                t.add("[blue]水解炮\n只能放在水上的激光炮台，属于初期\n炮台……");
                t.row();
                t.image(Core.atlas.find("铧金工业-填海桩1", Core.atlas.find("clear"))).left().fillX().height(64).width(64).pad(3);
                t.row();
                t.add("[blue]填海桩（地板）\n对于空无一物的大海，我们有独特的\n见解……");
                t.row();
                t.image(Core.atlas.find("铧金工业-铧塑电力节点", Core.atlas.find("clear"))).left().fillX().height(64).width(64).pad(3);
                t.row();
                t.add("[cyan]铧塑电力节点\n用于前线的超级电力节点，可以吸\n收激光与电弧，还可放置在液体上……")
            });
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
            dialog.show();
        })).size(400, 64);
        t.row();
    });
    dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
    dialog.show();
})).size(400, 64);
        table.row();
    table.button('[orange]背景介绍', Icon.infoCircle, run(() => {
    var dialog = new BaseDialog("背景介绍");
    dialog.cont.pane(t => {
        t.add("[yellow]宇宙无时无刻不在膨胀，已知直径就约莫有863万亿光年。\n哪怕是高等文明的领土，也四处充斥着未曾了解的区域……");
        t.row();
        t.button("玩家", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("玩家");
            dialog.cont.pane(t => {
                t.add("[yellow]“我方文明”的小型探索队，主要负责本星系内的\n公共区域的探索，遵循星系公约，坚决维护\n《主星系内探索队三不原则》：\n[white]不主动攻击原住民及其他文明探索队；\n不摧毁星球，及其生态与文明；\n不在星系内使用现役的、近万年间退役的军事武器。");
                t.row();
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
            dialog.show();
        })).size(400, 64);
        t.row();

        t.button("原版敌人", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("v0.18.2");
            dialog.cont.pane(t => {
                t.add("[red]目前无法知晓他们所属文明，\n他们显露出的技术皆是星际通用的，\n以及窃取“我方文明”的……")
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
            dialog.show();
        })).size(400, 64);
        t.row();

        t.button("孢子与孢兽", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("v0.18.3");
            dialog.cont.pane(t => {
                t.add("[purple]阿兰达舰队的目标，目前“我方文明”遇到的\n孢兽并没有展露出值得军队出动的实力……")
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
            dialog.show();
        })).size(400, 64);
        t.row();
        
        t.button("希莱姆与远古械教", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("v0.18.3");
            dialog.cont.pane(t => {
                t.add("[grey]目前已知的是，希莱姆幸存下来的原住民，\n大部分为所谓的“械教”的人员。他们利用生物科技与\n阿兰达舰队遗留物制造武器，工厂等……")
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
            dialog.show();
        })).size(400, 64);
        t.row();
        
        t.button("阿兰达舰队", Icon.infoCircle, run(() => {
            var dialog = new BaseDialog("v0.18.3");
            dialog.cont.pane(t => {
                t.add("[grey]隶属于卡帕尔文明的远征军第三舰队，似乎是在追击“孢子”。\n[yellow]（卡帕尔文明在本星系里同“我方文明”均属于高等文明。）")
            })
            dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
            dialog.show();
        })).size(400, 64);
        t.row();
    });
    dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
    dialog.show();
})).size(400, 64);
        table.row();
    table.button('[green]鸣谢名单', Icon.infoCircle, run(() => {
    var dialog = new BaseDialog("鸣谢名单");
    dialog.cont.pane(t => {
        t.add("[green]在这里感谢提供了代码的朋友，他们是以下几位：")
        t.row();
        t.image(Core.atlas.find("铧金工业-手电", Core.atlas.find("clear"))).left().fillX().height(160).width(160).pad(3);
        t.row();
        t.add("[yellow]手电（QQ：16****8557）");
        t.row();
        t.image(Core.atlas.find("铧金工业-神魂", Core.atlas.find("clear"))).left().fillX().height(160).width(160).pad(3);
        t.row();
        t.add("[yellow]神魂（QQ：63****807）");
        t.row();
        t.image(Core.atlas.find("铧金工业-晓伟", Core.atlas.find("clear"))).left().fillX().height(160).width(160).pad(3);
        t.row();
        t.add("[yellow]晓伟（QQ：35****6577）");
        t.row();
        t.image(Core.atlas.find("铧金工业-残影旧梦", Core.atlas.find("clear"))).left().fillX().height(160).width(160).pad(3);
        t.row();
        t.add("[yellow]残影旧梦（QQ：25****6905）");
        t.row();
        t.add("[green]以下的朋友为本mod提供了其他重要支持：");
        t.row();
        t.image(Core.atlas.find("铧金工业-30K铜", Core.atlas.find("clear"))).left().fillX().height(160).width(160).pad(3);
        t.row();
        t.add("[yellow]30K铜（QQ：27****7486）");
    });
    dialog.buttons.button("@close", ()=>{dialog.hide()}).size(400, 64);;
    dialog.show();
})).size(400, 64);
        table.row();
        return table;
    })()).grow().center().maxWidth(620);
    dialog.show();
}));