const 大型rtg = new ConsumeGenerator("大型RTG发电机")

大型rtg.consume(new ConsumeItemRadioactive())
//RTG型输入