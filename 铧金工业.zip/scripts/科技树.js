const lib = require("lib");
const A = require("星球");
const 物品 = require("物品");

const 阿兰达单位构建工厂 = new UnitFactory("阿兰达单位构建工厂");
const 红莲至尊 = new UnitType("红莲至尊-阿迪达尔");
const 自放电 = new SolarGenerator("铧能放电块");
const 自放电2 = new SolarGenerator("潮汐发电机");
const 重铧发电机 = new ImpactReactor("重铧发电机")
const 蟹蛛 = new UnitType("蟹蛛");
const 臭蛆 = new UnitType("臭蛆");
const 远古械教石像 = new LaserTurret("远古械教石像-蟹蛛");
const 孢子躁动厂 = new GenericCrafter("孢子躁动厂")
const 孢子实验室 = new GenericCrafter("孢子实验室")

红莲至尊.constructor = prov(() => extend(UnitTypes.flare.constructor.get().class, {}));
蟹蛛.constructor = prov(() => extend(UnitTypes.arkyid.constructor.get().class, {}));
臭蛆.constructor = prov(() => extend(UnitTypes.arkyid.constructor.get().class, {}));

自放电.buildType = prov(() => new JavaAdapter(SolarGenerator.SolarGeneratorBuild,{
	updateTile(){
		this.productionEfficiency = 1
	}
},自放电));
自放电2.buildType = prov(() => new JavaAdapter(SolarGenerator.SolarGeneratorBuild,{
	updateTile(){
		this.productionEfficiency = 1
	}
},自放电2));

lib.node(A.阿兰达失落神殿,远古械教石像,
	ItemStack.with(
		Items.scrap,(2880*40)
	),
	Seq.with(
		new Objectives.SectorComplete(A.阿兰达失落神殿))
);
lib.node(A.深渊入口,蟹蛛,
	ItemStack.with(
		Items.copper,(1*1)
	),
	Seq.with(
		new Objectives.SectorComplete(A.深渊入口))
);
lib.node( Blocks.largeSolarPanel, 自放电,
	ItemStack.with(
		Items.silicon, (20*40),
		物品.铧金, (5*40)
),
	Seq.with(
		new Objectives.Research(重铧发电机),
		new Objectives.SectorComplete(A.迷你游戏一))
);
lib.node(A.深渊,红莲至尊,
	ItemStack.with(
		Items.copper,(1*1)
	),
	Seq.with(
		new Objectives.SectorComplete(A.深渊))
);
lib.node(Blocks.tetrativeReconstructor,阿兰达单位构建工厂,
	ItemStack.with(
		Items.silicon,(3500*40),
		物品.铧金,(500*40),
		Items.lead,(5000*40),
		Items.titanium,(1500*40),
		Items.plastanium,(1500*40),
		Items.thorium,(2000*40),
		Items.surgeAlloy,(500*40),
		Items.phaseFabric,(250*40),
),
	Seq.with(
		new Objectives.SectorComplete(A.阿兰达失落神殿))
);
lib.node(Blocks.cultivator,孢子躁动厂,
	ItemStack.with(
		Items.metaglass,(15*40),
		Items.lead,(30*40),
		Items.titanium,(10*40),
),
	Seq.with(
		new Objectives.SectorComplete(SectorPresets.biomassFacility))
);
lib.node(孢子躁动厂,孢子实验室,
	ItemStack.with(
		Items.metaglass,(100*40),
		Items.copper,(160*40),
		Items.titanium,(120*40),
		Items.silicon,(60*40),
		Items.lead,(80*40)
),
	Seq.with(
		new Objectives.SectorComplete(A.寒冷隔离带))
);
lib.node(A.寒冷隔离带,臭蛆,
	ItemStack.with(
		Items.sporePod,(1*1)
	),
	Seq.with(
		new Objectives.SectorComplete(A.寒冷隔离带))
);