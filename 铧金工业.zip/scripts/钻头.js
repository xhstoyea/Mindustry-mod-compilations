const lib = require("铧金工业-Java");

const 冲击钻头 = new lib.DawnDrill("冲击钻头");

冲击钻头.buildVisibility = BuildVisibility.shown;
冲击钻头.category = Category.production;

冲击钻头.drillTime = 150;
冲击钻头.size = 5;
冲击钻头.drawRim = true;
冲击钻头.hasPower = true;
冲击钻头.tier = 25;
冲击钻头.drillEffect = Fx.mine;
冲击钻头.rotateSpeed = 2;
冲击钻头.warmupSpeed = 0.2;
冲击钻头.itemCapacity = 100;
冲击钻头.liquidCapacity = 90;
冲击钻头.liquidBoostIntensity = 1.9;
冲击钻头.consumePower(60);
冲击钻头.consumeLiquids(new LiquidStack(Liquids.cryofluid, 0.375)).boost();

const 爆硫 = ItemStack.with(
    Items.blastCompound, 2,
    Items.pyratite,5,
    )

//(物品数组, 发电量, 发电时间, 挖掘速度加成（倍）)
const 爆冲 = new lib.PowerItems(爆硫, 325, 360, 2.5)
//(物品, 消耗数量, 发电量, 发电时间, 挖掘速度加成（倍）, 冲击物品)
const 沙子 = new lib.PowerItems(Items.sand, 5, 10, 120, 1,爆冲)
const 废料 = new lib.PowerItems(Items.scrap, 5, 67, 60, 1,爆冲)
const 铜 = new lib.PowerItems(Items.copper, 5, 10, 180, 1,爆冲)
const 铅 = new lib.PowerItems(Items.lead, 5, 10, 180, 1,爆冲)
const 煤炭 = new lib.PowerItems(Items.coal, 5, 82, 240, 1, 爆冲)
const 钛 = new lib.PowerItems(Items.titanium, 5, 10, 240, 1,爆冲)
const 钍 = new lib.PowerItems(Items.thorium, 5, 135, 300, 1, 爆冲)
			
冲击钻头.ItemsPower = [沙子,废料,铜,铅,煤炭,钛,钍]//设置发电物品组

冲击钻头.plasma = 3//冲击贴图数量(实际数量是 4 因为不算 ID 为 0 的贴图)
冲击钻头.plasma1 = Color.valueOf("BA8AF8FF");
冲击钻头.plasma2 = Color.valueOf("826AC1FF");