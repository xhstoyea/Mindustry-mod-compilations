const lib = require("铧金工业-Java");

const 战术核心 = new lib.DawnCore("战术核心");

//最大方块数量
战术核心.MAXBlock = 11;

//力场接口
战术核心.ConsumeTypeItem = Items.phaseFabric
战术核心.radius = 200
战术核心.shieldHealth = 4000
战术核心.phaseShieldBoost = 3200
战术核心.phaseUseTime = 300
战术核心.phaseRadiusBoost = 160
战术核心.cooldownNormal = 1.15
战术核心.cooldownLiquid = 1.75
战术核心.cooldownBrokenBase = 0.35

//合金墙接口
战术核心.lightningChance = 0.07
战术核心.lightningDamage = 48

//发电量
战术核心.powerProduction = 25;
战术核心.unitCapModifier = 15;
战术核心.baseExplosiveness = 10;
战术核心.thrusterLength = 4/4;