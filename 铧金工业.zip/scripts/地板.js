const 铉晶矿 = new Floor("铉晶矿")
const 填海钛板 = new Floor("填海钛板");
const 填海桩 = new Wall("填海桩");

exports.填海钛板 = 填海钛板;
exports.填海桩 = 填海桩;
exports.铉晶矿 = 铉晶矿;

填海桩.update = true;
填海桩.buildType = prov(() => {
	const b = extend(Wall.WallBuild, 填海桩, {
	updateTile(){
	    Vars.world.tile(this.tileX(), this.tileY()).setFloor(填海钛板);
	    Vars.world.tile(this.tileX(), this.tileY()).setAir();
	},
	})
	return b
});