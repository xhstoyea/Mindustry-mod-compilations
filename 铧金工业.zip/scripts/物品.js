const 铧金 = new Item("铧金", Color.valueOf("#CF4141"));
const 铉晶 = new Item("铉晶", Color.valueOf("FFE7CDFF"));
const 躁动孢子 = new Item("躁动孢子", Color.valueOf("FF8800"));

exports.铧金 = 铧金;
exports.铉晶 = 铉晶;
exports.躁动孢子 = 躁动孢子;