const 希莱姆 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(希莱姆, 4));
        this.super$load();
    }
}, "希莱姆-822", Planets.sun, 1);
希莱姆.generator = new SerpuloPlanetGenerator();
//这个别动
希莱姆.bloom = false;
//不清楚
希莱姆.accessible = true;
//是否在行星菜单内显示
希莱姆.rotateTime = 12000
//一昼夜的时间(s)
希莱姆.localizedName= "希莱姆-822";
//如果有翻译文件就不需要写这个
希莱姆.visible = true;
//可见
希莱姆.alwaysUnlocked = true;
希莱姆.orbitRadius = 500;
//星球半径
希莱姆.atmosphereColor = Color.valueOf("000000");
//大气层颜色
希莱姆.atmosphereRadIn = 0.05;
//大气素
希莱姆.atmosphereRadOut = 0.5;
//大气输出
希莱姆.startSector = 0;
//默认解锁的区域数量
const lib = require("lib");
const s = require("地板");
const sS = require("sectorSize");
sS.planetGrid(希莱姆, 3.3);

const 地图一 = new SectorPreset("狭窄通道", 希莱姆, 0);
地图一.description = "降落地点出现了问题，我们迫降在了一处峡谷中，这里也是通往某处的通道。                                    击破敌方核心，继续前进！";
//引号内填msav的名字
地图一.difficulty = 1;
//难度
地图一.alwaysUnlocked = false;
//无需解锁
地图一.addStartingItems = true;
//允许添加初始资源
地图一.captureWave = 1;
//多少波可占领
地图一.localizedName = "狭窄通道";
exports.狭窄通道 = 地图一;
lib.addToResearch(地图一, {
    parent: "planetaryTerminal",
    objectives: Seq.with(
        new Objectives.SectorComplete(SectorPresets.planetaryTerminal))
});

const 地图二 =new  SectorPreset("迷你游戏1-尝试", 希莱姆, 1);
地图二.description = "我们的敌人想要和我们来一场特殊的游戏，满足他们！                                部分建筑被禁用，在有限的空间下摧毁敌方核心。";
地图二.difficulty = 2;
地图二.alwaysUnlocked = false;
地图二.addStartingItems = true;
地图二.captureWave = 1;
地图二.localizedName = "迷你游戏1-尝试";
exports.迷你游戏一 = 地图二;
lib.addToResearch(地图二, {
    parent: '狭窄通道',
    objectives: Seq.with(
        new Objectives.SectorComplete(地图一))
});

const 地图三 = new SectorPreset("迷你游戏2-燥热难耐", 希莱姆, 101);
地图三.difficulty = 4;
地图三.alwaysUnlocked = false;
地图三.addStartingItems = true;
地图三.captureWave = 1;
地图三.localizedName = "迷你游戏2-燥热难耐";
exports.迷你游戏二 = 地图三;
lib.addToResearch(地图三, {
    parent: '迷你游戏1-尝试',
    objectives: Seq.with(
        new Objectives.SectorComplete(地图二))
});

const 地图四 = new SectorPreset("荒芜沙田", 希莱姆, 96);
地图四.description = "一处资源丰富的地区，大量充斥着敌人的工厂与炮台，并且似乎通向某处不为人知的地方。                                                        总而言之，摧毁他们的核心，继续前进！";
地图四.difficulty = 8;
地图四.alwaysUnlocked = false;
地图四.addStartingItems = true;
地图四.captureWave = 1;
地图四.localizedName = "荒芜沙田";
exports.荒芜沙田 = 地图四;
lib.addToResearch(地图四, {
    parent: '狭窄通道',
    objectives: Seq.with(
        new Objectives.SectorComplete(地图一))
});

const 地图五 =new  SectorPreset("阿兰达失落神殿", 希莱姆, 36);
地图五.description = "我们好像来到了什么不得了的地方，看到中心处的神庙了吗？敌人竟然派出大量兵力攻打那里，也许有什么大秘密。                                                抵御敌人的进攻！";
地图五.difficulty = 8;
地图五.alwaysUnlocked = false;
地图五.addStartingItems = true;
地图五.captureWave = 45;
地图五.localizedName = "阿兰达失落神殿";
exports.阿兰达失落神殿 = 地图五;
lib.addToResearch(地图五, {
    parent: '荒芜沙田',
    objectives: Seq.with(
        new Objectives.SectorComplete(地图四))
});

const 地图六 =new  SectorPreset("深渊入口", 希莱姆, 178);
地图六.description = "敌人从这里撤退了，只有少数掩护部队会出现，但也不要大意。                                        尽快摧毁敌人的掩护部队！";
地图六.difficulty = 4;
地图六.alwaysUnlocked = false;
地图六.addStartingItems = true;
地图六.captureWave = 25;
地图六.localizedName = "深渊入口";
exports.深渊入口 = 地图六;
lib.addToResearch(地图六, {
    parent: '阿兰达失落神殿',
    objectives: Seq.with(
        new Objectives.SectorComplete(地图五))
});

const 地图七 =new  SectorPreset("深渊", 希莱姆, 177);
地图七.description = "这里不宜久留，好像有什么不好的东西会出现，多带些资源，也许会是一场苦战！                                                抵御敌人的进攻！";
地图七.difficulty = 10;
地图七.alwaysUnlocked = false;
地图七.addStartingItems = true;
地图七.captureWave = 12;
地图七.localizedName = "深渊";
exports.深渊 = 地图七;
lib.addToResearch(地图七, {
    parent: '深渊入口',
    objectives: Seq.with(
        new Objectives.SectorComplete(地图六))
});

const 地图八 =new  SectorPreset("寒冷隔离带", 希莱姆, 179);
地图八.description = "从这里出发，我们应该能找到阿兰达舰队离开的原因。                        抵御敌人的进攻！";
地图八.difficulty = 2;
地图八.alwaysUnlocked = false;
地图八.addStartingItems = true;
地图八.captureWave = 12;
地图八.localizedName = "寒冷隔离带";
exports.寒冷隔离带 = 地图八;
lib.addToResearch(地图八, {
    parent: '阿兰达失落神殿',
    objectives: Seq.with(
        new Objectives.SectorComplete(地图五))
});

const 地图九 =new  SectorPreset("悬崖要道", 希莱姆, 91);
地图九.description = "这个地方一夫当关万夫莫开，十分危险，而且这里有一些铉晶！也许这里通向了敌人的铉晶矿脉。                            抵御敌人的进攻！";
地图九.difficulty = 10;
地图九.alwaysUnlocked = false;
地图九.addStartingItems = true;
地图九.captureWave = 12;
地图九.localizedName = "悬崖要道";
exports.悬崖要道 = 地图九;
lib.addToResearch(地图九, {
    parent: '深渊',
    objectives: Seq.with(
        new Objectives.SectorComplete(地图七))
});

const 地图十 =new  SectorPreset("前线海岸", 希莱姆, 156);
地图十.description = "这里再过去就是敌人的海上基地了。                抵御敌人的进攻！";
地图十.difficulty = 4;
地图十.alwaysUnlocked = false;
地图十.addStartingItems = true;
地图十.captureWave = 18;
地图十.localizedName = "前线海岸";
exports.前线海岸 = 地图十;
lib.addToResearch(地图十, {
    parent: '悬崖要道',
    objectives: Seq.with(
        new Objectives.Research(s.填海桩),
        new Objectives.SectorComplete(地图九))
});