var ax = extend(UnitType, '蜂鸟', {});
ax.controller = () => new MinerAI();
ax.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));

var ax1 = extend(UnitType, '百灵', {});
ax1.controller = () => new MinerAI();
ax1.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));

var ax2 = extend(UnitType, '青灵', {});
ax2.controller = () => new MinerAI();
ax2.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));

var ax3 = extend(UnitType, '巨灵', {});
ax3.controller = () => new MinerAI();
ax3.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));

var ax4 = extend(UnitType, '玄鸟', {});
ax4.controller = () => new MinerAI();
ax4.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));

var axa = extend(UnitType, '幻影', {});
axa.controller = () => new BuilderAI();
axa.constructor = prov(() => extend(UnitTypes.mega.constructor.get().class, {}));

var axb = extend(UnitType, '虚影', {});
axb.controller = () => new BuilderAI();
axb.constructor = prov(() => extend(UnitTypes.mega.constructor.get().class, {}));
