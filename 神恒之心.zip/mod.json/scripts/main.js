importPackage(Packages.mindustry.graphics)

MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 1000
require("星球/神歆堕星");
require('qwer');