const core1 = extend(CoreBlock, "护城核心", {
});
const core2 = extend(CoreBlock, "征伐核心", {
});
const core3 = extend(CoreBlock, "精勤核心", {
});
const core1A = extend(CoreBlock, "破围核心", {
});
const core1B = extend(CoreBlock, "统御核心", {
});
const core2A = extend(CoreBlock, "维系核心", {
});
const core2B = extend(CoreBlock, "硬寨核心", {
});
const core3A = extend(CoreBlock, "鞭策核心", {
});
const core3B = extend(CoreBlock, "宛禁核心", {
});