const SCore = extend(CoreBlock, "SCore", {
	canBreak(tile) {
		return Vars.state.teams.cores(tile.team()).size > 1;
	},
	canPlaceOn(tile, team, rotation) {
		return Vars.state.teams.cores(team).size < 3;
	}
});