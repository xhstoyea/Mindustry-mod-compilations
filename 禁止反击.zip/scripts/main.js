Planets.serpulo.allowSectorInvasion = false
// Vars.state.rules.coreIncinerates = true;//核心焚烧