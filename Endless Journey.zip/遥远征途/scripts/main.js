function SizeSpeedStatus(name, speed) {
	return extend(StatusEffect,name, {
		update(unit) {
x = unit.type.size * 0.125 * speed
unit.speed = speed * 0.1 * unit.type.speed 
if(x > 0.1 * speed){
unit.speed = unit.type.speed * x;
	}
	}});
};
SizeSpeedStatus("电离减速1", 1);
let AddArmor = Stat("AddArmor");

function ArmorStatus(name, armor) {
	return extend(StatusEffect,name, {
		update(unit) {
unit.armor = unit.type.armor + armor;
	}});
};
ArmorStatus("sclerosis1", 4);
ArmorStatus("sclerosis2", 8);
require("blocks/super-router");
//require("blocks/shield");
Events.on(EventType.ClientLoadEvent, () => {

if(Vars.mods.getMod("ec") != null){Core.app.exit()};

if(Vars.mods.getMod("岩浆工业") != null)Vars.mods.removeMod(Vars.mods.getMod("岩浆工业"));

if(Vars.mods.getMod("虚无") != null)Vars.mods.removeMod(Vars.mods.getMod("虚无"));

if(Vars.mods.getMod("sun1") != null)Vars.mods.removeMod(Vars.mods.getMod("sun1"));

if(Vars.mods.getMod("深海科技") != null)Vars.mods.removeMod(Vars.mods.getMod("深海科技"));

if(Vars.mods.getMod("无限宇宙") != null)Vars.mods.removeMod(Vars.mods.getMod("无限宇宙"));
})