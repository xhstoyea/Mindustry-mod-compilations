global.Filter = function(name) {
	var m = Object.assign(extend(GenericCrafter, name, {
		setStats() {
			this.super$setStats();
			this.stats.remove(Stat.productionTime);
		}
	}), {
		size: 1,
		itemCapacity: 1,
		configurable: true
	});
	m.setupRequirements(
	Category.production,
	BuildVisibility.shown,
	ItemStack.with(Items.copper, 1));
	return m;
}


global.FourDireFilter = function(name) {
	var m = new global.Filter(name);
	m.buildType = () => {
		var items = [Items.copper, Items.lead, Items.titanium, Items.silicon];
		var shown = [false, false, false, false];
		var current = 0;
		return extend(GenericCrafter.GenericCrafterBuild, m, {
			acceptItem(source, item) {
				return this.items.get(item) < this.getMaximumAccepted(item);
			},
			buildConfiguration(table) {
				table.background(Tex.pane);
				table.pane(buttons => {
					buttons.collapser(bs => {
						Vars.content.items().each(item => {
							bs.button(Core.atlas.drawable(item.uiIcon), Styles.flati, 24, run(() => {
								for (var i = 0; i < 4; i++) {
									if (shown[i]) {
										items[i] = item;
										shown[i] = false;
									}
								}
							})).size(30);
						})
					}, () => (shown[0] || shown[1] || shown[2] || shown[3]));
				}).size(120, 30).row();
				table.pane(buttons2 => {
					function place(index) {
						buttons2.button(Icon.add, Styles.flati, 24, run(() => {
							shown[current] = false;
							shown[index] = true;
							current = index;
						})).update(m => {
							m.getStyle().imageUp = (items[index].uiIcon == null ? Icon.add : Core.atlas.drawable(items[index].uiIcon))
						}).size(30);
					}

					place(1);
					place(0);
					place(3);
					place(2);
				}).row();
				table.table(cons(places => {
					places.defaults().size(30);
					places.image(Icon.up);
					places.image(Icon.right);
					places.image(Icon.down);
					places.image(Icon.left);
				}));
			},
			updateTile() {
				for (var i = 0; i < 4; i++) {
					var build = this.nearby(i);
					if (build != null && build.acceptItem(this, items[i]) && this.items.has(items[i])) {
						build.handleItem(this, items[i]);
						this.items.remove(items[i], 1);
					}
				}
			}
		});
	}
}

new global.FourDireFilter('super-router'); 