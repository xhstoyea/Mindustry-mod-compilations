
const shield-breaker = new ForceProjector("shield-breaker");
shield-breaker.buildType = prov(() => extend(ForceProjector.ForceBuild, shield-breaker,{
    updateTile(){
        this.super$updateTile()
        let realRadius = this.realRadius();
        if(!this.broken){
            Groups.bullet.intersect(this.x - realRadius + 9, this.y - realRadius + 9, realRadius * 2 - 9, realRadius * 2 - 9, b => {
                if(b.type.absorbable && b.team != this.team){
                    b.vel.setAngle(b.rotation() + 180);
                    b.team = this.team
                    this.buildup += b.damage * 1.2;
                }
            });
        }
    }
}))