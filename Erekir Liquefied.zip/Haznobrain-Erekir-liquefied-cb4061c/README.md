# Welcome to erekir but we (me and my schizo imaginary friends) applied a shit ton of heat to it!
## I made this mod pretty much alone and the stuff that was made by others has credit given in its description or file.

My discord is either mindustridiot_06647 or haznobrainDev.
Discord server link: https://discord.gg/GKUXnhya

<br>the sprite quality may vary a lot.
## What does this add?
- a bunch of erekir maps
- a few erekir unit lines
- a bit of post-origin content
- a few turrets
- new materials

## A lot of the stuff in the mod will be changed sooner or later, especially maps.
so ye ig you should play, enjoy, and leave a star if you want :3 

# Screenshots!
![image](https://github.com/user-attachments/assets/80d92200-27b6-4ca0-b1e0-73b6a084dcaa)
![image](https://github.com/user-attachments/assets/274d271e-a3fb-4b2a-a5fe-f2a25f63de83)
![image](https://github.com/user-attachments/assets/b38474c2-8d04-4a73-a1d2-f876918ffdcd)
![image](https://github.com/user-attachments/assets/f3a0ac93-cb1e-41cc-8f76-c57915842ae2)
![image](https://github.com/user-attachments/assets/5404c639-4d89-4efc-a85f-fec76797eec5)
![image](https://github.com/user-attachments/assets/eea6c596-1ad8-44e8-95b6-43b189fa29a2)
![image](https://github.com/user-attachments/assets/9000489c-0512-44e6-9376-5e2e7ddf9aa8)
