//这是史，别看



Blocks.scatter.targetGround = true;
Blocks.scatter.ammoTypes.get(Items.lead).collidesGround = true;
Blocks.scatter.ammoTypes.get(Items.metaglass).collidesGround = true;
Blocks.scatter.ammoTypes.get(Items.scrap).collidesGround = true;
Blocks.scatter.ammoTypes.get(Items.lead).collidesTiles = true;
Blocks.scatter.ammoTypes.get(Items.metaglass).collidesTiles = true;
Blocks.scatter.ammoTypes.get(Items.scrap).collidesTiles = true;

UnitTypes.corvus.canBoost = true;
UnitTypes.corvus.engineOffset = 12;
UnitTypes.corvus.engineSize = 6;
UnitTypes.corvus.lowAltitude = true;
UnitTypes.corvus.riseSpeed = 0.05;
while(Unit.corvus.updateBoosting=0){UnitTypes.corvus.legCount = 0};
//谢谢你，看到赛博狗屎就走不动道的小馋猫


Items.blastCompound.flammability = 2.5;