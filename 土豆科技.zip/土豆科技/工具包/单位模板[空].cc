{
	"type": "flying",/*种类 */
	"name": "名称",/*名称，它叫什么名字！ */
	"description": "描述",/*描述，简介！ */
	"ammoCapacity": 00,/*弹药容量 */
    "ammoResupplyAmount":00,/*弹药补给倍率 */
    "speed": 0,/*速度 */
	"flying": true,/*能否飞行，true为能飞 */
	"turnCursor":false,/*转动光标 */
	"engineOffset": 0,/*发动机偏移 */
	"engineSize": 0,/*发动机大小 */
    "hitSize": 0,/*被击中大小，你的大小 */
    "targetAir":"true",/*目标航空 */
    "health": 00,/*血量 */
    "armor": 0,/*装甲 */
    "mineSpeed": 0,/*挖矿速度 1=100% */
    "mineTier": 0,/*挖矿等级，你可以挖什么矿 */
    "buildSpeed": 0,/*构建速度 1=100%*/
    "rotateSpeed": 0,/*转速，旋转的速度 */
    "itemCapacity": 00,/*容量，字面意思 */
    "commandLimit": 0,/*命令限制，能让多少单位跟着你！ */
    "rotateShooting": "true",/*旋转射击，是否旋转射击 */
    "abilities": [/*能力（如力场防御等） */
        {
    "type":"ForceFieldAbility",/*类型:力场能力 */
    "radius": 00,/*半径大小，按8/格算！ */
    "regen": 0.0,/*再生，力场回血的速度，别过高！ */
    "max": 000,/*力场血量上限 */
    "cooldown": 0000,}/*冷却时间，力场打没了之后重新出现的时间 */
    ],/*如果不用可以删除！别告诉我删都不会删！ */
    	"weapons":[ 
    	{"name":"贴图名",/*贴图的名字 */
	"x":0,"y":0,/*位置 x为上下y为左右 */
	"mirror":"true",/*镜像，是否对称 */
	"reload":0,/*重新装弹速度 */
	"rotate": "true",/*是否旋转 */
	"rotateSpeed":0,/*旋转速度 */
	"shootEffect":"shootSmall",/*射击效果 */
	"shootSound":"shoot",/*射击声 */
	"bullet":{
	"type":"ArtilleryBulletType",/*子弹类型 */
	"damage": 00,/*伤害 */
	"frontColor":"FFDE00",/*子弹颜色 正面颜色*/
	"backColor":"FF4E00",/*背景色 */
	"width": 5,/*子弹宽度 */
	"height": 5,/*子弹长度 */
	"speed": 0,/*子弹速度 */
	"lifetime":00,/*子弹血量 */
	"reloadTime": 00,//攻击范围
	"lifetime":00,//存在时间，帧
	"buildingDamageMultiplier":1/*对建筑物伤害/乘数 */
	"homingPower":0.00,//追踪力度
      "homingRange":00,//追踪范围，8/格
	} 	
	},
    ]
}