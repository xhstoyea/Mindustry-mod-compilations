
Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("[blue]土豆科技[yellow]信息栏");
    dialog.cont.image(Core.atlas.find("土豆科技-a")).row();;
    dialog.buttons.defaults().size(210, 64);
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(210, 64);
    dialog.cont.pane((() => {
        var table = new Table();   
         table.add("这是土豆科技！").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
        
table.button("[red]更新日志", run(() => {
    var dialog2 = new BaseDialog("[red]更新日志");
    var table = new Table();
	
	var t = new Table();
	t.add("\n[blue]我们都来支援他！模组QQ群：738368557\n[white]----1.23----\n:找六清要了这个信息栏；\n感谢黄豆提供的核弹发射器贴图和核弹以及建议！\n结构框架\n---1.23rework---\n整了点烂活,并且把mod救活了\n---1.24---\n完善了贴图，找回了RM 21，解决了崩溃的问题\n1.24.1     修改和补全了贴图\nK280、K-3C4PTNI、防空炮、冶铁高炉");
    dialog2.cont.add(new ScrollPane(t)).size(500, 600).row();
    dialog2.buttons.defaults().size(620, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(500, 64);
       dialog2.show();
    })).size(210, 64);
        return table;
    })()).grow().center().maxWidth(600);
    dialog.show();
}));