MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 40000
require("东西/物品");
require("东西/液体");
require("特别的工厂/综合冶炼厂");
require("特别的工厂/综合合成机");
require("特别的工厂/大气压缩机");
require("特别的工厂/复合刻印厂");
require("特别的工厂/液体中心");
require("qwer");
//require("特别的工厂/液体加注机");

