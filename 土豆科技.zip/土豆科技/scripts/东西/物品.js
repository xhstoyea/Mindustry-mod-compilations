function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("Fe")
newItem("钢铁")
newItem("水泥")
newItem("结构框架")
newItem("石灰石")
newItem("天然气桶")
newItem("重油桶")
newItem("轻油桶")
newItem("氧气罐")
newItem("氢气罐")
newItem("氨气罐")
newItem("硫磺罐")
newItem("氮气罐")
newItem("基础电路板")
newItem("复合电路板")
newItem("集成电路板")
newItem("生物塑料")
newItem("塑料")
newItem("水桶")
newItem("合金钢")
newItem("浓缩重油弹")
newItem("标准弹药箱")
newItem("B")
newItem("B4C")
newItem("PTTBF")
newItem("单位应力")

//做个尝试，上面的是从json中导入过来的(大概），下面是直接在这里做的
//如果这行注释还活着，那就是成功了
//下方代码来源于蔚蓝行星，我不知道，上面的函数名已经是newItem了，所以我寻思改一下才行
function addItem(name, color, obj) {
	Object.assign(exports[name] = new Item(name,
		Color.valueOf(color)), obj);
}
/*addItem("矢量合金", "F6BB64FF", { //物品详细信息
	hardness: 0, //硬度，只有矿物有，与挖掘速度、挖掘等级有关
	radioactivity: 0, //放射性
	explosiveness: 1, //爆炸性
	flammability: 0, //燃烧性
	charge: 1.5, //放电性
	cost: 1.5, //建筑时间消耗倍率
	frames: 10,//动态贴图帧数
})*/
addItem("穿甲弹药盒", "339900", {
	cost: 0.5,
})
//可能需要寻找高人,才能做到给物品添加注释了，所以我寻思需要有注释的物品用json来写