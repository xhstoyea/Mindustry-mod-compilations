const library = require("base/library");
const myitems = require("东西/物品");
const 复合刻印厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "复合刻印厂", [
  {
    input: {
    items: ["copper/1","土豆科技-生物塑料/1"],
      power: 2,         
    },                      
    output: {
      items: ["土豆科技-基础电路板/2"],
    },
    craftTime: 20,
  }, 
  {
    input: {
    items: ["土豆科技-基础电路板/1","土豆科技-塑料/2","silicon/2","土豆科技-氮气罐/1"],     
      power: 2,
    },                      
    output: {
      items: ["土豆科技-复合电路板/5"],
    },
    craftTime: 30,
  },
  {
    input: {
    items: ["土豆科技-复合电路板/1","土豆科技-氧气罐/1","土豆科技-塑料/4","土豆科技-氮气罐/2"],
      liquids: ["water/20"],    
      power: 4,         
    },                      
    output: {
      items: ["土豆科技-集成电路板/2"],
    },
    craftTime: 150,
  },   
]);