const library = require("base/library");
const myliquids = require("东西/液体");
const myitems = require("东西/物品");
const 液体中心 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "液体中心", [
  {
     input: {
    liquids: ["土豆科技-重油/100"], 
           },
    output: {
      items: ["土豆科技-重油桶/1"],
            },
    craftTime: 30,
  },
  {
    input: {
    liquids: ["土豆科技-重油/10"], 
    },
    output: {
      items: ["土豆科技-浓缩重油弹/1"],
    },
    craftTime: 30,
  },    
  {
    input: {
    liquids: ["土豆科技-天然气/100"],   
    },
    output: {
      items: ["土豆科技-天然气桶/1"],
    },
    craftTime: 30,
  }, 
  {
    input: {
    liquids: ["土豆科技-轻油/100"],  
    },
    output: {
      items: ["土豆科技-轻油桶/1"],
    },
    craftTime: 30,
  },
  {
    input: {
    liquids: ["water/100"],  
    },
    output: {
      items: ["土豆科技-水桶/1"],
    },
    craftTime: 30,
  },   
  {
    input: {
    items: ["土豆科技-重油桶/1"],  
           },
    output: {
      liquids: ["土豆科技-重油/100"],
            },
    craftTime: 30,
  },
  {
    input: {
    items: ["土豆科技-天然气桶/1"],     
    },
    output: {
      liquids: ["土豆科技-天然气/100"],
    },
    craftTime: 30,
  }, 
  {
    input: {
    items: ["土豆科技-轻油桶/1"],  
    },
    output: {
      liquids: ["土豆科技-轻油/100"],
    },
    craftTime: 30,
  },
  {
    input: {
    items: ["土豆科技-水桶/1"],  
    },
    output: {
      liquids: ["water/100"],
    },
    craftTime: 30,
  },  
]);