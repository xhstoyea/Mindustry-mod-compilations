const library = require("base/library");
const myitems = require("东西/物品");
const 综合冶炼厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "综合冶炼厂", [
  {
    input: {
    items: ["土豆科技-B/2","coal/1"],
      power: 2,         
    },                      
    output: {
      items: ["土豆科技-B4C/2"],
    },
    craftTime: 300,
  },
  {
    input: {
    items: ["scrap/3"],  
      power: 2,                
    },
    output: {
      items: ["土豆科技-Fe/1"],
    },
    craftTime: 120,
  }, 
  {
    input: {
    items: ["土豆科技-单位应力/1"],        
    },                      
    output: {
      power: 2,
    },
    craftTime: 150,
  },
]);