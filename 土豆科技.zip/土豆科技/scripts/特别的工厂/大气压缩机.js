const library = require("base/library");
const myitems = require("东西/物品");
const 大气压缩机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "大气压缩机", [
  {
    input: {
    items: ["copper/1"],
      power: 1,         
    },                      
    output: {
      items: ["土豆科技-氧气罐/1"],
    },
    craftTime: 420,
  },
  {
    input: {
    items: ["copper/1"],     
      power: 1,
    },                      
    output: {
      items: ["土豆科技-氮气罐/1"],
    },
    craftTime: 300,
  },   
  {
    input: {
    items: ["copper/1"],     
      power: 1,
    },                      
    output: {
      items: ["土豆科技-氢气罐/1"],
    },
    craftTime: 400,
  },
  {
    input: {
    items: ["copper/1"],     
      power: 1,
    },                      
    output: {
      items: ["土豆科技-氨气罐/1"],
    },
    craftTime: 540,
  },
  {
    input: {
    items: ["土豆科技-单位应力/1"],        
    },                      
    output: {
      power: 2,
    },
    craftTime: 150,
  },
  
]);