const library = require("base/library");
const myliquids = require("东西/液体");
const myitems = require("东西/物品");
const 综合合成机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "综合合成机", [
  {
    input: {
    items: ["copper/1"],     
    },
    output: {
      items: ["scrap/4"],
    },
    craftTime: 30,
  }, 
  {
    input: {
    items: ["lead/1"],  
    },
    output: {
      items: ["scrap/4"],
    },
    craftTime: 30,
  },
  {
    input: {
    items: ["土豆科技-硫磺罐/1","土豆科技-氢气罐/1"],  
    },
    output: {
      items: ["pyratite/100"],
    liquids: ["water/50"],      
    },
    craftTime: 1000,
  },  
  {
    input: {
    items: ["土豆科技-钢铁/1","copper/1"],
      power: 0.2,	
    },
    output: {
      items: ["土豆科技-标准弹药箱/1"],
    },
    craftTime: 200,
  },    
  {
    input: {
    items: ["土豆科技-钢铁/2","土豆科技-生物塑料/1"],  
	  power: 1.5,
    },
    output: {
      items: ["土豆科技-结构框架/1"],
    },
    craftTime: 300,
  },    
]);