module.exports = [
    'mono', 'poly', 'mega', 'assembly-drone', 'manifold'
]
