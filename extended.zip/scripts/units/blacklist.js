module.exports = [
    'anthicus-missile', 'quell-missile', 'disrupt-missile', 'scathe-missile'
]
