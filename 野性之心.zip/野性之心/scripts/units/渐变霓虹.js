let units = require("units/units");

let ni = units.newUnit("霓虹", MechUnit);
ni.weapons.add(Object.assign(new Weapon("野性之心-霓虹炮"), {
	x: 14,
	y: 1,
	top: false,
	recoil: 2,
	shake: 1,
	shootY: 6,
	reload: 12,
	shootCone: 1,
	cooldownTime: 60,
	shootSound: Sounds.laser,
	bullet: Object.assign(extend(PointBulletType, {}), {
		damage: 21,
		buildingDamageMultiplier:0.75,
		lifetime: 10,
		speed: 15,
		shootEffect: new Effect(20, e => {
			let RGB = new Color(1, 1, 1, 1);
			RGB.fromHsv((Time.globalTime * 3) % 360, 1, 1);
			Draw.color(Color.white, RGB, e.fin());
			Lines.stroke(e.fout() * 1.3 + 0.7);
			Angles.randLenVectors(e.id, 8, 41 * e.fin(), e.rotation, 10, (x, y) => {
				Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 6 + 0.5);
			});
		}),
		trailEffect: new Effect(20, e => {
			let RGB = new Color(1, 1, 1, 1);
			RGB.fromHsv((Time.globalTime * 3) % 360, 1, 1);
			Draw.color(Color.white, RGB, e.fin());
			Lines.stroke(e.fout() * 1.3 + 0.7);
			Lines.lineAngle(e.x, e.y, e.rotation, 10);
		}),
		hitEffect: Fx.dynamicSpikes.wrap(Pal.redLight, 8),
		despawnEffect: Fx.dynamicSpikes.wrap(Pal.redLight, 8)
	})
}))