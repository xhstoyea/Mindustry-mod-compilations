let ability = require("units/ability");

function newUnit(name, unitType) {
	const u = extend(UnitType, name, {});
	u.constructor = () => extend(unitType, {});
	return exports[name] = u;
}
exports.newUnit = newUnit;
/*"flying" -> UnitEntity;
"mech" -> MechUnit;
"legs" -> LegsUnit;
"naval" -> UnitWaterMove;
"payload" -> PayloadUnit;
"missile" -> TimedKillUnit;
"tank" -> TankUnit;
"hover" -> ElevationMoveUnit;
"tether" -> BuildingTetherPayloadUnit;
"crawl" -> CrawlUnit;*/

function parasite(name) {
	let p = extend(UnitType, name, {
		display(unit, table) {
			this.super$display(unit, table);
if (unit.fin() != null)  table.getChildren().get(1).add(new Bar("存活时间", Pal.accent,() => 1 - unit.fin())).row();
		}
	})
	p.constructor = () => extend(TimedKillUnit, {});
	return exports[name] = p;
}
parasite("蝗虫");
parasite("巢虫");

let 驱逐 = newUnit("驱逐",UnitEntity);

驱逐.abilities.add(ability.RotatorAbility("驱逐螺旋桨", 0, 0, 4, 20));

newUnit("薄暮",MechUnit);
newUnit("星矢",MechUnit);

newUnit("开拓",TankUnit);
newUnit("破坏",TankUnit);
newUnit("先锋",TankUnit);
newUnit("灼灭",TankUnit);

newUnit("渡迁",LegsUnit);
newUnit("行际",LegsUnit);
