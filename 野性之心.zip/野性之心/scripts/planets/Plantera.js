const lib = require("base/lib");
const items = require("base/items");
const blocks = require("blocks/先遣核心");

let c1 = Color.valueOf("895841FF");
let c2 = Color.valueOf("623C35FF");
let c3 = Color.valueOf("4D95A3FF"); //水深色
let c4 = Color.valueOf("57ABA2FF"); //水浅色
let c5 = Color.valueOf("72AF3EFF");
let c6 = Color.valueOf("679C39FF");
let c7 = Color.valueOf("88CB4EFF");
let c8 = Color.valueOf("82CD7EFF");
let c9 = Color.valueOf("FFFEF9BF");
let c10 = Color.valueOf("919191FF");

const Plantera = new Planet("Plantera", Planets.sun, 1, 2); //第二个的数值与战役区块数量有关，2=埃克里尔
Plantera.meshLoader = prov(() => new MultiMesh(
	new HexMesh(Plantera, 5) //这个数值与显示的小区块密度有关
));

Plantera.generator = extend(SerpuloPlanetGenerator, {
	arr: [c1, c2, c3, c4, c5, c6, c7, c8],
	allowLanding(sector) {
		return false;
	},
	getColor(position) {
		const noise = (amount, a, b, c) => {
			var n = Simplex.noise3d(this.seed + amount, a, b, c, position.x, position.y, position.z);
			return n
		};
		this.vec = new Vec3(noise(1, 16, 0.2, 8 / 3), noise(6, 72, 0.8, 9 / 2), noise(3, 2, 0.4, 3 / 2));
		var amo = Mathf.round(Mathf.clamp(this.vec.x * this.arr.length, 0, this.arr.length - 1));
		return Tmp.c1.set(this.arr[amo]);
	},
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgZmBmZmDJS8xNZWB7tmDH0/3NDNwpqcXJRZkFJZn5eQwMDGw5iUmpOcUMTNGxjAySL9v7njUsf7KzG6hS92lrx8vGxVBtDAyMIAQkAPPKHwQ=");
	}
});
//星球生成器（塞）
Plantera.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(Plantera, 11, 0.15, 0.13, 5, new Color().set(c9).mul(0.9), 2, 0.45, 0.9, 0.38),
	new HexSkyMesh(Plantera, 1, 0.6, 0.16, 5, Color.white.cpy().lerp(c10, 0.55), 2, 0.45, 1, 0.41))
); //云层

Plantera.visible = true;//可见
Plantera.tidalLock = true;//潮汐锁定
Plantera.accessible = true;//在行星菜单可见
Plantera.alwaysUnlocked = true;//总是解锁
Plantera.defaultCore = blocks.先遣核心;
Plantera.allowLaunchLoadout = false;//可携带初始物资
Plantera.clearSectorOnLose = true; //重置战败区块
Plantera.localizedName = "普兰提亚"; //名字
Plantera.iconColor = Color.valueOf("72AF3EFF");//菜单栏显示颜色
Plantera.bloom = false; //启用Bloom渲染效果
Plantera.startSector = 0; //初始区块
Plantera.orbitRadius = 40; //公转半径
Plantera.orbitTime = 180 * 60; //公转一圈时间
Plantera.rotateTime = 60 * 90; //自转一圈时间
Plantera.atmosphereRadIn = 0.05; //进入大气层距离
Plantera.atmosphereRadOut = 0.2; //离开大气层距离
Plantera.allowWaves = false;//存在后台模拟
Plantera.allowWaveSimulation = false;//存在区块入侵
Plantera.atmosphereColor = Plantera.lightColor = Color.valueOf("6950a1"); //大气层 发光颜色
Plantera.hiddenItems.addAll(
Items.lead,
Items.titanium,
Items.blastCompound,
Items.beryllium,
Items.tungsten,
Items.oxide,
Items.carbide
);
exports.Plantera = Plantera;

//区块
const map1 = new SectorPreset("林中平原", Plantera, 0); //名字 星球 区块
map1.description = "经过漫长的漂流，我们终于找到一处温暖湿润的宜居之地，但显然我们不是第一位客人。\n炼制铁矿，发展科技，抵抗袭击者。";
map1.difficulty = 1; //难度 1-10
map1.alwaysUnlocked = true; //总是解锁
map1.addStartingItems = true; //允许添加初始资源
map1.captureWave = 10; //多少波可占领
map1.localizedName = "林中平原";//显示名字
exports.map1 = map1;

const map2 = new SectorPreset("湍流河谷", Plantera, 36); //名字 星球 区块
map2.description = "顺流而下，我们临近敌人的基地。\n一座废弃的金矿矿脉正坐落于此。\n控制这片地区，开采并研究金矿的使用方法。";
map2.difficulty = 6; //难度 1-10
map2.alwaysUnlocked = false; //总是解锁
map2.addStartingItems = false; //允许添加初始资源
map2.captureWave = 20; //多少波可占领
map2.localizedName = "湍流河谷";//显示名字
exports.map2 = map2;

const mapt1 = new SectorPreset("【塔防模式】壹号地区", Plantera, 35); //名字 星球 区块
mapt1.description = "这处特殊的林区中有一条脆弱的木板栈道，建筑的庞大质量难以坐落其上。敌人派出了小股部队意图利用这点来攻击我方基地。";
mapt1.difficulty = 1; //难度 1-10
mapt1.alwaysUnlocked = false; //总是解锁
mapt1.addStartingItems = false; //允许添加初始资源
mapt1.captureWave = 11; //多少波可占领
mapt1.localizedName = "【塔防模式】壹号地区";//显示名字
exports.mapt1 = mapt1;

const mapt2 = new SectorPreset("【塔防模式】双龙", Plantera, 12); //名字 星球 区块
mapt2.description = "又是一处栈道地区，注意脆弱的木质地板上无法放置建筑，但可以容许单位通过。敌人将在此兵分两路进攻，您又能否将思想一分为二来进行防守呢？";
mapt2.difficulty = 5; //难度 1-10
mapt2.alwaysUnlocked = false; //总是解锁
mapt2.addStartingItems = false; //允许添加初始资源
mapt2.captureWave = 15; //多少波可占领
mapt2.localizedName = "【塔防模式】双龙";//显示名字
exports.mapt2 = mapt2;

const map3 = new SectorPreset("蜿蜒之地", Plantera, 32); //名字 星球 区块
map3.description = "我们占领了一处梭形冲积扇，却遭到了敌人伏击。\n建立你的防线，获取更多资源。";
map3.difficulty = 3; //难度 1-10
map3.alwaysUnlocked = false; //总是解锁
map3.addStartingItems = false; //允许添加初始资源
map3.captureWave = 19; //多少波可占领
map3.localizedName = "蜿蜒之地";//显示名字
exports.map3 = map3;

const map4 = new SectorPreset("轰鸣小径", Plantera, 16); //名字 星球 区块
map4.description = "我们抵达了敌人的前哨基地。\n是时候主动出击了！研究单位工厂，制造战斗单位，占领敌人基地！";
map4.difficulty = 4; //难度 1-10
map4.alwaysUnlocked = false; //总是解锁
map4.addStartingItems = false; //允许添加初始资源
map4.captureWave = 0; //多少波可占领
map4.localizedName = "轰鸣小径";//显示名字
exports.map4 = map4;

/*const mapc1 = new SectorPreset("【指挥官模式】游骑兵出动", Plantera, 63); //名字 星球 区块
mapc1.description = "一支先锋摩托队在丛林中迷失了。击破敌人建筑，夺取信号发生装置以救出他们。注意不要失去全部友方单位，否则本次任务失败。";
mapc1.difficulty = 1; //难度 1-10
mapc1.alwaysUnlocked = false; //总是解锁
mapc1.addStartingItems = false; //允许添加初始资源
mapc1.captureWave = 0; //多少波可占领
mapc1.localizedName = "【指挥官模式】游骑兵出动";//显示名字
exports.mapc1 = mapc1;*/

const map5 = new SectorPreset("遗落前哨", Plantera, 91); //名字 星球 区块
map5.description = "终于抵达我们的目的地。这里严防死守，但也并非无机可寻。灵活生产单位，利用地形优势，摧毁敌人的前哨站。";
map5.difficulty = 5; //难度 1-10
map5.alwaysUnlocked = false; //总是解锁
map5.addStartingItems = false; //允许添加初始资源
map5.captureWave = 0; //多少波可占领
map5.localizedName = "遗落前哨";//显示名字
exports.map5 = map5;

const map6 = new SectorPreset("洞穴闸门", Plantera, 11); //名字 星球 区块
map6.description = "敌人的残余部队逃往这所洞穴。这里环境低矮又黑暗，还需多加准备再前往追击。";
map6.difficulty = 6; //难度 1-10
map6.alwaysUnlocked = false; //总是解锁
map6.addStartingItems = false; //允许添加初始资源
map6.captureWave = 21; //多少波可占领
map6.localizedName = "洞穴闸门";//显示名字
exports.map6 = map6;

const map7 = new SectorPreset("冷水湖", Plantera, 89); //名字 星球 区块
map7.description = "继续向内深入，一座庞大的冷水湖坐落于此。两侧狭窄的道路与交错的桥梁成了敌人进攻的捷径。";
map7.difficulty = 6; //难度 1-10
map7.alwaysUnlocked = false; //总是解锁
map7.addStartingItems = false; //允许添加初始资源
map7.captureWave = 27; //多少波可占领
map7.localizedName = "冷水湖";//显示名字
exports.map7 = map7;

const map8 = new SectorPreset("放射性采集基地", Plantera, 27); //名字 星球 区块
map8.description = "这里是敌人挖掘放射性元素-钍矿石的秘密基地。建造防御工事，夺取此地区，研究新矿物的作用。";
map8.difficulty = 7; //难度 1-10
map8.alwaysUnlocked = false; //总是解锁
map8.addStartingItems = false; //允许添加初始资源
map8.captureWave = 29; //多少波可占领
map8.localizedName = "放射性采集基地";//显示名字
exports.map8 = map8;

const map9 = new SectorPreset("感染温床", Plantera, 43); //名字 星球 区块
map9.description = "洞穴尽头是一处早已损坏的敌人基地。检测到大量孢子培养设施，以及过量的硫元素和氯元素，推测有某种能分泌高腐蚀性酸液的生物居住在此。希望事态不会如我们所想的那般发展。";
map9.difficulty = 7; //难度 1-10
map9.alwaysUnlocked = false; //总是解锁
map9.addStartingItems = false; //允许添加初始资源
map9.captureWave = 20; //多少波可占领
map9.localizedName = "感染温床";//显示名字
exports.map9 = map9;

const map10 = new SectorPreset("裂隙虫道", Plantera, 44); //名字 星球 区块
map10.description = "孢子异虫的释放完全是一场意外，它们原本被用于压制一种更加可怕的未知存在……这下好了，我们要面对的麻烦翻倍了。";
map10.difficulty = 3; //难度 1-10
map10.alwaysUnlocked = false; //总是解锁
map10.addStartingItems = false; //允许添加初始资源
map10.captureWave = 26; //多少波可占领
map10.localizedName = "裂隙虫道";//显示名字
exports.map10 = map10;

const map11 = new SectorPreset("泥泞沼泽", Plantera, 2); //名字 星球 区块
map11.description = "洞穴另一侧的出口将我们带至这片丛林的腹地，一处崎岖幽深的沼泽。敌人在这里还有更多防御工事，他们可能正从沼泽中提取着某种资源。";
map11.difficulty = 6; //难度 1-10
map11.alwaysUnlocked = false; //总是解锁
map11.addStartingItems = false; //允许添加初始资源
map11.captureWave = 0; //多少波可占领
map11.localizedName = "泥泞沼泽";//显示名字
exports.map11 = map11;

const map12 = new SectorPreset("滚烫洞窟", Plantera, 77); //名字 星球 区块
map12.description = "自洞穴深处的灼热熔岩泉中可以提取矿渣液体，水源成了高温地带最稀缺的物资。我们占领了此处唯一的人工热泉，如果足够幸运能守住此地，或许可以建立一座温泉景区……";
map12.difficulty = 7; //难度 1-10
map12.alwaysUnlocked = false; //总是解锁
map12.addStartingItems = false; //允许添加初始资源
map12.captureWave = 24; //多少波可占领
map12.localizedName = "滚烫洞窟";//显示名字
exports.map12 = map12;

const map13 = new SectorPreset("熔火核心", Plantera, 90); //名字 星球 区块
map13.description = "在洞穴的最深处，是千度高温熔岩与其中浮动的碎裂页岩构成的废弃采集营地。占领这片营地，我们将由此建立庞大的后勤中枢，并获取新的终极炮塔设计图纸。";
map13.difficulty = 9; //难度 1-10
map13.alwaysUnlocked = false; //总是解锁
map13.addStartingItems = false; //允许添加初始资源
map13.captureWave = 29; //多少波可占领
map13.localizedName = "熔火核心";//显示名字
exports.map13 = map13;

const maps1 = new SectorPreset("风砂峡谷", Plantera, 41); //名字 星球 区块
maps1.description = "在这颗星球的荒芜之地，遍布风砂的峡谷之中，我们侦测到密集的敌人活动信号。他们似乎在此研究着什么。";
maps1.difficulty = 4; //难度 1-10
maps1.alwaysUnlocked = false; //总是解锁
maps1.addStartingItems = false; //允许添加初始资源
maps1.captureWave = 17; //多少波可占领
maps1.localizedName = "风砂峡谷";//显示名字
exports.maps1 = maps1;

const maps2 = new SectorPreset("焦油苔地", Plantera, 40); //名字 星球 区块
maps2.description = "风砂地区内沉积的古生物尸体经过长年累月的地壳运动，形成了大面积的可开采石油。敌人并不会放弃这一资源，我们也不会。";
maps2.difficulty = 6; //难度 1-10
maps2.alwaysUnlocked = false; //总是解锁
maps2.addStartingItems = false; //允许添加初始资源
maps2.captureWave = 27; //多少波可占领
maps2.localizedName = "焦油苔地";//显示名字
exports.maps2 = maps2;

const maps3 = new SectorPreset("砂丘城堡", Plantera, 39); //名字 星球 区块
maps3.description = "我们的卫星系统锁定了风砂地带的一处盆地，这里坐拥大量资源但地形错综复杂。你能抵抗虎视眈眈的敌人部队吗？";
maps3.difficulty = 7; //难度 1-10
maps3.alwaysUnlocked = false; //总是解锁
maps3.addStartingItems = false; //允许添加初始资源
maps3.captureWave = 27; //多少波可占领
maps3.localizedName = "砂丘城堡";//显示名字
exports.maps3 = maps3;

const mapboss1 = new SectorPreset("银翼的凶星", Plantera, 87); //名字 星球 区块
mapboss1.description = "信号塔矗立于三岔山巅，在帮助我们与轨道卫星取得联络之余也招致了某些异样的存在。起初我们认为那是一颗流星，直到它降落致此，肆意散布灾厄与毁灭。";
mapboss1.difficulty = 10; //难度 1-10
mapboss1.alwaysUnlocked = false; //总是解锁
mapboss1.addStartingItems = false; //允许添加初始资源
mapboss1.captureWave = 37; //多少波可占领
mapboss1.localizedName = "银翼的凶星";//显示名字
exports.mapboss1 = mapboss1;

const mapriv = new SectorPreset("河流两侧", Plantera, 33); //名字 星球 区块
mapriv.description = "我们本应在此设置一处先遣基地，没想到敌人早就在河对岸筑好了防御工事。生产单位摧毁敌方基地，不要拖延太久。";
mapriv.difficulty = 8; //难度 1-10
mapriv.alwaysUnlocked = false; //总是解锁
mapriv.addStartingItems = false; //允许添加初始资源
mapriv.captureWave = 0; //多少波可占领
mapriv.localizedName = "河流两侧";//显示名字
exports.mapriv = mapriv;

const mapmz = new SectorPreset("走迷宫", Plantera, 34); //名字 星球 区块
mapmz.description = "崎岖蜿蜒的草甸构成了此地的天然围墙，如同迷宫一般蜿蜒曲折。敌人会从三个方向同时进攻。占领此地以解锁剪切和萃取纤维的基本技术。";
mapmz.difficulty = 2; //难度 1-10
mapmz.alwaysUnlocked = false; //总是解锁
mapmz.addStartingItems = false; //允许添加初始资源
mapmz.captureWave = 15; //多少波可占领
mapmz.localizedName = "走迷宫";//显示名字
exports.mapmz = mapmz;

const mapt3 = new SectorPreset("【塔防模式】油泥恶地", Plantera, 1); //名字 星球 区块
mapt3.description = "这里的绝大部分地形被焦油隔开，敌人凭借焦油之上的栈桥肆意扩张。无人机平台已经为您建设完毕，利用运输无人机运转资源，完成防御。";
mapt3.difficulty = 7; //难度 1-10
mapt3.alwaysUnlocked = false; //总是解锁
mapt3.addStartingItems = false; //允许添加初始资源
mapt3.captureWave = 20; //多少波可占领
mapt3.localizedName = "【塔防模式】油泥恶地";//显示名字
exports.mapt3 = mapt3;

const mapmg = new SectorPreset("魔钢锻造厂", Plantera, 88); //名字 星球 区块
mapmg.description = "曾被用于研究魔性金属，山铜——奥利哈钢的废弃站点，只要占领此处我们便能抢先一步制造和使用奥利哈钢。";
mapmg.difficulty = 5; //难度 1-10
mapmg.alwaysUnlocked = false; //总是解锁
mapmg.addStartingItems = false; //允许添加初始资源
mapmg.captureWave = 15; //多少波可占领
mapmg.localizedName = "魔钢锻造厂";//显示名字
exports.mapmg = mapmg;

const mapio = new SectorPreset("内与外", Plantera, 15); //名字 星球 区块
mapio.description = "在丛林与砂原的交界之处，我们和敌人争夺这处关隘已久。在被无尽的敌方波次淹没之前尽可能生产塑钢，我们就能向总部发送救援信号。";
mapio.difficulty = 1; //难度 1-10
mapio.alwaysUnlocked = false; //总是解锁
mapio.addStartingItems = false; //允许添加初始资源
mapio.captureWave = 0; //多少波可占领
mapio.localizedName = "内与外";//显示名字
exports.mapio = mapio;