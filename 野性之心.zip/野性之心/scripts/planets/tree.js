const nodeRoot = TechTree.nodeRoot;
const nodeProduce = TechTree.nodeProduce;
const node = TechTree.node;
const SectorComplete = Objectives.SectorComplete;
const Research = Objectives.Research;

const planet = require("planets/Plantera");
const core = require("blocks/先遣核心");
const items = require("base/items");
const liquids = require("base/liquids");
const 力墙限制器 = require("blocks/力墙限制器");

//以下科技树由荔枝VSHES编写并缩进请遵守以下规定：缩进不规范，亲人两行泪。  能自行解读的拆包佬自己看吧

//科技树为node和nodeProduce 
//node为普通节点通常用于方块如node(Blocks.duo,() =>{})
//nodeProduce为生成节点一般用于液体或物品如nodeProduce(Items.copper, () => {})
//科技树的符号千万不能错比如如果后方有更多节点就需要用","符号加在)的后面如果没有则不能加（不然会报错）
//这里以node节点为基础nodeProduce同理 node(Blocks.duo,() =>{}) 这里的{}内就是这个节点的下一个节点,添加节点必须遵守上方的规则且缩进时不应该更改符号顺序
planet.Plantera.techTree = nodeRoot("普兰提亚", core.先遣核心, () => {
	node(planet.map1, () => {
		node(planet.map2, () => {
				node(planet.map4, () => {
					node(planet.map5, () => {
	node(planet.mapriv, () => {})
	node(planet.map6, () => {
	node(planet.map7, () => {
	node(planet.map8, () => {//放射性基地
	node(planet.mapboss1, () => {})
	node(planet.map12, () => {
	node(planet.map13, () => {})
	})
	node(planet.map9, () => {
	node(planet.map10, () => {}),
	node(planet.map11, () => {})
	})
	})
	})
	node(planet.mapmg, () => {})
	})
	})
	//node(planet.mapc1, () => {}),//指挥官1
	node(planet.mapt2, () => {}),//塔防2
	node(planet.maps1, () => {//风砂1
	node(planet.mapio, () => {})//内与外
	node(planet.maps2, () => {//风砂2
	node(planet.mapt3, () => {}),//塔防3
	node(planet.maps3, () => {})//风砂3
	})
	})
	})
	node(planet.mapmz, () => {})
	}),
	node(planet.map3, () => {}),
	node(planet.mapt1, () => {})
	}),
	//node(力墙限制器.力墙限制器, () => {}),
	nodeProduce(Items.copper, () => {
		nodeProduce(items.金, () => {}),
		nodeProduce(items.纤维织物, () => {
			nodeProduce(items.蓝藻, () => {})
		}),
		nodeProduce(Liquids.water, () => {
			nodeProduce(Liquids.cryofluid, () => {
				nodeProduce(liquids.精油, () => {}),
				nodeProduce(liquids.孢子毒素, () => {})
			})
		}),
		nodeProduce(Items.sand, () => {
			nodeProduce(Items.scrap, () => {
				nodeProduce(Liquids.slag, () => {})
			}),
			nodeProduce(Items.coal, () => {
				nodeProduce(Items.graphite, () => {
					nodeProduce(Items.silicon, () => {})
				}),
				nodeProduce(Items.pyratite, () => {
					nodeProduce(Items.blastCompound, () => {})
				}),
				nodeProduce(Items.sporePod, () => {
					nodeProduce(items.凝胶, () => {})
				}),
				nodeProduce(Liquids.oil, () => {
					nodeProduce(Items.plastanium, () => {})
				})
			})
		}),
		nodeProduce(items.铁矿石, () => {
			nodeProduce(Items.metaglass, () => {}),
			nodeProduce(items.钢铁, () => {
				nodeProduce(items.光合合金, () => {}),
				nodeProduce(Items.thorium, () => {
					nodeProduce(Items.surgeAlloy, () => {}),
					nodeProduce(Items.phaseFabric, () => {})
				})
			})
		})
	})
})