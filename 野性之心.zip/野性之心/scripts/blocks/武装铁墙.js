//作者VSHES/荔枝 qq2595168568 未经允许禁止私自使用
const wz = new ItemTurret('武装铁墙');
wz.configurable = true;
wz.solid = true;
wz.destructible = true;
wz.update = true;
wz.buildType = prov(() => extend(ItemTurret.ItemTurretBuild, wz, {
	i: 0,
	handleItem(source, item) {
		this.super$handleItem(source, item);
	},
	update() {
		this.super$update();
		if (this.i <= 10) {
			this.handleItem(this, Items.coal);
			this.i += 1;
		}
	}
}));
exports.wz = wz;