function setAttribute(block, attribute, amount) {
	return block.attributes.set(Attribute.get(attribute), amount);
}

const 丛林墙 = new StaticWall("1-丛林墙");
setAttribute(丛林墙, "grass", 1);

const 沼泽墙 = new StaticWall("沼泽墙");
setAttribute(沼泽墙, "grass", 1.2);

const 苔藓墙 = new StaticWall("苔藓墙");
setAttribute(苔藓墙, "grass", 0.8);

let f切叶机 = new WallCrafter("f切叶机");
f切叶机.attribute = Attribute.get("grass");

setAttribute(Blocks.shrubs, "grass", 0.8);