//以下注释为VSHES荔枝独立完成为了让其他开发者同样可以更新开屏显示窗口插件
Events.on(EventType.ClientLoadEvent, cons(e => {
	var dialog = new BaseDialog("野性之心");//新建一个显示窗口
	var dialogg = new BaseDialog("作者目录");
	
	dialog.buttons.button("@close", run(() => {
		dialog.hide()//退出此界面
	})).size(64, 64);//按钮用原版@close贴图
	
	dialogg.buttons.button("@close", run(() => {
		dialogg.hide();
		dialog.show();
		//退出此界面
	})).size(64, 64);//按钮用原版@close贴图
	
	dialog.buttons.button("[#FFD37FFF]更新日志", run(() => {
		var dialog2 = new BaseDialog("更新日志");
		dialog2.cont.pane((() => {
			var table = new Table();
			table.add(Core.bundle.format("text-updata")).left().growX().wrap().width(340).maxWidth(340).pad(4).labelAlign(Align.left);
			table.row();
			return table;
		})()).grow().center().maxWidth(340);
		dialog2.buttons.defaults().size(210, 64);
		dialog2.addCloseButton();
		dialog2.show();
	})).size(210, 64);
	
	dialog.cont.button("作者目录",run(() => {
               dialog.hide();
               dialogg.show();
             })).size(80,70);
	
	 dialog.cont.button("加入野性之心qq群",run(() => {
               Core.app.openURI("https://jq.qq.com/?_wv=1027&k=Gg4ck0dj");
             })).size(110,70).pad(2);//添加qq群功能为荔枝VSHES添加
              
          dialogg.cont.add("作者目录"); 
              
             	dialogg.cont.pane(table => {//滑动显示
			table.add(Core.bundle.get("mod.modMaker")).left().growX().wrap().width(620).maxWidth(620).pad(4).labelAlign(Align.left)//读取翻译文件
	}).grow().center().maxWidth(620)
             
             dialog.show();
}))
