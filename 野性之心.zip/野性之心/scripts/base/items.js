exports.铁矿石 = new Item('铁矿石');
exports.钢铁 = new Item('钢铁');
exports.凝胶 = new Item('凝胶');
exports.金 = new Item('金');
exports.纤维织物 = new Item('纤维织物');
exports.光合合金 = new Item('光合合金');
exports.蓝藻 = new Item('蓝藻');
//exports.json物品名字 = new Item('json物品名字');