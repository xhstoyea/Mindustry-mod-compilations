const DrillBuild = Drill.DrillBuild;
//代码作者miner
//抄袭者久远的屑
//感谢920大佬帮忙纠错
var heatRequirement = 5;
var overheatScale = 1;
var maxEfficiency = 5;

let 热量钻头 = Object.assign(extend(Drill, "热量钻头", {
    setBars(){
        this.super$setBars();
        
        this.addBar("heat", e => new Bar(
            () => Core.bundle.format("bar.heatpercent", parseInt(e.heat()), parseInt(e.efficiencyScale() * 100)),
            () => Pal.lightOrange,
            () => parseInt(e.heat()) / heatRequirement));
    },
}), {
    size: 4,
    drillTime: 8000,
    tier:8,
});

/** setupRequirements: 三个愿望 一次满足(误
* 参数1: 设置category
* 参数2: 设置buildVisibility
* 参数3: 设置requirements
*/
热量钻头.setupRequirements(
    Category.production,//在界面的哪个地方出现
    BuildVisibility.shown,
    ItemStack.with(Items.beryllium, 200, Items.oxide, 150,Items.phaseFabric,45)//制造需要消耗什么物品
);

var block =热量钻头;

热量钻头.buildType = () => {
    let sideHeat = new Array(4);
    let heat = 0;

    /** JavaAdapter: 
    * 主类(DrillBuild), 
    * 接口(HeatConsumer), 
    * 实现({...}), 
    * 构造函数的参数(heatDrill)
    *
    * 注意 extend函数其实也是用JavaAdapter 其区别在于:
    * extend无法实现接口,只能继承主类(这也是anuke给extend的本意
    */
    let build = new JavaAdapter(DrillBuild, HeatConsumer, {
        /** 这里是HeatConsumer需要实现的方法
        * float[] sideHeat();
        * float heatRequirement();
        */
    
        sideHeat(){
            return sideHeat;
        },
        
        heatRequirement(){
            return heatRequirement;
        },
        
        updateTile(){
            heat = this.calculateHeat(sideHeat);

            this.super$updateTile();
        },
        
        warmupTarget(){
            return Mathf.clamp(heat / heatRequirement);
        },
        
        // 这个为什么动不了啊! 肯定是anuke的问题!
        // 新版本又能用了¿¿¿
        updateEfficiencyMultiplier(){
            this.super$updateEfficiencyMultiplier();
            
            let es = this.efficiencyScale();
        
            this.potentialEfficiency *= es;
        },

        efficiencyScale(){
            let over = Math.max(heat - heatRequirement, 0);
            return Math.min(Mathf.clamp(heat / heatRequirement) + over / heatRequirement * overheatScale, maxEfficiency);
        },//吃热越多效率越高，但是会有一个上限
        
        // 获取热量
        heat(){
            return heat;
        },
        
    }, block);
    
    return build;
}

