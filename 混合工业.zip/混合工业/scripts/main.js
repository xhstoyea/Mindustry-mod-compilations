require("核心/赛普罗/备用核心")
require("钻头/埃里克尔/热量钻头")