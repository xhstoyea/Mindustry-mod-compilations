const 备用核心 = extend(CoreBlock, "备用核心", {
    
    canBreak() { return Vars.state.teams.cores(Vars.player.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) { return true; },
});
exports.备用核心 = 备用核心;