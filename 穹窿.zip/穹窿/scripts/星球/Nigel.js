const lib = require("base/lib");

const Nigel = new Planet("尼格拉", Planets.sun, 1, 3.2);
Nigel.meshLoader = prov(() => new MultiMesh(
	new HexMesh(Nigel, 8)
));
Nigel.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(Nigel, 2, 0.15, 0.14, 5, Color.valueOf("FFD864FF"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(Nigel, 3, 0.6, 0.15, 5, Color.valueOf("EAC658FF"), 2, 0.42, 1.2, 0.45)
));
Nigel.generator = new SerpuloPlanetGenerator();
Nigel.visible = Nigel.accessible = Nigel.alwaysUnlocked =  true;
Nigel.clearSectorOnLose = false;
Nigel.tidalLock = false;
Nigel.localizedName = "尼格拉";
Nigel.bloom = false;
Nigel.startSector = 1;
Nigel.orbitRadius = 95;
Nigel.orbitTime = 180 * 60;
Nigel.rotateTime = 90 * 60;
Nigel.atmosphereRadIn = 0.02;
Nigel.atmosphereRadOut = 0.3;
Nigel.atmosphereColor = Nigel.lightColor = Color.valueOf("FF5E5EFF");
Nigel.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);

const 预定降落区 = new SectorPreset("预定降落区", mars, 1);
预定降落区.description = "我们预定好的一个降落区域，这里仅拥有一小只巡逻部队，以及丰富的矿石。做好过渡，准备出发";
预定降落区.difficulty = 1;
预定降落区.alwaysUnlocked = true;
预定降落区.addStartingItems = true;
预定降落区.captureWave = 1;
预定降落区.localizedName = "预定降落区";
exports.预定降落区 = 预定降落区;
lib.addToResearch(预定降落区, {
	parent: "groundZero",
	objectives: Seq.with(
	new Objectives.SectorComplete(SectorPresets.groundZero))
});
