MapResizeDialog.minSize = 0;
MapResizeDialog.maxSize = 10001;
require('星球/Nigel');
require('辅助/材料颜色');
require('辅助/缩放强化');
require('辅助/时间控制');
require('辅助/资源显示');
