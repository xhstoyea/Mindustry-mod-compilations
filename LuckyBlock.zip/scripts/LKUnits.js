const lib = require("LKlib");

function spawnUnit(build,unitSeq){
  let type = unitSeq.get(Math.floor(Math.random() * unitSeq.size));
  if(!Vars.world.tile(build.tileX(),build.tileY()).floor.isLiquid && type instanceof WaterMovec){
    spawnUnit(build,unitSeq);
    return ;
  }
  type.spawn(build.team,build.x,build.y);
}

const 初级单位幸运方块 = lib.LuckyBlock("初级单位幸运方块");
初级单位幸运方块.size = 1;
初级单位幸运方块.setupRequirements(Category.effect,ItemStack.with(
  Items.copper,100
));

初级单位幸运方块.buildType = () => {
  let 抽取单位集 = lib.setUnitSeq(1,1200);
  return extend(Wall.WallBuild,初级单位幸运方块,{
    updateTile(){
      Vars.world.tile(this.tileX(),this.tileY()).setBlock(Blocks.air,this.team);
      spawnUnit(this,抽取单位集);
    }
  })
}

exports.初级单位幸运方块 = 初级单位幸运方块;

const 中级单位幸运方块 = lib.LuckyBlock("中级单位幸运方块");
中级单位幸运方块.size = 1;
中级单位幸运方块.setupRequirements(Category.effect,ItemStack.with(
  Items.copper,300
));

中级单位幸运方块.buildType = () => {
  let 抽取单位集 = lib.setUnitSeq(800,8000);
  return extend(Wall.WallBuild,中级单位幸运方块,{
    updateTile(){
      Vars.world.tile(this.tileX(),this.tileY()).setBlock(Blocks.air,this.team);
      spawnUnit(this,抽取单位集);
    }
  })
}

exports.中级单位幸运方块 = 中级单位幸运方块;

const 高级单位幸运方块 = lib.LuckyBlock("高级单位幸运方块");
高级单位幸运方块.size = 1;
高级单位幸运方块.setupRequirements(Category.effect,ItemStack.with(
  Items.copper,1000
));

高级单位幸运方块.buildType = () => {
  let 抽取单位集 = lib.setUnitSeq(6000,51200);
  return extend(Wall.WallBuild,高级单位幸运方块,{
    updateTile(){
      Vars.world.tile(this.tileX(),this.tileY()).setBlock(Blocks.air,this.team);
      let type = 抽取单位集.get(Math.floor(Math.random() * 抽取单位集.size));
      type.spawn(this.team,this.x,this.y);
    }
  })
}

exports.高级单位幸运方块 = 高级单位幸运方块;

const 终极单位幸运方块 = lib.LuckyBlock("终极单位幸运方块");
终极单位幸运方块.size = 1;
终极单位幸运方块.setupRequirements(Category.effect,ItemStack.with(
  Items.copper,10000
));

终极单位幸运方块.buildType = () => {
  let 抽取单位集 = lib.skyIsLimit(24000);
  return extend(Wall.WallBuild,终极单位幸运方块,{
    updateTile(){
      Vars.world.tile(this.tileX(),this.tileY()).setBlock(Blocks.air,this.team);
      let type = 抽取单位集.get(Math.floor(Math.random() * 抽取单位集.size));
      print(抽取单位集.size);
      type.spawn(this.team,this.x,this.y);
    }
  })
}

exports.终极单位幸运方块 = 终极单位幸运方块;