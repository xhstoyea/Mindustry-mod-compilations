let 原始方块集 = Vars.content.blocks().copy();
let 原始单位集 = Vars.content.units().copy();

Events.on(ContentInitEvent,e => {
  原始方块集 = Vars.content.blocks().copy();
  原始单位集 = Vars.content.units().copy();
});

原始方块集.each(block => {
  if(block instanceof SpawnBlock) 原始方块集.remove(block);
});
原始方块集.remove(Blocks.air);

function LuckyBlock(name){
  return extend(Wall,name,{
    health : 20,
    update : true,
    alwaysUnlocked : true,

    isVisible: function () {
      return true;
    },
    isPlaceable: function () {
      return true;
    }
  });
}
exports.LuckyBlock = (name) => LuckyBlock(name);

function setSeq(size){
  let 目标方块集 = new Seq();
  原始方块集.each(block => {
    if(block.size == size) 目标方块集.add(block);
  });
  return 目标方块集;
}
exports.setSeq = (size) => setSeq(size);

function setAimSeq(size,type){
  let 目标方块集 = new Seq();
  原始方块集.each(block => {
    if(block.size == size && block instanceof type) 目标方块集.add(block);
  });
  return 目标方块集;
}

exports.setAimSeq = (size,type) => setAimSeq(size,type);

function setUnitSeq(min,max){
  let 目标单位集 = new Seq();
  原始单位集.each(unit => {
    if(unit.health > min && unit.health < max) 目标单位集.add(unit);
  });
  return 目标单位集;
}

exports.setUnitSeq = (min,max) => setUnitSeq(min,max);

function skyIsLimit(min){
  let 目标单位集 = new Seq();
  原始单位集.each(unit => {
    if(unit.health > min) 目标单位集.add(unit);
  });
  return 目标单位集;
}

exports.skyIsLimit = (min) => skyIsLimit(min);