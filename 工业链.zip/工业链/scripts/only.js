var ax = extend(UnitType, '简陋矿机', {});
ax.controller = () => new MinerAI();
ax.constructor = prov(() => extend(UnitTypes.mono.constructor.get().class, {}));

const 迷你核心 = extend(CoreBlock,"迷你核心",{
	canPlaceOn(tile,team,rotation){
        return true;
    },
    canBreak(tile) {
		return Vars.state.teams.cores(tile.team()).size > 1;
	}
})

迷你核心.buildType = prov(() => {
	return extend(CoreBlock.CoreBuild, 迷你核心, {
		onRemoved(){
			var total = this.proximity.count( e => e.items != null && e.items == items);
            var fract = 1 / total / Vars.state.teams.cores(this.team).size;

            this.proximity.each( e => this.owns(e) && e.items == this.items && this.owns(e), t => {
            	t = new StorageBuild();
                var ent = t;
                ent.linkedCore = null;
                ent.items = new ItemModule();
                for( item in this.content.items()){
                    ent.items.set(item, (fract * items.get(item)));
                }
            });
            Vars.state.teams.unregisterCore(this);
            /*
            js检查器告诉我getClass()没有onProximityUpdate()是个什么鬼啊
            莫名其妙就成strict mode了
            麻
            这段有用的话就把最后一点算不上bug的bug消灭了啊嗷嗷嗷嗷嗷嗷嗷嗷
            for( var other in Vars.state.teams.cores(this.team) ){
                other.onProximityUpdate();
            };
            */
		}
	})
});