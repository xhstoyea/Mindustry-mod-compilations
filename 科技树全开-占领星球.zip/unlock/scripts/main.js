const modName = "科技树全开";

Events.on(EventType.ClientLoadEvent, e => {
    let dialog = new BaseDialog(modName);
    
    let labels = [
        new FLabel("[yellow]miner:"),
        new FLabel("欢迎使用[cyan]" + modName + "[white]Mod"),
        new FLabel("使用本Mod可能会[red]导致之前的存档丢失,务必备份好数据!"),
        new FLabel("[red]请认真思考!"),
    ];
    
    dialog.cont.table(Tex.pane, t => {
        t.table(null, labelTable => {
            labelTable.defaults().left();
            
            labels.forEach((label) => {
                labelTable.add(label).row();
                label.pause();
            })
        }).row();
        
        let unlockCons = null;
        
        t.table(null, tt => {
            tt.add("[cyan]请选择您的解锁方式:").labelAlign(Align.left).left().row();
            
            tt.table(null, buttons => {
                let addButton = (text, cons) => {
                    buttons.button(text, Styles.flatToggleMenut, () => {
                        unlockCons = cons;
                    }).minHeight(65).growX().checked(b => unlockCons == cons);
                }
                
                addButton("仅解锁科技树", () => {
                    unlock();
                });
                
                addButton("仅占领星球", () => {
                    capturePlanets();
                    capturePlanets();
                });
                
                addButton("我全都要!", () => {
                    unlock();
                    capturePlanets();
                    capturePlanets();
                });
            }).growX();
        }).growX().row();
        
        t.table(null, buttons => {
            buttons.button("我还没考虑好!", () => {
                dialog.hide();
            }).growX();
            
            let time = 60 * 3.75;
            let text = "解锁并禁用Mod!";
            
            buttons.button("", () => {
                unlockCons();
                
                /* 使用完毕,自动关闭 */
	            Core.settings.put("mod-" + modName + "-enabled", false);
	            
                dialog.hide();
            }).disabled(b => time > 0 || unlockCons == null).growX().update(b => {
                let t = "";
            
                if(time > 0){
                    t = "(" + parseInt(time / 60) + "s" + ")";
                }
                
                b.setText(text + t);
            });
            
            buttons.update(() => {
                if(time >= 0){
                    time -= Time.delta;
                }
            });
        }).padTop(5).growX();
    });
    
    dialog.show();
    
    Timer.schedule(() => labels.forEach((label) => {
        label.resume();
    }), 0.75);
});

function unlock(){
    Vars.content.each(content => {
    	if(content instanceof UnlockableContent) content.unlock();
	})
}

function capturePlanets(){
    let state = Vars.state;
	let rules = state.rules;
	let saves = Vars.control.saves;
	
    Vars.content.planets().each(p => p.sectors.each(s => {
		let info = s.info;
		info.wasCaptured = true;
		info.hasCore = true;
		
		rules.sector = s;
		
		if(!s.hasSave()){
			state.wave = 999;
			saves.saveSector(s);
		}
		
		s.saveInfo();
	}));
}