
const MultipleTurrets = extend(Wall, "砖墙", {configurable: true});

MultipleTurrets.buildVisibility = BuildVisibility.shown;
MultipleTurrets.category = Category.logic;

//这是必需的
MultipleTurrets.update = true;
//设置方块可使用物品
MultipleTurrets.hasItems = true;

//设置可使用的弹药
const TItems = [Items.pyratite,Items.pyratite,Items.pyratite,Items.pyratite]

MultipleTurrets.buildType = prov(() => {
	//创建多炮塔
	//(方块，队伍(不需要设置))
	let payloads = [
		new BuildPayload(Blocks.scorch, Team.derelict),
		new BuildPayload(Blocks.scorch, Team.derelict),
	    ];
    let ti = 0,speed = 1,dr=true
	const build = extend(Wall.WallBuild, MultipleTurrets,{
	
	buildConfiguration(table) {
	   
	    table.button(Core.atlas.drawable(Blocks.scorch.uiIcon), Styles.cleari, run(() => {
        payloads = [
		new BuildPayload(Blocks.scorch, Team.derelict),
		new BuildPayload(Blocks.scorch, Team.derelict),
	    ];
        })).size(50);
        
        table.button(Core.atlas.drawable(Blocks.hail.uiIcon), Styles.cleari, run(() => {
        payloads = [
		new BuildPayload(Blocks.hail, Team.derelict),
		new BuildPayload(Blocks.hail, Team.derelict),
	    ];
        })).size(50);
        
        table.row();
        
        table.button(Icon.upOpen, Styles.cleari, run(() => {
		speed += 0.5
        })).size(50);
        
        table.button(Icon.downOpen, Styles.cleari, run(() => {
		speed -= 0.5
        })).size(50);
        
        table.row();
        
        table.button(Icon.spray, Styles.cleari, run(() => {
		dr = !dr
        })).size(50);
        },
    
		//设置方块进入物品规则
		//你们可以自己设置规则
		acceptItem(source, item) {
			for(var i = 0; i < TItems.length; i++){
				if(TItems[i] == item){
					if(this.items.get(TItems[i]) < this.block.itemCapacity){
						return true;
					}
				}
			}

            return false;
        },
        
		updateTile() {
			this.super$updateTile();
            ti++
            payloads[0].set(this.x + 0, this.y + 0, payloads[0].build.payloadRotation);
            
			//可以让炮塔转起来的代码
			//删除注释以使用
			for (var i = 0; i < payloads.length; i++) {
                var t = payloads[i];
                var rotation = (360.0 / payloads.length) * i + ti*speed;

				//这里的24为距离本体方块中心的多少距离旋转(8为1格)
                t.set(this.x + Angles.trnsx(rotation, Math.sin(ti/50)*8+16), this.y + Angles.trnsy(rotation, Math.sin(ti/50)*8+16), t.build.payloadRotation);
            }
            
			//设置模块
			for(var id = 0; id < payloads.length; id++){
				//设置队伍，如果在上面的创建位置设置，无用
                if(payloads[id].build.team != this.team){
                    payloads[id].build.team = this.team;
                }
				//执行炮塔更新
                payloads[id].update(null, this);

				//为物品炮塔添加弹药
				//你们需要可自己定义
				for(var i = 0; i < TItems.length; i++){
					if(payloads[id].build.acceptItem(payloads[id].build, TItems[i]) && this.items.get(TItems[i]) >= 1) {
						payloads[id].build.handleItem(payloads[id].build, TItems[i]);
						this.items.remove(TItems[i], 1);
					}
				}
            }

		},
		draw(){
			this.super$draw();
            if(dr){
			//执行多炮塔的动画
			    for(var i = 0; i < payloads.length; i++){
                    payloads[i].draw();
                }
            }
		},
	}
);

	return build;
});