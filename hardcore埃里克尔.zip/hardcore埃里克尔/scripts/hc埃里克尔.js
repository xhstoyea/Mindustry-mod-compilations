const lib = require("lib");
const hc埃里克尔 = new Planet("hc埃里克尔", Planets.sun, 1, 2.1);
hc埃里克尔.meshLoader = prov(() => new MultiMesh(
	new HexMesh(hc埃里克尔, 7)
));
hc埃里克尔.generator = extend(ErekirPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgYWBhZmDJS8xNZeB5Or/v6YKFzxbseLq/mYE7JbU4uSizoCQzP4+BgYEtJzEpNaeYgSk6lpGBJzm/KFU3KbEYKskIQkACAAynFxI=")
	}
});
hc埃里克尔.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(hc埃里克尔, 2, 0.15, 0.14, 5, Color.valueOf("7A540CFF"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(hc埃里克尔, 3, 0.6, 0.15, 5, Color.valueOf("7A540CFF"), 2, 0.42, 1.2, 0.45)
));
hc埃里克尔.generator = new ErekirPlanetGenerator();
hc埃里克尔.visible = hc埃里克尔.accessible = hc埃里克尔.alwaysUnlocked = true;
hc埃里克尔.clearSectorOnLose = false;
hc埃里克尔.tidalLock = false;
hc埃里克尔.defaultAttributes.set(Attribute.heat, 0.8);
hc埃里克尔.updateLighting = false;
hc埃里克尔.lightSrcTo = 0.5;
hc埃里克尔.allowLaunchToNumbered = false
hc埃里克尔.lightDstFrom = 0.2;
hc埃里克尔.defaultEnv = Env.scorching | Env.terrestrial;
hc埃里克尔.defaultCore = Blocks.coreBastion;
hc埃里克尔.localizedName = "hc埃里克尔";
hc埃里克尔.prebuildBase = true;
hc埃里克尔.bloom = false;
hc埃里克尔.startSector = 2;
hc埃里克尔.orbitRadius = 85;
hc埃里克尔.orbitRadius = 85;
hc埃里克尔.clearSectorOnLose = true;
hc埃里克尔.atmosphereRadIn = 0.02;
hc埃里克尔.atmosphereRadOut = 0.3;
hc埃里克尔.atmosphereColor = hc埃里克尔.lightColor = Color.valueOf("7A540CFF");
hc埃里克尔.iconColor = Color.valueOf("7A540CFF"),
hc埃里克尔.hiddenItems.addAll(Items.serpuloItems).removeAll(Items.erekirItems);

const hc始发地区 = new SectorPreset("hc始发地区", hc埃里克尔, 2);
hc始发地区.alwaysUnlocked = false;
hc始发地区.difficulty = 2;
hc始发地区.localizedName = "hc始发地区";
exports.hc始发地区 = hc始发地区;
lib.addToResearch(hc始发地区, {
	parent: "origin",
	objectives: Seq.with(
	new Objectives.SectorComplete(SectorPresets.origin))
});

const hc庇护前哨 = new SectorPreset("hc庇护前哨", hc埃里克尔, 88);
hc庇护前哨.alwaysUnlocked = false;
hc庇护前哨.difficulty = 2;
hc庇护前哨.localizedName = "hc庇护前哨";
exports.hc庇护前哨 = hc庇护前哨;
lib.addToResearch(hc庇护前哨, {
    parent: "hc始发地区",
    objectives: Seq.with(
        new Objectives.SectorComplete(hc始发地区))
});

const hc岩浆湖 = new SectorPreset("hc岩浆湖", hc埃里克尔, 41);
hc岩浆湖.alwaysUnlocked = false;
hc岩浆湖.difficulty = 2;
hc岩浆湖.localizedName = "hc岩浆湖";
exports.hc岩浆湖 = hc岩浆湖;
lib.addToResearch(hc岩浆湖, {
    parent: "hc庇护前哨",
    objectives: Seq.with(
        new Objectives.SectorComplete(hc庇护前哨))
});

const hc交错丘陵 = new SectorPreset("hc交错丘陵", hc埃里克尔, 36);
hc交错丘陵.captureWave = 50;
hc交错丘陵.alwaysUnlocked = false;
hc交错丘陵.difficulty = 6;
hc交错丘陵.localizedName = "hc交错丘陵";
exports.hc交错丘陵 = hc交错丘陵;
lib.addToResearch(hc交错丘陵, {
    parent: hc庇护前哨,
    objectives: Seq.with(
        new Objectives.SectorComplete(hc庇护前哨))
});