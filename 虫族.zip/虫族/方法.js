
Angles.trnsx(旋转角, x, y);
Angles.trnsy(旋转角, x, y);//用于计算旋转后的位置

Mathf.chance(true的概率)
Mathf.range(波动范围);//结果从波动范围 到 -波动范围

Units.nearby(队伍,x,y,范围,other => {})//查找范围内单位
Units.nearbyBuildings(x,y,范围,b => {})//查找范围内建筑

Time.time//游戏时间
i += Time.delta//计时器

Core.atlas.find("bugs-gredizion"))//获取贴图
Core.bundle.get("report-1")//从bundles里找文本
Core.app.openURI("https://430230562.github.io/zerg")//打开网站

Vars.state.teams.cores(tile.team()).size//核心数量
Vars.ui.showLabel(显示文本, 0.01, this.x, this.y);

xx.items.add(物品, 数量);//建筑加物品
build.items.get(Items.copper);//建筑物品量

Core.app.exit()

bullet.create(this,队伍,x,y,旋转角度)//生成子弹

//tile
this.tile.circle(范围, cons(tile => {}))//查找范围内的地块,并保存在tile中
block()//地块上的建筑
setBlock(建筑,队伍)//设置地块上的建筑,Team.sharded为黄队
setAir();//清除地块上的建筑
setFloor();//设置地板

Vars.world.tile(tileX,tileY)//指定坐标地块

Puddles.deposit(tile, liquid, amount * scaling);//地板上生成液体

//unit
unit.spawn(队伍,x,y)

heal(治疗量)

damagePierce(伤害量)//无视护甲
damage(伤害量)//不无视护甲

apply(效果,时间)//给单位效果

Fires.create(unit.tileOn())//放火
collision(other, x, y)//单位被击中

//draw
Lines.arc(x,y,范围,0.15/*应该是线宽*/,旋转角度);
Draw.rect(贴图,x,y,旋转角度)

//bullet
hitEntity(b, entity, health){
    this.super$hitEntity(b, entity, health);
    if(entity instanceof Unit) {
        var unit = entity;
    }
},//击中单位