Events.on(EventType.ClientLoadEvent, e => {
	MapResizeDialog.minSize = 1; // 过小小心崩溃
	MapResizeDialog.maxSize = java.lang.Integer.MAX_VALUE; // 过大小心卡死
	
	let editor = Vars.ui.editor;
	let resizeDialog = Reflect.get(editor, "resizeDialog");
	let cont = resizeDialog.cont;
	
	resizeDialog.shown(() => {
		let table = resizeDialog.cont.getChildren().get(0);
		
		table.getCells().each(cell => {
		    cell.maxTextLength(java.lang.Integer.MAX_VALUE);
		});
	});
});