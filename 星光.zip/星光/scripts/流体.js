function newLiquid(name) {
	exports[name] = (() => {
		let myLiquid = extend(Liquid, name, {});
		return myLiquid;
	})();
}
newLiquid("盐卤水")
newLiquid("氯气")
newLiquid("电镀液")
newLiquid("液氮")
newLiquid("压缩空气")
newLiquid("磺基重油")