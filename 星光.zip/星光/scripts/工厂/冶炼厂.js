const library = require("library");
const myitems = require("物品");
const 冶炼厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "冶炼厂", [
  {
    input: {
      items: ["tr-锰/1","tr-铝/1"],   
     power:2.5
    },
    output: {
      items: ["tr-合金钢/1"],
    },
    craftTime:60,
  }, 
    {
    input: {
      items: ["sand/1","tr-焦炭/1"],     
      power:2
    },
    output: {
      items: ["silicon/1"],
    },
    craftTime:40
  },  
  {
    input: {
      items: ["sand/1","tr-硫/1"],     
      power:2
    },
    output: {
      items: ["silicon/1"],
    },
    craftTime:40
  },  
]);