const library = require("library");
const myliquids = require("流体");
const myitems = require("物品");
const 有机聚合室 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "有机聚合室", [
 {
    input: { 
      liquids: ["arkycite/4","ozone/4","tr-磺基重油/8"],
      power:2.5
    },
    output: {
      items: ["blast-compound/2"],
    },
    craftTime:60
  }, 
   {
    input: { 
      liquids: ["arkycite/4","nitrogen/4","tr-磺基重油/8"],
      power:2.5
    },
    output: {
      items: ["tr-硝化混合物/2"],
    },
    craftTime:60
  }, 
  {
    input: { 
      liquids: ["arkycite/4","cyanogen/4","tr-磺基重油/8"],
      power:2.5
    },
    output: {
      items: ["tr-氰化混合物/2"],
    },
    craftTime:60
  }, 
])