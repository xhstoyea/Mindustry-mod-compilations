const library = require("library");
const myliquids = require("流体");
const myitems = require("物品");
const 地下钻井平台 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "地下钻井平台", [
  {
    input: { 
      liquids: ["hydrogen/180"],
      power:25
    },
    output: {
      items: ["tr-硫/60"],
    },
    craftTime:480
  }, 
    {
    input: { 
      liquids: ["hydrogen/180"],
      power:25
    },
    output: {
      items: ["tr-焦炭/60"],
    },
    craftTime:480
  }, 
  {
    input: { 
      liquids: ["hydrogen/300"],
      power:25
    },
    output: {
      items: ["tr-锰/60"],
    },
    craftTime:720
  }, 
  {
    input: { 
      liquids: ["hydrogen/300"],
      power:25
    },
    output: {
      items: ["tr-铝/60"],
    },
    craftTime:720
  }, 
    {
    input: { 
      liquids: ["hydrogen/450"],
      power:25
    },
    output: {
      items: ["tr-银/60"],
    },
    craftTime:900
  }, 
  {
    input: { 
      liquids: ["hydrogen/450"],
      power:25
    },
    output: {
      items: ["tr-铟/60"],
    },
    craftTime:900
  }, 
      {
    input: { 
      liquids: ["hydrogen/450"],
      power:25
    },
    output: {
      items: ["tr-铬/60"],
    },
    craftTime:900
  }, 
      {
    input: { 
      liquids: ["hydrogen/450"],
      power:25
    },
    output: {
      items: ["tungsten/60"],
    },
    craftTime:900
  }, 
      {
    input: { 
      liquids: ["hydrogen/600"],
      power:25
    },
    output: {
      items: ["tr-铱/60"],
    },
    craftTime:1200
  }, 
  {
    input: { 
      liquids: ["hydrogen/600"],
      power:25
    },
    output: {
      items: ["tr-锇/60"],
    },
    craftTime:1200
  }, 
]);