//卸载速度
const amount = 10;

var centerRegion, topRegion, arrowRegion;
const liquidUnloader = extend(Conduit, "液体卸载器", {
    load() {
        this.super$load();
        centerRegion = Core.atlas.find(this.name + "-center");
        topRegion = [Core.atlas.find(this.name + "-top" + 1), Core.atlas.find(this.name + "-top" + 2)];
        arrowRegion = Core.atlas.find(this.name + "-arrow");
    },
    setStats(){
        this.super$setStats();
        this.stats.add(Stat.speed, amount * 60, StatUnit.liquidSecond);
        this.stats.remove(Stat.liquidCapacity);
    },
    drawPlanRegion(plan, list){
        Draw.rect(this.region, plan.drawx(), plan.drawy());
        Draw.rect((plan.rotation > 1 ? topRegion[1] : topRegion[0]), plan.drawx(), plan.drawy(), plan.rotation * 90);
        this.drawPlanConfig(plan, list);
    },
    drawPlanConfig(plan, list){
        this.drawPlanConfigCenter(plan, plan.config, this.name + "-center");
    },
    drawPlanConfigCenter(plan, content, region){
        if(content == null && !(content instanceof Liquid)) return;
        var color = content.color;
        Draw.color(color);
        Draw.rect(Core.atlas.find(region), plan.drawx(), plan.drawy());
        Draw.color();
    },
    setBars(){
        this.super$setBars();
        this.removeBar("liquid");
    },
    icons(){
        return [this.region, topRegion[0], arrowRegion];
    }
});

Object.assign(liquidUnloader, {
    group: BlockGroup.transportation,
    update: true,
    solid: true,
    hasLiquids: true,
    configurable: true,
    saveConfig: true,
    rotate: true,
    liquidCapacity: 0,
    noUpdateDisabled: true,
    envDisabled: Env.none,
    clearOnDoubleTap: true,
    priority: TargetPriority.transport,
    category: Category.liquid
});

liquidUnloader.buildType = prov(() => {
    var unloadLiquid = null;
    return extend(Building, {
        updateTile() {
            var front = this.front(), back = this.back();
            try{
                if(unloadLiquid != null && front != null && back != null && !(back.block instanceof Conduit) && front.team == this.team &&
                back.team == this.team && back.liquids != null && back.liquids.get(unloadLiquid) > 0){
                    back.transferLiquid(front, amount, unloadLiquid);
                }
            }catch(e){return;}
        },
        draw(){
            Draw.rect(this.block.region, this.x, this.y);
            Draw.rect((this.rotation > 1 ? topRegion[1] : topRegion[0]), this.x, this.y, this.rotdeg());
            if(unloadLiquid != null){
                Draw.color(unloadLiquid.color);
                Draw.rect(centerRegion, this.x, this.y);
                Draw.color();
            }else{
                Draw.rect(arrowRegion, this.x, this.y, this.rotdeg());
            }
        },
        buildConfiguration(table){
            ItemSelection.buildTable(this.block, table, Vars.content.liquids(), prov(() => unloadLiquid), cons((value) => this.configure(value)));
        },
        setLiquid(liquid){
            unloadLiquid = liquid;
        },
        write(write){
            this.super$write(write);
            write.s(unloadLiquid == null ? -1 : unloadLiquid.id);
            write.s(this.block.offset);
        },
        read(read, revision){
            this.super$read(read, revision);
            var id = read.s();
            unloadLiquid = id == -1 ? null : Vars.content.liquids().get(id);
            this.block.offset = read.s();
        }
    });
});
liquidUnloader.config(Liquid.__javaObject__, (tile, liquid) => tile.setLiquid(liquid));
liquidUnloader.configClear((tile) => tile.setLiquid(null));
liquidUnloader.buildVisibility = BuildVisibility.shown;
exports.liquidUnloader = liquidUnloader;