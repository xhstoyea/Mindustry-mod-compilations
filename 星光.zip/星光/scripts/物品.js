function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("铝")
newItem("硫")
newItem("合金钢")
newItem("铬")
newItem("银")
newItem("钠")
newItem("焦炭")
newItem("锇")
newItem("铱")
newItem("水晶玻璃")
newItem("泰坦合金")
newItem("混合盐")
newItem("硝化混合物")
newItem("氰化混合物")
newItem("重晶石")

