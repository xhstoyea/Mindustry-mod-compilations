var range = 10;
const CoreGenerator = extend(ConsumeGenerator, "核心电", {
    canPlaceOn(tile, team, rotation) {
        var canPlace = false;
        indexer.eachBlock(player.team(), Tmp.r1.setCentered(x, y, range * tilesize), b => (b instanceof CoreBuild), t => {
            canPlace = true;
        });
        return this.super$canPlaceOn(tile, team, rotation) && canPlace;
    }
});