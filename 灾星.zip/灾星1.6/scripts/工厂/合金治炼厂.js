const library = require("base/library");
const myitems = require("物品/物品");
const 合金治炼厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "合金治炼厂", [
  {
    input: {
    items: ["copper/10","lead/10"],
      power: 2,         
    },                      
    output: {
      items: ["灾星-铜铅合金/2"],
    },
    craftTime: 300,
  },
  {
    input: {
    items: ["lead/3","灾星-金/5"],  
      power: 2,                
    },
    output: {
      items: ["灾星-铅金合金/1"],
    },
    craftTime: 120,
  },    
]);