MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 40000
require("灾星");
require("工厂/合金治炼厂");
require("qwer");
require("items");

this.window = this;

for (let i = 0; i < 8; i++) {
	window["block" + i] = new Block("block" + i);
};

var node = TechTree.node;

TechTree.nodeRoot("灾星", 初级核心, () => {
	node(阿尔法二代, () => {
		node(block2, () => {
			node(block3, () => {});
		});
		node(block4, () => {
			node(block5, () => {});
		});
	});
	node(block6, () => {
		node(block7, () => {});
	});
});