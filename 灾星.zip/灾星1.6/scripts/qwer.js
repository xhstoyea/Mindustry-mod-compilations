
Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("[blue]灾星[yellow]信息栏");
    dialog.cont.image(Core.atlas.find("灾星-1")).row();;
    dialog.buttons.defaults().size(210, 64);
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(210, 64);
    dialog.cont.pane((() => {
        var table = new Table();   
         table.add("感谢游玩此模组，如果有建议可以给作者反馈\n感谢TQ，KTD，大豪的试玩，感谢ktd，大豪，tq提供的宝贵建议").left().growX().wrap().pad(4).labelAlign(Align.left).row();   
		 let label = new FLabel("[white]作者qq: {rainbow}3990824918");
		 table.add(label).left().row(); 
table.button("[red]更新日志", run(() => {
    var dialog2 = new BaseDialog("[red]更新日志");
    var table = new Table();
	
	var t = new Table();
	t.add("修改肥沃峡谷闪退问题\n添加多管，重管，冲击炮台\n添加基础物资制造权限及其工厂");
    dialog2.cont.add(new ScrollPane(t)).size(500, 600).row();
    dialog2.buttons.defaults().size(620, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(500, 64);
       dialog2.show();
    })).size(210, 64);
        return table;
    })()).grow().center().maxWidth(600);
    dialog.show();
}));