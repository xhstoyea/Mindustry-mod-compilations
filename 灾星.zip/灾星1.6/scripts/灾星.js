const lib = require("base/lib");
const 灾星 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(灾星, 4));
        this.super$load();
    }
}, "灾星", Planets.sun, 1);
const sS = require("base/sectorSize");
sS.planetGrid(灾星, 3.5);
//上面的是区块大小 ▲ 正常是3.3不建议乱改
灾星.generator = new SerpuloPlanetGenerator();
//可以将[Erekir]改成任何游戏中有的星球
灾星.atmosphereColor = Color.valueOf("#55cccc");//大气颜色
灾星.atmosphereRadIn = 0.09;//？？？
灾星.atmosphereRadOut = 0.3;//密度？
灾星.localizedName = "灾星";;
灾星.visible = true;//能否看得见
灾星.bloom = false;//这个不确定
灾星.accessible = true;//可达到？
灾星.alwaysUnlocked = true;//始终未锁定
灾星.startSector = 1;//开始的地方数量
灾星.orbitRadius = 100;//距离太阳
灾星.rotateTime = 2400;//一昼夜的时间(s)
//----分界线----从这往下可以复制增加区块
const 极寒荒漠 = new SectorPreset("极寒荒漠", 灾星, 1);//名字 星球 区块
极寒荒漠.description = "。";
极寒荒漠.difficulty = 1;//1-10
极寒荒漠.alwaysUnlocked = false;//总是解锁
极寒荒漠.addStartingItems = false;//允许添加初始资源
极寒荒漠.captureWave = 20;//多少波可占领
极寒荒漠.localizedName = "极寒荒漠";
exports.极寒荒漠 = 极寒荒漠;
lib.addToResearch(极寒荒漠, {
	parent: "groundZero",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});
const 肥沃峡谷 = new SectorPreset("肥沃峡谷", 灾星, 2);//名字 星球 区块
肥沃峡谷.description = "。";
肥沃峡谷.difficulty = 1;//1-10
肥沃峡谷.alwaysUnlocked = true;//总是解锁
肥沃峡谷.addStartingItems = false;//允许添加初始资源
肥沃峡谷.captureWave = 25;//多少波可占领
肥沃峡谷.localizedName = "肥沃峡谷";
exports.肥沃峡谷 = 肥沃峡谷;
lib.addToResearch(肥沃峡谷, {
	parent: "极寒荒漠",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.groundZero))
});
//---------分----界----线---------------
//防呆列表
//（灾星）随便写算是星球的名字
//想改turn或false的酌情使用,最好翻译一下
//想加新的区块可以复制上面的
//请不要乱改sectorSize.js
//记得自己加地图到外面的maps文件夹里
//
//
