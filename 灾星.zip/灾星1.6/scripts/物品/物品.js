function newItem(name) {
	exports[name] = (() => {
		let myItem = extend(Item, name, {});
		return myItem;
	})();
}
newItem("铜铅合金")
newItem("铅金合金")
newItem("金")
newItem("基础合金")



